# Add project specific ProGuard rules here.
-keep class com.bugor.engine.** { *; }
-keep class com.bugor.engine.BugorBridge { *; }
-keepclassmembers class com.bugor.engine.BugorBridge {
    native <methods>;
}
-keep class com.bugor.engine.MainActivity { *; }
-keep class com.bugor.engine.BugorApplication { *; }
-keep class com.bugor.engine.BugorService { *; }
-keep class com.bugor.engine.OverlayActivity { *; }
-keep class com.bugor.engine.BootReceiver { *; }

-keep class com.bugor.engine.** { *; }
-keepclassmembers class com.bugor.engine.** { *; }

-keep class * {
    native <methods>;
}

-keep class * extends android.app.Activity
-keep class * extends android.app.Service
-keep class * extends android.content.BroadcastReceiver
-keep class * extends android.app.Application

-dontwarn com.bugor.engine.**
-dontwarn **
-ignorewarnings

-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
-keepattributes Exceptions, InnerClasses, Signature, Deprecated, SourceFile, LineNumberTable, *Annotation*, EnclosingMethod

-keep class android.** { *; }
-keep class androidx.** { *; }
