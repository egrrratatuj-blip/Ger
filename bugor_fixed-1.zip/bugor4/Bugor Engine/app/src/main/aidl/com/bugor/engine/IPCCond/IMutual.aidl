package com.bugor.engine.IPCCond;

import android.view.Surface;

interface IMutual {
    void setSurface(in Surface surface);
    String start(int width, int height);
    void MotionEventClick(int action, int pointerId, float x, float y, float pressure);
    float[] GetImGuiwinsize();
    void setPid(int pid);
    void setKey(String key);
    void setUUid(String uuid);
}
