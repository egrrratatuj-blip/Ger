#pragma once
#include <cstdio>
#include <cstdarg>
#include <cstring>
#include <ctime>
#include <mutex>
#include <string>

namespace Logging {

enum Level { VERBOSE, DEBUG, INFO, WARN, ERROR, FATAL };

class Logger {
public:
    Logger(const char* tag);
    void Log(Level level, const char* format, ...);
    void V(const char* fmt, ...);
    void D(const char* fmt, ...);
    void I(const char* fmt, ...);
    void W(const char* fmt, ...);
    void E(const char* fmt, ...);
    void F(const char* fmt, ...);
private:
    char m_tag[32];
    static FILE* s_file;
    static std::mutex s_mutex;
    static int s_fileSize;
    void Write(Level level, const char* msg);
};

Logger& GetLogger(const char* tag);
void Init(const char* logDir);
void Shutdown();

}
