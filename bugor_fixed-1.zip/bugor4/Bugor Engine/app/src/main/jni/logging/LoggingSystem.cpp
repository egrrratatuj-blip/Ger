#include "LoggingSystem.h"
#include <sys/stat.h>
#include <unistd.h>
#include <android/log.h>
#include <vector>
#include <cstdio>

namespace Logging {

namespace {
    const size_t RING_SIZE = 1000;
    const size_t MAX_FILE_BYTES = 10 * 1024 * 1024;
    const int MAX_BACKUPS = 3;

    static std::string s_ringBuffer[RING_SIZE];
    static size_t s_ringHead = 0;
    static size_t s_ringCount = 0;
    static std::mutex s_ringMutex;
    static std::string s_logDir;
}

FILE* Logger::s_file = nullptr;
std::mutex Logger::s_mutex;
int Logger::s_fileSize = 0;
static Logger* s_loggers[64];
static int s_loggerCount = 0;

static const char* LevelStr(Level level) {
    switch (level) {
        case VERBOSE: return "V";
        case DEBUG:   return "D";
        case INFO:    return "I";
        case WARN:    return "W";
        case ERROR:   return "E";
        case FATAL:   return "F";
    }
    return "?";
}

static int AndroidLevel(Level level) {
    switch (level) {
        case VERBOSE: return ANDROID_LOG_VERBOSE;
        case DEBUG:   return ANDROID_LOG_DEBUG;
        case INFO:    return ANDROID_LOG_INFO;
        case WARN:    return ANDROID_LOG_WARN;
        case ERROR:   return ANDROID_LOG_ERROR;
        case FATAL:   return ANDROID_LOG_FATAL;
    }
    return ANDROID_LOG_DEFAULT;
}

static std::string Timestamp() {
    time_t now = time(nullptr);
    struct tm t;
    localtime_r(&now, &t);
    char buf[32];
    strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", &t);
    return buf;
}

static void RotateFiles() {
    std::string oldest = s_logDir + "/bugor.log." + std::to_string(MAX_BACKUPS);
    remove(oldest.c_str());
    for (int i = MAX_BACKUPS - 1; i >= 1; --i) {
        std::string from = s_logDir + "/bugor.log." + std::to_string(i);
        std::string to = s_logDir + "/bugor.log." + std::to_string(i + 1);
        rename(from.c_str(), to.c_str());
    }
    std::string current = s_logDir + "/bugor.log";
    std::string backup = s_logDir + "/bugor.log.1";
    rename(current.c_str(), backup.c_str());
    Logger::s_file = fopen(current.c_str(), "w");
    Logger::s_fileSize = 0;
}

Logger::Logger(const char* tag) {
    strncpy(m_tag, tag, sizeof(m_tag) - 1);
    m_tag[sizeof(m_tag) - 1] = '\0';
}

void Logger::Write(Level level, const char* msg) {
    std::string line = "[" + Timestamp() + "][" + LevelStr(level) + "][" + m_tag + "] " + msg;
    {
        std::lock_guard<std::mutex> lock(s_ringMutex);
        s_ringBuffer[(s_ringHead + s_ringCount) % RING_SIZE] = line;
        if (s_ringCount < RING_SIZE) {
            s_ringCount++;
        } else {
            s_ringHead = (s_ringHead + 1) % RING_SIZE;
        }
    }
    if (level >= DEBUG) {
        __android_log_print(AndroidLevel(level), m_tag, "%s", msg);
    }
    {
        std::lock_guard<std::mutex> lock(s_mutex);
        if (s_file) {
            fprintf(s_file, "%s\n", line.c_str());
            s_fileSize += (int)line.size() + 1;
            fflush(s_file);
            if (s_fileSize >= (int)MAX_FILE_BYTES) {
                fclose(s_file);
                s_file = nullptr;
                RotateFiles();
            }
        }
    }
}

void Logger::Log(Level level, const char* format, ...) {
    char buf[4096];
    va_list args;
    va_start(args, format);
    vsnprintf(buf, sizeof(buf), format, args);
    va_end(args);
    Write(level, buf);
}

void Logger::V(const char* fmt, ...) {
    char buf[4096];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    Write(VERBOSE, buf);
}

void Logger::D(const char* fmt, ...) {
    char buf[4096];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    Write(DEBUG, buf);
}

void Logger::I(const char* fmt, ...) {
    char buf[4096];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    Write(INFO, buf);
}

void Logger::W(const char* fmt, ...) {
    char buf[4096];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    Write(WARN, buf);
}

void Logger::E(const char* fmt, ...) {
    char buf[4096];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    Write(ERROR, buf);
}

void Logger::F(const char* fmt, ...) {
    char buf[4096];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    Write(FATAL, buf);
}

Logger& GetLogger(const char* tag) {
    for (int i = 0; i < s_loggerCount; ++i) {
        if (strcmp(s_loggers[i]->m_tag, tag) == 0) {
            return *s_loggers[i];
        }
    }
    s_loggers[s_loggerCount] = new Logger(tag);
    return *s_loggers[s_loggerCount++];
}

void Init(const char* logDir) {
    std::lock_guard<std::mutex> lock(Logger::s_mutex);
    s_logDir = logDir;
    mkdir(logDir, 0755);
    std::string path = s_logDir + "/bugor.log";
    Logger::s_file = fopen(path.c_str(), "a");
    if (Logger::s_file) {
        fseek(Logger::s_file, 0, SEEK_END);
        Logger::s_fileSize = ftell(Logger::s_file);
    }
}

void Shutdown() {
    std::lock_guard<std::mutex> lock(Logger::s_mutex);
    if (Logger::s_file) {
        fclose(Logger::s_file);
        Logger::s_file = nullptr;
    }
}

std::vector<std::string> GetRecentLogs(size_t count) {
    std::lock_guard<std::mutex> lock(s_ringMutex);
    std::vector<std::string> result;
    if (s_ringCount == 0) return result;
    size_t n = count < s_ringCount ? count : s_ringCount;
    size_t start = (s_ringCount < RING_SIZE) ? 0 : s_ringHead;
    for (size_t i = 0; i < n; ++i) {
        result.push_back(s_ringBuffer[(start + i) % RING_SIZE]);
    }
    return result;
}

}
