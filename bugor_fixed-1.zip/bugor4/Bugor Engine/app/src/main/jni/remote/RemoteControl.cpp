#include "RemoteControl.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <cstdio>
#include <cerrno>
#include <cinttypes>
#include <arpa/inet.h>
#include <fcntl.h>
#include <poll.h>

Packet::Packet()
{
    memset(&header, 0, sizeof(header));
    header.magic = 0x4247524D;
    header.version = 1;
    header.sequence = 0;
    header.timestamp = static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count());
    header.flags = 0;
    header.compression = 0;
}

Packet::Packet(PacketType type, const std::vector<uint8_t> &data)
    : Packet()
{
    header.type = static_cast<uint16_t>(type);
    payload = data;
    header.payload_length = static_cast<uint32_t>(data.size());
    header.checksum = calculateChecksum();
}

Packet::Packet(PacketType type, const std::string &data)
    : Packet(type, std::vector<uint8_t>(data.begin(), data.end()))
{
}

std::vector<uint8_t> Packet::serialize() const
{
    std::vector<uint8_t> result(sizeof(PacketHeader) + payload.size());
    memcpy(result.data(), &header, sizeof(PacketHeader));
    if (!payload.empty()) memcpy(result.data() + sizeof(PacketHeader), payload.data(), payload.size());
    return result;
}

bool Packet::deserialize(const std::vector<uint8_t> &data)
{
    if (data.size() < sizeof(PacketHeader)) return false;
    memcpy(&header, data.data(), sizeof(PacketHeader));
    size_t remaining = data.size() - sizeof(PacketHeader);
    if (remaining < header.payload_length) return false;
    payload.resize(header.payload_length);
    if (header.payload_length > 0) memcpy(payload.data(), data.data() + sizeof(PacketHeader), header.payload_length);
    return true;
}

bool Packet::validate() const
{
    if (header.magic != 0x4247524D) return false;
    if (header.payload_length != static_cast<uint32_t>(payload.size())) return false;
    return header.checksum == calculateChecksum();
}

bool Packet::compress()
{
    return false;
}

bool Packet::decompress()
{
    return false;
}

bool Packet::encrypt(const std::vector<uint8_t> &key)
{
    (void)key;
    return false;
}

bool Packet::decrypt(const std::vector<uint8_t> &key)
{
    (void)key;
    return false;
}

uint32_t Packet::calculateChecksum() const
{
    uint32_t sum = 0;
    for (size_t i = 0; i < payload.size(); ++i) sum += payload[i];
    return sum;
}

size_t Packet::size() const
{
    return sizeof(PacketHeader) + payload.size();
}

void Packet::setPriority(MessagePriority priority)
{
    header.flags = (header.flags & ~0x03) | static_cast<uint16_t>(priority);
}

MessagePriority Packet::getPriority() const
{
    return static_cast<MessagePriority>(header.flags & 0x03);
}

bool Packet::isHeartbeat() const
{
    return header.type == static_cast<uint16_t>(PacketType::Heartbeat) ||
           header.type == static_cast<uint16_t>(PacketType::HeartbeatAck);
}

bool Packet::isCommand() const
{
    return header.type == static_cast<uint16_t>(PacketType::Command) ||
           header.type == static_cast<uint16_t>(PacketType::CommandResult) ||
           header.type == static_cast<uint16_t>(PacketType::CommandError);
}

bool Packet::isData() const
{
    return header.type == static_cast<uint16_t>(PacketType::DataTransfer) ||
           header.type == static_cast<uint16_t>(PacketType::DataAck);
}

bool Packet::isStream() const
{
    return header.type >= static_cast<uint16_t>(PacketType::StreamStart) &&
           header.type <= static_cast<uint16_t>(PacketType::StreamError);
}

bool Packet::isLog() const
{
    return header.type == static_cast<uint16_t>(PacketType::LogEntry) ||
           header.type == static_cast<uint16_t>(PacketType::LogBulk);
}

bool Packet::isEvent() const
{
    return header.type == static_cast<uint16_t>(PacketType::Event) ||
           header.type == static_cast<uint16_t>(PacketType::EventBatch);
}

bool Packet::isError() const
{
    return header.type == static_cast<uint16_t>(PacketType::Error) ||
           header.type == static_cast<uint16_t>(PacketType::Disconnect) ||
           header.type == static_cast<uint16_t>(PacketType::Shutdown);
}

RemoteControlServer::RemoteControlServer()
    : running(false)
    , listening(false)
    , initialized(false)
    , loggingEnabled(false)
    , server_fd(-1)
    , epoll_fd(-1)
    , event_fd(-1)
    , ssl_ctx(nullptr)
    , acceptThread(nullptr)
    , workerThread(nullptr)
    , heartbeatThread(nullptr)
    , threadsRunning(false)
    , nextClientId(1)
    , totalBytesSent(0)
    , totalBytesReceived(0)
    , totalPackets(0)
    , totalCommands(0)
    , totalErrors(0)
{
}

RemoteControlServer::~RemoteControlServer()
{
    shutdown();
}

bool RemoteControlServer::initialize(const ServerConfig &config)
{
    if (initialized) return true;
    this->config = config;
    if (!createServerSocket()) return false;
    if (!setupEpoll()) return false;
    if (config.use_ssl && !setupSSL()) return false;
    initialized = true;
    return true;
}

void RemoteControlServer::shutdown()
{
    if (!initialized) return;
    threadsRunning = false;
    stop();
    if (acceptThread) { acceptThread->join(); delete acceptThread; acceptThread = nullptr; }
    if (workerThread) { workerThread->join(); delete workerThread; workerThread = nullptr; }
    if (heartbeatThread) { heartbeatThread->join(); delete heartbeatThread; heartbeatThread = nullptr; }
    if (server_fd >= 0) { close(server_fd); server_fd = -1; }
    if (epoll_fd >= 0) { close(epoll_fd); epoll_fd = -1; }
    if (event_fd >= 0) { close(event_fd); event_fd = -1; }
    if (ssl_ctx) { SSL_CTX_free(ssl_ctx); ssl_ctx = nullptr; }
    clients.clear();
    commandHandlers.clear();
    initialized = false;
}

bool RemoteControlServer::isRunning() const
{
    return running;
}

bool RemoteControlServer::start()
{
    if (!initialized || running) return false;
    if (listen(server_fd, config.backlog > 0 ? config.backlog : SOMAXCONN) < 0) return false;
    struct epoll_event ev;
    ev.events = EPOLLIN;
    ev.data.fd = server_fd;
    if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, server_fd, &ev) < 0) return false;
    listening = true;
    running = true;
    threadsRunning = true;
    acceptThread = new std::thread(&RemoteControlServer::acceptLoop, this);
    workerThread = new std::thread(&RemoteControlServer::workerLoop, this);
    heartbeatThread = new std::thread(&RemoteControlServer::heartbeatLoop, this);
    return true;
}

bool RemoteControlServer::stop()
{
    if (!running) return false;
    running = false;
    listening = false;
    threadsRunning = false;
    if (server_fd >= 0) {
        epoll_ctl(epoll_fd, EPOLL_CTL_DEL, server_fd, nullptr);
    }
    return true;
}

bool RemoteControlServer::restart()
{
    stop();
    return start();
}

bool RemoteControlServer::isListening() const
{
    return listening;
}

bool RemoteControlServer::broadcast(const Packet &packet)
{
    std::lock_guard<std::mutex> lock(clientMutex);
    bool all_ok = true;
    for (auto &kv : clients) {
        if (kv.second.state == ConnectionState::Connected || kv.second.state == ConnectionState::Authenticated) {
            if (!sendTo(kv.first, packet)) all_ok = false;
        }
    }
    return all_ok;
}

bool RemoteControlServer::broadcast(const std::string &command, const std::string &data)
{
    Packet packet(PacketType::Command, data);
    CommandPacket cmd;
    cmd.command = command;
    cmd.args = data;
    return broadcast(packet);
}

bool RemoteControlServer::sendTo(uint32_t client_id, const Packet &packet)
{
    auto it = clients.find(client_id);
    if (it == clients.end()) return false;
    auto serialized = packet.serialize();
    ssize_t sent = write(it->second.fd, serialized.data(), serialized.size());
    if (sent > 0) {
        totalBytesSent += static_cast<uint64_t>(sent);
        ++totalPackets;
        it->second.session.bytes_sent += static_cast<uint64_t>(sent);
        return true;
    }
    return false;
}

bool RemoteControlServer::sendTo(const std::string &client_id, const CommandPacket &cmd)
{
    for (auto &kv : clients) {
        if (kv.second.session.client_id == client_id) {
            Packet packet(PacketType::Command, cmd.command);
            return sendTo(kv.first, packet);
        }
    }
    return false;
}

void RemoteControlServer::registerCommandHandler(const std::string &command, std::function<std::string(const CommandPacket&)> handler)
{
    std::lock_guard<std::mutex> lock(handlerMutex);
    commandHandlers[command] = handler;
}

void RemoteControlServer::unregisterCommandHandler(const std::string &command)
{
    std::lock_guard<std::mutex> lock(handlerMutex);
    commandHandlers.erase(command);
}

void RemoteControlServer::registerEventHandler(std::function<void(uint32_t, const Packet&)> handler)
{
    eventHandler = handler;
}

void RemoteControlServer::registerConnectionHandler(std::function<void(uint32_t, bool)> handler)
{
    connectionHandler = handler;
}

bool RemoteControlServer::disconnectClient(uint32_t client_id)
{
    std::lock_guard<std::mutex> lock(clientMutex);
    cleanupClient(client_id);
    return true;
}

bool RemoteControlServer::disconnectAll()
{
    std::lock_guard<std::mutex> lock(clientMutex);
    for (auto &kv : clients) {
        cleanupClient(kv.first);
    }
    clients.clear();
    return true;
}

uint32_t RemoteControlServer::getClientCount() const
{
    return static_cast<uint32_t>(clients.size());
}

std::vector<ClientConnection> RemoteControlServer::getClients() const
{
    std::vector<ClientConnection> result;
    for (const auto &kv : clients) result.push_back(kv.second);
    return result;
}

ClientConnection RemoteControlServer::getClient(uint32_t client_id) const
{
    auto it = clients.find(client_id);
    return it != clients.end() ? it->second : ClientConnection();
}

std::vector<uint32_t> RemoteControlServer::getClientIDs() const
{
    std::vector<uint32_t> ids;
    for (const auto &kv : clients) ids.push_back(kv.first);
    return ids;
}

bool RemoteControlServer::hasClient(uint32_t client_id) const
{
    return clients.find(client_id) != clients.end();
}

ServerConfig RemoteControlServer::getConfig() const
{
    return config;
}

bool RemoteControlServer::setConfig(const ServerConfig &config)
{
    this->config = config;
    return true;
}

void RemoteControlServer::setMaxConnections(uint32_t max)
{
    config.max_connections = max;
}

void RemoteControlServer::setRateLimit(uint32_t limit)
{
    config.rate_limit = limit;
}

uint64_t RemoteControlServer::getTotalBytesSent() const
{
    return totalBytesSent;
}

uint64_t RemoteControlServer::getTotalBytesReceived() const
{
    return totalBytesReceived;
}

uint32_t RemoteControlServer::getTotalPackets() const
{
    return totalPackets;
}

uint32_t RemoteControlServer::getTotalCommands() const
{
    return totalCommands;
}

uint32_t RemoteControlServer::getTotalErrors() const
{
    return totalErrors;
}

RemoteError RemoteControlServer::getLastError() const
{
    return lastError;
}

bool RemoteControlServer::isSSLEnabled() const
{
    return config.use_ssl;
}

bool RemoteControlServer::isCompressionEnabled() const
{
    return config.enable_compression;
}

bool RemoteControlServer::isEncryptionEnabled() const
{
    return config.require_encryption;
}

void RemoteControlServer::enableLogging(bool enable)
{
    loggingEnabled = enable;
}

void RemoteControlServer::setLogFile(const std::string &path)
{
    if (logStream.is_open()) logStream.close();
    logStream.open(path, std::ios::app);
    loggingEnabled = true;
}

bool RemoteControlServer::createServerSocket()
{
    server_fd = socket(AF_INET, config.enable_ipv6 ? SOCK_STREAM : SOCK_STREAM, 0);
    if (server_fd < 0) return false;
    int opt = 1;
    if (config.enable_reuse_addr) setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
    if (config.enable_tcp_nodelay) setsockopt(server_fd, IPPROTO_TCP, TCP_NODELAY, &opt, sizeof(opt));
    setNonBlocking(server_fd);
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(config.port);
    if (!config.bind_address.empty()) {
        inet_pton(AF_INET, config.bind_address.c_str(), &addr.sin_addr);
    } else {
        addr.sin_addr.s_addr = INADDR_ANY;
    }
    if (bind(server_fd, reinterpret_cast<struct sockaddr*>(&addr), sizeof(addr)) < 0) return false;
    return true;
}

bool RemoteControlServer::setupEpoll()
{
    epoll_fd = epoll_create1(0);
    if (epoll_fd < 0) return false;
    if (config.enable_eventfd) {
        event_fd = eventfd(0, EFD_NONBLOCK);
        if (event_fd >= 0) {
            struct epoll_event ev;
            ev.events = EPOLLIN;
            ev.data.fd = event_fd;
            epoll_ctl(epoll_fd, EPOLL_CTL_ADD, event_fd, &ev);
        }
    }
    return true;
}

bool RemoteControlServer::setupSSL()
{
    SSL_load_error_strings();
    OpenSSL_add_all_algorithms();
    ssl_ctx = SSL_CTX_new(TLS_server_method());
    if (!ssl_ctx) return false;
    if (!config.certificate_path.empty() && !config.private_key_path.empty()) {
        SSL_CTX_use_certificate_file(ssl_ctx, config.certificate_path.c_str(), SSL_FILETYPE_PEM);
        SSL_CTX_use_PrivateKey_file(ssl_ctx, config.private_key_path.c_str(), SSL_FILETYPE_PEM);
    }
    return true;
}

bool RemoteControlServer::acceptConnection()
{
    struct sockaddr_in client_addr;
    socklen_t addr_len = sizeof(client_addr);
    int client_fd = accept(server_fd, reinterpret_cast<struct sockaddr*>(&client_addr), &addr_len);
    if (client_fd < 0) return false;
    std::lock_guard<std::mutex> lock(clientMutex);
    if (clients.size() >= config.max_connections) { close(client_fd); return false; }
    uint32_t id = nextClientId++;
    ClientConnection conn;
    conn.fd = client_fd;
    conn.id = id;
    conn.address = inet_ntoa(client_addr.sin_addr);
    conn.port = ntohs(client_addr.sin_port);
    conn.state = ConnectionState::Connected;
    conn.connected_at = std::chrono::system_clock::now();
    conn.last_activity = conn.connected_at;
    conn.session.connected_at = static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            conn.connected_at.time_since_epoch()).count());
    conn.session.state = ConnectionState::Connected;
    conn.authenticated = false;
    conn.encrypted = false;
    if (config.use_ssl) {
        conn.ssl = SSL_new(ssl_ctx);
        SSL_set_fd(conn.ssl, client_fd);
    }
    setNonBlocking(client_fd);
    clients[id] = conn;
    if (connectionHandler) connectionHandler(id, true);
    return true;
}

void RemoteControlServer::handleClient(int fd)
{
    (void)fd;
}

void RemoteControlServer::processClient(ClientConnection &client)
{
    uint8_t buf[BUFFER_SIZE];
    ssize_t n = read(client.fd, buf, sizeof(buf));
    if (n > 0) {
        client.read_buffer.insert(client.read_buffer.end(), buf, buf + n);
        totalBytesReceived += static_cast<uint64_t>(n);
        client.session.bytes_received += static_cast<uint64_t>(n);
        client.last_activity = std::chrono::system_clock::now();
        while (client.read_buffer.size() >= sizeof(PacketHeader)) {
            Packet packet;
            std::vector<uint8_t> pkt_data(client.read_buffer.begin(), client.read_buffer.begin() + sizeof(PacketHeader) + reinterpret_cast<PacketHeader*>(client.read_buffer.data())->payload_length);
            if (pkt_data.size() > client.read_buffer.size()) break;
            if (packet.deserialize(pkt_data)) {
                processPacket(client, packet);
                client.read_buffer.erase(client.read_buffer.begin(), client.read_buffer.begin() + pkt_data.size());
            } else {
                break;
            }
        }
    } else if (n == 0) {
        cleanupClient(client.id);
    }
}

void RemoteControlServer::processPacket(ClientConnection &client, const Packet &packet)
{
    ++totalPackets;
    ++client.session.packet_count;
    if (packet.isHeartbeat()) {
        Packet ack(PacketType::HeartbeatAck, std::vector<uint8_t>());
        sendTo(client.id, ack);
    } else if (packet.isCommand()) {
        CommandPacket cmd;
        cmd.command = std::string(packet.payload.begin(), packet.payload.end());
        handleCommand(client, cmd);
    } else if (packet.isError()) {
        ++totalErrors;
    } else if (packet.isEvent()) {
        if (eventHandler) eventHandler(client.id, packet);
    }
}

void RemoteControlServer::handleCommand(ClientConnection &client, const CommandPacket &cmd)
{
    ++totalCommands;
    ++client.session.command_count;
    std::lock_guard<std::mutex> lock(handlerMutex);
    auto it = commandHandlers.find(cmd.command);
    if (it != commandHandlers.end()) {
        std::string result = it->second(cmd);
        sendResponse(client, result, "");
    } else {
        sendResponse(client, "", "Unknown command: " + cmd.command);
    }
}

void RemoteControlServer::sendResponse(ClientConnection &client, const std::string &response, const std::string &error)
{
    if (error.empty()) {
        Packet pkt(PacketType::CommandResult, response);
        sendTo(client.id, pkt);
    } else {
        Packet pkt(PacketType::CommandError, error);
        sendTo(client.id, pkt);
    }
}

void RemoteControlServer::cleanupClient(uint32_t client_id)
{
    auto it = clients.find(client_id);
    if (it == clients.end()) return;
    if (it->second.ssl) { SSL_shutdown(it->second.ssl); SSL_free(it->second.ssl); }
    close(it->second.fd);
    if (connectionHandler) connectionHandler(client_id, false);
    clients.erase(it);
}

void RemoteControlServer::sendError(ClientConnection &client, RemoteError error, const std::string &message)
{
    lastError = error;
    ++totalErrors;
    Packet pkt(PacketType::Error, message);
    sendTo(client.id, pkt);
}

void RemoteControlServer::acceptLoop()
{
    while (threadsRunning) {
        struct epoll_event events[MAX_EVENTS];
        int nfds = epoll_wait(epoll_fd, events, MAX_EVENTS, 100);
        for (int i = 0; i < nfds; ++i) {
            if (events[i].data.fd == server_fd) {
                while (acceptConnection()) {}
            } else if (events[i].data.fd == event_fd) {
                uint64_t val;
                read(event_fd, &val, sizeof(val));
            } else {
                auto it = clients.find(events[i].data.fd);
                if (it != clients.end()) {
                    processClient(it->second);
                }
            }
        }
    }
}

void RemoteControlServer::workerLoop()
{
    while (threadsRunning) {
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
}

void RemoteControlServer::heartbeatLoop()
{
    while (threadsRunning) {
        std::this_thread::sleep_for(std::chrono::milliseconds(config.keepalive_interval > 0 ? config.keepalive_interval : 30000));
        Packet hb(PacketType::Heartbeat, std::vector<uint8_t>());
        broadcast(hb);
    }
}

void RemoteControlServer::setNonBlocking(int fd)
{
    int flags = fcntl(fd, F_GETFL, 0);
    fcntl(fd, F_SETFL, flags | O_NONBLOCK);
}

void RemoteControlServer::setSocketOptions(int fd)
{
    int opt = 1;
    setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, &opt, sizeof(opt));
    if (config.enable_tcp_nodelay) setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &opt, sizeof(opt));
}

bool RemoteControlServer::authenticateClient(ClientConnection &client, const Packet &packet)
{
    (void)packet;
    client.authenticated = true;
    client.state = ConnectionState::Authenticated;
    return true;
}

bool RemoteControlServer::validatePacket(const Packet &packet) const
{
    return packet.validate();
}

void RemoteControlServer::log(const std::string &message)
{
    if (loggingEnabled && logStream.is_open()) {
        logStream << message << "\n";
    }
}

RemoteControlClient::RemoteControlClient()
    : initialized(false)
    , connected(false)
    , autoReconnect(false)
    , loggingEnabled(false)
    , sock(-1)
    , ssl(nullptr)
    , ssl_ctx(nullptr)
    , readThread(nullptr)
    , heartbeatThread(nullptr)
    , reconnectThread(nullptr)
    , threadsRunning(false)
    , shouldReconnect(false)
    , sequenceNumber(0)
    , bytesSent(0)
    , bytesReceived(0)
    , packetCount(0)
    , commandCount(0)
    , errorCount(0)
    , reconnectCount(0)
{
}

RemoteControlClient::~RemoteControlClient()
{
    shutdown();
}

bool RemoteControlClient::initialize(const ClientConfig &config)
{
    if (initialized) return true;
    this->config = config;
    session.session_id = "client_" + std::to_string(static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count()));
    session.client_id = config.client_id;
    session.client_version = config.client_version;
    if (config.use_ssl && !setupSSL()) return false;
    initialized = true;
    return true;
}

void RemoteControlClient::shutdown()
{
    if (!initialized) return;
    threadsRunning = false;
    shouldReconnect = false;
    disconnect();
    if (readThread) { readThread->join(); delete readThread; readThread = nullptr; }
    if (heartbeatThread) { heartbeatThread->join(); delete heartbeatThread; heartbeatThread = nullptr; }
    if (reconnectThread) { reconnectThread->join(); delete reconnectThread; reconnectThread = nullptr; }
    if (ssl) { SSL_free(ssl); ssl = nullptr; }
    if (ssl_ctx) { SSL_CTX_free(ssl_ctx); ssl_ctx = nullptr; }
    initialized = false;
}

bool RemoteControlClient::isInitialized() const
{
    return initialized;
}

bool RemoteControlClient::isConnected() const
{
    return connected;
}

bool RemoteControlClient::connect()
{
    if (!initialized || connected) return false;
    if (!createSocket()) return false;
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(config.server_port);
    if (inet_pton(AF_INET, config.server_host.c_str(), &addr.sin_addr) <= 0) return false;
    if (config.connect_timeout > 0) {
        struct timeval tv;
        tv.tv_sec = config.connect_timeout / 1000;
        tv.tv_usec = (config.connect_timeout % 1000) * 1000;
        setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
        setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    }
    if (::connect(sock, reinterpret_cast<struct sockaddr*>(&addr), sizeof(addr)) < 0) {
        lastError = RemoteError::ConnectionFailed;
        close(sock);
        sock = -1;
        return false;
    }
    connected = true;
    session.state = ConnectionState::Connected;
    session.connected_at = static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count());
    connectTime = std::chrono::system_clock::now();
    if (config.use_ssl) {
        ssl = SSL_new(ssl_ctx);
        SSL_set_fd(ssl, sock);
        if (SSL_connect(ssl) <= 0) {
            lastError = RemoteError::EncryptionError;
            disconnect();
            return false;
        }
        session.encrypted = true;
    }
    if (config.enable_auth && !authenticate()) {
        lastError = RemoteError::AuthenticationFailed;
        disconnect();
        return false;
    }
    threadsRunning = true;
    readThread = new std::thread(&RemoteControlClient::readLoop, this);
    heartbeatThread = new std::thread(&RemoteControlClient::handleHeartbeat, this);
    if (config.auto_reconnect && autoReconnect) {
        shouldReconnect = true;
    }
    if (connectionHandler) connectionHandler(true);
    return true;
}

bool RemoteControlClient::disconnect()
{
    if (!connected) return false;
    threadsRunning = false;
    connected = false;
    session.state = ConnectionState::Disconnected;
    if (ssl) { SSL_shutdown(ssl); SSL_free(ssl); ssl = nullptr; }
    if (sock >= 0) { close(sock); sock = -1; }
    if (connectionHandler) connectionHandler(false);
    return true;
}

bool RemoteControlClient::reconnect()
{
    disconnect();
    return connect();
}

ConnectionState RemoteControlClient::getState() const
{
    return session.state;
}

std::future<std::string> RemoteControlClient::sendCommand(const std::string &command, const std::string &args, uint32_t timeout_ms)
{
    CommandPacket cmd;
    cmd.command = command;
    cmd.args = args;
    cmd.timeout_ms = timeout_ms;
    cmd.synchronous = true;
    return sendCommand(cmd);
}

std::future<std::string> RemoteControlClient::sendCommand(const CommandPacket &cmd)
{
    std::promise<std::string> promise;
    auto future = promise.get_future();
    uint64_t seq = sequenceNumber++;
    std::lock_guard<std::mutex> lock(pendingMutex);
    pendingCommands[seq] = std::move(promise);
    Packet packet(PacketType::Command, cmd.command);
    packet.header.sequence = seq;
    if (connected) sendPacket(packet);
    return future;
}

bool RemoteControlClient::sendAsync(const std::string &command, const std::string &args)
{
    Packet packet(PacketType::Command, command);
    return sendPacket(packet);
}

bool RemoteControlClient::sendPacket(const Packet &packet)
{
    if (!connected) return false;
    std::lock_guard<std::mutex> lock(sendMutex);
    auto data = packet.serialize();
    ++packetCount;
    ++session.packet_count;
    ssize_t sent;
    if (ssl) {
        sent = SSL_write(ssl, data.data(), static_cast<int>(data.size()));
    } else {
        sent = write(sock, data.data(), data.size());
    }
    if (sent > 0) {
        bytesSent += static_cast<uint64_t>(sent);
        session.bytes_sent += static_cast<uint64_t>(sent);
    }
    return sent > 0;
}

bool RemoteControlClient::sendPacket(PacketType type, const std::vector<uint8_t> &data)
{
    return sendPacket(Packet(type, data));
}

bool RemoteControlClient::sendPacket(PacketType type, const std::string &data)
{
    return sendPacket(Packet(type, data));
}

bool RemoteControlClient::sendHeartbeat()
{
    Packet hb(PacketType::Heartbeat, std::vector<uint8_t>());
    return sendPacket(hb);
}

bool RemoteControlClient::sendLog(const std::string &log_entry)
{
    Packet pkt(PacketType::LogEntry, log_entry);
    return sendPacket(pkt);
}

bool RemoteControlClient::sendLogs(const std::vector<std::string> &log_entries)
{
    for (const auto &entry : log_entries) {
        if (!sendLog(entry)) return false;
    }
    return true;
}

bool RemoteControlClient::sendEvent(const std::string &event_name, const std::string &event_data)
{
    std::string combined = event_name + ":" + event_data;
    Packet pkt(PacketType::Event, combined);
    return sendPacket(pkt);
}

bool RemoteControlClient::sendStream(const std::string &stream_id, const std::vector<uint8_t> &data)
{
    std::vector<uint8_t> combined;
    combined.insert(combined.end(), stream_id.begin(), stream_id.end());
    combined.push_back(0);
    combined.insert(combined.end(), data.begin(), data.end());
    Packet pkt(PacketType::StreamData, combined);
    return sendPacket(pkt);
}

bool RemoteControlClient::sendStreamEnd(const std::string &stream_id)
{
    Packet pkt(PacketType::StreamEnd, stream_id);
    return sendPacket(pkt);
}

void RemoteControlClient::registerResponseHandler(std::function<void(const CommandPacket&)> handler)
{
    responseHandler = handler;
}

void RemoteControlClient::registerEventHandler(std::function<void(const std::string&, const std::string&)> handler)
{
    eventHandler = handler;
}

void RemoteControlClient::registerLogHandler(std::function<void(const std::string&)> handler)
{
    logHandler = handler;
}

void RemoteControlClient::registerConnectionHandler(std::function<void(bool)> handler)
{
    connectionHandler = handler;
}

void RemoteControlClient::registerErrorHandler(std::function<void(RemoteError, const std::string&)> handler)
{
    errorHandler = handler;
}

ClientConfig RemoteControlClient::getConfig() const
{
    return config;
}

bool RemoteControlClient::setConfig(const ClientConfig &config)
{
    this->config = config;
    return true;
}

void RemoteControlClient::setReconnectDelay(uint32_t delay)
{
    config.reconnect_delay = delay;
}

void RemoteControlClient::setMaxReconnectDelay(uint32_t delay)
{
    config.max_reconnect_delay = delay;
}

void RemoteControlClient::setMaxReconnectAttempts(uint32_t attempts)
{
    config.max_reconnect_attempts = attempts;
}

SessionInfo RemoteControlClient::getSession() const
{
    return session;
}

std::string RemoteControlClient::getSessionId() const
{
    return session.session_id;
}

std::string RemoteControlClient::getClientId() const
{
    return session.client_id;
}

uint64_t RemoteControlClient::getBytesSent() const
{
    return bytesSent;
}

uint64_t RemoteControlClient::getBytesReceived() const
{
    return bytesReceived;
}

uint32_t RemoteControlClient::getPacketCount() const
{
    return packetCount;
}

uint32_t RemoteControlClient::getCommandCount() const
{
    return commandCount;
}

uint32_t RemoteControlClient::getErrorCount() const
{
    return errorCount;
}

uint32_t RemoteControlClient::getReconnectCount() const
{
    return reconnectCount;
}

RemoteError RemoteControlClient::getLastError() const
{
    return lastError;
}

bool RemoteControlClient::isSSLEnabled() const
{
    return config.use_ssl;
}

bool RemoteControlClient::isCompressionEnabled() const
{
    return config.use_compression;
}

bool RemoteControlClient::isEncryptionEnabled() const
{
    return config.use_encryption;
}

void RemoteControlClient::enableLogging(bool enable)
{
    loggingEnabled = enable;
}

void RemoteControlClient::setLogFile(const std::string &path)
{
    if (logStream.is_open()) logStream.close();
    logStream.open(path, std::ios::app);
    loggingEnabled = true;
}

void RemoteControlClient::enableAutoReconnect(bool enable)
{
    autoReconnect = enable;
    shouldReconnect = enable;
    if (enable && !connected && initialized && !reconnectThread) {
        reconnectThread = new std::thread(&RemoteControlClient::reconnectLoop, this);
    }
}

bool RemoteControlClient::isAutoReconnectEnabled() const
{
    return autoReconnect;
}

bool RemoteControlClient::createSocket()
{
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) return false;
    if (config.use_tcp_nodelay) {
        int opt = 1;
        setsockopt(sock, IPPROTO_TCP, TCP_NODELAY, &opt, sizeof(opt));
    }
    if (config.use_keepalive) {
        int opt = 1;
        setsockopt(sock, SOL_SOCKET, SO_KEEPALIVE, &opt, sizeof(opt));
    }
    return true;
}

bool RemoteControlClient::setupSSL()
{
    SSL_load_error_strings();
    OpenSSL_add_all_algorithms();
    ssl_ctx = SSL_CTX_new(TLS_client_method());
    if (!ssl_ctx) return false;
    if (!config.ca_cert_path.empty()) {
        SSL_CTX_load_verify_locations(ssl_ctx, config.ca_cert_path.c_str(), nullptr);
    }
    if (config.verify_certificate) SSL_CTX_set_verify(ssl_ctx, SSL_VERIFY_PEER, nullptr);
    return true;
}

bool RemoteControlClient::performHandshake()
{
    Packet hb(PacketType::Heartbeat, std::vector<uint8_t>());
    return sendPacket(hb);
}

bool RemoteControlClient::authenticate()
{
    Packet auth(PacketType::Custom, config.api_key);
    return sendPacket(auth);
}

bool RemoteControlClient::sendRaw(const std::vector<uint8_t> &data)
{
    ssize_t sent = write(sock, data.data(), data.size());
    return sent > 0;
}

std::vector<uint8_t> RemoteControlClient::readRaw()
{
    uint8_t buf[BUFFER_SIZE];
    ssize_t n;
    if (ssl) {
        n = SSL_read(ssl, buf, sizeof(buf));
    } else {
        n = read(sock, buf, sizeof(buf));
    }
    if (n > 0) {
        bytesReceived += static_cast<uint64_t>(n);
        session.bytes_received += static_cast<uint64_t>(n);
        return std::vector<uint8_t>(buf, buf + n);
    }
    return {};
}

void RemoteControlClient::readLoop()
{
    while (threadsRunning && connected) {
        uint8_t buf[BUFFER_SIZE];
        ssize_t n;
        if (ssl) {
            n = SSL_read(ssl, buf, sizeof(buf));
        } else {
            n = read(sock, buf, sizeof(buf));
        }
        if (n > 0) {
            bytesReceived += static_cast<uint64_t>(n);
            session.bytes_received += static_cast<uint64_t>(n);
            session.last_activity = static_cast<uint64_t>(
                std::chrono::duration_cast<std::chrono::milliseconds>(
                    std::chrono::system_clock::now().time_since_epoch()).count());
            Packet packet;
            std::vector<uint8_t> pkt_data(buf, buf + n);
            if (packet.deserialize(pkt_data)) {
                processPacket(packet);
            }
        } else if (n == 0) {
            break;
        }
    }
    if (connected) {
        disconnect();
        if (autoReconnect && shouldReconnect) {
            if (!reconnectThread) {
                reconnectThread = new std::thread(&RemoteControlClient::reconnectLoop, this);
            }
        }
    }
}

void RemoteControlClient::processPacket(const Packet &packet)
{
    ++packetCount;
    if (packet.isHeartbeat()) {
        Packet ack(PacketType::HeartbeatAck, std::vector<uint8_t>());
        sendPacket(ack);
    } else if (packet.isCommand()) {
        CommandPacket cmd;
        cmd.command = std::string(packet.payload.begin(), packet.payload.end());
        handleCommandResult(cmd);
    } else if (packet.isEvent()) {
        if (eventHandler) {
            std::string content(packet.payload.begin(), packet.payload.end());
            size_t colon = content.find(':');
            if (colon != std::string::npos) {
                eventHandler(content.substr(0, colon), content.substr(colon + 1));
            } else {
                eventHandler(content, "");
            }
        }
    } else if (packet.isLog()) {
        if (logHandler) {
            logHandler(std::string(packet.payload.begin(), packet.payload.end()));
        }
    } else if (packet.isError()) {
        ++errorCount;
        handleError(packet);
    }
}

void RemoteControlClient::handleHeartbeat()
{
    while (threadsRunning && connected) {
        std::this_thread::sleep_for(std::chrono::milliseconds(config.ping_interval > 0 ? config.ping_interval : 30000));
        if (connected) sendHeartbeat();
    }
}

void RemoteControlClient::handleCommandResult(const CommandPacket &cmd)
{
    (void)cmd;
}

void RemoteControlClient::handleError(const Packet &packet)
{
    std::string msg(packet.payload.begin(), packet.payload.end());
    if (errorHandler) errorHandler(RemoteError::NetworkError, msg);
}

void RemoteControlClient::reconnectLoop()
{
    while (shouldReconnect && !connected) {
        std::this_thread::sleep_for(std::chrono::milliseconds(config.reconnect_delay > 0 ? config.reconnect_delay : 1000));
        if (!shouldReconnect) break;
        if (connect()) {
            ++reconnectCount;
            break;
        }
    }
    reconnectThread = nullptr;
}

void RemoteControlClient::setNonBlocking(int fd)
{
    int flags = fcntl(fd, F_GETFL, 0);
    fcntl(fd, F_SETFL, flags | O_NONBLOCK);
}

bool RemoteControlClient::waitForData(int fd, uint32_t timeout_ms)
{
    struct pollfd pfd;
    pfd.fd = fd;
    pfd.events = POLLIN;
    return poll(&pfd, 1, static_cast<int>(timeout_ms)) > 0;
}

void RemoteControlClient::log(const std::string &message)
{
    if (loggingEnabled && logStream.is_open()) {
        logStream << message << "\n";
    }
}
