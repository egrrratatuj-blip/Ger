#ifndef BUGOR_REMOTE_CONTROL_H
#define BUGOR_REMOTE_CONTROL_H

#include <string>
#include <vector>
#include <map>
#include <functional>
#include <memory>
#include <mutex>
#include <atomic>
#include <thread>
#include <chrono>
#include <queue>
#include <sstream>
#include <fstream>
#include <cstdint>
#include <cstring>
#include <algorithm>
#include <random>
#include <set>
#include <future>
#include <iomanip>

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/epoll.h>
#include <sys/eventfd.h>
#include <sys/timerfd.h>
#include <unistd.h>
#include <fcntl.h>
#include <netdb.h>
#include <poll.h>
#include <signal.h>
#include <errno.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/hmac.h>
#include <zlib.h>

#define MAX_EVENTS 1024
#define BUFFER_SIZE 65536
#define MAX_CONNECTIONS 256
#define HANDSHAKE_TIMEOUT 10000
#define RECONNECT_DELAY 1000
#define MAX_RECONNECT_DELAY 30000
#define PING_INTERVAL 30000
#define MAX_PACKET_SIZE 1048576
#define RATE_LIMIT_WINDOW 1000
#define MAX_RATE_REQUESTS 60

enum class PacketType : uint16_t {
    Heartbeat = 0x0001,
    HeartbeatAck = 0x0002,
    Command = 0x0010,
    CommandResult = 0x0011,
    CommandError = 0x0012,
    DataTransfer = 0x0020,
    DataAck = 0x0021,
    StreamStart = 0x0030,
    StreamData = 0x0031,
    StreamEnd = 0x0032,
    StreamError = 0x0033,
    LogEntry = 0x0040,
    LogBulk = 0x0041,
    Event = 0x0050,
    EventBatch = 0x0051,
    Error = 0xFFF0,
    Disconnect = 0xFFF1,
    Shutdown = 0xFFF2,
    Reconnect = 0xFFF3,
    Custom = 0x1000
};

enum class MessagePriority {
    Low = 0,
    Normal = 1,
    High = 2,
    Critical = 3
};

enum class ConnectionState {
    Disconnected,
    Connecting,
    Connected,
    Authenticating,
    Authenticated,
    Reconnecting,
    ShuttingDown
};

enum class RemoteError {
    None,
    ConnectionFailed,
    AuthenticationFailed,
    Timeout,
    ProtocolError,
    EncryptionError,
    CompressionError,
    RateLimited,
    ServerFull,
    Unauthorized,
    InvalidCommand,
    ExecutionFailed,
    NetworkError,
    ResourceExhausted,
    SecurityViolation,
    VersionMismatch
};

struct PacketHeader {
    uint32_t magic;
    uint16_t version;
    uint16_t type;
    uint64_t sequence;
    uint64_t timestamp;
    uint32_t payload_length;
    uint32_t checksum;
    uint16_t flags;
    uint16_t compression;
    uint8_t reserved[8];
};

struct CommandPacket {
    uint64_t command_id;
    std::string command;
    std::string args;
    std::string sender;
    uint32_t timeout_ms;
    bool requires_ack;
    bool synchronous;
    MessagePriority priority;
    std::map<std::string, std::string> metadata;
};

struct SessionInfo {
    std::string session_id;
    std::string client_id;
    std::string client_version;
    std::string device_info;
    std::string platform;
    std::string api_key;
    std::string auth_token;
    std::string encryption_key;
    uint32_t protocol_version;
    uint32_t keepalive;
    uint64_t connected_at;
    uint64_t last_activity;
    uint64_t bytes_sent;
    uint64_t bytes_received;
    uint32_t packet_count;
    uint32_t command_count;
    uint32_t error_count;
    uint32_t reconnect_count;
    bool authenticated;
    bool encrypted;
    bool compressed;
    ConnectionState state;
};

struct ServerConfig {
    std::string host;
    uint16_t port;
    std::string bind_address;
    std::string server_name;
    std::string server_version;
    std::string api_key;
    std::string certificate_path;
    std::string private_key_path;
    std::string ca_cert_path;
    std::string allowed_origins;
    std::string rate_limit_policy;
    std::string log_path;
    uint32_t max_connections;
    uint32_t max_packet_size;
    uint32_t keepalive_interval;
    uint32_t handshake_timeout;
    uint32_t idle_timeout;
    uint32_t rate_limit;
    uint32_t backlog;
    uint32_t worker_threads;
    uint32_t buffer_size;
    uint32_t tls_version;
    bool use_ssl;
    bool require_auth;
    bool require_encryption;
    bool enable_compression;
    bool enable_ipv6;
    bool enable_reuse_addr;
    bool enable_tcp_nodelay;
    bool enable_keepalive;
    bool enable_backlog;
    bool enable_epoll;
    bool enable_eventfd;
    bool enable_timerfd;
};

struct ClientConfig {
    std::string server_host;
    uint16_t server_port;
    std::string client_id;
    std::string client_version;
    std::string device_id;
    std::string device_name;
    std::string platform;
    std::string api_key;
    std::string auth_token;
    std::string encryption_key;
    std::string proxy_host;
    std::string proxy_auth;
    std::string ca_cert_path;
    std::string client_cert_path;
    std::string client_key_path;
    uint16_t proxy_port;
    uint32_t connect_timeout;
    uint32_t read_timeout;
    uint32_t write_timeout;
    uint32_t reconnect_delay;
    uint32_t max_reconnect_delay;
    uint32_t max_reconnect_attempts;
    uint32_t keepalive_interval;
    uint32_t ping_interval;
    uint32_t max_packet_size;
    uint32_t buffer_size;
    uint32_t tls_version;
    uint32_t rate_limit;
    uint32_t reconnect_count;
    uint32_t command_timeout;
    bool use_ssl;
    bool use_compression;
    bool use_encryption;
    bool auto_reconnect;
    bool use_proxy;
    bool use_ipv6;
    bool use_tcp_nodelay;
    bool use_keepalive;
    bool verify_certificate;
    bool enable_heartbeat;
    bool enable_ping;
    bool enable_auth;
    bool enable_backlog;
    bool enable_events;
    bool enable_streaming;
    bool enable_bulk_transfer;
};

class RemoteControlServer;
class RemoteControlClient;

struct ClientConnection {
    int fd;
    uint32_t id;
    std::string address;
    uint16_t port;
    ConnectionState state;
    SessionInfo session;
    std::chrono::system_clock::time_point connected_at;
    std::chrono::system_clock::time_point last_activity;
    std::vector<uint8_t> read_buffer;
    std::vector<uint8_t> write_buffer;
    std::queue<CommandPacket> command_queue;
    SSL *ssl;
    bool authenticated;
    bool encrypted;
};

class RemoteErrorEvent {
public:
    RemoteError error;
    std::string message;
    uint32_t code;
    bool fatal;
};

class Packet {
public:
    PacketHeader header;
    std::vector<uint8_t> payload;

    Packet();
    Packet(PacketType type, const std::vector<uint8_t> &data);
    Packet(PacketType type, const std::string &data);

    std::vector<uint8_t> serialize() const;
    bool deserialize(const std::vector<uint8_t> &data);
    bool validate() const;
    bool compress();
    bool decompress();
    bool encrypt(const std::vector<uint8_t> &key);
    bool decrypt(const std::vector<uint8_t> &key);
    uint32_t calculateChecksum() const;
    size_t size() const;
    void setPriority(MessagePriority priority);
    MessagePriority getPriority() const;
    bool isHeartbeat() const;
    bool isCommand() const;
    bool isData() const;
    bool isStream() const;
    bool isLog() const;
    bool isEvent() const;
    bool isError() const;
};

class RemoteControlServer {
public:
    RemoteControlServer();
    ~RemoteControlServer();

    bool initialize(const ServerConfig &config);
    void shutdown();
    bool isRunning() const;

    bool start();
    bool stop();
    bool restart();
    bool isListening() const;

    bool broadcast(const Packet &packet);
    bool broadcast(const std::string &command, const std::string &data);
    bool sendTo(uint32_t client_id, const Packet &packet);
    bool sendTo(const std::string &client_id, const CommandPacket &cmd);

    void registerCommandHandler(const std::string &command, std::function<std::string(const CommandPacket&)> handler);
    void unregisterCommandHandler(const std::string &command);
    void registerEventHandler(std::function<void(uint32_t, const Packet&)> handler);
    void registerConnectionHandler(std::function<void(uint32_t, bool connected)> handler);

    bool disconnectClient(uint32_t client_id);
    bool disconnectAll();
    uint32_t getClientCount() const;
    std::vector<ClientConnection> getClients() const;
    ClientConnection getClient(uint32_t client_id) const;
    std::vector<uint32_t> getClientIDs() const;
    bool hasClient(uint32_t client_id) const;

    ServerConfig getConfig() const;
    bool setConfig(const ServerConfig &config);
    void setMaxConnections(uint32_t max);
    void setRateLimit(uint32_t limit);

    uint64_t getTotalBytesSent() const;
    uint64_t getTotalBytesReceived() const;
    uint32_t getTotalPackets() const;
    uint32_t getTotalCommands() const;
    uint32_t getTotalErrors() const;
    RemoteError getLastError() const;

    bool isSSLEnabled() const;
    bool isCompressionEnabled() const;
    bool isEncryptionEnabled() const;

    void enableLogging(bool enable);
    void setLogFile(const std::string &path);

private:
    bool running;
    bool listening;
    bool initialized;
    bool loggingEnabled;

    ServerConfig config;
    RemoteError lastError;

    int server_fd;
    int epoll_fd;
    int event_fd;
    SSL_CTX *ssl_ctx;
    std::thread *acceptThread;
    std::thread *workerThread;
    std::thread *heartbeatThread;
    std::atomic<bool> threadsRunning;

    std::mutex clientMutex;
    std::mutex handlerMutex;
    std::mutex packetMutex;

    std::map<uint32_t, ClientConnection> clients;
    uint32_t nextClientId;

    std::map<std::string, std::function<std::string(const CommandPacket&)>> commandHandlers;
    std::function<void(uint32_t, const Packet&)> eventHandler;
    std::function<void(uint32_t, bool)> connectionHandler;

    std::ofstream logStream;
    char readBuffer[BUFFER_SIZE];
    char writeBuffer[BUFFER_SIZE];

    uint64_t totalBytesSent;
    uint64_t totalBytesReceived;
    uint32_t totalPackets;
    uint32_t totalCommands;
    uint32_t totalErrors;
    std::chrono::system_clock::time_point startTime;

    bool createServerSocket();
    bool setupEpoll();
    bool setupSSL();
    bool acceptConnection();
    void handleClient(int fd);
    void processClient(ClientConnection &client);
    void processPacket(ClientConnection &client, const Packet &packet);
    void handleCommand(ClientConnection &client, const CommandPacket &cmd);
    void sendResponse(ClientConnection &client, const std::string &response, const std::string &error);
    void cleanupClient(uint32_t client_id);
    void sendError(ClientConnection &client, RemoteError error, const std::string &message);
    void acceptLoop();
    void workerLoop();
    void heartbeatLoop();
    void setNonBlocking(int fd);
    void setSocketOptions(int fd);
    bool authenticateClient(ClientConnection &client, const Packet &packet);
    bool validatePacket(const Packet &packet) const;
    void log(const std::string &message);
};

class RemoteControlClient {
public:
    RemoteControlClient();
    ~RemoteControlClient();

    bool initialize(const ClientConfig &config);
    void shutdown();
    bool isInitialized() const;
    bool isConnected() const;

    bool connect();
    bool disconnect();
    bool reconnect();
    ConnectionState getState() const;

    std::future<std::string> sendCommand(const std::string &command, const std::string &args = "", uint32_t timeout_ms = 5000);
    std::future<std::string> sendCommand(const CommandPacket &cmd);
    bool sendAsync(const std::string &command, const std::string &args = "");
    bool sendPacket(const Packet &packet);
    bool sendPacket(PacketType type, const std::vector<uint8_t> &data);
    bool sendPacket(PacketType type, const std::string &data);
    bool sendHeartbeat();
    bool sendLog(const std::string &log_entry);
    bool sendLogs(const std::vector<std::string> &log_entries);
    bool sendEvent(const std::string &event_name, const std::string &event_data);
    bool sendStream(const std::string &stream_id, const std::vector<uint8_t> &data);
    bool sendStreamEnd(const std::string &stream_id);

    void registerResponseHandler(std::function<void(const CommandPacket&)> handler);
    void registerEventHandler(std::function<void(const std::string&, const std::string&)> handler);
    void registerLogHandler(std::function<void(const std::string&)> handler);
    void registerConnectionHandler(std::function<void(bool)> handler);
    void registerErrorHandler(std::function<void(RemoteError, const std::string&)> handler);

    ClientConfig getConfig() const;
    bool setConfig(const ClientConfig &config);
    void setReconnectDelay(uint32_t delay);
    void setMaxReconnectDelay(uint32_t delay);
    void setMaxReconnectAttempts(uint32_t attempts);

    SessionInfo getSession() const;
    std::string getSessionId() const;
    std::string getClientId() const;

    uint64_t getBytesSent() const;
    uint64_t getBytesReceived() const;
    uint32_t getPacketCount() const;
    uint32_t getCommandCount() const;
    uint32_t getErrorCount() const;
    uint32_t getReconnectCount() const;
    RemoteError getLastError() const;

    bool isSSLEnabled() const;
    bool isCompressionEnabled() const;
    bool isEncryptionEnabled() const;

    void enableLogging(bool enable);
    void setLogFile(const std::string &path);
    void enableAutoReconnect(bool enable);
    bool isAutoReconnectEnabled() const;

private:
    bool initialized;
    bool connected;
    bool autoReconnect;
    bool loggingEnabled;

    ClientConfig config;
    RemoteError lastError;
    SessionInfo session;

    int sock;
    SSL *ssl;
    SSL_CTX *ssl_ctx;

    std::thread *readThread;
    std::thread *heartbeatThread;
    std::thread *reconnectThread;
    std::atomic<bool> threadsRunning;
    std::atomic<bool> shouldReconnect;

    std::mutex sendMutex;
    std::mutex recvMutex;
    std::mutex handlerMutex;
    std::mutex pendingMutex;

    uint64_t sequenceNumber;
    uint64_t bytesSent;
    uint64_t bytesReceived;
    uint32_t packetCount;
    uint32_t commandCount;
    uint32_t errorCount;
    uint32_t reconnectCount;
    std::chrono::system_clock::time_point connectTime;
    std::chrono::system_clock::time_point lastHeartbeat;

    std::map<uint64_t, std::promise<std::string>> pendingCommands;
    std::function<void(const CommandPacket&)> responseHandler;
    std::function<void(const std::string&, const std::string&)> eventHandler;
    std::function<void(const std::string&)> logHandler;
    std::function<void(bool)> connectionHandler;
    std::function<void(RemoteError, const std::string&)> errorHandler;

    std::ofstream logStream;
    char readBuffer[BUFFER_SIZE];

    bool createSocket();
    bool setupSSL();
    bool performHandshake();
    bool authenticate();
    bool sendRaw(const std::vector<uint8_t> &data);
    std::vector<uint8_t> readRaw();
    void readLoop();
    void processPacket(const Packet &packet);
    void handleHeartbeat();
    void handleCommandResult(const CommandPacket &cmd);
    void handleError(const Packet &packet);
    void reconnectLoop();
    void setNonBlocking(int fd);
    bool waitForData(int fd, uint32_t timeout_ms);
    void log(const std::string &message);
};

#endif
