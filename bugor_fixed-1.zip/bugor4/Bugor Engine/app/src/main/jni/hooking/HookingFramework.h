#ifndef BUGOR_HOOKING_FRAMEWORK_H
#define BUGOR_HOOKING_FRAMEWORK_H

#include <string>
#include <vector>
#include <map>
#include <functional>
#include <memory>
#include <mutex>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <algorithm>
#include <set>
#include <unordered_map>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <thread>
#include <chrono>

#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <dlfcn.h>
#include <elf.h>
#include <link.h>

#ifdef __aarch64__
#include <sys/ptrace.h>
#include <asm/ptrace.h>
#endif

struct HookConfig {
    std::string target_module;
    std::string target_function;
    uintptr_t target_address;
    std::string hook_name;
    uint32_t priority;
    uint32_t call_count;
    uint32_t max_calls;
    uint32_t max_hook_depth;
    uint32_t timeout_ms;
    uint32_t retry_count;
    uint64_t interval_ns;
    int hook_type;
    bool enabled;
    bool auto_remove;
    bool thread_safe;
    bool replace_original;
    bool preserve_caller;
    bool skip_on_error;
    bool async_execution;
    bool log_calls;
    bool log_args;
    bool log_result;
    bool log_stack;
    bool breakpoint_on_call;
    bool bypass_security;
    bool wait_for_module;
    bool hook_on_module_load;
    bool hook_library;
    bool hook_all_functions;
    bool trampoline_only;
    bool inline_hook;
    bool got_hook;
    bool detour_hook;
    bool vtable_hook;
    bool symbol_hook;
    bool debug_symbols;
    bool frida_compat;
    bool xposed_compat;
    bool cydia_compat;
    bool substrate_compat;
    bool elf_rewrite;
    bool process_memory;
    bool kernel_mode;
    bool stealth_mode;
    bool anti_detection;
    bool encrypt_hooks;
    bool persist_across_fork;
    std::vector<uint8_t> hook_bytes;
    std::vector<uint8_t> original_bytes;
    std::vector<uintptr_t> hook_addresses;
    std::vector<std::string> module_filters;
    std::map<std::string, std::string> hook_options;
    void *callback_data;
    void *user_data;
    std::function<void(uintptr_t, void*, size_t)> pre_callback;
    std::function<void(uintptr_t, void*, size_t)> post_callback;
    std::function<void(uintptr_t, void*, size_t)> replace_callback;
};

struct HookInfo {
    uint32_t id;
    std::string name;
    std::string module_name;
    std::string function_name;
    uintptr_t target_address;
    uintptr_t trampoline_address;
    uintptr_t detour_address;
    uintptr_t original_function;
    void *hook_function;
    size_t hook_size;
    size_t original_size;
    int hook_type;
    uint32_t call_count;
    uint32_t install_count;
    uint32_t error_count;
    bool enabled;
    bool installed;
    bool paused;
    bool is_inline;
    bool is_got;
    bool is_vtable;
    bool is_detour;
    bool is_trampoline;
    bool persistent;
    std::chrono::system_clock::time_point installed_at;
    std::chrono::system_clock::time_point last_called;
    std::vector<HookInfo> nested_hooks;
    HookConfig config;
};

enum class HookType {
    Inline = 0,
    GOT = 1,
    Detour = 2,
    VTable = 3,
    Symbol = 4,
    Trampoline = 5,
    PLT = 6,
    IAT = 7,
    EAT = 8,
    Import = 9,
    Export = 10,
    Breakpoint = 11,
    Instruction,
    Function,
    Library,
    API,
    Syscall,
    Kernel,
    Hybrid,
    Dynamic,
    Static,
    Proxy
};

struct HookStatistics {
    uint32_t total_hooks;
    uint32_t active_hooks;
    uint32_t paused_hooks;
    uint32_t failed_hooks;
    uint32_t removed_hooks;
    uint32_t total_calls;
    uint32_t intercepted_calls;
    uint32_t bypassed_calls;
    uint32_t errors;
    uint32_t timeouts;
    uint64_t total_hook_time_us;
    uint64_t avg_hook_time_us;
    uint64_t max_hook_time_us;
    double success_rate;
    double performance_score;
    std::map<std::string, uint32_t> hook_type_counts;
    std::map<std::string, double> module_hit_rates;
};

struct HookContext {
    uintptr_t original_function;
    uintptr_t trampoline;
    void *user_data;
    std::vector<uintptr_t> saved_registers;
    std::vector<uint8_t> saved_stack;
    bool should_skip;
    bool should_replace;
    bool should_break;
    int return_code;
    bool modified_return;
    uintptr_t return_value;
    void *stack_pointer;
    void *frame_pointer;
    void *instruction_pointer;
    std::map<std::string, uint64_t> arguments;
    std::vector<uint8_t> argument_data;
    std::vector<uint8_t> result_data;
    uint32_t arg_count;
    uint32_t call_depth;
    uint64_t call_timestamp;
    uint64_t elapsed_ns;
};

enum class HookEvent {
    BeforeInstall,
    AfterInstall,
    BeforeUninstall,
    AfterUninstall,
    BeforeCall,
    AfterCall,
    OnError,
    OnTimeout,
    OnDetect,
    OnBypass,
    OnReplace,
    ModuleLoaded,
    ModuleUnloaded,
    ThreadCreated,
    ThreadDestroyed,
    Fork,
    Exec
};

struct TrampolineInfo {
    uintptr_t address;
    size_t size;
    uint8_t *original_code;
    uint8_t *trampoline_code;
    bool in_use;
    bool is_original;
    std::string owner_hook;
};

class HookingFramework {
public:
    HookingFramework();
    ~HookingFramework();

    bool initialize();
    void shutdown();
    bool isInitialized() const;
    bool isAvailable() const;

    uint32_t installHook(const HookConfig &config);
    bool uninstallHook(uint32_t hook_id);
    bool uninstallAllHooks();
    bool uninstallHooksByModule(const std::string &module_name);
    bool uninstallHooksByType(HookType type);
    bool uninstallHooksByPattern(const std::string &pattern);

    bool enableHook(uint32_t hook_id);
    bool disableHook(uint32_t hook_id);
    bool pauseHook(uint32_t hook_id);
    bool resumeHook(uint32_t hook_id);

    bool isHookInstalled(uint32_t hook_id) const;
    bool isHookEnabled(uint32_t hook_id) const;
    HookInfo getHookInfo(uint32_t hook_id) const;
    std::vector<HookInfo> getActiveHooks() const;
    std::vector<HookInfo> getAllHooks() const;
    uint32_t getHookCount() const;
    uint32_t getActiveHookCount() const;

    void setPreHookCallback(uint32_t hook_id, std::function<void(uintptr_t, void*, size_t)> callback);
    void setPostHookCallback(uint32_t hook_id, std::function<void(uintptr_t, void*, size_t)> callback);
    void setReplaceCallback(uint32_t hook_id, std::function<void(uintptr_t, void*, size_t)> callback);
    void setGlobalPreHook(std::function<void(uint32_t, uintptr_t, void*, size_t)> callback);
    void setGlobalPostHook(std::function<void(uint32_t, uintptr_t, void*, size_t)> callback);

    HookConfig getHookConfig(uint32_t hook_id) const;
    bool updateHookConfig(uint32_t hook_id, const HookConfig &config);

    uintptr_t getOriginalFunction(uint32_t hook_id) const;
    uintptr_t getTrampolineAddress(uint32_t hook_id) const;
    void *getHookFunction(uint32_t hook_id) const;

    bool backupOriginal(uint32_t hook_id);
    bool restoreOriginal(uint32_t hook_id);
    bool restoreAllOriginals();

    uint32_t installInlineHook(uintptr_t target, void *hook, size_t size);
    uint32_t installGOTHook(const std::string &module, const std::string &function, void *hook);
    uint32_t installDetourHook(uintptr_t target, void *hook, uint32_t length);
    uint32_t installVTableHook(void *instance, uint32_t index, void *hook);
    uint32_t installSymbolHook(const std::string &module, const std::string &symbol, void *hook);
    uint32_t installPLTHook(const std::string &module, const std::string &function, void *hook);
    uint32_t installBreakpointHook(uintptr_t address, void *hook);
    uint32_t installInstructionHook(uintptr_t address, void *hook, size_t size);

    uint32_t hookFunction(uintptr_t address, void *hook_function, void **original);
    uint32_t hookFunction(const std::string &module, const std::string &function, void *hook, void **original);
    uint32_t hookMethod(void *instance, uint32_t method_index, void *hook, void **original);
    uint32_t hookLibrary(const std::string &library, const std::string &function, void *hook, void **original);

    bool replaceFunction(uint32_t hook_id, void *new_function);
    bool replaceFunction(uintptr_t target, void *new_function);
    bool replaceFunction(const std::string &module, const std::string &function, void *new_function);

    bool createTrampoline(uintptr_t target, uintptr_t &trampoline, size_t size);
    bool destroyTrampoline(uintptr_t trampoline);
    bool createInlineTrampoline(uintptr_t target, uintptr_t &trampoline, size_t size);
    
    uintptr_t getOrCreateTrampoline(uint32_t hook_id);
    uintptr_t findFreeTrampoline(size_t size);
    bool isAddressInTrampoline(uintptr_t addr);

    bool writeHookCode(uintptr_t address, const std::vector<uint8_t> &code);
    bool writeHookCode(uintptr_t address, const void *code, size_t size);
    bool writeNOPs(uintptr_t address, size_t count);
    bool writeBranch(uintptr_t source, uintptr_t target);
    bool writeCall(uintptr_t source, uintptr_t target);
    bool writeJump(uintptr_t source, uintptr_t target);

    std::vector<uint8_t> readCode(uintptr_t address, size_t size);
    std::vector<uint8_t> generateTrampolineCode(uintptr_t target, uintptr_t trampoline_addr);
    std::vector<uint8_t> generateHookCode(uintptr_t target, uintptr_t hook_func);
    std::vector<uint8_t> generateNOPCode(size_t count);

    bool protectMemory(uintptr_t address, size_t size, int protection);
    bool makeMemoryExecutable(uintptr_t address, size_t size);
    bool makeMemoryWritable(uintptr_t address, size_t size);
    bool makeMemoryReadable(uintptr_t address, size_t size);
    bool makeMemoryReadWrite(uintptr_t address, size_t size);
    bool makeMemoryReadExecute(uintptr_t address, size_t size);
    bool makeMemoryReadWriteExecute(uintptr_t address, size_t size);

    bool flushCache(uintptr_t address, size_t size);
    bool flushInstructionCache();
    bool flushDataCache(uintptr_t address, size_t size);

    uintptr_t resolveSymbol(const std::string &symbol);
    uintptr_t resolveSymbol(const std::string &module, const std::string &symbol);
    uintptr_t resolvePLTEntry(const std::string &module, const std::string &function);
    uintptr_t resolveGOTEntry(const std::string &module, const std::string &function);

    void *loadLibrary(const std::string &path);
    bool unloadLibrary(void *handle);
    bool isLibraryLoaded(const std::string &name);
    uintptr_t getLibraryBase(const std::string &name);
    std::vector<std::pair<std::string, uintptr_t>> getLoadedLibraries();

    std::string getLibraryPath(const std::string &name);
    std::vector<std::string> getLibraryDependencies(const std::string &name);
    void *getSymbolAddress(void *handle, const std::string &symbol);

    std::vector<std::string> enumerateExportedFunctions(const std::string &module);
    std::vector<std::string> enumerateImportedFunctions(const std::string &module);
    std::vector<std::string> enumerateSymbols(const std::string &module);

    size_t getHookSize(uint32_t hook_id) const;
    size_t getRequiredHookSize(uintptr_t address) const;
    size_t getMinimumHookSize() const;
    size_t getPluginSize() const;

    HookStatistics getStatistics() const;
    void resetStatistics();
    void enableStatistics(bool enable);
    bool isStatisticsEnabled() const;

    void enableLogging(bool enable);
    bool isLoggingEnabled() const;
    void setLogFile(const std::string &path);

    void addExclusion(const std::string &module, const std::string &function);
    void removeExclusion(const std::string &module, const std::string &function);
    bool isExcluded(const std::string &module, const std::string &function) const;
    void clearExclusions();

    void enableStealthMode(bool enable);
    bool isStealthModeEnabled() const;
    void enableAntiDetection(bool enable);
    bool isAntiDetectionEnabled() const;
    void enableEncryption(bool enable);
    bool isEncryptionEnabled() const;

    void registerEventListener(std::function<void(HookEvent, uint32_t)> listener);
    void unregisterEventListener();

    std::string getVersion() const;
    std::string getArchitecture() const;
    std::string getHookTypeName(HookType type) const;

    bool saveState(const std::string &path);
    bool loadState(const std::string &path);

private:
    static HookingFramework *instance;
    bool initialized;
    bool statisticsEnabled;
    bool loggingEnabled;
    bool stealthMode;
    bool antiDetection;
    bool encryptionEnabled;

    std::mutex hookMutex;
    std::mutex trampolineMutex;

    std::unordered_map<uint32_t, HookInfo> hooks;
    std::vector<TrampolineInfo> trampolines;
    std::vector<std::pair<std::string, std::string>> exclusions;
    HookStatistics statistics;
    std::set<uintptr_t> trampolineAddresses;

    std::function<void(uint32_t, uintptr_t, void*, size_t)> globalPreHook;
    std::function<void(uint32_t, uintptr_t, void*, size_t)> globalPostHook;
    std::function<void(HookEvent, uint32_t)> eventListener;

    uint32_t nextHookId;
    std::string logPath;
    std::ofstream logStream;

    std::vector<uint8_t> armTrampolineTemplate;
    std::vector<uint8_t> arm64TrampolineTemplate;
    std::vector<uint8_t> x86TrampolineTemplate;
    std::vector<uint8_t> x64TrampolineTemplate;

    uint32_t generateHookId();
    bool validateHookConfig(const HookConfig &config) const;
    bool writeMemoryProtected(uintptr_t address, const void *data, size_t size);
    bool readMemorySafe(uintptr_t address, void *buffer, size_t size);
    bool isAddressValid(uintptr_t address) const;
    bool isMemoryRegionExecutable(uintptr_t address) const;

    void initializeTemplates();
    void cleanupTrampolines();
    void logHookOperation(const std::string &operation, uint32_t hook_id);
    void updateStatistics(const HookInfo &info);
    void fireEvent(HookEvent event, uint32_t hook_id);

    bool findNOPsInRange(uintptr_t start, size_t size, std::vector<uintptr_t> &nops);
    bool isNOP(uintptr_t address);

    uintptr_t findGOTEntry(const std::string &module, const std::string &function);
    uintptr_t findPLTEntry(const std::string &module, const std::string &function);
    uintptr_t findExportEntry(const std::string &module, const std::string &function);

    bool parseElfSymbols(const std::string &module, std::vector<std::string> &symbols, bool is_export);
    Elf64_Addr getElfSymbolAddress(const std::string &module, const std::string &symbol);
    Elf64_Addr getElfFunctionAddress(const std::string &module, const std::string &function);

    bool isARM64() const;
    bool isARM32() const;
    bool isX86() const;
    bool isX64() const;

    bool writeARM64Branch(uintptr_t source, uintptr_t target);
    bool writeARM32Branch(uintptr_t source, uintptr_t target);
    bool writeX86Branch(uintptr_t source, uintptr_t target);
    bool writeX64Branch(uintptr_t source, uintptr_t target);

    std::vector<uint8_t> generateARM64Trampoline(uintptr_t target, uintptr_t trampoline, uintptr_t hook_func);
    std::vector<uint8_t> generateARM32Trampoline(uintptr_t target, uintptr_t trampoline, uintptr_t hook_func);
    std::vector<uint8_t> generateX86Trampoline(uintptr_t target, uintptr_t trampoline, uintptr_t hook_func);
    std::vector<uint8_t> generateX64Trampoline(uintptr_t target, uintptr_t trampoline, uintptr_t hook_func);
};

#endif
