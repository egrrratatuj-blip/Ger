#include "HookingFramework.h"
#include <dlfcn.h>
#include <cstring>
#include <cerrno>
#include <cstdio>
#include <cinttypes>

HookingFramework *HookingFramework::instance = nullptr;

HookingFramework::HookingFramework()
    : initialized(false)
    , statisticsEnabled(false)
    , loggingEnabled(false)
    , stealthMode(false)
    , antiDetection(false)
    , encryptionEnabled(false)
    , nextHookId(1)
{
}

HookingFramework::~HookingFramework()
{
    shutdown();
}

bool HookingFramework::initialize()
{
    if (initialized) return true;
    initializeTemplates();
    initialized = true;
    if (instance == nullptr) instance = this;
    return true;
}

void HookingFramework::shutdown()
{
    if (!initialized) return;
    uninstallAllHooks();
    cleanupTrampolines();
    if (logStream.is_open()) logStream.close();
    initialized = false;
    if (instance == this) instance = nullptr;
}

bool HookingFramework::isInitialized() const
{
    return initialized;
}

bool HookingFramework::isAvailable() const
{
    return initialized;
}

uint32_t HookingFramework::generateHookId()
{
    return nextHookId++;
}

bool HookingFramework::validateHookConfig(const HookConfig &config) const
{
    if (config.target_address == 0 && config.target_function.empty()) return false;
    if (config.hook_type < 0 || config.hook_type > 15) return false;
    return true;
}

uint32_t HookingFramework::installHook(const HookConfig &config)
{
    if (!initialized) return 0;
    if (!validateHookConfig(config)) return 0;
    std::lock_guard<std::mutex> lock(hookMutex);
    uint32_t id = generateHookId();
    HookInfo info;
    info.id = id;
    info.name = config.hook_name.empty() ? ("hook_" + std::to_string(id)) : config.hook_name;
    info.module_name = config.target_module;
    info.function_name = config.target_function;
    info.target_address = config.target_address;
    info.config = config;
    info.enabled = config.enabled;
    info.installed = false;
    info.call_count = 0;
    info.install_count = 0;
    info.error_count = 0;
    info.installed_at = std::chrono::system_clock::now();
    if (config.inline_hook || config.hook_type == static_cast<int>(HookType::Inline)) {
        info.is_inline = true;
        info.hook_type = static_cast<int>(HookType::Inline);
    } else if (config.got_hook || config.hook_type == static_cast<int>(HookType::GOT)) {
        info.is_got = true;
        info.hook_type = static_cast<int>(HookType::GOT);
    } else if (config.detour_hook || config.hook_type == static_cast<int>(HookType::Detour)) {
        info.is_detour = true;
        info.hook_type = static_cast<int>(HookType::Detour);
    } else if (config.vtable_hook || config.hook_type == static_cast<int>(HookType::VTable)) {
        info.is_vtable = true;
        info.hook_type = static_cast<int>(HookType::VTable);
    } else {
        info.is_inline = true;
        info.hook_type = static_cast<int>(HookType::Inline);
    }
    uintptr_t target = config.target_address;
    if (target == 0 && !config.target_module.empty() && !config.target_function.empty()) {
        target = resolveSymbol(config.target_module, config.target_function);
    } else if (target == 0 && !config.target_function.empty()) {
        target = resolveSymbol(config.target_function);
    }
    if (target == 0) {
        logHookOperation("installHook", id);
        hooks[id] = info;
        return id;
    }
    info.target_address = target;
    info.hook_size = getMinimumHookSize();
    bool installed = false;
    if (info.is_inline) {
        installed = (installInlineHook(target, config.callback_data, getMinimumHookSize()) != 0);
    } else if (info.is_got) {
        installed = (installGOTHook(config.target_module, config.target_function, config.callback_data) != 0);
    } else if (info.is_detour) {
        installed = (installDetourHook(target, config.callback_data, getMinimumHookSize()) != 0);
    }
    info.installed = installed;
    if (installed) {
        ++info.install_count;
        info.installed_at = std::chrono::system_clock::now();
    }
    hooks[id] = info;
    updateStatistics(info);
    fireEvent(HookEvent::AfterInstall, id);
    logHookOperation("installHook", id);
    return id;
}

bool HookingFramework::uninstallHook(uint32_t hook_id)
{
    std::lock_guard<std::mutex> lock(hookMutex);
    auto it = hooks.find(hook_id);
    if (it == hooks.end()) return false;
    HookInfo &info = it->second;
    if (info.installed) {
        fireEvent(HookEvent::BeforeUninstall, hook_id);
        size_t sz = info.original_size > 0 ? info.original_size : info.hook_size;
        writeMemoryProtected(info.target_address, info.config.original_bytes.data(), sz);
        info.installed = false;
        info.enabled = false;
        fireEvent(HookEvent::AfterUninstall, hook_id);
    }
    logHookOperation("uninstallHook", hook_id);
    hooks.erase(it);
    return true;
}

bool HookingFramework::uninstallAllHooks()
{
    std::lock_guard<std::mutex> lock(hookMutex);
    bool all_ok = true;
    for (auto &kv : hooks) {
        if (kv.second.installed) {
            size_t sz = kv.second.original_size > 0 ? kv.second.original_size : kv.second.hook_size;
            if (!writeMemoryProtected(kv.second.target_address, kv.second.config.original_bytes.data(), sz)) {
                all_ok = false;
            }
        }
    }
    hooks.clear();
    return all_ok;
}

bool HookingFramework::uninstallHooksByModule(const std::string &module_name)
{
    std::vector<uint32_t> to_remove;
    for (const auto &kv : hooks) {
        if (kv.second.module_name == module_name) to_remove.push_back(kv.first);
    }
    bool all_ok = true;
    for (auto id : to_remove) {
        if (!uninstallHook(id)) all_ok = false;
    }
    return all_ok;
}

bool HookingFramework::uninstallHooksByType(HookType type)
{
    std::vector<uint32_t> to_remove;
    int t = static_cast<int>(type);
    for (const auto &kv : hooks) {
        if (kv.second.hook_type == t) to_remove.push_back(kv.first);
    }
    bool all_ok = true;
    for (auto id : to_remove) {
        if (!uninstallHook(id)) all_ok = false;
    }
    return all_ok;
}

bool HookingFramework::uninstallHooksByPattern(const std::string &pattern)
{
    std::vector<uint32_t> to_remove;
    for (const auto &kv : hooks) {
        if (kv.second.name.find(pattern) != std::string::npos ||
            kv.second.function_name.find(pattern) != std::string::npos) {
            to_remove.push_back(kv.first);
        }
    }
    bool all_ok = true;
    for (auto id : to_remove) {
        if (!uninstallHook(id)) all_ok = false;
    }
    return all_ok;
}

bool HookingFramework::enableHook(uint32_t hook_id)
{
    std::lock_guard<std::mutex> lock(hookMutex);
    auto it = hooks.find(hook_id);
    if (it == hooks.end()) return false;
    it->second.enabled = true;
    return true;
}

bool HookingFramework::disableHook(uint32_t hook_id)
{
    std::lock_guard<std::mutex> lock(hookMutex);
    auto it = hooks.find(hook_id);
    if (it == hooks.end()) return false;
    it->second.enabled = false;
    return true;
}

bool HookingFramework::pauseHook(uint32_t hook_id)
{
    std::lock_guard<std::mutex> lock(hookMutex);
    auto it = hooks.find(hook_id);
    if (it == hooks.end()) return false;
    it->second.paused = true;
    return true;
}

bool HookingFramework::resumeHook(uint32_t hook_id)
{
    std::lock_guard<std::mutex> lock(hookMutex);
    auto it = hooks.find(hook_id);
    if (it == hooks.end()) return false;
    it->second.paused = false;
    return true;
}

bool HookingFramework::isHookInstalled(uint32_t hook_id) const
{
    std::lock_guard<std::mutex> lock(hookMutex);
    auto it = hooks.find(hook_id);
    return it != hooks.end() && it->second.installed;
}

bool HookingFramework::isHookEnabled(uint32_t hook_id) const
{
    std::lock_guard<std::mutex> lock(hookMutex);
    auto it = hooks.find(hook_id);
    return it != hooks.end() && it->second.enabled;
}

HookInfo HookingFramework::getHookInfo(uint32_t hook_id) const
{
    std::lock_guard<std::mutex> lock(hookMutex);
    static HookInfo empty;
    auto it = hooks.find(hook_id);
    return it != hooks.end() ? it->second : empty;
}

std::vector<HookInfo> HookingFramework::getActiveHooks() const
{
    std::lock_guard<std::mutex> lock(hookMutex);
    std::vector<HookInfo> active;
    for (const auto &kv : hooks) {
        if (kv.second.installed && kv.second.enabled) active.push_back(kv.second);
    }
    return active;
}

std::vector<HookInfo> HookingFramework::getAllHooks() const
{
    std::lock_guard<std::mutex> lock(hookMutex);
    std::vector<HookInfo> all;
    for (const auto &kv : hooks) all.push_back(kv.second);
    return all;
}

uint32_t HookingFramework::getHookCount() const
{
    return static_cast<uint32_t>(hooks.size());
}

uint32_t HookingFramework::getActiveHookCount() const
{
    uint32_t count = 0;
    for (const auto &kv : hooks) {
        if (kv.second.installed && kv.second.enabled) ++count;
    }
    return count;
}

void HookingFramework::setPreHookCallback(uint32_t hook_id, std::function<void(uintptr_t, void*, size_t)> callback)
{
    std::lock_guard<std::mutex> lock(hookMutex);
    auto it = hooks.find(hook_id);
    if (it != hooks.end()) it->second.config.pre_callback = callback;
}

void HookingFramework::setPostHookCallback(uint32_t hook_id, std::function<void(uintptr_t, void*, size_t)> callback)
{
    std::lock_guard<std::mutex> lock(hookMutex);
    auto it = hooks.find(hook_id);
    if (it != hooks.end()) it->second.config.post_callback = callback;
}

void HookingFramework::setReplaceCallback(uint32_t hook_id, std::function<void(uintptr_t, void*, size_t)> callback)
{
    std::lock_guard<std::mutex> lock(hookMutex);
    auto it = hooks.find(hook_id);
    if (it != hooks.end()) it->second.config.replace_callback = callback;
}

void HookingFramework::setGlobalPreHook(std::function<void(uint32_t, uintptr_t, void*, size_t)> callback)
{
    globalPreHook = callback;
}

void HookingFramework::setGlobalPostHook(std::function<void(uint32_t, uintptr_t, void*, size_t)> callback)
{
    globalPostHook = callback;
}

HookConfig HookingFramework::getHookConfig(uint32_t hook_id) const
{
    std::lock_guard<std::mutex> lock(hookMutex);
    auto it = hooks.find(hook_id);
    return it != hooks.end() ? it->second.config : HookConfig();
}

bool HookingFramework::updateHookConfig(uint32_t hook_id, const HookConfig &config)
{
    std::lock_guard<std::mutex> lock(hookMutex);
    auto it = hooks.find(hook_id);
    if (it == hooks.end()) return false;
    it->second.config = config;
    return true;
}

uintptr_t HookingFramework::getOriginalFunction(uint32_t hook_id) const
{
    std::lock_guard<std::mutex> lock(hookMutex);
    auto it = hooks.find(hook_id);
    return it != hooks.end() ? it->second.original_function : 0;
}

uintptr_t HookingFramework::getTrampolineAddress(uint32_t hook_id) const
{
    auto it = hooks.find(hook_id);
    return it != hooks.end() ? it->second.trampoline_address : 0;
}

void *HookingFramework::getHookFunction(uint32_t hook_id) const
{
    auto it = hooks.find(hook_id);
    return it != hooks.end() ? it->second.hook_function : nullptr;
}

bool HookingFramework::backupOriginal(uint32_t hook_id)
{
    std::lock_guard<std::mutex> lock(hookMutex);
    auto it = hooks.find(hook_id);
    if (it == hooks.end()) return false;
    HookInfo &info = it->second;
    size_t sz = info.hook_size > 0 ? info.hook_size : getMinimumHookSize();
    info.config.original_bytes.resize(sz);
    if (!readMemorySafe(info.target_address, info.config.original_bytes.data(), sz)) return false;
    info.original_size = sz;
    return true;
}

bool HookingFramework::restoreOriginal(uint32_t hook_id)
{
    std::lock_guard<std::mutex> lock(hookMutex);
    auto it = hooks.find(hook_id);
    if (it == hooks.end()) return false;
    HookInfo &info = it->second;
    if (info.config.original_bytes.empty()) return false;
    bool ok = writeMemoryProtected(info.target_address, info.config.original_bytes.data(), info.config.original_bytes.size());
    if (ok) info.installed = false;
    return ok;
}

bool HookingFramework::restoreAllOriginals()
{
    bool all_ok = true;
    for (auto &kv : hooks) {
        if (!restoreOriginal(kv.first)) all_ok = false;
    }
    return all_ok;
}

uint32_t HookingFramework::installInlineHook(uintptr_t target, void *hook, size_t size)
{
    if (!initialized || target == 0 || hook == nullptr) return 0;
    std::lock_guard<std::mutex> lock(hookMutex);
    uint32_t id = generateHookId();
    HookInfo info;
    info.id = id;
    info.target_address = target;
    info.hook_function = hook;
    info.hook_size = size > 0 ? size : getMinimumHookSize();
    info.is_inline = true;
    info.hook_type = static_cast<int>(HookType::Inline);
    info.installed_at = std::chrono::system_clock::now();
    std::vector<uint8_t> original(info.hook_size);
    if (!readMemorySafe(target, original.data(), info.hook_size)) return 0;
    info.config.original_bytes = original;
    info.original_size = info.hook_size;
    std::vector<uint8_t> hook_code(info.hook_size);
    if (isARM64()) {
        uint32_t *code = reinterpret_cast<uint32_t*>(hook_code.data());
        code[0] = 0x58000050;
        code[1] = 0xD61F0200;
        uint64_t addr = reinterpret_cast<uint64_t>(hook);
        memcpy(&code[2], &addr, sizeof(addr));
    } else if (isARM32()) {
        uint32_t *code = reinterpret_cast<uint32_t*>(hook_code.data());
        code[0] = 0xE51FF004;
        code[1] = reinterpret_cast<uint32_t>(hook);
    } else if (isX64()) {
        uint8_t *code = hook_code.data();
        code[0] = 0xFF; code[1] = 0x25; code[2] = 0x00; code[3] = 0x00; code[4] = 0x00; code[5] = 0x00;
        uint64_t addr = reinterpret_cast<uint64_t>(hook);
        memcpy(&code[6], &addr, sizeof(addr));
    } else {
        uint8_t *code = hook_code.data();
        code[0] = 0xE9;
        uint32_t offset = static_cast<uint32_t>(reinterpret_cast<uint64_t>(hook) - target - 5);
        memcpy(&code[1], &offset, sizeof(offset));
    }
    if (!writeMemoryProtected(target, hook_code.data(), info.hook_size)) return 0;
    flushCache(target, info.hook_size);
    info.installed = true;
    info.enabled = true;
    hooks[id] = info;
    updateStatistics(info);
    fireEvent(HookEvent::AfterInstall, id);
    return id;
}

uint32_t HookingFramework::installGOTHook(const std::string &module, const std::string &function, void *hook)
{
    if (!initialized || module.empty() || function.empty() || hook == nullptr) return 0;
    uintptr_t got_entry = findGOTEntry(module, function);
    if (got_entry == 0) return 0;
    std::lock_guard<std::mutex> lock(hookMutex);
    uint32_t id = generateHookId();
    HookInfo info;
    info.id = id;
    info.module_name = module;
    info.function_name = function;
    info.target_address = got_entry;
    info.hook_function = hook;
    info.hook_size = sizeof(void*);
    info.is_got = true;
    info.hook_type = static_cast<int>(HookType::GOT);
    info.installed_at = std::chrono::system_clock::now();
    uintptr_t original_func = 0;
    readMemorySafe(got_entry, &original_func, sizeof(original_func));
    info.original_function = original_func;
    info.config.original_bytes.resize(sizeof(uintptr_t));
    memcpy(info.config.original_bytes.data(), &original_func, sizeof(uintptr_t));
    if (!writeMemoryProtected(got_entry, &hook, sizeof(void*))) return 0;
    info.installed = true;
    info.enabled = true;
    hooks[id] = info;
    updateStatistics(info);
    fireEvent(HookEvent::AfterInstall, id);
    return id;
}

uint32_t HookingFramework::installDetourHook(uintptr_t target, void *hook, uint32_t length)
{
    if (!initialized || target == 0 || hook == nullptr) return 0;
    if (length < getMinimumHookSize()) length = getMinimumHookSize();
    std::lock_guard<std::mutex> lock(hookMutex);
    uint32_t id = generateHookId();
    HookInfo info;
    info.id = id;
    info.target_address = target;
    info.hook_function = hook;
    info.hook_size = length;
    info.is_detour = true;
    info.hook_type = static_cast<int>(HookType::Detour);
    info.installed_at = std::chrono::system_clock::now();
    std::vector<uint8_t> original(length);
    if (!readMemorySafe(target, original.data(), length)) return 0;
    info.config.original_bytes = original;
    info.original_size = length;
    uintptr_t trampoline = 0;
    if (!createTrampoline(target, trampoline, length)) return 0;
    info.trampoline_address = trampoline;
    info.detour_address = trampoline;
    std::vector<uint8_t> jmp_code;
    if (isARM64()) {
        jmp_code.resize(16);
        uint32_t *code = reinterpret_cast<uint32_t*>(jmp_code.data());
        code[0] = 0x58000050;
        code[1] = 0xD61F0200;
        uint64_t addr = reinterpret_cast<uint64_t>(hook);
        memcpy(&code[2], &addr, sizeof(addr));
    } else if (isX64()) {
        jmp_code.resize(14);
        jmp_code[0] = 0xFF; jmp_code[1] = 0x25; jmp_code[2] = 0x00; jmp_code[3] = 0x00; jmp_code[4] = 0x00; jmp_code[5] = 0x00;
        uint64_t addr = reinterpret_cast<uint64_t>(hook);
        memcpy(&jmp_code[6], &addr, sizeof(addr));
    } else {
        jmp_code.resize(5);
        jmp_code[0] = 0xE9;
        uint32_t offset = static_cast<uint32_t>(reinterpret_cast<uint64_t>(hook) - target - 5);
        memcpy(&jmp_code[1], &offset, sizeof(offset));
    }
    if (!writeMemoryProtected(target, jmp_code.data(), jmp_code.size())) return 0;
    flushCache(target, jmp_code.size());
    info.installed = true;
    info.enabled = true;
    hooks[id] = info;
    updateStatistics(info);
    fireEvent(HookEvent::AfterInstall, id);
    return id;
}

uint32_t HookingFramework::installVTableHook(void *instance, uint32_t index, void *hook)
{
    if (!initialized || instance == nullptr || hook == nullptr) return 0;
    void **vtable = *reinterpret_cast<void***>(instance);
    if (vtable == nullptr) return 0;
    uintptr_t vtable_entry = reinterpret_cast<uintptr_t>(&vtable[index]);
    std::lock_guard<std::mutex> lock(hookMutex);
    uint32_t id = generateHookId();
    HookInfo info;
    info.id = id;
    info.target_address = vtable_entry;
    info.hook_function = hook;
    info.hook_size = sizeof(void*);
    info.is_vtable = true;
    info.hook_type = static_cast<int>(HookType::VTable);
    info.installed_at = std::chrono::system_clock::now();
    info.config.original_bytes.resize(sizeof(void*));
    memcpy(info.config.original_bytes.data(), &vtable[index], sizeof(void*));
    info.original_function = reinterpret_cast<uintptr_t>(vtable[index]);
    if (!writeMemoryProtected(vtable_entry, &hook, sizeof(void*))) return 0;
    info.installed = true;
    info.enabled = true;
    hooks[id] = info;
    updateStatistics(info);
    fireEvent(HookEvent::AfterInstall, id);
    return id;
}

uint32_t HookingFramework::installSymbolHook(const std::string &module, const std::string &symbol, void *hook)
{
    if (!initialized || module.empty() || symbol.empty() || hook == nullptr) return 0;
    uintptr_t addr = resolveSymbol(module, symbol);
    if (addr == 0) return 0;
    return installInlineHook(addr, hook, getMinimumHookSize());
}

uint32_t HookingFramework::installPLTHook(const std::string &module, const std::string &function, void *hook)
{
    if (!initialized || module.empty() || function.empty() || hook == nullptr) return 0;
    uintptr_t plt_entry = findPLTEntry(module, function);
    if (plt_entry == 0) return 0;
    return installInlineHook(plt_entry, hook, getMinimumHookSize());
}

uint32_t HookingFramework::installBreakpointHook(uintptr_t address, void *hook)
{
    if (!initialized || address == 0) return 0;
    std::lock_guard<std::mutex> lock(hookMutex);
    uint8_t bkpt = isARM64() ? 0x00 : (isARM32() ? 0x70 : 0xCC);
    std::vector<uint8_t> original(1);
    readMemorySafe(address, original.data(), 1);
    if (!writeMemoryProtected(address, &bkpt, 1)) return 0;
    uint32_t id = generateHookId();
    HookInfo info;
    info.id = id;
    info.target_address = address;
    info.hook_function = hook;
    info.hook_size = 1;
    info.config.original_bytes = original;
    info.original_size = 1;
    info.is_inline = true;
    info.hook_type = static_cast<int>(HookType::Breakpoint);
    info.installed = true;
    info.enabled = true;
    hooks[id] = info;
    return id;
}

uint32_t HookingFramework::installInstructionHook(uintptr_t address, void *hook, size_t size)
{
    if (!initialized || address == 0 || hook == nullptr || size == 0) return 0;
    return installInlineHook(address, hook, size);
}

uint32_t HookingFramework::hookFunction(uintptr_t address, void *hook_function, void **original)
{
    if (address == 0 || hook_function == nullptr) return 0;
    uint32_t id = installInlineHook(address, hook_function, getMinimumHookSize());
    if (id && original) {
        auto it = hooks.find(id);
        if (it != hooks.end()) {
            it->second.original_function = address;
            *original = reinterpret_cast<void*>(address);
        }
    }
    return id;
}

uint32_t HookingFramework::hookFunction(const std::string &module, const std::string &function, void *hook, void **original)
{
    uintptr_t addr = resolveSymbol(module, function);
    if (addr == 0) return 0;
    return hookFunction(addr, hook, original);
}

uint32_t HookingFramework::hookMethod(void *instance, uint32_t method_index, void *hook, void **original)
{
    return installVTableHook(instance, method_index, hook);
}

uint32_t HookingFramework::hookLibrary(const std::string &library, const std::string &function, void *hook, void **original)
{
    return hookFunction(library, function, hook, original);
}

bool HookingFramework::replaceFunction(uint32_t hook_id, void *new_function)
{
    auto it = hooks.find(hook_id);
    if (it == hooks.end()) return false;
    it->second.hook_function = new_function;
    return true;
}

bool HookingFramework::replaceFunction(uintptr_t target, void *new_function)
{
    uint32_t id = installInlineHook(target, new_function, getMinimumHookSize());
    return id != 0;
}

bool HookingFramework::replaceFunction(const std::string &module, const std::string &function, void *new_function)
{
    uintptr_t addr = resolveSymbol(module, function);
    if (addr == 0) return false;
    return replaceFunction(addr, new_function);
}

bool HookingFramework::createTrampoline(uintptr_t target, uintptr_t &trampoline, size_t size)
{
    size_t trampoline_size = size + getMinimumHookSize() + 16;
    void *mem = mmap(nullptr, trampoline_size, PROT_READ | PROT_WRITE | PROT_EXEC,
                     MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (mem == MAP_FAILED) return false;
    trampoline = reinterpret_cast<uintptr_t>(mem);
    if (!readMemorySafe(target, mem, size)) {
        munmap(mem, trampoline_size);
        return false;
    }
    void *trampoline_addr = reinterpret_cast<void*>(trampoline);
    uintptr_t jmp_target = target + size;
    if (isARM64()) {
        uint32_t *code = reinterpret_cast<uint32_t*>(static_cast<uint8_t*>(mem) + size);
        code[0] = 0x58000050;
        code[1] = 0xD61F0200;
        uint64_t addr = static_cast<uint64_t>(jmp_target);
        memcpy(&code[2], &addr, sizeof(addr));
    } else if (isX64()) {
        uint8_t *code = static_cast<uint8_t*>(mem) + size;
        code[0] = 0xFF; code[1] = 0x25; code[2] = 0x00; code[3] = 0x00; code[4] = 0x00; code[5] = 0x00;
        uint64_t addr = static_cast<uint64_t>(jmp_target);
        memcpy(&code[6], &addr, sizeof(addr));
    } else {
        uint8_t *code = static_cast<uint8_t*>(mem) + size;
        code[0] = 0xE9;
        uint32_t offset = static_cast<uint32_t>(jmp_target - trampoline - size - 5);
        memcpy(&code[1], &offset, sizeof(offset));
    }
    TrampolineInfo tinfo;
    tinfo.address = trampoline;
    tinfo.size = static_cast<size_t>(trampoline_size);
    tinfo.in_use = true;
    tinfo.is_original = true;
    trampolines.push_back(tinfo);
    trampolineAddresses.insert(trampoline);
    return true;
}

bool HookingFramework::destroyTrampoline(uintptr_t trampoline)
{
    auto it = std::find_if(trampolines.begin(), trampolines.end(),
        [trampoline](const TrampolineInfo &t) { return t.address == trampoline; });
    if (it == trampolines.end()) return false;
    munmap(reinterpret_cast<void*>(it->address), it->size);
    trampolineAddresses.erase(trampoline);
    trampolines.erase(it);
    return true;
}

bool HookingFramework::createInlineTrampoline(uintptr_t target, uintptr_t &trampoline, size_t size)
{
    return createTrampoline(target, trampoline, size);
}

uintptr_t HookingFramework::getOrCreateTrampoline(uint32_t hook_id)
{
    auto it = hooks.find(hook_id);
    if (it == hooks.end()) return 0;
    if (it->second.trampoline_address != 0) return it->second.trampoline_address;
    uintptr_t trampoline = 0;
    if (createTrampoline(it->second.target_address, trampoline, it->second.hook_size)) {
        it->second.trampoline_address = trampoline;
    }
    return trampoline;
}

uintptr_t HookingFramework::findFreeTrampoline(size_t size)
{
    for (const auto &t : trampolines) {
        if (!t.in_use && t.size >= size) return t.address;
    }
    return 0;
}

bool HookingFramework::isAddressInTrampoline(uintptr_t addr)
{
    for (const auto &t : trampolines) {
        if (addr >= t.address && addr < t.address + t.size) return true;
    }
    return false;
}

bool HookingFramework::writeHookCode(uintptr_t address, const std::vector<uint8_t> &code)
{
    return writeMemoryProtected(address, code.data(), code.size());
}

bool HookingFramework::writeHookCode(uintptr_t address, const void *code, size_t size)
{
    return writeMemoryProtected(address, code, size);
}

bool HookingFramework::writeNOPs(uintptr_t address, size_t count)
{
    std::vector<uint8_t> nops(count, 0);
    if (isARM64()) {
        for (size_t i = 0; i < count; i += 4) {
            nops[i] = 0x1F; nops[i+1] = 0x20; nops[i+2] = 0x03; nops[i+3] = 0xD5;
        }
    } else if (isARM32()) {
        for (size_t i = 0; i < count; i += 4) {
            nops[i] = 0x00; nops[i+1] = 0x00; nops[i+2] = 0xA0; nops[i+3] = 0xE1;
        }
    } else {
        std::fill(nops.begin(), nops.end(), 0x90);
    }
    return writeMemoryProtected(address, nops.data(), count);
}

bool HookingFramework::writeBranch(uintptr_t source, uintptr_t target)
{
    if (isARM64()) return writeARM64Branch(source, target);
    if (isARM32()) return writeARM32Branch(source, target);
    if (isX64()) return writeX64Branch(source, target);
    return writeX86Branch(source, target);
}

bool HookingFramework::writeCall(uintptr_t source, uintptr_t target)
{
    if (isX64()) {
        uint8_t code[13];
        code[0] = 0xFF; code[1] = 0x15; code[2] = 0x00; code[3] = 0x00; code[4] = 0x00; code[5] = 0x00;
        uint64_t addr = static_cast<uint64_t>(target);
        memcpy(&code[6], &addr, sizeof(addr));
        return writeMemoryProtected(source, code, sizeof(code));
    }
    uint8_t code[5];
    code[0] = 0xE8;
    uint32_t offset = static_cast<uint32_t>(target - source - 5);
    memcpy(&code[1], &offset, sizeof(offset));
    return writeMemoryProtected(source, code, sizeof(code));
}

bool HookingFramework::writeJump(uintptr_t source, uintptr_t target)
{
    return writeBranch(source, target);
}

std::vector<uint8_t> HookingFramework::readCode(uintptr_t address, size_t size)
{
    std::vector<uint8_t> code(size);
    readMemorySafe(address, code.data(), size);
    return code;
}

std::vector<uint8_t> HookingFramework::generateTrampolineCode(uintptr_t target, uintptr_t trampoline_addr)
{
    if (isARM64()) return generateARM64Trampoline(target, trampoline_addr, 0);
    if (isARM32()) return generateARM32Trampoline(target, trampoline_addr, 0);
    if (isX64()) return generateX64Trampoline(target, trampoline_addr, 0);
    return generateX86Trampoline(target, trampoline_addr, 0);
}

std::vector<uint8_t> HookingFramework::generateHookCode(uintptr_t target, uintptr_t hook_func)
{
    if (isARM64()) return generateARM64Trampoline(target, 0, hook_func);
    if (isARM32()) return generateARM32Trampoline(target, 0, hook_func);
    if (isX64()) return generateX64Trampoline(target, 0, hook_func);
    return generateX86Trampoline(target, 0, hook_func);
}

std::vector<uint8_t> HookingFramework::generateNOPCode(size_t count)
{
    std::vector<uint8_t> nops(count, 0);
    if (isARM64()) {
        for (size_t i = 0; i < count; i += 4) {
            uint32_t nop = 0xD503201F;
            memcpy(&nops[i], &nop, sizeof(nop));
        }
    } else if (isARM32()) {
        for (size_t i = 0; i < count; i += 4) {
            uint32_t nop = 0xE1A00000;
            memcpy(&nops[i], &nop, sizeof(nop));
        }
    } else {
        std::fill(nops.begin(), nops.end(), 0x90);
    }
    return nops;
}

bool HookingFramework::protectMemory(uintptr_t address, size_t size, int protection)
{
    uintptr_t page_start = address & ~(static_cast<uintptr_t>(sysconf(_SC_PAGESIZE)) - 1);
    size_t region_size = ((address - page_start + size + sysconf(_SC_PAGESIZE) - 1) / sysconf(_SC_PAGESIZE)) * sysconf(_SC_PAGESIZE);
    return mprotect(reinterpret_cast<void*>(page_start), region_size, protection) == 0;
}

bool HookingFramework::makeMemoryExecutable(uintptr_t address, size_t size)
{
    return protectMemory(address, size, PROT_READ | PROT_EXEC);
}

bool HookingFramework::makeMemoryWritable(uintptr_t address, size_t size)
{
    return protectMemory(address, size, PROT_READ | PROT_WRITE);
}

bool HookingFramework::makeMemoryReadable(uintptr_t address, size_t size)
{
    return protectMemory(address, size, PROT_READ);
}

bool HookingFramework::makeMemoryReadWrite(uintptr_t address, size_t size)
{
    return protectMemory(address, size, PROT_READ | PROT_WRITE);
}

bool HookingFramework::makeMemoryReadExecute(uintptr_t address, size_t size)
{
    return protectMemory(address, size, PROT_READ | PROT_EXEC);
}

bool HookingFramework::makeMemoryReadWriteExecute(uintptr_t address, size_t size)
{
    return protectMemory(address, size, PROT_READ | PROT_WRITE | PROT_EXEC);
}

bool HookingFramework::flushCache(uintptr_t address, size_t size)
{
    __builtin___clear_cache(reinterpret_cast<char*>(address), reinterpret_cast<char*>(address + size));
    return true;
}

bool HookingFramework::flushInstructionCache()
{
    return true;
}

bool HookingFramework::flushDataCache(uintptr_t address, size_t size)
{
    __builtin___clear_cache(reinterpret_cast<char*>(address), reinterpret_cast<char*>(address + size));
    return true;
}

uintptr_t HookingFramework::resolveSymbol(const std::string &symbol)
{
    void *addr = dlsym(RTLD_DEFAULT, symbol.c_str());
    return reinterpret_cast<uintptr_t>(addr);
}

uintptr_t HookingFramework::resolveSymbol(const std::string &module, const std::string &symbol)
{
    void *handle = dlopen(module.c_str(), RTLD_LAZY | RTLD_NOLOAD);
    if (handle == nullptr) return 0;
    void *addr = dlsym(handle, symbol.c_str());
    dlclose(handle);
    return reinterpret_cast<uintptr_t>(addr);
}

uintptr_t HookingFramework::resolvePLTEntry(const std::string &module, const std::string &function)
{
    return findPLTEntry(module, function);
}

uintptr_t HookingFramework::resolveGOTEntry(const std::string &module, const std::string &function)
{
    return findGOTEntry(module, function);
}

void *HookingFramework::loadLibrary(const std::string &path)
{
    void *handle = dlopen(path.c_str(), RTLD_LAZY);
    return handle;
}

bool HookingFramework::unloadLibrary(void *handle)
{
    if (handle == nullptr) return false;
    return dlclose(handle) == 0;
}

bool HookingFramework::isLibraryLoaded(const std::string &name)
{
    void *handle = dlopen(name.c_str(), RTLD_LAZY | RTLD_NOLOAD);
    if (handle) { dlclose(handle); return true; }
    return false;
}

uintptr_t HookingFramework::getLibraryBase(const std::string &name)
{
    void *handle = dlopen(name.c_str(), RTLD_LAZY | RTLD_NOLOAD);
    if (handle == nullptr) return 0;
    link_map *lm = nullptr;
    dlinfo(handle, RTLD_DI_LINKMAP, &lm);
    dlclose(handle);
    return lm ? reinterpret_cast<uintptr_t>(lm->l_addr) : 0;
}

std::vector<std::pair<std::string, uintptr_t>> HookingFramework::getLoadedLibraries()
{
    std::vector<std::pair<std::string, uintptr_t>> libs;
    std::ifstream maps("/proc/self/maps");
    std::string line;
    std::set<std::string> seen;
    while (std::getline(maps, line)) {
        if (line.find(".so") == std::string::npos) continue;
        size_t p = line.rfind(' ');
        if (p == std::string::npos) continue;
        std::string path = line.substr(p + 1);
        if (path.empty() || seen.count(path)) continue;
        seen.insert(path);
        size_t dash = line.find('-');
        uintptr_t base = 0;
        if (dash != std::string::npos) {
            base = std::stoull(line.substr(0, dash), nullptr, 16);
        }
        libs.emplace_back(path, base);
    }
    return libs;
}

std::string HookingFramework::getLibraryPath(const std::string &name)
{
    void *handle = dlopen(name.c_str(), RTLD_LAZY | RTLD_NOLOAD);
    if (handle == nullptr) return "";
    link_map *lm = nullptr;
    dlinfo(handle, RTLD_DI_LINKMAP, &lm);
    dlclose(handle);
    return lm ? lm->l_name : "";
}

std::vector<std::string> HookingFramework::getLibraryDependencies(const std::string &name)
{
    std::vector<std::string> deps;
    void *handle = dlopen(name.c_str(), RTLD_LAZY | RTLD_NOLOAD);
    if (handle == nullptr) return deps;
    link_map *lm = nullptr;
    dlinfo(handle, RTLD_DI_LINKMAP, &lm);
    dlclose(handle);
    if (lm) {
        std::string line;
        std::ifstream maps("/proc/self/maps");
        std::set<std::string> seen;
        while (std::getline(maps, line)) {
            if (line.find(".so") == std::string::npos) continue;
            size_t p = line.rfind(' ');
            if (p == std::string::npos) continue;
            std::string path = line.substr(p + 1);
            if (!path.empty() && seen.insert(path).second) deps.push_back(path);
        }
    }
    return deps;
}

void *HookingFramework::getSymbolAddress(void *handle, const std::string &symbol)
{
    if (handle == nullptr) return nullptr;
    return dlsym(handle, symbol.c_str());
}

std::vector<std::string> HookingFramework::enumerateExportedFunctions(const std::string &module)
{
    std::vector<std::string> symbols;
    parseElfSymbols(module, symbols, true);
    return symbols;
}

std::vector<std::string> HookingFramework::enumerateImportedFunctions(const std::string &module)
{
    std::vector<std::string> symbols;
    parseElfSymbols(module, symbols, false);
    return symbols;
}

std::vector<std::string> HookingFramework::enumerateSymbols(const std::string &module)
{
    std::vector<std::string> symbols;
    parseElfSymbols(module, symbols, true);
    return symbols;
}

size_t HookingFramework::getHookSize(uint32_t hook_id) const
{
    auto it = hooks.find(hook_id);
    return it != hooks.end() ? it->second.hook_size : 0;
}

size_t HookingFramework::getRequiredHookSize(uintptr_t address) const
{
    return getMinimumHookSize();
}

size_t HookingFramework::getMinimumHookSize() const
{
    if (isARM64()) return 16;
    if (isARM32()) return 8;
    if (isX64()) return 14;
    return 5;
}

size_t HookingFramework::getPluginSize() const
{
    return 0;
}

HookStatistics HookingFramework::getStatistics() const
{
    return statistics;
}

void HookingFramework::resetStatistics()
{
    memset(&statistics, 0, sizeof(statistics));
}

void HookingFramework::enableStatistics(bool enable)
{
    statisticsEnabled = enable;
}

bool HookingFramework::isStatisticsEnabled() const
{
    return statisticsEnabled;
}

void HookingFramework::enableLogging(bool enable)
{
    loggingEnabled = enable;
    if (enable && !logPath.empty()) {
        logStream.open(logPath, std::ios::app);
    } else if (!enable && logStream.is_open()) {
        logStream.close();
    }
}

bool HookingFramework::isLoggingEnabled() const
{
    return loggingEnabled;
}

void HookingFramework::setLogFile(const std::string &path)
{
    logPath = path;
    if (loggingEnabled) {
        if (logStream.is_open()) logStream.close();
        logStream.open(path, std::ios::app);
    }
}

void HookingFramework::addExclusion(const std::string &module, const std::string &function)
{
    exclusions.emplace_back(module, function);
}

void HookingFramework::removeExclusion(const std::string &module, const std::string &function)
{
    exclusions.erase(std::remove_if(exclusions.begin(), exclusions.end(),
        [&](const std::pair<std::string, std::string> &e) {
            return e.first == module && e.second == function;
        }), exclusions.end());
}

bool HookingFramework::isExcluded(const std::string &module, const std::string &function) const
{
    return std::any_of(exclusions.begin(), exclusions.end(),
        [&](const std::pair<std::string, std::string> &e) {
            return e.first == module && e.second == function;
        });
}

void HookingFramework::clearExclusions()
{
    exclusions.clear();
}

void HookingFramework::enableStealthMode(bool enable)
{
    stealthMode = enable;
}

bool HookingFramework::isStealthModeEnabled() const
{
    return stealthMode;
}

void HookingFramework::enableAntiDetection(bool enable)
{
    antiDetection = enable;
}

bool HookingFramework::isAntiDetectionEnabled() const
{
    return antiDetection;
}

void HookingFramework::enableEncryption(bool enable)
{
    encryptionEnabled = enable;
}

bool HookingFramework::isEncryptionEnabled() const
{
    return encryptionEnabled;
}

void HookingFramework::registerEventListener(std::function<void(HookEvent, uint32_t)> listener)
{
    eventListener = listener;
}

void HookingFramework::unregisterEventListener()
{
    eventListener = nullptr;
}

std::string HookingFramework::getVersion() const
{
    return "1.0.0";
}

std::string HookingFramework::getArchitecture() const
{
#if defined(__aarch64__)
    return "ARM64";
#elif defined(__arm__)
    return "ARM32";
#elif defined(__x86_64__)
    return "x64";
#elif defined(__i386__)
    return "x86";
#else
    return "Unknown";
#endif
}

std::string HookingFramework::getHookTypeName(HookType type) const
{
    switch (type) {
        case HookType::Inline: return "Inline";
        case HookType::GOT: return "GOT";
        case HookType::Detour: return "Detour";
        case HookType::VTable: return "VTable";
        case HookType::Symbol: return "Symbol";
        case HookType::Trampoline: return "Trampoline";
        case HookType::PLT: return "PLT";
        case HookType::IAT: return "IAT";
        case HookType::EAT: return "EAT";
        case HookType::Import: return "Import";
        case HookType::Export: return "Export";
        case HookType::Breakpoint: return "Breakpoint";
        case HookType::Instruction: return "Instruction";
        case HookType::Function: return "Function";
        case HookType::Library: return "Library";
        case HookType::API: return "API";
        case HookType::Syscall: return "Syscall";
        case HookType::Kernel: return "Kernel";
        case HookType::Hybrid: return "Hybrid";
        case HookType::Dynamic: return "Dynamic";
        case HookType::Static: return "Static";
        case HookType::Proxy: return "Proxy";
        default: return "Unknown";
    }
}

bool HookingFramework::saveState(const std::string &path)
{
    std::ofstream out(path, std::ios::binary);
    if (!out.is_open()) return false;
    out.write("HKSF", 4);
    uint32_t count = static_cast<uint32_t>(hooks.size());
    out.write(reinterpret_cast<const char*>(&count), sizeof(count));
    for (const auto &kv : hooks) {
        const HookInfo &h = kv.second;
        out.write(reinterpret_cast<const char*>(&h.id), sizeof(h.id));
        uint32_t name_len = static_cast<uint32_t>(h.name.size());
        out.write(reinterpret_cast<const char*>(&name_len), sizeof(name_len));
        out.write(h.name.c_str(), name_len);
        out.write(reinterpret_cast<const char*>(&h.target_address), sizeof(h.target_address));
        out.write(reinterpret_cast<const char*>(&h.hook_size), sizeof(h.hook_size));
        out.write(reinterpret_cast<const char*>(&h.enabled), sizeof(h.enabled));
    }
    return out.good();
}

bool HookingFramework::loadState(const std::string &path)
{
    std::ifstream in(path, std::ios::binary);
    if (!in.is_open()) return false;
    char magic[4];
    in.read(magic, 4);
    if (memcmp(magic, "HKSF", 4) != 0) return false;
    uint32_t count = 0;
    in.read(reinterpret_cast<char*>(&count), sizeof(count));
    for (uint32_t i = 0; i < count; ++i) {
        HookInfo h;
        in.read(reinterpret_cast<char*>(&h.id), sizeof(h.id));
        uint32_t name_len = 0;
        in.read(reinterpret_cast<char*>(&name_len), sizeof(name_len));
        h.name.resize(name_len);
        in.read(&h.name[0], name_len);
        in.read(reinterpret_cast<char*>(&h.target_address), sizeof(h.target_address));
        in.read(reinterpret_cast<char*>(&h.hook_size), sizeof(h.hook_size));
        in.read(reinterpret_cast<char*>(&h.enabled), sizeof(h.enabled));
        hooks[h.id] = h;
    }
    return in.good();
}

bool HookingFramework::writeMemoryProtected(uintptr_t address, const void *data, size_t size)
{
    uintptr_t page_size = sysconf(_SC_PAGESIZE);
    uintptr_t page_start = address & ~(page_size - 1);
    size_t region_size = ((address - page_start + size + page_size - 1) / page_size) * page_size;
    int old_prot = PROT_READ | PROT_WRITE | PROT_EXEC;
    mprotect(reinterpret_cast<void*>(page_start), region_size, PROT_READ | PROT_WRITE);
    ssize_t written = pwrite64(open("/proc/self/mem", O_RDWR), data, size, address);
    mprotect(reinterpret_cast<void*>(page_start), region_size, old_prot);
    return written == static_cast<ssize_t>(size);
}

bool HookingFramework::readMemorySafe(uintptr_t address, void *buffer, size_t size)
{
    ssize_t n = pread64(open("/proc/self/mem", O_RDONLY), buffer, size, address);
    return n == static_cast<ssize_t>(size);
}

bool HookingFramework::isAddressValid(uintptr_t address) const
{
    return address > 0x10000 && address < 0x7FFFFFFFFFFFFFFFUL;
}

bool HookingFramework::isMemoryRegionExecutable(uintptr_t address) const
{
    uint8_t test = 0;
    return readMemorySafe(address, &test, 1);
}

void HookingFramework::initializeTemplates()
{
    if (isARM64()) {
        arm64TrampolineTemplate = {0x50, 0x00, 0x00, 0x58, 0x00, 0x02, 0x1F, 0xD6};
    } else if (isARM32()) {
        armTrampolineTemplate = {0x04, 0xF0, 0x1F, 0xE5};
    } else if (isX64()) {
        x64TrampolineTemplate = {0xFF, 0x25, 0x00, 0x00, 0x00, 0x00};
    } else {
        x86TrampolineTemplate = {0xE9};
    }
}

void HookingFramework::cleanupTrampolines()
{
    for (auto &t : trampolines) {
        munmap(reinterpret_cast<void*>(t.address), t.size);
    }
    trampolines.clear();
    trampolineAddresses.clear();
}

void HookingFramework::logHookOperation(const std::string &operation, uint32_t hook_id)
{
    if (!loggingEnabled) return;
    if (logStream.is_open()) {
        logStream << "[" << operation << "] hook_id=" << hook_id << "\n";
    }
}

void HookingFramework::updateStatistics(const HookInfo &info)
{
    if (!statisticsEnabled) return;
    ++statistics.total_hooks;
    if (info.installed) ++statistics.active_hooks;
    statistics.success_rate = statistics.total_hooks > 0
        ? static_cast<double>(statistics.active_hooks) / statistics.total_hooks * 100.0 : 0.0;
}

void HookingFramework::fireEvent(HookEvent event, uint32_t hook_id)
{
    if (eventListener) eventListener(event, hook_id);
}

bool HookingFramework::findNOPsInRange(uintptr_t start, size_t size, std::vector<uintptr_t> &nops)
{
    std::vector<uint8_t> data(size);
    if (!readMemorySafe(start, data.data(), size)) return false;
    size_t nop_size = isARM64() ? 4 : (isARM32() ? 4 : 1);
    uint32_t nop_pattern = 0;
    if (isARM64()) nop_pattern = 0xD503201F;
    else if (isARM32()) nop_pattern = 0xE1A00000;
    for (size_t i = 0; i + nop_size <= size; i += nop_size) {
        uint32_t val = 0;
        memcpy(&val, &data[i], nop_size);
        if (val == nop_pattern) nops.push_back(start + i);
    }
    return !nops.empty();
}

bool HookingFramework::isNOP(uintptr_t address)
{
    uint32_t val = 0;
    if (!readMemorySafe(address, &val, sizeof(val))) return false;
    if (isARM64()) return val == 0xD503201F;
    if (isARM32()) return val == 0xE1A00000;
    uint8_t byte = 0;
    readMemorySafe(address, &byte, 1);
    return byte == 0x90;
}

uintptr_t HookingFramework::findGOTEntry(const std::string &module, const std::string &function)
{
    void *handle = dlopen(module.c_str(), RTLD_LAZY | RTLD_NOLOAD);
    if (handle == nullptr) return 0;
    uintptr_t func = reinterpret_cast<uintptr_t>(dlsym(handle, function.c_str()));
    dlclose(handle);
    if (func == 0) return 0;
    return func;
}

uintptr_t HookingFramework::findPLTEntry(const std::string &module, const std::string &function)
{
    return findGOTEntry(module, function);
}

uintptr_t HookingFramework::findExportEntry(const std::string &module, const std::string &function)
{
    return resolveSymbol(module, function);
}

bool HookingFramework::parseElfSymbols(const std::string &module, std::vector<std::string> &symbols, bool is_export)
{
    return false;
}

Elf64_Addr HookingFramework::getElfSymbolAddress(const std::string &module, const std::string &symbol)
{
    return resolveSymbol(module, symbol);
}

Elf64_Addr HookingFramework::getElfFunctionAddress(const std::string &module, const std::string &function)
{
    return resolveSymbol(module, function);
}

bool HookingFramework::isARM64() const
{
#if defined(__aarch64__)
    return true;
#else
    return false;
#endif
}

bool HookingFramework::isARM32() const
{
#if defined(__arm__)
    return true;
#else
    return false;
#endif
}

bool HookingFramework::isX86() const
{
#if defined(__i386__)
    return true;
#else
    return false;
#endif
}

bool HookingFramework::isX64() const
{
#if defined(__x86_64__)
    return true;
#else
    return false;
#endif
}

bool HookingFramework::writeARM64Branch(uintptr_t source, uintptr_t target)
{
    uint32_t instr[4];
    instr[0] = 0x58000050;
    instr[1] = 0xD61F0200;
    uint64_t addr = static_cast<uint64_t>(target);
    memcpy(&instr[2], &addr, sizeof(addr));
    return writeMemoryProtected(source, instr, sizeof(instr));
}

bool HookingFramework::writeARM32Branch(uintptr_t source, uintptr_t target)
{
    uint32_t instr[2];
    instr[0] = 0xE51FF004;
    instr[1] = static_cast<uint32_t>(target);
    return writeMemoryProtected(source, instr, sizeof(instr));
}

bool HookingFramework::writeX86Branch(uintptr_t source, uintptr_t target)
{
    uint8_t code[5];
    code[0] = 0xE9;
    uint32_t offset = static_cast<uint32_t>(target - source - 5);
    memcpy(&code[1], &offset, sizeof(offset));
    return writeMemoryProtected(source, code, sizeof(code));
}

bool HookingFramework::writeX64Branch(uintptr_t source, uintptr_t target)
{
    uint8_t code[14];
    code[0] = 0xFF; code[1] = 0x25; code[2] = 0x00; code[3] = 0x00; code[4] = 0x00; code[5] = 0x00;
    uint64_t addr = static_cast<uint64_t>(target);
    memcpy(&code[6], &addr, sizeof(addr));
    return writeMemoryProtected(source, code, sizeof(code));
}

std::vector<uint8_t> HookingFramework::generateARM64Trampoline(uintptr_t target, uintptr_t trampoline, uintptr_t hook_func)
{
    std::vector<uint8_t> code(32, 0);
    uint32_t *instr = reinterpret_cast<uint32_t*>(code.data());
    uint64_t addr = (hook_func != 0) ? static_cast<uint64_t>(hook_func) : static_cast<uint64_t>(target + 16);
    instr[0] = 0x58000050;
    instr[1] = 0xD61F0200;
    memcpy(&instr[2], &addr, sizeof(addr));
    return code;
}

std::vector<uint8_t> HookingFramework::generateARM32Trampoline(uintptr_t target, uintptr_t trampoline, uintptr_t hook_func)
{
    std::vector<uint8_t> code(8, 0);
    uint32_t *instr = reinterpret_cast<uint32_t*>(code.data());
    uint32_t addr = (hook_func != 0) ? static_cast<uint32_t>(hook_func) : static_cast<uint32_t>(target + 8);
    instr[0] = 0xE51FF004;
    instr[1] = addr;
    return code;
}

std::vector<uint8_t> HookingFramework::generateX86Trampoline(uintptr_t target, uintptr_t trampoline, uintptr_t hook_func)
{
    std::vector<uint8_t> code(5, 0);
    code[0] = 0xE9;
    uint32_t addr = (hook_func != 0) ? static_cast<uint32_t>(hook_func) : static_cast<uint32_t>(target + 5);
    uint32_t offset = addr - target - 5;
    memcpy(&code[1], &offset, sizeof(offset));
    return code;
}

std::vector<uint8_t> HookingFramework::generateX64Trampoline(uintptr_t target, uintptr_t trampoline, uintptr_t hook_func)
{
    std::vector<uint8_t> code(14, 0);
    code[0] = 0xFF; code[1] = 0x25; code[2] = 0x00; code[3] = 0x00; code[4] = 0x00; code[5] = 0x00;
    uint64_t addr = (hook_func != 0) ? static_cast<uint64_t>(hook_func) : static_cast<uint64_t>(target + 14);
    memcpy(&code[6], &addr, sizeof(addr));
    return code;
}
