#ifndef BUGOR_ENCRYPTION_MANAGER_H
#define BUGOR_ENCRYPTION_MANAGER_H

#include <string>
#include <vector>
#include <map>
#include <memory>
#include <mutex>
#include <atomic>
#include <functional>
#include <cstdint>
#include <cstring>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <random>
#include <chrono>

#include <openssl/evp.h>
#include <openssl/aes.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <openssl/hmac.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/err.h>
#include <openssl/bio.h>
#include <openssl/bn.h>
#include <openssl/ossl_typ.h>
#include <openssl/kdf.h>
#include <openssl/objects.h>
#include <openssl/ec.h>
#include <openssl/ecdsa.h>
#include <openssl/ecdh.h>
#include <openssl/curve25519.h>
#include <openssl/conf.h>
#include <openssl/engine.h>
#include <openssl/crypto.h>

#include <zlib.h>

enum class CipherAlgorithm {
    AES_128_ECB,
    AES_128_CBC,
    AES_128_CFB,
    AES_128_OFB,
    AES_128_CTR,
    AES_128_GCM,
    AES_128_CCM,
    AES_192_ECB,
    AES_192_CBC,
    AES_192_CFB,
    AES_192_OFB,
    AES_192_CTR,
    AES_192_GCM,
    AES_192_CCM,
    AES_256_ECB,
    AES_256_CBC,
    AES_256_CFB,
    AES_256_OFB,
    AES_256_CTR,
    AES_256_GCM,
    AES_256_CCM,
    DES_ECB,
    DES_CBC,
    DES_CFB,
    DES_OFB,
    TripleDES_ECB,
    TripleDES_CBC,
    TripleDES_CFB,
    TripleDES_OFB,
    Blowfish_ECB,
    Blowfish_CBC,
    Blowfish_CFB,
    Blowfish_OFB,
    Twofish_ECB,
    Twofish_CBC,
    Twofish_CFB,
    Twofish_OFB,
    ChaCha20,
    ChaCha20_Poly1305,
    Salsa20,
    XSalsa20,
    RC4,
    Rabbit,
    HC128,
    HC256,
    Camellia_128,
    Camellia_192,
    Camellia_256,
    SM4_ECB,
    SM4_CBC,
    SM4_CFB,
    SM4_OFB,
    SM4_CTR,
    Custom
};

enum class HashAlgorithm {
    MD5,
    SHA1,
    SHA224,
    SHA256,
    SHA384,
    SHA512,
    SHA3_224,
    SHA3_256,
    SHA3_384,
    SHA3_512,
    BLAKE2b_256,
    BLAKE2b_512,
    BLAKE2s_256,
    RIPEMD160,
    WHIRLPOOL,
    SM3,
    Custom
};

enum class KeyExchangeAlgorithm {
    RSA,
    DH,
    ECDH,
    Curve25519,
    X25519,
    Ed25519,
    ECDHE,
    DHE,
    PSK,
    SRP,
    Custom
};

enum class SignatureAlgorithm {
    RSA_PKCS1,
    RSA_PSS,
    ECDSA,
    Ed25519,
    DSA,
    HMAC,
    CMAC,
    Poly1305,
    Custom
};

struct EncryptionKey {
    std::vector<uint8_t> key_data;
    std::vector<uint8_t> iv;
    std::vector<uint8_t> salt;
    std::vector<uint8_t> tag;
    std::vector<uint8_t> aad;
    uint32_t key_size;
    uint32_t iv_size;
    uint32_t tag_size;
    uint32_t iterations;
    CipherAlgorithm algorithm;
    std::string key_id;
    std::string key_type;
    std::string key_label;
    std::chrono::system_clock::time_point created_at;
    std::chrono::system_clock::time_point expires_at;
    bool permanent;
    bool exportable;
    bool revoked;
};

struct KeyPair {
    std::string public_key;
    std::string private_key;
    std::vector<uint8_t> public_key_bytes;
    std::vector<uint8_t> private_key_bytes;
    uint32_t key_size;
    KeyExchangeAlgorithm algorithm;
    std::string key_id;
    std::string key_label;
    std::chrono::system_clock::time_point created_at;
    bool permanent;
};

struct SecurityConfig {
    uint32_t key_size;
    uint32_t iv_size;
    uint32_t tag_size;
    uint32_t salt_size;
    uint32_t iterations;
    uint32_t rsa_key_size;
    uint32_t dsa_key_size;
    uint32_t ecdsa_curve;
    uint32_t dh_key_size;
    uint32_t pbkdf2_iterations;
    uint32_t scrypt_cost;
    uint32_t scrypt_block_size;
    uint32_t scrypt_parallel;
    uint32_t argon2_cost;
    uint32_t argon2_memory;
    uint32_t argon2_parallel;
    uint32_t key_rotation_days;
    uint32_t session_timeout_minutes;
    uint32_t max_keys;
    uint32_t min_key_size;
    uint32_t max_key_size;
    bool use_hardware_acceleration;
    bool use_secure_enclave;
    bool use_key_derivation;
    bool use_authenticated_encryption;
    bool use_compression_before_encrypt;
    bool verify_integrity;
    bool auto_key_rotation;
    bool store_keys_securely;
    bool enable_padding_oracle_protection;
    bool enable_timing_attack_protection;
    bool enable_side_channel_protection;
    bool fips_compliant;
    CipherAlgorithm default_cipher;
    HashAlgorithm default_hash;
    KeyExchangeAlgorithm default_key_exchange;
    SignatureAlgorithm default_signature;
};

class EncryptionManager {
public:
    EncryptionManager();
    ~EncryptionManager();

    bool initialize(const SecurityConfig &config);
    void shutdown();
    bool isInitialized() const;

    std::vector<uint8_t> encrypt(const std::vector<uint8_t> &data, const EncryptionKey &key);
    std::vector<uint8_t> decrypt(const std::vector<uint8_t> &data, const EncryptionKey &key);
    std::string encryptString(const std::string &data, const EncryptionKey &key);
    std::string decryptString(const std::string &data, const EncryptionKey &key);

    bool encryptFile(const std::string &input_path, const std::string &output_path, const EncryptionKey &key);
    bool decryptFile(const std::string &input_path, const std::string &output_path, const EncryptionKey &key);
    bool encryptStream(std::istream &input, std::ostream &output, const EncryptionKey &key);
    bool decryptStream(std::istream &input, std::ostream &output, const EncryptionKey &key);

    EncryptionKey generateKey(CipherAlgorithm algorithm = CipherAlgorithm::AES_256_GCM);
    EncryptionKey generateKey(int key_size);
    EncryptionKey generateKey(const std::string &password, const std::vector<uint8_t> &salt = {});
    EncryptionKey deriveKey(const std::string &password, const std::vector<uint8_t> &salt, uint32_t iterations = 100000);
    EncryptionKey deriveKey(const std::vector<uint8_t> &key_material, const std::vector<uint8_t> &salt, uint32_t iterations = 100000);
    EncryptionKey importKey(const std::vector<uint8_t> &key_data, CipherAlgorithm algorithm = CipherAlgorithm::AES_256_GCM);
    bool exportKey(const EncryptionKey &key, std::vector<uint8_t> &output);
    bool deleteKey(const std::string &key_id);
    bool hasKey(const std::string &key_id) const;
    EncryptionKey getKey(const std::string &key_id) const;
    std::vector<EncryptionKey> getKeys() const;
    bool rotateKeys();

    KeyPair generateKeyPair(KeyExchangeAlgorithm algorithm = KeyExchangeAlgorithm::RSA, uint32_t key_size = 2048);
    KeyPair generateRSAKeyPair(uint32_t key_size = 2048);
    KeyPair generateECDSAKeyPair(uint32_t curve = NID_X9_62_prime256v1);
    KeyPair generateDHKeyPair(uint32_t key_size = 2048);
    KeyPair generateX25519KeyPair();
    KeyPair generateEd25519KeyPair();
    KeyPair importKeyPair(const std::string &public_key, const std::string &private_key, KeyExchangeAlgorithm algorithm);
    bool exportKeyPair(const KeyPair &pair, std::string &public_out, std::string &private_out);
    bool deleteKeyPair(const std::string &key_id);
    KeyPair getKeyPair(const std::string &key_id) const;
    std::vector<KeyPair> getKeyPairs() const;

    std::vector<uint8_t> sign(const std::vector<uint8_t> &data, const KeyPair &key);
    bool verify(const std::vector<uint8_t> &data, const std::vector<uint8_t> &signature, const KeyPair &key);
    std::string signString(const std::string &data, const KeyPair &key);
    bool verifyString(const std::string &data, const std::string &signature, const KeyPair &key);
    bool signFile(const std::string &file_path, const std::string &signature_path, const KeyPair &key);
    bool verifyFile(const std::string &file_path, const std::string &signature_path, const KeyPair &key);

    std::vector<uint8_t> hash(const std::vector<uint8_t> &data, HashAlgorithm algorithm = HashAlgorithm::SHA256);
    std::string hashString(const std::string &data, HashAlgorithm algorithm = HashAlgorithm::SHA256);
    std::string hashFile(const std::string &file_path, HashAlgorithm algorithm = HashAlgorithm::SHA256);
    bool verifyHash(const std::vector<uint8_t> &data, const std::vector<uint8_t> &expected_hash, HashAlgorithm algorithm = HashAlgorithm::SHA256);
    bool verifyHashString(const std::string &data, const std::string &expected_hash, HashAlgorithm algorithm = HashAlgorithm::SHA256);

    std::vector<uint8_t> HMAC(const std::vector<uint8_t> &data, const std::vector<uint8_t> &key, HashAlgorithm algorithm = HashAlgorithm::SHA256);
    std::string HMACString(const std::string &data, const std::string &key, HashAlgorithm algorithm = HashAlgorithm::SHA256);
    bool verifyHMAC(const std::vector<uint8_t> &data, const std::vector<uint8_t> &hmac, const std::vector<uint8_t> &key, HashAlgorithm algorithm = HashAlgorithm::SHA256);

    std::vector<uint8_t> computeKDF(const std::string &password, const std::vector<uint8_t> &salt, uint32_t key_length, uint32_t iterations = 100000);
    std::vector<uint8_t> PBKDF2(const std::string &password, const std::vector<uint8_t> &salt, uint32_t iterations, uint32_t key_length, HashAlgorithm algorithm = HashAlgorithm::SHA256);
    std::vector<uint8_t> scrypt(const std::string &password, const std::vector<uint8_t> &salt, uint32_t cost, uint32_t block_size, uint32_t parallel, uint32_t key_length);
    std::vector<uint8_t> argon2(const std::string &password, const std::vector<uint8_t> &salt, uint32_t cost, uint32_t memory, uint32_t parallel, uint32_t key_length);
    std::vector<uint8_t> HKDF(const std::vector<uint8_t> &key_material, const std::vector<uint8_t> &salt, const std::vector<uint8_t> &info, uint32_t key_length, HashAlgorithm algorithm = HashAlgorithm::SHA256);

    std::vector<uint8_t> computeSharedSecret(const KeyPair &private_key, const KeyPair &public_key);
    std::vector<uint8_t> computeECDHSharedSecret(const KeyPair &private_key, const KeyPair &public_key);
    std::vector<uint8_t> computeDHSharedSecret(const KeyPair &private_key, const KeyPair &public_key);
    std::vector<uint8_t> computeX25519SharedSecret(const std::vector<uint8_t> &private_key, const std::vector<uint8_t> &public_key);

    std::vector<uint8_t> generateRandomBytes(size_t length);
    uint32_t generateRandomInt(uint32_t min, uint32_t max);
    uint64_t generateRandomLong(uint64_t min, uint64_t max);
    std::string generateRandomString(size_t length);
    std::string generateUUID();
    std::string generateSessionId();
    std::string generateToken(size_t length = 32);

    std::string encodeBase64(const std::vector<uint8_t> &data);
    std::vector<uint8_t> decodeBase64(const std::string &data);
    std::string encodeBase64URL(const std::vector<uint8_t> &data);
    std::vector<uint8_t> decodeBase64URL(const std::string &data);
    std::string encodeHex(const std::vector<uint8_t> &data);
    std::vector<uint8_t> decodeHex(const std::string &hex);

    std::vector<uint8_t> compress(const std::vector<uint8_t> &data, int level = Z_DEFAULT_COMPRESSION);
    std::vector<uint8_t> decompress(const std::vector<uint8_t> &data);
    std::string compressString(const std::string &data, int level = Z_DEFAULT_COMPRESSION);
    std::string decompressString(const std::string &data);

    bool hasHardwareSupport() const;
    std::string getVersion() const;
    std::string getProviderName() const;
    bool isFIPSEnabled() const;
    bool isHardwareAccelerated() const;

    SecurityConfig getConfig() const;
    bool setConfig(const SecurityConfig &config);
    void setDefaultCipher(CipherAlgorithm algorithm);
    void setDefaultHash(HashAlgorithm algorithm);

    void setKeyDerivationIterations(uint32_t iterations);
    void setKeyRotationDays(uint32_t days);
    void enableAutoKeyRotation(bool enable);
    bool isAutoKeyRotationEnabled() const;

    bool saveKeyStore(const std::string &path);
    bool loadKeyStore(const std::string &path);
    bool clearKeyStore();

    void onSecurityEvent(std::function<void(const std::string&, const std::string&)> callback);

    static std::string getCipherName(CipherAlgorithm algorithm);
    static std::string getHashName(HashAlgorithm algorithm);
    static std::string getAlgorithmString(CipherAlgorithm algorithm);
    static int getOpenSSLCipher(CipherAlgorithm algorithm);
    static int getOpenSSLHash(HashAlgorithm algorithm);
    static size_t getKeySize(CipherAlgorithm algorithm);
    static size_t getIVSize(CipherAlgorithm algorithm);
    static size_t getTagSize(CipherAlgorithm algorithm);
    static bool isAuthenticated(CipherAlgorithm algorithm);
    static bool isAEAD(CipherAlgorithm algorithm);

private:
    bool initialized;
    bool hardwareAcceleration;
    bool autoKeyRotation;
    EVP_PKEY *pkey;

    SecurityConfig config;
    std::mutex cryptoMutex;
    std::mutex keyMutex;
    std::mutex pairMutex;

    std::map<std::string, EncryptionKey> keys;
    std::map<std::string, KeyPair> keyPairs;
    std::function<void(const std::string&, const std::string&)> securityCallback;

    bool encryptAES(const std::vector<uint8_t> &plaintext, std::vector<uint8_t> &ciphertext, const EncryptionKey &key);
    bool decryptAES(const std::vector<uint8_t> &ciphertext, std::vector<uint8_t> &plaintext, const EncryptionKey &key);
    bool encryptChaCha20(const std::vector<uint8_t> &plaintext, std::vector<uint8_t> &ciphertext, const EncryptionKey &key);
    bool decryptChaCha20(const std::vector<uint8_t> &ciphertext, std::vector<uint8_t> &plaintext, const EncryptionKey &key);

    bool encryptWithEVP(const std::vector<uint8_t> &plaintext, std::vector<uint8_t> &ciphertext, const EncryptionKey &key);
    bool decryptWithEVP(const std::vector<uint8_t> &ciphertext, std::vector<uint8_t> &plaintext, const EncryptionKey &key);

    std::vector<uint8_t> padPKCS7(const std::vector<uint8_t> &data, size_t block_size);
    std::vector<uint8_t> unpadPKCS7(const std::vector<uint8_t> &data);

    void generateSalt(std::vector<uint8_t> &salt, size_t size);
    void generateIV(std::vector<uint8_t> &iv, size_t size);
    void generateTag(std::vector<uint8_t> &tag, size_t size);

    bool validateKey(const EncryptionKey &key) const;
    bool validateKeyPair(const KeyPair &pair) const;
    bool isKeyExpired(const EncryptionKey &key) const;

    void initOpenSSL();
    void cleanupOpenSSL();
    bool checkForHardwareSupport();

    bool saveKeysToFile(const std::string &path);
    bool loadKeysFromFile(const std::string &path);

    void logSecurityEvent(const std::string &event, const std::string &details);
};

#endif
