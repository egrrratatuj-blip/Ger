#include "EncryptionManager.h"
#include <cstring>
#include <vector>
#include <cstdio>
#include <cerrno>
#include <cinttypes>

EncryptionManager::EncryptionManager()
    : initialized(false)
    , hardwareAcceleration(false)
    , autoKeyRotation(false)
    , pkey(nullptr)
{
}

EncryptionManager::~EncryptionManager()
{
    shutdown();
}

bool EncryptionManager::initialize(const SecurityConfig &config)
{
    if (initialized) return true;
    this->config = config;
    initOpenSSL();
    hardwareAcceleration = checkForHardwareSupport();
    initialized = true;
    return true;
}

void EncryptionManager::shutdown()
{
    if (!initialized) return;
    keys.clear();
    keyPairs.clear();
    cleanupOpenSSL();
    initialized = false;
}

bool EncryptionManager::isInitialized() const
{
    return initialized;
}

std::vector<uint8_t> EncryptionManager::encrypt(const std::vector<uint8_t> &data, const EncryptionKey &key)
{
    std::vector<uint8_t> result;
    if (!encryptWithEVP(data, result, key)) return {};
    return result;
}

std::vector<uint8_t> EncryptionManager::decrypt(const std::vector<uint8_t> &data, const EncryptionKey &key)
{
    std::vector<uint8_t> result;
    if (!decryptWithEVP(data, result, key)) return {};
    return result;
}

std::string EncryptionManager::encryptString(const std::string &data, const EncryptionKey &key)
{
    std::vector<uint8_t> input(data.begin(), data.end());
    auto encrypted = encrypt(input, key);
    return encodeBase64(encrypted);
}

std::string EncryptionManager::decryptString(const std::string &data, const EncryptionKey &key)
{
    auto decoded = decodeBase64(data);
    auto decrypted = decrypt(decoded, key);
    return std::string(decrypted.begin(), decrypted.end());
}

bool EncryptionManager::encryptFile(const std::string &input_path, const std::string &output_path, const EncryptionKey &key)
{
    std::ifstream in(input_path, std::ios::binary);
    if (!in.is_open()) return false;
    std::ofstream out(output_path, std::ios::binary);
    if (!out.is_open()) return false;
    return encryptStream(in, out, key);
}

bool EncryptionManager::decryptFile(const std::string &input_path, const std::string &output_path, const EncryptionKey &key)
{
    std::ifstream in(input_path, std::ios::binary);
    if (!in.is_open()) return false;
    std::ofstream out(output_path, std::ios::binary);
    if (!out.is_open()) return false;
    return decryptStream(in, out, key);
}

bool EncryptionManager::encryptStream(std::istream &input, std::ostream &output, const EncryptionKey &key)
{
    std::vector<uint8_t> buffer((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
    auto encrypted = encrypt(buffer, key);
    if (encrypted.empty()) return false;
    output.write(reinterpret_cast<const char*>(encrypted.data()), encrypted.size());
    return output.good();
}

bool EncryptionManager::decryptStream(std::istream &input, std::ostream &output, const EncryptionKey &key)
{
    std::vector<uint8_t> buffer((std::istreambuf_iterator<char>(input)), std::istreambuf_iterator<char>());
    auto decrypted = decrypt(buffer, key);
    if (decrypted.empty()) return false;
    output.write(reinterpret_cast<const char*>(decrypted.data()), decrypted.size());
    return output.good();
}

EncryptionKey EncryptionManager::generateKey(CipherAlgorithm algorithm)
{
    EncryptionKey key;
    key.algorithm = algorithm;
    key.key_size = static_cast<uint32_t>(getKeySize(algorithm));
    key.iv_size = static_cast<uint32_t>(getIVSize(algorithm));
    key.tag_size = static_cast<uint32_t>(getTagSize(algorithm));
    key.key_data.resize(key.key_size > 0 ? key.key_size : 32);
    key.iv.resize(key.iv_size);
    RAND_bytes(key.key_data.data(), static_cast<int>(key.key_data.size()));
    RAND_bytes(key.iv.data(), static_cast<int>(key.iv.size()));
    if (key.tag_size > 0) key.tag.resize(key.tag_size);
    generateSalt(key.salt, 16);
    key.iterations = config.iterations > 0 ? config.iterations : 100000;
    key.created_at = std::chrono::system_clock::now();
    key.permanent = false;
    key.exportable = true;
    key.revoked = false;
    key.key_id = "key_" + encodeHex(key.key_data);
    return key;
}

EncryptionKey EncryptionManager::generateKey(int key_size)
{
    CipherAlgorithm algo = CipherAlgorithm::AES_256_GCM;
    if (key_size <= 128) algo = CipherAlgorithm::AES_128_GCM;
    else if (key_size <= 192) algo = CipherAlgorithm::AES_192_GCM;
    return generateKey(algo);
}

EncryptionKey EncryptionManager::generateKey(const std::string &password, const std::vector<uint8_t> &salt)
{
    std::vector<uint8_t> s = salt.empty() ? std::vector<uint8_t>(16) : salt;
    if (salt.empty()) RAND_bytes(s.data(), static_cast<int>(s.size()));
    return deriveKey(password, s, config.iterations);
}

EncryptionKey EncryptionManager::deriveKey(const std::string &password, const std::vector<uint8_t> &salt, uint32_t iterations)
{
    EncryptionKey key;
    key.algorithm = config.default_cipher;
    key.key_size = static_cast<uint32_t>(getKeySize(config.default_cipher));
    key.iv_size = static_cast<uint32_t>(getIVSize(config.default_cipher));
    key.tag_size = static_cast<uint32_t>(getTagSize(config.default_cipher));
    key.salt = salt;
    key.iterations = iterations;
    key.key_data.resize(key.key_size > 0 ? key.key_size : 32);
    key.iv.resize(key.iv_size);
    PKCS5_PBKDF2_HMAC_SHA1(password.c_str(), static_cast<int>(password.size()),
        salt.data(), static_cast<int>(salt.size()), static_cast<int>(iterations),
        static_cast<int>(key.key_data.size()), key.key_data.data());
    RAND_bytes(key.iv.data(), static_cast<int>(key.iv.size()));
    key.created_at = std::chrono::system_clock::now();
    key.key_id = "derived_" + encodeHex(key.key_data);
    return key;
}

static std::string toHex(const std::vector<uint8_t>& v) {
    static const char* hex = "0123456789abcdef";
    std::string s;
    s.reserve(v.size() * 2);
    for (uint8_t b : v) { s.push_back(hex[b >> 4]); s.push_back(hex[b & 0xF]); }
    return s;
}

EncryptionKey EncryptionManager::deriveKey(const std::vector<uint8_t> &key_material, const std::vector<uint8_t> &salt, uint32_t iterations)
{
    return deriveKey(toHex(key_material), salt, iterations);
}

std::vector<uint8_t> EncryptionManager::computeKDF(const std::string &password, const std::vector<uint8_t> &salt, uint32_t key_length, uint32_t iterations)
{
    std::vector<uint8_t> result(key_length);
    PKCS5_PBKDF2_HMAC_SHA1(password.c_str(), static_cast<int>(password.size()),
        salt.data(), static_cast<int>(salt.size()), static_cast<int>(iterations),
        static_cast<int>(result.size()), result.data());
    return result;
}

std::vector<uint8_t> EncryptionManager::PBKDF2(const std::string &password, const std::vector<uint8_t> &salt, uint32_t iterations, uint32_t key_length, HashAlgorithm algorithm)
{
    std::vector<uint8_t> result(key_length);
    const EVP_MD *md = EVP_sha256();
    switch (algorithm) {
        case HashAlgorithm::SHA1: md = EVP_sha1(); break;
        case HashAlgorithm::SHA256: md = EVP_sha256(); break;
        case HashAlgorithm::SHA512: md = EVP_sha512(); break;
        default: md = EVP_sha256(); break;
    }
    PKCS5_PBKDF2_HMAC(password.c_str(), static_cast<int>(password.size()),
        salt.data(), static_cast<int>(salt.size()), static_cast<int>(iterations),
        md, static_cast<int>(result.size()), result.data());
    return result;
}

std::vector<uint8_t> EncryptionManager::scrypt(const std::string &password, const std::vector<uint8_t> &salt, uint32_t cost, uint32_t block_size, uint32_t parallel, uint32_t key_length)
{
    std::vector<uint8_t> result(key_length);
    EVP_PBE_scrypt(password.c_str(), password.size(), salt.data(), salt.size(),
        static_cast<uint64_t>(cost), static_cast<uint64_t>(block_size), static_cast<uint64_t>(parallel),
        0, result.data(), result.size());
    return result;
}

std::vector<uint8_t> EncryptionManager::argon2(const std::string &password, const std::vector<uint8_t> &salt, uint32_t cost, uint32_t memory, uint32_t parallel, uint32_t key_length)
{
    return PBKDF2(password, salt, cost > 0 ? cost : 100000, key_length, HashAlgorithm::SHA512);
}

std::vector<uint8_t> EncryptionManager::HKDF(const std::vector<uint8_t> &key_material, const std::vector<uint8_t> &salt, const std::vector<uint8_t> &info, uint32_t key_length, HashAlgorithm algorithm)
{
    std::vector<uint8_t> result(key_length);
    const EVP_MD *md = EVP_sha256();
    switch (algorithm) {
        case HashAlgorithm::SHA256: md = EVP_sha256(); break;
        case HashAlgorithm::SHA384: md = EVP_sha384(); break;
        case HashAlgorithm::SHA512: md = EVP_sha512(); break;
        default: md = EVP_sha256(); break;
    }
    if (HKDF_expand(md, key_material.data(), key_material.size(), info.data(), static_cast<int>(info.size()),
        result.data(), static_cast<int>(result.size())) <= 0) {
        result.clear();
    }
    return result;
}

EncryptionKey EncryptionManager::importKey(const std::vector<uint8_t> &key_data, CipherAlgorithm algorithm)
{
    EncryptionKey key;
    key.key_data = key_data;
    key.algorithm = algorithm;
    key.key_size = static_cast<uint32_t>(key_data.size());
    key.iv_size = static_cast<uint32_t>(getIVSize(algorithm));
    key.created_at = std::chrono::system_clock::now();
    key.key_id = "imported_" + encodeHex(key_data);
    std::lock_guard<std::mutex> lock(keyMutex);
    keys[key.key_id] = key;
    return key;
}

bool EncryptionManager::exportKey(const EncryptionKey &key, std::vector<uint8_t> &output)
{
    if (!key.exportable) return false;
    output = key.key_data;
    return true;
}

bool EncryptionManager::deleteKey(const std::string &key_id)
{
    std::lock_guard<std::mutex> lock(keyMutex);
    return keys.erase(key_id) > 0;
}

bool EncryptionManager::hasKey(const std::string &key_id) const
{
    return keys.find(key_id) != keys.end();
}

EncryptionKey EncryptionManager::getKey(const std::string &key_id) const
{
    auto it = keys.find(key_id);
    return it != keys.end() ? it->second : EncryptionKey();
}

std::vector<EncryptionKey> EncryptionManager::getKeys() const
{
    std::vector<EncryptionKey> result;
    for (const auto &kv : keys) result.push_back(kv.second);
    return result;
}

bool EncryptionManager::rotateKeys()
{
    std::lock_guard<std::mutex> lock(keyMutex);
    for (auto &kv : keys) {
        kv.second.revoked = true;
    }
    return true;
}

KeyPair EncryptionManager::generateKeyPair(KeyExchangeAlgorithm algorithm, uint32_t key_size)
{
    switch (algorithm) {
        case KeyExchangeAlgorithm::RSA: return generateRSAKeyPair(key_size);
        case KeyExchangeAlgorithm::ECDSA:
        case KeyExchangeAlgorithm::ECDH: return generateECDSAKeyPair();
        case KeyExchangeAlgorithm::X25519: return generateX25519KeyPair();
        case KeyExchangeAlgorithm::Ed25519: return generateEd25519KeyPair();
        default: return generateRSAKeyPair(key_size);
    }
}

KeyPair EncryptionManager::generateRSAKeyPair(uint32_t key_size)
{
    KeyPair pair;
    pair.algorithm = KeyExchangeAlgorithm::RSA;
    pair.key_size = key_size;
    EVP_PKEY *pkey = EVP_PKEY_new();
    EVP_PKEY_CTX *ctx = EVP_PKEY_CTX_new_id(EVP_PKEY_RSA, nullptr);
    EVP_PKEY_keygen_init(ctx);
    EVP_PKEY_CTX_set_rsa_keygen_bits(ctx, static_cast<int>(key_size));
    EVP_PKEY_keygen(ctx, &pkey);
    EVP_PKEY_CTX_free(ctx);
    if (pkey) {
        BIO *bio = BIO_new(BIO_s_mem());
        PEM_write_bio_PUBKEY(bio, pkey);
        char *data = nullptr;
        long len = BIO_get_mem_data(bio, &data);
        pair.public_key.assign(data, len);
        BIO_free(bio);
        bio = BIO_new(BIO_s_mem());
        PEM_write_bio_PrivateKey(bio, pkey, nullptr, nullptr, 0, nullptr, nullptr);
        len = BIO_get_mem_data(bio, &data);
        pair.private_key.assign(data, len);
        BIO_free(bio);
        EVP_PKEY_free(pkey);
    }
    pair.created_at = std::chrono::system_clock::now();
    pair.key_id = "rsa_" + std::to_string(key_size) + "_" + std::to_string(
        static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(
            pair.created_at.time_since_epoch()).count()));
    return pair;
}

KeyPair EncryptionManager::generateECDSAKeyPair(uint32_t curve)
{
    KeyPair pair;
    pair.algorithm = KeyExchangeAlgorithm::ECDSA;
    pair.key_size = 256;
    EVP_PKEY *pkey = EVP_PKEY_new();
    EVP_PKEY_CTX *ctx = EVP_PKEY_CTX_new_id(EVP_PKEY_EC, nullptr);
    EVP_PKEY_keygen_init(ctx);
    EVP_PKEY_CTX_set_ec_paramgen_curve_nid(ctx, static_cast<int>(curve));
    EVP_PKEY_keygen(ctx, &pkey);
    EVP_PKEY_CTX_free(ctx);
    if (pkey) {
        BIO *bio = BIO_new(BIO_s_mem());
        PEM_write_bio_PUBKEY(bio, pkey);
        char *data = nullptr;
        long len = BIO_get_mem_data(bio, &data);
        pair.public_key.assign(data, len);
        BIO_free(bio);
        bio = BIO_new(BIO_s_mem());
        PEM_write_bio_PrivateKey(bio, pkey, nullptr, nullptr, 0, nullptr, nullptr);
        len = BIO_get_mem_data(bio, &data);
        pair.private_key.assign(data, len);
        BIO_free(bio);
        EVP_PKEY_free(pkey);
    }
    pair.created_at = std::chrono::system_clock::now();
    pair.key_id = "ecdsa_" + std::to_string(
        static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(
            pair.created_at.time_since_epoch()).count()));
    return pair;
}

KeyPair EncryptionManager::generateDHKeyPair(uint32_t key_size)
{
    return generateRSAKeyPair(key_size);
}

KeyPair EncryptionManager::generateX25519KeyPair()
{
    KeyPair pair;
    pair.algorithm = KeyExchangeAlgorithm::X25519;
    pair.key_size = 256;
    EVP_PKEY *pkey = EVP_PKEY_new();
    EVP_PKEY_CTX *ctx = EVP_PKEY_CTX_new_id(EVP_PKEY_X25519, nullptr);
    EVP_PKEY_keygen_init(ctx);
    EVP_PKEY_keygen(ctx, &pkey);
    EVP_PKEY_CTX_free(ctx);
    if (pkey) {
        BIO *bio = BIO_new(BIO_s_mem());
        PEM_write_bio_PUBKEY(bio, pkey);
        char *data = nullptr;
        long len = BIO_get_mem_data(bio, &data);
        pair.public_key.assign(data, len);
        BIO_free(bio);
        bio = BIO_new(BIO_s_mem());
        PEM_write_bio_PrivateKey(bio, pkey, nullptr, nullptr, 0, nullptr, nullptr);
        len = BIO_get_mem_data(bio, &data);
        pair.private_key.assign(data, len);
        BIO_free(bio);
        EVP_PKEY_free(pkey);
    }
    pair.created_at = std::chrono::system_clock::now();
    pair.key_id = "x25519_" + std::to_string(
        static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(
            pair.created_at.time_since_epoch()).count()));
    return pair;
}

KeyPair EncryptionManager::generateEd25519KeyPair()
{
    KeyPair pair;
    pair.algorithm = KeyExchangeAlgorithm::Ed25519;
    pair.key_size = 256;
    EVP_PKEY *pkey = EVP_PKEY_new();
    EVP_PKEY_CTX *ctx = EVP_PKEY_CTX_new_id(EVP_PKEY_ED25519, nullptr);
    EVP_PKEY_keygen_init(ctx);
    EVP_PKEY_keygen(ctx, &pkey);
    EVP_PKEY_CTX_free(ctx);
    if (pkey) {
        BIO *bio = BIO_new(BIO_s_mem());
        PEM_write_bio_PUBKEY(bio, pkey);
        char *data = nullptr;
        long len = BIO_get_mem_data(bio, &data);
        pair.public_key.assign(data, len);
        BIO_free(bio);
        bio = BIO_new(BIO_s_mem());
        PEM_write_bio_PrivateKey(bio, pkey, nullptr, nullptr, 0, nullptr, nullptr);
        len = BIO_get_mem_data(bio, &data);
        pair.private_key.assign(data, len);
        BIO_free(bio);
        EVP_PKEY_free(pkey);
    }
    pair.created_at = std::chrono::system_clock::now();
    pair.key_id = "ed25519_" + std::to_string(
        static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(
            pair.created_at.time_since_epoch()).count()));
    return pair;
}

KeyPair EncryptionManager::importKeyPair(const std::string &public_key, const std::string &private_key, KeyExchangeAlgorithm algorithm)
{
    KeyPair pair;
    pair.public_key = public_key;
    pair.private_key = private_key;
    pair.algorithm = algorithm;
    pair.created_at = std::chrono::system_clock::now();
    pair.key_id = "imported_" + std::to_string(
        static_cast<uint64_t>(std::chrono::duration_cast<std::chrono::milliseconds>(
            pair.created_at.time_since_epoch()).count()));
    return pair;
}

bool EncryptionManager::exportKeyPair(const KeyPair &pair, std::string &public_out, std::string &private_out)
{
    public_out = pair.public_key;
    private_out = pair.private_key;
    return true;
}

bool EncryptionManager::deleteKeyPair(const std::string &key_id)
{
    std::lock_guard<std::mutex> lock(pairMutex);
    return keyPairs.erase(key_id) > 0;
}

KeyPair EncryptionManager::getKeyPair(const std::string &key_id) const
{
    auto it = keyPairs.find(key_id);
    return it != keyPairs.end() ? it->second : KeyPair();
}

std::vector<KeyPair> EncryptionManager::getKeyPairs() const
{
    std::vector<KeyPair> result;
    for (const auto &kv : keyPairs) result.push_back(kv.second);
    return result;
}

std::vector<uint8_t> EncryptionManager::sign(const std::vector<uint8_t> &data, const KeyPair &key)
{
    std::vector<uint8_t> signature;
    BIO *bio = BIO_new_mem_buf(key.private_key.data(), static_cast<int>(key.private_key.size()));
    EVP_PKEY *pkey = PEM_read_bio_PrivateKey(bio, nullptr, nullptr, nullptr);
    BIO_free(bio);
    if (!pkey) return signature;
    EVP_MD_CTX *ctx = EVP_MD_CTX_new();
    EVP_DigestSignInit(ctx, nullptr, EVP_sha256(), nullptr, pkey);
    EVP_DigestSignUpdate(ctx, data.data(), data.size());
    size_t sig_len = 0;
    EVP_DigestSignFinal(ctx, nullptr, &sig_len);
    signature.resize(sig_len);
    EVP_DigestSignFinal(ctx, signature.data(), &sig_len);
    signature.resize(sig_len);
    EVP_MD_CTX_free(ctx);
    EVP_PKEY_free(pkey);
    return signature;
}

bool EncryptionManager::verify(const std::vector<uint8_t> &data, const std::vector<uint8_t> &signature, const KeyPair &key)
{
    BIO *bio = BIO_new_mem_buf(key.public_key.data(), static_cast<int>(key.public_key.size()));
    EVP_PKEY *pkey = PEM_read_bio_PUBKEY(bio, nullptr, nullptr, nullptr);
    BIO_free(bio);
    if (!pkey) return false;
    EVP_MD_CTX *ctx = EVP_MD_CTX_new();
    EVP_DigestVerifyInit(ctx, nullptr, EVP_sha256(), nullptr, pkey);
    EVP_DigestVerifyUpdate(ctx, data.data(), data.size());
    int ret = EVP_DigestVerifyFinal(ctx, signature.data(), signature.size());
    EVP_MD_CTX_free(ctx);
    EVP_PKEY_free(pkey);
    return ret == 1;
}

std::string EncryptionManager::signString(const std::string &data, const KeyPair &key)
{
    std::vector<uint8_t> input(data.begin(), data.end());
    auto sig = sign(input, key);
    return encodeBase64(sig);
}

bool EncryptionManager::verifyString(const std::string &data, const std::string &signature, const KeyPair &key)
{
    std::vector<uint8_t> input(data.begin(), data.end());
    auto sig = decodeBase64(signature);
    return verify(input, sig, key);
}

bool EncryptionManager::signFile(const std::string &file_path, const std::string &signature_path, const KeyPair &key)
{
    std::ifstream in(file_path, std::ios::binary);
    if (!in.is_open()) return false;
    std::vector<uint8_t> data((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    auto sig = sign(data, key);
    std::ofstream out(signature_path, std::ios::binary);
    if (!out.is_open()) return false;
    out.write(reinterpret_cast<const char*>(sig.data()), sig.size());
    return out.good();
}

bool EncryptionManager::verifyFile(const std::string &file_path, const std::string &signature_path, const KeyPair &key)
{
    std::ifstream in(file_path, std::ios::binary);
    if (!in.is_open()) return false;
    std::vector<uint8_t> data((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    std::ifstream sin(signature_path, std::ios::binary);
    if (!sin.is_open()) return false;
    std::vector<uint8_t> sig((std::istreambuf_iterator<char>(sin)), std::istreambuf_iterator<char>());
    return verify(data, sig, key);
}

std::vector<uint8_t> EncryptionManager::hash(const std::vector<uint8_t> &data, HashAlgorithm algorithm)
{
    const EVP_MD *md = EVP_sha256();
    switch (algorithm) {
        case HashAlgorithm::MD5: md = EVP_md5(); break;
        case HashAlgorithm::SHA1: md = EVP_sha1(); break;
        case HashAlgorithm::SHA224: md = EVP_sha224(); break;
        case HashAlgorithm::SHA256: md = EVP_sha256(); break;
        case HashAlgorithm::SHA384: md = EVP_sha384(); break;
        case HashAlgorithm::SHA512: md = EVP_sha512(); break;
        default: md = EVP_sha256(); break;
    }
    unsigned int len = EVP_MD_size(md);
    std::vector<uint8_t> result(len);
    EVP_MD_CTX *ctx = EVP_MD_CTX_new();
    EVP_DigestInit_ex(ctx, md, nullptr);
    EVP_DigestUpdate(ctx, data.data(), data.size());
    EVP_DigestFinal_ex(ctx, result.data(), &len);
    EVP_MD_CTX_free(ctx);
    result.resize(len);
    return result;
}

std::string EncryptionManager::hashString(const std::string &data, HashAlgorithm algorithm)
{
    std::vector<uint8_t> input(data.begin(), data.end());
    auto h = hash(input, algorithm);
    return encodeHex(h);
}

std::string EncryptionManager::hashFile(const std::string &file_path, HashAlgorithm algorithm)
{
    std::ifstream in(file_path, std::ios::binary);
    if (!in.is_open()) return "";
    const EVP_MD *md = EVP_sha256();
    switch (algorithm) {
        case HashAlgorithm::SHA256: md = EVP_sha256(); break;
        case HashAlgorithm::SHA512: md = EVP_sha512(); break;
        default: md = EVP_sha256(); break;
    }
    EVP_MD_CTX *ctx = EVP_MD_CTX_new();
    EVP_DigestInit_ex(ctx, md, nullptr);
    char buf[8192];
    while (in.read(buf, sizeof(buf))) EVP_DigestUpdate(ctx, buf, static_cast<size_t>(in.gcount()));
    if (in.gcount() > 0) EVP_DigestUpdate(ctx, buf, static_cast<size_t>(in.gcount()));
    unsigned int len = EVP_MD_size(md);
    std::vector<uint8_t> result(len);
    EVP_DigestFinal_ex(ctx, result.data(), &len);
    EVP_MD_CTX_free(ctx);
    return encodeHex(result);
}

bool EncryptionManager::verifyHash(const std::vector<uint8_t> &data, const std::vector<uint8_t> &expected_hash, HashAlgorithm algorithm)
{
    auto h = hash(data, algorithm);
    return h == expected_hash;
}

bool EncryptionManager::verifyHashString(const std::string &data, const std::string &expected_hash, HashAlgorithm algorithm)
{
    auto h = hashString(data, algorithm);
    return h == expected_hash;
}

std::vector<uint8_t> EncryptionManager::HMAC(const std::vector<uint8_t> &data, const std::vector<uint8_t> &key, HashAlgorithm algorithm)
{
    const EVP_MD *md = EVP_sha256();
    switch (algorithm) {
        case HashAlgorithm::SHA1: md = EVP_sha1(); break;
        case HashAlgorithm::SHA256: md = EVP_sha256(); break;
        case HashAlgorithm::SHA512: md = EVP_sha512(); break;
        default: md = EVP_sha256(); break;
    }
    unsigned int len = 0;
    std::vector<uint8_t> result(EVP_MAX_MD_SIZE);
    HMAC(md, key.data(), static_cast<int>(key.size()), data.data(), data.size(), result.data(), &len);
    result.resize(len);
    return result;
}

std::string EncryptionManager::HMACString(const std::string &data, const std::string &key, HashAlgorithm algorithm)
{
    std::vector<uint8_t> d(data.begin(), data.end());
    std::vector<uint8_t> k(key.begin(), key.end());
    auto h = HMAC(d, k, algorithm);
    return encodeHex(h);
}

bool EncryptionManager::verifyHMAC(const std::vector<uint8_t> &data, const std::vector<uint8_t> &hmac, const std::vector<uint8_t> &key, HashAlgorithm algorithm)
{
    auto computed = HMAC(data, key, algorithm);
    return computed == hmac;
}

std::vector<uint8_t> EncryptionManager::computeSharedSecret(const KeyPair &private_key, const KeyPair &public_key)
{
    if (private_key.algorithm == KeyExchangeAlgorithm::ECDH) return computeECDHSharedSecret(private_key, public_key);
    if (private_key.algorithm == KeyExchangeAlgorithm::X25519) return computeX25519SharedSecret(private_key.private_key_bytes, public_key.public_key_bytes);
    return computeDHSharedSecret(private_key, public_key);
}

std::vector<uint8_t> EncryptionManager::computeECDHSharedSecret(const KeyPair &private_key, const KeyPair &public_key)
{
    BIO *priv_bio = BIO_new_mem_buf(private_key.private_key.data(), static_cast<int>(private_key.private_key.size()));
    EVP_PKEY *priv = PEM_read_bio_PrivateKey(priv_bio, nullptr, nullptr, nullptr);
    BIO_free(priv_bio);
    BIO *pub_bio = BIO_new_mem_buf(public_key.public_key.data(), static_cast<int>(public_key.public_key.size()));
    EVP_PKEY *pub = PEM_read_bio_PUBKEY(pub_bio, nullptr, nullptr, nullptr);
    BIO_free(pub_bio);
    if (!priv || !pub) return {};
    EVP_PKEY_CTX *ctx = EVP_PKEY_CTX_new(priv, nullptr);
    EVP_PKEY_derive_init(ctx);
    EVP_PKEY_derive_set_peer(ctx, pub);
    size_t secret_len = 0;
    EVP_PKEY_derive(ctx, nullptr, &secret_len);
    std::vector<uint8_t> secret(secret_len);
    EVP_PKEY_derive(ctx, secret.data(), &secret_len);
    EVP_PKEY_CTX_free(ctx);
    EVP_PKEY_free(priv);
    EVP_PKEY_free(pub);
    return secret;
}

std::vector<uint8_t> EncryptionManager::computeDHSharedSecret(const KeyPair &private_key, const KeyPair &public_key)
{
    return computeECDHSharedSecret(private_key, public_key);
}

std::vector<uint8_t> EncryptionManager::computeX25519SharedSecret(const std::vector<uint8_t> &private_key, const std::vector<uint8_t> &public_key)
{
    std::vector<uint8_t> secret(32);
    (void)private_key;
    (void)public_key;
    return secret;
}

std::vector<uint8_t> EncryptionManager::generateRandomBytes(size_t length)
{
    std::vector<uint8_t> result(length);
    RAND_bytes(result.data(), static_cast<int>(length));
    return result;
}

uint32_t EncryptionManager::generateRandomInt(uint32_t min, uint32_t max)
{
    if (min >= max) return min;
    uint32_t range = max - min + 1;
    uint32_t val;
    RAND_bytes(reinterpret_cast<uint8_t*>(&val), sizeof(val));
    return min + (val % range);
}

uint64_t EncryptionManager::generateRandomLong(uint64_t min, uint64_t max)
{
    if (min >= max) return min;
    uint64_t range = max - min + 1;
    uint64_t val;
    RAND_bytes(reinterpret_cast<uint8_t*>(&val), sizeof(val));
    return min + (val % range);
}

std::string EncryptionManager::generateRandomString(size_t length)
{
    static const char chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    std::string result;
    result.reserve(length);
    for (size_t i = 0; i < length; ++i) {
        uint32_t idx;
        RAND_bytes(reinterpret_cast<uint8_t*>(&idx), sizeof(idx));
        result.push_back(chars[idx % (sizeof(chars) - 1)]);
    }
    return result;
}

std::string EncryptionManager::generateUUID()
{
    auto bytes = generateRandomBytes(16);
    bytes[6] = (bytes[6] & 0x0F) | 0x40;
    bytes[8] = (bytes[8] & 0x3F) | 0x80;
    char buf[37];
    snprintf(buf, sizeof(buf), "%02x%02x%02x%02x-%02x%02x-%02x%02x-%02x%02x-%02x%02x%02x%02x%02x%02x",
        bytes[0], bytes[1], bytes[2], bytes[3], bytes[4], bytes[5], bytes[6], bytes[7],
        bytes[8], bytes[9], bytes[10], bytes[11], bytes[12], bytes[13], bytes[14], bytes[15]);
    return buf;
}

std::string EncryptionManager::generateSessionId()
{
    return "sess_" + generateRandomString(16);
}

std::string EncryptionManager::generateToken(size_t length)
{
    return generateRandomString(length);
}

std::string EncryptionManager::encodeBase64(const std::vector<uint8_t> &data)
{
    BIO *bio, *b64;
    BUF_MEM *buffer;
    b64 = BIO_new(BIO_f_base64());
    bio = BIO_new(BIO_s_mem());
    bio = BIO_push(b64, bio);
    BIO_write(bio, data.data(), static_cast<int>(data.size()));
    BIO_flush(bio);
    BIO_get_mem_ptr(bio, &buffer);
    std::string result(buffer->data, buffer->length - 1);
    BIO_free_all(bio);
    return result;
}

std::vector<uint8_t> EncryptionManager::decodeBase64(const std::string &data)
{
    BIO *bio, *b64;
    size_t len = data.size();
    std::vector<uint8_t> result(len);
    b64 = BIO_new(BIO_f_base64());
    bio = BIO_new_mem_buf(data.c_str(), static_cast<int>(len));
    bio = BIO_push(b64, bio);
    int decoded = BIO_read(bio, result.data(), static_cast<int>(len));
    BIO_free_all(bio);
    if (decoded > 0) result.resize(static_cast<size_t>(decoded));
    else result.clear();
    return result;
}

std::string EncryptionManager::encodeBase64URL(const std::vector<uint8_t> &data)
{
    std::string b64 = encodeBase64(data);
    for (auto &c : b64) {
        if (c == '+') c = '-';
        else if (c == '/') c = '_';
    }
    size_t pos = b64.find('=');
    if (pos != std::string::npos) b64 = b64.substr(0, pos);
    return b64;
}

std::vector<uint8_t> EncryptionManager::decodeBase64URL(const std::string &data)
{
    std::string b64 = data;
    for (auto &c : b64) {
        if (c == '-') c = '+';
        else if (c == '_') c = '/';
    }
    while (b64.size() % 4) b64.push_back('=');
    return decodeBase64(b64);
}

std::string EncryptionManager::encodeHex(const std::vector<uint8_t> &data)
{
    std::ostringstream oss;
    for (auto b : data) oss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(b);
    return oss.str();
}

std::vector<uint8_t> EncryptionManager::decodeHex(const std::string &hex)
{
    std::vector<uint8_t> data;
    for (size_t i = 0; i < hex.size(); i += 2) {
        uint8_t byte = 0;
        for (int j = 0; j < 2 && i + j < hex.size(); ++j) {
            char c = hex[i + j];
            byte <<= 4;
            if (c >= '0' && c <= '9') byte |= (c - '0');
            else if (c >= 'a' && c <= 'f') byte |= (10 + c - 'a');
            else if (c >= 'A' && c <= 'F') byte |= (10 + c - 'A');
        }
        data.push_back(byte);
    }
    return data;
}

std::vector<uint8_t> EncryptionManager::compress(const std::vector<uint8_t> &data, int level)
{
    z_stream strm;
    memset(&strm, 0, sizeof(strm));
    if (deflateInit(&strm, level) != Z_OK) return {};
    std::vector<uint8_t> result(deflateBound(&strm, static_cast<uLong>(data.size())));
    strm.next_in = const_cast<uint8_t*>(data.data());
    strm.avail_in = static_cast<uInt>(data.size());
    strm.next_out = result.data();
    strm.avail_out = static_cast<uInt>(result.size());
    deflate(&strm, Z_FINISH);
    result.resize(strm.total_out);
    deflateEnd(&strm);
    return result;
}

std::vector<uint8_t> EncryptionManager::decompress(const std::vector<uint8_t> &data)
{
    z_stream strm;
    memset(&strm, 0, sizeof(strm));
    if (inflateInit(&strm) != Z_OK) return {};
    std::vector<uint8_t> result(data.size() * 4);
    strm.next_in = const_cast<uint8_t*>(data.data());
    strm.avail_in = static_cast<uInt>(data.size());
    strm.next_out = result.data();
    strm.avail_out = static_cast<uInt>(result.size());
    inflate(&strm, Z_FINISH);
    result.resize(strm.total_out);
    inflateEnd(&strm);
    return result;
}

std::string EncryptionManager::compressString(const std::string &data, int level)
{
    std::vector<uint8_t> input(data.begin(), data.end());
    auto compressed = compress(input, level);
    return encodeBase64(compressed);
}

std::string EncryptionManager::decompressString(const std::string &data)
{
    auto compressed = decodeBase64(data);
    auto decompressed = decompress(compressed);
    return std::string(decompressed.begin(), decompressed.end());
}

bool EncryptionManager::hasHardwareSupport() const
{
    return hardwareAcceleration;
}

std::string EncryptionManager::getVersion() const
{
    return "1.0.0";
}

std::string EncryptionManager::getProviderName() const
{
    return "OpenSSL";
}

bool EncryptionManager::isFIPSEnabled() const
{
    return false;
}

bool EncryptionManager::isHardwareAccelerated() const
{
    return hardwareAcceleration;
}

SecurityConfig EncryptionManager::getConfig() const
{
    return config;
}

bool EncryptionManager::setConfig(const SecurityConfig &config)
{
    this->config = config;
    return true;
}

void EncryptionManager::setDefaultCipher(CipherAlgorithm algorithm)
{
    config.default_cipher = algorithm;
}

void EncryptionManager::setDefaultHash(HashAlgorithm algorithm)
{
    config.default_hash = algorithm;
}

void EncryptionManager::setKeyDerivationIterations(uint32_t iterations)
{
    config.iterations = iterations;
}

void EncryptionManager::setKeyRotationDays(uint32_t days)
{
    config.key_rotation_days = days;
}

void EncryptionManager::enableAutoKeyRotation(bool enable)
{
    autoKeyRotation = enable;
}

bool EncryptionManager::isAutoKeyRotationEnabled() const
{
    return autoKeyRotation;
}

bool EncryptionManager::saveKeyStore(const std::string &path)
{
    return saveKeysToFile(path);
}

bool EncryptionManager::loadKeyStore(const std::string &path)
{
    return loadKeysFromFile(path);
}

bool EncryptionManager::clearKeyStore()
{
    std::lock_guard<std::mutex> lock(keyMutex);
    keys.clear();
    keyPairs.clear();
    return true;
}

void EncryptionManager::onSecurityEvent(std::function<void(const std::string&, const std::string&)> callback)
{
    securityCallback = callback;
}

bool EncryptionManager::encryptAES(const std::vector<uint8_t> &plaintext, std::vector<uint8_t> &ciphertext, const EncryptionKey &key)
{
    return encryptWithEVP(plaintext, ciphertext, key);
}

bool EncryptionManager::decryptAES(const std::vector<uint8_t> &ciphertext, std::vector<uint8_t> &plaintext, const EncryptionKey &key)
{
    return decryptWithEVP(ciphertext, plaintext, key);
}

bool EncryptionManager::encryptChaCha20(const std::vector<uint8_t> &plaintext, std::vector<uint8_t> &ciphertext, const EncryptionKey &key)
{
    return encryptWithEVP(plaintext, ciphertext, key);
}

bool EncryptionManager::decryptChaCha20(const std::vector<uint8_t> &ciphertext, std::vector<uint8_t> &plaintext, const EncryptionKey &key)
{
    return decryptWithEVP(ciphertext, plaintext, key);
}

bool EncryptionManager::encryptWithEVP(const std::vector<uint8_t> &plaintext, std::vector<uint8_t> &ciphertext, const EncryptionKey &key)
{
    const EVP_CIPHER *cipher = EVP_aes_256_gcm();
    int nid = getOpenSSLCipher(key.algorithm);
    if (nid > 0) cipher = EVP_get_cipherbynid(nid);
    if (!cipher) return false;
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (!ctx) return false;
    if (EVP_EncryptInit_ex(ctx, cipher, nullptr, key.key_data.data(), key.iv.data()) != 1) {
        EVP_CIPHER_CTX_free(ctx);
        return false;
    }
    if (isAEAD(key.algorithm) && !key.aad.empty()) {
        EVP_EncryptUpdate(ctx, nullptr, nullptr, key.aad.data(), static_cast<int>(key.aad.size()));
    }
    size_t block_size = static_cast<size_t>(EVP_CIPHER_CTX_block_size(ctx));
    std::vector<uint8_t> padded = (block_size > 1) ? padPKCS7(plaintext, block_size) : plaintext;
    ciphertext.resize(padded.size() + EVP_CIPHER_CTX_block_size(ctx));
    int out_len = 0;
    if (EVP_EncryptUpdate(ctx, ciphertext.data(), &out_len, padded.data(), static_cast<int>(padded.size())) != 1) {
        EVP_CIPHER_CTX_free(ctx);
        return false;
    }
    int tmp_len = 0;
    if (EVP_EncryptFinal_ex(ctx, ciphertext.data() + out_len, &tmp_len) != 1) {
        EVP_CIPHER_CTX_free(ctx);
        return false;
    }
    out_len += tmp_len;
    ciphertext.resize(static_cast<size_t>(out_len));
    if (isAEAD(key.algorithm) || isAuthenticated(key.algorithm)) {
        uint8_t tag[16];
        if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, static_cast<int>(key.tag_size > 0 ? key.tag_size : 16), tag) != 1) {
            EVP_CIPHER_CTX_free(ctx);
            return false;
        }
        ciphertext.insert(ciphertext.end(), tag, tag + (key.tag_size > 0 ? key.tag_size : 16));
    }
    EVP_CIPHER_CTX_free(ctx);
    return true;
}

bool EncryptionManager::decryptWithEVP(const std::vector<uint8_t> &ciphertext, std::vector<uint8_t> &plaintext, const EncryptionKey &key)
{
    const EVP_CIPHER *cipher = EVP_aes_256_gcm();
    int nid = getOpenSSLCipher(key.algorithm);
    if (nid > 0) cipher = EVP_get_cipherbynid(nid);
    if (!cipher) return false;
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (!ctx) return false;
    if (EVP_DecryptInit_ex(ctx, cipher, nullptr, key.key_data.data(), key.iv.data()) != 1) {
        EVP_CIPHER_CTX_free(ctx);
        return false;
    }
    size_t tag_size = isAEAD(key.algorithm) ? (key.tag_size > 0 ? key.tag_size : 16) : 0;
    std::vector<uint8_t> ct_data = ciphertext;
    std::vector<uint8_t> tag;
    if (tag_size > 0 && ct_data.size() >= tag_size) {
        tag.assign(ct_data.end() - static_cast<ptrdiff_t>(tag_size), ct_data.end());
        ct_data.resize(ct_data.size() - tag_size);
    }
    if (isAEAD(key.algorithm) && !key.aad.empty()) {
        EVP_DecryptUpdate(ctx, nullptr, nullptr, key.aad.data(), static_cast<int>(key.aad.size()));
    }
    plaintext.resize(ct_data.size() + EVP_CIPHER_CTX_block_size(ctx));
    int out_len = 0;
    if (EVP_DecryptUpdate(ctx, plaintext.data(), &out_len, ct_data.data(), static_cast<int>(ct_data.size())) != 1) {
        EVP_CIPHER_CTX_free(ctx);
        return false;
    }
    if (!tag.empty()) {
        EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_TAG, static_cast<int>(tag.size()), tag.data());
    }
    int tmp_len = 0;
    if (EVP_DecryptFinal_ex(ctx, plaintext.data() + out_len, &tmp_len) != 1) {
        EVP_CIPHER_CTX_free(ctx);
        return false;
    }
    out_len += tmp_len;
    plaintext.resize(static_cast<size_t>(out_len));
    EVP_CIPHER_CTX_free(ctx);
    if (EVP_CIPHER_block_size(cipher) > 1) plaintext = unpadPKCS7(plaintext);
    return true;
}

std::vector<uint8_t> EncryptionManager::padPKCS7(const std::vector<uint8_t> &data, size_t block_size)
{
    if (block_size == 0 || block_size > 255) return data;
    size_t pad_len = block_size - (data.size() % block_size);
    std::vector<uint8_t> padded = data;
    padded.insert(padded.end(), pad_len, static_cast<uint8_t>(pad_len));
    return padded;
}

std::vector<uint8_t> EncryptionManager::unpadPKCS7(const std::vector<uint8_t> &data)
{
    if (data.empty()) return data;
    size_t pad_len = data.back();
    if (pad_len == 0 || pad_len > data.size()) return data;
    for (size_t i = data.size() - pad_len; i < data.size(); ++i) {
        if (data[i] != pad_len) return data;
    }
    return std::vector<uint8_t>(data.begin(), data.end() - static_cast<ptrdiff_t>(pad_len));
}

void EncryptionManager::generateSalt(std::vector<uint8_t> &salt, size_t size)
{
    salt.resize(size);
    RAND_bytes(salt.data(), static_cast<int>(size));
}

void EncryptionManager::generateIV(std::vector<uint8_t> &iv, size_t size)
{
    iv.resize(size);
    RAND_bytes(iv.data(), static_cast<int>(size));
}

void EncryptionManager::generateTag(std::vector<uint8_t> &tag, size_t size)
{
    tag.resize(size);
    RAND_bytes(tag.data(), static_cast<int>(size));
}

bool EncryptionManager::validateKey(const EncryptionKey &key) const
{
    return !key.key_data.empty() && key.key_size > 0;
}

bool EncryptionManager::validateKeyPair(const KeyPair &pair) const
{
    return !pair.public_key.empty() || !pair.private_key.empty();
}

bool EncryptionManager::isKeyExpired(const EncryptionKey &key) const
{
    if (key.permanent) return false;
    auto now = std::chrono::system_clock::now();
    return now > key.expires_at;
}

void EncryptionManager::initOpenSSL()
{
    OpenSSL_add_all_algorithms();
    ERR_load_crypto_strings();
    OpenSSL_add_all_ciphers();
    OpenSSL_add_all_digests();
}

void EncryptionManager::cleanupOpenSSL()
{
    EVP_cleanup();
    ERR_free_strings();
}

bool EncryptionManager::checkForHardwareSupport()
{
    return false;
}

bool EncryptionManager::saveKeysToFile(const std::string &path)
{
    std::ofstream out(path);
    if (!out.is_open()) return false;
    for (const auto &kv : keys) {
        out << kv.first << ":" << encodeHex(kv.second.key_data) << "\n";
    }
    return out.good();
}

bool EncryptionManager::loadKeysFromFile(const std::string &path)
{
    std::ifstream in(path);
    if (!in.is_open()) return false;
    std::string line;
    while (std::getline(in, line)) {
        size_t colon = line.find(':');
        if (colon == std::string::npos) continue;
        std::string id = line.substr(0, colon);
        std::string hex = line.substr(colon + 1);
        EncryptionKey key;
        key.key_id = id;
        key.key_data = decodeHex(hex);
        keys[id] = key;
    }
    return true;
}

void EncryptionManager::logSecurityEvent(const std::string &event, const std::string &details)
{
    if (securityCallback) securityCallback(event, details);
}

std::string EncryptionManager::getCipherName(CipherAlgorithm algorithm)
{
    return getAlgorithmString(algorithm);
}

std::string EncryptionManager::getHashName(HashAlgorithm algorithm)
{
    switch (algorithm) {
        case HashAlgorithm::MD5: return "MD5";
        case HashAlgorithm::SHA1: return "SHA1";
        case HashAlgorithm::SHA224: return "SHA224";
        case HashAlgorithm::SHA256: return "SHA256";
        case HashAlgorithm::SHA384: return "SHA384";
        case HashAlgorithm::SHA512: return "SHA512";
        case HashAlgorithm::SHA3_256: return "SHA3-256";
        default: return "SHA256";
    }
}

std::string EncryptionManager::getAlgorithmString(CipherAlgorithm algorithm)
{
    switch (algorithm) {
        case CipherAlgorithm::AES_128_ECB: return "aes-128-ecb";
        case CipherAlgorithm::AES_128_CBC: return "aes-128-cbc";
        case CipherAlgorithm::AES_128_CFB: return "aes-128-cfb";
        case CipherAlgorithm::AES_128_OFB: return "aes-128-ofb";
        case CipherAlgorithm::AES_128_CTR: return "aes-128-ctr";
        case CipherAlgorithm::AES_128_GCM: return "aes-128-gcm";
        case CipherAlgorithm::AES_256_ECB: return "aes-256-ecb";
        case CipherAlgorithm::AES_256_CBC: return "aes-256-cbc";
        case CipherAlgorithm::AES_256_CFB: return "aes-256-cfb";
        case CipherAlgorithm::AES_256_OFB: return "aes-256-ofb";
        case CipherAlgorithm::AES_256_CTR: return "aes-256-ctr";
        case CipherAlgorithm::AES_256_GCM: return "aes-256-gcm";
        case CipherAlgorithm::ChaCha20: return "chacha20";
        case CipherAlgorithm::ChaCha20_Poly1305: return "chacha20-poly1305";
        default: return "aes-256-gcm";
    }
}

int EncryptionManager::getOpenSSLCipher(CipherAlgorithm algorithm)
{
    switch (algorithm) {
        case CipherAlgorithm::AES_128_ECB: return NID_aes_128_ecb;
        case CipherAlgorithm::AES_128_CBC: return NID_aes_128_cbc;
        case CipherAlgorithm::AES_128_CFB: return NID_aes_128_cfb;
        case CipherAlgorithm::AES_128_OFB: return NID_aes_128_ofb;
        case CipherAlgorithm::AES_128_CTR: return NID_aes_128_ctr;
        case CipherAlgorithm::AES_128_GCM: return NID_aes_128_gcm;
        case CipherAlgorithm::AES_256_ECB: return NID_aes_256_ecb;
        case CipherAlgorithm::AES_256_CBC: return NID_aes_256_cbc;
        case CipherAlgorithm::AES_256_CFB: return NID_aes_256_cfb;
        case CipherAlgorithm::AES_256_OFB: return NID_aes_256_ofb;
        case CipherAlgorithm::AES_256_CTR: return NID_aes_256_ctr;
        case CipherAlgorithm::AES_256_GCM: return NID_aes_256_gcm;
        default: return NID_aes_256_gcm;
    }
}

int EncryptionManager::getOpenSSLHash(HashAlgorithm algorithm)
{
    switch (algorithm) {
        case HashAlgorithm::MD5: return NID_md5;
        case HashAlgorithm::SHA1: return NID_sha1;
        case HashAlgorithm::SHA224: return NID_sha224;
        case HashAlgorithm::SHA256: return NID_sha256;
        case HashAlgorithm::SHA384: return NID_sha384;
        case HashAlgorithm::SHA512: return NID_sha512;
        default: return NID_sha256;
    }
}

size_t EncryptionManager::getKeySize(CipherAlgorithm algorithm)
{
    switch (algorithm) {
        case CipherAlgorithm::AES_128_ECB:
        case CipherAlgorithm::AES_128_CBC:
        case CipherAlgorithm::AES_128_CFB:
        case CipherAlgorithm::AES_128_OFB:
        case CipherAlgorithm::AES_128_CTR:
        case CipherAlgorithm::AES_128_GCM:
        case CipherAlgorithm::AES_128_CCM:
            return 16;
        case CipherAlgorithm::AES_192_ECB:
        case CipherAlgorithm::AES_192_CBC:
        case CipherAlgorithm::AES_192_CFB:
        case CipherAlgorithm::AES_192_OFB:
        case CipherAlgorithm::AES_192_CTR:
        case CipherAlgorithm::AES_192_GCM:
        case CipherAlgorithm::AES_192_CCM:
            return 24;
        case CipherAlgorithm::AES_256_ECB:
        case CipherAlgorithm::AES_256_CBC:
        case CipherAlgorithm::AES_256_CFB:
        case CipherAlgorithm::AES_256_OFB:
        case CipherAlgorithm::AES_256_CTR:
        case CipherAlgorithm::AES_256_GCM:
        case CipherAlgorithm::AES_256_CCM:
        case CipherAlgorithm::ChaCha20:
        case CipherAlgorithm::ChaCha20_Poly1305:
            return 32;
        default: return 32;
    }
}

size_t EncryptionManager::getIVSize(CipherAlgorithm algorithm)
{
    switch (algorithm) {
        case CipherAlgorithm::AES_128_ECB:
        case CipherAlgorithm::AES_192_ECB:
        case CipherAlgorithm::AES_256_ECB:
            return 0;
        case CipherAlgorithm::AES_128_GCM:
        case CipherAlgorithm::AES_192_GCM:
        case CipherAlgorithm::AES_256_GCM:
        case CipherAlgorithm::ChaCha20:
            return 12;
        default: return 16;
    }
}

size_t EncryptionManager::getTagSize(CipherAlgorithm algorithm)
{
    switch (algorithm) {
        case CipherAlgorithm::AES_128_GCM:
        case CipherAlgorithm::AES_192_GCM:
        case CipherAlgorithm::AES_256_GCM:
        case CipherAlgorithm::ChaCha20_Poly1305:
            return 16;
        default: return 0;
    }
}

bool EncryptionManager::isAuthenticated(CipherAlgorithm algorithm)
{
    return isAEAD(algorithm);
}

bool EncryptionManager::isAEAD(CipherAlgorithm algorithm)
{
    return algorithm == CipherAlgorithm::AES_128_GCM ||
           algorithm == CipherAlgorithm::AES_192_GCM ||
           algorithm == CipherAlgorithm::AES_256_GCM ||
           algorithm == CipherAlgorithm::AES_128_CCM ||
           algorithm == CipherAlgorithm::AES_192_CCM ||
           algorithm == CipherAlgorithm::AES_256_CCM ||
           algorithm == CipherAlgorithm::ChaCha20_Poly1305;
}
