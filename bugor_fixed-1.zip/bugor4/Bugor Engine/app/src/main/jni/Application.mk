APP_ABI := arm64-v8a
APP_PLATFORM := android-29
APP_STL := c++_static
APP_CPPFLAGS := -std=c++20 -fno-rtti -fno-exceptions
APP_OPTIM := release
NDK_TOOLCHAIN_VERSION := clang
