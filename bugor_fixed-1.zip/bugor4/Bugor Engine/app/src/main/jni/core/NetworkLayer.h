#pragma once
#include <string>
#include <vector>
#include <map>
#include <functional>
#include <thread>
#include <mutex>
#include <atomic>
#include <cstdint>

namespace NetworkLayer {

enum class PacketType : uint8_t {
    HEARTBEAT = 0,
    CONFIG_SYNC = 1,
    COMMAND = 2,
    DATA_REQUEST = 3,
    DATA_RESPONSE = 4,
    LOG = 5,
    ERROR = 6,
    SHUTDOWN = 7
};

struct PacketHeader {
    uint32_t magic;      // 0x42475200 ('BGR\0')
    PacketType type;
    uint32_t size;        // payload size (little-endian)
    uint32_t checksum;    // CRC32 of payload
    uint8_t reserved[6];
} __attribute__((packed));

struct Packet {
    PacketHeader header;
    std::vector<uint8_t> payload;
};

class NetworkServer {
    int serverFd;
    int clientFd;
    std::thread acceptThread;
    std::thread recvThread;
    std::mutex sendMutex;
    std::mutex clientMutex;
    std::atomic<bool> running;
    std::atomic<bool> connected;
    int port;
    std::vector<uint8_t> recvBuffer;

    void AcceptLoop();
    void RecvLoop();
    void HandlePacket(const Packet& pkt);
    uint32_t CalculateCRC32(const uint8_t* data, size_t len);

public:
    NetworkServer(int port = 13370);
    ~NetworkServer();

    bool Start();
    void Stop();
    void SendPacket(const Packet& pkt);
    void SendConfigSync(const std::map<std::string, int>& toggles, const std::map<std::string, float>& config);
    void SendLog(const std::string& msg);
    void SendCommand(const std::string& cmd);

    bool IsConnected() const { return connected; }
    bool IsRunning() const { return running; }

    std::function<void(const std::string& cmd)> OnCommand;
    std::function<void(const std::map<std::string, int>&)> OnConfigSync;
};

class NetworkClient {
    int sockFd;
    std::thread recvThread;
    std::mutex sendMutex;
    std::atomic<bool> running;
    std::atomic<bool> connected;
    std::string host;
    int port;
    std::vector<uint8_t> recvBuffer;

    void RecvLoop();
    void HandlePacket(const Packet& pkt);
    uint32_t CalculateCRC32(const uint8_t* data, size_t len);

public:
    NetworkClient(const std::string& host = "127.0.0.1", int port = 13370);
    ~NetworkClient();

    bool Connect();
    void Disconnect();
    void SendPacket(const Packet& pkt);
    void SendCommand(const std::string& cmd);

    bool IsConnected() const { return connected; }

    std::function<void(const std::string& cmd)> OnCommand;
};

}
