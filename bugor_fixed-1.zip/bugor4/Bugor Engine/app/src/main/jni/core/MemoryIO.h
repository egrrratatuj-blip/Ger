#ifndef BUGOR_CORE_MEMORYIO_H
#define BUGOR_CORE_MEMORYIO_H

#include <sys/uio.h>
#include <cstdint>
#include <cstddef>
#include <cstdio>
#include <vector>
#include <string>

struct BatchEntry {
    uintptr_t addr;
    void* buf;
    size_t size;
};

ssize_t ReadProcessMemory(int pid, uintptr_t addr, void* buf, size_t size);
ssize_t WriteProcessMemory(int pid, uintptr_t addr, const void* buf, size_t size);
ssize_t ReadProcessVM(int pid, const iovec* local, unsigned long lcnt,
                      const iovec* remote, unsigned long rcnt, bool write);

class MemoryIO {
public:
    int pid;
    int m_TimeoutMs;
    int m_memFd;
    pid_t m_memPid;

    MemoryIO();
    ~MemoryIO();
    void Init(int pid1);
    void SetTimeout(int ms);
    int GetPID(const char* packageName);
    void CloseMemFd();

    bool Read(uintptr_t addr, void* buf, size_t size);
    bool Write(uintptr_t addr, const void* buf, size_t size);
    float ReadFloat(uintptr_t addr);
    int ReadInt(uintptr_t addr);
    uint32_t ReadDword(uintptr_t addr);
    uint64_t ReadQword(uintptr_t addr);
    uint8_t ReadByte(uintptr_t addr);
    uintptr_t ReadPtr64(uintptr_t addr);
    uintptr_t ReadPtr32(uintptr_t addr);
    void WriteFloat(uintptr_t addr, float val);
    void WriteInt(uintptr_t addr, int val);
    void WriteDword(uintptr_t addr, uint32_t val);
    void WriteQword(uintptr_t addr, uint64_t val);

    uintptr_t GetModuleBase(const char* name);
    uintptr_t GetModuleBase(const char* name, bool exactMatch);
    uintptr_t GetBSS(const char* name);
    size_t GetModuleSize(const char* name);
    bool ReadString(uintptr_t addr, char* buf, size_t maxLen);
    bool ReadUTF8String(uintptr_t addr, char* buf, size_t maxLen);

    uintptr_t FindSignature(const char* module, const char* pattern, const char* mask);
    std::vector<uintptr_t> FindSignatures(const char* module, const char* pattern, const char* mask);
    uintptr_t TracePointer(uintptr_t addr, const std::vector<uintptr_t>& offsets);
    bool ReadBatch(std::vector<BatchEntry>& entries);
};

#endif
