#ifndef BUGOR_CORE_ENGINE_H
#define BUGOR_CORE_ENGINE_H

#include <string>
#include <vector>
#include <map>
#include <functional>
#include <memory>
#include <mutex>
#include <atomic>
#include <thread>
#include <chrono>
#include <queue>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <set>
#include <cstdint>
#include <cstring>
#include <dlfcn.h>
#include <jni.h>

#include "../memory/MemoryManager.h"
#include "../hooking/HookingFramework.h"
#include "../crash/CrashReporter.h"
#include "../core/ScriptEngine.h"
#include "../analytics/AnalyticsEngine.h"
#include "../remote/RemoteControl.h"
#include "../persistence/PersistenceManager.h"
#include "../encryption/EncryptionManager.h"
#include "../debugger/Debugger.h"
#include "../app/LoggingSystem.h"

enum class EngineMode {
    Standalone,
    Client,
    Server,
    Debug,
    Replay,
    Analysis,
    Hybrid
};

enum class EngineState {
    Uninitialized,
    Initializing,
    Ready,
    Running,
    Paused,
    Stopping,
    Stopped,
    Error,
    Recovery
};

struct EngineConfig {
    std::string app_name;
    std::string app_version;
    std::string data_directory;
    std::string log_directory;
    std::string config_directory;
    std::string plugin_directory;
    std::string script_directory;
    std::string temp_directory;
    std::string cache_directory;
    std::string crash_dump_directory;
    std::string encryption_key_path;
    std::string license_key;
    std::string remote_host;
    std::string remote_api_key;
    uint16_t remote_port;
    uint16_t debugger_port;
    uint32_t worker_threads;
    uint32_t max_memory_mb;
    uint32_t operation_timeout_ms;
    uint32_t initialization_timeout_ms;
    uint32_t shutdown_timeout_ms;
    bool enable_logging;
    bool enable_crash_reporter;
    bool enable_script_engine;
    bool enable_analytics;
    bool enable_remote_control;
    bool enable_persistence;
    bool enable_encryption;
    bool enable_debugger;
    bool enable_hooking;
    bool enable_memory_operations;
    bool enable_auto_recovery;
    bool enable_performance_monitoring;
    bool enable_security;
    bool enable_sandbox;
    bool enable_multi_threading;
    bool enable_plugin_system;
    bool enable_hot_reload;
    bool enable_auto_update;
    bool strict_mode;
    bool debug_mode;
    EngineMode mode;
};

struct EngineMetrics {
    uint64_t uptime_ms;
    uint64_t memory_usage;
    uint64_t peak_memory_usage;
    uint64_t thread_count;
    uint64_t active_operations;
    uint64_t total_operations;
    uint64_t failed_operations;
    uint64_t total_memory_reads;
    uint64_t total_memory_writes;
    uint64_t total_hooks_installed;
    uint64_t total_hooks_removed;
    uint64_t total_scripts_executed;
    uint64_t total_analytics_events;
    double cpu_usage_percent;
    double operations_per_second;
    double avg_response_time_ms;
    double max_response_time_ms;
    double error_rate;
    std::map<std::string, double> subcomponent_metrics;
};

struct HealthStatus {
    bool database_healthy;
    bool memory_subsystem_healthy;
    bool hooking_subsystem_healthy;
    bool script_engine_healthy;
    bool remote_connection_healthy;
    bool encryption_subsystem_healthy;
    bool crash_reporter_healthy;
    bool analytics_healthy;
    bool debugger_healthy;
    bool persistence_healthy;
    std::string last_error;
    std::string last_error_timestamp;
    std::map<std::string, bool> component_health;
    std::map<std::string, std::string> component_errors;
};

class BugorEngine {
public:
    static BugorEngine& getInstance();

    BugorEngine();
    ~BugorEngine();

    bool initialize(const EngineConfig &config);
    bool initialize(int argc, char *argv[]);
    void shutdown();
    bool restart();
    bool isInitialized() const;
    bool isRunning() const;
    EngineState getState() const;
    EngineMode getMode() const;

    bool start();
    bool stop();
    bool pause();
    bool resume();
    bool reload();

    bool recover();
    bool reset();
    bool clearState();

    EngineConfig getConfig() const;
    bool setConfig(const EngineConfig &config);
    bool updateConfig(const std::string &key, const std::string &value);
    bool loadConfig(const std::string &path);
    bool saveConfig(const std::string &path);

    MemoryManager* getMemoryManager();
    HookingFramework* getHookingFramework();
    CrashReporter* getCrashReporter();
    ScriptEngine* getScriptEngine();
    AnalyticsEngine* getAnalyticsEngine();
    RemoteControlClient* getRemoteClient();
    PersistenceManager* getPersistenceManager();
    EncryptionManager* getEncryptionManager();
    Debugger* getDebugger();
    LoggingSystem* getLoggingSystem();

    std::string executeCommand(const std::string &command, const std::map<std::string, std::string> &params = {});
    std::string executeScript(const std::string &script);
    std::string executeExpression(const std::string &expression);

    bool loadPlugin(const std::string &path);
    bool unloadPlugin(const std::string &name);
    bool reloadPlugin(const std::string &name);
    std::vector<std::string> getLoadedPlugins() const;

    bool registerCommand(const std::string &name, std::function<std::string(const std::map<std::string, std::string>&)> handler);
    bool unregisterCommand(const std::string &name);
    bool hasCommand(const std::string &name) const;
    std::vector<std::string> getRegisteredCommands() const;

    bool registerEventHandler(const std::string &event, std::function<void(const std::map<std::string, std::string>&)> handler);
    bool unregisterEventHandler(const std::string &event);
    bool emitEvent(const std::string &event, const std::map<std::string, std::string> &data = {});

    bool loadConfigFromFile(const std::string &path);
    bool saveConfigToFile(const std::string &path);
    std::string getConfigAsJSON() const;
    bool loadConfigFromJSON(const std::string &json);

    EngineMetrics getMetrics() const;
    bool resetMetrics();
    bool enableMetrics(bool enable);
    bool isMetricsEnabled() const;

    HealthStatus getHealthStatus() const;
    bool runHealthCheck();
    bool runDiagnostics();
    std::string getDiagnosticsReport() const;

    bool isFeatureEnabled(const std::string &feature) const;
    bool enableFeature(const std::string &feature);
    bool disableFeature(const std::string &feature);
    std::vector<std::string> getEnabledFeatures() const;
    std::vector<std::string> getAvailableFeatures() const;

    std::string getVersion() const;
    std::string getBuildInfo() const;
    std::string getPlatformInfo() const;

    bool checkLicense();
    std::string getLicenseInfo() const;

    bool takeScreenshot(const std::string &path = "");
    bool recordScreen(const std::string &path, uint32_t duration_ms = 0);

    void onStateChange(std::function<void(EngineState, EngineState)> callback);
    void onError(std::function<void(const std::string&, int)> callback);
    void onWarning(std::function<void(const std::string&)> callback);

    JavaVM* getJavaVM() const;
    JNIEnv* getJNIEnv() const;
    bool attachToJVM(JavaVM *vm);
    bool detachFromJVM();

private:
    static BugorEngine *instance;

    bool initialized;
    bool running;
    bool metricsEnabled;
    bool paused;

    EngineState state;
    EngineMode mode;
    EngineConfig config;
    EngineMetrics metrics;
    HealthStatus health;

    JavaVM *javaVM;
    std::thread::id mainThreadId;

    std::mutex engineMutex;
    std::mutex commandMutex;
    std::mutex eventMutex;
    std::mutex pluginMutex;
    std::mutex metricsMutex;

    MemoryManager *memoryManager;
    HookingFramework *hookingFramework;
    CrashReporter *crashReporter;
    ScriptEngine *scriptEngine;
    AnalyticsEngine *analyticsEngine;
    RemoteControlClient *remoteClient;
    RemoteControlServer *remoteServer;
    PersistenceManager *persistenceManager;
    EncryptionManager *encryptionManager;
    Debugger *debugger;
    LoggingSystem *loggingSystem;

    std::map<std::string, void*> loadedPlugins;
    std::map<std::string, std::function<std::string(const std::map<std::string, std::string>&)>> commandHandlers;
    std::map<std::string, std::vector<std::function<void(const std::map<std::string, std::string>&)>>> eventHandlers;

    std::thread *metricsThread;
    std::thread *healthThread;
    std::thread *maintenanceThread;
    std::atomic<bool> backgroundThreadsRunning;

    std::function<void(EngineState, EngineState)> stateChangeCallback;
    std::function<void(const std::string&, int)> errorCallback;
    std::function<void(const std::string&)> warningCallback;

    bool initializeSubsystems();
    bool initializeMemoryManager();
    bool initializeHooking();
    bool initializeCrashReporter();
    bool initializeScriptEngine();
    bool initializeAnalytics();
    bool initializeRemoteControl();
    bool initializePersistence();
    bool initializeEncryption();
    bool initializeDebugger();
    bool initializeLogging();

    void shutdownSubsystems();
    void shutdownMemoryManager();
    void shutdownHooking();
    void shutdownCrashReporter();
    void shutdownScriptEngine();
    void shutdownAnalytics();
    void shutdownRemoteControl();
    void shutdownPersistence();
    void shutdownEncryption();
    void shutdownDebugger();
    void shutdownLogging();

    void collectMetrics();
    void metricsLoop();
    void healthCheckLoop();
    void maintenanceLoop();

    void setState(EngineState newState);
    void handleError(const std::string &error, int code);
    void handleWarning(const std::string &warning);

    bool createDirectories();
    bool validateConfig(const EngineConfig &config) const;
    bool lockInstance();
    void unlockInstance();

    std::string getTimestamp() const;
    void logEngineEvent(const std::string &event, const std::string &details);
};

#endif
