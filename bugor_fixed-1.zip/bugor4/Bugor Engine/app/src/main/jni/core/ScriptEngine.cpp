#include "ScriptEngine.h"
#include <cmath>
#include <thread>
#include <chrono>
#include <sstream>
#include <algorithm>
#include <cctype>
#include <android/log.h>
#include "../memory/MemoryManager.h"
#include "../core/BugorEngine.h"

namespace ScriptEngine {

namespace {
    const int64_t BREAK_SENTINEL = INT64_MIN;
    const int64_t CONTINUE_SENTINEL = INT64_MIN + 1;

    struct FuncDef {
        std::vector<std::string> paramNames;
        int bodyStart;
        int bodyEnd;
    };

    std::map<std::string, FuncDef> g_userFuncs;

    bool IsTruthy(const ScriptValue& v) {
        switch (v.type) {
            case ScriptValueType::NIL: return false;
            case ScriptValueType::BOOLEAN: return v.boolVal;
            case ScriptValueType::INTEGER: return v.intVal != 0;
            case ScriptValueType::FLOAT: return v.floatVal != 0.0f;
            case ScriptValueType::STRING: return !v.strVal.empty();
            case ScriptValueType::ARRAY: return !v.arrayVal.empty();
            case ScriptValueType::MAP: return !v.mapVal.empty();
            case ScriptValueType::NATIVE_FUNC: return true;
        }
        return false;
    }

    int GetPrecedence(const std::string& op) {
        if (op == "=") return 1;
        if (op == "||") return 2;
        if (op == "&&") return 3;
        if (op == "==" || op == "!=") return 4;
        if (op == "<" || op == ">" || op == "<=" || op == ">=") return 5;
        if (op == "+" || op == "-") return 6;
        if (op == "*" || op == "/" || op == "%") return 7;
        return 0;
    }

    bool IsRightAssociative(const std::string& op) {
        return op == "=";
    }

    ScriptValue EvalBinary(const ScriptValue& left, const std::string& op, const ScriptValue& right) {
        if (op == "=") {
            return right;
        }

        bool leftNum = left.type == ScriptValueType::INTEGER || left.type == ScriptValueType::FLOAT;
        bool rightNum = right.type == ScriptValueType::INTEGER || right.type == ScriptValueType::FLOAT;

        if (op == "+" && left.type == ScriptValueType::STRING && right.type == ScriptValueType::STRING) {
            return ScriptValue(left.strVal + right.strVal);
        }

        if (op == "+" && leftNum && rightNum) {
            bool isFloat = left.type == ScriptValueType::FLOAT || right.type == ScriptValueType::FLOAT;
            if (isFloat) {
                float l = left.type == ScriptValueType::FLOAT ? left.floatVal : (float)left.intVal;
                float r = right.type == ScriptValueType::FLOAT ? right.floatVal : (float)right.intVal;
                return ScriptValue(l + r);
            }
            return ScriptValue(left.intVal + right.intVal);
        }

        if (op == "-" && leftNum && rightNum) {
            bool isFloat = left.type == ScriptValueType::FLOAT || right.type == ScriptValueType::FLOAT;
            if (isFloat) {
                float l = left.type == ScriptValueType::FLOAT ? left.floatVal : (float)left.intVal;
                float r = right.type == ScriptValueType::FLOAT ? right.floatVal : (float)right.intVal;
                return ScriptValue(l - r);
            }
            return ScriptValue(left.intVal - right.intVal);
        }

        if (op == "*" && leftNum && rightNum) {
            bool isFloat = left.type == ScriptValueType::FLOAT || right.type == ScriptValueType::FLOAT;
            if (isFloat) {
                float l = left.type == ScriptValueType::FLOAT ? left.floatVal : (float)left.intVal;
                float r = right.type == ScriptValueType::FLOAT ? right.floatVal : (float)right.intVal;
                return ScriptValue(l * r);
            }
            return ScriptValue(left.intVal * right.intVal);
        }

        if (op == "/" && leftNum && rightNum) {
            float l = left.type == ScriptValueType::FLOAT ? left.floatVal : (float)left.intVal;
            float r = right.type == ScriptValueType::FLOAT ? right.floatVal : (float)right.intVal;
            if (r == 0.0f) return ScriptValue();
            return ScriptValue(l / r);
        }

        if (op == "%" && left.type == ScriptValueType::INTEGER && right.type == ScriptValueType::INTEGER) {
            if (right.intVal == 0) return ScriptValue();
            return ScriptValue(left.intVal % right.intVal);
        }

        if (op == "<" && leftNum && rightNum) {
            float l = left.type == ScriptValueType::FLOAT ? left.floatVal : (float)left.intVal;
            float r = right.type == ScriptValueType::FLOAT ? right.floatVal : (float)right.intVal;
            return ScriptValue(l < r);
        }

        if (op == ">" && leftNum && rightNum) {
            float l = left.type == ScriptValueType::FLOAT ? left.floatVal : (float)left.intVal;
            float r = right.type == ScriptValueType::FLOAT ? right.floatVal : (float)right.intVal;
            return ScriptValue(l > r);
        }

        if (op == "<=" && leftNum && rightNum) {
            float l = left.type == ScriptValueType::FLOAT ? left.floatVal : (float)left.intVal;
            float r = right.type == ScriptValueType::FLOAT ? right.floatVal : (float)right.intVal;
            return ScriptValue(l <= r);
        }

        if (op == ">=" && leftNum && rightNum) {
            float l = left.type == ScriptValueType::FLOAT ? left.floatVal : (float)left.intVal;
            float r = right.type == ScriptValueType::FLOAT ? right.floatVal : (float)right.intVal;
            return ScriptValue(l >= r);
        }

        if (op == "==") {
            if (left.type == ScriptValueType::NIL && right.type == ScriptValueType::NIL) return ScriptValue(true);
            if (left.type == ScriptValueType::INTEGER && right.type == ScriptValueType::INTEGER) return ScriptValue(left.intVal == right.intVal);
            if (left.type == ScriptValueType::FLOAT && right.type == ScriptValueType::FLOAT) return ScriptValue(left.floatVal == right.floatVal);
            if (left.type == ScriptValueType::BOOLEAN && right.type == ScriptValueType::BOOLEAN) return ScriptValue(left.boolVal == right.boolVal);
            if (left.type == ScriptValueType::STRING && right.type == ScriptValueType::STRING) return ScriptValue(left.strVal == right.strVal);
            if (leftNum && rightNum) {
                float l = left.type == ScriptValueType::FLOAT ? left.floatVal : (float)left.intVal;
                float r = right.type == ScriptValueType::FLOAT ? right.floatVal : (float)right.intVal;
                return ScriptValue(l == r);
            }
            return ScriptValue(false);
        }

        if (op == "!=") {
            ScriptValue eq = EvalBinary(left, "==", right);
            return ScriptValue(!eq.boolVal);
        }

        if (op == "&&") {
            return ScriptValue(IsTruthy(left) && IsTruthy(right));
        }

        if (op == "||") {
            return ScriptValue(IsTruthy(left) || IsTruthy(right));
        }

        return ScriptValue();
    }

    std::string EscapeString(const std::string& s) {
        std::string out;
        out += '"';
        for (size_t i = 0; i < s.size(); i++) {
            char c = s[i];
            switch (c) {
                case '\n': out += "\\n"; break;
                case '\t': out += "\\t"; break;
                case '\r': out += "\\r"; break;
                case '\\': out += "\\\\"; break;
                case '"': out += "\\\""; break;
                default: out += c;
            }
        }
        out += '"';
        return out;
    }
}

std::string ScriptValue::ToString() const {
    switch (type) {
        case ScriptValueType::NIL:
            return "nil";
        case ScriptValueType::INTEGER:
            return std::to_string(intVal);
        case ScriptValueType::FLOAT: {
            std::ostringstream ss;
            ss << floatVal;
            return ss.str();
        }
        case ScriptValueType::BOOLEAN:
            return boolVal ? "true" : "false";
        case ScriptValueType::STRING:
            return strVal;
        case ScriptValueType::ARRAY: {
            std::string out = "[";
            for (size_t i = 0; i < arrayVal.size(); i++) {
                if (i > 0) out += ", ";
                out += arrayVal[i].ToString();
            }
            out += "]";
            return out;
        }
        case ScriptValueType::MAP: {
            std::string out = "{";
            bool first = true;
            for (auto& kv : mapVal) {
                if (!first) out += ", ";
                first = false;
                out += EscapeString(kv.first);
                out += ": ";
                out += kv.second.ToString();
            }
            out += "}";
            return out;
        }
        case ScriptValueType::NATIVE_FUNC:
            return "<native>";
    }
    return "nil";
}

ScriptValue& ScriptContext::Get(const std::string& name) {
    auto it = locals.find(name);
    if (it != locals.end()) return it->second;
    it = globals.find(name);
    if (it != globals.end()) return it->second;
    if (parent) return parent->Get(name);
    globals[name] = ScriptValue();
    return globals[name];
}

void ScriptContext::Set(const std::string& name, const ScriptValue& val) {
    if (locals.find(name) != locals.end()) {
        locals[name] = val;
    } else if (globals.find(name) != globals.end()) {
        globals[name] = val;
    } else if (parent) {
        parent->Set(name, val);
    } else {
        globals[name] = val;
    }
}

void ScriptContext::Return(const ScriptValue& val) {
    returnStack.push_back(val);
}

std::vector<std::string> ScriptEngine::Tokenize(const std::string& src) {
    std::vector<std::string> toks;
    size_t i = 0;
    int line = 1;

    while (i < src.size()) {
        char c = src[i];

        if (c == ' ' || c == '\t' || c == '\r') { i++; continue; }
        if (c == '\n') { i++; line++; continue; }

        if (c == '/' && i + 1 < src.size() && src[i + 1] == '/') {
            i += 2;
            while (i < src.size() && src[i] != '\n') i++;
            continue;
        }

        if (c == '/' && i + 1 < src.size() && src[i + 1] == '*') {
            i += 2;
            while (i + 1 < src.size() && !(src[i] == '*' && src[i + 1] == '/')) {
                if (src[i] == '\n') line++;
                i++;
            }
            if (i + 1 < src.size()) i += 2;
            continue;
        }

        if (c == '"') {
            std::string tok;
            tok += '"';
            i++;
            while (i < src.size() && src[i] != '"') {
                if (src[i] == '\\' && i + 1 < src.size()) {
                    char n = src[i + 1];
                    switch (n) {
                        case 'n': tok += '\n'; break;
                        case 't': tok += '\t'; break;
                        case 'r': tok += '\r'; break;
                        case '0': tok += '\0'; break;
                        case '\\': tok += '\\'; break;
                        case '"': tok += '"'; break;
                        default: tok += n; break;
                    }
                    i += 2;
                } else {
                    if (src[i] == '\n') line++;
                    tok += src[i];
                    i++;
                }
            }
            if (i < src.size()) { tok += '"'; i++; }
            toks.push_back(tok);
            continue;
        }

        if (std::isalpha(c) || c == '_') {
            std::string id;
            while (i < src.size() && (std::isalnum(src[i]) || src[i] == '_')) {
                id += src[i];
                i++;
            }
            toks.push_back(id);
            continue;
        }

        if (std::isdigit(c) || (c == '.' && i + 1 < src.size() && std::isdigit(src[i + 1]))) {
            std::string num;
            bool isFloat = false;
            while (i < src.size()) {
                char nc = src[i];
                if (std::isdigit(nc)) {
                    num += nc; i++;
                } else if (nc == '.' && !isFloat) {
                    isFloat = true;
                    num += nc; i++;
                } else if ((nc == 'e' || nc == 'E') && i + 1 < src.size()) {
                    isFloat = true;
                    num += nc; i++;
                    if (src[i] == '+' || src[i] == '-') { num += src[i]; i++; }
                } else {
                    break;
                }
            }
            toks.push_back(num);
            continue;
        }

        std::string two = std::string() + c + (i + 1 < src.size() ? src[i + 1] : '\0');
        if (two == "==" || two == "!=" || two == "<=" || two == ">=" || two == "&&" || two == "||") {
            toks.push_back(two);
            i += 2;
            continue;
        }

        toks.push_back(std::string(1, c));
        i++;
    }

    return toks;
}

std::string ScriptEngine::Peek() {
    if (pos >= (int)tokens.size()) return "";
    return tokens[pos];
}

std::string ScriptEngine::Next() {
    if (pos >= (int)tokens.size()) return "";
    return tokens[pos++];
}

bool ScriptEngine::Match(const std::string& expected) {
    if (Peek() == expected) {
        Next();
        return true;
    }
    return false;
}

void ScriptEngine::Expect(const std::string& expected) {
    if (Peek() != expected) {
        Error("Expected '" + expected + "' but got '" + Peek() + "'");
    } else {
        Next();
    }
}

void ScriptEngine::Error(const std::string& msg) {
    if (!hasError) {
        hasError = true;
        errorMsg = msg;
        errorLine = 0;
    }
}

ScriptValue ScriptEngine::ParsePrimary() {
    if (hasError) return ScriptValue();

    if (Match("(")) {
        ScriptValue val = ParseExpression();
        Expect(")");
        return val;
    }

    if (Match("[")) {
        ScriptValue val;
        val.type = ScriptValueType::ARRAY;
        if (!Match("]")) {
            val.arrayVal.push_back(ParseExpression());
            while (Match(",")) {
                val.arrayVal.push_back(ParseExpression());
            }
            Expect("]");
        }
        return val;
    }

    if (Match("{")) {
        ScriptValue val;
        val.type = ScriptValueType::MAP;
        if (!Match("}")) {
            ScriptValue key = ParseExpression();
            Expect(":");
            ScriptValue value = ParseExpression();
            val.mapVal[key.ToString()] = value;
            while (Match(",")) {
                key = ParseExpression();
                Expect(":");
                value = ParseExpression();
                val.mapVal[key.ToString()] = value;
            }
            Expect("}");
        }
        return val;
    }

    if (Match("true")) return ScriptValue(true);
    if (Match("false")) return ScriptValue(false);
    if (Match("nil")) return ScriptValue();

    if (Peek().size() > 0 && Peek()[0] == '"') {
        std::string s = Next();
        ScriptValue val;
        val.type = ScriptValueType::STRING;
        val.strVal = s.substr(1, s.size() - 2);
        return val;
    }

    if (Peek().size() > 0 && (std::isdigit((unsigned char)Peek()[0]) || (Peek()[0] == '.' && Peek().size() > 1))) {
        std::string num = Next();
        if (num.find('.') != std::string::npos || num.find('e') != std::string::npos || num.find('E') != std::string::npos) {
            return ScriptValue(std::stof(num));
        }
        return ScriptValue((int64_t)std::stoll(num));
    }

    if (Peek().size() > 0 && (std::isalpha((unsigned char)Peek()[0]) || Peek()[0] == '_')) {
        std::string name = Next();
        if (Peek() == "(") {
            return ParseFunctionCall(name);
        }
        return rootCtx.Get(name);
    }

    Error("Unexpected token: " + Peek());
    return ScriptValue();
}

std::vector<ScriptValue> ScriptEngine::ParseArguments() {
    std::vector<ScriptValue> args;
    Expect("(");
    if (!Match(")")) {
        args.push_back(ParseExpression());
        while (Match(",")) {
            args.push_back(ParseExpression());
        }
        Expect(")");
    }
    return args;
}

ScriptValue ScriptEngine::ParseFunctionCall(const std::string& name) {
    ScriptValue func = rootCtx.Get(name);
    if (func.type == ScriptValueType::NATIVE_FUNC && func.nativeFunc) {
        std::vector<ScriptValue> args = ParseArguments();
        return func.nativeFunc(args);
    }
    auto bit = builtins.find(name);
    if (bit != builtins.end() && bit->second.type == ScriptValueType::NATIVE_FUNC && bit->second.nativeFunc) {
        std::vector<ScriptValue> args = ParseArguments();
        return bit->second.nativeFunc(args);
    }
    Error("Call to undefined function: " + name);
    return ScriptValue();
}

ScriptValue ScriptEngine::ParseExpression() {
    if (hasError) return ScriptValue();

    int exprStartPos = pos;

    ScriptValue left;
    if (Peek() == "-" || Peek() == "!") {
        std::string op = Next();
        left = ParseExpression();
        if (op == "-") {
            if (left.type == ScriptValueType::INTEGER) left = ScriptValue(-left.intVal);
            else if (left.type == ScriptValueType::FLOAT) left = ScriptValue(-left.floatVal);
            else Error("Bad unary operand");
        } else {
            left = ScriptValue(!IsTruthy(left));
        }
    } else {
        left = ParsePrimary();
    }

    while (true) {
        if (Peek() == "(") {
            if (left.type == ScriptValueType::NATIVE_FUNC && left.nativeFunc) {
                std::vector<ScriptValue> args = ParseArguments();
                left = left.nativeFunc(args);
            } else {
                Error("Not callable");
                return ScriptValue();
            }
        } else if (Peek() == "[") {
            Next();
            ScriptValue index = ParseExpression();
            Expect("]");
            if (left.type == ScriptValueType::ARRAY && index.type == ScriptValueType::INTEGER) {
                int idx = (int)index.intVal;
                if (idx >= 0 && idx < (int)left.arrayVal.size()) {
                    left = left.arrayVal[idx];
                } else {
                    Error("Array index out of bounds");
                    return ScriptValue();
                }
            } else if (left.type == ScriptValueType::MAP && index.type == ScriptValueType::STRING) {
                auto it = left.mapVal.find(index.strVal);
                if (it != left.mapVal.end()) {
                    left = it->second;
                } else {
                    left = ScriptValue();
                }
            } else if (left.type == ScriptValueType::STRING && index.type == ScriptValueType::INTEGER) {
                int idx = (int)index.intVal;
                if (idx >= 0 && idx < (int)left.strVal.size()) {
                    left = ScriptValue(std::string(1, left.strVal[idx]));
                } else {
                    Error("String index out of bounds");
                    return ScriptValue();
                }
            } else {
                Error("Cannot index non-indexable type");
                return ScriptValue();
            }
        } else if (Peek() == ".") {
            Next();
            std::string member = Next();
            if (Peek() == "(") {
                if (left.type == ScriptValueType::MAP) {
                    auto it = left.mapVal.find(member);
                    if (it != left.mapVal.end() && it->second.type == ScriptValueType::NATIVE_FUNC && it->second.nativeFunc) {
                        std::vector<ScriptValue> args = ParseArguments();
                        left = it->second.nativeFunc(args);
                    } else {
                        Error("Method not found: " + member);
                        return ScriptValue();
                    }
                } else {
                    Error("Cannot call method on non-map type");
                    return ScriptValue();
                }
            } else {
                if (left.type == ScriptValueType::MAP) {
                    auto it = left.mapVal.find(member);
                    if (it != left.mapVal.end()) {
                        left = it->second;
                    } else {
                        left = ScriptValue();
                    }
                } else {
                    Error("Cannot access property on non-map type");
                    return ScriptValue();
                }
            }
        } else {
            break;
        }
    }

    while (true) {
        std::string op = Peek();
        int prec = GetPrecedence(op);
        if (prec == 0) break;

        if (op == "=") {
            Next();
            ScriptValue val = ParseExpression();
            if (exprStartPos < (int)tokens.size()) {
                std::string aname = tokens[exprStartPos];
                if (!aname.empty() && (std::isalpha((unsigned char)aname[0]) || aname[0] == '_')) {
                    rootCtx.Set(aname, val);
                }
            }
            left = val;
            continue;
        }

        Next();
        ScriptValue right = ParseExpression();

        while (true) {
            if (Peek() == "(") {
                if (right.type == ScriptValueType::NATIVE_FUNC && right.nativeFunc) {
                    std::vector<ScriptValue> args = ParseArguments();
                    right = right.nativeFunc(args);
                } else {
                    break;
                }
            } else if (Peek() == "[") {
                Next();
                ScriptValue idx = ParseExpression();
                Expect("]");
                if (right.type == ScriptValueType::ARRAY && idx.type == ScriptValueType::INTEGER) {
                    int ii = (int)idx.intVal;
                    if (ii >= 0 && ii < (int)right.arrayVal.size()) {
                        right = right.arrayVal[ii];
                    } else {
                        Error("Index out of bounds");
                        return ScriptValue();
                    }
                } else if (right.type == ScriptValueType::MAP && idx.type == ScriptValueType::STRING) {
                    auto it2 = right.mapVal.find(idx.strVal);
                    if (it2 != right.mapVal.end()) right = it2->second;
                    else right = ScriptValue();
                } else {
                    Error("Bad index");
                    return ScriptValue();
                }
            } else if (Peek() == ".") {
                Next();
                std::string member = Next();
                if (right.type == ScriptValueType::MAP) {
                    auto it2 = right.mapVal.find(member);
                    if (it2 != right.mapVal.end()) right = it2->second;
                    else right = ScriptValue();
                } else {
                    Error("Bad member access");
                    return ScriptValue();
                }
            } else {
                break;
            }
        }

        left = EvalBinary(left, op, right);
    }

    return left;
}

ScriptValue ScriptEngine::ParseStatement() {
    if (hasError) return ScriptValue();

    if (Peek() == "var") {
        Next();
        std::string name = Next();
        if (Match("=")) {
            ScriptValue val = ParseExpression();
            rootCtx.locals[name] = val;
        } else {
            rootCtx.locals[name] = ScriptValue();
        }
        if (Peek() == ";") Next();
        return ScriptValue();
    }

    if (Peek() == "if") return ParseIf();
    if (Peek() == "while") return ParseWhile();
    if (Peek() == "for") return ParseFor();
    if (Peek() == "function") return ParseFunctionDef();

    if (Peek() == "return") {
        Next();
        ScriptValue val;
        if (Peek() != ";" && Peek() != "}" && Peek() != "") {
            val = ParseExpression();
        }
        if (Peek() == ";") Next();
        rootCtx.Return(val);
        return val;
    }

    if (Peek() == "break") {
        Next();
        if (Peek() == ";") Next();
        ScriptValue s;
        s.type = ScriptValueType::INTEGER;
        s.intVal = BREAK_SENTINEL;
        return s;
    }

    if (Peek() == "continue") {
        Next();
        if (Peek() == ";") Next();
        ScriptValue s;
        s.type = ScriptValueType::INTEGER;
        s.intVal = CONTINUE_SENTINEL;
        return s;
    }

    if (Peek() == "{") return ParseBlock();

    if (Peek() == ";") {
        Next();
        return ScriptValue();
    }

    ScriptValue expr = ParseExpression();
    if (Peek() == ";") Next();
    return expr;
}

ScriptValue ScriptEngine::ParseBlock() {
    Expect("{");
    ScriptValue result;
    while (Peek() != "}" && Peek() != "" && !hasError) {
        result = ParseStatement();
        if (!rootCtx.returnStack.empty()) return result;
        if (result.type == ScriptValueType::INTEGER && (result.intVal == BREAK_SENTINEL || result.intVal == CONTINUE_SENTINEL)) {
            return result;
        }
    }
    Expect("}");
    return result;
}

int FindBlockEndFrom(const std::vector<std::string>& toks, int start) {
    if (start >= (int)toks.size() || toks[start] != "{") return start;
    int depth = 1;
    int i = start + 1;
    while (i < (int)toks.size() && depth > 0) {
        if (toks[i] == "{") depth++;
        else if (toks[i] == "}") depth--;
        if (depth > 0) i++;
    }
    return i + 1;
}

int FindStatementEndFrom(const std::vector<std::string>& toks, int start) {
    if (start >= (int)toks.size()) return start;
    if (toks[start] == "{") return FindBlockEndFrom(toks, start);
    int depth = 0;
    int i = start;
    while (i < (int)toks.size()) {
        if (toks[i] == "{" || toks[i] == "(" || toks[i] == "[") depth++;
        else if (toks[i] == "}" || toks[i] == ")" || toks[i] == "]") {
            depth--;
            if (depth < 0) break;
        } else if (toks[i] == ";" && depth == 0) {
            return i + 1;
        }
        i++;
    }
    return i;
}

ScriptValue ScriptEngine::ParseIf() {
    Expect("if");
    Expect("(");
    ScriptValue cond = ParseExpression();
    Expect(")");

    int ifStart = pos;
    int ifEnd;
    bool ifIsBlock = (Peek() == "{");
    if (ifIsBlock) {
        ifEnd = FindBlockEndFrom(tokens, pos);
    } else if (Peek() == "if") {
        int saved = pos;
        pos++;
        Expect("(");
        int depth = 1;
        while (pos < (int)tokens.size() && depth > 0) {
            if (tokens[pos] == "(") depth++;
            else if (tokens[pos] == ")") depth--;
            pos++;
        }
        int bodyEnd = FindStatementEndFrom(tokens, pos);
        if (pos < (int)tokens.size() && tokens[pos] == "else") {
            bodyEnd = FindStatementEndFrom(tokens, pos + 1);
        }
        ifEnd = bodyEnd;
        pos = saved;
        ifEnd = FindStatementEndFrom(tokens, pos);
    } else {
        ifEnd = FindStatementEndFrom(tokens, pos);
    }

    bool hasElse = false;
    int elsePos = ifEnd;
    if (elsePos < (int)tokens.size() && tokens[elsePos] == "else") {
        hasElse = true;
    }

    ScriptValue result;
    bool truthy = IsTruthy(cond);

    if (truthy) {
        result = ParseStatement();
        if (result.type == ScriptValueType::INTEGER && (result.intVal == BREAK_SENTINEL || result.intVal == CONTINUE_SENTINEL)) {
            if (hasElse) {
                pos = elsePos + 1;
                if (Peek() == "{") pos = FindBlockEndFrom(tokens, pos);
                else if (Peek() == "if") {
                    pos++;
                    Expect("(");
                    int d = 1;
                    while (pos < (int)tokens.size() && d > 0) {
                        if (tokens[pos] == "(") d++;
                        else if (tokens[pos] == ")") d--;
                        pos++;
                    }
                    int be = FindStatementEndFrom(tokens, pos);
                    if (pos < (int)tokens.size() && tokens[pos] == "else") {
                        be = FindStatementEndFrom(tokens, pos + 1);
                    }
                    pos = be;
                } else pos = FindStatementEndFrom(tokens, pos);
            }
            return result;
        }
        if (hasElse) {
            pos = elsePos + 1;
            if (Peek() == "{") pos = FindBlockEndFrom(tokens, pos);
            else if (Peek() == "if") {
                pos++;
                Expect("(");
                int d = 1;
                while (pos < (int)tokens.size() && d > 0) {
                    if (tokens[pos] == "(") d++;
                    else if (tokens[pos] == ")") d--;
                    pos++;
                }
                int be = FindStatementEndFrom(tokens, pos);
                if (pos < (int)tokens.size() && tokens[pos] == "else") {
                    be = FindStatementEndFrom(tokens, pos + 1);
                }
                pos = be;
            } else pos = FindStatementEndFrom(tokens, pos);
        }
    } else {
        pos = ifEnd;
        if (hasElse) {
            pos = elsePos + 1;
            if (Peek() == "if") {
                result = ParseIf();
            } else {
                result = ParseStatement();
            }
        }
    }

    return result;
}

ScriptValue ScriptEngine::ParseWhile() {
    Expect("while");
    Expect("(");
    int condStart = pos;
    int condParenDepth = 1;
    while (pos < (int)tokens.size() && condParenDepth > 0) {
        if (tokens[pos] == "(") condParenDepth++;
        else if (tokens[pos] == ")") condParenDepth--;
        if (condParenDepth > 0) pos++;
    }
    pos++;
    int bodyStart = pos;
    int bodyEnd;
    if (Peek() == "{") bodyEnd = FindBlockEndFrom(tokens, pos);
    else bodyEnd = FindStatementEndFrom(tokens, pos);

    pos = condStart;
    ScriptValue result;
    while (true) {
        condParenDepth = 1;
        pos = condStart;
        ScriptValue cond = ParseExpression();
        Expect(")");
        if (!IsTruthy(cond)) break;
        pos = bodyStart;
        result = (Peek() == "{") ? ParseBlock() : ParseStatement();
        if (result.type == ScriptValueType::INTEGER) {
            if (result.intVal == BREAK_SENTINEL) break;
            if (result.intVal == CONTINUE_SENTINEL) continue;
        }
        if (!rootCtx.returnStack.empty()) return result;
    }
    pos = bodyEnd;
    return ScriptValue();
}

ScriptValue ScriptEngine::ParseFor() {
    Expect("for");
    Expect("(");

    if (Match("var")) {
        std::string name = Next();
        if (Match("=")) rootCtx.locals[name] = ParseExpression();
        else rootCtx.locals[name] = ScriptValue();
    } else if (Peek() != ";") {
        ParseExpression();
    }
    Expect(";");

    int condStart = pos;
    int depth = 0;
    while (pos < (int)tokens.size()) {
        if (tokens[pos] == "(" || tokens[pos] == "[" || tokens[pos] == "{") depth++;
        else if (tokens[pos] == ")" || tokens[pos] == "]" || tokens[pos] == "}") depth--;
        if (tokens[pos] == ";" && depth == 0) break;
        pos++;
    }
    int condEnd = pos;
    Expect(";");

    int incStart = pos;
    depth = 0;
    while (pos < (int)tokens.size()) {
        if (tokens[pos] == "(" || tokens[pos] == "[" || tokens[pos] == "{") depth++;
        else if (tokens[pos] == ")" || tokens[pos] == "]" || tokens[pos] == "}") depth--;
        if (tokens[pos] == ")" && depth == 0) break;
        pos++;
    }
    int incEnd = pos;
    Expect(")");

    int bodyStart = pos;
    int bodyEnd = (Peek() == "{") ? FindBlockEndFrom(tokens, pos) : FindStatementEndFrom(tokens, pos);

    ScriptValue result;
    while (true) {
        if (condStart < condEnd) {
            pos = condStart;
            ScriptValue cond = ParseExpression();
            Expect(";");
            if (!IsTruthy(cond)) break;
        }

        pos = bodyStart;
        result = (Peek() == "{") ? ParseBlock() : ParseStatement();

        if (result.type == ScriptValueType::INTEGER) {
            if (result.intVal == BREAK_SENTINEL) break;
        }
        if (!rootCtx.returnStack.empty()) {
            if (incStart < incEnd) {
                int sv = pos;
                pos = incStart;
                ParseExpression();
                pos = sv;
            }
            return result;
        }

        if (incStart < incEnd) {
            pos = incStart;
            ParseExpression();
        }

        if (result.type == ScriptValueType::INTEGER && result.intVal == CONTINUE_SENTINEL) continue;
    }

    pos = bodyEnd;
    return ScriptValue();
}

ScriptValue ScriptEngine::ParseFunctionDef() {
    Expect("function");
    std::string name = Next();
    Expect("(");
    std::vector<std::string> params;
    if (!Match(")")) {
        params.push_back(Next());
        while (Match(",")) {
            params.push_back(Next());
        }
        Expect(")");
    }
    Expect("{");

    int bodyStart = pos;
    int bodyEnd;
    int depth = 1;
    int i = pos;
    while (i < (int)tokens.size() && depth > 0) {
        if (tokens[i] == "{") depth++;
        else if (tokens[i] == "}") depth--;
        if (depth > 0) i++;
    }
    bodyEnd = i;
    pos = i + 1;

    FuncDef fd;
    fd.paramNames = params;
    fd.bodyStart = bodyStart;
    fd.bodyEnd = bodyEnd;

    g_userFuncs[name] = fd;

    rootCtx.globals[name] = ScriptValue(
        [this, name](const std::vector<ScriptValue>& args) -> ScriptValue {
            auto fit = g_userFuncs.find(name);
            if (fit == g_userFuncs.end()) return ScriptValue();
            const FuncDef& fd = fit->second;

            auto savedLocals = rootCtx.locals;
            auto savedReturnStack = rootCtx.returnStack;
            rootCtx.locals.clear();
            rootCtx.returnStack.clear();

            for (size_t i = 0; i < fd.paramNames.size() && i < args.size(); i++) {
                rootCtx.locals[fd.paramNames[i]] = args[i];
            }

            int savedPos = pos;
            pos = fd.bodyStart;
            while (pos < fd.bodyEnd && !hasError) {
                ScriptValue stmt = ParseStatement();
                if (!rootCtx.returnStack.empty()) {
                    ScriptValue ret = rootCtx.returnStack.back();
                    rootCtx.locals = savedLocals;
                    rootCtx.returnStack = savedReturnStack;
                    pos = savedPos;
                    return ret;
                }
            }

            rootCtx.locals = savedLocals;
            rootCtx.returnStack = savedReturnStack;
            pos = savedPos;
            return ScriptValue();
        }
    );

    return ScriptValue();
}

void ScriptEngine::SetupDefaultFunctions() {
    builtins["readFloat"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.empty()) return ScriptValue(0.0f);
        uintptr_t addr = (uintptr_t)(args[0].type == ScriptValueType::INTEGER ? args[0].intVal : 0);
        MemoryManager* mem = BugorEngine::getInstance().getMemoryManager();
        if (mem) return ScriptValue(mem->readFloat(addr));
        return ScriptValue(0.0f);
    });

    builtins["readInt"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.empty()) return ScriptValue(0LL);
        uintptr_t addr = (uintptr_t)(args[0].type == ScriptValueType::INTEGER ? args[0].intVal : 0);
        MemoryManager* mem = BugorEngine::getInstance().getMemoryManager();
        if (mem) return ScriptValue((int64_t)mem->readInt(addr));
        return ScriptValue(0LL);
    });

    builtins["readPtr"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.empty()) return ScriptValue(0LL);
        uintptr_t addr = (uintptr_t)(args[0].type == ScriptValueType::INTEGER ? args[0].intVal : 0);
        MemoryManager* mem = BugorEngine::getInstance().getMemoryManager();
        if (mem) return ScriptValue((int64_t)mem->readLong(addr));
        return ScriptValue(0LL);
    });

    builtins["writeFloat"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.size() < 2) return ScriptValue(false);
        uintptr_t addr = (uintptr_t)(args[0].type == ScriptValueType::INTEGER ? args[0].intVal : 0);
        float val = args[1].type == ScriptValueType::FLOAT ? args[1].floatVal : (float)args[1].intVal;
        MemoryManager* mem = BugorEngine::getInstance().getMemoryManager();
        if (mem) return ScriptValue(mem->writeFloat(addr, val));
        return ScriptValue(false);
    });

    builtins["writeInt"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.size() < 2) return ScriptValue(false);
        uintptr_t addr = (uintptr_t)(args[0].type == ScriptValueType::INTEGER ? args[0].intVal : 0);
        uint32_t val = (uint32_t)(args[1].type == ScriptValueType::INTEGER ? args[1].intVal : (int64_t)args[1].floatVal);
        MemoryManager* mem = BugorEngine::getInstance().getMemoryManager();
        if (mem) return ScriptValue(mem->writeInt(addr, val));
        return ScriptValue(false);
    });

    builtins["getModuleBase"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.empty()) return ScriptValue(0LL);
        std::string name = args[0].ToString();
        MemoryManager* mem = BugorEngine::getInstance().getMemoryManager();
        if (mem) return ScriptValue((int64_t)mem->getModuleBase(name));
        return ScriptValue(0LL);
    });

    builtins["log"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        std::string msg;
        for (size_t i = 0; i < args.size(); i++) {
            if (i > 0) msg += " ";
            msg += args[i].ToString();
        }
        __android_log_print(ANDROID_LOG_INFO, "ScriptEngine", "%s", msg.c_str());
        return ScriptValue();
    });

    builtins["sleep"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.empty()) return ScriptValue();
        int64_t ms = args[0].type == ScriptValueType::INTEGER ? args[0].intVal : (int64_t)args[0].floatVal;
        if (ms > 0) std::this_thread::sleep_for(std::chrono::milliseconds(ms));
        return ScriptValue();
    });

    builtins["sqrt"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.empty()) return ScriptValue(0.0f);
        float v = args[0].type == ScriptValueType::FLOAT ? args[0].floatVal : (float)args[0].intVal;
        return ScriptValue(std::sqrt(v));
    });

    builtins["sin"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.empty()) return ScriptValue(0.0f);
        float v = args[0].type == ScriptValueType::FLOAT ? args[0].floatVal : (float)args[0].intVal;
        return ScriptValue(std::sin(v));
    });

    builtins["cos"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.empty()) return ScriptValue(0.0f);
        float v = args[0].type == ScriptValueType::FLOAT ? args[0].floatVal : (float)args[0].intVal;
        return ScriptValue(std::cos(v));
    });

    builtins["abs"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.empty()) return ScriptValue(0LL);
        if (args[0].type == ScriptValueType::FLOAT) return ScriptValue(std::abs(args[0].floatVal));
        int64_t v = args[0].intVal;
        return ScriptValue(v < 0 ? -v : v);
    });

    builtins["type"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.empty()) return ScriptValue("nil");
        switch (args[0].type) {
            case ScriptValueType::NIL: return ScriptValue("nil");
            case ScriptValueType::INTEGER: return ScriptValue("integer");
            case ScriptValueType::FLOAT: return ScriptValue("float");
            case ScriptValueType::BOOLEAN: return ScriptValue("boolean");
            case ScriptValueType::STRING: return ScriptValue("string");
            case ScriptValueType::ARRAY: return ScriptValue("array");
            case ScriptValueType::MAP: return ScriptValue("map");
            case ScriptValueType::NATIVE_FUNC: return ScriptValue("function");
        }
        return ScriptValue("nil");
    });

    builtins["len"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.empty()) return ScriptValue(0LL);
        switch (args[0].type) {
            case ScriptValueType::STRING: return ScriptValue((int64_t)args[0].strVal.size());
            case ScriptValueType::ARRAY: return ScriptValue((int64_t)args[0].arrayVal.size());
            case ScriptValueType::MAP: return ScriptValue((int64_t)args[0].mapVal.size());
            default: return ScriptValue(0LL);
        }
    });

    builtins["toint"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.empty()) return ScriptValue(0LL);
        if (args[0].type == ScriptValueType::INTEGER) return args[0];
        if (args[0].type == ScriptValueType::FLOAT) return ScriptValue((int64_t)args[0].floatVal);
        if (args[0].type == ScriptValueType::STRING) {
            try { return ScriptValue((int64_t)std::stoll(args[0].strVal)); }
            catch (...) { return ScriptValue(0LL); }
        }
        return ScriptValue(0LL);
    });

    builtins["tofloat"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.empty()) return ScriptValue(0.0f);
        if (args[0].type == ScriptValueType::FLOAT) return args[0];
        if (args[0].type == ScriptValueType::INTEGER) return ScriptValue((float)args[0].intVal);
        if (args[0].type == ScriptValueType::STRING) {
            try { return ScriptValue(std::stof(args[0].strVal)); }
            catch (...) { return ScriptValue(0.0f); }
        }
        return ScriptValue(0.0f);
    });

    builtins["tostring"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.empty()) return ScriptValue("");
        return ScriptValue(args[0].ToString());
    });

    builtins["ceil"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.empty()) return ScriptValue(0LL);
        float v = args[0].type == ScriptValueType::FLOAT ? args[0].floatVal : (float)args[0].intVal;
        return ScriptValue((int64_t)std::ceil(v));
    });

    builtins["floor"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.empty()) return ScriptValue(0LL);
        float v = args[0].type == ScriptValueType::FLOAT ? args[0].floatVal : (float)args[0].intVal;
        return ScriptValue((int64_t)std::floor(v));
    });

    builtins["min"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.size() < 2) return ScriptValue();
        float a = args[0].type == ScriptValueType::FLOAT ? args[0].floatVal : (float)args[0].intVal;
        float b = args[1].type == ScriptValueType::FLOAT ? args[1].floatVal : (float)args[1].intVal;
        bool isFloat = args[0].type == ScriptValueType::FLOAT || args[1].type == ScriptValueType::FLOAT;
        if (isFloat) return ScriptValue(std::fmin(a, b));
        return ScriptValue((int64_t)(a < b ? a : b));
    });

    builtins["max"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.size() < 2) return ScriptValue();
        float a = args[0].type == ScriptValueType::FLOAT ? args[0].floatVal : (float)args[0].intVal;
        float b = args[1].type == ScriptValueType::FLOAT ? args[1].floatVal : (float)args[1].intVal;
        bool isFloat = args[0].type == ScriptValueType::FLOAT || args[1].type == ScriptValueType::FLOAT;
        if (isFloat) return ScriptValue(std::fmax(a, b));
        return ScriptValue((int64_t)(a > b ? a : b));
    });

    builtins["print"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        std::string msg;
        for (size_t i = 0; i < args.size(); i++) {
            if (i > 0) msg += " ";
            msg += args[i].ToString();
        }
        __android_log_print(ANDROID_LOG_INFO, "ScriptEngine", "%s", msg.c_str());
        return ScriptValue();
    });

    builtins["format"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.empty()) return ScriptValue("");
        std::string fmt = args[0].ToString();
        std::string result;
        size_t argIdx = 1;
        for (size_t i = 0; i < fmt.size(); i++) {
            if (fmt[i] == '{' && i + 1 < fmt.size() && fmt[i + 1] == '}') {
                if (argIdx < args.size()) {
                    result += args[argIdx].ToString();
                    argIdx++;
                }
                i++;
            } else {
                result += fmt[i];
            }
        }
        return ScriptValue(result);
    });

    builtins["assert"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.empty()) return ScriptValue();
        if (!IsTruthy(args[0])) {
            std::string msg = args.size() > 1 ? args[1].ToString() : "assertion failed";
            __android_log_print(ANDROID_LOG_ERROR, "ScriptEngine", "Assertion failed: %s", msg.c_str());
        }
        return ScriptValue();
    });

    builtins["clock"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        auto now = std::chrono::steady_clock::now().time_since_epoch();
        float ms = std::chrono::duration_cast<std::chrono::milliseconds>(now).count();
        return ScriptValue(ms);
    });

    builtins["readDouble"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.empty()) return ScriptValue(0.0f);
        uintptr_t addr = (uintptr_t)(args[0].type == ScriptValueType::INTEGER ? args[0].intVal : 0);
        MemoryManager* mem = BugorEngine::getInstance().getMemoryManager();
        if (mem) return ScriptValue((float)mem->readDouble(addr));
        return ScriptValue(0.0f);
    });

    builtins["writeDouble"] = ScriptValue([](const std::vector<ScriptValue>& args) -> ScriptValue {
        if (args.size() < 2) return ScriptValue(false);
        uintptr_t addr = (uintptr_t)(args[0].type == ScriptValueType::INTEGER ? args[0].intVal : 0);
        double val = args[1].type == ScriptValueType::FLOAT ? (double)args[1].floatVal : (double)args[1].intVal;
        MemoryManager* mem = BugorEngine::getInstance().getMemoryManager();
        if (mem) return ScriptValue(mem->writeDouble(addr, val));
        return ScriptValue(false);
    });
}

ScriptEngine::ScriptEngine() : pos(0), hasError(false), errorMsg(""), errorLine(0) {
    SetupDefaultFunctions();
}

bool ScriptEngine::Load(const std::string& sourceCode) {
    source = sourceCode;
    pos = 0;
    hasError = false;
    errorMsg = "";
    errorLine = 0;
    tokens = Tokenize(source);
    rootCtx.locals.clear();
    rootCtx.returnStack.clear();
    return !hasError;
}

ScriptValue ScriptEngine::Run() {
    if (hasError) return ScriptValue();
    pos = 0;
    hasError = false;
    errorMsg = "";
    errorLine = 0;
    rootCtx.locals.clear();
    rootCtx.returnStack.clear();
    rootCtx.parent = nullptr;

    ScriptValue result;
    while (pos < (int)tokens.size() && !hasError) {
        result = ParseStatement();
        if (!rootCtx.returnStack.empty()) {
            ScriptValue ret = rootCtx.returnStack.back();
            rootCtx.returnStack.clear();
            return ret;
        }
    }
    return result;
}

void ScriptEngine::RegisterFunction(const std::string& name, std::function<ScriptValue(const std::vector<ScriptValue>&)> fn) {
    builtins[name] = ScriptValue(fn);
}

}
