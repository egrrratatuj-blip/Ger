#include "core/NetworkLayer.h"
#include <cstring>
#include <algorithm>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <cerrno>
#include <cstdio>

namespace NetworkLayer {

static const uint32_t MAGIC_NUMBER = 0x42475200;

static const uint32_t CRC32_TABLE[256] = {
    0x00000000, 0x77073096, 0xEE0E612C, 0x990951BA,
    0x076DC419, 0x706AF48F, 0xE963A535, 0x9E6495A3,
    0x0EDB8832, 0x79DCB8A4, 0xE0D5E91E, 0x97D2D988,
    0x09B64C2B, 0x7EB17CBD, 0xE7B82D07, 0x90BF1D91,
    0x1DB71064, 0x6AB020F2, 0xF3B97148, 0x84BE41DE,
    0x1ADAD47D, 0x6DDDE4EB, 0xF4D4B551, 0x83D385C7,
    0x136C9856, 0x646BA8C0, 0xFD62F97A, 0x8A65C9EC,
    0x14015C4F, 0x63066CD9, 0xFA0F3D63, 0x8D080DF5,
    0x3B6E20C8, 0x4C69105E, 0xD56041E4, 0xA2677172,
    0x3C03E4D1, 0x4B04D447, 0xD20D85FD, 0xA50AB56B,
    0x35B5A8FA, 0x42B2986C, 0xDBBBC9D6, 0xACBCF940,
    0x32D86CE3, 0x45DF5C75, 0xDCD60DCF, 0xABD13D59,
    0x26D930AC, 0x51DE003A, 0xC8D75180, 0xBFD06116,
    0x21B4F4B5, 0x56B3C423, 0xCFBA9599, 0xB8BDA50F,
    0x2802B89E, 0x5F058808, 0xC60CD9B2, 0xB10BE924,
    0x2F6F7C87, 0x58684C11, 0xC1611DAB, 0xB6662D3D,
    0x76DC4190, 0x01DB7106, 0x98D220BC, 0xEFD5102A,
    0x71B18589, 0x06B6B51F, 0x9FBFE4A5, 0xE8B8D433,
    0x7807C9A2, 0x0F00F934, 0x9609A88E, 0xE10E9818,
    0x7F6A0DBB, 0x086D3D2D, 0x91646C97, 0xE6635C01,
    0x6B6B51F4, 0x1C6C6162, 0x856530D8, 0xF262004E,
    0x6C0695ED, 0x1B01A57B, 0x8208F4C1, 0xF50FC457,
    0x65B0D9C6, 0x12B7E950, 0x8BBEB8EA, 0xFCB9887C,
    0x62DD1DDF, 0x15DA2D49, 0x8CD37CF3, 0xFBD44C65,
    0x4DB26158, 0x3AB551CE, 0xA3BC0074, 0xD4BB30E2,
    0x4ADFA541, 0x3DD895D7, 0xA4D1C46D, 0xD3D6F4FB,
    0x4369E96A, 0x346ED9FC, 0xAD678846, 0xDA60B8D0,
    0x44042D73, 0x33031DE5, 0xAA0A4C5F, 0xDD0D7CC9,
    0x5005713C, 0x270241AA, 0xBE0B1010, 0xC90C2086,
    0x5768B525, 0x206F85B3, 0xB966D409, 0xCE61E49F,
    0x5EDEF90E, 0x29D9C998, 0xB0D09822, 0xC7D7A8B4,
    0x59B33D17, 0x2EB40D81, 0xB7BD5C3B, 0xC0BA6CAD,
    0xEDB88320, 0x9ABFB3B6, 0x03B6E20C, 0x74B1D29A,
    0xEAD54739, 0x9DD277AF, 0x04DB2615, 0x73DC1683,
    0xE3630B12, 0x94643B84, 0x0D6D6A3E, 0x7A6A5AA8,
    0xE40ECF0B, 0x9309FF9D, 0x0A00AE27, 0x7D079EB1,
    0xF00F9344, 0x8708A3D2, 0x1E01F268, 0x6906C2FE,
    0xF762575D, 0x806567CB, 0x196C3671, 0x6E6B06E7,
    0xFED41B76, 0x89D32BE0, 0x10DA7A5A, 0x67DD4ACC,
    0xF9B9DF6F, 0x8EBEEFF9, 0x17B7BE43, 0x60B08ED5,
    0xD6D6A3E8, 0xA1D1937E, 0x38D8C2C4, 0x4FDFF252,
    0xD1BB67F1, 0xA6BC5767, 0x3FB506DD, 0x48B2364B,
    0xD80D2BDA, 0xAF0A1B4C, 0x36034AF6, 0x41047A60,
    0xDF60EFC3, 0xA867DF55, 0x316E8EEF, 0x4669BE79,
    0xCB61B38C, 0xBC66831A, 0x256FD2A0, 0x5268E236,
    0xCC0C7795, 0xBB0B4703, 0x220216B9, 0x5505262F,
    0xC5BA3BBE, 0xB2BD0B28, 0x2BB45A92, 0x5CB36A04,
    0xC2D7FFA7, 0xB5D0CF31, 0x2CD99E8B, 0x5BDEAE1D,
    0x9B64C2B0, 0xEC63F226, 0x756AA39C, 0x026D930A,
    0x9C0906A9, 0xEB0E363F, 0x72076785, 0x05005713,
    0x95BF4A82, 0xE2B87A14, 0x7BB12BAE, 0x0CB61B38,
    0x92D28E9B, 0xE5D5BE0D, 0x7CDCEFB7, 0x0BDBDF21,
    0x86D3D2D4, 0xF1D4E242, 0x68DDB3F8, 0x1FDA836E,
    0x81BE16CD, 0xF6B9265B, 0x6FB077E1, 0x18B74777,
    0x88085AE6, 0xFF0F6A70, 0x66063BCA, 0x11010B5C,
    0x8F659EFF, 0xF862AE69, 0x616BFFD3, 0x166CCF45,
    0xA00AE278, 0xD70DD2EE, 0x4E048354, 0x3903B3C2,
    0xA7672661, 0xD06016F7, 0x4969474D, 0x3E6E77DB,
    0xAED16A4A, 0xD9D65ADC, 0x40DF0B66, 0x37D83BF0,
    0xA9BCAE53, 0xDEBB9EC5, 0x47B2CF7F, 0x30B5FFE9,
    0xBDBDF21C, 0xCABAC28A, 0x53B39330, 0x24B4A3A6,
    0xBAD03605, 0xCDD70693, 0x54DE5729, 0x23D967BF,
    0xB3667A2E, 0xC4614AB8, 0x5D681B02, 0x2A6F2B94,
    0xB40BBE37, 0xC30C8EA1, 0x5A05DF1B, 0x2D02EF8D
};

uint32_t NetworkServer::CalculateCRC32(const uint8_t* data, size_t len) {
    uint32_t crc = 0xFFFFFFFF;
    for (size_t i = 0; i < len; ++i) {
        crc = CRC32_TABLE[(crc ^ data[i]) & 0xFF] ^ (crc >> 8);
    }
    return crc ^ 0xFFFFFFFF;
}

uint32_t NetworkClient::CalculateCRC32(const uint8_t* data, size_t len) {
    uint32_t crc = 0xFFFFFFFF;
    for (size_t i = 0; i < len; ++i) {
        crc = CRC32_TABLE[(crc ^ data[i]) & 0xFF] ^ (crc >> 8);
    }
    return crc ^ 0xFFFFFFFF;
}

static bool SetNonBlocking(int fd, bool nonBlocking) {
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags == -1) return false;
    if (nonBlocking)
        flags |= O_NONBLOCK;
    else
        flags &= ~O_NONBLOCK;
    return fcntl(fd, F_SETFL, flags) == 0;
}

static bool RecvAll(int fd, uint8_t* buf, size_t len) {
    while (len > 0) {
        ssize_t n = recv(fd, buf, len, 0);
        if (n <= 0) return false;
        buf += n;
        len -= static_cast<size_t>(n);
    }
    return true;
}

static bool SendAll(int fd, const uint8_t* buf, size_t len) {
    while (len > 0) {
        ssize_t n = send(fd, buf, len, MSG_NOSIGNAL);
        if (n <= 0) return false;
        buf += n;
        len -= static_cast<size_t>(n);
    }
    return true;
}

NetworkServer::NetworkServer(int port)
    : serverFd(-1), clientFd(-1), running(false), connected(false), port(port) {
}

NetworkServer::~NetworkServer() {
    Stop();
}

bool NetworkServer::Start() {
    if (running.load()) return false;

    serverFd = socket(AF_INET, SOCK_STREAM, 0);
    if (serverFd < 0) return false;

    int optval = 1;
    if (setsockopt(serverFd, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval)) < 0) {
        close(serverFd);
        serverFd = -1;
        return false;
    }

    struct sockaddr_in addr;
    std::memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(static_cast<uint16_t>(port));

    if (bind(serverFd, reinterpret_cast<struct sockaddr*>(&addr), sizeof(addr)) < 0) {
        close(serverFd);
        serverFd = -1;
        return false;
    }

    if (listen(serverFd, 1) < 0) {
        close(serverFd);
        serverFd = -1;
        return false;
    }

    running.store(true);
    acceptThread = std::thread(&NetworkServer::AcceptLoop, this);
    return true;
}

void NetworkServer::Stop() {
    running.store(false);
    connected.store(false);

    if (acceptThread.joinable())
        acceptThread.join();

    if (recvThread.joinable())
        recvThread.join();

    if (clientFd >= 0) {
        close(clientFd);
        clientFd = -1;
    }

    if (serverFd >= 0) {
        close(serverFd);
        serverFd = -1;
    }
}

void NetworkServer::AcceptLoop() {
    while (running.load()) {
        struct sockaddr_in clientAddr;
        socklen_t addrLen = sizeof(clientAddr);

        int fd = accept(serverFd, reinterpret_cast<struct sockaddr*>(&clientAddr), &addrLen);
        if (fd < 0) {
            if (errno == EINTR) continue;
            break;
        }

        int optval = 1;
        setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &optval, sizeof(optval));

        {
            std::lock_guard<std::mutex> lock(clientMutex);
            if (clientFd >= 0) {
                close(clientFd);
            }
            clientFd = fd;
        }
        connected.store(true);

        if (recvThread.joinable()) {
            recvThread.join();
        }
        recvThread = std::thread(&NetworkServer::RecvLoop, this);
    }
}

void NetworkServer::RecvLoop() {
    while (connected.load() && running.load()) {
        PacketHeader header;
        if (!RecvAll(clientFd, reinterpret_cast<uint8_t*>(&header), sizeof(header))) {
            connected.store(false);
            break;
        }

        if (header.magic != MAGIC_NUMBER) {
            connected.store(false);
            break;
        }

        uint32_t payloadSize = ntohl(header.size);
        if (payloadSize > 1024 * 1024) {
            connected.store(false);
            break;
        }

        Packet pkt;
        pkt.header = header;
        pkt.payload.resize(payloadSize);

        if (payloadSize > 0) {
            if (!RecvAll(clientFd, pkt.payload.data(), payloadSize)) {
                connected.store(false);
                break;
            }
        }

        uint32_t computedCrc = CalculateCRC32(pkt.payload.data(), payloadSize);
        if (computedCrc != ntohl(header.checksum)) {
            Packet errPkt;
            errPkt.header.magic = MAGIC_NUMBER;
            errPkt.header.type = PacketType::ERROR;
            std::string errMsg = "CRC mismatch";
            errPkt.payload.assign(errMsg.begin(), errMsg.end());
            errPkt.header.size = htonl(static_cast<uint32_t>(errPkt.payload.size()));
            errPkt.header.checksum = htonl(CalculateCRC32(errPkt.payload.data(), errPkt.payload.size()));
            SendPacket(errPkt);
            continue;
        }

        HandlePacket(pkt);
    }
}

void NetworkServer::HandlePacket(const Packet& pkt) {
    switch (pkt.header.type) {
        case PacketType::COMMAND: {
            std::string cmd(pkt.payload.begin(), pkt.payload.end());
            if (OnCommand) OnCommand(cmd);
            break;
        }
        case PacketType::CONFIG_SYNC: {
            const uint8_t* data = pkt.payload.data();
            size_t offset = 0;
            size_t remaining = pkt.payload.size();

            if (remaining < 4) break;
            uint32_t numIntEntries;
            std::memcpy(&numIntEntries, data + offset, 4);
            numIntEntries = ntohl(numIntEntries);
            offset += 4;

            std::map<std::string, int> toggles;
            for (uint32_t i = 0; i < numIntEntries; ++i) {
                if (offset + 4 > remaining) break;
                uint32_t keyLen;
                std::memcpy(&keyLen, data + offset, 4);
                keyLen = ntohl(keyLen);
                offset += 4;

                if (offset + keyLen + 4 > remaining) break;
                std::string key(reinterpret_cast<const char*>(data + offset), keyLen);
                offset += keyLen;

                int32_t val;
                std::memcpy(&val, data + offset, 4);
                val = ntohl(static_cast<uint32_t>(val));
                offset += 4;

                toggles[key] = val;
            }

            if (OnConfigSync) OnConfigSync(toggles);
            break;
        }
        case PacketType::HEARTBEAT: {
            Packet hb;
            hb.header.magic = MAGIC_NUMBER;
            hb.header.type = PacketType::HEARTBEAT;
            hb.header.size = 0;
            hb.header.checksum = htonl(CalculateCRC32(nullptr, 0));
            SendPacket(hb);
            break;
        }
        case PacketType::SHUTDOWN: {
            connected.store(false);
            break;
        }
        default:
            break;
    }
}

void NetworkServer::SendPacket(const Packet& pkt) {
    if (!connected.load()) return;

    std::lock_guard<std::mutex> lock(sendMutex);

    PacketHeader header = pkt.header;
    header.magic = MAGIC_NUMBER;
    header.checksum = htonl(CalculateCRC32(pkt.payload.data(), pkt.payload.size()));

    if (!SendAll(clientFd, reinterpret_cast<const uint8_t*>(&header), sizeof(header)))
        return;

    if (pkt.payload.size() > 0) {
        if (!SendAll(clientFd, pkt.payload.data(), pkt.payload.size()))
            return;
    }
}

void NetworkServer::SendConfigSync(const std::map<std::string, int>& toggles, const std::map<std::string, float>& config) {
    std::vector<uint8_t> payload;
    size_t totalSize = 4;

    for (const auto& kv : toggles) {
        totalSize += 4 + kv.first.size() + 4;
    }
    for (const auto& kv : config) {
        totalSize += 4 + kv.first.size() + 4;
    }

    payload.reserve(totalSize);
    uint32_t netNumToggles = htonl(static_cast<uint32_t>(toggles.size()));
    uint8_t* ptr = reinterpret_cast<uint8_t*>(&netNumToggles);
    payload.insert(payload.end(), ptr, ptr + 4);

    for (const auto& kv : toggles) {
        uint32_t keyLen = htonl(static_cast<uint32_t>(kv.first.size()));
        ptr = reinterpret_cast<uint8_t*>(&keyLen);
        payload.insert(payload.end(), ptr, ptr + 4);

        payload.insert(payload.end(), kv.first.begin(), kv.first.end());

        uint32_t val = htonl(static_cast<uint32_t>(kv.second));
        ptr = reinterpret_cast<uint8_t*>(&val);
        payload.insert(payload.end(), ptr, ptr + 4);
    }

    uint32_t netNumConfig = htonl(static_cast<uint32_t>(config.size()));
    ptr = reinterpret_cast<uint8_t*>(&netNumConfig);
    payload.insert(payload.end(), ptr, ptr + 4);

    for (const auto& kv : config) {
        uint32_t keyLen = htonl(static_cast<uint32_t>(kv.first.size()));
        ptr = reinterpret_cast<uint8_t*>(&keyLen);
        payload.insert(payload.end(), ptr, ptr + 4);

        payload.insert(payload.end(), kv.first.begin(), kv.first.end());

        uint32_t ival;
        std::memcpy(&ival, &kv.second, sizeof(float));
        ival = htonl(ival);
        ptr = reinterpret_cast<uint8_t*>(&ival);
        payload.insert(payload.end(), ptr, ptr + 4);
    }

    Packet pkt;
    pkt.header.magic = MAGIC_NUMBER;
    pkt.header.type = PacketType::CONFIG_SYNC;
    pkt.header.size = htonl(static_cast<uint32_t>(payload.size()));
    pkt.payload = std::move(payload);
    pkt.header.checksum = htonl(CalculateCRC32(pkt.payload.data(), pkt.payload.size()));

    SendPacket(pkt);
}

void NetworkServer::SendLog(const std::string& msg) {
    Packet pkt;
    pkt.header.magic = MAGIC_NUMBER;
    pkt.header.type = PacketType::LOG;
    pkt.payload.assign(msg.begin(), msg.end());
    pkt.header.size = htonl(static_cast<uint32_t>(pkt.payload.size()));
    pkt.header.checksum = htonl(CalculateCRC32(pkt.payload.data(), pkt.payload.size()));
    SendPacket(pkt);
}

void NetworkServer::SendCommand(const std::string& cmd) {
    Packet pkt;
    pkt.header.magic = MAGIC_NUMBER;
    pkt.header.type = PacketType::COMMAND;
    pkt.payload.assign(cmd.begin(), cmd.end());
    pkt.header.size = htonl(static_cast<uint32_t>(pkt.payload.size()));
    pkt.header.checksum = htonl(CalculateCRC32(pkt.payload.data(), pkt.payload.size()));
    SendPacket(pkt);
}

NetworkClient::NetworkClient(const std::string& host, int port)
    : sockFd(-1), running(false), connected(false), host(host), port(port) {
}

NetworkClient::~NetworkClient() {
    Disconnect();
}

bool NetworkClient::Connect() {
    if (connected.load()) return false;

    sockFd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockFd < 0) return false;

    struct sockaddr_in addr;
    std::memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(static_cast<uint16_t>(port));

    if (inet_pton(AF_INET, host.c_str(), &addr.sin_addr) <= 0) {
        close(sockFd);
        sockFd = -1;
        return false;
    }

    if (connect(sockFd, reinterpret_cast<struct sockaddr*>(&addr), sizeof(addr)) < 0) {
        close(sockFd);
        sockFd = -1;
        return false;
    }

    int optval = 1;
    setsockopt(sockFd, IPPROTO_TCP, TCP_NODELAY, &optval, sizeof(optval));

    connected.store(true);
    running.store(true);
    recvThread = std::thread(&NetworkClient::RecvLoop, this);
    return true;
}

void NetworkClient::Disconnect() {
    running.store(false);
    connected.store(false);

    if (recvThread.joinable())
        recvThread.join();

    if (sockFd >= 0) {
        close(sockFd);
        sockFd = -1;
    }
}

void NetworkClient::RecvLoop() {
    while (connected.load() && running.load()) {
        PacketHeader header;
        if (!RecvAll(sockFd, reinterpret_cast<uint8_t*>(&header), sizeof(header))) {
            connected.store(false);
            break;
        }

        if (header.magic != MAGIC_NUMBER) {
            connected.store(false);
            break;
        }

        uint32_t payloadSize = ntohl(header.size);
        if (payloadSize > 1024 * 1024) {
            connected.store(false);
            break;
        }

        Packet pkt;
        pkt.header = header;
        pkt.payload.resize(payloadSize);

        if (payloadSize > 0) {
            if (!RecvAll(sockFd, pkt.payload.data(), payloadSize)) {
                connected.store(false);
                break;
            }
        }

        uint32_t computedCrc = CalculateCRC32(pkt.payload.data(), payloadSize);
        if (computedCrc != ntohl(header.checksum)) {
            Packet errPkt;
            errPkt.header.magic = MAGIC_NUMBER;
            errPkt.header.type = PacketType::ERROR;
            std::string errMsg = "CRC mismatch";
            errPkt.payload.assign(errMsg.begin(), errMsg.end());
            errPkt.header.size = htonl(static_cast<uint32_t>(errPkt.payload.size()));
            errPkt.header.checksum = htonl(CalculateCRC32(errPkt.payload.data(), errPkt.payload.size()));
            SendPacket(errPkt);
            continue;
        }

        HandlePacket(pkt);
    }
}

void NetworkClient::HandlePacket(const Packet& pkt) {
    switch (pkt.header.type) {
        case PacketType::COMMAND: {
            std::string cmd(pkt.payload.begin(), pkt.payload.end());
            if (OnCommand) OnCommand(cmd);
            break;
        }
        case PacketType::SHUTDOWN: {
            connected.store(false);
            break;
        }
        case PacketType::HEARTBEAT: {
            Packet hb;
            hb.header.magic = MAGIC_NUMBER;
            hb.header.type = PacketType::HEARTBEAT;
            hb.header.size = 0;
            hb.header.checksum = htonl(CalculateCRC32(nullptr, 0));
            SendPacket(hb);
            break;
        }
        default:
            break;
    }
}

void NetworkClient::SendPacket(const Packet& pkt) {
    if (!connected.load()) return;

    std::lock_guard<std::mutex> lock(sendMutex);

    PacketHeader header = pkt.header;
    header.magic = MAGIC_NUMBER;
    header.checksum = htonl(CalculateCRC32(pkt.payload.data(), pkt.payload.size()));

    if (!SendAll(sockFd, reinterpret_cast<const uint8_t*>(&header), sizeof(header)))
        return;

    if (pkt.payload.size() > 0) {
        if (!SendAll(sockFd, pkt.payload.data(), pkt.payload.size()))
            return;
    }
}

void NetworkClient::SendCommand(const std::string& cmd) {
    Packet pkt;
    pkt.header.magic = MAGIC_NUMBER;
    pkt.header.type = PacketType::COMMAND;
    pkt.payload.assign(cmd.begin(), cmd.end());
    pkt.header.size = htonl(static_cast<uint32_t>(pkt.payload.size()));
    pkt.header.checksum = htonl(CalculateCRC32(pkt.payload.data(), pkt.payload.size()));
    SendPacket(pkt);
}

}
