#ifndef BUGOR_MEMORYPOOL_H
#define BUGOR_MEMORYPOOL_H

#include <sys/uio.h>
#include <cstdint>
#include <cstddef>
#include <mutex>

struct MemReadBatch {
    uintptr_t Address;
    void* Buffer;
    size_t Size;
    bool Result;
};

class MemoryPool {
    static const int POOL_SIZE = 8192;
    char pool[POOL_SIZE];
    int poolOffset;
    int batchCount;
    MemReadBatch batches[256];
    iovec local[256];
    std::mutex poolMutex;

public:
    MemoryPool();
    void* Alloc(size_t size);
    void Reset();
    bool AddRead(uintptr_t addr, void* buf, size_t size);
    bool AddReadString(uintptr_t addr, char* buf, size_t maxLen);
    bool AddReadVec(uintptr_t addr, float* out, int count);
    bool ExecuteBatch(int pid);

    template<typename T>
    T Read(int pid, uintptr_t addr) {
        T val;
        if (batchCount > 0) ExecuteBatch(pid);
        batches[0].Address = addr;
        batches[0].Buffer = &val;
        batches[0].Size = sizeof(T);
        batches[0].Result = false;
        batchCount = 1;
        ExecuteBatch(pid);
        return val;
    }
};

#endif
