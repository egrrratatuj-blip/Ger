#include "MemoryIO.h"
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <cstring>
#include <cerrno>
#include <sys/syscall.h>
#include <sys/time.h>
#include <signal.h>

#ifndef IOV_MAX
#define IOV_MAX 1024
#endif

static void TimeoutHandler(int) {}

static bool IsValidPtr(uintptr_t p) {
    return p > 0x10000ULL && p < 0x7FFFFFFFFFFFULL && (p & 3) == 0;
}

ssize_t ReadProcessVM(int pid, const iovec* local, unsigned long lcnt,
                      const iovec* remote, unsigned long rcnt, bool write) {
#ifdef __aarch64__
    return syscall(write ? 271 : 270, pid, local, lcnt, remote, rcnt, 0);
#else
    return syscall(write ? 311 : 310, pid, local, lcnt, remote, rcnt, 0);
#endif
}

ssize_t ReadProcessMemory(int pid, uintptr_t addr, void* buf, size_t size) {
    if (pid <= 0 || !buf || size == 0) return -1;
    iovec local = {buf, size};
    iovec remote = {(void*)addr, size};
    ssize_t result = process_vm_readv(pid, &local, 1, &remote, 1, 0);
    if (result == (ssize_t)size) return result;

    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/mem", pid);
    int fd = open(path, O_RDONLY);
    if (fd < 0) return -1;
    result = pread64(fd, buf, size, (off64_t)addr);
    close(fd);
    return result;
}

ssize_t WriteProcessMemory(int pid, uintptr_t addr, const void* buf, size_t size) {
    if (pid <= 0 || !buf || size == 0) return -1;
    iovec local = {(void*)buf, size};
    iovec remote = {(void*)addr, size};
    ssize_t result = process_vm_writev(pid, &local, 1, &remote, 1, 0);
    if (result == (ssize_t)size) return result;

    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/mem", pid);
    int fd = open(path, O_RDWR);
    if (fd < 0) return -1;
    result = pwrite64(fd, buf, size, (off64_t)addr);
    close(fd);
    return result;
}

MemoryIO::MemoryIO() {
    pid = 0;
    m_TimeoutMs = 5000;
    m_memFd = -1;
    m_memPid = 0;
}

MemoryIO::~MemoryIO() {
    CloseMemFd();
}

void MemoryIO::CloseMemFd() {
    if (m_memFd >= 0) {
        close(m_memFd);
        m_memFd = -1;
    }
    m_memPid = 0;
}

void MemoryIO::Init(int pid1) {
    if (pid1 <= 0) return;
    if (pid1 != pid) CloseMemFd();
    pid = pid1;
}

void MemoryIO::SetTimeout(int ms) {
    if (ms < 0) ms = 0;
    m_TimeoutMs = ms;
}

int MemoryIO::GetPID(const char* packageName) {
    if (!packageName) return -1;
    DIR* dir = opendir("/proc");
    if (!dir) return -1;
    struct dirent* entry;
    char filename[128], cmdline[256];
    while ((entry = readdir(dir)) != NULL) {
        int id = atoi(entry->d_name);
        if (id <= 0) continue;
        snprintf(filename, sizeof(filename), "/proc/%d/cmdline", id);
        FILE* fp = fopen(filename, "r");
        if (!fp) continue;
        cmdline[0] = 0;
        size_t n = fread(cmdline, 1, sizeof(cmdline) - 1, fp);
        fclose(fp);
        if (n == 0) continue;
        cmdline[n] = 0;
        size_t len = strlen(packageName);
        if (n >= len && strncmp(packageName, cmdline, len) == 0) {
            closedir(dir);
            return id;
        }
    }
    closedir(dir);
    return -1;
}

static bool ReadWithTimeout(int fd, void* buf, size_t size, off_t off, uint32_t timeout_ms) {
    if (timeout_ms == 0) {
        return pread64(fd, buf, size, off) == (ssize_t)size;
    }
    struct sigaction sa, old;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = TimeoutHandler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sigaction(SIGALRM, &sa, &old);

    struct itimerval it;
    it.it_value.tv_sec = timeout_ms / 1000;
    it.it_value.tv_usec = (timeout_ms % 1000) * 1000;
    it.it_interval.tv_sec = 0;
    it.it_interval.tv_usec = 0;
    setitimer(ITIMER_REAL, &it, NULL);

    ssize_t n = pread64(fd, buf, size, off);

    struct itimerval zero;
    memset(&zero, 0, sizeof(zero));
    setitimer(ITIMER_REAL, &zero, NULL);
    sigaction(SIGALRM, &old, NULL);
    return n == (ssize_t)size;
}

bool MemoryIO::Read(uintptr_t addr, void* buf, size_t size) {
    if (pid <= 0 || !buf || size == 0) return false;

    iovec local = {buf, size};
    iovec remote = {(void*)addr, size};
    ssize_t result = process_vm_readv(pid, &local, 1, &remote, 1, 0);
    if (result == (ssize_t)size) return true;

    if (m_memPid != pid) {
        CloseMemFd();
        char path[64];
        snprintf(path, sizeof(path), "/proc/%d/mem", pid);
        m_memFd = open(path, O_RDONLY);
        m_memPid = pid;
    }

    if (m_memFd < 0) return false;
    return ReadWithTimeout(m_memFd, buf, size, (off_t)addr, (uint32_t)m_TimeoutMs);
}

bool MemoryIO::Write(uintptr_t addr, const void* buf, size_t size) {
    if (pid <= 0 || !buf || size == 0) return false;

    iovec local = {(void*)buf, size};
    iovec remote = {(void*)addr, size};
    ssize_t result = process_vm_writev(pid, &local, 1, &remote, 1, 0);
    if (result == (ssize_t)size) return true;

    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/mem", pid);
    int fd = open(path, O_RDWR);
    if (fd < 0) return false;
    ssize_t w = pwrite64(fd, buf, size, (off64_t)addr);
    close(fd);
    return w == (ssize_t)size;
}

float MemoryIO::ReadFloat(uintptr_t addr) {
    float v = 0; Read(addr, &v, 4); return v;
}

int MemoryIO::ReadInt(uintptr_t addr) {
    int v = 0; Read(addr, &v, 4); return v;
}

uint32_t MemoryIO::ReadDword(uintptr_t addr) {
    uint32_t v = 0; Read(addr, &v, 4); return v;
}

uint64_t MemoryIO::ReadQword(uintptr_t addr) {
    uint64_t v = 0; Read(addr, &v, 8); return v;
}

uint8_t MemoryIO::ReadByte(uintptr_t addr) {
    uint8_t v = 0; Read(addr, &v, 1); return v;
}

uintptr_t MemoryIO::ReadPtr64(uintptr_t addr) {
    if (pid <= 0) return 0;
    if (!IsValidPtr(addr)) return 0;
    uint64_t v = 0;
    if (!Read(addr, &v, 8)) return 0;
    return (uintptr_t)v;
}

uintptr_t MemoryIO::ReadPtr32(uintptr_t addr) {
    if (pid <= 0) return 0;
    uint32_t v = 0;
    if (!Read(addr, &v, 4)) return 0;
    return (uintptr_t)v;
}

void MemoryIO::WriteFloat(uintptr_t addr, float val) {
    Write(addr, &val, 4);
}

void MemoryIO::WriteInt(uintptr_t addr, int val) {
    Write(addr, &val, 4);
}

void MemoryIO::WriteDword(uintptr_t addr, uint32_t val) {
    Write(addr, &val, 4);
}

void MemoryIO::WriteQword(uintptr_t addr, uint64_t val) {
    Write(addr, &val, 8);
}

static bool LineMatchesLibrary(const char* line, const char* name) {
    if (!line || !name) return false;
    const char* p = strstr(line, name);
    if (!p) return false;
    char c = p[strlen(name)];
    return (c == 0 || c == '\n' || c == ' ' || c == '\t');
}

uintptr_t MemoryIO::GetModuleBase(const char* name) {
    return GetModuleBase(name, false);
}

uintptr_t MemoryIO::GetModuleBase(const char* name, bool exactMatch) {
    if (pid <= 0 || !name) return 0;
    char path[256], line[1024];
    uintptr_t addr = 0;
    snprintf(path, sizeof(path), "/proc/%d/maps", pid);
    FILE* fp = fopen(path, "r");
    if (!fp) return 0;
    while (fgets(line, sizeof(line), fp)) {
        if (exactMatch) {
            const char* lib = strrchr(line, '/');
            if (!lib) continue;
            lib++;
            const char* e = lib;
            while (*e && *e != '\n' && *e != ' ' && *e != '\t') e++;
            size_t libLen = e - lib;
            if (libLen != strlen(name)) continue;
            if (strncmp(lib, name, libLen) != 0) continue;
        } else {
            if (!LineMatchesLibrary(line, name)) continue;
        }
        uintptr_t s = 0, e = 0;
        if (sscanf(line, "%lx-%lx", &s, &e) == 2) {
            addr = s;
            break;
        }
    }
    fclose(fp);
    return addr;
}

uintptr_t MemoryIO::GetBSS(const char* name) {
    if (pid <= 0 || !name) return 0;
    char path[256], line[1024];
    uintptr_t bssAddr = 0;
    snprintf(path, sizeof(path), "/proc/%d/maps", pid);
    FILE* fp = fopen(path, "r");
    if (!fp) return 0;
    while (fgets(line, sizeof(line), fp)) {
        if (!LineMatchesLibrary(line, name)) continue;
        if (!strstr(line, "rw-p")) continue;
        uintptr_t s = 0, e = 0;
        if (sscanf(line, "%lx-%lx", &s, &e) == 2) {
            if (s > bssAddr) bssAddr = s;
        }
    }
    fclose(fp);
    return bssAddr;
}

size_t MemoryIO::GetModuleSize(const char* name) {
    if (pid <= 0 || !name) return 0;
    char path[256], line[1024];
    uintptr_t start = 0, end = 0;
    snprintf(path, sizeof(path), "/proc/%d/maps", pid);
    FILE* fp = fopen(path, "r");
    if (!fp) return 0;
    while (fgets(line, sizeof(line), fp)) {
        if (!LineMatchesLibrary(line, name)) continue;
        uintptr_t s = 0, e = 0;
        if (sscanf(line, "%lx-%lx", &s, &e) != 2) continue;
        if (!start || s < start) start = s;
        if (e > end) end = e;
    }
    fclose(fp);
    if (end < start) return 0;
    return end - start;
}

bool MemoryIO::ReadString(uintptr_t addr, char* buf, size_t maxLen) {
    if (pid <= 0 || !addr || !buf || maxLen == 0) return false;
    if (maxLen > 256) maxLen = 256;
    memset(buf, 0, maxLen);
    size_t readSize = maxLen - 1;
    if (!Read(addr, buf, readSize)) return false;
    buf[readSize] = 0;
    return true;
}

bool MemoryIO::ReadUTF8String(uintptr_t addr, char* buf, size_t maxLen) {
    if (pid <= 0 || !addr || !buf || maxLen == 0) return false;
    if (maxLen > 512) maxLen = 512;
    if (maxLen == 1) { buf[0] = 0; return true; }
    int32_t length = 0;
    if (!Read(addr + 0x10, &length, 4)) { buf[0] = 0; return false; }
    if (length < 0) { buf[0] = 0; return false; }
    if (length > 512) length = 512;
    size_t count = (size_t)length;
    uint16_t buf16[512];
    if (!Read(addr + 0x14, buf16, count * 2)) {
        buf[0] = 0;
        return false;
    }
    char* dst = buf;
    char* end = buf + maxLen - 1;
    for (size_t i = 0; i < count && dst < end; i++) {
        uint32_t cp = buf16[i];
        if (cp >= 0xD800 && cp <= 0xDBFF) {
            i++;
            if (i < count) {
                uint32_t lo = buf16[i];
                if (lo >= 0xDC00 && lo <= 0xDFFF) {
                    cp = ((cp - 0xD800) << 10) + (lo - 0xDC00) + 0x10000;
                } else {
                    cp = 0xFFFD;
                    i--;
                }
            } else {
                cp = 0xFFFD;
            }
        } else if (cp >= 0xDC00 && cp <= 0xDFFF) {
            cp = 0xFFFD;
        }
        if (cp <= 0x007F) {
            *dst++ = (char)cp;
        } else if (cp <= 0x07FF && (dst + 1) < end) {
            *dst++ = (char)(((cp >> 6) & 0x1F) | 0xC0);
            *dst++ = (char)((cp & 0x3F) | 0x80);
        } else if (cp <= 0xFFFF && (dst + 2) < end) {
            *dst++ = (char)(((cp >> 12) & 0x0F) | 0xE0);
            *dst++ = (char)(((cp >> 6) & 0x3F) | 0x80);
            *dst++ = (char)((cp & 0x3F) | 0x80);
        } else if (cp <= 0x10FFFF && (dst + 3) < end) {
            *dst++ = (char)(((cp >> 18) & 0x07) | 0xF0);
            *dst++ = (char)(((cp >> 12) & 0x3F) | 0x80);
            *dst++ = (char)(((cp >> 6) & 0x3F) | 0x80);
            *dst++ = (char)((cp & 0x3F) | 0x80);
        } else {
            if (dst < end) *dst++ = '?';
        }
    }
    *dst = 0;
    return true;
}

static bool MaskMatch(const uint8_t* mem, const uint8_t* pat, const char* mask, size_t len) {
    for (size_t j = 0; j < len; j++) {
        if (mask[j] == 'x' && mem[j] != pat[j]) return false;
    }
    return true;
}

uintptr_t MemoryIO::FindSignature(const char* module, const char* pattern, const char* mask) {
    if (pid <= 0 || !module || !pattern || !mask) return 0;
    size_t patternLen = strlen(mask);
    if (patternLen == 0) return 0;
    uintptr_t base = GetModuleBase(module);
    size_t size = GetModuleSize(module);
    if (!base || !size || size < patternLen) return 0;

    std::vector<uint8_t> data(size);
    if (!Read(base, data.data(), size)) return 0;

    const uint8_t* pat = (const uint8_t*)pattern;
    for (size_t i = 0; i <= size - patternLen; i++) {
        if (MaskMatch(data.data() + i, pat, mask, patternLen)) {
            return base + i;
        }
    }
    return 0;
}

std::vector<uintptr_t> MemoryIO::FindSignatures(const char* module, const char* pattern, const char* mask) {
    std::vector<uintptr_t> results;
    if (pid <= 0 || !module || !pattern || !mask) return results;
    size_t patternLen = strlen(mask);
    if (patternLen == 0) return results;
    uintptr_t base = GetModuleBase(module);
    size_t size = GetModuleSize(module);
    if (!base || !size || size < patternLen) return results;

    std::vector<uint8_t> data(size);
    if (!Read(base, data.data(), size)) return results;

    const uint8_t* pat = (const uint8_t*)pattern;
    for (size_t i = 0; i <= size - patternLen; i++) {
        if (MaskMatch(data.data() + i, pat, mask, patternLen)) {
            results.push_back(base + i);
        }
    }
    return results;
}

uintptr_t MemoryIO::TracePointer(uintptr_t addr, const std::vector<uintptr_t>& offsets) {
    if (pid <= 0 || !addr) return 0;
    if (offsets.empty()) return addr;
    uintptr_t ptr = addr;
    for (size_t i = 0; i < offsets.size(); i++) {
        if (offsets[i] > UINTPTR_MAX - ptr) return 0;
        ptr += offsets[i];
        if (i == offsets.size() - 1) break;
        if (!IsValidPtr(ptr)) return 0;
        uint64_t v = 0;
        if (!Read(ptr, &v, 8)) return 0;
        ptr = (uintptr_t)v;
        if (!ptr) return 0;
    }
    return ptr;
}

bool MemoryIO::ReadBatch(std::vector<BatchEntry>& entries) {
    if (pid <= 0 || entries.empty()) return false;
    bool ok = true;
    size_t total = entries.size();
    size_t pos = 0;
    while (pos < total) {
        size_t count = total - pos;
        if (count > IOV_MAX) count = IOV_MAX;
        std::vector<iovec> local(count), remote(count);
        for (size_t i = 0; i < count; i++) {
            local[i].iov_base = entries[pos + i].buf;
            local[i].iov_len = entries[pos + i].size;
            remote[i].iov_base = (void*)entries[pos + i].addr;
            remote[i].iov_len = entries[pos + i].size;
        }
        ssize_t ret = ReadProcessVM(pid, local.data(), count, remote.data(), count, false);
        if (ret < 0) {
            ok = false;
            break;
        }
        pos += count;
    }
    return ok;
}
