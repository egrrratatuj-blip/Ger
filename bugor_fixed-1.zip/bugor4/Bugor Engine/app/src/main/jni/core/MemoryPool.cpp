#include "MemoryPool.h"
#include <unistd.h>
#include <fcntl.h>
#include <cstring>

MemoryPool::MemoryPool() : poolOffset(0), batchCount(0) {}

void* MemoryPool::Alloc(size_t size) {
    std::lock_guard<std::mutex> lock(poolMutex);
    if (poolOffset + (int)size > POOL_SIZE) return nullptr;
    void* ptr = pool + poolOffset;
    poolOffset += (int)size;
    return ptr;
}

void MemoryPool::Reset() {
    std::lock_guard<std::mutex> lock(poolMutex);
    poolOffset = 0;
    batchCount = 0;
}

bool MemoryPool::AddRead(uintptr_t addr, void* buf, size_t size) {
    std::lock_guard<std::mutex> lock(poolMutex);
    if (batchCount >= 256) return false;
    batches[batchCount].Address = addr;
    batches[batchCount].Buffer = buf;
    batches[batchCount].Size = size;
    batches[batchCount].Result = false;
    batchCount++;
    return true;
}

bool MemoryPool::AddReadString(uintptr_t addr, char* buf, size_t maxLen) {
    std::lock_guard<std::mutex> lock(poolMutex);
    if (batchCount >= 256) return false;
    batches[batchCount].Address = addr;
    batches[batchCount].Buffer = buf;
    batches[batchCount].Size = maxLen;
    batches[batchCount].Result = false;
    batchCount++;
    return true;
}

bool MemoryPool::AddReadVec(uintptr_t addr, float* out, int count) {
    return AddRead(addr, out, (size_t)count * sizeof(float));
}

bool MemoryPool::ExecuteBatch(int pid) {
    std::lock_guard<std::mutex> lock(poolMutex);
    if (batchCount == 0) return true;
    if (pid <= 0) { batchCount = 0; return false; }

    iovec remote[256];
    for (int i = 0; i < batchCount; i++) {
        local[i].iov_base = batches[i].Buffer;
        local[i].iov_len = batches[i].Size;
        remote[i].iov_base = (void*)batches[i].Address;
        remote[i].iov_len = batches[i].Size;
    }

    size_t totalSize = 0;
    for (int i = 0; i < batchCount; i++) totalSize += batches[i].Size;

    ssize_t ret = process_vm_readv(pid, local, batchCount, remote, batchCount, 0);
    if (ret == (ssize_t)totalSize) {
        for (int i = 0; i < batchCount; i++) batches[i].Result = true;
        batchCount = 0;
        return true;
    }

    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/mem", pid);
    int fd = open(path, O_RDONLY);
    if (fd < 0) { batchCount = 0; return false; }

    for (int i = 0; i < batchCount; i++) {
        ssize_t r = pread64(fd, batches[i].Buffer, batches[i].Size,
                           (off64_t)batches[i].Address);
        batches[i].Result = (r == (ssize_t)batches[i].Size);
    }
    close(fd);
    batchCount = 0;
    return true;
}
