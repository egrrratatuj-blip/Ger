#pragma once
#include <string>
#include <vector>
#include <map>
#include <functional>
#include <cstdint>

namespace ScriptEngine {

enum class ScriptValueType { NIL, INTEGER, FLOAT, BOOLEAN, STRING, ARRAY, MAP, NATIVE_FUNC };

struct ScriptValue {
    ScriptValueType type = ScriptValueType::NIL;
    int64_t intVal = 0;
    float floatVal = 0.0f;
    bool boolVal = false;
    std::string strVal;
    std::vector<ScriptValue> arrayVal;
    std::map<std::string, ScriptValue> mapVal;
    std::function<ScriptValue(const std::vector<ScriptValue>&)> nativeFunc;
    
    ScriptValue() : type(ScriptValueType::NIL) {}
    ScriptValue(int64_t v) : type(ScriptValueType::INTEGER), intVal(v) {}
    ScriptValue(float v) : type(ScriptValueType::FLOAT), floatVal(v) {}
    ScriptValue(bool v) : type(ScriptValueType::BOOLEAN), boolVal(v) {}
    ScriptValue(const std::string& v) : type(ScriptValueType::STRING), strVal(v) {}
    ScriptValue(const char* v) : type(ScriptValueType::STRING), strVal(v) {}
    ScriptValue(std::function<ScriptValue(const std::vector<ScriptValue>&)> fn) : type(ScriptValueType::NATIVE_FUNC), nativeFunc(fn) {}
    
    std::string ToString() const;
};

class ScriptContext {
public:
    std::map<std::string, ScriptValue> globals;
    std::map<std::string, ScriptValue> locals;
    ScriptContext* parent = nullptr;
    std::vector<ScriptValue> returnStack;
    
    ScriptValue& Get(const std::string& name);
    void Set(const std::string& name, const ScriptValue& val);
    void Return(const ScriptValue& val);
};

class ScriptEngine {
    std::string source;
    std::vector<std::string> tokens;
    std::map<std::string, ScriptValue> builtins;
    ScriptContext rootCtx;
    int pos;
    bool hasError;
    std::string errorMsg;
    int errorLine;
    
    std::vector<std::string> Tokenize(const std::string& src);
    ScriptValue ParseExpression();
    ScriptValue ParseStatement();
    ScriptValue ParseBlock();
    ScriptValue ParseIf();
    ScriptValue ParseWhile();
    ScriptValue ParseFor();
    ScriptValue ParseFunctionDef();
    ScriptValue ParseFunctionCall(const std::string& name);
    std::vector<ScriptValue> ParseArguments();
    ScriptValue ParsePrimary();
    
    std::string Peek();
    std::string Next();
    bool Match(const std::string& expected);
    void Expect(const std::string& expected);
    void Error(const std::string& msg);
    
    void SetupDefaultFunctions();
    
public:
    ScriptEngine();
    bool Load(const std::string& sourceCode);
    ScriptValue Run();
    void RegisterFunction(const std::string& name, std::function<ScriptValue(const std::vector<ScriptValue>&)> fn);
    bool HasError() const { return hasError; }
    std::string GetError() const { return errorMsg; }
    std::map<std::string, ScriptValue>& GetGlobals() { return rootCtx.globals; }
};

}
