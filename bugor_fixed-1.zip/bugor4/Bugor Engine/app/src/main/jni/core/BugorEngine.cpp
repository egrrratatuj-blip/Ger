#include "core/BugorEngine.h"
#include <iostream>
#include <sstream>
#include <chrono>
#include <thread>
#include <sys/utsname.h>
#include <sys/sysinfo.h>

BugorEngine *BugorEngine::instance = nullptr;

BugorEngine& BugorEngine::getInstance() {
    static BugorEngine engine;
    return engine;
}

BugorEngine::BugorEngine()
    : initialized(false), running(false), metricsEnabled(true), paused(false),
      state(EngineState::Uninitialized), mode(EngineMode::Standalone),
      javaVM(nullptr),
      memoryManager(nullptr), hookingFramework(nullptr), crashReporter(nullptr),
      scriptEngine(nullptr), analyticsEngine(nullptr), remoteClient(nullptr),
      remoteServer(nullptr), persistenceManager(nullptr), encryptionManager(nullptr),
      debugger(nullptr), loggingSystem(nullptr),
      metricsThread(nullptr), healthThread(nullptr), maintenanceThread(nullptr),
      backgroundThreadsRunning(false) {}

BugorEngine::~BugorEngine() { shutdown(); }

bool BugorEngine::initialize(const EngineConfig &cfg) {
    if (initialized) return true;

    std::lock_guard<std::mutex> lock(engineMutex);
    config = cfg;
    state = EngineState::Initializing;

    if (!createDirectories()) {
        state = EngineState::Error;
        return false;
    }

    if (!initializeSubsystems()) {
        state = EngineState::Error;
        return false;
    }

    initialized = true;
    running = true;
    state = EngineState::Ready;
    return true;
}

bool BugorEngine::initialize(int argc, char *argv[]) {
    EngineConfig cfg;
    cfg.app_name = "Bugor Engine";
    cfg.app_version = "3.0.0";
    cfg.data_directory = "/data/data/com.bugor.engine/";
    cfg.log_directory = "/data/data/com.bugor.engine/logs/";
    cfg.enable_logging = true;
    cfg.enable_crash_reporter = true;
    cfg.enable_script_engine = true;
    cfg.enable_analytics = true;
    cfg.enable_persistence = true;
    cfg.enable_encryption = true;
    cfg.enable_hooking = true;
    cfg.enable_memory_operations = true;
    cfg.enable_multi_threading = true;
    cfg.mode = EngineMode::Standalone;

    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "--server") cfg.mode = EngineMode::Server;
        else if (arg == "--client") cfg.mode = EngineMode::Client;
        else if (arg == "--debug") cfg.mode = EngineMode::Debug;
        else if (arg == "--verbose" || arg == "-v") cfg.log_directory = "";
    }

    return initialize(cfg);
}

void BugorEngine::shutdown() {
    if (!initialized) return;

    std::lock_guard<std::mutex> lock(engineMutex);
    state = EngineState::Stopping;
    running = false;
    backgroundThreadsRunning = false;

    if (metricsThread && metricsThread->joinable()) metricsThread->join();
    if (healthThread && healthThread->joinable()) healthThread->join();
    if (maintenanceThread && maintenanceThread->joinable()) maintenanceThread->join();

    shutdownSubsystems();
    initialized = false;
    state = EngineState::Stopped;
}

bool BugorEngine::restart() {
    shutdown();
    return initialize(config);
}

bool BugorEngine::isInitialized() const { return initialized; }
bool BugorEngine::isRunning() const { return running; }
EngineState BugorEngine::getState() const { return state; }
EngineMode BugorEngine::getMode() const { return mode; }

bool BugorEngine::start() {
    if (!initialized || running) return false;
    running = true;
    state = EngineState::Running;
    return true;
}

bool BugorEngine::stop() {
    running = false;
    state = EngineState::Stopped;
    return true;
}

bool BugorEngine::pause() {
    if (!running) return false;
    paused = true;
    state = EngineState::Paused;
    return true;
}

bool BugorEngine::resume() {
    if (!paused) return false;
    paused = false;
    state = EngineState::Running;
    return true;
}

bool BugorEngine::reload() {
    state = EngineState::Initializing;
    shutdownSubsystems();
    bool ok = initializeSubsystems();
    state = ok ? EngineState::Ready : EngineState::Error;
    return ok;
}

bool BugorEngine::recover() {
    if (state != EngineState::Error) return true;
    return reload();
}

bool BugorEngine::reset() {
    shutdown();
    config = EngineConfig();
    return true;
}

bool BugorEngine::clearState() { return true; }

EngineConfig BugorEngine::getConfig() const { return config; }

bool BugorEngine::setConfig(const EngineConfig &cfg) {
    config = cfg;
    return true;
}

bool BugorEngine::updateConfig(const std::string &key, const std::string &value) { return true; }

bool BugorEngine::loadConfig(const std::string &path) { return true; }

bool BugorEngine::saveConfig(const std::string &path) { return true; }

MemoryManager* BugorEngine::getMemoryManager() { return memoryManager; }
HookingFramework* BugorEngine::getHookingFramework() { return hookingFramework; }
CrashReporter* BugorEngine::getCrashReporter() { return crashReporter; }
ScriptEngine* BugorEngine::getScriptEngine() { return scriptEngine; }
AnalyticsEngine* BugorEngine::getAnalyticsEngine() { return analyticsEngine; }
RemoteControlClient* BugorEngine::getRemoteClient() { return remoteClient; }
PersistenceManager* BugorEngine::getPersistenceManager() { return persistenceManager; }
EncryptionManager* BugorEngine::getEncryptionManager() { return encryptionManager; }
Debugger* BugorEngine::getDebugger() { return debugger; }
LoggingSystem* BugorEngine::getLoggingSystem() { return loggingSystem; }

std::string BugorEngine::executeCommand(const std::string &command, const std::map<std::string, std::string> &params) {
    std::lock_guard<std::mutex> lock(commandMutex);
    auto it = commandHandlers.find(command);
    if (it != commandHandlers.end()) {
        return it->second(params);
    }
    return "Unknown command: " + command;
}

std::string BugorEngine::executeScript(const std::string &script) {
    if (!scriptEngine) return "Script engine not initialized";
    scriptEngine->executeScript(script);
    return "OK";
}

std::string BugorEngine::executeExpression(const std::string &expression) {
    if (!scriptEngine) return "Script engine not initialized";
    return "";
}

bool BugorEngine::loadPlugin(const std::string &path) {
    void *handle = dlopen(path.c_str(), RTLD_NOW | RTLD_GLOBAL);
    if (!handle) return false;
    loadedPlugins[path] = handle;
    return true;
}

bool BugorEngine::unloadPlugin(const std::string &name) {
    auto it = loadedPlugins.find(name);
    if (it == loadedPlugins.end()) return false;
    dlclose(it->second);
    loadedPlugins.erase(it);
    return true;
}

bool BugorEngine::reloadPlugin(const std::string &name) {
    if (!unloadPlugin(name)) return false;
    return loadPlugin(name);
}

std::vector<std::string> BugorEngine::getLoadedPlugins() const {
    std::vector<std::string> names;
    for (auto &[name, _] : loadedPlugins) names.push_back(name);
    return names;
}

bool BugorEngine::registerCommand(const std::string &name, std::function<std::string(const std::map<std::string, std::string>&)> handler) {
    commandHandlers[name] = handler;
    return true;
}

bool BugorEngine::unregisterCommand(const std::string &name) {
    return commandHandlers.erase(name) > 0;
}

bool BugorEngine::hasCommand(const std::string &name) const {
    return commandHandlers.find(name) != commandHandlers.end();
}

std::vector<std::string> BugorEngine::getRegisteredCommands() const {
    std::vector<std::string> names;
    for (auto &[name, _] : commandHandlers) names.push_back(name);
    return names;
}

bool BugorEngine::registerEventHandler(const std::string &event, std::function<void(const std::map<std::string, std::string>&)> handler) {
    eventHandlers[event].push_back(handler);
    return true;
}

bool BugorEngine::unregisterEventHandler(const std::string &event) {
    return eventHandlers.erase(event) > 0;
}

bool BugorEngine::emitEvent(const std::string &event, const std::map<std::string, std::string> &data) {
    auto it = eventHandlers.find(event);
    if (it == eventHandlers.end()) return false;
    for (auto &handler : it->second) {
        handler(data);
    }
    return true;
}

EngineMetrics BugorEngine::getMetrics() const { return metrics; }

bool BugorEngine::resetMetrics() {
    metrics = EngineMetrics();
    return true;
}

bool BugorEngine::enableMetrics(bool enable) {
    metricsEnabled = enable;
    return true;
}

bool BugorEngine::isMetricsEnabled() const { return metricsEnabled; }

HealthStatus BugorEngine::getHealthStatus() const { return health; }

bool BugorEngine::runHealthCheck() {
    health.memory_subsystem_healthy = memoryManager != nullptr;
    health.hooking_subsystem_healthy = hookingFramework != nullptr;
    health.script_engine_healthy = scriptEngine != nullptr;
    health.crash_reporter_healthy = crashReporter != nullptr;
    health.analytics_healthy = analyticsEngine != nullptr;
    health.remote_connection_healthy = remoteClient != nullptr;
    health.persistence_healthy = persistenceManager != nullptr;
    health.encryption_subsystem_healthy = encryptionManager != nullptr;
    health.debugger_healthy = debugger != nullptr;
    return true;
}

bool BugorEngine::runDiagnostics() { return true; }
std::string BugorEngine::getDiagnosticsReport() const { return "OK"; }

bool BugorEngine::isFeatureEnabled(const std::string &feature) const {
    if (feature == "memory") return memoryManager != nullptr;
    if (feature == "hooking") return hookingFramework != nullptr;
    if (feature == "script") return scriptEngine != nullptr;
    if (feature == "crash") return crashReporter != nullptr;
    if (feature == "analytics") return analyticsEngine != nullptr;
    if (feature == "remote") return remoteClient != nullptr;
    if (feature == "persistence") return persistenceManager != nullptr;
    if (feature == "encryption") return encryptionManager != nullptr;
    if (feature == "debugger") return debugger != nullptr;
    if (feature == "logging") return loggingSystem != nullptr;
    return false;
}

bool BugorEngine::enableFeature(const std::string &feature) { return true; }
bool BugorEngine::disableFeature(const std::string &feature) { return true; }

std::vector<std::string> BugorEngine::getEnabledFeatures() const {
    std::vector<std::string> features;
    if (memoryManager) features.push_back("memory");
    if (hookingFramework) features.push_back("hooking");
    if (scriptEngine) features.push_back("script");
    if (crashReporter) features.push_back("crash");
    if (analyticsEngine) features.push_back("analytics");
    if (remoteClient) features.push_back("remote");
    if (persistenceManager) features.push_back("persistence");
    if (encryptionManager) features.push_back("encryption");
    if (debugger) features.push_back("debugger");
    if (loggingSystem) features.push_back("logging");
    return features;
}

std::vector<std::string> BugorEngine::getAvailableFeatures() const {
    return {"memory", "hooking", "script", "crash", "analytics", "remote", "persistence", "encryption", "debugger", "logging"};
}

std::string BugorEngine::getVersion() const { return "3.0.0"; }

std::string BugorEngine::getBuildInfo() const {
    return "Bugor Engine v3.0.0 | Built with NDK r26 | C++17 | " + getPlatformInfo();
}

std::string BugorEngine::getPlatformInfo() const {
    struct utsname buf;
    uname(&buf);
    return std::string(buf.sysname) + " " + buf.release + " " + buf.machine;
}

bool BugorEngine::checkLicense() { return true; }
std::string BugorEngine::getLicenseInfo() const { return "License: MIT"; }

void BugorEngine::onStateChange(std::function<void(EngineState, EngineState)> callback) {
    stateChangeCallback = callback;
}

void BugorEngine::onError(std::function<void(const std::string&, int)> callback) {
    errorCallback = callback;
}

void BugorEngine::onWarning(std::function<void(const std::string&)> callback) {
    warningCallback = callback;
}

JavaVM* BugorEngine::getJavaVM() const { return javaVM; }

JNIEnv* BugorEngine::getJNIEnv() const {
    if (!javaVM) return nullptr;
    JNIEnv *env;
    if (javaVM->GetEnv((void**)&env, JNI_VERSION_1_6) == JNI_OK) return env;
    return nullptr;
}

bool BugorEngine::attachToJVM(JavaVM *vm) {
    javaVM = vm;
    return true;
}

bool BugorEngine::detachFromJVM() {
    javaVM = nullptr;
    return true;
}

bool BugorEngine::initializeSubsystems() {
    if (!initializeLogging()) return false;
    if (!initializeMemoryManager()) return false;
    if (!initializeHooking()) return false;
    if (!initializeCrashReporter()) return false;
    if (!initializeScriptEngine()) return false;
    if (!initializeAnalytics()) return false;
    if (!initializePersistence()) return false;
    if (!initializeEncryption()) return false;

    backgroundThreadsRunning = true;
    metricsThread = new std::thread(&BugorEngine::metricsLoop, this);
    healthThread = new std::thread(&BugorEngine::healthCheckLoop, this);

    if (config.mode == EngineMode::Server || config.mode == EngineMode::Hybrid) {
        initializeRemoteControl();
    }
    if (config.mode == EngineMode::Client || config.mode == EngineMode::Hybrid) {
        initializeRemoteControl();
    }
    if (config.enable_debugger) {
        initializeDebugger();
    }

    return true;
}

bool BugorEngine::initializeMemoryManager() {
    memoryManager = new MemoryManager();
    if (!memoryManager->initialize()) {
        delete memoryManager;
        memoryManager = nullptr;
        return false;
    }
    return true;
}

bool BugorEngine::initializeHooking() {
    hookingFramework = new HookingFramework();
    if (!hookingFramework->initialize()) {
        delete hookingFramework;
        hookingFramework = nullptr;
        return false;
    }
    return true;
}

bool BugorEngine::initializeCrashReporter() {
    if (!config.enable_crash_reporter) return true;
    crashReporter = new CrashReporter();
    CrashReportConfig crashConfig;
    crashConfig.crash_dir = config.crash_dump_directory.empty() ? config.data_directory + "/crashes" : config.crash_dump_directory;
    crashConfig.upload_enabled = false;
    crashConfig.signal_handler = true;
    crashConfig.cpp_exception_handler = true;
    if (!crashReporter->initialize(crashConfig)) {
        delete crashReporter;
        crashReporter = nullptr;
        return false;
    }
    return true;
}

bool BugorEngine::initializeScriptEngine() {
    if (!config.enable_script_engine) return true;
    scriptEngine = new ScriptEngine();
    if (!scriptEngine->initialize()) {
        delete scriptEngine;
        scriptEngine = nullptr;
        return false;
    }
    return true;
}

bool BugorEngine::initializeAnalytics() {
    if (!config.enable_analytics) return true;
    analyticsEngine = new AnalyticsEngine();
    if (!analyticsEngine->initialize()) {
        delete analyticsEngine;
        analyticsEngine = nullptr;
        return false;
    }
    return true;
}

bool BugorEngine::initializeRemoteControl() {
    if (!config.enable_remote_control) return true;
    if (config.mode == EngineMode::Server || config.mode == EngineMode::Hybrid) {
        ServerConfig serverConfig;
        serverConfig.port = config.remote_port;
        serverConfig.api_key = config.remote_api_key;
        remoteServer = new RemoteControlServer();
        remoteServer->initialize(serverConfig);
        remoteServer->start();
    }
    if (config.mode == EngineMode::Client || config.mode == EngineMode::Hybrid || config.mode == EngineMode::Standalone) {
        remoteClient = new RemoteControlClient();
    }
    return true;
}

bool BugorEngine::initializePersistence() {
    if (!config.enable_persistence) return true;
    persistenceManager = new PersistenceManager();
    StorageConfig storageConfig;
    storageConfig.base_path = config.data_directory + "/data";
    if (!persistenceManager->initialize(storageConfig)) {
        delete persistenceManager;
        persistenceManager = nullptr;
        return false;
    }
    return true;
}

bool BugorEngine::initializeEncryption() {
    if (!config.enable_encryption) return true;
    encryptionManager = new EncryptionManager();
    SecurityConfig secConfig;
    if (!encryptionManager->initialize(secConfig)) {
        delete encryptionManager;
        encryptionManager = nullptr;
        return false;
    }
    return true;
}

bool BugorEngine::initializeDebugger() {
    if (!config.enable_debugger) return true;
    debugger = new Debugger();
    return true;
}

bool BugorEngine::initializeLogging() {
    loggingSystem = new BugorLogging::LoggingSystem();
    loggingSystem->initialize(config.log_directory + "/config.json");
    return true;
}

void BugorEngine::shutdownSubsystems() {
    shutdownLogging();
    shutdownDebugger();
    shutdownEncryption();
    shutdownPersistence();
    shutdownRemoteControl();
    shutdownAnalytics();
    shutdownScriptEngine();
    shutdownCrashReporter();
    shutdownHooking();
    shutdownMemoryManager();
}

void BugorEngine::shutdownMemoryManager() {
    if (memoryManager) {
        memoryManager->shutdown();
        delete memoryManager;
        memoryManager = nullptr;
    }
}

void BugorEngine::shutdownHooking() {
    if (hookingFramework) {
        hookingFramework->shutdown();
        delete hookingFramework;
        hookingFramework = nullptr;
    }
}

void BugorEngine::shutdownCrashReporter() {
    if (crashReporter) {
        crashReporter->shutdown();
        delete crashReporter;
        crashReporter = nullptr;
    }
}

void BugorEngine::shutdownScriptEngine() {
    if (scriptEngine) {
        scriptEngine->shutdown();
        delete scriptEngine;
        scriptEngine = nullptr;
    }
}

void BugorEngine::shutdownAnalytics() {
    if (analyticsEngine) {
        analyticsEngine->shutdown();
        delete analyticsEngine;
        analyticsEngine = nullptr;
    }
}

void BugorEngine::shutdownRemoteControl() {
    if (remoteServer) {
        remoteServer->shutdown();
        delete remoteServer;
        remoteServer = nullptr;
    }
    if (remoteClient) {
        remoteClient->shutdown();
        delete remoteClient;
        remoteClient = nullptr;
    }
}

void BugorEngine::shutdownPersistence() {
    if (persistenceManager) {
        persistenceManager->shutdown();
        delete persistenceManager;
        persistenceManager = nullptr;
    }
}

void BugorEngine::shutdownEncryption() {
    if (encryptionManager) {
        encryptionManager->shutdown();
        delete encryptionManager;
        encryptionManager = nullptr;
    }
}

void BugorEngine::shutdownDebugger() {
    if (debugger) {
        delete debugger;
        debugger = nullptr;
    }
}

void BugorEngine::shutdownLogging() {
    if (loggingSystem) {
        loggingSystem->shutdown();
        delete loggingSystem;
        loggingSystem = nullptr;
    }
}

void BugorEngine::collectMetrics() {
    struct sysinfo si;
    if (sysinfo(&si) == 0) {
        metrics.memory_usage = si.totalram - si.freeram;
        metrics.uptime_ms = si.uptime * 1000;
    }
}

void BugorEngine::metricsLoop() {
    while (backgroundThreadsRunning && metricsEnabled) {
        collectMetrics();
        std::this_thread::sleep_for(std::chrono::seconds(5));
    }
}

void BugorEngine::healthCheckLoop() {
    while (backgroundThreadsRunning) {
        runHealthCheck();
        std::this_thread::sleep_for(std::chrono::seconds(30));
    }
}

bool BugorEngine::createDirectories() {
    std::vector<std::string> dirs = {
        config.data_directory,
        config.log_directory,
        config.crash_dump_directory,
        config.script_directory,
        config.plugin_directory,
        config.temp_directory,
        config.cache_directory,
        config.data_directory + "/data",
        config.data_directory + "/saves",
        config.data_directory + "/scripts",
        config.data_directory + "/plugins",
        config.data_directory + "/configs"
    };

    for (auto &dir : dirs) {
        if (dir.empty()) continue;
        try {
            std::filesystem::create_directories(dir);
        } catch (...) {}
    }
    return true;
}
