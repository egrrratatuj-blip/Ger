#pragma once
#include <string>
#include <cstdint>
#include <vector>

bool BugorNativeInitialize(const char* configPath);
bool BugorNativeShutdown();
bool BugorNativeIsInitialized();
std::string BugorNativeGetVersion();
bool BugorNativeExecuteScript(const char* script);
std::string BugorNativeExecuteCommand(const char* command);
uintptr_t BugorNativeReadLong(uintptr_t address);
int BugorNativeReadInt(uintptr_t address);
float BugorNativeReadFloat(uintptr_t address);
double BugorNativeReadDouble(uintptr_t address);
bool BugorNativeWriteLong(uintptr_t address, uintptr_t value);
bool BugorNativeWriteInt(uintptr_t address, int value);
bool BugorNativeWriteFloat(uintptr_t address, float value);
bool BugorNativeWriteDouble(uintptr_t address, double value);
std::string BugorNativeSearchMemory(int valueType, uintptr_t value, int valueSize, uintptr_t regionStart, uintptr_t regionEnd);
bool BugorNativePatchMemory(uintptr_t address, const uint8_t* data, size_t len);
uintptr_t BugorNativeGetModuleBase(const char* moduleName);
std::string BugorNativeDumpMemory(uintptr_t address, int size);
int BugorNativeInstallHook(uintptr_t targetAddress, void* hookFunction);
bool BugorNativeUninstallHook(int hookId);
bool BugorNativeFreezeValue(uintptr_t address, uintptr_t value, int valueType);
bool BugorNativeUnfreezeValue(uintptr_t address);
bool BugorNativeUnfreezeAll();
bool BugorNativeProtectMemory(uintptr_t address, size_t size, int protection);
uintptr_t BugorNativeAllocateMemory(size_t size, int protection);
bool BugorNativeFreeMemory(uintptr_t address);
std::string BugorNativeGetRegions();
bool BugorNativeLoadScriptFile(const char* path);
bool BugorNativeLoadScript(const char* name, const char* source);
bool BugorNativeConnectRemote(const char* host, int port, const char* apiKey);
bool BugorNativeDisconnectRemote();
std::string BugorNativeSendRemoteCommand(const char* command, const char* args);
std::string BugorNativeEncrypt(const char* data, const char* key);
std::string BugorNativeDecrypt(const char* data, const char* key);
std::string BugorNativeHash(const char* data);
std::string BugorNativeGetMetrics();
void BugorNativeSetLogLevel(int level);
void BugorNativeLog(int level, const char* message);
bool BugorNativeAttachDebugger(int pid);
bool BugorNativeDetachDebugger();
bool BugorNativeSetBreakpoint(uintptr_t address);
bool BugorNativeStoreValue(const char* key, const char* value);
std::string BugorNativeLoadValue(const char* key);
bool BugorNativeDeleteValue(const char* key);
std::string BugorNativeGetHealthStatus();
void* BugorNativeGetEnginePointer();
int BugorNativeGetState();
bool BugorNativePause();
bool BugorNativeResume();
bool BugorNativeRestart();
std::string BugorNativeGetBuildInfo();
bool BugorNativeRegisterFunction(const char* name, void* funcPtr);
bool BugorNativeStartServer(int port);
bool BugorNativeStopServer();
