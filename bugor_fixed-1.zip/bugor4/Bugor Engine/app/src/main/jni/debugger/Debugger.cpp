#include "Debugger.h"
#include <sys/ptrace.h>
#include <sys/wait.h>
#include <cstdio>
#include <cerrno>
#include <cinttypes>
#include <sys/uio.h>
#include <sys/user.h>

Debugger::Debugger()
    : initialized(false)
    , attached(false)
    , running(false)
    , stopped(false)
    , loggingEnabled(false)
    , targetPid(0)
    , currentTid(0)
    , nextBreakpointId(1)
    , nextWatchpointId(1)
    , nextTracepointId(1)
    , eventThread(nullptr)
    , eventThreadRunning(false)
{
    memset(&debugInfo, 0, sizeof(debugInfo));
}

Debugger::~Debugger()
{
    shutdown();
}

bool Debugger::initialize(const DebuggerConfig &config)
{
    if (initialized) return true;
    this->config = config;
    initialized = true;
    return true;
}

void Debugger::shutdown()
{
    if (!initialized) return;
    eventThreadRunning = false;
    if (eventThread) { eventThread->join(); delete eventThread; eventThread = nullptr; }
    detach();
    removeAllBreakpoints();
    removeAllWatchpoints();
    initialized = false;
}

bool Debugger::isInitialized() const
{
    return initialized;
}

bool Debugger::attach(pid_t pid)
{
    if (!initialized || attached) return false;
    if (!ptraceAttach(pid)) return false;
    targetPid = pid;
    currentTid = pid;
    attached = true;
    debugInfo.pid = pid;
    debugInfo.attached = true;
    debugInfo.running = false;
    debugInfo.stopped = true;
    if (config.stop_on_attach) {
        int status;
        waitpid(pid, &status, 0);
    }
    if (config.break_on_entry) {
        addBreakpoint(config.exec_path);
    }
    eventThreadRunning = true;
    eventThread = new std::thread(&Debugger::eventLoop, this);
    if (processStartCallback) processStartCallback(pid);
    return true;
}

bool Debugger::detach()
{
    if (!attached) return false;
    eventThreadRunning = false;
    removeAllBreakpoints();
    ptraceDetach(targetPid);
    attached = false;
    debugInfo.attached = false;
    return true;
}

bool Debugger::launch(const std::string &path, const std::vector<std::string> &args)
{
    if (!initialized || attached) return false;
    pid_t pid = fork();
    if (pid == 0) {
        ptrace(PTRACE_TRACEME, 0, nullptr, nullptr);
        if (config.stop_on_start) raise(SIGSTOP);
        std::vector<char*> argv;
        argv.push_back(const_cast<char*>(path.c_str()));
        for (const auto &a : args) argv.push_back(const_cast<char*>(a.c_str()));
        argv.push_back(nullptr);
        if (config.follow_exec) ptrace(PTRACE_SETOPTIONS, 0, nullptr, PTRACE_O_TRACEEXEC);
        execvp(path.c_str(), argv.data());
        _exit(1);
    } else if (pid > 0) {
        targetPid = pid;
        currentTid = pid;
        attached = true;
        debugInfo.pid = pid;
        debugInfo.executable = path;
        debugInfo.attached = true;
        int status;
        waitpid(pid, &status, 0);
        if (config.follow_fork) {
            ptrace(PTRACE_SETOPTIONS, pid, nullptr, PTRACE_O_TRACEFORK);
        }
        eventThreadRunning = true;
        eventThread = new std::thread(&Debugger::eventLoop, this);
        if (processStartCallback) processStartCallback(pid);
        return true;
    }
    return false;
}

bool Debugger::terminate()
{
    if (!attached) return false;
    kill(targetPid, SIGKILL);
    detach();
    return true;
}

bool Debugger::restart()
{
    if (!attached) return false;
    std::string exe = debugInfo.executable;
    detach();
    return launch(exe);
}

bool Debugger::isAttached() const
{
    return attached;
}

bool Debugger::isRunning() const
{
    return running;
}

bool Debugger::isStopped() const
{
    return stopped;
}

bool Debugger::continue_()
{
    if (!attached) return false;
    stopped = false;
    running = true;
    return ptraceContinue(targetPid, 0);
}

bool Debugger::stepInto()
{
    if (!attached) return false;
    return ptraceSingleStep(targetPid);
}

bool Debugger::stepOver()
{
    if (!attached) return false;
    uintptr_t pc = getPC();
    uint8_t orig = 0;
    uint8_t bkpt = 0xCC;
    bool has_bkpt = false;
    if (breakpoints.find(nextBreakpointId) == breakpoints.end()) {
        readMemory(pc + 1, &orig, 1);
        writeMemory(pc + 1, &bkpt, 1);
        has_bkpt = true;
    }
    bool ret = continue_();
    if (has_bkpt) writeMemory(pc + 1, &orig, 1);
    return ret;
}

bool Debugger::stepOut()
{
    if (!attached) return false;
    uintptr_t lr = 0;
#if defined(__aarch64__)
    lr = getRegisterValue(30);
#else
    lr = getReturnAddress();
#endif
    if (lr == 0) return false;
    return stepUntil(lr);
}

bool Debugger::stepInstruction()
{
    return stepInto();
}

bool Debugger::stepRange(uintptr_t start, uintptr_t end)
{
    while (true) {
        uintptr_t pc = getPC();
        if (pc < start || pc >= end) break;
        if (!stepInto()) return false;
    }
    return true;
}

bool Debugger::stepUntil(uintptr_t address)
{
    uint64_t bp_id = addBreakpoint(address);
    if (bp_id == 0) return false;
    bool ret = continue_();
    if (ret) {
        int status;
        waitpid(targetPid, &status, 0);
    }
    removeBreakpoint(bp_id);
    return ret;
}

bool Debugger::stepOverInstruction()
{
    return stepOver();
}

bool Debugger::wait(uint32_t timeout_ms)
{
    return waitForStop(timeout_ms);
}

bool Debugger::waitForStop(uint32_t timeout_ms)
{
    int status;
    int options = 0;
    pid_t ret;
    if (timeout_ms > 0) {
        ret = waitpid(targetPid, &status, WNOHANG);
        if (ret == 0) {
            usleep(timeout_ms * 1000);
            ret = waitpid(targetPid, &status, WNOHANG);
        }
    } else {
        ret = waitpid(targetPid, &status, 0);
    }
    if (ret > 0) {
        stopped = true;
        running = false;
        debugInfo.status = status;
        if (WIFEXITED(status)) {
            debugInfo.exit_code = WEXITSTATUS(status);
            debugInfo.terminated = true;
            if (processExitCallback) processExitCallback(debugInfo.exit_code);
        }
        return true;
    }
    return false;
}

bool Debugger::waitForSignal(int signum, uint32_t timeout_ms)
{
    uint64_t start = static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count());
    while (true) {
        uint64_t now = static_cast<uint64_t>(
            std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::steady_clock::now().time_since_epoch()).count());
        if (now - start > timeout_ms) return false;
        int status;
        pid_t ret = waitpid(targetPid, &status, WNOHANG);
        if (ret > 0 && WIFSTOPPED(status) && WSTOPSIG(status) == signum) return true;
        usleep(1000);
    }
}

bool Debugger::waitForEvent(uint32_t timeout_ms)
{
    return waitForStop(timeout_ms);
}

uint64_t Debugger::addBreakpoint(uintptr_t address)
{
    if (!initialized || address == 0) return 0;
    std::lock_guard<std::mutex> lock(breakpointMutex);
    Breakpoint bp;
    bp.id = nextBreakpointId++;
    bp.address = address;
    bp.breakpoint_byte = 0x00;
#if defined(__aarch64__)
    bp.breakpoint_byte = 0x00;
#elif defined(__arm__)
    bp.breakpoint_byte = 0x70;
#else
    bp.breakpoint_byte = 0xCC;
#endif
    bp.enabled = true;
    bp.hit_count = 0;
    bp.hardware = config.hardware_breakpoints;
    readMemory(address, &bp.original_bytes, sizeof(bp.original_bytes));
    if (!insertBreakpoint(bp)) return 0;
    breakpoints[bp.id] = bp;
    return bp.id;
}

uint64_t Debugger::addBreakpoint(const std::string &symbol)
{
    uintptr_t addr = getSymbolAddress(symbol);
    if (addr == 0) return 0;
    return addBreakpoint(addr);
}

uint64_t Debugger::addBreakpoint(const std::string &module, const std::string &function)
{
    std::string full = module + "!" + function;
    return addBreakpoint(full);
}

bool Debugger::removeBreakpoint(uint64_t breakpoint_id)
{
    std::lock_guard<std::mutex> lock(breakpointMutex);
    auto it = breakpoints.find(breakpoint_id);
    if (it == breakpoints.end()) return false;
    removeBreakpoint(it->second);
    breakpoints.erase(it);
    return true;
}

bool Debugger::removeAllBreakpoints()
{
    std::lock_guard<std::mutex> lock(breakpointMutex);
    for (auto &kv : breakpoints) {
        if (kv.second.enabled) removeBreakpoint(kv.second);
    }
    breakpoints.clear();
    return true;
}

bool Debugger::enableBreakpoint(uint64_t breakpoint_id)
{
    std::lock_guard<std::mutex> lock(breakpointMutex);
    auto it = breakpoints.find(breakpoint_id);
    if (it == breakpoints.end()) return false;
    it->second.enabled = true;
    return insertBreakpoint(it->second);
}

bool Debugger::disableBreakpoint(uint64_t breakpoint_id)
{
    std::lock_guard<std::mutex> lock(breakpointMutex);
    auto it = breakpoints.find(breakpoint_id);
    if (it == breakpoints.end()) return false;
    it->second.enabled = false;
    return removeBreakpoint(it->second);
}

bool Debugger::isBreakpointEnabled(uint64_t breakpoint_id) const
{
    auto it = breakpoints.find(breakpoint_id);
    return it != breakpoints.end() && it->second.enabled;
}

Breakpoint Debugger::getBreakpoint(uint64_t breakpoint_id) const
{
    auto it = breakpoints.find(breakpoint_id);
    return it != breakpoints.end() ? it->second : Breakpoint();
}

std::vector<Breakpoint> Debugger::getBreakpoints() const
{
    std::vector<Breakpoint> result;
    for (const auto &kv : breakpoints) result.push_back(kv.second);
    return result;
}

uint64_t Debugger::addWatchpoint(uintptr_t address, size_t size, int type)
{
    if (!initialized || address == 0) return 0;
    uint64_t id = nextWatchpointId++;
    watchpoints[id] = address;
    (void)size;
    (void)type;
    return id;
}

uint64_t Debugger::addWatchpoint(const std::string &variable)
{
    uintptr_t addr = getSymbolAddress(variable);
    if (addr == 0) return 0;
    return addWatchpoint(addr, sizeof(uint64_t), 0);
}

bool Debugger::removeWatchpoint(uint64_t watchpoint_id)
{
    return watchpoints.erase(watchpoint_id) > 0;
}

bool Debugger::removeAllWatchpoints()
{
    watchpoints.clear();
    return true;
}

std::vector<uint64_t> Debugger::getWatchpoints() const
{
    std::vector<uint64_t> ids;
    for (const auto &kv : watchpoints) ids.push_back(kv.first);
    return ids;
}

uint64_t Debugger::addTracepoint(uintptr_t address)
{
    uint64_t id = nextTracepointId++;
    TracePoint tp;
    tp.address = address;
    traceBuffer.push_back(tp);
    return id;
}

bool Debugger::removeTracepoint(uint64_t tracepoint_id)
{
    (void)tracepoint_id;
    return false;
}

bool Debugger::removeAllTracepoints()
{
    traceBuffer.clear();
    return true;
}

std::vector<TracePoint> Debugger::getTracePoints() const
{
    return traceBuffer;
}

bool Debugger::startTracing()
{
    config.trace_instructions = true;
    return true;
}

bool Debugger::stopTracing()
{
    config.trace_instructions = false;
    return true;
}

bool Debugger::isTracing() const
{
    return config.trace_instructions;
}

bool Debugger::readMemory(uintptr_t address, void *buffer, size_t size)
{
    if (!attached) return false;
    return ptraceReadMemory(targetPid, address, buffer, size);
}

bool Debugger::writeMemory(uintptr_t address, const void *data, size_t size)
{
    if (!attached) return false;
    return ptraceWriteMemory(targetPid, address, data, size);
}

std::vector<uint8_t> Debugger::readMemory(uintptr_t address, size_t size)
{
    std::vector<uint8_t> result(size);
    if (!ptraceReadMemory(targetPid, address, result.data(), size)) result.clear();
    return result;
}

std::string Debugger::readString(uintptr_t address, size_t max_size)
{
    std::string result;
    result.reserve(max_size);
    for (size_t i = 0; i < max_size; ++i) {
        uint8_t c = 0;
        if (!ptraceReadMemory(targetPid, address + i, &c, 1)) break;
        if (c == '\0') break;
        result.push_back(static_cast<char>(c));
    }
    return result;
}

bool Debugger::writeString(uintptr_t address, const std::string &str)
{
    return writeMemory(address, str.c_str(), str.size() + 1);
}

uint64_t Debugger::readRegister(const std::string &name)
{
    if (!attached) return 0;
    struct user_regs_struct regs;
    if (!ptraceGetRegs(targetPid, regs)) return 0;
    int id = getRegisterId(name);
    if (id < 0) return 0;
    return getRegisterValue(id);
}

bool Debugger::writeRegister(const std::string &name, uint64_t value)
{
    if (!attached) return false;
    struct user_regs_struct regs;
    if (!ptraceGetRegs(targetPid, regs)) return false;
    int id = getRegisterId(name);
    if (id < 0) return false;
    uint64_t *reg_array = reinterpret_cast<uint64_t*>(&regs);
    if (static_cast<size_t>(id) < sizeof(user_regs_struct) / sizeof(uint64_t)) {
        reg_array[id] = value;
        return ptraceSetRegs(targetPid, regs);
    }
    return false;
}

std::map<std::string, uint64_t> Debugger::readAllRegisters()
{
    std::map<std::string, uint64_t> regs;
    struct user_regs_struct pt_regs;
    if (!ptraceGetRegs(targetPid, pt_regs)) return regs;
    uint64_t *ptr = reinterpret_cast<uint64_t*>(&pt_regs);
    auto names = getRegisterNames();
    for (size_t i = 0; i < names.size() && i < sizeof(user_regs_struct) / sizeof(uint64_t); ++i) {
        regs[names[i]] = ptr[i];
    }
    return regs;
}

bool Debugger::writeAllRegisters(const std::map<std::string, uint64_t> &regs)
{
    struct user_regs_struct pt_regs;
    if (!ptraceGetRegs(targetPid, pt_regs)) return false;
    uint64_t *ptr = reinterpret_cast<uint64_t*>(&pt_regs);
    for (const auto &kv : regs) {
        int id = getRegisterId(kv.first);
        if (id >= 0 && static_cast<size_t>(id) < sizeof(user_regs_struct) / sizeof(uint64_t)) {
            ptr[id] = kv.second;
        }
    }
    return ptraceSetRegs(targetPid, pt_regs);
}

std::string Debugger::printRegisters()
{
    std::ostringstream oss;
    auto regs = readAllRegisters();
    for (const auto &kv : regs) {
        oss << kv.first << " = 0x" << std::hex << kv.second << std::dec << "\n";
    }
    return oss.str();
}

uintptr_t Debugger::getRegisterValue(int reg_id)
{
    struct user_regs_struct regs;
    if (!ptraceGetRegs(targetPid, regs)) return 0;
    uint64_t *ptr = reinterpret_cast<uint64_t*>(&regs);
    size_t num_regs = sizeof(user_regs_struct) / sizeof(uint64_t);
    if (static_cast<size_t>(reg_id) < num_regs) return static_cast<uintptr_t>(ptr[reg_id]);
    return 0;
}

int Debugger::getRegisterId(const std::string &name)
{
    auto names = getRegisterNames();
    for (size_t i = 0; i < names.size(); ++i) {
        if (names[i] == name) return static_cast<int>(i);
    }
    return -1;
}

std::string Debugger::getRegisterName(int reg_id)
{
    auto names = getRegisterNames();
    if (static_cast<size_t>(reg_id) < names.size()) return names[reg_id];
    return "unknown";
}

std::vector<std::string> Debugger::getRegisterNames() const
{
    std::vector<std::string> names;
#if defined(__aarch64__)
    for (int i = 0; i < 31; ++i) names.push_back("x" + std::to_string(i));
    names.push_back("sp");
    names.push_back("pc");
    names.push_back("pstate");
#elif defined(__x86_64__)
    names = {"rax", "rbx", "rcx", "rdx", "rsi", "rdi", "rbp", "rsp",
             "r8", "r9", "r10", "r11", "r12", "r13", "r14", "r15",
             "rip", "rflags", "cs", "ss", "ds", "es", "fs", "gs", "orig_rax"};
#else
    names = {"eax", "ebx", "ecx", "edx", "esi", "edi", "ebp", "esp", "eip"};
#endif
    return names;
}

bool Debugger::setPC(uintptr_t address)
{
    return writeRegister("pc", address);
}

uintptr_t Debugger::getPC()
{
    return getRegisterValue(static_cast<int>(
        sizeof(user_regs_struct) / sizeof(uint64_t) - 3));
}

uintptr_t Debugger::getSP()
{
#if defined(__aarch64__)
    return getRegisterValue(31);
#elif defined(__x86_64__)
    return getRegisterValue(getRegisterId("rsp"));
#else
    return getRegisterValue(getRegisterId("esp"));
#endif
}

uintptr_t Debugger::getBP()
{
#if defined(__aarch64__)
    return getRegisterValue(29);
#elif defined(__x86_64__)
    return getRegisterValue(getRegisterId("rbp"));
#else
    return getRegisterValue(getRegisterId("ebp"));
#endif
}

uintptr_t Debugger::getReturnAddress()
{
#if defined(__aarch64__)
    return getRegisterValue(30);
#else
    return readMemory(getSP(), sizeof(uintptr_t));
#endif
}

bool Debugger::readFloats(uintptr_t address, float *buffer, size_t count)
{
    return readMemory(address, buffer, count * sizeof(float));
}

bool Debugger::writeFloats(uintptr_t address, const float *data, size_t count)
{
    return writeMemory(address, data, count * sizeof(float));
}

bool Debugger::readDoubles(uintptr_t address, double *buffer, size_t count)
{
    return readMemory(address, buffer, count * sizeof(double));
}

bool Debugger::writeDoubles(uintptr_t address, const double *data, size_t count)
{
    return writeMemory(address, data, count * sizeof(double));
}

bool Debugger::callFunction(uintptr_t address)
{
    return callFunction(address, {});
}

bool Debugger::callFunction(const std::string &function)
{
    return callFunction(function, {});
}

uintptr_t Debugger::callFunction(const std::string &function, const std::vector<uint64_t> &args)
{
    uintptr_t addr = getSymbolAddress(function);
    if (addr == 0) return 0;
    return callFunction(addr, args);
}

uintptr_t Debugger::callFunction(uintptr_t address, const std::vector<uint64_t> &args)
{
    if (!attached) return 0;
    struct user_regs_struct old_regs;
    if (!ptraceGetRegs(targetPid, old_regs)) return 0;
    struct user_regs_struct new_regs = old_regs;
    uint64_t *ptr = reinterpret_cast<uint64_t*>(&new_regs);
    for (size_t i = 0; i < args.size() && i < 6; ++i) {
#if defined(__aarch64__)
        ptr[i] = args[i];
#else
        ptr[i] = args[i];
#endif
    }
    ptr[getRegisterId("pc")] = address;
    uintptr_t orig_pc = getPC();
    uintptr_t ret_addr = orig_pc;
    ptr[getRegisterId("lr")] = ret_addr;
    if (!ptraceSetRegs(targetPid, new_regs)) return 0;
    if (!ptraceContinue(targetPid, 0)) return 0;
    int status;
    waitpid(targetPid, &status, 0);
    if (WIFSTOPPED(status)) {
        struct user_regs_struct result_regs;
        ptraceGetRegs(targetPid, result_regs);
        uint64_t ret = reinterpret_cast<uint64_t*>(&result_regs)[0];
        return static_cast<uintptr_t>(ret);
    }
    return 0;
}

bool Debugger::injectCode(const std::vector<uint8_t> &code, uintptr_t &address)
{
    address = allocateMemory(code.size());
    if (address == 0) return false;
    return writeMemory(address, code.data(), code.size());
}

bool Debugger::injectCode(const std::string &code_hex, uintptr_t &address)
{
    std::vector<uint8_t> code;
    for (size_t i = 0; i < code_hex.size(); i += 2) {
        uint8_t byte = 0;
        for (int j = 0; j < 2 && i + j < code_hex.size(); ++j) {
            char c = code_hex[i + j];
            byte <<= 4;
            if (c >= '0' && c <= '9') byte |= (c - '0');
            else if (c >= 'a' && c <= 'f') byte |= (10 + c - 'a');
            else if (c >= 'A' && c <= 'F') byte |= (10 + c - 'A');
        }
        code.push_back(byte);
    }
    return injectCode(code, address);
}

bool Debugger::injectLibrary(const std::string &path)
{
    void *handle = dlopen(path.c_str(), RTLD_LAZY);
    return handle != nullptr;
}

bool Debugger::injectShellcode(const std::vector<uint8_t> &shellcode)
{
    uintptr_t addr = 0;
    if (!injectCode(shellcode, addr)) return false;
    return callFunction(addr) != 0;
}

std::vector<DebugSymbol> Debugger::enumerateSymbols(const std::string &module)
{
    if (module.empty()) return symbols;
    std::vector<DebugSymbol> result;
    for (const auto &s : symbols) {
        if (s.module_name == module) result.push_back(s);
    }
    return result;
}

DebugSymbol Debugger::findSymbol(const std::string &name)
{
    for (const auto &s : symbols) {
        if (s.name == name || s.demangled_name == name) return s;
    }
    return DebugSymbol();
}

DebugSymbol Debugger::findSymbol(uintptr_t address)
{
    for (const auto &s : symbols) {
        if (s.address == address) return s;
    }
    return DebugSymbol();
}

std::string Debugger::getSymbolName(uintptr_t address)
{
    auto sym = findSymbol(address);
    return sym.name.empty() ? ("0x" + std::to_string(address)) : sym.name;
}

uintptr_t Debugger::getSymbolAddress(const std::string &name)
{
    auto sym = findSymbol(name);
    return sym.address;
}

std::vector<CodeRegion> Debugger::getCodeRegions()
{
    return codeRegions;
}

std::string Debugger::disassemble(uintptr_t address, uint32_t count)
{
    std::ostringstream oss;
    std::vector<uint8_t> code(count * 4);
    if (!readMemory(address, code.data(), code.size())) return "";
    for (uint32_t i = 0; i < count; ++i) {
        oss << "0x" << std::hex << (address + i * 4) << std::dec << ": ";
        for (int j = 0; j < 4; ++j) {
            if (i * 4 + j < static_cast<uint32_t>(code.size())) {
                oss << std::hex << std::setw(2) << std::setfill('0')
                    << static_cast<int>(code[i * 4 + j]) << " ";
            }
        }
        oss << "\n";
    }
    return oss.str();
}

std::string Debugger::disassembleRange(uintptr_t start, uintptr_t end)
{
    uint32_t count = static_cast<uint32_t>((end - start) / 4);
    return disassemble(start, count);
}

std::string Debugger::disassembleFunction(const std::string &function)
{
    uintptr_t addr = getSymbolAddress(function);
    if (addr == 0) return "";
    return disassemble(addr, config.disassembly_lines > 0 ? config.disassembly_lines : 10);
}

std::string Debugger::disassembleCurrent()
{
    return disassemble(getPC(), config.disassembly_lines > 0 ? config.disassembly_lines : 10);
}

std::vector<std::string> Debugger::getBacktrace(uint32_t max_depth)
{
    std::vector<std::string> bt;
    uintptr_t fp = getBP();
    uintptr_t pc = getPC();
    uintptr_t lr = getReturnAddress();
    for (uint32_t i = 0; i < max_depth && fp != 0; ++i) {
        std::string frame = "#" + std::to_string(i) + " 0x" + std::to_string(pc);
        std::string name = getSymbolName(pc);
        if (!name.empty()) frame += " " + name;
        bt.push_back(frame);
        if (pc == lr || i == 0) {
            pc = lr;
        } else {
            if (!readMemory(fp + sizeof(uintptr_t), &pc, sizeof(pc))) break;
        }
        if (!readMemory(fp, &fp, sizeof(fp))) break;
    }
    return bt;
}

std::string Debugger::printBacktrace(uint32_t max_depth)
{
    std::ostringstream oss;
    auto bt = getBacktrace(max_depth);
    for (const auto &frame : bt) oss << frame << "\n";
    return oss.str();
}

std::vector<uintptr_t> Debugger::getBacktraceAddresses(uint32_t max_depth)
{
    std::vector<uintptr_t> addrs;
    auto bt = getBacktrace(max_depth);
    for (const auto &frame : bt) {
        size_t pos = frame.find("0x");
        if (pos != std::string::npos) {
            addrs.push_back(std::stoull(frame.substr(pos), nullptr, 16));
        }
    }
    return addrs;
}

std::vector<std::string> Debugger::getStack(uintptr_t sp, uint32_t count)
{
    if (sp == 0) sp = getSP();
    std::vector<std::string> stack;
    for (uint32_t i = 0; i < count; ++i) {
        uintptr_t val = 0;
        if (ptraceReadMemory(targetPid, sp + i * sizeof(uintptr_t), &val, sizeof(val))) {
            std::ostringstream oss;
            oss << "0x" << std::hex << std::setw(16) << std::setfill('0') << (sp + i * sizeof(uintptr_t))
                << ":  0x" << std::setw(16) << std::setfill('0') << val;
            stack.push_back(oss.str());
        }
    }
    return stack;
}

std::string Debugger::printStack(uintptr_t sp, uint32_t count)
{
    std::ostringstream oss;
    for (const auto &line : getStack(sp, count)) oss << line << "\n";
    return oss.str();
}

std::vector<DebugInfo> Debugger::enumerateThreads()
{
    std::vector<DebugInfo> threads;
    DebugInfo main = getDebugInfo();
    threads.push_back(main);
    return threads;
}

DebugInfo Debugger::getThreadInfo(pid_t tid)
{
    DebugInfo info;
    info.tid = tid;
    return info;
}

pid_t Debugger::getCurrentThread()
{
    return currentTid;
}

bool Debugger::switchToThread(pid_t tid)
{
    currentTid = tid;
    return true;
}

bool Debugger::suspendThread(pid_t tid)
{
    return kill(tid, SIGSTOP) == 0;
}

bool Debugger::resumeThread(pid_t tid)
{
    return kill(tid, SIGCONT) == 0;
}

bool Debugger::suspendAllThreads()
{
    return suspendThread(targetPid);
}

bool Debugger::resumeAllThreads()
{
    return resumeThread(targetPid);
}

bool Debugger::handleSyscall()
{
    return true;
}

bool Debugger::handleSignal()
{
    return true;
}

bool Debugger::handleException()
{
    return true;
}

DebugInfo Debugger::getDebugInfo() const
{
    return debugInfo;
}

DebuggerConfig Debugger::getConfig() const
{
    return config;
}

std::string Debugger::getTargetExecutable() const
{
    return debugInfo.executable;
}

pid_t Debugger::getTargetPid() const
{
    return targetPid;
}

bool Debugger::loadSymbols(const std::string &path)
{
    return loadSymbolsFromFile(path);
}

bool Debugger::loadSymbolsFromFile(const std::string &path)
{
    std::ifstream in(path);
    if (!in.is_open()) return false;
    std::string line;
    while (std::getline(in, line)) {
        size_t space = line.find(' ');
        if (space == std::string::npos) continue;
        DebugSymbol sym;
        sym.address = std::stoull(line.substr(0, space), nullptr, 16);
        sym.name = line.substr(space + 1);
        symbols.push_back(sym);
    }
    return true;
}

bool Debugger::loadSymbolsFromModule(const std::string &module)
{
    return parseElfSymbols(module, symbols);
}

bool Debugger::saveCoreDump(const std::string &path)
{
    std::ofstream out(path, std::ios::binary);
    if (!out.is_open()) return false;
    auto regions = getCodeRegions();
    for (const auto &r : regions) {
        std::vector<uint8_t> data(r.size);
        if (readMemory(r.start, data.data(), r.size)) {
            out.write(reinterpret_cast<const char*>(data.data()), data.size());
        }
    }
    return out.good();
}

bool Debugger::loadCoreDump(const std::string &path)
{
    (void)path;
    return false;
}

bool Debugger::saveSession(const std::string &path)
{
    std::ofstream out(path, std::ios::binary);
    if (!out.is_open()) return false;
    uint32_t count = static_cast<uint32_t>(breakpoints.size());
    out.write(reinterpret_cast<const char*>(&count), sizeof(count));
    for (const auto &kv : breakpoints) {
        out.write(reinterpret_cast<const char*>(&kv.second.address), sizeof(kv.second.address));
        out.write(reinterpret_cast<const char*>(&kv.second.original_bytes), sizeof(kv.second.original_bytes));
    }
    return out.good();
}

bool Debugger::loadSession(const std::string &path)
{
    std::ifstream in(path, std::ios::binary);
    if (!in.is_open()) return false;
    uint32_t count = 0;
    in.read(reinterpret_cast<char*>(&count), sizeof(count));
    for (uint32_t i = 0; i < count; ++i) {
        Breakpoint bp;
        in.read(reinterpret_cast<char*>(&bp.address), sizeof(bp.address));
        in.read(reinterpret_cast<char*>(&bp.original_bytes), sizeof(bp.original_bytes));
        bp.id = nextBreakpointId++;
        bp.enabled = true;
        breakpoints[bp.id] = bp;
    }
    return true;
}

void Debugger::enableLogging(bool enable)
{
    loggingEnabled = enable;
}

bool Debugger::isLoggingEnabled() const
{
    return loggingEnabled;
}

void Debugger::onBreakpointHit(std::function<void(const Breakpoint&)> callback)
{
    breakpointCallback = callback;
}

void Debugger::onWatchpointHit(std::function<void(uintptr_t, size_t)> callback)
{
    watchpointCallback = callback;
}

void Debugger::onSignal(std::function<void(int)> callback)
{
    signalCallback = callback;
}

void Debugger::onException(std::function<void(int)> callback)
{
    exceptionCallback = callback;
}

void Debugger::onSyscall(std::function<void(int, uint64_t*)> callback)
{
    syscallCallback = callback;
}

void Debugger::onProcessStart(std::function<void(pid_t)> callback)
{
    processStartCallback = callback;
}

void Debugger::onProcessExit(std::function<void(int)> callback)
{
    processExitCallback = callback;
}

void Debugger::onThreadCreate(std::function<void(pid_t)> callback)
{
    threadCreateCallback = callback;
}

void Debugger::onThreadExit(std::function<void(pid_t)> callback)
{
    threadExitCallback = callback;
}

void Debugger::onLibraryLoad(std::function<void(const std::string&, uintptr_t)> callback)
{
    libraryLoadCallback = callback;
}

void Debugger::onLibraryUnload(std::function<void(const std::string&)> callback)
{
    libraryUnloadCallback = callback;
}

bool Debugger::ptraceAttach(pid_t pid)
{
    return ptrace(PTRACE_ATTACH, pid, nullptr, nullptr) == 0;
}

bool Debugger::ptraceDetach(pid_t pid)
{
    return ptrace(PTRACE_DETACH, pid, nullptr, nullptr) == 0;
}

bool Debugger::ptraceContinue(pid_t pid, int signal)
{
    return ptrace(PTRACE_CONT, pid, nullptr, signal) == 0;
}

bool Debugger::ptraceSingleStep(pid_t pid)
{
    return ptrace(PTRACE_SINGLESTEP, pid, nullptr, 0) == 0;
}

bool Debugger::ptraceSyscall(pid_t pid)
{
    return ptrace(PTRACE_SYSCALL, pid, nullptr, 0) == 0;
}

bool Debugger::ptraceGetRegs(pid_t pid, struct user_regs_struct &regs)
{
    struct iovec iov;
    iov.iov_base = &regs;
    iov.iov_len = sizeof(regs);
    return ptrace(PTRACE_GETREGSET, pid, NT_PRSTATUS, &iov) == 0;
}

bool Debugger::ptraceSetRegs(pid_t pid, const struct user_regs_struct &regs)
{
    struct iovec iov;
    iov.iov_base = const_cast<user_regs_struct*>(&regs);
    iov.iov_len = sizeof(regs);
    return ptrace(PTRACE_SETREGSET, pid, NT_PRSTATUS, &iov) == 0;
}

bool Debugger::ptraceGetFPRegs(pid_t pid, struct user_fpregs_struct &fpregs)
{
    struct iovec iov;
    iov.iov_base = &fpregs;
    iov.iov_len = sizeof(fpregs);
    return ptrace(PTRACE_GETREGSET, pid, NT_FPREGSET, &iov) == 0;
}

bool Debugger::ptraceSetFPRegs(pid_t pid, const struct user_fpregs_struct &fpregs)
{
    struct iovec iov;
    iov.iov_base = const_cast<user_fpregs_struct*>(&fpregs);
    iov.iov_len = sizeof(fpregs);
    return ptrace(PTRACE_SETREGSET, pid, NT_FPREGSET, &iov) == 0;
}

bool Debugger::ptraceReadMemory(pid_t pid, uintptr_t addr, void *buffer, size_t size)
{
    size_t words = (size + sizeof(long) - 1) / sizeof(long);
    unsigned char *dst = static_cast<unsigned char*>(buffer);
    for (size_t i = 0; i < words; ++i) {
        errno = 0;
        long word = ptrace(PTRACE_PEEKDATA, pid, reinterpret_cast<void*>(addr + i * sizeof(long)), nullptr);
        if (word == -1 && errno != 0) return false;
        memcpy(dst + i * sizeof(long), &word, std::min(sizeof(long), size - i * sizeof(long)));
    }
    return true;
}

bool Debugger::ptraceWriteMemory(pid_t pid, uintptr_t addr, const void *data, size_t size)
{
    size_t words = (size + sizeof(long) - 1) / sizeof(long);
    const unsigned char *src = static_cast<const unsigned char*>(data);
    for (size_t i = 0; i < words; ++i) {
        unsigned long word = 0;
        memcpy(&word, src + i * sizeof(long), std::min(sizeof(long), size - i * sizeof(long)));
        if (ptrace(PTRACE_POKEDATA, pid, reinterpret_cast<void*>(addr + i * sizeof(long)), reinterpret_cast<void*>(word)) != 0) return false;
    }
    return true;
}

bool Debugger::ptracePeekText(pid_t pid, uintptr_t addr, void *buffer, size_t size)
{
    return ptraceReadMemory(pid, addr, buffer, size);
}

bool Debugger::ptracePokeText(pid_t pid, uintptr_t addr, const void *data, size_t size)
{
    return ptraceWriteMemory(pid, addr, data, size);
}

bool Debugger::ptraceGetEventMsg(pid_t pid, unsigned long &msg)
{
    return ptrace(PTRACE_GETEVENTMSG, pid, nullptr, &msg) == 0;
}

bool Debugger::insertBreakpoint(Breakpoint &bp)
{
    if (!attached) return false;
    uint8_t orig = 0;
    if (!ptraceReadMemory(targetPid, bp.address, &orig, 1)) return false;
    bp.original_bytes = orig;
    if (!ptraceWriteMemory(targetPid, bp.address, &bp.breakpoint_byte, 1)) return false;
    return true;
}

bool Debugger::removeBreakpoint(Breakpoint &bp)
{
    if (!attached) return false;
    return ptraceWriteMemory(targetPid, bp.address, &bp.original_bytes, sizeof(bp.original_bytes));
}

bool Debugger::handleBreakpointHit(pid_t tid)
{
    (void)tid;
    for (auto &kv : breakpoints) {
        if (kv.second.address == getPC() - 1 || kv.second.address == getPC()) {
            ++kv.second.hit_count;
            if (breakpointCallback) breakpointCallback(kv.second);
            return true;
        }
    }
    return false;
}

bool Debugger::handleWatchpointHit(pid_t tid, uintptr_t addr)
{
    (void)tid;
    (void)addr;
    return false;
}

void Debugger::eventLoop()
{
    while (eventThreadRunning && attached) {
        int status;
        pid_t pid = waitpid(targetPid, &status, WNOHANG);
        if (pid > 0) handleEvent(pid, status);
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
}

void Debugger::handleEvent(pid_t pid, int status)
{
    if (WIFEXITED(status)) {
        debugInfo.terminated = true;
        debugInfo.exit_code = WEXITSTATUS(status);
        if (processExitCallback) processExitCallback(debugInfo.exit_code);
        eventThreadRunning = false;
    } else if (WIFSTOPPED(status)) {
        int sig = WSTOPSIG(status);
        if (sig == SIGTRAP) {
            handleBreakpointHit(pid);
            stopped = true;
            running = false;
        } else if (signalCallback) {
            signalCallback(sig);
        }
    }
}

bool Debugger::findMainModule()
{
    return true;
}

bool Debugger::enumerateMemoryRegions()
{
    return true;
}

bool Debugger::enumerateSymbolsForModule(const std::string &module)
{
    return parseElfSymbols(module, symbols);
}

bool Debugger::parseElfSymbols(const std::string &module, std::vector<DebugSymbol> &symbols)
{
    (void)module;
    (void)symbols;
    return false;
}

bool Debugger::parseDWARFInfo(const std::string &module)
{
    (void)module;
    return false;
}

bool Debugger::loadSymbolTable(const std::string &path)
{
    return loadSymbolsFromFile(path);
}

uintptr_t Debugger::resolveAddress(const std::string &expression)
{
    if (expression.find("0x") == 0 || expression.find("0X") == 0) {
        return std::stoull(expression, nullptr, 16);
    }
    return getSymbolAddress(expression);
}

bool Debugger::setupPtraceOptions()
{
    if (!attached) return false;
    long options = 0;
    if (config.follow_fork) options |= PTRACE_O_TRACEFORK;
    if (config.follow_exec) options |= PTRACE_O_TRACEEXEC;
    return ptrace(PTRACE_SETOPTIONS, targetPid, nullptr, options) == 0;
}

bool Debugger::waitForProcess(pid_t pid, int &status, int options)
{
    return waitpid(pid, &status, options) > 0;
}

bool Debugger::redirectIO(const std::string &input, const std::string &output, const std::string &error)
{
    (void)input;
    (void)output;
    (void)error;
    return false;
}

bool Debugger::setupEnvironment(std::vector<std::string> &env)
{
    (void)env;
    return true;
}

bool Debugger::disableASLR()
{
    return true;
}

bool Debugger::execChild(const std::string &path, char **argv, char **envp)
{
    return execve(path.c_str(), argv, envp) == 0;
}

void Debugger::logDebug(const std::string &message)
{
    if (loggingEnabled) {
        std::cerr << "[DEBUGGER] " << message << std::endl;
    }
}

std::string Debugger::statusToString(int status) const
{
    if (WIFEXITED(status)) return "Exited with code " + std::to_string(WEXITSTATUS(status));
    if (WIFSIGNALED(status)) return "Killed by signal " + std::to_string(WTERMSIG(status));
    if (WIFSTOPPED(status)) return "Stopped by signal " + std::to_string(WSTOPSIG(status));
    return "Unknown";
}

std::string Debugger::signalToString(int signum) const
{
    switch (signum) {
        case SIGINT: return "SIGINT";
        case SIGILL: return "SIGILL";
        case SIGABRT: return "SIGABRT";
        case SIGFPE: return "SIGFPE";
        case SIGSEGV: return "SIGSEGV";
        case SIGTERM: return "SIGTERM";
        case SIGTRAP: return "SIGTRAP (breakpoint)";
        default: return "SIGNAL_" + std::to_string(signum);
    }
}

std::string Debugger::syscallToString(int syscall_num) const
{
    (void)syscall_num;
    return "syscall_" + std::to_string(syscall_num);
}
