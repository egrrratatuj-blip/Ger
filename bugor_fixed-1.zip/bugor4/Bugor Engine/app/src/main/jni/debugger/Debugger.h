#ifndef BUGOR_DEBUGGER_H
#define BUGOR_DEBUGGER_H

#include <string>
#include <vector>
#include <map>
#include <functional>
#include <memory>
#include <mutex>
#include <atomic>
#include <thread>
#include <chrono>
#include <queue>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <algorithm>
#include <set>
#include <cstdint>
#include <cstring>
#include <sys/ptrace.h>
#include <sys/wait.h>
#include <sys/user.h>
#include <sys/uio.h>
#include <sys/syscall.h>
#include <sys/reg.h>
#include <unistd.h>
#include <fcntl.h>
#include <elf.h>
#include <dlfcn.h>

#if defined(__x86_64__) || defined(__i386__)
struct RegisterState {
    uint64_t rax, rbx, rcx, rdx;
    uint64_t rsi, rdi, rbp, rsp;
    uint64_t r8, r9, r10, r11;
    uint64_t r12, r13, r14, r15;
    uint64_t rip, rflags;
    uint64_t cs, ss, ds, es, fs, gs;
    uint64_t orig_rax;
    uint64_t fs_base, gs_base;
};
#endif

struct ARMRegisterState {
    uint64_t x[31];
    uint64_t sp, pc, pstate;
    uint32_t w[31];
    uint64_t q[32];
    uint64_t tpidr, tpidrro;
};

struct Breakpoint {
    uint64_t id;
    uintptr_t address;
    uintptr_t original_bytes;
    uint8_t breakpoint_byte;
    bool enabled;
    bool one_shot;
    bool temporary;
    bool hardware;
    bool conditional;
    uint32_t hit_count;
    uint32_t max_hits;
    std::string condition;
    std::string command;
    std::function<bool()> condition_fn;
    std::function<void()> callback;
};

struct DebugSymbol {
    uintptr_t address;
    std::string name;
    std::string demangled_name;
    std::string module_name;
    std::string source_file;
    uint32_t source_line;
    uint32_t size;
    uint16_t type;
    bool is_function;
    bool is_variable;
    bool is_public;
    bool is_static;
    bool is_exported;
};

struct CodeRegion {
    uintptr_t start;
    uintptr_t end;
    uint32_t size;
    uint32_t protection;
    std::string name;
    std::vector<uint8_t> code;
};

struct TracePoint {
    uintptr_t address;
    uint64_t timestamp;
    uint32_t thread_id;
    std::string thread_name;
    uint64_t registers[32];
    std::vector<uint8_t> stack_data;
    uint32_t stack_depth;
    std::string function_name;
    std::string source_file;
    uint32_t source_line;
};

struct DebuggerConfig {
    int attach_pid;
    std::string exec_path;
    std::vector<std::string> args;
    std::vector<std::string> env;
    uint32_t max_breakpoints;
    uint32_t max_watchpoints;
    uint32_t max_tracepoints;
    uint32_t trace_buffer_size;
    uint32_t max_stack_depth;
    uint32_t disassembly_lines;
    uint32_t disassembly_context;
    bool attach_existing;
    bool follow_fork;
    bool follow_exec;
    bool stop_on_start;
    bool stop_on_entry;
    bool stop_on_exit;
    bool stop_on_attach;
    bool stop_on_error;
    bool auto_continue;
    bool break_on_entry;
    bool break_on_exit;
    bool break_on_syscall;
    bool break_on_signal;
    bool break_on_exception;
    bool break_on_library_load;
    bool break_on_thread_create;
    bool break_on_fork;
    bool aslr_enabled;
    bool non_stop_mode;
    bool async_mode;
    bool hardware_breakpoints;
    bool software_breakpoints;
    bool conditional_breakpoints;
    bool trace_instructions;
    bool trace_calls;
    bool trace_returns;
    bool trace_syscalls;
    bool trace_signals;
    bool trace_memory;
    bool log_commands;
    bool log_events;
    bool log_output;
    bool use_ptrace;
    bool use_gdb_server;
    bool use_jdwp;
    bool record_execution;
    bool replay_execution;
    bool reverse_execution;
};

struct DebugInfo {
    pid_t pid;
    pid_t tid;
    int status;
    int signal;
    int exit_code;
    int stop_reason;
    std::string executable;
    std::string cmdline;
    std::string cwd;
    uintptr_t entry_point;
    uintptr_t base_address;
    uintptr_t heap_start;
    uintptr_t heap_end;
    uintptr_t stack_start;
    uintptr_t stack_end;
    bool attached;
    bool running;
    bool stopped;
    bool terminated;
    bool core_dumped;
};

class Debugger {
public:
    Debugger();
    ~Debugger();

    bool initialize(const DebuggerConfig &config);
    void shutdown();
    bool isInitialized() const;

    bool attach(pid_t pid);
    bool detach();
    bool launch(const std::string &path, const std::vector<std::string> &args = {});
    bool terminate();
    bool restart();
    bool isAttached() const;
    bool isRunning() const;
    bool isStopped() const;

    bool continue_();
    bool stepInto();
    bool stepOver();
    bool stepOut();
    bool stepInstruction();
    bool stepRange(uintptr_t start, uintptr_t end);
    bool stepUntil(uintptr_t address);
    bool stepOverInstruction();

    bool wait(uint32_t timeout_ms = 5000);
    bool waitForStop(uint32_t timeout_ms = 5000);
    bool waitForSignal(int signum, uint32_t timeout_ms = 5000);
    bool waitForEvent(uint32_t timeout_ms = 5000);

    uint64_t addBreakpoint(uintptr_t address);
    uint64_t addBreakpoint(const std::string &symbol);
    uint64_t addBreakpoint(const std::string &module, const std::string &function);
    bool removeBreakpoint(uint64_t breakpoint_id);
    bool removeAllBreakpoints();
    bool enableBreakpoint(uint64_t breakpoint_id);
    bool disableBreakpoint(uint64_t breakpoint_id);
    bool isBreakpointEnabled(uint64_t breakpoint_id) const;
    Breakpoint getBreakpoint(uint64_t breakpoint_id) const;
    std::vector<Breakpoint> getBreakpoints() const;

    uint64_t addWatchpoint(uintptr_t address, size_t size, int type = 0);
    uint64_t addWatchpoint(const std::string &variable);
    bool removeWatchpoint(uint64_t watchpoint_id);
    bool removeAllWatchpoints();
    std::vector<uint64_t> getWatchpoints() const;

    uint64_t addTracepoint(uintptr_t address);
    bool removeTracepoint(uint64_t tracepoint_id);
    bool removeAllTracepoints();
    std::vector<TracePoint> getTracePoints() const;
    bool startTracing();
    bool stopTracing();
    bool isTracing() const;

    bool readMemory(uintptr_t address, void *buffer, size_t size);
    bool writeMemory(uintptr_t address, const void *data, size_t size);
    std::vector<uint8_t> readMemory(uintptr_t address, size_t size);
    std::string readString(uintptr_t address, size_t max_size = 256);
    bool writeString(uintptr_t address, const std::string &str);

    uint64_t readRegister(const std::string &name);
    bool writeRegister(const std::string &name, uint64_t value);
    std::map<std::string, uint64_t> readAllRegisters();
    bool writeAllRegisters(const std::map<std::string, uint64_t> &regs);
    std::string printRegisters();

    uintptr_t getRegisterValue(int reg_id);
    int getRegisterId(const std::string &name);
    std::string getRegisterName(int reg_id);
    std::vector<std::string> getRegisterNames() const;

    bool setPC(uintptr_t address);
    uintptr_t getPC();
    uintptr_t getSP();
    uintptr_t getBP();
    uintptr_t getReturnAddress();

    bool readFloats(uintptr_t address, float *buffer, size_t count);
    bool writeFloats(uintptr_t address, const float *data, size_t count);
    bool readDoubles(uintptr_t address, double *buffer, size_t count);
    bool writeDoubles(uintptr_t address, const double *data, size_t count);

    bool callFunction(uintptr_t address);
    bool callFunction(const std::string &function);
    uintptr_t callFunction(const std::string &function, const std::vector<uint64_t> &args);
    uintptr_t callFunction(uintptr_t address, const std::vector<uint64_t> &args);

    bool injectCode(const std::vector<uint8_t> &code, uintptr_t &address);
    bool injectCode(const std::string &code, uintptr_t &address);
    bool injectLibrary(const std::string &path);
    bool injectShellcode(const std::vector<uint8_t> &shellcode);

    std::vector<DebugSymbol> enumerateSymbols(const std::string &module = "");
    DebugSymbol findSymbol(const std::string &name);
    DebugSymbol findSymbol(uintptr_t address);
    std::string getSymbolName(uintptr_t address);
    uintptr_t getSymbolAddress(const std::string &name);

    std::vector<CodeRegion> getCodeRegions();
    std::string disassemble(uintptr_t address, uint32_t count = 10);
    std::string disassembleRange(uintptr_t start, uintptr_t end);
    std::string disassembleFunction(const std::string &function);
    std::string disassembleCurrent();

    std::vector<std::string> getBacktrace(uint32_t max_depth = 32);
    std::string printBacktrace(uint32_t max_depth = 32);
    std::vector<uintptr_t> getBacktraceAddresses(uint32_t max_depth = 32);

    std::vector<std::string> getStack(uintptr_t sp = 0, uint32_t count = 64);
    std::string printStack(uintptr_t sp = 0, uint32_t count = 64);

    std::vector<DebugInfo> enumerateThreads();
    DebugInfo getThreadInfo(pid_t tid);
    pid_t getCurrentThread();
    bool switchToThread(pid_t tid);
    bool suspendThread(pid_t tid);
    bool resumeThread(pid_t tid);
    bool suspendAllThreads();
    bool resumeAllThreads();

    bool handleSyscall();
    bool handleSignal();
    bool handleException();

    DebugInfo getDebugInfo() const;
    DebuggerConfig getConfig() const;
    std::string getTargetExecutable() const;
    pid_t getTargetPid() const;

    bool loadSymbols(const std::string &path);
    bool loadSymbolsFromFile(const std::string &path);
    bool loadSymbolsFromModule(const std::string &module);

    bool saveCoreDump(const std::string &path);
    bool loadCoreDump(const std::string &path);

    bool saveSession(const std::string &path);
    bool loadSession(const std::string &path);

    void enableLogging(bool enable);
    bool isLoggingEnabled() const;

    void onBreakpointHit(std::function<void(const Breakpoint&)> callback);
    void onWatchpointHit(std::function<void(uintptr_t, size_t)> callback);
    void onSignal(std::function<void(int)> callback);
    void onException(std::function<void(int)> callback);
    void onSyscall(std::function<void(int, uint64_t*)> callback);
    void onProcessStart(std::function<void(pid_t)> callback);
    void onProcessExit(std::function<void(int)> callback);
    void onThreadCreate(std::function<void(pid_t)> callback);
    void onThreadExit(std::function<void(pid_t)> callback);
    void onLibraryLoad(std::function<void(const std::string&, uintptr_t)> callback);
    void onLibraryUnload(std::function<void(const std::string&)> callback);

private:
    bool initialized;
    bool attached;
    bool running;
    bool stopped;
    bool loggingEnabled;

    DebuggerConfig config;
    DebugInfo debugInfo;

    pid_t targetPid;
    pid_t currentTid;

    std::mutex debuggerMutex;
    std::mutex breakpointMutex;
    std::mutex memoryMutex;

    std::map<uint64_t, Breakpoint> breakpoints;
    std::map<uint64_t, uintptr_t> watchpoints;
    std::vector<TracePoint> tracepoints;
    std::vector<DebugSymbol> symbols;
    std::vector<CodeRegion> codeRegions;
    std::vector<TracePoint> traceBuffer;

    uint64_t nextBreakpointId;
    uint64_t nextWatchpointId;
    uint64_t nextTracepointId;

    struct sigaction oldSigAction;

    std::function<void(const Breakpoint&)> breakpointCallback;
    std::function<void(uintptr_t, size_t)> watchpointCallback;
    std::function<void(int)> signalCallback;
    std::function<void(int)> exceptionCallback;
    std::function<void(int, uint64_t*)> syscallCallback;
    std::function<void(pid_t)> processStartCallback;
    std::function<void(int)> processExitCallback;
    std::function<void(pid_t)> threadCreateCallback;
    std::function<void(pid_t)> threadExitCallback;
    std::function<void(const std::string&, uintptr_t)> libraryLoadCallback;
    std::function<void(const std::string&)> libraryUnloadCallback;

    std::thread *eventThread;
    std::atomic<bool> eventThreadRunning;

    bool ptraceAttach(pid_t pid);
    bool ptraceDetach(pid_t pid);
    bool ptraceContinue(pid_t pid, int signal = 0);
    bool ptraceSingleStep(pid_t pid);
    bool ptraceSyscall(pid_t pid);
    bool ptraceGetRegs(pid_t pid, struct user_regs_struct &regs);
    bool ptraceSetRegs(pid_t pid, const struct user_regs_struct &regs);
    bool ptraceGetFPRegs(pid_t pid, struct user_fpregs_struct &fpregs);
    bool ptraceSetFPRegs(pid_t pid, const struct user_fpregs_struct &fpregs);
    bool ptraceReadMemory(pid_t pid, uintptr_t addr, void *buffer, size_t size);
    bool ptraceWriteMemory(pid_t pid, uintptr_t addr, const void *data, size_t size);
    bool ptracePeekText(pid_t pid, uintptr_t addr, void *buffer, size_t size);
    bool ptracePokeText(pid_t pid, uintptr_t addr, const void *data, size_t size);
    bool ptraceGetEventMsg(pid_t pid, unsigned long &msg);

    bool insertBreakpoint(Breakpoint &bp, bool temporary = false);
    bool removeBreakpoint(Breakpoint &bp);
    bool handleBreakpointHit(pid_t tid);
    bool handleWatchpointHit(pid_t tid, uintptr_t addr);

    void eventLoop();
    void handleEvent(pid_t pid, int status);

    bool findMainModule();
    bool enumerateMemoryRegions();
    bool enumerateSymbolsForModule(const std::string &module);

    bool parseElfSymbols(const std::string &module, std::vector<DebugSymbol> &symbols);
    bool parseDWARFInfo(const std::string &module);
    bool loadSymbolTable(const std::string &path);

    uintptr_t resolveAddress(const std::string &expression);

    bool setupPtraceOptions();
    bool waitForProcess(pid_t pid, int &status, int options = 0);

    bool redirectIO(const std::string &input, const std::string &output, const std::string &error);
    bool setupEnvironment(std::vector<std::string> &env);
    bool disableASLR();
    bool execChild(const std::string &path, char **argv, char **envp);

    void logDebug(const std::string &message);
    std::string statusToString(int status) const;
    std::string signalToString(int signum) const;
    std::string syscallToString(int syscall_num) const;
};

#endif
