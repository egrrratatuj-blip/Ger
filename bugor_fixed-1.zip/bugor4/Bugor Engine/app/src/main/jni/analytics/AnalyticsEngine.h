#ifndef BUGOR_ANALYTICS_ENGINE_H
#define BUGOR_ANALYTICS_ENGINE_H

#include <string>
#include <vector>
#include <map>
#include <functional>
#include <memory>
#include <mutex>
#include <atomic>
#include <thread>
#include <chrono>
#include <queue>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <cmath>
#include <algorithm>
#include <random>
#include <cstdint>
#include <cstring>
#include <set>
#include <unordered_map>
#include <stack>
#include <deque>
#include <condition_variable>
struct cJSON { int type; cJSON* next; cJSON* prev; cJSON* child; char* string; char* valuestring; double valuedouble; int valueint; };

struct AnalyticsEvent {
    std::string name;
    std::string category;
    std::string label;
    std::string user_id;
    std::string session_id;
    std::string source;
    std::string platform;
    std::string device_id;
    std::string app_version;
    std::string os_version;
    std::map<std::string, std::string> properties;
    std::map<std::string, double> metrics;
    uint64_t timestamp;
    uint64_t duration_ms;
    double value;
    int32_t priority;
    bool anonymized;
    bool sampled;
    bool persisted;
};

struct AnalyticsSession {
    std::string session_id;
    std::string user_id;
    std::string device_id;
    std::string ip_address;
    std::string user_agent;
    std::string referrer;
    std::string campaign;
    std::string landing_page;
    std::string exit_page;
    uint64_t start_time;
    uint64_t end_time;
    uint64_t duration_ms;
    uint32_t event_count;
    uint32_t page_views;
    uint32_t interactions;
    std::vector<AnalyticsEvent> events;
    std::map<std::string, uint32_t> event_counts;
    std::map<std::string, double> aggregated_metrics;
    bool active;
};

struct AnalyticsFunnel {
    std::string name;
    std::string description;
    uint32_t version;
    std::vector<std::string> steps;
    std::map<uint32_t, uint32_t> step_counts;
    std::map<uint32_t, double> conversion_rates;
    uint32_t total_entries;
    uint32_t total_completions;
    double overall_conversion_rate;
    std::chrono::system_clock::time_point created_at;
    std::chrono::system_clock::time_point last_updated;
    bool active;
};

struct AnalyticsCohort {
    std::string name;
    std::string description;
    std::string criteria;
    std::string grouping;
    std::vector<std::string> user_ids;
    std::map<std::string, double> metrics;
    uint32_t user_count;
    double retention_rate;
    std::chrono::system_clock::time_point created_at;
    std::chrono::system_clock::time_point last_calculated;
    bool active;
};

struct AnalyticsReport {
    std::string name;
    std::string type;
    std::string format;
    std::string period;
    std::string group_by;
    std::string filter;
    std::string segments;
    std::string metrics;
    std::string dimensions;
    std::string sort_by;
    std::string output_path;
    std::map<std::string, std::string> parameters;
    std::map<std::string, double> results;
    std::vector<std::map<std::string, std::string>> data_rows;
    uint64_t generated_at;
    uint32_t row_count;
    bool scheduled;
    bool recurring;
    bool auto_export;
};

struct AnalyticsMetric {
    std::string name;
    std::string description;
    std::string unit;
    std::string aggregation;
    std::string source;
    std::vector<std::pair<uint64_t, double>> data_points;
    double current_value;
    double previous_value;
    double min_value;
    double max_value;
    double avg_value;
    double median_value;
    double std_deviation;
    double percentile_90;
    double percentile_95;
    double percentile_99;
    uint32_t sample_count;
    uint64_t last_updated;
    bool active;
};

struct RetentionCohort {
    uint64_t cohort_date;
    uint32_t user_count;
    std::vector<double> retention_by_period;
    std::vector<uint32_t> active_users_by_period;
    double week_1_retention;
    double week_2_retention;
    double week_4_retention;
    double month_1_retention;
    double month_3_retention;
    double month_6_retention;
    double month_12_retention;
};

struct UserProperties {
    std::string user_id;
    std::string device_id;
    std::string platform;
    std::string os_version;
    std::string app_version;
    std::string country;
    std::string city;
    std::string language;
    std::string timezone;
    std::string first_seen;
    std::string last_seen;
    uint64_t first_seen_timestamp;
    uint64_t last_seen_timestamp;
    uint32_t session_count;
    uint32_t event_count;
    uint64_t total_time_spent;
    std::map<std::string, std::string> traits;
    std::map<std::string, double> scores;
    std::vector<std::string> segments;
    std::vector<std::string> cohorts;
};

enum class AnalyticsAggregation {
    Count,
    Sum,
    Average,
    Min,
    Max,
    Median,
    Mode,
    StdDev,
    Variance,
    Percentile90,
    Percentile95,
    Percentile99,
    Unique,
    Rate,
    Distribution
};

enum class AnalyticsPeriod {
    Hourly,
    Daily,
    Weekly,
    Monthly,
    Quarterly,
    Yearly,
    Custom
};

class AnalyticsEngine {
public:
    AnalyticsEngine();
    ~AnalyticsEngine();

    bool initialize(const std::string &config_path = "");
    void shutdown();
    bool isInitialized() const;

    void setEnabled(bool enable);
    bool isEnabled() const;
    void setDebugMode(bool enable);
    bool isDebugMode() const;

    void trackEvent(const AnalyticsEvent &event);
    void trackEvent(const std::string &name, const std::map<std::string, std::string> &properties = {});
    void trackEvent(const std::string &name, const std::string &category, const std::string &label = "");
    void trackEvent(const std::string &name, double value, const std::map<std::string, std::string> &properties = {});

    void trackScreen(const std::string &screen_name, const std::map<std::string, std::string> &properties = {});
    void trackAction(const std::string &action, const std::map<std::string, std::string> &properties = {});
    void trackError(const std::string &error_message, const std::map<std::string, std::string> &properties = {});
    void trackPerformance(const std::string &operation, double duration_ms, const std::map<std::string, std::string> &properties = {});
    void trackFeature(const std::string &feature, const std::string &action, const std::map<std::string, std::string> &properties = {});
    void trackUserAction(const std::string &action, const std::map<std::string, std::string> &properties = {});

    AnalyticsSession startSession(const std::string &user_id = "");
    AnalyticsSession endSession();
    AnalyticsSession getCurrentSession() const;
    bool isSessionActive() const;
    std::string getSessionId() const;
    uint32_t getSessionCount() const;

    bool identifyUser(const std::string &user_id, const std::map<std::string, std::string> &traits = {});
    bool anonymizeUser();
    std::string getUserId() const;
    UserProperties getUserProperties(const std::string &user_id) const;
    std::vector<std::string> getUserSegments(const std::string &user_id) const;

    bool setUserTrait(const std::string &trait, const std::string &value);
    std::string getUserTrait(const std::string &trait) const;
    std::map<std::string, std::string> getUserTraits() const;

    bool setUserScore(const std::string &score_name, double value);
    double getUserScore(const std::string &score_name) const;
    std::map<std::string, double> getUserScores() const;

    bool addUserToSegment(const std::string &segment);
    bool removeUserFromSegment(const std::string &segment);
    bool isUserInSegment(const std::string &segment) const;
    std::vector<std::string> getUserSegments() const;

    bool trackFunnel(const std::string &funnel_name, const std::string &step);
    bool createFunnel(const std::string &name, const std::vector<std::string> &steps);
    bool updateFunnel(const AnalyticsFunnel &funnel);
    bool deleteFunnel(const std::string &name);
    AnalyticsFunnel getFunnel(const std::string &name) const;
    std::vector<AnalyticsFunnel> getFunnels() const;

    bool createCohort(const std::string &name, const std::string &criteria);
    bool updateCohort(const AnalyticsCohort &cohort);
    bool deleteCohort(const std::string &name);
    AnalyticsCohort getCohort(const std::string &name) const;
    std::vector<AnalyticsCohort> getCohorts() const;
    bool addUserToCohort(const std::string &cohort_name, const std::string &user_id);
    bool removeUserFromCohort(const std::string &cohort_name, const std::string &user_id);
    std::vector<std::string> getUserCohorts(const std::string &user_id) const;

    RetentionCohort calculateRetention(const std::string &cohort_name, uint32_t periods = 12);
    std::vector<RetentionCohort> getRetentionData() const;

    bool recordMetric(const std::string &name, double value, const std::map<std::string, std::string> &tags = {});
    AnalyticsMetric getMetric(const std::string &name) const;
    std::vector<AnalyticsMetric> getMetrics() const;
    std::map<std::string, double> getMetricValues(const std::string &name) const;

    AnalyticsReport generateReport(const std::string &name, const std::string &type);
    AnalyticsReport generateReport(const AnalyticsReport &template_report);
    bool scheduleReport(const AnalyticsReport &report, const std::string &cron_expression);
    bool cancelReport(const std::string &name);
    std::vector<AnalyticsReport> getScheduledReports() const;
    bool exportReport(const std::string &name, const std::string &format, const std::string &path);
    bool exportReportData(const std::string &name, const std::string &path);

    uint64_t getEventCount(const std::string &event_name = "") const;
    std::map<std::string, uint64_t> getEventCounts() const;
    std::map<std::string, uint64_t> getEventCountsByCategory() const;

    std::map<std::string, double> getAggregatedMetrics(const std::vector<std::string> &metric_names, AnalyticsPeriod period = AnalyticsPeriod::Daily);
    double getAggregatedValue(const std::string &metric_name, AnalyticsAggregation aggregation);

    std::vector<AnalyticsEvent> getRecentEvents(uint32_t count = 100) const;
    std::vector<AnalyticsEvent> getEvents(const std::string &name, uint64_t start_time = 0, uint64_t end_time = 0) const;
    std::vector<AnalyticsEvent> getEventsByCategory(const std::string &category, uint64_t start_time = 0, uint64_t end_time = 0) const;

    uint64_t getActiveUsers(uint64_t start_time, uint64_t end_time) const;
    uint64_t getNewUsers(uint64_t start_time, uint64_t end_time) const;
    uint64_t getReturningUsers(uint64_t start_time, uint64_t end_time) const;
    double getUserRetentionRate(uint64_t start_date) const;

    double getConversionRate(const std::string &funnel_name) const;
    std::map<std::string, double> getStepConversionRates(const std::string &funnel_name) const;

    std::map<std::string, uint64_t> getUserActivityTimeline(const std::string &user_id, uint32_t days = 30) const;
    std::map<std::string, double> getUserEngagementMetrics(const std::string &user_id) const;

    bool setSuperProperties(const std::map<std::string, std::string> &properties);
    std::map<std::string, std::string> getSuperProperties() const;
    bool clearSuperProperties();

    void flush();
    void flushAll();
    void setFlushInterval(uint32_t interval_ms);
    void setMaxBatchSize(uint32_t size);
    void setMaxQueueSize(uint32_t size);

    void setStoragePath(const std::string &path);
    std::string getStoragePath() const;
    bool persistToDisk(bool enable);
    bool loadFromDisk(const std::string &path = "");

    void setServerUrl(const std::string &url);
    std::string getServerUrl() const;
    void setApiKey(const std::string &api_key);
    std::string getApiKey() const;

    void enableAutoTracking(bool enable);
    void enableBackgroundTracking(bool enable);
    void enableCrashTracking(bool enable);

    std::string generateSessionId() const;
    std::string generateUserId() const;
    std::string generateEventId() const;
    std::string getDeviceId() const;

    std::map<std::string, std::string> getDeviceInfo() const;
    std::map<std::string, std::string> getAppInfo() const;
    std::map<std::string, std::string> getNetworkInfo() const;

    void onEvent(std::function<void(const AnalyticsEvent&)> callback);
    void onSessionStart(std::function<void(const AnalyticsSession&)> callback);
    void onSessionEnd(std::function<void(const AnalyticsSession&)> callback);
    void onError(std::function<void(const std::string&)> callback);

private:
    bool initialized;
    bool enabled;
    bool debugMode;
    bool autoTracking;
    bool backgroundTracking;
    bool crashTracking;
    bool diskPersistence;

    std::string userId;
    std::string deviceId;
    std::string sessionId;
    std::string storagePath;
    std::string serverUrl;
    std::string apiKey;

    uint32_t flushInterval;
    uint32_t maxBatchSize;
    uint32_t maxQueueSize;
    uint64_t eventIdCounter;

    std::mutex analyticsMutex;
    std::mutex eventMutex;
    std::mutex sessionMutex;
    std::mutex userMutex;
    std::mutex funnelMutex;
    std::mutex cohortMutex;
    std::mutex metricMutex;
    std::mutex flushMutex;

    std::queue<AnalyticsEvent> eventQueue;
    std::vector<AnalyticsEvent> persistedEvents;
    AnalyticsSession currentSession;
    std::map<std::string, UserProperties> userProperties;
    std::map<std::string, AnalyticsFunnel> funnels;
    std::map<std::string, AnalyticsCohort> cohorts;
    std::map<std::string, AnalyticsMetric> metrics;
    std::map<std::string, std::string> superProperties;
    std::map<std::string, uint64_t> eventCounts;
    std::map<std::string, uint64_t> categoryCounts;
    std::vector<RetentionCohort> retentionData;
    std::vector<std::string> userSegments;

    std::thread *flushThread;
    std::thread *metricThread;
    std::atomic<bool> threadsRunning;

    std::function<void(const AnalyticsEvent&)> eventCallback;
    std::function<void(const AnalyticsSession&)> sessionStartCallback;
    std::function<void(const AnalyticsSession&)> sessionEndCallback;
    std::function<void(const std::string&)> errorCallback;

    void processEvent(const AnalyticsEvent &event);
    void processSessionEvents();
    void updateUserProfile(const AnalyticsEvent &event);
    void updateFunnels(const AnalyticsEvent &event);
    void updateMetrics(const AnalyticsEvent &event);
    void updateCohorts(const AnalyticsEvent &event);
    void calculateRetention();
    void calculateAggregations();

    void flushEvents();
    void flushLoop();
    void metricAggregationLoop();

    bool saveEvents();
    bool loadEvents();
    bool saveMetrics();
    bool loadMetrics();
    bool saveSessions();
    bool loadSessions();

    std::string eventToJSON(const AnalyticsEvent &event) const;
    AnalyticsEvent eventFromJSON(const std::string &json) const;
    std::string eventsToJSON(const std::vector<AnalyticsEvent> &events) const;
    std::vector<AnalyticsEvent> eventsFromJSON(const std::string &json) const;

    double calculateStdDev(const std::vector<double> &values) const;
    double calculatePercentile(const std::vector<double> &values, double percentile) const;
    double calculateMedian(const std::vector<double> &values) const;
    double calculateMode(const std::vector<double> &values) const;

    std::string getCurrentTimestamp() const;
    uint64_t getCurrentTimestampMs() const;
    std::string formatTimestamp(uint64_t timestamp_ms, const std::string &format = "%Y-%m-%d %H:%M:%S") const;
};

#endif
