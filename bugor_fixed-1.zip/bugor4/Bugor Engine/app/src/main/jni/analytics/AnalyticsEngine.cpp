#include "AnalyticsEngine.h"
#include <fstream>
#include <chrono>
#include <cstdio>
#include <cerrno>
#include <cinttypes>
#include <sys/stat.h>

AnalyticsEngine::AnalyticsEngine()
    : initialized(false)
    , enabled(true)
    , debugMode(false)
    , autoTracking(false)
    , backgroundTracking(false)
    , crashTracking(false)
    , diskPersistence(true)
    , flushInterval(30000)
    , maxBatchSize(100)
    , maxQueueSize(10000)
    , eventIdCounter(0)
    , flushThread(nullptr)
    , metricThread(nullptr)
    , threadsRunning(false)
{
    deviceId = generateDeviceId();
}

AnalyticsEngine::~AnalyticsEngine()
{
    shutdown();
}

bool AnalyticsEngine::initialize(const std::string &config_path)
{
    if (initialized) return true;
    if (!config_path.empty()) {
        std::ifstream in(config_path);
        if (in.is_open()) in.close();
    }
    sessionId = generateSessionId();
    if (diskPersistence) {
        loadEvents();
        loadMetrics();
        loadSessions();
    }
    threadsRunning = true;
    flushThread = new std::thread(&AnalyticsEngine::flushLoop, this);
    metricThread = new std::thread(&AnalyticsEngine::metricAggregationLoop, this);
    initialized = true;
    return true;
}

void AnalyticsEngine::shutdown()
{
    if (!initialized) return;
    threadsRunning = false;
    if (flushThread) {
        flushThread->join();
        delete flushThread;
        flushThread = nullptr;
    }
    if (metricThread) {
        metricThread->join();
        delete metricThread;
        metricThread = nullptr;
    }
    flushAll();
    if (diskPersistence) {
        saveEvents();
        saveMetrics();
        saveSessions();
    }
    initialized = false;
}

bool AnalyticsEngine::isInitialized() const
{
    return initialized;
}

void AnalyticsEngine::setEnabled(bool enable)
{
    enabled = enable;
}

bool AnalyticsEngine::isEnabled() const
{
    return enabled;
}

void AnalyticsEngine::setDebugMode(bool enable)
{
    debugMode = enable;
}

bool AnalyticsEngine::isDebugMode() const
{
    return debugMode;
}

void AnalyticsEngine::trackEvent(const AnalyticsEvent &event)
{
    if (!enabled || !initialized) return;
    std::lock_guard<std::mutex> lock(eventMutex);
    AnalyticsEvent e = event;
    if (e.timestamp == 0) e.timestamp = getCurrentTimestampMs();
    if (e.session_id.empty()) e.session_id = sessionId;
    e.id = ++eventIdCounter;
    eventQueue.push(e);
    ++eventCounts[e.name];
    ++categoryCounts[e.category];
    if (currentSession.active) {
        ++currentSession.event_count;
        currentSession.events.push_back(e);
        ++currentSession.event_counts[e.name];
    }
    if (eventQueue.size() >= maxBatchSize) flush();
    if (eventCallback) eventCallback(e);
    processEvent(e);
}

void AnalyticsEngine::trackEvent(const std::string &name, const std::map<std::string, std::string> &properties)
{
    AnalyticsEvent event;
    event.name = name;
    event.properties = properties;
    event.timestamp = getCurrentTimestampMs();
    event.session_id = sessionId;
    event.user_id = userId;
    event.device_id = deviceId;
    trackEvent(event);
}

void AnalyticsEngine::trackEvent(const std::string &name, const std::string &category, const std::string &label)
{
    AnalyticsEvent event;
    event.name = name;
    event.category = category;
    event.label = label;
    event.timestamp = getCurrentTimestampMs();
    event.session_id = sessionId;
    trackEvent(event);
}

void AnalyticsEngine::trackEvent(const std::string &name, double value, const std::map<std::string, std::string> &properties)
{
    AnalyticsEvent event;
    event.name = name;
    event.value = value;
    event.properties = properties;
    event.timestamp = getCurrentTimestampMs();
    event.session_id = sessionId;
    trackEvent(event);
}

void AnalyticsEngine::trackScreen(const std::string &screen_name, const std::map<std::string, std::string> &properties)
{
    AnalyticsEvent event;
    event.name = "screen_view";
    event.category = "navigation";
    event.label = screen_name;
    event.properties = properties;
    event.properties["screen_name"] = screen_name;
    event.timestamp = getCurrentTimestampMs();
    trackEvent(event);
}

void AnalyticsEngine::trackAction(const std::string &action, const std::map<std::string, std::string> &properties)
{
    AnalyticsEvent event;
    event.name = "user_action";
    event.category = "interaction";
    event.label = action;
    event.properties = properties;
    event.properties["action"] = action;
    event.timestamp = getCurrentTimestampMs();
    trackEvent(event);
}

void AnalyticsEngine::trackError(const std::string &error_message, const std::map<std::string, std::string> &properties)
{
    AnalyticsEvent event;
    event.name = "error";
    event.category = "error";
    event.label = error_message;
    event.properties = properties;
    event.properties["error_message"] = error_message;
    event.timestamp = getCurrentTimestampMs();
    trackEvent(event);
}

void AnalyticsEngine::trackPerformance(const std::string &operation, double duration_ms, const std::map<std::string, std::string> &properties)
{
    AnalyticsEvent event;
    event.name = "performance";
    event.category = "performance";
    event.label = operation;
    event.metrics["duration_ms"] = duration_ms;
    event.duration_ms = static_cast<uint64_t>(duration_ms);
    event.properties = properties;
    event.timestamp = getCurrentTimestampMs();
    trackEvent(event);
}

void AnalyticsEngine::trackFeature(const std::string &feature, const std::string &action, const std::map<std::string, std::string> &properties)
{
    AnalyticsEvent event;
    event.name = "feature_used";
    event.category = "feature";
    event.label = feature;
    event.properties = properties;
    event.properties["feature"] = feature;
    event.properties["action"] = action;
    event.timestamp = getCurrentTimestampMs();
    trackEvent(event);
}

void AnalyticsEngine::trackUserAction(const std::string &action, const std::map<std::string, std::string> &properties)
{
    trackAction(action, properties);
}

AnalyticsSession AnalyticsEngine::startSession(const std::string &user_id)
{
    std::lock_guard<std::mutex> lock(sessionMutex);
    if (currentSession.active) endSession();
    currentSession.session_id = generateSessionId();
    currentSession.user_id = user_id.empty() ? this->userId : user_id;
    currentSession.device_id = deviceId;
    currentSession.start_time = getCurrentTimestampMs();
    currentSession.active = true;
    currentSession.event_count = 0;
    currentSession.page_views = 0;
    currentSession.interactions = 0;
    sessionId = currentSession.session_id;
    if (sessionStartCallback) sessionStartCallback(currentSession);
    return currentSession;
}

AnalyticsSession AnalyticsEngine::endSession()
{
    std::lock_guard<std::mutex> lock(sessionMutex);
    if (!currentSession.active) return currentSession;
    currentSession.end_time = getCurrentTimestampMs();
    currentSession.duration_ms = currentSession.end_time - currentSession.start_time;
    currentSession.active = false;
    if (sessionEndCallback) sessionEndCallback(currentSession);
    if (diskPersistence) saveSessions();
    return currentSession;
}

AnalyticsSession AnalyticsEngine::getCurrentSession() const
{
    return currentSession;
}

bool AnalyticsEngine::isSessionActive() const
{
    return currentSession.active;
}

std::string AnalyticsEngine::getSessionId() const
{
    return sessionId;
}

uint32_t AnalyticsEngine::getSessionCount() const
{
    return currentSession.active ? 1 : 0;
}

bool AnalyticsEngine::identifyUser(const std::string &user_id, const std::map<std::string, std::string> &traits)
{
    std::lock_guard<std::mutex> lock(userMutex);
    this->userId = user_id;
    UserProperties &props = userProperties[user_id];
    props.user_id = user_id;
    props.device_id = deviceId;
    props.first_seen_timestamp = getCurrentTimestampMs();
    props.last_seen_timestamp = getCurrentTimestampMs();
    for (const auto &t : traits) props.traits[t.first] = t.second;
    return true;
}

bool AnalyticsEngine::anonymizeUser()
{
    userId = "";
    return true;
}

std::string AnalyticsEngine::getUserId() const
{
    return userId;
}

UserProperties AnalyticsEngine::getUserProperties(const std::string &user_id) const
{
    std::lock_guard<std::mutex> lock(userMutex);
    auto it = userProperties.find(user_id);
    return it != userProperties.end() ? it->second : UserProperties();
}

std::vector<std::string> AnalyticsEngine::getUserSegments(const std::string &user_id) const
{
    return userSegments;
}

bool AnalyticsEngine::setUserTrait(const std::string &trait, const std::string &value)
{
    if (userId.empty()) return false;
    std::lock_guard<std::mutex> lock(userMutex);
    userProperties[userId].traits[trait] = value;
    return true;
}

std::string AnalyticsEngine::getUserTrait(const std::string &trait) const
{
    if (userId.empty()) return "";
    auto it = userProperties.find(userId);
    if (it == userProperties.end()) return "";
    auto tit = it->second.traits.find(trait);
    return tit != it->second.traits.end() ? tit->second : "";
}

std::map<std::string, std::string> AnalyticsEngine::getUserTraits() const
{
    if (userId.empty()) return {};
    auto it = userProperties.find(userId);
    return it != userProperties.end() ? it->second.traits : std::map<std::string, std::string>();
}

bool AnalyticsEngine::setUserScore(const std::string &score_name, double value)
{
    if (userId.empty()) return false;
    std::lock_guard<std::mutex> lock(userMutex);
    userProperties[userId].scores[score_name] = value;
    return true;
}

double AnalyticsEngine::getUserScore(const std::string &score_name) const
{
    if (userId.empty()) return 0.0;
    auto it = userProperties.find(userId);
    if (it == userProperties.end()) return 0.0;
    auto sit = it->second.scores.find(score_name);
    return sit != it->second.scores.end() ? sit->second : 0.0;
}

std::map<std::string, double> AnalyticsEngine::getUserScores() const
{
    if (userId.empty()) return {};
    auto it = userProperties.find(userId);
    return it != userProperties.end() ? it->second.scores : std::map<std::string, double>();
}

bool AnalyticsEngine::addUserToSegment(const std::string &segment)
{
    std::lock_guard<std::mutex> lock(userMutex);
    if (std::find(userSegments.begin(), userSegments.end(), segment) == userSegments.end()) {
        userSegments.push_back(segment);
    }
    return true;
}

bool AnalyticsEngine::removeUserFromSegment(const std::string &segment)
{
    std::lock_guard<std::mutex> lock(userMutex);
    auto it = std::find(userSegments.begin(), userSegments.end(), segment);
    if (it != userSegments.end()) { userSegments.erase(it); return true; }
    return false;
}

bool AnalyticsEngine::isUserInSegment(const std::string &segment) const
{
    return std::find(userSegments.begin(), userSegments.end(), segment) != userSegments.end();
}

std::vector<std::string> AnalyticsEngine::getUserSegments() const
{
    return userSegments;
}

bool AnalyticsEngine::trackFunnel(const std::string &funnel_name, const std::string &step)
{
    std::lock_guard<std::mutex> lock(funnelMutex);
    auto it = funnels.find(funnel_name);
    if (it == funnels.end()) return false;
    uint32_t step_idx = 0;
    for (size_t i = 0; i < it->second.steps.size(); ++i) {
        if (it->second.steps[i] == step) { step_idx = static_cast<uint32_t>(i); break; }
    }
    ++it->second.step_counts[step_idx];
    if (step_idx == 0) ++it->second.total_entries;
    if (step_idx == it->second.steps.size() - 1) ++it->second.total_completions;
    for (auto &kv : it->second.step_counts) {
        if (it->second.total_entries > 0) {
            it->second.conversion_rates[kv.first] = static_cast<double>(kv.second) / it->second.total_entries * 100.0;
        }
    }
    if (it->second.total_entries > 0) {
        it->second.overall_conversion_rate = static_cast<double>(it->second.total_completions) / it->second.total_entries * 100.0;
    }
    it->second.last_updated = std::chrono::system_clock::now();
    return true;
}

bool AnalyticsEngine::createFunnel(const std::string &name, const std::vector<std::string> &steps)
{
    std::lock_guard<std::mutex> lock(funnelMutex);
    if (funnels.find(name) != funnels.end()) return false;
    AnalyticsFunnel funnel;
    funnel.name = name;
    funnel.steps = steps;
    funnel.total_entries = 0;
    funnel.total_completions = 0;
    funnel.overall_conversion_rate = 0.0;
    funnel.created_at = std::chrono::system_clock::now();
    funnel.last_updated = funnel.created_at;
    funnel.active = true;
    funnels[name] = funnel;
    return true;
}

bool AnalyticsEngine::updateFunnel(const AnalyticsFunnel &funnel)
{
    funnels[funnel.name] = funnel;
    return true;
}

bool AnalyticsEngine::deleteFunnel(const std::string &name)
{
    return funnels.erase(name) > 0;
}

AnalyticsFunnel AnalyticsEngine::getFunnel(const std::string &name) const
{
    auto it = funnels.find(name);
    return it != funnels.end() ? it->second : AnalyticsFunnel();
}

std::vector<AnalyticsFunnel> AnalyticsEngine::getFunnels() const
{
    std::vector<AnalyticsFunnel> result;
    for (const auto &kv : funnels) result.push_back(kv.second);
    return result;
}

bool AnalyticsEngine::createCohort(const std::string &name, const std::string &criteria)
{
    std::lock_guard<std::mutex> lock(cohortMutex);
    if (cohorts.find(name) != cohorts.end()) return false;
    AnalyticsCohort cohort;
    cohort.name = name;
    cohort.criteria = criteria;
    cohort.user_count = 0;
    cohort.retention_rate = 0.0;
    cohort.created_at = std::chrono::system_clock::now();
    cohort.last_calculated = cohort.created_at;
    cohort.active = true;
    cohorts[name] = cohort;
    return true;
}

bool AnalyticsEngine::updateCohort(const AnalyticsCohort &cohort)
{
    cohorts[cohort.name] = cohort;
    return true;
}

bool AnalyticsEngine::deleteCohort(const std::string &name)
{
    return cohorts.erase(name) > 0;
}

AnalyticsCohort AnalyticsEngine::getCohort(const std::string &name) const
{
    auto it = cohorts.find(name);
    return it != cohorts.end() ? it->second : AnalyticsCohort();
}

std::vector<AnalyticsCohort> AnalyticsEngine::getCohorts() const
{
    std::vector<AnalyticsCohort> result;
    for (const auto &kv : cohorts) result.push_back(kv.second);
    return result;
}

bool AnalyticsEngine::addUserToCohort(const std::string &cohort_name, const std::string &user_id)
{
    std::lock_guard<std::mutex> lock(cohortMutex);
    auto it = cohorts.find(cohort_name);
    if (it == cohorts.end()) return false;
    if (std::find(it->second.user_ids.begin(), it->second.user_ids.end(), user_id) == it->second.user_ids.end()) {
        it->second.user_ids.push_back(user_id);
        it->second.user_count = static_cast<uint32_t>(it->second.user_ids.size());
    }
    return true;
}

bool AnalyticsEngine::removeUserFromCohort(const std::string &cohort_name, const std::string &user_id)
{
    std::lock_guard<std::mutex> lock(cohortMutex);
    auto it = cohorts.find(cohort_name);
    if (it == cohorts.end()) return false;
    auto uit = std::find(it->second.user_ids.begin(), it->second.user_ids.end(), user_id);
    if (uit != it->second.user_ids.end()) {
        it->second.user_ids.erase(uit);
        it->second.user_count = static_cast<uint32_t>(it->second.user_ids.size());
        return true;
    }
    return false;
}

std::vector<std::string> AnalyticsEngine::getUserCohorts(const std::string &user_id) const
{
    std::vector<std::string> result;
    for (const auto &kv : cohorts) {
        if (std::find(kv.second.user_ids.begin(), kv.second.user_ids.end(), user_id) != kv.second.user_ids.end()) {
            result.push_back(kv.first);
        }
    }
    return result;
}

RetentionCohort AnalyticsEngine::calculateRetention(const std::string &cohort_name, uint32_t periods)
{
    RetentionCohort rc;
    rc.cohort_date = 0;
    rc.user_count = 0;
    rc.retention_by_period.resize(periods, 0.0);
    rc.active_users_by_period.resize(periods, 0);
    return rc;
}

std::vector<RetentionCohort> AnalyticsEngine::getRetentionData() const
{
    return retentionData;
}

bool AnalyticsEngine::recordMetric(const std::string &name, double value, const std::map<std::string, std::string> &tags)
{
    std::lock_guard<std::mutex> lock(metricMutex);
    AnalyticsMetric &m = metrics[name];
    m.name = name;
    m.data_points.emplace_back(getCurrentTimestampMs(), value);
    m.current_value = value;
    m.sample_count++;
    m.last_updated = getCurrentTimestampMs();
    if (m.sample_count == 1) {
        m.min_value = value;
        m.max_value = value;
        m.avg_value = value;
    } else {
        if (value < m.min_value) m.min_value = value;
        if (value > m.max_value) m.max_value = value;
        m.avg_value = m.avg_value * (m.sample_count - 1) / m.sample_count + value / m.sample_count;
    }
    return true;
}

AnalyticsMetric AnalyticsEngine::getMetric(const std::string &name) const
{
    auto it = metrics.find(name);
    return it != metrics.end() ? it->second : AnalyticsMetric();
}

std::vector<AnalyticsMetric> AnalyticsEngine::getMetrics() const
{
    std::vector<AnalyticsMetric> result;
    for (const auto &kv : metrics) result.push_back(kv.second);
    return result;
}

std::map<std::string, double> AnalyticsEngine::getMetricValues(const std::string &name) const
{
    std::map<std::string, double> result;
    auto it = metrics.find(name);
    if (it != metrics.end()) {
        for (const auto &dp : it->second.data_points) {
            result[std::to_string(dp.first)] = dp.second;
        }
    }
    return result;
}

AnalyticsReport AnalyticsEngine::generateReport(const std::string &name, const std::string &type)
{
    AnalyticsReport report;
    report.name = name;
    report.type = type;
    report.generated_at = getCurrentTimestampMs();
    report.row_count = 0;
    return report;
}

AnalyticsReport AnalyticsEngine::generateReport(const AnalyticsReport &template_report)
{
    return generateReport(template_report.name, template_report.type);
}

bool AnalyticsEngine::scheduleReport(const AnalyticsReport &report, const std::string &cron_expression)
{
    (void)report;
    (void)cron_expression;
    return false;
}

bool AnalyticsEngine::cancelReport(const std::string &name)
{
    (void)name;
    return false;
}

std::vector<AnalyticsReport> AnalyticsEngine::getScheduledReports() const
{
    return {};
}

bool AnalyticsEngine::exportReport(const std::string &name, const std::string &format, const std::string &path)
{
    return exportReportData(name, path);
}

bool AnalyticsEngine::exportReportData(const std::string &name, const std::string &path)
{
    std::ofstream out(path);
    if (!out.is_open()) return false;
    out << "Report: " << name << "\n";
    out << "Generated: " << getCurrentTimestamp() << "\n";
    return out.good();
}

uint64_t AnalyticsEngine::getEventCount(const std::string &event_name) const
{
    if (event_name.empty()) {
        uint64_t total = 0;
        for (const auto &kv : eventCounts) total += kv.second;
        return total;
    }
    auto it = eventCounts.find(event_name);
    return it != eventCounts.end() ? it->second : 0;
}

std::map<std::string, uint64_t> AnalyticsEngine::getEventCounts() const
{
    return eventCounts;
}

std::map<std::string, uint64_t> AnalyticsEngine::getEventCountsByCategory() const
{
    return categoryCounts;
}

std::map<std::string, double> AnalyticsEngine::getAggregatedMetrics(const std::vector<std::string> &metric_names, AnalyticsPeriod period)
{
    std::map<std::string, double> result;
    uint64_t now = getCurrentTimestampMs();
    uint64_t period_ms = 86400000ULL;
    switch (period) {
        case AnalyticsPeriod::Hourly: period_ms = 3600000ULL; break;
        case AnalyticsPeriod::Daily: period_ms = 86400000ULL; break;
        case AnalyticsPeriod::Weekly: period_ms = 604800000ULL; break;
        case AnalyticsPeriod::Monthly: period_ms = 2592000000ULL; break;
        default: period_ms = 86400000ULL; break;
    }
    for (const auto &name : metric_names) {
        auto it = metrics.find(name);
        if (it == metrics.end()) continue;
        double sum = 0.0;
        uint32_t count = 0;
        for (const auto &dp : it->second.data_points) {
            if (dp.first >= now - period_ms) { sum += dp.second; ++count; }
        }
        result[name] = count > 0 ? sum / count : 0.0;
    }
    return result;
}

double AnalyticsEngine::getAggregatedValue(const std::string &metric_name, AnalyticsAggregation aggregation)
{
    auto it = metrics.find(metric_name);
    if (it == metrics.end()) return 0.0;
    switch (aggregation) {
        case AnalyticsAggregation::Sum: {
            double sum = 0.0;
            for (const auto &dp : it->second.data_points) sum += dp.second;
            return sum;
        }
        case AnalyticsAggregation::Average: return it->second.avg_value;
        case AnalyticsAggregation::Min: return it->second.min_value;
        case AnalyticsAggregation::Max: return it->second.max_value;
        case AnalyticsAggregation::Count: return static_cast<double>(it->second.sample_count);
        default: return it->second.current_value;
    }
}

std::vector<AnalyticsEvent> AnalyticsEngine::getRecentEvents(uint32_t count) const
{
    std::vector<AnalyticsEvent> result;
    std::lock_guard<std::mutex> lock(eventMutex);
    auto q = eventQueue;
    while (!q.empty() && result.size() < count) {
        result.push_back(q.front());
        q.pop();
    }
    return result;
}

std::vector<AnalyticsEvent> AnalyticsEngine::getEvents(const std::string &name, uint64_t start_time, uint64_t end_time) const
{
    std::vector<AnalyticsEvent> result;
    if (end_time == 0) end_time = getCurrentTimestampMs();
    std::lock_guard<std::mutex> lock(eventMutex);
    auto q = eventQueue;
    while (!q.empty()) {
        auto e = q.front(); q.pop();
        if (e.name == name && e.timestamp >= start_time && e.timestamp <= end_time) {
            result.push_back(e);
        }
    }
    return result;
}

std::vector<AnalyticsEvent> AnalyticsEngine::getEventsByCategory(const std::string &category, uint64_t start_time, uint64_t end_time) const
{
    std::vector<AnalyticsEvent> result;
    if (end_time == 0) end_time = getCurrentTimestampMs();
    std::lock_guard<std::mutex> lock(eventMutex);
    auto q = eventQueue;
    while (!q.empty()) {
        auto e = q.front(); q.pop();
        if (e.category == category && e.timestamp >= start_time && e.timestamp <= end_time) {
            result.push_back(e);
        }
    }
    return result;
}

uint64_t AnalyticsEngine::getActiveUsers(uint64_t start_time, uint64_t end_time) const
{
    return 0;
}

uint64_t AnalyticsEngine::getNewUsers(uint64_t start_time, uint64_t end_time) const
{
    return 0;
}

uint64_t AnalyticsEngine::getReturningUsers(uint64_t start_time, uint64_t end_time) const
{
    return 0;
}

double AnalyticsEngine::getUserRetentionRate(uint64_t start_date) const
{
    return 0.0;
}

double AnalyticsEngine::getConversionRate(const std::string &funnel_name) const
{
    auto it = funnels.find(funnel_name);
    return it != funnels.end() ? it->second.overall_conversion_rate : 0.0;
}

std::map<std::string, double> AnalyticsEngine::getStepConversionRates(const std::string &funnel_name) const
{
    auto it = funnels.find(funnel_name);
    return it != funnels.end() ? it->second.conversion_rates : std::map<std::string, double>();
}

std::map<std::string, uint64_t> AnalyticsEngine::getUserActivityTimeline(const std::string &user_id, uint32_t days) const
{
    std::map<std::string, uint64_t> timeline;
    (void)user_id;
    (void)days;
    return timeline;
}

std::map<std::string, double> AnalyticsEngine::getUserEngagementMetrics(const std::string &user_id) const
{
    std::map<std::string, double> metrics;
    (void)user_id;
    return metrics;
}

bool AnalyticsEngine::setSuperProperties(const std::map<std::string, std::string> &properties)
{
    superProperties = properties;
    return true;
}

std::map<std::string, std::string> AnalyticsEngine::getSuperProperties() const
{
    return superProperties;
}

bool AnalyticsEngine::clearSuperProperties()
{
    superProperties.clear();
    return true;
}

void AnalyticsEngine::flush()
{
    std::lock_guard<std::mutex> lock(flushMutex);
    flushEvents();
}

void AnalyticsEngine::flushAll()
{
    flush();
}

void AnalyticsEngine::setFlushInterval(uint32_t interval_ms)
{
    flushInterval = interval_ms;
}

void AnalyticsEngine::setMaxBatchSize(uint32_t size)
{
    maxBatchSize = size;
}

void AnalyticsEngine::setMaxQueueSize(uint32_t size)
{
    maxQueueSize = size;
}

void AnalyticsEngine::setStoragePath(const std::string &path)
{
    storagePath = path;
}

std::string AnalyticsEngine::getStoragePath() const
{
    return storagePath.empty() ? "/data/data/com.bugor.engine/analytics" : storagePath;
}

bool AnalyticsEngine::persistToDisk(bool enable)
{
    diskPersistence = enable;
    return true;
}

bool AnalyticsEngine::loadFromDisk(const std::string &path)
{
    if (!path.empty()) storagePath = path;
    return loadEvents() && loadMetrics() && loadSessions();
}

void AnalyticsEngine::setServerUrl(const std::string &url)
{
    serverUrl = url;
}

std::string AnalyticsEngine::getServerUrl() const
{
    return serverUrl;
}

void AnalyticsEngine::setApiKey(const std::string &api_key)
{
    apiKey = api_key;
}

std::string AnalyticsEngine::getApiKey() const
{
    return apiKey;
}

void AnalyticsEngine::enableAutoTracking(bool enable)
{
    autoTracking = enable;
}

void AnalyticsEngine::enableBackgroundTracking(bool enable)
{
    backgroundTracking = enable;
}

void AnalyticsEngine::enableCrashTracking(bool enable)
{
    crashTracking = enable;
}

std::string AnalyticsEngine::generateSessionId() const
{
    static uint64_t counter = 0;
    return "sess_" + std::to_string(getCurrentTimestampMs()) + "_" + std::to_string(++counter);
}

std::string AnalyticsEngine::generateUserId() const
{
    static uint64_t counter = 0;
    return "user_" + std::to_string(getCurrentTimestampMs()) + "_" + std::to_string(++counter);
}

std::string AnalyticsEngine::generateEventId() const
{
    return "evt_" + std::to_string(++eventIdCounter);
}

std::string AnalyticsEngine::getDeviceId() const
{
    return deviceId;
}

std::map<std::string, std::string> AnalyticsEngine::getDeviceInfo() const
{
    std::map<std::string, std::string> info;
    info["device_id"] = deviceId;
    info["platform"] = "Android";
    return info;
}

std::map<std::string, std::string> AnalyticsEngine::getAppInfo() const
{
    std::map<std::string, std::string> info;
    info["app_version"] = "1.0.0";
    info["build_type"] = "release";
    return info;
}

std::map<std::string, std::string> AnalyticsEngine::getNetworkInfo() const
{
    std::map<std::string, std::string> info;
    info["connection_type"] = "wifi";
    return info;
}

void AnalyticsEngine::onEvent(std::function<void(const AnalyticsEvent&)> callback)
{
    eventCallback = callback;
}

void AnalyticsEngine::onSessionStart(std::function<void(const AnalyticsSession&)> callback)
{
    sessionStartCallback = callback;
}

void AnalyticsEngine::onSessionEnd(std::function<void(const AnalyticsSession&)> callback)
{
    sessionEndCallback = callback;
}

void AnalyticsEngine::onError(std::function<void(const std::string&)> callback)
{
    errorCallback = callback;
}

void AnalyticsEngine::processEvent(const AnalyticsEvent &event)
{
    updateUserProfile(event);
    updateFunnels(event);
    updateMetrics(event);
    updateCohorts(event);
}

void AnalyticsEngine::processSessionEvents()
{
}

void AnalyticsEngine::updateUserProfile(const AnalyticsEvent &event)
{
    if (event.user_id.empty()) return;
    UserProperties &props = userProperties[event.user_id];
    props.last_seen_timestamp = event.timestamp;
    props.last_seen = formatTimestamp(event.timestamp);
    ++props.event_count;
}

void AnalyticsEngine::updateFunnels(const AnalyticsEvent &event)
{
    for (auto &kv : funnels) {
        for (const auto &step : kv.second.steps) {
            if (event.name == step || event.label == step) {
                trackFunnel(kv.first, step);
            }
        }
    }
}

void AnalyticsEngine::updateMetrics(const AnalyticsEvent &event)
{
    for (const auto &kv : event.metrics) {
        recordMetric(event.name + "." + kv.first, kv.second);
    }
}

void AnalyticsEngine::updateCohorts(const AnalyticsEvent &event)
{
    (void)event;
}

void AnalyticsEngine::calculateRetention()
{
}

void AnalyticsEngine::calculateAggregations()
{
    for (auto &kv : metrics) {
        std::vector<double> values;
        for (const auto &dp : kv.second.data_points) values.push_back(dp.second);
        if (values.empty()) continue;
        std::sort(values.begin(), values.end());
        kv.second.median_value = calculateMedian(values);
        kv.second.std_deviation = calculateStdDev(values);
        kv.second.percentile_90 = calculatePercentile(values, 90.0);
        kv.second.percentile_95 = calculatePercentile(values, 95.0);
        kv.second.percentile_99 = calculatePercentile(values, 99.0);
    }
}

void AnalyticsEngine::flushEvents()
{
    if (eventQueue.empty()) return;
    while (!eventQueue.empty()) {
        AnalyticsEvent e = eventQueue.front();
        eventQueue.pop();
        persistedEvents.push_back(e);
    }
    if (diskPersistence && !persistedEvents.empty()) saveEvents();
}

void AnalyticsEngine::flushLoop()
{
    while (threadsRunning) {
        std::this_thread::sleep_for(std::chrono::milliseconds(flushInterval));
        if (!eventQueue.empty()) flush();
    }
}

void AnalyticsEngine::metricAggregationLoop()
{
    while (threadsRunning) {
        std::this_thread::sleep_for(std::chrono::minutes(5));
        calculateAggregations();
    }
}

bool AnalyticsEngine::saveEvents()
{
    std::string path = getStoragePath() + "/events.json";
    std::ofstream out(path);
    if (!out.is_open()) return false;
    out << eventsToJSON(persistedEvents);
    return out.good();
}

bool AnalyticsEngine::loadEvents()
{
    std::string path = getStoragePath() + "/events.json";
    std::ifstream in(path);
    if (!in.is_open()) return false;
    std::stringstream ss;
    ss << in.rdbuf();
    persistedEvents = eventsFromJSON(ss.str());
    return true;
}

bool AnalyticsEngine::saveMetrics()
{
    std::string path = getStoragePath() + "/metrics.json";
    std::ofstream out(path);
    if (!out.is_open()) return false;
    out << "{";
    bool first = true;
    for (const auto &kv : metrics) {
        if (!first) out << ",";
        first = false;
        out << "\"" << kv.first << "\":" << kv.second.current_value;
    }
    out << "}";
    return out.good();
}

bool AnalyticsEngine::loadMetrics()
{
    return true;
}

bool AnalyticsEngine::saveSessions()
{
    return true;
}

bool AnalyticsEngine::loadSessions()
{
    return true;
}

std::string AnalyticsEngine::eventToJSON(const AnalyticsEvent &event) const
{
    std::ostringstream oss;
    oss << "{";
    oss << "\"name\":\"" << event.name << "\"";
    oss << ",\"category\":\"" << event.category << "\"";
    oss << ",\"timestamp\":" << event.timestamp;
    oss << ",\"session_id\":\"" << event.session_id << "\"";
    oss << "}";
    return oss.str();
}

AnalyticsEvent AnalyticsEngine::eventFromJSON(const std::string &json) const
{
    AnalyticsEvent event;
    size_t pos = json.find("\"name\":\"");
    if (pos != std::string::npos) {
        pos += 8;
        size_t end = json.find("\"", pos);
        event.name = json.substr(pos, end - pos);
    }
    return event;
}

std::string AnalyticsEngine::eventsToJSON(const std::vector<AnalyticsEvent> &events) const
{
    std::ostringstream oss;
    oss << "[";
    for (size_t i = 0; i < events.size(); ++i) {
        if (i > 0) oss << ",";
        oss << eventToJSON(events[i]);
    }
    oss << "]";
    return oss.str();
}

std::vector<AnalyticsEvent> AnalyticsEngine::eventsFromJSON(const std::string &json) const
{
    std::vector<AnalyticsEvent> events;
    size_t pos = 0;
    while (true) {
        size_t start = json.find('{', pos);
        if (start == std::string::npos) break;
        size_t end = json.find('}', start);
        if (end == std::string::npos) break;
        events.push_back(eventFromJSON(json.substr(start, end - start + 1)));
        pos = end + 1;
    }
    return events;
}

double AnalyticsEngine::calculateStdDev(const std::vector<double> &values) const
{
    if (values.size() < 2) return 0.0;
    double mean = 0.0;
    for (double v : values) mean += v;
    mean /= values.size();
    double variance = 0.0;
    for (double v : values) variance += (v - mean) * (v - mean);
    variance /= values.size();
    return std::sqrt(variance);
}

double AnalyticsEngine::calculatePercentile(const std::vector<double> &values, double percentile) const
{
    if (values.empty()) return 0.0;
    double idx = (percentile / 100.0) * (values.size() - 1);
    size_t lower = static_cast<size_t>(idx);
    size_t upper = lower + 1;
    if (upper >= values.size()) return values[lower];
    double frac = idx - static_cast<double>(lower);
    return values[lower] * (1.0 - frac) + values[upper] * frac;
}

double AnalyticsEngine::calculateMedian(const std::vector<double> &values) const
{
    return calculatePercentile(values, 50.0);
}

double AnalyticsEngine::calculateMode(const std::vector<double> &values) const
{
    if (values.empty()) return 0.0;
    std::map<double, uint32_t> freq;
    for (double v : values) ++freq[v];
    double mode = values[0];
    uint32_t max_count = 0;
    for (const auto &kv : freq) {
        if (kv.second > max_count) { max_count = kv.second; mode = kv.first; }
    }
    return mode;
}

std::string AnalyticsEngine::getCurrentTimestamp() const
{
    return formatTimestamp(getCurrentTimestampMs());
}

uint64_t AnalyticsEngine::getCurrentTimestampMs() const
{
    return static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::system_clock::now().time_since_epoch()).count());
}

std::string AnalyticsEngine::formatTimestamp(uint64_t timestamp_ms, const std::string &format) const
{
    (void)format;
    time_t seconds = static_cast<time_t>(timestamp_ms / 1000);
    struct tm tm;
    localtime_r(&seconds, &tm);
    char buf[64];
    strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", &tm);
    return buf;
}

static uint64_t deviceIdCounter = 0;

std::string AnalyticsEngine::generateDeviceId() const
{
    return "dev_" + std::to_string(getCurrentTimestampMs()) + "_" + std::to_string(++deviceIdCounter);
}
