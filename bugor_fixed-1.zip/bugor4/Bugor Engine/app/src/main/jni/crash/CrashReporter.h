#pragma once
#include <string>

namespace CrashReporter {

void InstallHandlers();
void UninstallHandlers();
void SetCrashDir(const std::string& dir);

}
