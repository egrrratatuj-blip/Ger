#include "CrashReporter.h"
#include <signal.h>
#include <ucontext.h>
#include <unwind.h>
#include <dlfcn.h>
#include <cxxabi.h>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <cstdint>
#include <sstream>
#include <iomanip>
#include <vector>
#include <string>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

namespace Logging {
    std::vector<std::string> GetRecentLogs(size_t count);
}

static std::string s_crashDir;
static bool s_crashDirSet = false;

void SetCrashDir(const std::string& dir) {
    s_crashDir = dir;
    s_crashDirSet = true;
}

static std::string GetCrashDir() {
    if (s_crashDirSet && !s_crashDir.empty()) return s_crashDir;
    return "/data/data/com.bugor.engine/cache/crashes";
}

namespace CrashReporter {

static struct sigaction s_oldActions[NSIG];
static bool s_installed = false;

static const char* SignalName(int sig) {
    switch (sig) {
        case SIGSEGV: return "SIGSEGV";
        case SIGABRT: return "SIGABRT";
        case SIGILL:  return "SIGILL";
        case SIGFPE:  return "SIGFPE";
        case SIGBUS:  return "SIGBUS";
        default:      return "UNKNOWN";
    }
}

struct BacktraceState {
    void** current;
    void** end;
};

static _Unwind_Reason_Code UnwindCallback(struct _Unwind_Context* ctx, void* arg) {
    BacktraceState* state = static_cast<BacktraceState*>(arg);
    uintptr_t pc = _Unwind_GetIP(ctx);
    if (pc) {
        if (state->current >= state->end) return _URC_END_OF_STACK;
        *state->current++ = reinterpret_cast<void*>(pc);
    }
    return _URC_NO_REASON;
}

static std::string Demangle(const char* name) {
    if (!name || !*name) return "";
    int status = 0;
    char* demangled = abi::__cxa_demangle(name, nullptr, nullptr, &status);
    if (demangled) {
        std::string res(demangled);
        free(demangled);
        return res;
    }
    return name;
}

static std::string FormatStackFrame(int index, uintptr_t addr) {
    Dl_info info;
    std::ostringstream oss;
    oss << "#" << std::setw(2) << std::setfill('0') << index << " ";
    oss << "0x" << std::hex << addr << std::dec << " ";
    if (dladdr(reinterpret_cast<void*>(addr), &info) && info.dli_fname) {
        uintptr_t base = info.dli_fbase ? reinterpret_cast<uintptr_t>(info.dli_fbase) : 0;
        oss << info.dli_fname << "+0x" << std::hex << (addr - base) << std::dec;
        if (info.dli_sname) {
            oss << " " << Demangle(info.dli_sname);
        }
    } else {
        oss << "??";
    }
    return oss.str();
}

static void SignalHandler(int signum, siginfo_t* info, void* context) {
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = SIG_DFL;
    sigaction(signum, &sa, nullptr);

    const char* crashDir = GetCrashDir().c_str();
    mkdir(crashDir, 0755);

    time_t now = time(nullptr);
    struct tm t;
    localtime_r(&now, &t);
    char tsFile[32], tsDisplay[32];
    strftime(tsFile, sizeof(tsFile), "%Y%m%d_%H%M%S", &t);
    strftime(tsDisplay, sizeof(tsDisplay), "%Y-%m-%d %H:%M:%S", &t);

    std::string path = std::string(crashDir) + "/crash_" + tsFile + ".txt";
    int fd = open(path.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) {
        raise(signum);
        return;
    }

    auto WriteStr = [fd](const std::string& s) {
        write(fd, s.c_str(), s.size());
    };

    WriteStr("=== BUGOR ENGINE CRASH REPORT ===\n");
    WriteStr("Timestamp: " + std::string(tsDisplay) + "\n");
    {
        std::ostringstream oss;
        oss << "Signal: " << SignalName(signum) << " (" << signum << ") at 0x"
            << std::hex << (info ? reinterpret_cast<uintptr_t>(info->si_addr) : 0) << std::dec << "\n";
        WriteStr(oss.str());
    }
    WriteStr("\nStack Trace:\n");

    void* buffer[64];
    BacktraceState state;
    state.current = buffer;
    state.end = buffer + 64;
    _Unwind_Backtrace(UnwindCallback, &state);
    size_t frameCount = static_cast<size_t>(state.current - buffer);
    for (size_t i = 0; i < frameCount; ++i) {
        WriteStr(FormatStackFrame(static_cast<int>(i), reinterpret_cast<uintptr_t>(buffer[i])) + "\n");
    }

    WriteStr("\nRegisters:\n");
    if (context) {
        ucontext_t* uc = static_cast<ucontext_t*>(context);
#if defined(__aarch64__)
        for (int i = 0; i < 31; ++i) {
            std::ostringstream oss;
            oss << "x" << i << ": 0x" << std::hex << uc->uc_mcontext.regs[i] << std::dec << "\n";
            WriteStr(oss.str());
        }
        {
            std::ostringstream oss;
            oss << "sp: 0x" << std::hex << uc->uc_mcontext.sp << std::dec << "\n";
            oss << "pc: 0x" << std::hex << uc->uc_mcontext.pc << std::dec << "\n";
            WriteStr(oss.str());
        }
#elif defined(__arm__)
        uint32_t* arm_regs = &uc->uc_mcontext.arm_r0;
        for (int i = 0; i < 13; ++i) {
            std::ostringstream oss;
            oss << "r" << i << ": 0x" << std::hex << arm_regs[i] << std::dec << "\n";
            WriteStr(oss.str());
        }
        {
            std::ostringstream oss;
            oss << "sp:  0x" << std::hex << uc->uc_mcontext.arm_sp << std::dec << "\n";
            oss << "lr:  0x" << std::hex << uc->uc_mcontext.arm_lr << std::dec << "\n";
            oss << "pc:  0x" << std::hex << uc->uc_mcontext.arm_pc << std::dec << "\n";
            WriteStr(oss.str());
        }
#endif
    }

    WriteStr("\n/proc/self/maps:\n");
    int mapsFd = open("/proc/self/maps", O_RDONLY);
    if (mapsFd >= 0) {
        char buf[4096];
        ssize_t n;
        while ((n = read(mapsFd, buf, sizeof(buf))) > 0) {
            write(fd, buf, static_cast<size_t>(n));
        }
        close(mapsFd);
    }

    WriteStr("\nLast Log Entries:\n");
    auto logs = Logging::GetRecentLogs(50);
    for (const auto& log : logs) {
        WriteStr(log + "\n");
    }

    close(fd);
    raise(signum);
}

void InstallHandlers() {
    if (s_installed) return;
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_sigaction = SignalHandler;
    sa.sa_flags = SA_SIGINFO | SA_NODEFER;
    sigemptyset(&sa.sa_mask);
    int signals[] = {SIGSEGV, SIGABRT, SIGILL, SIGFPE, SIGBUS};
    for (int sig : signals) {
        sigaction(sig, &sa, &s_oldActions[sig]);
    }
    s_installed = true;
}

void UninstallHandlers() {
    if (!s_installed) return;
    int signals[] = {SIGSEGV, SIGABRT, SIGILL, SIGFPE, SIGBUS};
    for (int sig : signals) {
        sigaction(sig, &s_oldActions[sig], nullptr);
    }
    s_installed = false;
}

}
