LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)

LOCAL_MODULE := BugorEngine

LOCAL_CPPFLAGS := -std=c++20 -fvisibility=hidden -fno-rtti -fno-exceptions \
    -Wall -Wextra -Wno-unused-parameter -Wno-unused-variable -Wno-sign-compare \
    -O2 -DNDEBUG -DANDROID

LOCAL_CFLAGS := -O2 -DNDEBUG -DANDROID
LOCAL_LDFLAGS := -Wl,--gc-sections -s

LOCAL_C_INCLUDES := $(LOCAL_PATH)
LOCAL_C_INCLUDES += $(LOCAL_PATH)/app
LOCAL_C_INCLUDES += $(LOCAL_PATH)/app/ui
LOCAL_C_INCLUDES += $(LOCAL_PATH)/app/ui/tabs
LOCAL_C_INCLUDES += $(LOCAL_PATH)/app/ui/widgets
LOCAL_C_INCLUDES += $(LOCAL_PATH)/app/ui/overlay
LOCAL_C_INCLUDES += $(LOCAL_PATH)/app/ui/effects
LOCAL_C_INCLUDES += $(LOCAL_PATH)/app/ui/anim
LOCAL_C_INCLUDES += $(LOCAL_PATH)/core
LOCAL_C_INCLUDES += $(LOCAL_PATH)/memory
LOCAL_C_INCLUDES += $(LOCAL_PATH)/hooking
LOCAL_C_INCLUDES += $(LOCAL_PATH)/crash
LOCAL_C_INCLUDES += $(LOCAL_PATH)/encryption
LOCAL_C_INCLUDES += $(LOCAL_PATH)/persistence
LOCAL_C_INCLUDES += $(LOCAL_PATH)/remote
LOCAL_C_INCLUDES += $(LOCAL_PATH)/analytics
LOCAL_C_INCLUDES += $(LOCAL_PATH)/debugger
LOCAL_C_INCLUDES += $(LOCAL_PATH)/logging
LOCAL_C_INCLUDES += $(LOCAL_PATH)/imgui
LOCAL_C_INCLUDES += $(LOCAL_PATH)/imgui/backends

LOCAL_SRC_FILES := \
    main.cpp \
    RootJNI.cpp \
    \
    app/Aimbot.cpp \
    app/AimbotEnhanced.cpp \
    app/AntiCheatSystem.cpp \
    app/AntiDebug.cpp \
    app/ConfigSystem.cpp \
    app/ESP.cpp \
    app/GameOffsets.cpp \
    app/Globals.cpp \
    app/SkinChanger.cpp \
    app/LoggingSystem.cpp \
    app/MathUtils.cpp \
    app/MemoryIO.cpp \
    app/NetworkSystem.cpp \
    app/Obfuscator.cpp \
    app/Offsets.cpp \
    app/PluginSystem.cpp \
    app/ConfigSerializer.cpp \
    app/ConfigWatcher.cpp \
    app/MiscFeatures.cpp \
    \
    app/ui/Layout.cpp \
    \
    app/ui/tabs/TabAimbot.cpp \
    app/ui/tabs/TabConfig.cpp \
    app/ui/tabs/TabESP.cpp \
    app/ui/tabs/TabInfo.cpp \
    app/ui/tabs/TabLoot.cpp \
    app/ui/tabs/TabMisc.cpp \
    app/ui/tabs/TabPlayers.cpp \
    app/ui/tabs/TabRadar.cpp \
    app/ui/tabs/TabSkin.cpp \
    app/ui/tabs/TabTheme.cpp \
    \
    app/ui/widgets/Widgets_Buttons.cpp \
    app/ui/widgets/Widgets_Containers.cpp \
    app/ui/widgets/Widgets_Data.cpp \
    app/ui/widgets/Widgets_Dialogs.cpp \
    app/ui/widgets/Widgets_Input.cpp \
    app/ui/widgets/Widgets_Nav.cpp \
    app/ui/widgets/Widgets_Sliders.cpp \
    app/ui/widgets/Widgets_Switches.cpp \
    app/ui/widgets/Widgets_Text.cpp \
    app/ui/widgets/Widgets_Visuals.cpp \
    \
    app/ui/effects/Effects_Blur.cpp \
    app/ui/effects/Effects_Glow.cpp \
    app/ui/effects/Effects_Gradients.cpp \
    app/ui/effects/Effects_Particles.cpp \
    \
    app/ui/anim/Anim_Easing.cpp \
    app/ui/anim/Anim_Manager.cpp \
    \
    app/ui/overlay/Compass.cpp \
    app/ui/overlay/Crosshair.cpp \
    app/ui/overlay/InfoPanel.cpp \
    app/ui/overlay/Notifications.cpp \
    app/ui/overlay/Watermark.cpp \
    \
    core/BugorEngine.cpp \
    core/ScriptEngine.cpp \
    core/MemoryIO.cpp \
    core/MemoryPool.cpp \
    core/NetworkLayer.cpp \
    \
    memory/MemoryManager.cpp \
    \
    hooking/HookingFramework.cpp \
    \
    crash/CrashReporter.cpp \
    \
    encryption/EncryptionManager.cpp \
    \
    persistence/PersistenceManager.cpp \
    \
    remote/RemoteControl.cpp \
    \
    analytics/AnalyticsEngine.cpp \
    \
    debugger/Debugger.cpp \
    \
    logging/LoggingSystem.cpp \
    \
    BugorBridge.cpp

LOCAL_SRC_FILES += \
    imgui/imgui.cpp \
    imgui/imgui_draw.cpp \
    imgui/imgui_tables.cpp \
    imgui/imgui_widgets.cpp \
    imgui/imgui_demo.cpp \
    imgui/backends/imgui_impl_android.cpp \
    imgui/backends/imgui_impl_opengl3.cpp \
    imgui/backends/imgui_Input_android.cpp

LOCAL_LDLIBS := -llog -landroid -lEGL -lGLESv3 -lz

include $(BUILD_SHARED_LIBRARY)
