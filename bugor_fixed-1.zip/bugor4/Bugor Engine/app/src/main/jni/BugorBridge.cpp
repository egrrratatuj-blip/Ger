#include "BugorBridge.h"
#include <string>
#include <android/log.h>
#include <dlfcn.h>
#include <cstring>
#include <vector>
#include <map>
#include <sstream>

#include "core/BugorEngine.h"
#include "memory/MemoryManager.h"
#include "hooking/HookingFramework.h"
#include "crash/CrashReporter.h"
#include "core/ScriptEngine.h"
#include "app/LoggingSystem.h"
#include "encryption/EncryptionManager.h"
#include "persistence/PersistenceManager.h"
#include "remote/RemoteControl.h"
#include "analytics/AnalyticsEngine.h"
#include "debugger/Debugger.h"

#define LOG_TAG "BugorEngine"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static BugorEngine *g_engine = nullptr;

bool BugorNativeInitialize(const char* path) {
    LOGI("Initializing Bugor Engine with config: %s", path);
    g_engine = &BugorEngine::getInstance();
    EngineConfig config;
    config.app_name = "Bugor Engine";
    config.app_version = "3.0.0";
    config.data_directory = "/data/data/com.bugor.engine/";
    config.log_directory = "/data/data/com.bugor.engine/logs/";
    config.enable_logging = true;
    config.enable_crash_reporter = true;
    config.enable_script_engine = true;
    config.enable_analytics = true;
    config.enable_remote_control = true;
    config.enable_persistence = true;
    config.enable_encryption = true;
    config.enable_debugger = true;
    config.enable_hooking = true;
    config.enable_memory_operations = true;
    config.enable_multi_threading = true;
    config.mode = EngineMode::Standalone;
    return g_engine->initialize(config);
}

bool BugorNativeShutdown() {
    LOGI("Shutting down Bugor Engine");
    if (g_engine) {
        g_engine->shutdown();
        return true;
    }
    return false;
}

bool BugorNativeIsInitialized() {
    return g_engine && g_engine->isInitialized();
}

std::string BugorNativeGetVersion() {
    return g_engine ? g_engine->getVersion() : "unknown";
}

bool BugorNativeExecuteScript(const char* script) {
    if (g_engine && g_engine->getScriptEngine()) {
        g_engine->getScriptEngine()->executeScript(script);
        return true;
    }
    return false;
}

std::string BugorNativeExecuteCommand(const char* command) {
    if (g_engine) {
        return g_engine->executeCommand(command);
    }
    return "";
}

uintptr_t BugorNativeReadLong(uintptr_t address) {
    if (!g_engine || !g_engine->getMemoryManager()) return 0;
    return g_engine->getMemoryManager()->readLong(address);
}

int BugorNativeReadInt(uintptr_t address) {
    if (!g_engine || !g_engine->getMemoryManager()) return 0;
    return g_engine->getMemoryManager()->readInt(address);
}

float BugorNativeReadFloat(uintptr_t address) {
    if (!g_engine || !g_engine->getMemoryManager()) return 0.0f;
    return g_engine->getMemoryManager()->readFloat(address);
}

double BugorNativeReadDouble(uintptr_t address) {
    if (!g_engine || !g_engine->getMemoryManager()) return 0.0;
    return g_engine->getMemoryManager()->readDouble(address);
}

bool BugorNativeWriteLong(uintptr_t address, uintptr_t value) {
    if (!g_engine || !g_engine->getMemoryManager()) return false;
    return g_engine->getMemoryManager()->writeLong(address, value);
}

bool BugorNativeWriteInt(uintptr_t address, int value) {
    if (!g_engine || !g_engine->getMemoryManager()) return false;
    return g_engine->getMemoryManager()->writeInt(address, (uint32_t)value);
}

bool BugorNativeWriteFloat(uintptr_t address, float value) {
    if (!g_engine || !g_engine->getMemoryManager()) return false;
    return g_engine->getMemoryManager()->writeFloat(address, value);
}

bool BugorNativeWriteDouble(uintptr_t address, double value) {
    if (!g_engine || !g_engine->getMemoryManager()) return false;
    return g_engine->getMemoryManager()->writeDouble(address, value);
}

std::string BugorNativeSearchMemory(int valueType, uintptr_t value, int valueSize, uintptr_t regionStart, uintptr_t regionEnd) {
    if (!g_engine || !g_engine->getMemoryManager()) return "[]";
    MemorySearchPattern pattern;
    pattern.value_type = valueType;
    pattern.value = value;
    pattern.value_size = valueSize;
    pattern.use_value = true;
    auto results = g_engine->getMemoryManager()->search(pattern, regionStart, regionEnd);
    std::ostringstream json;
    json << "[";
    for (size_t i = 0; i < results.size(); i++) {
        if (i > 0) json << ",";
        json << "{\"address\":" << results[i].address;
        json << ",\"value\":" << results[i].current_value;
        json << ",\"size\":" << results[i].size;
        json << "}";
    }
    json << "]";
    return json.str();
}

bool BugorNativePatchMemory(uintptr_t address, const uint8_t* data, size_t len) {
    if (!g_engine || !g_engine->getMemoryManager()) return false;
    std::vector<uint8_t> bytes(data, data + len);
    return g_engine->getMemoryManager()->patchMemory(address, bytes);
}

uintptr_t BugorNativeGetModuleBase(const char* moduleName) {
    if (!g_engine || !g_engine->getMemoryManager()) return 0;
    return g_engine->getMemoryManager()->getModuleBase(moduleName);
}

std::string BugorNativeDumpMemory(uintptr_t address, int size) {
    if (!g_engine || !g_engine->getMemoryManager()) return "";
    return g_engine->getMemoryManager()->dumpHex(address, size);
}

int BugorNativeInstallHook(uintptr_t targetAddress, void* hookFunction) {
    if (!g_engine || !g_engine->getHookingFramework()) return -1;
    HookConfig config;
    config.target_address = targetAddress;
    config.hook_function = hookFunction;
    config.inline_hook = true;
    return (int)g_engine->getHookingFramework()->installHook(config);
}

bool BugorNativeUninstallHook(int hookId) {
    if (!g_engine || !g_engine->getHookingFramework()) return false;
    return g_engine->getHookingFramework()->uninstallHook(hookId);
}

bool BugorNativeFreezeValue(uintptr_t address, uintptr_t value, int valueType) {
    if (!g_engine || !g_engine->getMemoryManager()) return false;
    return g_engine->getMemoryManager()->freezeValue(address, value, valueType);
}

bool BugorNativeUnfreezeValue(uintptr_t address) {
    if (!g_engine || !g_engine->getMemoryManager()) return false;
    return g_engine->getMemoryManager()->unfreezeValue(address);
}

bool BugorNativeUnfreezeAll() {
    if (!g_engine || !g_engine->getMemoryManager()) return false;
    return g_engine->getMemoryManager()->unfreezeAll();
}

bool BugorNativeProtectMemory(uintptr_t address, size_t size, int protection) {
    if (!g_engine || !g_engine->getMemoryManager()) return false;
    return g_engine->getMemoryManager()->protectMemory(address, size, protection);
}

uintptr_t BugorNativeAllocateMemory(size_t size, int protection) {
    if (!g_engine || !g_engine->getMemoryManager()) return 0;
    return (uintptr_t)g_engine->getMemoryManager()->allocateMemory(size, protection);
}

bool BugorNativeFreeMemory(uintptr_t address) {
    if (!g_engine || !g_engine->getMemoryManager()) return false;
    return g_engine->getMemoryManager()->freeMemory(address);
}

std::string BugorNativeGetRegions() {
    if (!g_engine || !g_engine->getMemoryManager()) return "[]";
    auto regions = g_engine->getMemoryManager()->enumerateRegions();
    std::ostringstream json;
    json << "[";
    for (size_t i = 0; i < regions.size(); i++) {
        if (i > 0) json << ",";
        json << "{";
        json << "\"start\":" << regions[i].start << ",";
        json << "\"end\":" << regions[i].end << ",";
        json << "\"size\":" << regions[i].size << ",";
        json << "\"readable\":" << (regions[i].readable ? "true" : "false") << ",";
        json << "\"writable\":" << (regions[i].writable ? "true" : "false") << ",";
        json << "\"executable\":" << (regions[i].executable ? "true" : "false") << ",";
        json << "\"path\":\"" << regions[i].path << "\"";
        json << "}";
    }
    json << "]";
    return json.str();
}

bool BugorNativeLoadScriptFile(const char* path) {
    if (!g_engine || !g_engine->getScriptEngine()) return false;
    return g_engine->getScriptEngine()->loadScript(path);
}

bool BugorNativeLoadScript(const char* name, const char* source) {
    if (!g_engine || !g_engine->getScriptEngine()) return false;
    return g_engine->getScriptEngine()->loadScript(name, source);
}

bool BugorNativeConnectRemote(const char* host, int port, const char* apiKey) {
    if (!g_engine || !g_engine->getRemoteClient()) return false;
    ClientConfig config;
    config.server_host = host;
    config.server_port = port;
    config.api_key = apiKey;
    g_engine->getRemoteClient()->initialize(config);
    return g_engine->getRemoteClient()->connect();
}

bool BugorNativeDisconnectRemote() {
    if (!g_engine || !g_engine->getRemoteClient()) return false;
    g_engine->getRemoteClient()->disconnect();
    return true;
}

std::string BugorNativeSendRemoteCommand(const char* command, const char* args) {
    if (!g_engine || !g_engine->getRemoteClient()) return "";
    auto future = g_engine->getRemoteClient()->sendCommand(command, args);
    return future.get();
}

std::string BugorNativeEncrypt(const char* data, const char* key) {
    if (!g_engine || !g_engine->getEncryptionManager()) return "";
    EncryptionKey encKey;
    encKey.key_data = std::vector<uint8_t>(key, key + strlen(key));
    encKey.algorithm = CipherAlgorithm::AES_256_GCM;
    return g_engine->getEncryptionManager()->encryptString(data, encKey);
}

std::string BugorNativeDecrypt(const char* data, const char* key) {
    if (!g_engine || !g_engine->getEncryptionManager()) return "";
    EncryptionKey encKey;
    encKey.key_data = std::vector<uint8_t>(key, key + strlen(key));
    encKey.algorithm = CipherAlgorithm::AES_256_GCM;
    return g_engine->getEncryptionManager()->decryptString(data, encKey);
}

std::string BugorNativeHash(const char* data) {
    if (!g_engine || !g_engine->getEncryptionManager()) return "";
    return g_engine->getEncryptionManager()->hashString(data);
}

std::string BugorNativeGetMetrics() {
    if (!g_engine) return "{}";
    auto metrics = g_engine->getMetrics();
    std::ostringstream json;
    json << "{";
    json << "\"uptime_ms\":" << metrics.uptime_ms << ",";
    json << "\"memory_usage\":" << metrics.memory_usage << ",";
    json << "\"thread_count\":" << metrics.thread_count << ",";
    json << "\"total_operations\":" << metrics.total_operations << ",";
    json << "\"total_memory_reads\":" << metrics.total_memory_reads << ",";
    json << "\"total_memory_writes\":" << metrics.total_memory_writes << ",";
    json << "\"total_hooks_installed\":" << metrics.total_hooks_installed << ",";
    json << "\"total_scripts_executed\":" << metrics.total_scripts_executed << ",";
    json << "\"avg_response_time_ms\":" << metrics.avg_response_time_ms;
    json << "}";
    return json.str();
}

void BugorNativeSetLogLevel(int level) {
    if (!g_engine || !g_engine->getLoggingSystem()) return;
    g_engine->getLoggingSystem()->setLevel((BugorLogging::LogLevel)level);
}

void BugorNativeLog(int level, const char* message) {
    if (!g_engine || !g_engine->getLoggingSystem()) return;
    g_engine->getLoggingSystem()->log((BugorLogging::LogLevel)level, message);
}

bool BugorNativeAttachDebugger(int pid) {
    if (!g_engine || !g_engine->getDebugger()) return false;
    DebuggerConfig config;
    config.attach_pid = pid;
    config.attach_existing = true;
    return g_engine->getDebugger()->initialize(config);
}

bool BugorNativeDetachDebugger() {
    if (!g_engine || !g_engine->getDebugger()) return false;
    return g_engine->getDebugger()->detach();
}

bool BugorNativeSetBreakpoint(uintptr_t address) {
    if (!g_engine || !g_engine->getDebugger()) return false;
    g_engine->getDebugger()->addBreakpoint(address);
    return true;
}

bool BugorNativeStoreValue(const char* key, const char* value) {
    if (!g_engine || !g_engine->getPersistenceManager()) return false;
    return g_engine->getPersistenceManager()->store(key, value);
}

std::string BugorNativeLoadValue(const char* key) {
    if (!g_engine || !g_engine->getPersistenceManager()) return "";
    return g_engine->getPersistenceManager()->getString(key);
}

bool BugorNativeDeleteValue(const char* key) {
    if (!g_engine || !g_engine->getPersistenceManager()) return false;
    return g_engine->getPersistenceManager()->remove(key);
}

std::string BugorNativeGetHealthStatus() {
    if (!g_engine) return "{}";
    auto health = g_engine->getHealthStatus();
    std::ostringstream json;
    json << "{";
    json << "\"memory_subsystem_healthy\":" << (health.memory_subsystem_healthy ? "true" : "false") << ",";
    json << "\"hooking_subsystem_healthy\":" << (health.hooking_subsystem_healthy ? "true" : "false") << ",";
    json << "\"script_engine_healthy\":" << (health.script_engine_healthy ? "true" : "false") << ",";
    json << "\"crash_reporter_healthy\":" << (health.crash_reporter_healthy ? "true" : "false");
    json << "}";
    return json.str();
}

void* BugorNativeGetEnginePointer() {
    return (void*)g_engine;
}

int BugorNativeGetState() {
    if (!g_engine) return 0;
    return (int)g_engine->getState();
}

bool BugorNativePause() {
    if (!g_engine) return false;
    return g_engine->pause();
}

bool BugorNativeResume() {
    if (!g_engine) return false;
    return g_engine->resume();
}

bool BugorNativeRestart() {
    if (!g_engine) return false;
    return g_engine->restart();
}

std::string BugorNativeGetBuildInfo() {
    return "Bugor Engine v3.0.0 - ARM64/ARM32/x86_64 - Built with NDK r26";
}

bool BugorNativeRegisterFunction(const char* name, void* funcPtr) {
    return false;
}

bool BugorNativeStartServer(int port) {
    return false;
}

bool BugorNativeStopServer() {
    return false;
}
