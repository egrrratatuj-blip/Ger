#pragma once
#include "MemoryIO.h"
#include "Config.h"
#include <vector>
#include <string>

enum BoneID {
    Hips = 0,
    Spine,
    Spine1,
    Spine2,
    Neck,
    Head,
    LeftShoulder,
    LeftArm,
    LeftForearm,
    LeftHand,
    RightShoulder,
    RightArm,
    RightForearm,
    RightHand,
    LeftThigh,
    LeftCalf,
    LeftFoot,
    RightThigh,
    RightCalf,
    RightFoot
};

struct GamesOffsetTable {
    const char *GamePackage;
    const char *GameModule;
    const char *GameName;
    uintptr_t OffsetUWorld;
    uintptr_t OffsetGameInstance;
    uintptr_t OffsetLocalPlayer;
    uintptr_t OffsetPlayerController;
    uintptr_t OffsetCameraManager;
    uintptr_t OffsetEntityList;
    uintptr_t OffsetEntityCount;
    uintptr_t OffsetEntityBase;
    uintptr_t OffsetEntityPos;
    uintptr_t OffsetEntityHead;
    uintptr_t OffsetEntityHealth;
    uintptr_t OffsetEntityMaxHealth;
    uintptr_t OffsetEntityArmor;
    uintptr_t OffsetEntityShield;
    uintptr_t OffsetEntityName;
    uintptr_t OffsetEntityWeapon;
    uintptr_t OffsetEntityTeam;
    uintptr_t OffsetEntityAlive;
    uintptr_t OffsetEntityBone;
    uintptr_t OffsetEntityMesh;
    uintptr_t OffsetMatrix;
    uintptr_t OffsetViewPort;
    uintptr_t OffsetViewMatrix;
    uintptr_t OffsetProjectionMatrix;
    uintptr_t OffsetCameraPos;
    uintptr_t OffsetCameraRot;
    uintptr_t OffsetCameraFOV;
    uintptr_t OffsetRecoil;
    uintptr_t OffsetSpread;
    uintptr_t OffsetFireRate;
    uintptr_t OffsetFireFlag;
    uintptr_t OffsetAmmo;
    uintptr_t OffsetMaxAmmo;
    uintptr_t OffsetVelocity;
    uintptr_t OffsetIsVisible;
    uintptr_t OffsetPlayerStats;
    uintptr_t OffsetForceAttack;
    std::vector<uintptr_t> TraceUWorld;
    std::vector<uintptr_t> TraceEntityList;
};

class GameOffsets {
public:
    MemoryIO *Mem;
    bool Initialized;
    uintptr_t UnityBase;
    uintptr_t UWorld;
    uintptr_t GameInstance;
    uintptr_t LocalPlayer;
    uintptr_t PlayerController;
    uintptr_t CameraManager;
    uintptr_t OffsetCameraManager;
    uintptr_t OffsetVelocity;
    uintptr_t EntityListPtr;
    uintptr_t ViewMatrixAddr;
    uintptr_t CameraAddr;
    int EntityCount;
    int CurrentGameID;
    float ViewMatrix[16];
    D3DVector CameraPos;
    float CameraYaw;
    float CameraFOV;
    uintptr_t ForceAttackAddr;
    GamesOffsetTable GamesTable[4];
    
    GameOffsets(MemoryIO *mem);
    void InitGame(int gameID);
    int DetectGame();
    void UpdateViewMatrix();
    void UpdateCamera();
    bool UpdateEntityList();
    bool ReadEntityData(int index, PlayerData *data);
    D3DVector GetBonePosition(uintptr_t boneAddr, int boneID);
    bool UpdateOffsets();
    void Reset();
    uintptr_t TraceChain(uintptr_t base, std::vector<uintptr_t> chain);
};
