#pragma once
#include "../../../../imgui/imgui.h"

void M_FloatLabel(const char* label, ImVec2 pos, ImColor color, float size = 22.0f);
void M_GradientText(ImDrawList* dl, const char* text, ImVec2 pos, ImColor colorA, ImColor colorB, float size = 22.0f);
void M_GlitchText(ImDrawList* dl, const char* text, ImVec2 pos, ImColor color, float size = 22.0f, float glitchAmount = 5.0f);
void M_OutlinedText(ImDrawList* dl, const char* text, ImVec2 pos, ImColor textColor, ImColor outlineColor, float size = 22.0f);
void M_TypewriterText(ImDrawList* dl, const char* text, ImVec2 pos, ImColor color, float size = 22.0f, float speed = 10.0f);
void M_ScrollingText(ImDrawList* dl, const char* text, ImVec2 pos, float width, ImColor color, float size = 22.0f, float speed = 50.0f);
void M_RainbowText(ImDrawList* dl, const char* text, ImVec2 pos, float saturation = 1.0f, float value = 1.0f, float speed = 1.0f, float size = 22.0f);
void M_WavyText(ImDrawList* dl, const char* text, ImVec2 pos, ImColor color, float amplitude = 5.0f, float frequency = 10.0f, float size = 22.0f);
void M_FadeText(ImDrawList* dl, const char* text, ImVec2 pos, ImColor color, float fadeLeft = 0.0f, float fadeRight = 1.0f, float size = 22.0f);
