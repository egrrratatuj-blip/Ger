#pragma once
#include "../../../imgui/imgui.h"
#include "../../../imgui/imgui_internal.h"
#include "Anim_Easing.h"
#include <string.h>

struct SpringAnim {
    float value;
    float velocity;
    float target;
    float stiffness;
    float damping;
    float mass;
    SpringAnim();
    void SetTarget(float t);
    void Update(float dt);
    bool IsDone();
};

class AnimationTrack {
public:
    enum Type { FLOAT, VEC2, COLOR };
    enum LoopMode { ONCE, LOOP, PING_PONG };
    Type type;
    LoopMode loop;
    float duration;
    float elapsed;
    float delay;
    float delayRemaining;
    int easingType;
    bool playing;
    bool completed;
    bool reverse;
    char name[64];
    float startFloat, endFloat, currentFloat;
    ImVec2 startVec2, endVec2, currentVec2;
    ImColor startColor, endColor, currentColor;
    void (*onComplete)(const char* name);
    void (*onUpdate)(const char* name, float value);
    AnimationTrack();
    void Play();
    void Stop();
    void Pause();
    void Resume();
    void Reset();
    void SetFloat(const char* name, float from, float to, float dur, int ease, float delay = 0.0f);
    void SetVec2(const char* name, ImVec2 from, ImVec2 to, float dur, int ease, float delay = 0.0f);
    void SetColor(const char* name, ImColor from, ImColor to, float dur, int ease, float delay = 0.0f);
    void Update(float dt);
    float GetFloat();
    ImVec2 GetVec2();
    ImColor GetColor();
    float GetProgress();
};

class AnimationGroup {
public:
    AnimationTrack tracks[16];
    int trackCount;
    bool parallel;
    bool playing;
    AnimationGroup();
    void AddTrack(AnimationTrack& track);
    void SetParallel(bool p);
    void Play();
    void Stop();
    void Update(float dt);
    bool IsPlaying();
};

class AnimationManager {
public:
    AnimationTrack tracks[64];
    int trackCount;
    AnimationGroup groups[8];
    int groupCount;
    AnimationManager();
    int CreateTrack();
    bool DestroyTrack(int id);
    int CreateGroup();
    bool DestroyGroup(int id);
    AnimationTrack* GetTrack(int id);
    AnimationGroup* GetGroup(int id);
    void UpdateAll(float dt);
    void StopAll();
    void PauseAll();
    int GetActiveCount();
};

struct SimpleTween {
    char id[64];
    float currentValue;
    float targetValue;
    float speed;
    bool active;
    ImColor currentColor;
    ImColor targetColor;
    bool isColor;
};

void TweenFloat(const char* id, float target, float speed);
float GetTweenedFloat(const char* id);
void TweenColor(const char* id, ImColor target, float speed);
ImColor GetTweenedColor(const char* id);
void UpdateTweens(float dt);

class Sequencer {
public:
    struct Step {
        float duration;
        int easingType;
        float (*getValue)();
        void (*setValue)(float);
        float startVal;
        float endVal;
    };
    Step steps[32];
    int stepCount;
    int currentStep;
    float stepTime;
    bool playing;
    bool loop;
    Sequencer();
    void AddStep(float dur, int ease, float(*get)(), void(*set)(), float end);
    void Play();
    void Stop();
    void Update(float dt);
    float GetCurrentValue();
};

AnimationManager* GetAnimManager();
