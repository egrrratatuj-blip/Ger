#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "../../Config.h"
#include "../../../imgui/imgui.h"
#include "../../../imgui/imgui_internal.h"
#include <math.h>

static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }

extern Config g_Cfg;
extern Toggles g_Tog;

static int s_style = 0;
static float s_recoilOffset = 0.0f;
static float s_pulsePhase = 0.0f;
static bool s_wasFiring = false;

static ImVec2 GetSafeCenter() {
    ImVec2 sz = ImGui::GetIO().DisplaySize;
    if (sz.x < 1.0f) sz.x = 1.0f;
    if (sz.y < 1.0f) sz.y = 1.0f;
    return ImVec2(sz.x * 0.5f, sz.y * 0.5f);
}

void SetCrosshairStyle(int style) {
    if (style >= 0 && style <= 5) s_style = style;
}

int GetCrosshairStyle() {
    return s_style;
}

void TriggerCrosshairRecoil() {
    s_recoilOffset = 15.0f;
}

static void DrawCrossDefault(ImDrawList* dl, ImVec2 center, float size, float thick, ImColor col, float dt) {
    if (size < 1.0f) size = 1.0f;
    if (thick < 0.5f) thick = 0.5f;
    float gap = 4.0f;
    float len = size;
    ImColor glowCol = ImColor(col.Value.x, col.Value.y, col.Value.z, 40);
    float glowSize = 2.5f;
    dl->AddLine(ImVec2(center.x, center.y - gap - len - glowSize), ImVec2(center.x, center.y - gap + glowSize), C(glowCol), thick + 4.0f);
    dl->AddLine(ImVec2(center.x, center.y + gap - glowSize), ImVec2(center.x, center.y + gap + len + glowSize), C(glowCol), thick + 4.0f);
    dl->AddLine(ImVec2(center.x - gap - len - glowSize, center.y), ImVec2(center.x - gap + glowSize, center.y), C(glowCol), thick + 4.0f);
    dl->AddLine(ImVec2(center.x + gap - glowSize, center.y), ImVec2(center.x + gap + len + glowSize, center.y), C(glowCol), thick + 4.0f);
    dl->AddLine(ImVec2(center.x, center.y - gap - len), ImVec2(center.x, center.y - gap), C(col), thick);
    dl->AddLine(ImVec2(center.x, center.y + gap), ImVec2(center.x, center.y + gap + len), C(col), thick);
    dl->AddLine(ImVec2(center.x - gap - len, center.y), ImVec2(center.x - gap, center.y), C(col), thick);
    dl->AddLine(ImVec2(center.x + gap, center.y), ImVec2(center.x + gap + len, center.y), C(col), thick);
}

static void DrawCrossDot(ImDrawList* dl, ImVec2 center, float size, ImColor col) {
    float radius = size * 0.25f;
    if (radius < 2.0f) radius = 2.0f;
    ImColor glowCol = ImColor(col.Value.x, col.Value.y, col.Value.z, 30);
    dl->AddCircleFilled(center, radius + 4.0f, C(glowCol), 24);
    dl->AddCircleFilled(center, radius, C(col), 24);
}

static void DrawCrossCircle(ImDrawList* dl, ImVec2 center, float size, ImColor col, float dt) {
    s_pulsePhase += dt * 3.0f;
    if (s_pulsePhase > 1000.0f) s_pulsePhase -= 1000.0f;
    float radius = size + sinf(s_pulsePhase) * 2.0f;
    if (radius < 4.0f) radius = 4.0f;
    ImColor glowCol = ImColor(col.Value.x, col.Value.y, col.Value.z, 30);
    dl->AddCircle(center, radius + 3.0f, C(glowCol), 32, 3.0f);
    dl->AddCircle(center, radius, C(col), 32, 2.0f);
    float dotRadius = 2.5f;
    dl->AddCircleFilled(center, dotRadius + 2.0f, C(glowCol), 16);
    dl->AddCircleFilled(center, dotRadius, C(col), 16);
}

static void DrawCrossDynamic(ImDrawList* dl, ImVec2 center, float size, float thick, ImColor col, float dt) {
    if (size < 1.0f) size = 1.0f;
    if (thick < 0.5f) thick = 0.5f;
    s_recoilOffset += dt * 10.0f;
    if (s_recoilOffset > 100.0f) s_recoilOffset = 100.0f;
    s_recoilOffset *= 0.9f;
    if (s_recoilOffset < 0.1f) s_recoilOffset = 0.0f;
    float gap = 4.0f + s_recoilOffset;
    float len = size + s_recoilOffset * 0.5f;
    ImColor glowCol = ImColor(col.Value.x, col.Value.y, col.Value.z, 40);
    dl->AddLine(ImVec2(center.x, center.y - gap - len), ImVec2(center.x, center.y - gap), C(glowCol), thick + 4.0f);
    dl->AddLine(ImVec2(center.x, center.y + gap), ImVec2(center.x, center.y + gap + len), C(glowCol), thick + 4.0f);
    dl->AddLine(ImVec2(center.x - gap - len, center.y), ImVec2(center.x - gap, center.y), C(glowCol), thick + 4.0f);
    dl->AddLine(ImVec2(center.x + gap, center.y), ImVec2(center.x + gap + len, center.y), C(glowCol), thick + 4.0f);
    dl->AddLine(ImVec2(center.x, center.y - gap - len), ImVec2(center.x, center.y - gap), C(col), thick);
    dl->AddLine(ImVec2(center.x, center.y + gap), ImVec2(center.x, center.y + gap + len), C(col), thick);
    dl->AddLine(ImVec2(center.x - gap - len, center.y), ImVec2(center.x - gap, center.y), C(col), thick);
    dl->AddLine(ImVec2(center.x + gap, center.y), ImVec2(center.x + gap + len, center.y), C(col), thick);
}

static void DrawCrossCorner(ImDrawList* dl, ImVec2 center, float size, float thick, ImColor col) {
    if (size < 1.0f) size = 1.0f;
    if (thick < 0.5f) thick = 0.5f;
    float offset = 8.0f;
    float len = size * 0.5f;
    if (len < 4.0f) len = 4.0f;
    float gap = 2.0f;
    float dotSize = 2.5f;
    ImColor glowCol = ImColor(col.Value.x, col.Value.y, col.Value.z, 40);
    dl->AddLine(ImVec2(center.x - offset, center.y - offset - len), ImVec2(center.x - offset, center.y - offset), C(glowCol), thick + 3.0f);
    dl->AddLine(ImVec2(center.x - offset - len, center.y - offset), ImVec2(center.x - offset, center.y - offset), C(glowCol), thick + 3.0f);
    dl->AddLine(ImVec2(center.x + offset, center.y - offset - len), ImVec2(center.x + offset, center.y - offset), C(glowCol), thick + 3.0f);
    dl->AddLine(ImVec2(center.x + offset + len, center.y - offset), ImVec2(center.x + offset, center.y - offset), C(glowCol), thick + 3.0f);
    dl->AddLine(ImVec2(center.x - offset, center.y + offset + len), ImVec2(center.x - offset, center.y + offset), C(glowCol), thick + 3.0f);
    dl->AddLine(ImVec2(center.x - offset - len, center.y + offset), ImVec2(center.x - offset, center.y + offset), C(glowCol), thick + 3.0f);
    dl->AddLine(ImVec2(center.x + offset, center.y + offset + len), ImVec2(center.x + offset, center.y + offset), C(glowCol), thick + 3.0f);
    dl->AddLine(ImVec2(center.x + offset + len, center.y + offset), ImVec2(center.x + offset, center.y + offset), C(glowCol), thick + 3.0f);
    dl->AddLine(ImVec2(center.x - offset, center.y - offset - len), ImVec2(center.x - offset, center.y - offset), C(col), thick);
    dl->AddLine(ImVec2(center.x - offset - len, center.y - offset), ImVec2(center.x - offset, center.y - offset), C(col), thick);
    dl->AddLine(ImVec2(center.x + offset, center.y - offset - len), ImVec2(center.x + offset, center.y - offset), C(col), thick);
    dl->AddLine(ImVec2(center.x + offset + len, center.y - offset), ImVec2(center.x + offset, center.y - offset), C(col), thick);
    dl->AddLine(ImVec2(center.x - offset, center.y + offset + len), ImVec2(center.x - offset, center.y + offset), C(col), thick);
    dl->AddLine(ImVec2(center.x - offset - len, center.y + offset), ImVec2(center.x - offset, center.y + offset), C(col), thick);
    dl->AddLine(ImVec2(center.x + offset, center.y + offset + len), ImVec2(center.x + offset, center.y + offset), C(col), thick);
    dl->AddLine(ImVec2(center.x + offset + len, center.y + offset), ImVec2(center.x + offset, center.y + offset), C(col), thick);
    dl->AddCircleFilled(ImVec2(center.x - offset - len, center.y - offset - len), dotSize, C(col), 8);
    dl->AddCircleFilled(ImVec2(center.x + offset + len, center.y - offset - len), dotSize, C(col), 8);
    dl->AddCircleFilled(ImVec2(center.x - offset - len, center.y + offset + len), dotSize, C(col), 8);
    dl->AddCircleFilled(ImVec2(center.x + offset + len, center.y + offset + len), dotSize, C(col), 8);
}

static void DrawCrossPrecision(ImDrawList* dl, ImVec2 center, float size, float thick, ImColor col) {
    if (size < 1.0f) size = 1.0f;
    if (thick < 0.5f) thick = 0.5f;
    float len = size * 0.4f;
    float gap = 2.0f;
    float dotSize = 1.5f;
    if (len < 3.0f) len = 3.0f;
    ImColor glowCol = ImColor(col.Value.x, col.Value.y, col.Value.z, 30);
    dl->AddLine(ImVec2(center.x, center.y - gap - len), ImVec2(center.x, center.y - gap), C(glowCol), thick + 2.0f);
    dl->AddLine(ImVec2(center.x, center.y + gap), ImVec2(center.x, center.y + gap + len), C(glowCol), thick + 2.0f);
    dl->AddLine(ImVec2(center.x - gap - len, center.y), ImVec2(center.x - gap, center.y), C(glowCol), thick + 2.0f);
    dl->AddLine(ImVec2(center.x + gap, center.y), ImVec2(center.x + gap + len, center.y), C(glowCol), thick + 2.0f);
    dl->AddLine(ImVec2(center.x, center.y - gap - len), ImVec2(center.x, center.y - gap), C(col), thick);
    dl->AddLine(ImVec2(center.x, center.y + gap), ImVec2(center.x, center.y + gap + len), C(col), thick);
    dl->AddLine(ImVec2(center.x - gap - len, center.y), ImVec2(center.x - gap, center.y), C(col), thick);
    dl->AddLine(ImVec2(center.x + gap, center.y), ImVec2(center.x + gap + len, center.y), C(col), thick);
    float dotOff = gap + len + 2.0f;
    dl->AddCircleFilled(ImVec2(center.x, center.y - dotOff), dotSize, C(col), 6);
    dl->AddCircleFilled(ImVec2(center.x, center.y + dotOff), dotSize, C(col), 6);
    dl->AddCircleFilled(ImVec2(center.x - dotOff, center.y), dotSize, C(col), 6);
    dl->AddCircleFilled(ImVec2(center.x + dotOff, center.y), dotSize, C(col), 6);
}

void DrawCrosshair(ImDrawList* dl, float dt) {
    if (!g_Tog.ShowCrosshair) return;
    ImVec2 center = GetSafeCenter();
    float size = g_Cfg.CrosshairSize;
    float thick = g_Cfg.CrosshairThickness;
    ImColor col = g_Cfg.CrosshairColor;
    switch (s_style) {
        case 0: DrawCrossDefault(dl, center, size, thick, col, dt); break;
        case 1: DrawCrossDot(dl, center, size, col); break;
        case 2: DrawCrossCircle(dl, center, size, col, dt); break;
        case 3: DrawCrossDynamic(dl, center, size, thick, col, dt); break;
        case 4: DrawCrossCorner(dl, center, size, thick, col); break;
        case 5: DrawCrossPrecision(dl, center, size, thick, col); break;
        default: DrawCrossDefault(dl, center, size, thick, col, dt); break;
    }
}

void DrawCrosshairAt(ImDrawList* dl, ImVec2 pos, float dt) {
    if (!g_Tog.ShowCrosshair) return;
    float size = g_Cfg.CrosshairSize;
    float thick = g_Cfg.CrosshairThickness;
    ImColor col = g_Cfg.CrosshairColor;
    switch (s_style) {
        case 0: DrawCrossDefault(dl, pos, size, thick, col, dt); break;
        case 1: DrawCrossDot(dl, pos, size, col); break;
        case 2: DrawCrossCircle(dl, pos, size, col, dt); break;
        case 3: DrawCrossDynamic(dl, pos, size, thick, col, dt); break;
        case 4: DrawCrossCorner(dl, pos, size, thick, col); break;
        case 5: DrawCrossPrecision(dl, pos, size, thick, col); break;
        default: DrawCrossDefault(dl, pos, size, thick, col, dt); break;
    }
}

void DrawCrosshairWithOffset(ImDrawList* dl, float offsetX, float offsetY, float dt) {
    if (!g_Tog.ShowCrosshair) return;
    ImVec2 center = GetSafeCenter();
    center.x += offsetX;
    center.y += offsetY;
    float size = g_Cfg.CrosshairSize;
    float thick = g_Cfg.CrosshairThickness;
    ImColor col = g_Cfg.CrosshairColor;
    switch (s_style) {
        case 0: DrawCrossDefault(dl, center, size, thick, col, dt); break;
        case 1: DrawCrossDot(dl, center, size, col); break;
        case 2: DrawCrossCircle(dl, center, size, col, dt); break;
        case 3: DrawCrossDynamic(dl, center, size, thick, col, dt); break;
        case 4: DrawCrossCorner(dl, center, size, thick, col); break;
        case 5: DrawCrossPrecision(dl, center, size, thick, col); break;
        default: DrawCrossDefault(dl, center, size, thick, col, dt); break;
    }
}

void CycleCrosshairStyle() {
    s_style = (s_style + 1) % 6;
}

void ResetCrosshairRecoil() {
    s_recoilOffset = 0.0f;
}

void DrawCrosshairPreview(ImDrawList* dl, ImVec2 pos, int style, float size, float thick, ImColor col) {
    float dt = ImGui::GetIO().DeltaTime;
    switch (style) {
        case 0: DrawCrossDefault(dl, pos, size, thick, col, dt); break;
        case 1: DrawCrossDot(dl, pos, size, col); break;
        case 2: DrawCrossCircle(dl, pos, size, col, dt); break;
        case 3: DrawCrossDynamic(dl, pos, size, thick, col, dt); break;
        case 4: DrawCrossCorner(dl, pos, size, thick, col); break;
        case 5: DrawCrossPrecision(dl, pos, size, thick, col); break;
        default: DrawCrossDefault(dl, pos, size, thick, col, dt); break;
    }
}
