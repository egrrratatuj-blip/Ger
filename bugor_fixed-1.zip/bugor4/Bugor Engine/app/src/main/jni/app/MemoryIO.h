#pragma once
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
#include <pthread.h>
#include <sys/syscall.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <dlfcn.h>
#include <vector>
#include <string>
#include <stdint.h>
#include <cstring>
#include <signal.h>

struct BatchEntry {
    uintptr_t addr;
    void* buf;
    size_t size;
};

class MemoryIO {
public:
    pthread_mutex_t m_mutex;
    int pid;
    int m_TimeoutMs;
    MemoryIO();
    void Init(int pid1);
    void SetTimeout(int ms);
    int GetPID(const char *packageName);
    ssize_t ProcessVM(pid_t pid, const struct iovec *local, unsigned long lcnt,
                      const struct iovec *remote, unsigned long rcnt,
                      unsigned long flags, bool write);
    bool PVM(void *addr, void *buf, size_t size, bool write);
    bool Read(uintptr_t addr, void *buf, size_t size);
    bool Write(uintptr_t addr, void *buf, size_t size);
    float ReadFloat(uintptr_t addr);
    int ReadInt(uintptr_t addr);
    uint32_t ReadDword(uintptr_t addr);
    uint64_t ReadQword(uintptr_t addr);
    uint8_t ReadByte(uintptr_t addr);
    uintptr_t ReadPtr64(uintptr_t addr);
    uintptr_t ReadPtr32(uintptr_t addr);
    void WriteFloat(uintptr_t addr, float val);
    void WriteInt(uintptr_t addr, int val);
    void WriteDword(uintptr_t addr, uint32_t val);
    void WriteQword(uintptr_t addr, uint64_t val);
    uintptr_t GetModuleBase(const char *name);
    uintptr_t GetModuleBase(const char *name, bool exactMatch);
    uintptr_t GetBSS(const char *name);
    size_t GetModuleSize(const char *name);
    bool ReadString(uintptr_t addr, char *buf, size_t maxLen);
    bool ReadUTF8String(uintptr_t addr, char *buf, size_t maxLen);
    uintptr_t FindSignature(const char *module, const char *pattern, const char *mask);
    std::vector<uintptr_t> FindSignatures(const char *module, const char *pattern, const char *mask);
    uintptr_t TracePointer(uintptr_t addr, std::vector<uintptr_t> offsets);
    bool ReadBatch(std::vector<BatchEntry>& entries);
};
