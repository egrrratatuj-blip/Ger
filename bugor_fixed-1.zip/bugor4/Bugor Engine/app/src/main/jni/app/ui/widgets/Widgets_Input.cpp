#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "../../../imgui/imgui.h"
#include "../../../imgui/imgui_internal.h"
#include "../../../imgui/mycustom/imgui_Custom.h"
#include <math.h>
#include <string.h>
#include <map>
#include <stdlib.h>

static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }

bool M_KeybindRecorder(const char* label, int* key, ImColor accent)
{
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGuiContext& g = *GImGui;
    ImGui::PushID(label);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 4.0f);

    ImVec2 pos = ImGui::GetCursorScreenPos();
    float fullWidth = ImGui::GetContentRegionAvail().x;
    if (fullWidth < 80.0f) fullWidth = 80.0f;

    ImVec2 labelSize = ImGui::CalcTextSize(label);
    ImGui::RenderText(ImVec2(pos.x, pos.y), label);

    float boxY = pos.y + labelSize.y + 4.0f;
    float boxHeight = 34.0f;
    ImVec2 boxMin(pos.x, boxY);
    ImVec2 boxMax(pos.x + fullWidth, boxY + boxHeight);

    ImGuiID id = ImGui::GetID("_kb");
    ImRect boxRect(boxMin, boxMax);
    ImGui::ItemSize(ImVec2(fullWidth, boxHeight));
    ImGui::ItemAdd(boxRect, id);

    bool isRecording = false;
    static std::map<ImGuiID, bool> s_recordingStates;
    auto recIt = s_recordingStates.find(id);
    if (recIt == s_recordingStates.end())
    {
        recIt = s_recordingStates.emplace(id, false).first;
    }
    isRecording = recIt->second;

    bool changed = false;

    if (ImGui::IsItemHovered() && ImGui::IsMouseClicked(0))
    {
        isRecording = true;
    }

    if (isRecording)
    {
        ImGuiIO& io = ImGui::GetIO();
        for (int i = ImGuiKey_NamedKey_BEGIN; i < ImGuiKey_NamedKey_END; i++)
        {
            if (ImGui::IsKeyPressed(i))
            {
                if (i == ImGuiKey_Escape)
                {
                    isRecording = false;
                }
                else if (i == ImGuiKey_Enter || i == ImGuiKey_Space)
                {
                }
                else
                {
                    *key = i;
                    changed = true;
                    isRecording = false;
                }
            }
        }

        if (ImGui::IsMouseClicked(0) && !ImGui::IsItemHovered())
        {
            isRecording = false;
        }
    }

    recIt->second = isRecording;

    if (*key >= ImGuiKey_NamedKey_BEGIN && *key < ImGuiKey_NamedKey_END)
    {
        const char* keyName = ImGui::GetKeyName(*key);
        ImVec2 textSize = ImGui::CalcTextSize(keyName);

        if (isRecording)
        {
            draw->AddRectFilled(boxMin, boxMax, C(ImColor(60, 30, 30)), 6.0f);
            draw->AddRect(boxMin, boxMax, C(ImColor(200, 80, 80)), 6.0f);

            const char* waitingText = "...";
            ImVec2 waitingSize = ImGui::CalcTextSize(waitingText);
            float blink = sinf(ImGui::GetTime() * 6.0f) * 0.5f + 0.5f;
            ImColor waitingCol(255, 150, 150, (int)(150 + 105 * blink));
            draw->AddText(ImVec2(boxMin.x + (fullWidth - waitingSize.x) * 0.5f,
                                 boxMin.y + (boxHeight - waitingSize.y) * 0.5f),
                          C(waitingCol), waitingText);
        }
        else
        {
            draw->AddRectFilled(boxMin, boxMax, C(ImColor(35, 35, 45)), 6.0f);
            draw->AddRect(boxMin, boxMax, C(ImColor(55, 55, 70)), 6.0f);

            float bgW = textSize.x + 16.0f;
            float bgX = boxMin.x + 8.0f;
            ImVec2 kbMin(bgX, boxMin.y + 4.0f);
            ImVec2 kbMax(bgX + bgW, boxMax.y - 4.0f);
            draw->AddRectFilled(kbMin, kbMax, C(ImColor(50, 50, 60)), 4.0f);
            draw->AddRect(kbMin, kbMax, C(ImColor(70, 70, 85)), 4.0f);
            draw->AddText(ImVec2(bgX + 8.0f, boxMin.y + (boxHeight - textSize.y) * 0.5f),
                C(ImColor(220, 220, 220)), keyName);

            float clearX = boxMax.x - 20.0f;
            float clearY = boxMin.y + boxHeight * 0.5f;
            bool clearHov = fabsf(ImGui::GetMousePos().x - clearX) < 8.0f &&
                            fabsf(ImGui::GetMousePos().y - clearY) < 8.0f;
            draw->AddCircleFilled(ImVec2(clearX, clearY), 6.0f,
                C(clearHov ? ImColor(180, 60, 60) : ImColor(60, 60, 60)));
            draw->AddText(ImVec2(clearX - 3.0f, clearY - 6.0f),
                C(clearHov ? ImColor(255, 255, 255) : ImColor(140, 140, 140)), "x");
            if (clearHov && ImGui::IsMouseClicked(0))
            {
                *key = -1;
                changed = true;
            }
        }
    }
    else
    {
        if (isRecording)
        {
            draw->AddRectFilled(boxMin, boxMax, C(ImColor(60, 30, 30)), 6.0f);
            draw->AddRect(boxMin, boxMax, C(ImColor(200, 80, 80)), 6.0f);

            const char* waitingText = "Press a key...";
            ImVec2 waitingSize = ImGui::CalcTextSize(waitingText);
            float blink = sinf(ImGui::GetTime() * 6.0f) * 0.5f + 0.5f;
            ImColor waitingCol(255, 150, 150, (int)(150 + 105 * blink));
            draw->AddText(ImVec2(boxMin.x + (fullWidth - waitingSize.x) * 0.5f,
                                 boxMin.y + (boxHeight - waitingSize.y) * 0.5f),
                          C(waitingCol), waitingText);
        }
        else
        {
            draw->AddRectFilled(boxMin, boxMax, C(ImColor(35, 35, 45)), 6.0f);
            draw->AddRect(boxMin, boxMax, C(ImColor(55, 55, 70)), 6.0f);

            draw->AddText(ImVec2(boxMin.x + 10.0f, boxMin.y + (boxHeight - ImGui::GetTextLineHeight()) * 0.5f),
                C(ImColor(120, 120, 140)), "Click to bind...");
        }
    }

    if (isRecording)
    {
        draw->AddRect(boxMin, boxMax, C(ImColor(255, 60, 60, (int)(100 + 80 * sinf(ImGui::GetTime() * 4.0f)))), 6.0f, 0, 2.0f);
    }

    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + boxHeight + 6.0f);
    ImGui::PopID();
    return changed;
}

bool M_InputTextCustom(const char* label, char* buf, int bufSize, ImColor accent)
{
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGuiContext& g = *GImGui;
    ImGui::PushID(label);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 4.0f);

    ImVec2 pos = ImGui::GetCursorScreenPos();
    float fullWidth = ImGui::GetContentRegionAvail().x;
    if (fullWidth < 80.0f) fullWidth = 80.0f;

    ImVec2 labelSize = ImGui::CalcTextSize(label);
    ImGui::RenderText(ImVec2(pos.x, pos.y), label);

    float boxY = pos.y + labelSize.y + 4.0f;
    float boxHeight = 32.0f;
    ImVec2 boxMin(pos.x, boxY);
    ImVec2 boxMax(pos.x + fullWidth, boxY + boxHeight);

    ImRect boxRect(boxMin, boxMax);
    ImGuiID id = ImGui::GetID("_input");
    ImGui::ItemSize(ImVec2(fullWidth, boxHeight));
    ImGui::ItemAdd(boxRect, id);

    bool changed = false;

    if (ImGui::IsItemHovered() && ImGui::IsMouseClicked(0))
    {
        ImGui::SetActiveID(id, window);
    }

    bool isActive = (g.ActiveId == id);
    if (isActive)
    {
        ImGuiIO& io = ImGui::GetIO();
        for (int i = 0; i < io.InputQueueCharacters.Size; i++)
        {
            unsigned int c = (unsigned int)io.InputQueueCharacters[i];
            if (c >= 32 && c <= 126)
            {
                int len = (int)strlen(buf);
                if (len < bufSize - 1)
                {
                    buf[len] = (char)c;
                    buf[len + 1] = 0;
                    changed = true;
                }
            }
        }
        io.InputQueueCharacters.resize(0);

        if (ImGui::IsKeyPressed(ImGuiKey_Backspace) && !ImGui::IsKeyDown(ImGuiKey_LeftCtrl) && !ImGui::IsKeyDown(ImGuiKey_RightCtrl))
        {
            int len = (int)strlen(buf);
            if (len > 0)
            {
                buf[len - 1] = 0;
                changed = true;
            }
        }
        if (ImGui::IsKeyPressed(ImGuiKey_Escape))
        {
            ImGui::ClearActiveID();
        }
    }

    draw->AddRectFilled(boxMin, boxMax, C(ImColor(30, 30, 42)), 4.0f);
    draw->AddRect(boxMin, boxMax, C(isActive ? accent : ImColor(50, 50, 65)), 4.0f);

    float textX = boxMin.x + 8.0f;
    float textW = fullWidth - 16.0f;
    ImVec2 textSize = ImGui::CalcTextSize(buf);
    ImColor textCol = isActive ? ImColor(220, 220, 220) : ImColor(150, 150, 150);

    if (textSize.x > textW)
    {
        float scrollOffset = textSize.x - textW;
        ImGui::PushClipRect(ImVec2(textX, boxMin.y), ImVec2(textX + textW, boxMax.y), true);
        draw->AddText(ImVec2(textX - scrollOffset, boxMin.y + (boxHeight - ImGui::GetTextLineHeight()) * 0.5f),
            C(textCol), buf);
        ImGui::PopClipRect();
    }
    else if (buf[0] == 0 && !isActive)
    {
        draw->AddText(ImVec2(textX, boxMin.y + (boxHeight - ImGui::GetTextLineHeight()) * 0.5f),
            C(ImColor(80, 80, 100)), label);
    }
    else
    {
        draw->AddText(ImVec2(textX, boxMin.y + (boxHeight - ImGui::GetTextLineHeight()) * 0.5f),
            C(textCol), buf);
    }

    if (isActive)
    {
        float blink = sinf(ImGui::GetTime() * 6.0f) * 0.5f + 0.5f;
        if (blink > 0.3f)
        {
            float cursorX = textX + ImGui::CalcTextSize(buf).x;
            if (cursorX > textX + textW) cursorX = textX + textW;
            draw->AddLine(ImVec2(cursorX, boxMin.y + 5.0f), ImVec2(cursorX, boxMax.y - 5.0f),
                C(ImColor(200, 200, 200, (int)(200 * blink))), 1.5f);
        }
    }

    if (!ImGui::IsMouseDown(0) && g.ActiveId == id && !ImGui::IsMouseHoveringRect(boxMin, boxMax))
    {
        ImGui::ClearActiveID();
    }

    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + boxHeight + 6.0f);
    ImGui::PopID();
    return changed;
}

bool M_PasswordField(const char* label, char* buf, int bufSize, ImColor accent)
{
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGuiContext& g = *GImGui;
    ImGui::PushID(label);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 4.0f);

    ImVec2 pos = ImGui::GetCursorScreenPos();
    float fullWidth = ImGui::GetContentRegionAvail().x;
    if (fullWidth < 80.0f) fullWidth = 80.0f;

    ImVec2 labelSize = ImGui::CalcTextSize(label);
    ImGui::RenderText(ImVec2(pos.x, pos.y), label);

    float boxY = pos.y + labelSize.y + 4.0f;
    float boxHeight = 34.0f;
    ImVec2 boxMin(pos.x, boxY);
    ImVec2 boxMax(pos.x + fullWidth, boxY + boxHeight);

    ImRect boxRect(boxMin, boxMax);
    ImGuiID id = ImGui::GetID("_pwd");
    ImGui::ItemSize(ImVec2(fullWidth, boxHeight));
    ImGui::ItemAdd(boxRect, id);

    bool changed = false;
    static std::map<ImGuiID, bool> s_visibleStates;
    auto visIt = s_visibleStates.find(id);
    if (visIt == s_visibleStates.end())
    {
        visIt = s_visibleStates.emplace(id, false).first;
    }
    bool visible = visIt->second;

    if (ImGui::IsItemHovered() && ImGui::IsMouseClicked(0))
    {
        ImGui::SetActiveID(id, window);
    }

    bool isActive = (g.ActiveId == id);
    if (isActive)
    {
        ImGuiIO& io = ImGui::GetIO();
        for (int i = 0; i < io.InputQueueCharacters.Size; i++)
        {
            unsigned int c = (unsigned int)io.InputQueueCharacters[i];
            if (c >= 32 && c <= 126)
            {
                int len = (int)strlen(buf);
                if (len < bufSize - 1)
                {
                    buf[len] = (char)c;
                    buf[len + 1] = 0;
                    changed = true;
                }
            }
        }
        io.InputQueueCharacters.resize(0);

        if (ImGui::IsKeyPressed(ImGuiKey_Backspace) && !ImGui::IsKeyDown(ImGuiKey_LeftCtrl) && !ImGui::IsKeyDown(ImGuiKey_RightCtrl))
        {
            int len = (int)strlen(buf);
            if (len > 0)
            {
                buf[len - 1] = 0;
                changed = true;
            }
        }
        if (ImGui::IsKeyPressed(ImGuiKey_Escape))
        {
            ImGui::ClearActiveID();
        }
    }

    draw->AddRectFilled(boxMin, boxMax, C(ImColor(28, 28, 40)), 4.0f);
    draw->AddRect(boxMin, boxMax, C(isActive ? accent : ImColor(50, 50, 65)), 4.0f);

    float textX = boxMin.x + 8.0f;
    float textW = fullWidth - 44.0f;

    if (visible || !isActive)
    {
        char masked[256];
        int len = (int)strlen(buf);
        for (int i = 0; i < len && i < 255; i++) masked[i] = '*';
        masked[len] = 0;

        ImVec2 maskedSize = ImGui::CalcTextSize(masked);
        if (maskedSize.x > textW)
        {
            float scrollOffset = maskedSize.x - textW;
            ImGui::PushClipRect(ImVec2(textX, boxMin.y), ImVec2(textX + textW, boxMax.y), true);
            draw->AddText(ImVec2(textX - scrollOffset, boxMin.y + (boxHeight - ImGui::GetTextLineHeight()) * 0.5f),
                C(ImColor(200, 200, 200)), masked);
            ImGui::PopClipRect();
        }
        else
        {
            draw->AddText(ImVec2(textX, boxMin.y + (boxHeight - ImGui::GetTextLineHeight()) * 0.5f),
                C(ImColor(200, 200, 200)), masked);
        }
    }
    else
    {
        draw->AddText(ImVec2(textX, boxMin.y + (boxHeight - ImGui::GetTextLineHeight()) * 0.5f),
            C(ImColor(200, 200, 200)), buf);
    }

    float eyeX = boxMax.x - 26.0f;
    float eyeY = boxMin.y + boxHeight * 0.5f;
    bool eyeHov = fabsf(ImGui::GetMousePos().x - eyeX) < 8.0f && fabsf(ImGui::GetMousePos().y - eyeY) < 8.0f;
    draw->AddCircleFilled(ImVec2(eyeX, eyeY), 8.0f, C(eyeHov ? ImColor(80, 80, 100) : ImColor(50, 50, 60)));
    draw->AddText(ImVec2(eyeX - 5.0f, eyeY - 7.0f),
        C(eyeHov ? ImColor(220, 220, 220) : ImColor(130, 130, 130)), visible ? "\xe2\x97\x8f" : "\xe2\x97\x8b");
    if (eyeHov && ImGui::IsMouseClicked(0))
    {
        visIt->second = !visIt->second;
    }

    if (isActive)
    {
        float blink = sinf(ImGui::GetTime() * 6.0f) * 0.5f + 0.5f;
        if (blink > 0.3f)
        {
            float cursorX = textX + ImGui::CalcTextSize(buf).x;
            if (cursorX > textX + textW) cursorX = textX + textW;
            draw->AddLine(ImVec2(cursorX, boxMin.y + 5.0f), ImVec2(cursorX, boxMax.y - 5.0f),
                C(ImColor(200, 200, 200, (int)(200 * blink))), 1.5f);
        }
    }

    if (!ImGui::IsMouseDown(0) && g.ActiveId == id && !ImGui::IsMouseHoveringRect(boxMin, boxMax))
    {
        ImGui::ClearActiveID();
    }

    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + boxHeight + 6.0f);
    ImGui::PopID();
    return changed;
}

void M_SearchBar(const char* id, char* buf, int bufSize, ImColor accent)
{
    ImDrawList* d = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float w = ImGui::GetContentRegionAvail().x;
    float h = 36.0f;
    ImColor bg(12, 12, 22, 240);
    d->AddRectFilled(pos, ImVec2(pos.x + w, pos.y + h), C(bg), 6.0f);
    ImColor border(255, 255, 255, 15);
    d->AddRect(pos, ImVec2(pos.x + w, pos.y + h), C(border), 6.0f, ImDrawFlags_RoundCornersAll, 1.0f);
    ImColor accentLine = accent;
    accentLine.Value.w *= 0.2f;
    d->AddLine(ImVec2(pos.x + 6.0f, pos.y + h - 1.0f), ImVec2(pos.x + w - 6.0f, pos.y + h - 1.0f), C(accentLine), 1.0f);
    float iconX = pos.x + 10.0f;
    float iconY = pos.y + (h - 12.0f) * 0.5f;
    ImColor iconCol(80, 80, 110, 200);
    d->AddRectFilled(ImVec2(iconX, iconY), ImVec2(iconX + 12.0f, iconY + 12.0f), C(iconCol), 3.0f);
    ImGui::SetCursorScreenPos(ImVec2(pos.x + 28.0f, pos.y + 4.0f));
    ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.85f, 0.85f, 0.92f, 1.0f));
    ImGui::PushStyleColor(ImGuiCol_TextDisabled, ImVec4(0.4f, 0.4f, 0.5f, 0.8f));
    ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 0.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding, ImVec2(0, 0));
    ImGui::PushItemWidth(w - 42.0f);
    ImGui::InputTextWithHint(id, "Filter by name...", buf, bufSize);
    ImGui::PopItemWidth();
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor(3);
    if (buf[0] != 0)
    {
        float clearX = pos.x + w - 26.0f;
        float clearY = pos.y + (h - 16.0f) * 0.5f;
        ImVec2 clearMin(clearX, clearY);
        ImVec2 clearMax(clearX + 16.0f, clearY + 16.0f);
        bool clearHover = ImGui::IsMouseHoveringRect(clearMin, clearMax);
        ImColor clearCol = clearHover ? ImColor(255, 80, 80, 220) : ImColor(100, 100, 130, 150);
        d->AddRectFilled(clearMin, clearMax, C(clearCol), 4.0f);
        if (clearHover && ImGui::IsMouseClicked(0))
            buf[0] = 0;
        ImColor xCol(255, 255, 255, 200);
        d->AddLine(ImVec2(clearX + 4.0f, clearY + 4.0f), ImVec2(clearX + 12.0f, clearY + 12.0f), C(xCol), 2.0f);
        d->AddLine(ImVec2(clearX + 12.0f, clearY + 4.0f), ImVec2(clearX + 4.0f, clearY + 12.0f), C(xCol), 2.0f);
    }
    ImGui::SetCursorScreenPos(ImVec2(pos.x, pos.y + h + 6.0f));
}
