#include "TabHelpers.h"

ImColor hsvToRgb(float h, float s, float v)
{
    if (s < 0.001f) return ImColor(v, v, v);
    float r = v, g = v, b = v;
    int i = (int)(h * 6.0f);
    float f = h * 6.0f - (float)i;
    float p = v * (1.0f - s);
    float q = v * (1.0f - f * s);
    float t = v * (1.0f - (1.0f - f) * s);
    switch (i % 6)
    {
        case 0: r = v; g = t; b = p; break;
        case 1: r = q; g = v; b = p; break;
        case 2: r = p; g = v; b = t; break;
        case 3: r = p; g = q; b = v; break;
        case 4: r = t; g = p; b = v; break;
        default: r = v; g = p; b = q; break;
    }
    return ImColor(r, g, b);
}

ImColor lerpCol(const ImColor& a, const ImColor& b, float t)
{
    float ct = t < 0.0f ? 0.0f : (t > 1.0f ? 1.0f : t);
    return ImColor(
        a.Value.x + (b.Value.x - a.Value.x) * ct,
        a.Value.y + (b.Value.y - a.Value.y) * ct,
        a.Value.z + (b.Value.z - a.Value.z) * ct,
        a.Value.w + (b.Value.w - a.Value.w) * ct
    );
}

float clampF(float v, float lo, float hi)
{
    return v < lo ? lo : (v > hi ? hi : v);
}

void drawCardGlow(ImDrawList* dl, ImVec2 pos, float w, float h, ImColor accent, float intensity)
{
    for (int i = 3; i >= 0; i--)
    {
        float t = (float)i / 3.0f;
        float expand = 2.0f + t * 5.0f;
        float alpha = intensity * t * 0.07f;
        if (alpha < 0.002f) continue;
        ImColor col(accent.Value.x, accent.Value.y, accent.Value.z, alpha);
        dl->AddRect(
            ImVec2(pos.x - expand, pos.y - expand),
            ImVec2(pos.x + w + expand, pos.y + h + expand),
            C(col), 5.0f + expand * 0.25f, ImDrawFlags_RoundCornersAll, 1.0f + t * 0.8f
        );
    }
}

void drawSectionBar(ImDrawList* dl, ImVec2 pos, float w, ImColor accent)
{
    ImColor barCol = accent;
    barCol.Value.w = 0.12f;
    dl->AddRectFilled(
        ImVec2(pos.x + 4.0f, pos.y),
        ImVec2(pos.x + w - 4.0f, pos.y + 2.0f),
        C(barCol), 1.0f
    );
    ImColor dotCol = accent;
    dotCol.Value.w = 0.2f;
    float dotX = pos.x + w * 0.5f;
    dl->AddCircleFilled(ImVec2(dotX, pos.y + 1.0f), 3.0f, C(dotCol), 8);
    dl->AddCircleFilled(ImVec2(dotX - w * 0.3f, pos.y + 1.0f), 2.0f, C(dotCol), 8);
    dl->AddCircleFilled(ImVec2(dotX + w * 0.3f, pos.y + 1.0f), 2.0f, C(dotCol), 8);
}

void drawActivePulse(ImDrawList* dl, ImVec2 pos, float w, ImColor accent, float phase, float height)
{
    ImColor pulseCol = accent;
    pulseCol.Value.w = 0.03f + phase * 0.06f;
    dl->AddRectFilled(
        ImVec2(pos.x + 4.0f, pos.y),
        ImVec2(pos.x + w - 4.0f, pos.y + height),
        C(pulseCol), height * 0.5f
    );
    ImColor subCol = accent;
    subCol.Value.w = 0.01f + phase * 0.03f;
    dl->AddRectFilled(
        ImVec2(pos.x + 8.0f, pos.y + 1.0f),
        ImVec2(pos.x + w - 8.0f, pos.y + height - 1.0f),
        C(subCol), height * 0.3f
    );
}
