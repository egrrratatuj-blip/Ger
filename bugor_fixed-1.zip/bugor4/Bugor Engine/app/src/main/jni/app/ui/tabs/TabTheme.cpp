#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "TabTheme.h"
#include "../ui_integration.h"
#include "../widgets/Widgets_Switches.h"
#include "../widgets/Widgets_Buttons.h"
#include "../widgets/Widgets_Containers.h"
#include "../widgets/Widgets_Sliders.h"
#include "../widgets/Widgets_Visuals.h"

#include <map>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <cstdlib>

extern void M_CyberHeader(const char* title, ImColor accent, const char* subtitle = nullptr);
extern bool M_GradientButton(const char* label, ImVec2 size, ImColor colorA, ImColor colorB, float rounding = 15.0f);
extern bool M_ModernSwitch(const char* label, bool* value, ImColor accent);
extern bool M_ClassicToggle(const char* label, bool* value, ImColor accent);
extern bool M_FancyCheckbox(const char* label, bool* value, ImColor accent);
extern bool M_RadioSelector(const char* label, bool active, ImColor accent);
extern bool M_ToggleRow(const char* icon, const char* label, const char* subtitle, bool* value, ImColor accent);
extern bool M_SegmentedToggle(const char* label, int* activeIndex, const char** options, int optionCount, ImColor accent);
extern bool M_CyberButton(const char* label, ImVec2 size, ImColor accent);
extern bool M_GradientSlider(const char* label, float* value, float min, float max, const char* format, ImColor accent);
extern bool M_IntSlider(const char* label, int* value, int min, int max, const char* format, ImColor accent);
extern bool M_RangeSlider(const char* label, float* minVal, float* maxVal, float absMin, float absMax, const char* format, ImColor accent);
extern bool M_KnobDial(const char* label, float* value, float min, float max, const char* format, ImColor accent);
extern bool M_DropdownSelect(const char* label, int* selected, const char** items, int count, ImColor accent);
extern bool M_ColorSlider(const char* label, float* value, ImColor colorA, ImColor colorB, ImColor accent);
extern bool M_CardContainer(const char* title, bool* collapsed, ImColor accent, const char* badge = nullptr);
extern void M_StatCard(const char* label, const char* value, const char* trend, bool trendUp, ImColor accent);
extern void M_SectionDivider(const char* label, ImColor accent);
extern void M_InfoRow(const char* label, const char* value, ImColor valueColor, const char* icon = nullptr);
extern void M_Badge(const char* text, ImColor color, ImVec2 position);

static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }

static void HSVtoRGB(float h, float s, float v, float& r, float& g, float& b)
{
    if (s < 0.0001f) { r = v; g = v; b = v; return; }
    h = fmodf(h, 1.0f); if (h < 0.0f) h += 1.0f;
    float h6 = h * 6.0f;
    int i = (int)h6;
    float f = h6 - (float)i;
    float p = v * (1.0f - s);
    float q = v * (1.0f - s * f);
    float t = v * (1.0f - s * (1.0f - f));
    switch (i) {
        case 0: r = v; g = t; b = p; break;
        case 1: r = q; g = v; b = p; break;
        case 2: r = p; g = v; b = t; break;
        case 3: r = p; g = q; b = v; break;
        case 4: r = t; g = p; b = v; break;
        default: r = v; g = p; b = q; break;
    }
}

static void RGBtoHSV(float r, float g, float b, float& h, float& s, float& v)
{
    v = ImMax(ImMax(r, g), b);
    float diff = v - ImMin(ImMin(r, g), b);
    if (diff < 0.0001f) { s = 0.0f; h = 0.0f; return; }
    s = diff / v;
    if (v == r) h = (g - b) / diff;
    else if (v == g) h = 2.0f + (b - r) / diff;
    else h = 4.0f + (r - g) / diff;
    h /= 6.0f;
    if (h < 0.0f) h += 1.0f;
}

static ImColor ThemeColors[8][12] = {
    {
        ImColor(10, 15, 30), ImColor(0, 180, 255), ImColor(100, 200, 255),
        ImColor(255, 255, 255), ImColor(15, 20, 40), ImColor(0, 150, 220),
        ImColor(20, 25, 45), ImColor(50, 210, 255), ImColor(0, 130, 200),
        ImColor(40, 50, 80), ImColor(30, 35, 55), ImColor(150, 230, 255)
    },
    {
        ImColor(30, 10, 15), ImColor(200, 40, 60), ImColor(255, 100, 130),
        ImColor(255, 240, 240), ImColor(40, 15, 22), ImColor(180, 35, 50),
        ImColor(35, 18, 25), ImColor(230, 60, 80), ImColor(160, 25, 40),
        ImColor(60, 30, 40), ImColor(45, 22, 30), ImColor(255, 150, 170)
    },
    {
        ImColor(10, 25, 15), ImColor(50, 200, 80), ImColor(200, 180, 50),
        ImColor(240, 255, 240), ImColor(15, 35, 22), ImColor(40, 180, 70),
        ImColor(20, 30, 22), ImColor(70, 230, 100), ImColor(30, 160, 60),
        ImColor(35, 55, 40), ImColor(28, 38, 30), ImColor(220, 220, 100)
    },
    {
        ImColor(30, 22, 10), ImColor(220, 170, 50), ImColor(255, 230, 180),
        ImColor(255, 250, 235), ImColor(38, 28, 15), ImColor(200, 150, 40),
        ImColor(35, 26, 18), ImColor(250, 195, 70), ImColor(180, 130, 30),
        ImColor(55, 45, 30), ImColor(42, 32, 22), ImColor(255, 240, 210)
    },
    {
        ImColor(10, 20, 10), ImColor(0, 255, 65), ImColor(100, 255, 150),
        ImColor(220, 255, 220), ImColor(15, 28, 15), ImColor(0, 220, 55),
        ImColor(18, 25, 18), ImColor(50, 255, 100), ImColor(0, 200, 45),
        ImColor(25, 50, 30), ImColor(22, 30, 22), ImColor(180, 255, 200)
    },
    {
        ImColor(15, 20, 30), ImColor(150, 210, 255), ImColor(220, 240, 255),
        ImColor(240, 245, 255), ImColor(20, 28, 40), ImColor(130, 190, 240),
        ImColor(22, 28, 38), ImColor(180, 225, 255), ImColor(110, 170, 220),
        ImColor(40, 55, 75), ImColor(30, 36, 48), ImColor(240, 248, 255)
    },
    {
        ImColor(18, 10, 30), ImColor(180, 60, 220), ImColor(255, 80, 200),
        ImColor(245, 230, 255), ImColor(25, 15, 40), ImColor(160, 50, 200),
        ImColor(22, 15, 35), ImColor(210, 80, 250), ImColor(140, 40, 180),
        ImColor(45, 25, 60), ImColor(30, 20, 42), ImColor(255, 150, 230)
    },
    {
        ImColor(8, 8, 10), ImColor(200, 30, 30), ImColor(180, 180, 180),
        ImColor(220, 220, 220), ImColor(12, 10, 12), ImColor(180, 25, 25),
        ImColor(15, 14, 16), ImColor(230, 50, 50), ImColor(150, 20, 20),
        ImColor(40, 35, 38), ImColor(20, 18, 20), ImColor(220, 220, 220)
    }
};

static int s_CurrentTheme = 0;
static int s_EditedTheme = 0;
static int s_ColorSlot = 0;
static float s_HueEdit = 0.0f;
static float s_SatEdit = 1.0f;
static float s_ValEdit = 1.0f;

static float s_StyleRounding = 8.0f;
static float s_StyleFrameRounding = 4.0f;
static float s_StyleTabRounding = 4.0f;
static float s_StyleGrabRounding = 4.0f;
static float s_StyleScrollbarSize = 14.0f;
static float s_StyleFramePaddingX = 8.0f;
static float s_StyleFramePaddingY = 4.0f;
static float s_StyleItemSpacingX = 8.0f;
static float s_StyleItemSpacingY = 4.0f;
static float s_StyleWindowBorder = 1.0f;
static float s_StyleWindowPaddingX = 8.0f;
static float s_StyleWindowPaddingY = 8.0f;
static float s_StyleItemInnerSpacingX = 4.0f;
static float s_StyleItemInnerSpacingY = 4.0f;
static float s_StyleGrabMinSize = 10.0f;
static float s_StyleIndentSpacing = 20.0f;

static bool s_PreviewSwitch1 = true;
static bool s_PreviewSwitch2 = false;
static bool s_PreviewSwitch3 = true;
static bool s_PreviewSwitch4 = true;
static bool s_PreviewSwitch5 = false;
static bool s_PreviewSwitch6 = true;
static bool s_PreviewSwitch7 = false;
static bool s_PreviewCheckbox1 = true;
static bool s_PreviewCheckbox2 = false;
static float s_PreviewSliderVal = 0.55f;
static float s_PreviewKnobVal = 50.0f;
static int s_PreviewDropdown = 0;
static bool s_PreviewCardCollapsed = false;
static bool s_PreviewRadio1 = true;
static bool s_PreviewRadio2 = false;
static bool s_PreviewRadio3 = false;
static int s_PreviewIntVal = 42;
static float s_PreviewRangeMin = 20.0f;
static float s_PreviewRangeMax = 80.0f;
static int s_PreviewSegmented = 0;
static bool s_PreviewToggleRow = false;

static const char* s_ColorSlotNames[15] = {
    "Window Background", "Title Bar", "Accent Primary", "Accent Secondary",
    "Text Primary", "Text Dim", "Button Normal", "Button Hover",
    "Button Active", "Frame BG", "Border", "Checkmark",
    "Scrollbar", "Tab Active", "Tab Inactive"
};

static int s_ColorSlotMap[15] = { 0, 4, 1, 2, 3, 3, 5, 7, 8, 6, 9, 11, 10, 1, 10 };
static float s_TextDimAlpha = 0.5f;

static ImColor s_DefaultThemeColors[8][12];
static const char* THEME_CONFIG_PATH = "theme_config.bin";

static void SaveThemeDefaults()
{
    memcpy(s_DefaultThemeColors, ThemeColors, sizeof(ThemeColors));
}

static void SyncThemeToStyle()
{
    int idx = s_EditedTheme;
    if (idx < 0 || idx >= 8) idx = 0;
    ImColor* tc = ThemeColors[idx];
    ImGuiStyle& style = ImGui::GetStyle();
    style.Colors[ImGuiCol_WindowBg] = tc[0];
    style.Colors[ImGuiCol_TitleBg] = tc[4];
    style.Colors[ImGuiCol_TitleBgActive] = tc[4];
    style.Colors[ImGuiCol_TitleBgCollapsed] = ImColor(tc[4].Value.x, tc[4].Value.y, tc[4].Value.z, tc[4].Value.w * 0.6f);
    style.Colors[ImGuiCol_Button] = tc[5];
    style.Colors[ImGuiCol_ButtonHovered] = tc[7];
    style.Colors[ImGuiCol_ButtonActive] = tc[8];
    style.Colors[ImGuiCol_FrameBg] = tc[6];
    style.Colors[ImGuiCol_FrameBgHovered] = ImColor(tc[6].Value.x * 1.2f, tc[6].Value.y * 1.2f, tc[6].Value.z * 1.2f, tc[6].Value.w);
    style.Colors[ImGuiCol_FrameBgActive] = tc[1];
    style.Colors[ImGuiCol_Text] = tc[3];
    style.Colors[ImGuiCol_TextDisabled] = ImColor(tc[3].Value.x, tc[3].Value.y, tc[3].Value.z, tc[3].Value.w * 0.5f);
    style.Colors[ImGuiCol_Border] = tc[9];
    style.Colors[ImGuiCol_BorderShadow] = ImColor(0, 0, 0, 0);
    style.Colors[ImGuiCol_ScrollbarBg] = tc[6];
    style.Colors[ImGuiCol_ScrollbarGrab] = tc[10];
    style.Colors[ImGuiCol_ScrollbarGrabHovered] = tc[7];
    style.Colors[ImGuiCol_ScrollbarGrabActive] = tc[8];
    style.Colors[ImGuiCol_CheckMark] = tc[11];
    style.Colors[ImGuiCol_SliderGrab] = tc[1];
    style.Colors[ImGuiCol_SliderGrabActive] = tc[7];
    style.Colors[ImGuiCol_Header] = tc[1];
    style.Colors[ImGuiCol_HeaderHovered] = tc[7];
    style.Colors[ImGuiCol_HeaderActive] = tc[8];
    style.Colors[ImGuiCol_Separator] = tc[9];
    style.Colors[ImGuiCol_SeparatorHovered] = tc[7];
    style.Colors[ImGuiCol_SeparatorActive] = tc[8];
    style.Colors[ImGuiCol_ResizeGrip] = tc[10];
    style.Colors[ImGuiCol_ResizeGripHovered] = tc[7];
    style.Colors[ImGuiCol_ResizeGripActive] = tc[8];
    style.Colors[ImGuiCol_Tab] = tc[10];
    style.Colors[ImGuiCol_TabHovered] = tc[7];
    style.Colors[ImGuiCol_TabActive] = tc[1];
    style.Colors[ImGuiCol_TabUnfocused] = tc[10];
    style.Colors[ImGuiCol_TabUnfocusedActive] = ImColor(tc[1].Value.x * 0.6f, tc[1].Value.y * 0.6f, tc[1].Value.z * 0.6f, tc[1].Value.w);
    style.Colors[ImGuiCol_PopupBg] = tc[0];
    style.Colors[ImGuiCol_ChildBg] = tc[0];
    style.Colors[ImGuiCol_MenuBarBg] = tc[4];
    style.Colors[ImGuiCol_NavHighlight] = tc[11];
    style.Colors[ImGuiCol_NavWindowingHighlight] = ImColor(255, 255, 255, 80);
    style.Colors[ImGuiCol_NavWindowingDimBg] = ImColor(0, 0, 0, 50);
    style.Colors[ImGuiCol_ModalWindowDimBg] = ImColor(0, 0, 0, 60);
    style.Colors[ImGuiCol_DragDropTarget] = tc[11];
    style.WindowRounding = s_StyleRounding;
    style.FrameRounding = s_StyleFrameRounding;
    style.TabRounding = s_StyleTabRounding;
    style.GrabRounding = s_StyleGrabRounding;
    style.ScrollbarSize = s_StyleScrollbarSize;
    style.FramePadding = ImVec2(s_StyleFramePaddingX, s_StyleFramePaddingY);
    style.ItemSpacing = ImVec2(s_StyleItemSpacingX, s_StyleItemSpacingY);
    style.WindowBorderSize = s_StyleWindowBorder;
    style.FrameBorderSize = 1.0f;
    style.ScrollbarRounding = s_StyleFrameRounding;
    style.TabBorderSize = 0.0f;
    style.WindowPadding = ImVec2(8, 8);
    style.ItemInnerSpacing = ImVec2(4, 4);
    style.CellPadding = ImVec2(4, 2);
    style.TouchExtraPadding = ImVec2(0, 0);
    style.IndentSpacing = 20.0f;
    style.ScrollbarMinSize = 20.0f;
    style.GrabMinSize = 10.0f;
    style.WindowTitleAlign = ImVec2(0.0f, 0.5f);
    style.WindowMenuButtonPosition = ImGuiDir_None;
    style.ColorButtonPosition = ImGuiDir_Right;
    style.ButtonTextAlign = ImVec2(0.5f, 0.5f);
    style.SelectableTextAlign = ImVec2(0.0f, 0.0f);
    style.DisplaySafeAreaPadding = ImVec2(4, 4);
    style.DisplayWindowPadding = ImVec2(20, 20);
    style.MouseCursorScale = 1.0f;
    style.AntiAliasedLines = true;
    style.AntiAliasedLinesUseTex = true;
    style.AntiAliasedFill = true;
    style.CurveTessellationTol = 1.25f;
    style.CircleTessellationMaxError = 0.30f;
}

static void SaveThemeConfig()
{
    FILE* f = fopen(THEME_CONFIG_PATH, "wb");
    if (!f) return;
    fwrite(ThemeColors, sizeof(ThemeColors), 1, f);
    fwrite(&s_TextDimAlpha, sizeof(s_TextDimAlpha), 1, f);
    fwrite(&s_StyleRounding, sizeof(s_StyleRounding), 1, f);
    fwrite(&s_StyleFrameRounding, sizeof(s_StyleFrameRounding), 1, f);
    fwrite(&s_StyleTabRounding, sizeof(s_StyleTabRounding), 1, f);
    fwrite(&s_StyleGrabRounding, sizeof(s_StyleGrabRounding), 1, f);
    fwrite(&s_StyleScrollbarSize, sizeof(s_StyleScrollbarSize), 1, f);
    fwrite(&s_StyleFramePaddingX, sizeof(s_StyleFramePaddingX), 1, f);
    fwrite(&s_StyleFramePaddingY, sizeof(s_StyleFramePaddingY), 1, f);
    fwrite(&s_StyleItemSpacingX, sizeof(s_StyleItemSpacingX), 1, f);
    fwrite(&s_StyleItemSpacingY, sizeof(s_StyleItemSpacingY), 1, f);
    fwrite(&s_StyleWindowBorder, sizeof(s_StyleWindowBorder), 1, f);
    fwrite(&s_StyleGrabMinSize, sizeof(s_StyleGrabMinSize), 1, f);
    fwrite(&s_StyleIndentSpacing, sizeof(s_StyleIndentSpacing), 1, f);
    fclose(f);
}

static void LoadThemeConfig()
{
    FILE* f = fopen(THEME_CONFIG_PATH, "rb");
    if (!f) return;
    fread(ThemeColors, sizeof(ThemeColors), 1, f);
    fread(&s_TextDimAlpha, sizeof(s_TextDimAlpha), 1, f);
    fread(&s_StyleRounding, sizeof(s_StyleRounding), 1, f);
    fread(&s_StyleFrameRounding, sizeof(s_StyleFrameRounding), 1, f);
    fread(&s_StyleTabRounding, sizeof(s_StyleTabRounding), 1, f);
    fread(&s_StyleGrabRounding, sizeof(s_StyleGrabRounding), 1, f);
    fread(&s_StyleScrollbarSize, sizeof(s_StyleScrollbarSize), 1, f);
    fread(&s_StyleFramePaddingX, sizeof(s_StyleFramePaddingX), 1, f);
    fread(&s_StyleFramePaddingY, sizeof(s_StyleFramePaddingY), 1, f);
    fread(&s_StyleItemSpacingX, sizeof(s_StyleItemSpacingX), 1, f);
    fread(&s_StyleItemSpacingY, sizeof(s_StyleItemSpacingY), 1, f);
    fread(&s_StyleWindowBorder, sizeof(s_StyleWindowBorder), 1, f);
    fread(&s_StyleGrabMinSize, sizeof(s_StyleGrabMinSize), 1, f);
    fread(&s_StyleIndentSpacing, sizeof(s_StyleIndentSpacing), 1, f);
    fclose(f);
}

static const char* s_ThemeNames[8] = {
    "Neon Blue", "Rose Red", "Emerald", "Royal Gold",
    "Toxic Green", "Frost Ice", "Royal Purple", "Obsidian"
};

static const char* s_ColorLabels[12] = {
    "Background", "Accent", "Accent2", "Text", "Title BG", "Button",
    "Frame BG", "Hover", "Active", "Border", "Frame Alt", "Highlight"
};

static ImColor GetCurrentColor()
{
    ImColor c = ThemeColors[s_EditedTheme][s_ColorSlotMap[s_ColorSlot]];
    if (s_ColorSlot == 5) c = ImColor(c.Value.x, c.Value.y, c.Value.z, s_TextDimAlpha);
    return c;
}

static void SetCurrentColorRGB(float r, float g, float b)
{
    if (s_ColorSlot == 5) return;
    ThemeColors[s_EditedTheme][s_ColorSlotMap[s_ColorSlot]].Value.x = ImClamp(r, 0.0f, 1.0f);
    ThemeColors[s_EditedTheme][s_ColorSlotMap[s_ColorSlot]].Value.y = ImClamp(g, 0.0f, 1.0f);
    ThemeColors[s_EditedTheme][s_ColorSlotMap[s_ColorSlot]].Value.z = ImClamp(b, 0.0f, 1.0f);
}

static void SetCurrentColorA(float a)
{
    if (s_ColorSlot == 5) { s_TextDimAlpha = ImClamp(a, 0.0f, 1.0f); return; }
    ThemeColors[s_EditedTheme][s_ColorSlotMap[s_ColorSlot]].Value.w = ImClamp(a, 0.0f, 1.0f);
}

static void SyncHSVFromCurrentColor()
{
    ImColor c = GetCurrentColor();
    float h, s, v;
    RGBtoHSV(c.Value.x, c.Value.y, c.Value.z, h, s, v);
    s_HueEdit = h;
    s_SatEdit = s;
    s_ValEdit = v;
}

static void ApplyTheme(int idx)
{
    if (idx < 0 || idx >= 8) return;
    s_CurrentTheme = idx;
    s_EditedTheme = idx;
    SyncHSVFromCurrentColor();
    SyncThemeToStyle();
    SaveThemeConfig();
}

static bool ColorPickerQuad(ImVec2 pos, float size, float* sat, float* val, float hue)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    int steps = 32;
    for (int y = 0; y < steps; y++)
    {
        float fy = (float)y / (float)(steps - 1);
        for (int x = 0; x < steps; x++)
        {
            float fx = (float)x / (float)(steps - 1);
            float r, g, b;
            HSVtoRGB(hue, fx, 1.0f - fy, r, g, b);
            float cr = r * (1.0f - fy) + fy * 0.0f;
            float cg = g * (1.0f - fy) + fy * 0.0f;
            float cb = b * (1.0f - fy) + fy * 0.0f;
            float x0 = pos.x + fx * size;
            float y0 = pos.y + fy * size;
            float x1 = pos.x + (fx + 1.0f / steps) * size;
            float y1 = pos.y + (fy + 1.0f / steps) * size;
            dl->AddRectFilled(ImVec2(x0, y0), ImVec2(x1, y1), C(ImColor((int)(cr * 255), (int)(cg * 255), (int)(cb * 255))));
        }
    }
    dl->AddRect(pos, ImVec2(pos.x + size, pos.y + size), C(ImColor(60, 60, 80)), 0.0f, 0, 1.5f);
    float cx = pos.x + (*sat) * size;
    float cy = pos.y + (1.0f - (*val)) * size;
    dl->AddCircleFilled(ImVec2(cx, cy), 5.0f, C(ImColor(255, 255, 255)), 12);
    dl->AddCircle(ImVec2(cx, cy), 5.0f, C(ImColor(0, 0, 0, 100)), 12, 1.5f);
    ImRect rect(pos, ImVec2(pos.x + size, pos.y + size));
    ImGui::ItemSize(ImVec2(size, size));
    ImGui::ItemAdd(rect, ImGui::GetID("picker_quad"));
    bool changed = false;
    if (ImGui::IsItemHovered() && ImGui::IsMouseDown(0))
    {
        ImVec2 mp = ImGui::GetMousePos();
        float ns = ImClamp((mp.x - pos.x) / size, 0.0f, 1.0f);
        float nv = ImClamp(1.0f - (mp.y - pos.y) / size, 0.0f, 1.0f);
        if (*sat != ns || *val != nv) { *sat = ns; *val = nv; changed = true; }
    }
    return changed;
}

static bool ColorPickerStrip(ImVec2 pos, float height, float width, float* hue)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    int steps = 64;
    for (int i = 0; i < steps; i++)
    {
        float h0 = (float)i / (float)steps;
        float h1 = (float)(i + 1) / (float)steps;
        float r0, g0, b0, r1, g1, b1;
        HSVtoRGB(h0, 1.0f, 1.0f, r0, g0, b0);
        HSVtoRGB(h1, 1.0f, 1.0f, r1, g1, b1);
        float y0 = pos.y + (h0) * height;
        float y1 = pos.y + (h1) * height;
        dl->AddRectFilledMultiColor(
            ImVec2(pos.x, y0), ImVec2(pos.x + width, y1),
            C(ImColor((int)(r0 * 255), (int)(g0 * 255), (int)(b0 * 255))),
            C(ImColor((int)(r1 * 255), (int)(g1 * 255), (int)(b1 * 255))),
            C(ImColor((int)(r1 * 255), (int)(g1 * 255), (int)(b1 * 255))),
            C(ImColor((int)(r0 * 255), (int)(g0 * 255), (int)(b0 * 255)))
        );
    }
    dl->AddRect(pos, ImVec2(pos.x + width, pos.y + height), C(ImColor(60, 60, 80)), 0.0f, 0, 1.5f);
    float cy = pos.y + (*hue) * height;
    dl->AddRectFilled(ImVec2(pos.x - 2, cy - 4), ImVec2(pos.x + width + 2, cy + 4), C(ImColor(255, 255, 255)), 2.0f);
    dl->AddRect(ImVec2(pos.x - 2, cy - 4), ImVec2(pos.x + width + 2, cy + 4), C(ImColor(0, 0, 0, 80)), 2.0f, 0, 1.0f);
    ImRect rect(pos, ImVec2(pos.x + width, pos.y + height));
    ImGui::ItemSize(ImVec2(width, height));
    ImGui::ItemAdd(rect, ImGui::GetID("picker_strip"));
    bool changed = false;
    if (ImGui::IsItemHovered() && ImGui::IsMouseDown(0))
    {
        ImVec2 mp = ImGui::GetMousePos();
        float nh = ImClamp((mp.y - pos.y) / height, 0.0f, 1.0f);
        if (*hue != nh) { *hue = nh; changed = true; }
    }
    return changed;
}

static void ResetStyleToDefaults()
{
    s_StyleRounding = 8.0f;
    s_StyleFrameRounding = 4.0f;
    s_StyleTabRounding = 4.0f;
    s_StyleGrabRounding = 4.0f;
    s_StyleScrollbarSize = 14.0f;
    s_StyleFramePaddingX = 8.0f;
    s_StyleFramePaddingY = 4.0f;
    s_StyleItemSpacingX = 8.0f;
    s_StyleItemSpacingY = 4.0f;
    s_StyleWindowBorder = 1.0f;
    s_StyleWindowPaddingX = 8.0f;
    s_StyleWindowPaddingY = 8.0f;
    s_StyleItemInnerSpacingX = 4.0f;
    s_StyleItemInnerSpacingY = 4.0f;
    s_StyleGrabMinSize = 10.0f;
    s_StyleIndentSpacing = 20.0f;
}

static void SyncStyleFromImGui()
{
    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowRounding = s_StyleRounding;
    style.FrameRounding = s_StyleFrameRounding;
    style.TabRounding = s_StyleTabRounding;
    style.GrabRounding = s_StyleGrabRounding;
    style.ScrollbarSize = s_StyleScrollbarSize;
    style.FramePadding = ImVec2(s_StyleFramePaddingX, s_StyleFramePaddingY);
    style.ItemSpacing = ImVec2(s_StyleItemSpacingX, s_StyleItemSpacingY);
    style.WindowBorderSize = s_StyleWindowBorder;
    style.WindowPadding = ImVec2(s_StyleWindowPaddingX, s_StyleWindowPaddingY);
    style.ItemInnerSpacing = ImVec2(s_StyleItemInnerSpacingX, s_StyleItemInnerSpacingY);
    style.GrabMinSize = s_StyleGrabMinSize;
    style.IndentSpacing = s_StyleIndentSpacing;
}

static void DrawThemeCard(ImDrawList* dl, int idx, ImVec2 cardMin, ImVec2 cardMax, float rounding)
{
    float cardW = cardMax.x - cardMin.x;
    float cardH = cardMax.y - cardMin.y;
    bool hovered = ImGui::IsMouseHoveringRect(cardMin, cardMax);
    ImColor* tc = ThemeColors[idx];
    static std::map<int, ImGui::AnimFloat> glowAnims;
    auto it = glowAnims.find(idx);
    if (it == glowAnims.end())
        it = glowAnims.emplace(idx, ImGui::AnimFloat(0.0f, 6.0f)).first;
    it->second.SetTarget(hovered || s_CurrentTheme == idx ? 1.0f : 0.0f);
    it->second.Update();
    float glow = it->second.Get();
    for (int lay = 0; lay < 4; lay++)
    {
        float soff = 1.0f + lay * 1.8f;
        ImVec2 smin(cardMin.x + soff, cardMin.y + soff * 1.5f);
        ImVec2 smax(cardMax.x + soff, cardMax.y + soff * 1.5f);
        int a = (int)((40 + 30 * glow) * (1.0f - lay * 0.22f));
        dl->AddRectFilled(smin, smax, C(ImColor(0, 0, 0, a)), rounding + lay * 0.5f);
    }
    ImColor bgCol = ImColor(20, 22, 38);
    if (hovered) bgCol = ImColor(26, 28, 48);
    if (s_CurrentTheme == idx) bgCol = ImColor(30, 34, 60);
    dl->AddRectFilled(cardMin, cardMax, C(bgCol), rounding);
    {
        float barH = 3.0f;
        dl->AddRectFilled(ImVec2(cardMin.x + 4, cardMin.y + 4), ImVec2(cardMax.x - 4, cardMin.y + 4 + barH), C(tc[1]), 1.5f);
    }
    float swatchY = cardMin.y + 12.0f;
    float swatchH = 16.0f;
    float swatchW = (cardW - 18.0f) / 5.0f;
    for (int s = 0; s < 5; s++)
    {
        ImVec2 sp0(cardMin.x + 9.0f + s * (swatchW + 2.0f), swatchY);
        ImVec2 sp1(sp0.x + swatchW, sp0.y + swatchH);
        ImColor sc;
        switch (s)
        {
            case 0: sc = tc[0]; break;
            case 1: sc = tc[1]; break;
            case 2: sc = tc[3]; break;
            case 3: sc = tc[9]; break;
            default: sc = tc[11]; break;
        }
        dl->AddRectFilled(sp0, sp1, C(sc), 2.0f);
        dl->AddRect(sp0, sp1, C(ImColor(255, 255, 255, 20)), 2.0f, 0, 0.5f);
    }
    float nameY = swatchY + swatchH + 8.0f;
    ImVec2 nameSize = ImGui::CalcTextSize(s_ThemeNames[idx]);
    float nameX = cardMin.x + (cardW - nameSize.x) * 0.5f;
    ImU32 nameCol = C(s_CurrentTheme == idx ? ImColor(255, 255, 255) : ImColor(180, 180, 210));
    dl->AddText(ImVec2(nameX, nameY), nameCol, s_ThemeNames[idx]);
    if (s_CurrentTheme == idx)
    {
        float pulse = sinf(ImGui::GetTime() * 3.0f) * 0.3f + 0.7f;
        ImColor glowCol = ImColor((int)(tc[1].Value.x * 255), (int)(tc[1].Value.y * 255), (int)(tc[1].Value.z * 255), (int)(pulse * 120 * glow));
        ImColor glowCol2 = ImColor((int)(tc[1].Value.x * 255), (int)(tc[1].Value.y * 255), (int)(tc[1].Value.z * 255), (int)(pulse * 50 * glow));
        for (int g = 0; g < 3; g++)
        {
            float expand = g * 2.0f;
            ImColor gc = g == 0 ? glowCol : glowCol2;
            dl->AddRect(
                ImVec2(cardMin.x - 1.0f - expand, cardMin.y - 1.0f - expand),
                ImVec2(cardMax.x + 1.0f + expand, cardMax.y + 1.0f + expand),
                C(gc), rounding + expand, 0, 2.5f - g * 0.5f
            );
        }
    }
    else if (glow > 0.01f)
    {
        ImColor glowCol = ImColor(255, 255, 255, (int)(35 * glow));
        dl->AddRect(cardMin, cardMax, C(glowCol), rounding, 0, 1.5f);
    }
    ImColor borderCol = s_CurrentTheme == idx ? tc[1] : ImColor(50, 50, 70);
    borderCol.Value.w = s_CurrentTheme == idx ? (0.5f + 0.3f * glow) : 0.3f;
    dl->AddRect(cardMin, cardMax, C(borderCol), rounding, 0, s_CurrentTheme == idx ? 2.0f : 1.0f);
    ImGui::SetCursorScreenPos(ImVec2(cardMin.x, cardMin.y));
    ImGui::PushID(idx);
    ImGui::InvisibleButton(s_ThemeNames[idx], ImVec2(cardW, cardH));
    if (ImGui::IsItemHovered() && ImGui::IsMouseClicked(0))
    {
        ApplyTheme(idx);
    }
    ImGui::PopID();
    ImGui::SetCursorScreenPos(ImVec2(cardMin.x, cardMax.y + 4.0f));
}

static void DrawPresetColorSwatch(ImVec2 pos, float swatchSize, ImColor color, bool selected)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(pos, ImVec2(pos.x + swatchSize, pos.y + swatchSize), C(color), 3.0f);
    if (selected)
        dl->AddRect(pos, ImVec2(pos.x + swatchSize, pos.y + swatchSize), C(ImColor(255, 255, 255)), 3.0f, 0, 2.0f);
    else
        dl->AddRect(pos, ImVec2(pos.x + swatchSize, pos.y + swatchSize), C(ImColor(60, 60, 80)), 3.0f, 0, 1.0f);
}

void DrawTabTheme(ImDrawList* dl, ImVec2 contentArea, ImVec2 contentPos)
{
    SaveThemeDefaults();
    LoadThemeConfig();
    SyncThemeToStyle();
    ImGui::SetCursorPos(ImVec2(contentPos.x, contentPos.y));
    ImGui::BeginChild("ThemeTab", contentArea, false, ImGuiWindowFlags_AlwaysVerticalScrollbar);
    float availW = ImGui::GetContentRegionAvail().x;

    M_CyberHeader("THEME PRESETS", ThemeColors[s_CurrentTheme][1]);
    {
        float cardW = (availW - 28.0f) / 4.0f;
        float cardH = 82.0f;
        float gridSpacing = 8.0f;
        float totalGridW = cardW * 4.0f + gridSpacing * 3.0f;
        float gridOffsetX = (availW - totalGridW) * 0.5f;
        if (gridOffsetX < 0.0f) gridOffsetX = 0.0f;
        for (int row = 0; row < 2; row++)
        {
            for (int col = 0; col < 4; col++)
            {
                int idx = row * 4 + col;
                if (idx >= 8) break;
                float cx = contentPos.x + gridOffsetX + col * (cardW + gridSpacing);
                float cy = ImGui::GetCursorScreenPos().y + row * (cardH + gridSpacing);
                ImVec2 cMin(cx, cy);
                ImVec2 cMax(cx + cardW, cy + cardH);
                ImGui::SetCursorScreenPos(ImVec2(cx, cy));
                DrawThemeCard(dl, idx, cMin, cMax, 6.0f);
                if (col == 3)
                    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + gridSpacing);
            }
        }
        ImGui::Dummy(ImVec2(0, 8.0f));
    }

    M_CyberHeader("CUSTOM COLORS", ThemeColors[s_CurrentTheme][1]);
    {
        const char* themesForEdit[8] = {
            "Neon Blue", "Rose Red", "Emerald", "Royal Gold",
            "Toxic Green", "Frost Ice", "Royal Purple", "Obsidian"
        };
        M_DropdownSelect("Theme To Edit", &s_EditedTheme, themesForEdit, 8, ThemeColors[s_CurrentTheme][1]);

        const char* slotItems[15] = {
            "Window Background", "Title Bar", "Accent Primary", "Accent Secondary",
            "Text Primary", "Text Dim", "Button Normal", "Button Hover",
            "Button Active", "Frame BG", "Border", "Checkmark",
            "Scrollbar", "Tab Active", "Tab Inactive"
        };
        M_DropdownSelect("Color Slot", &s_ColorSlot, slotItems, 15, ThemeColors[s_CurrentTheme][1]);

        ImColor currentCol = GetCurrentColor();

        float previewSize = 48.0f;
        float previewX = ImGui::GetCursorScreenPos().x + 8.0f;
        float previewY = ImGui::GetCursorScreenPos().y;
        dl->AddRectFilled(ImVec2(previewX, previewY), ImVec2(previewX + previewSize, previewY + previewSize), C(currentCol), 4.0f);
        dl->AddRect(ImVec2(previewX, previewY), ImVec2(previewX + previewSize, previewY + previewSize), C(ImColor(80, 80, 100)), 4.0f, 0, 1.5f);
        ImColor checkBg = ImColor(20, 20, 35);
        dl->AddRectFilled(ImVec2(previewX + previewSize + 8.0f, previewY), ImVec2(previewX + previewSize * 2.0f + 8.0f, previewY + previewSize), C(checkBg), 4.0f);
        dl->AddRectFilled(ImVec2(previewX + previewSize + 8.0f, previewY), ImVec2(previewX + previewSize * 2.0f + 8.0f, previewY + previewSize), C(ImColor(currentCol.Value.x, currentCol.Value.y, currentCol.Value.z, 1.0f)), 4.0f);
        dl->AddRect(ImVec2(previewX + previewSize + 8.0f, previewY), ImVec2(previewX + previewSize * 2.0f + 8.0f, previewY + previewSize), C(ImColor(80, 80, 100)), 4.0f, 0, 1.5f);

        char hexBuf[16];
        int ri = (int)(currentCol.Value.x * 255);
        int gi = (int)(currentCol.Value.y * 255);
        int bi = (int)(currentCol.Value.z * 255);
        int ai = s_ColorSlot == 5 ? (int)(s_TextDimAlpha * 255) : (int)(currentCol.Value.w * 255);
        ImFormatString(hexBuf, sizeof(hexBuf), "#%02X%02X%02X", ri, gi, bi);
        float hexX = previewX + previewSize * 2.0f + 16.0f;
        float hexY = previewY;
        dl->AddText(ImVec2(hexX, hexY), C(ImColor(180, 180, 210)), hexBuf);
        char rgbBuf[64];
        ImFormatString(rgbBuf, sizeof(rgbBuf), "RGB: %d, %d, %d", ri, gi, bi);
        dl->AddText(ImVec2(hexX, hexY + 16.0f), C(ImColor(140, 140, 170)), rgbBuf);
        char alphaBuf[32];
        ImFormatString(alphaBuf, sizeof(alphaBuf), "Alpha: %d", ai);
        dl->AddText(ImVec2(hexX, hexY + 32.0f), C(ImColor(140, 140, 170)), alphaBuf);
        ImGui::Dummy(ImVec2(0, previewSize + 8.0f));

        {
            static char hexInput[16] = "";
            hexInput[0] = 0;
            ImColor c = GetCurrentColor();
            int hri = (int)(c.Value.x * 255);
            int hgi = (int)(c.Value.y * 255);
            int hbi = (int)(c.Value.z * 255);
            ImFormatString(hexInput, sizeof(hexInput), "#%02X%02X%02X", hri, hgi, hbi);
            ImGui::SetNextItemWidth(availW * 0.4f);
            ImGui::InputText("Hex", hexInput, sizeof(hexInput), ImGuiInputTextFlags_CharsHexadecimal | ImGuiInputTextFlags_CharsUppercase);
            if (ImGui::IsItemDeactivatedAfterEdit())
            {
                if (strlen(hexInput) == 7 && hexInput[0] == '#')
                {
                    int hr, hg, hb;
                    if (sscanf(hexInput + 1, "%02x%02x%02x", &hr, &hg, &hb) == 3)
                    {
                        SetCurrentColorRGB(hr / 255.0f, hg / 255.0f, hb / 255.0f);
                        SyncHSVFromCurrentColor();
                        ApplyTheme(s_EditedTheme);
                    }
                }
            }
        }

        float r = currentCol.Value.x;
        float g = currentCol.Value.y;
        float b = currentCol.Value.z;
        float a = s_ColorSlot == 5 ? s_TextDimAlpha : currentCol.Value.w;
        float rf = r, gf = g, bf = b, af = a;

        if (M_ColorSlider("Red", &rf, ImColor(0,0,0), ImColor(1,0,0), ThemeColors[s_CurrentTheme][1]))
        {
            r = rf;
            if (s_ColorSlot != 5) { SetCurrentColorRGB(r, g, b); }
            else { s_TextDimAlpha = af; }
            ApplyTheme(s_EditedTheme);
        }
        if (M_ColorSlider("Green", &gf, ImColor(0,0,0), ImColor(0,1,0), ThemeColors[s_CurrentTheme][1]))
        {
            g = gf;
            if (s_ColorSlot != 5) { SetCurrentColorRGB(r, g, b); }
            else { s_TextDimAlpha = af; }
            ApplyTheme(s_EditedTheme);
        }
        if (M_ColorSlider("Blue", &bf, ImColor(0,0,0), ImColor(0,0,1), ThemeColors[s_CurrentTheme][1]))
        {
            b = bf;
            if (s_ColorSlot != 5) { SetCurrentColorRGB(r, g, b); }
            else { s_TextDimAlpha = af; }
            ApplyTheme(s_EditedTheme);
        }
        if (M_ColorSlider("Alpha", &af, ImColor(0,0,0), ImColor(1,1,1), ThemeColors[s_CurrentTheme][1]))
        {
            if (s_ColorSlot != 5) { SetCurrentColorA(af); }
            else { s_TextDimAlpha = af; }
            ApplyTheme(s_EditedTheme);
        }

        float hue = s_HueEdit, sat = s_SatEdit, val = s_ValEdit;
        {
            ImVec2 quadPos = ImGui::GetCursorScreenPos();
            float quadSize = ImGui::GetContentRegionAvail().x * 0.65f;
            if (quadSize > 180.0f) quadSize = 180.0f;
            if (ColorPickerQuad(quadPos, quadSize, &sat, &val, hue))
            {
                s_SatEdit = sat;
                s_ValEdit = val;
                float nr, ng, nb;
                HSVtoRGB(hue, sat, val, nr, ng, nb);
                if (s_ColorSlot != 5) SetCurrentColorRGB(nr, ng, nb);
                ApplyTheme(s_EditedTheme);
            }
            float stripH = quadSize;
            float stripW = 20.0f;
            ImVec2 stripPos(quadPos.x + quadSize + 10.0f, quadPos.y);
            if (ColorPickerStrip(stripPos, stripH, stripW, &hue))
            {
                s_HueEdit = hue;
                float nr, ng, nb;
                HSVtoRGB(hue, sat, val, nr, ng, nb);
                if (s_ColorSlot != 5) SetCurrentColorRGB(nr, ng, nb);
                ApplyTheme(s_EditedTheme);
            }
            ImGui::Dummy(ImVec2(0, quadSize + 10.0f));
        }

        float swatchSize = 22.0f;
        float swatchSpacing = 6.0f;
        float swatchRowOffset = (availW - (swatchSize * 6.0f + swatchSpacing * 5.0f)) * 0.5f;
        if (swatchRowOffset < 0.0f) swatchRowOffset = 0.0f;
        ImColor presetColors[12] = {
            ImColor(255, 50, 50), ImColor(255, 160, 40), ImColor(255, 230, 60),
            ImColor(60, 220, 80), ImColor(40, 200, 200), ImColor(50, 130, 255),
            ImColor(160, 60, 255), ImColor(255, 80, 180), ImColor(240, 240, 240),
            ImColor(140, 140, 160), ImColor(40, 40, 50), ImColor(10, 10, 15)
        };
        for (int row = 0; row < 2; row++)
        {
            float sy = ImGui::GetCursorPosY() + (row == 0 ? 0.0f : swatchSize + swatchSpacing);
            ImGui::SetCursorPosY(sy);
            float sx = ImGui::GetCursorScreenPos().x + swatchRowOffset;
            for (int col = 0; col < 6; col++)
            {
                int pidx = row * 6 + col;
                if (pidx >= 12) break;
                ImVec2 sp0(sx + col * (swatchSize + swatchSpacing), sy);
                ImVec2 sp1(sp0.x + swatchSize, sp0.y + swatchSize);
                bool sHovered = ImGui::IsMouseHoveringRect(sp0, sp1);
                bool sClicked = sHovered && ImGui::IsMouseClicked(0);
                dl->AddRectFilled(sp0, sp1, C(presetColors[pidx]), 3.0f);
                if (sHovered)
                    dl->AddRect(sp0, sp1, C(ImColor(255, 255, 255, 180)), 3.0f, 0, 2.0f);
                else
                    dl->AddRect(sp0, sp1, C(ImColor(60, 60, 80)), 3.0f, 0, 1.0f);
                if (sClicked)
                {
                    if (s_ColorSlot != 5) SetCurrentColorRGB(
                        presetColors[pidx].Value.x, presetColors[pidx].Value.y, presetColors[pidx].Value.z);
                    ApplyTheme(s_EditedTheme);
                }
                ImGui::SetCursorScreenPos(ImVec2(sp0.x, sp0.y));
                ImGui::PushID(1000 + pidx);
                ImGui::InvisibleButton("##swatch", ImVec2(swatchSize, swatchSize));
                ImGui::PopID();
            }
            ImGui::SetCursorPosY(sy + swatchSize + swatchSpacing);
        }
        ImGui::Dummy(ImVec2(0, 4.0f));

        if (M_GradientButton("Apply", ImVec2(availW * 0.48f, 32.0f), ThemeColors[s_CurrentTheme][1], ThemeColors[s_CurrentTheme][2]))
        {
            ApplyTheme(s_EditedTheme);
        }
        ImGui::SameLine(0.0f, availW * 0.04f);
        if (M_GradientButton("Reset", ImVec2(availW * 0.48f, 32.0f), ImColor(80, 40, 40), ImColor(120, 40, 40)))
        {
            for (int ci = 0; ci < 12; ci++)
                ThemeColors[s_EditedTheme][ci] = s_DefaultThemeColors[s_EditedTheme][ci];
            s_ColorSlot = 0;
            s_HueEdit = 0.0f;
            s_SatEdit = 1.0f;
            s_ValEdit = 1.0f;
            s_TextDimAlpha = 0.5f;
            SyncHSVFromCurrentColor();
            ApplyTheme(s_EditedTheme);
        }
        ImGui::Dummy(ImVec2(0, 8.0f));
    }

    {
        static ImColor customSwatches[8] = {
            ImColor(255, 255, 255), ImColor(200, 200, 200), ImColor(100, 100, 100),
            ImColor(50, 50, 50), ImColor(255, 0, 0), ImColor(0, 255, 0),
            ImColor(0, 0, 255), ImColor(255, 255, 0)
        };
        static int editingSwatch = -1;
        ImVec2 csPos = ImGui::GetCursorScreenPos();
        float csSize = 26.0f;
        float csSp = 6.0f;
        float csLabelOff = (availW - (csSize * 8.0f + csSp * 7.0f)) * 0.5f;
        if (csLabelOff < 0.0f) csLabelOff = 0.0f;
        dl->AddText(ImVec2(csPos.x + 8.0f, csPos.y), C(ImColor(140, 140, 170, 200)), "Custom Swatches");
        dl->AddText(ImVec2(csPos.x + 8.0f, csPos.y + 14.0f), C(ImColor(100, 100, 130, 150)), "Click to save current color  |  Right-click to apply");
        float csY = csPos.y + 30.0f;
        float csX = csPos.x + csLabelOff;
        for (int si = 0; si < 8; si++)
        {
            ImVec2 s0(csX + si * (csSize + csSp), csY);
            ImVec2 s1(s0.x + csSize, s0.y + csSize);
            dl->AddRectFilled(s0, s1, C(customSwatches[si]), 4.0f);
            bool sHov = ImGui::IsMouseHoveringRect(s0, s1);
            if (sHov) dl->AddRect(s0, s1, C(ImColor(255, 255, 255, 180)), 4.0f, 0, 2.0f);
            else dl->AddRect(s0, s1, C(ImColor(60, 60, 80)), 4.0f, 0, 1.0f);
            if (sHov && ImGui::IsMouseClicked(0))
            {
                ImColor cur = GetCurrentColor();
                customSwatches[si] = cur;
                editingSwatch = si;
            }
            if (sHov && ImGui::IsMouseClicked(1))
            {
                if (s_ColorSlot != 5)
                {
                    SetCurrentColorRGB(customSwatches[si].Value.x, customSwatches[si].Value.y, customSwatches[si].Value.z);
                    SyncHSVFromCurrentColor();
                }
            }
            if (editingSwatch == si)
            {
                ImColor gcol = ThemeColors[s_CurrentTheme][1];
                gcol.Value.w = 0.4f + sinf(ImGui::GetTime() * 4.0f) * 0.2f;
                dl->AddRect(s0, s1, C(gcol), 4.0f, 0, 2.5f);
            }
            char sLabel[4];
            ImFormatString(sLabel, sizeof(sLabel), "%d", si + 1);
            ImVec2 ls = ImGui::CalcTextSize(sLabel);
            float lx = csX + si * (csSize + csSp) + (csSize - ls.x) * 0.5f;
            dl->AddText(ImVec2(lx, s1.y + 2.0f), C(ImColor(100, 100, 130, 150)), sLabel);
        }
        ImGui::Dummy(ImVec2(0, csSize + 18.0f));
    }

    {
        ImColor c = GetCurrentColor();
        float ch, cs, cv;
        RGBtoHSV(c.Value.x, c.Value.y, c.Value.z, ch, cs, cv);
        ImVec2 harmPos = ImGui::GetCursorScreenPos();
        float harmY = harmPos.y;
        float swSize = 18.0f;
        float swSp = 4.0f;
        ImColor comp;
        { float nr, ng, nb; HSVtoRGB(ch + 0.5f, cs, cv, nr, ng, nb); comp = ImColor((int)(nr*255), (int)(ng*255), (int)(nb*255)); }
        ImColor analog1, analog2;
        { float nr, ng, nb; HSVtoRGB(ch + 0.083f, cs, cv, nr, ng, nb); analog1 = ImColor((int)(nr*255), (int)(ng*255), (int)(nb*255)); }
        { float nr, ng, nb; HSVtoRGB(ch - 0.083f, cs, cv, nr, ng, nb); analog2 = ImColor((int)(nr*255), (int)(ng*255), (int)(nb*255)); }
        ImColor triad1, triad2;
        { float nr, ng, nb; HSVtoRGB(ch + 0.333f, cs, cv, nr, ng, nb); triad1 = ImColor((int)(nr*255), (int)(ng*255), (int)(nb*255)); }
        { float nr, ng, nb; HSVtoRGB(ch + 0.667f, cs, cv, nr, ng, nb); triad2 = ImColor((int)(nr*255), (int)(ng*255), (int)(nb*255)); }
        ImColor split1, split2;
        { float nr, ng, nb; HSVtoRGB(ch + 0.417f, cs, cv, nr, ng, nb); split1 = ImColor((int)(nr*255), (int)(ng*255), (int)(nb*255)); }
        { float nr, ng, nb; HSVtoRGB(ch + 0.583f, cs, cv, nr, ng, nb); split2 = ImColor((int)(nr*255), (int)(ng*255), (int)(nb*255)); }
        float hx = harmPos.x + 8.0f;
        dl->AddText(ImVec2(hx, harmY), C(ImColor(140, 140, 170, 200)), "Complementary");
        DrawPresetColorSwatch(ImVec2(hx + ImGui::CalcTextSize("Complementary").x + 12.0f, harmY), swSize, comp, false);
        harmY += 22.0f;
        dl->AddText(ImVec2(hx, harmY), C(ImColor(140, 140, 170, 200)), "Analogous");
        float ax = hx + ImGui::CalcTextSize("Analogous").x + 12.0f;
        DrawPresetColorSwatch(ImVec2(ax, harmY), swSize, analog1, false);
        DrawPresetColorSwatch(ImVec2(ax + swSize + swSp, harmY), swSize, c, false);
        DrawPresetColorSwatch(ImVec2(ax + (swSize + swSp) * 2, harmY), swSize, analog2, false);
        harmY += 22.0f;
        dl->AddText(ImVec2(hx, harmY), C(ImColor(140, 140, 170, 200)), "Triadic");
        float tx = hx + ImGui::CalcTextSize("Triadic").x + 12.0f;
        DrawPresetColorSwatch(ImVec2(tx, harmY), swSize, triad1, false);
        DrawPresetColorSwatch(ImVec2(tx + swSize + swSp, harmY), swSize, c, false);
        DrawPresetColorSwatch(ImVec2(tx + (swSize + swSp) * 2, harmY), swSize, triad2, false);
        harmY += 22.0f;
        dl->AddText(ImVec2(hx, harmY), C(ImColor(140, 140, 170, 200)), "Split Comp");
        float sx = hx + ImGui::CalcTextSize("Split Comp").x + 12.0f;
        DrawPresetColorSwatch(ImVec2(sx, harmY), swSize, c, false);
        DrawPresetColorSwatch(ImVec2(sx + swSize + swSp, harmY), swSize, split1, false);
        DrawPresetColorSwatch(ImVec2(sx + (swSize + swSp) * 2, harmY), swSize, split2, false);
        ImGui::Dummy(ImVec2(0, harmY - harmPos.y + 12.0f));
    }

    {
        ImColor c = GetCurrentColor();
        float ch, cs, cv;
        RGBtoHSV(c.Value.x, c.Value.y, c.Value.z, ch, cs, cv);
        ImVec2 mpos = ImGui::GetCursorScreenPos();
        float my = mpos.y;
        float swSize = 18.0f;
        float swSp = 4.0f;
        dl->AddText(ImVec2(mpos.x + 8.0f, my), C(ImColor(140, 140, 170, 200)), "Monochromatic");
        float monoShades[5] = { 0.2f, 0.4f, 0.6f, 0.8f, 1.0f };
        float mlx = mpos.x + ImGui::CalcTextSize("Monochromatic").x + 12.0f;
        for (int mi = 0; mi < 5; mi++)
        {
            float nr, ng, nb;
            HSVtoRGB(ch, cs, cv * monoShades[mi], nr, ng, nb);
            ImColor mc = ImColor((int)(nr*255), (int)(ng*255), (int)(nb*255));
            DrawPresetColorSwatch(ImVec2(mlx + mi * (swSize + swSp), my), swSize, mc, false);
        }
        my += 22.0f;
        dl->AddText(ImVec2(mpos.x + 8.0f, my), C(ImColor(140, 140, 170, 200)), "Square");
        float sqOffsets[4] = { 0.0f, 0.25f, 0.5f, 0.75f };
        float slx = mpos.x + ImGui::CalcTextSize("Square").x + 12.0f;
        for (int si = 0; si < 4; si++)
        {
            float nr, ng, nb;
            HSVtoRGB(fmodf(ch + sqOffsets[si], 1.0f), cs, cv, nr, ng, nb);
            ImColor sc = ImColor((int)(nr*255), (int)(ng*255), (int)(nb*255));
            DrawPresetColorSwatch(ImVec2(slx + si * (swSize + swSp), my), swSize, sc, false);
        }
        my += 22.0f;
        float lum = 0.2126f * c.Value.x + 0.7152f * c.Value.y + 0.0722f * c.Value.z;
        float contBg = (lum + 0.05f) / 0.05f;
        char lumBuf[80];
        ImFormatString(lumBuf, sizeof(lumBuf), "Luminance: %.3f  |  Contrast (on bg): %.1f:1", lum, contBg);
        dl->AddText(ImVec2(mpos.x + 8.0f, my), C(ImColor(140, 140, 170, 200)), lumBuf);
        my += 16.0f;
        char hsvBuf[64];
        ImFormatString(hsvBuf, sizeof(hsvBuf), "HSV: %.0f deg  S: %.0f%%  V: %.0f%%", ch * 360.0f, cs * 100.0f, cv * 100.0f);
        dl->AddText(ImVec2(mpos.x + 8.0f, my), C(ImColor(140, 140, 170, 200)), hsvBuf);
        char hexStr[16];
        ImFormatString(hexStr, sizeof(hexStr), "HEX: #%02X%02X%02X", (int)(c.Value.x*255), (int)(c.Value.y*255), (int)(c.Value.z*255));
        dl->AddText(ImVec2(mpos.x + 8.0f, my + 16.0f), C(ImColor(140, 140, 170, 200)), hexStr);
        ImGui::Dummy(ImVec2(0, my - mpos.y + 28.0f));
    }

    M_CyberHeader("STYLE SETTINGS", ThemeColors[s_CurrentTheme][1]);
    {
        ImGui::Columns(2, "stylecols", false);
        ImGui::SetColumnWidth(0, availW * 0.5f - 4.0f);
        ImGui::SetColumnWidth(1, availW * 0.5f - 4.0f);
        if (M_GradientSlider("Window Rounding", &s_StyleRounding, 0.0f, 20.0f, "%.0f", ThemeColors[s_CurrentTheme][1]))
            SyncStyleFromImGui();
        if (M_GradientSlider("Frame Rounding", &s_StyleFrameRounding, 0.0f, 16.0f, "%.0f", ThemeColors[s_CurrentTheme][1]))
            SyncStyleFromImGui();
        if (M_GradientSlider("Tab Rounding", &s_StyleTabRounding, 0.0f, 12.0f, "%.0f", ThemeColors[s_CurrentTheme][1]))
            SyncStyleFromImGui();
        if (M_GradientSlider("Grab Rounding", &s_StyleGrabRounding, 0.0f, 12.0f, "%.0f", ThemeColors[s_CurrentTheme][1]))
            SyncStyleFromImGui();
        if (M_GradientSlider("Scrollbar Size", &s_StyleScrollbarSize, 4.0f, 20.0f, "%.0f", ThemeColors[s_CurrentTheme][1]))
            SyncStyleFromImGui();
        ImGui::NextColumn();
        if (M_GradientSlider("Frame Padding X", &s_StyleFramePaddingX, 4.0f, 24.0f, "%.0f", ThemeColors[s_CurrentTheme][1]))
            SyncStyleFromImGui();
        if (M_GradientSlider("Frame Padding Y", &s_StyleFramePaddingY, 4.0f, 16.0f, "%.0f", ThemeColors[s_CurrentTheme][1]))
            SyncStyleFromImGui();
        if (M_GradientSlider("Item Spacing X", &s_StyleItemSpacingX, 4.0f, 20.0f, "%.0f", ThemeColors[s_CurrentTheme][1]))
            SyncStyleFromImGui();
        if (M_GradientSlider("Item Spacing Y", &s_StyleItemSpacingY, 2.0f, 16.0f, "%.0f", ThemeColors[s_CurrentTheme][1]))
            SyncStyleFromImGui();
        if (M_GradientSlider("Window Border", &s_StyleWindowBorder, 0.0f, 4.0f, "%.0f", ThemeColors[s_CurrentTheme][1]))
            SyncStyleFromImGui();
        ImGui::NextColumn();
        if (M_GradientSlider("Window Pad X", &s_StyleWindowPaddingX, 2.0f, 20.0f, "%.0f", ThemeColors[s_CurrentTheme][1]))
            SyncStyleFromImGui();
        if (M_GradientSlider("Window Pad Y", &s_StyleWindowPaddingY, 2.0f, 16.0f, "%.0f", ThemeColors[s_CurrentTheme][1]))
            SyncStyleFromImGui();
        if (M_GradientSlider("Inner Spacing X", &s_StyleItemInnerSpacingX, 2.0f, 16.0f, "%.0f", ThemeColors[s_CurrentTheme][1]))
            SyncStyleFromImGui();
        if (M_GradientSlider("Inner Spacing Y", &s_StyleItemInnerSpacingY, 2.0f, 12.0f, "%.0f", ThemeColors[s_CurrentTheme][1]))
            SyncStyleFromImGui();
        if (M_GradientSlider("Grab Min Size", &s_StyleGrabMinSize, 4.0f, 24.0f, "%.0f", ThemeColors[s_CurrentTheme][1]))
            SyncStyleFromImGui();
        if (M_GradientSlider("Indent Spacing", &s_StyleIndentSpacing, 8.0f, 40.0f, "%.0f", ThemeColors[s_CurrentTheme][1]))
            SyncStyleFromImGui();
        ImGui::Columns(1);
        if (M_GradientButton("Reset Style", ImVec2(availW * 0.4f, 28.0f), ImColor(80, 60, 40), ImColor(120, 90, 50)))
        {
            ResetStyleToDefaults();
            SyncStyleFromImGui();
        }
        ImGui::Dummy(ImVec2(0, 8.0f));
    }

    M_CyberHeader("LIVE PREVIEW", ThemeColors[s_CurrentTheme][1]);
    {
        ImVec2 previewSize = ImVec2(availW, 720.0f);
        ImGui::BeginChild("Preview", previewSize, false, ImGuiWindowFlags_AlwaysVerticalScrollbar);
        ImGui::PushItemFlag(ImGuiItemFlags_Disabled, true);
        M_ModernSwitch("Wi-Fi", &s_PreviewSwitch1, ThemeColors[s_CurrentTheme][1]);
        M_ModernSwitch("Bluetooth", &s_PreviewSwitch2, ThemeColors[s_CurrentTheme][1]);
        M_ModernSwitch("Auto Sync", &s_PreviewSwitch3, ThemeColors[s_CurrentTheme][1]);
        M_ModernSwitch("Dark Mode", &s_PreviewSwitch4, ThemeColors[s_CurrentTheme][11]);
        M_ModernSwitch("Notifications", &s_PreviewSwitch5, ThemeColors[s_CurrentTheme][7]);
        M_ModernSwitch("Vibration", &s_PreviewSwitch6, ThemeColors[s_CurrentTheme][2]);
        M_ModernSwitch("Sound FX", &s_PreviewSwitch7, ThemeColors[s_CurrentTheme][8]);
        M_ClassicToggle("Classic Toggle", &s_PreviewSwitch1, ThemeColors[s_CurrentTheme][1]);
        M_ToggleRow("\xe2\x9a\x99", "Dark Mode Toggle", "System-wide dark mode", &s_PreviewToggleRow, ThemeColors[s_CurrentTheme][1]);
        const char* segItems[] = { "Off", "Low", "Med", "High" };
        M_SegmentedToggle("Quality", &s_PreviewSegmented, segItems, 4, ThemeColors[s_CurrentTheme][1]);
        M_SectionDivider("BUTTONS", ThemeColors[s_CurrentTheme][1]);
        float btnW = ImGui::GetContentRegionAvail().x;
        M_GradientButton("Small", ImVec2(btnW * 0.3f, 28.0f), ThemeColors[s_CurrentTheme][1], ThemeColors[s_CurrentTheme][2]);
        ImGui::SameLine(0.0f, 8.0f);
        M_GradientButton("Medium", ImVec2(btnW * 0.3f, 34.0f), ThemeColors[s_CurrentTheme][1], ThemeColors[s_CurrentTheme][2]);
        ImGui::SameLine(0.0f, 8.0f);
        M_GradientButton("Large", ImVec2(btnW * 0.3f, 42.0f), ThemeColors[s_CurrentTheme][1], ThemeColors[s_CurrentTheme][2]);
        M_CyberButton("CYBER PUNK", ImVec2(btnW, 36.0f), ThemeColors[s_CurrentTheme][1]);
        M_SectionDivider("INPUTS", ThemeColors[s_CurrentTheme][1]);
        float sv = s_PreviewSliderVal;
        M_GradientSlider("Volume", &sv, 0.0f, 1.0f, "%.2f", ThemeColors[s_CurrentTheme][1]);
        s_PreviewSliderVal = sv;
        M_IntSlider("Brightness", &s_PreviewIntVal, 0, 100, "%d", ThemeColors[s_CurrentTheme][1]);
        M_RangeSlider("Range", &s_PreviewRangeMin, &s_PreviewRangeMax, 0.0f, 100.0f, "%.0f", ThemeColors[s_CurrentTheme][1]);
        M_KnobDial("Sensitivity", &s_PreviewKnobVal, 0.0f, 100.0f, "%.0f", ThemeColors[s_CurrentTheme][1]);
        const char* dropItems[] = { "Option A", "Option B", "Option C", "Option D" };
        M_DropdownSelect("Mode", &s_PreviewDropdown, dropItems, 4, ThemeColors[s_CurrentTheme][1]);
        M_FancyCheckbox("Enable Notifications", &s_PreviewCheckbox1, ThemeColors[s_CurrentTheme][1]);
        M_FancyCheckbox("Dark Mode", &s_PreviewCheckbox2, ThemeColors[s_CurrentTheme][1]);
        M_RadioSelector("Option 1", s_PreviewRadio1, ThemeColors[s_CurrentTheme][1]);
        M_RadioSelector("Option 2", s_PreviewRadio2, ThemeColors[s_CurrentTheme][2]);
        M_RadioSelector("Option 3", s_PreviewRadio3, ThemeColors[s_CurrentTheme][7]);
        M_SectionDivider("CONTAINERS", ThemeColors[s_CurrentTheme][1]);
        M_CardContainer("Settings Panel", &s_PreviewCardCollapsed, ThemeColors[s_CurrentTheme][1], "NEW");
        if (!s_PreviewCardCollapsed)
        {
            ImGui::Dummy(ImVec2(0, 4.0f));
            ImGui::Text("Content inside card container with custom styling");
            ImGui::Text("Line 2 of card content for preview purposes");
            ImGui::Dummy(ImVec2(0, 4.0f));
        }
        M_SectionDivider("STATISTICS", ThemeColors[s_CurrentTheme][1]);
        M_StatCard("Score", "60", "+12%", true, ThemeColors[s_CurrentTheme][1]);
        ImGui::SameLine(0.0f, 6.0f);
        M_StatCard("Kills", "120", "+8%", true, ThemeColors[s_CurrentTheme][2]);
        ImGui::SameLine(0.0f, 6.0f);
        M_StatCard("Deaths", "30", "-5%", false, ThemeColors[s_CurrentTheme][7]);
        M_SectionDivider("INFO ROWS", ThemeColors[s_CurrentTheme][1]);
        M_InfoRow("Status", "Connected", ThemeColors[s_CurrentTheme][1], "\xe2\x9c\x93");
        M_InfoRow("Latency", "32 ms", ThemeColors[s_CurrentTheme][11]);
        M_InfoRow("Version", "2.1.0", ThemeColors[s_CurrentTheme][1]);
        M_InfoRow("FPS", "144", ThemeColors[s_CurrentTheme][2]);
        M_InfoRow("Memory", "64 MB", ThemeColors[s_CurrentTheme][11]);
        M_InfoRow("CPU", "2.4 GHz", ThemeColors[s_CurrentTheme][1]);
        M_SectionDivider("PROGRESS", ThemeColors[s_CurrentTheme][1]);
        float pVal1 = 0.75f;
        ImGui::ProgressBar(pVal1, ImVec2(availW * 0.8f, 6.0f), "");
        ImGui::SameLine();
        ImGui::TextColored(ImColor(ThemeColors[s_CurrentTheme][3].Value.x, ThemeColors[s_CurrentTheme][3].Value.y, ThemeColors[s_CurrentTheme][3].Value.z, 0.8f), " %.0f%%", pVal1 * 100.0f);
        float pVal2 = 0.45f;
        ImGui::ProgressBar(pVal2, ImVec2(availW * 0.8f, 6.0f), "");
        ImGui::SameLine();
        ImGui::TextColored(ImColor(ThemeColors[s_CurrentTheme][3].Value.x, ThemeColors[s_CurrentTheme][3].Value.y, ThemeColors[s_CurrentTheme][3].Value.z, 0.8f), " %.0f%%", pVal2 * 100.0f);
        float pVal3 = 0.90f;
        ImGui::ProgressBar(pVal3, ImVec2(availW * 0.8f, 6.0f), "");
        ImGui::SameLine();
        ImGui::TextColored(ImColor(ThemeColors[s_CurrentTheme][3].Value.x, ThemeColors[s_CurrentTheme][3].Value.y, ThemeColors[s_CurrentTheme][3].Value.z, 0.8f), " %.0f%%", pVal3 * 100.0f);
        M_SectionDivider("TEXT SAMPLES", ThemeColors[s_CurrentTheme][1]);
        ImGui::TextUnformatted("Standard text line using the current theme text color");
        ImGui::TextColored(ThemeColors[s_CurrentTheme][1], "Accent colored text for highlights and labels");
        ImGui::TextColored(ThemeColors[s_CurrentTheme][11], "Checkmark/highlight color applied to secondary text");
        ImGui::TextColored(ImColor(ThemeColors[s_CurrentTheme][3].Value.x, ThemeColors[s_CurrentTheme][3].Value.y, ThemeColors[s_CurrentTheme][3].Value.z, 0.5f), "Dimmed / disabled text at 50%% alpha for secondary information");
        ImGui::BulletText("Bullet point item one in the preview list");
        ImGui::BulletText("Bullet point item two with extended description");
        ImGui::BulletText("Bullet point item three showing multi-line content");
        M_SectionDivider("MORE CONTROLS", ThemeColors[s_CurrentTheme][1]);
        ImGui::TextUnformatted("Additional button styles and control states:");
        M_GradientButton("Primary Action", ImVec2(availW * 0.45f, 30.0f), ThemeColors[s_CurrentTheme][1], ThemeColors[s_CurrentTheme][2]);
        ImGui::SameLine(0.0f, 6.0f);
        M_GradientButton("Secondary", ImVec2(availW * 0.45f, 30.0f), ThemeColors[s_CurrentTheme][2], ThemeColors[s_CurrentTheme][7]);
        M_GradientButton("Danger Zone", ImVec2(availW * 0.45f, 30.0f), ImColor(180, 40, 40), ImColor(220, 60, 60));
        ImGui::SameLine(0.0f, 6.0f);
        M_GradientButton("Success", ImVec2(availW * 0.45f, 30.0f), ImColor(40, 160, 60), ImColor(60, 200, 80));
        M_SectionDivider("LAYOUT ELEMENTS", ThemeColors[s_CurrentTheme][1]);
        ImGui::TextUnformatted("Sample list of items with themed separators:");
        ImColor sepCol = ThemeColors[s_CurrentTheme][9];
        dl->AddLine(ImVec2(ImGui::GetCursorScreenPos().x, ImGui::GetCursorScreenPos().y), ImVec2(ImGui::GetCursorScreenPos().x + availW * 0.9f, ImGui::GetCursorScreenPos().y), C(sepCol), 1.0f);
        ImGui::Dummy(ImVec2(0.0f, 4.0f));
        ImGui::TextUnformatted("  Item 1  -  Sample data row in the preview panel");
        dl->AddLine(ImVec2(ImGui::GetCursorScreenPos().x, ImGui::GetCursorScreenPos().y), ImVec2(ImGui::GetCursorScreenPos().x + availW * 0.9f, ImGui::GetCursorScreenPos().y), C(sepCol), 1.0f);
        ImGui::Dummy(ImVec2(0.0f, 4.0f));
        ImGui::TextUnformatted("  Item 2  -  Another row demonstrating themed separation");
        dl->AddLine(ImVec2(ImGui::GetCursorScreenPos().x, ImGui::GetCursorScreenPos().y), ImVec2(ImGui::GetCursorScreenPos().x + availW * 0.9f, ImGui::GetCursorScreenPos().y), C(sepCol), 1.0f);
        ImGui::Dummy(ImVec2(0.0f, 4.0f));
        ImGui::TextUnformatted("  Item 3  -  Third row with varied content length here");
        dl->AddLine(ImVec2(ImGui::GetCursorScreenPos().x, ImGui::GetCursorScreenPos().y), ImVec2(ImGui::GetCursorScreenPos().x + availW * 0.9f, ImGui::GetCursorScreenPos().y), C(sepCol), 1.0f);
        ImGui::Dummy(ImVec2(0.0f, 4.0f));
        ImGui::TextUnformatted("  Item 4  -  Fourth data entry in the themed preview list");
        dl->AddLine(ImVec2(ImGui::GetCursorScreenPos().x, ImGui::GetCursorScreenPos().y), ImVec2(ImGui::GetCursorScreenPos().x + availW * 0.9f, ImGui::GetCursorScreenPos().y), C(sepCol), 1.0f);
        ImGui::Dummy(ImVec2(0.0f, 8.0f));
        ImGui::PopItemFlag();
        ImGui::EndChild();
    }

    M_CyberHeader("THEME MANAGEMENT", ThemeColors[s_CurrentTheme][1]);
    {
        float btnW = (availW - 12.0f) / 3.0f;
        if (M_GradientButton("Export Theme", ImVec2(btnW, 34.0f), ThemeColors[s_CurrentTheme][1], ImColor(60, 200, 100)))
        {
        }
        ImGui::SameLine(0.0f, 6.0f);
        if (M_GradientButton("Import Theme", ImVec2(btnW, 34.0f), ThemeColors[s_CurrentTheme][2], ImColor(200, 180, 60)))
        {
        }
        ImGui::SameLine(0.0f, 6.0f);
        if (M_GradientButton("Reset All", ImVec2(btnW, 34.0f), ImColor(120, 40, 40), ImColor(180, 50, 50)))
        {
            for (int ti = 0; ti < 8; ti++)
                for (int ci = 0; ci < 12; ci++)
                    ThemeColors[ti][ci] = s_DefaultThemeColors[ti][ci];
            s_EditedTheme = 0;
            s_CurrentTheme = 0;
            s_ColorSlot = 0;
            s_HueEdit = 0.0f;
            s_SatEdit = 1.0f;
            s_ValEdit = 1.0f;
            s_TextDimAlpha = 0.5f;
            ResetStyleToDefaults();
            ApplyTheme(0);
        }
        char themeJson[512];
        ImColor* tc = ThemeColors[s_CurrentTheme];
        ImFormatString(themeJson, sizeof(themeJson),
            "{bg:[%d,%d,%d],accent:[%d,%d,%d],text:[%d,%d,%d],title:[%d,%d,%d],btn:[%d,%d,%d],fr:[%d,%d,%d]}",
            (int)(tc[0].Value.x * 255), (int)(tc[0].Value.y * 255), (int)(tc[0].Value.z * 255),
            (int)(tc[1].Value.x * 255), (int)(tc[1].Value.y * 255), (int)(tc[1].Value.z * 255),
            (int)(tc[3].Value.x * 255), (int)(tc[3].Value.y * 255), (int)(tc[3].Value.z * 255),
            (int)(tc[4].Value.x * 255), (int)(tc[4].Value.y * 255), (int)(tc[4].Value.z * 255),
            (int)(tc[5].Value.x * 255), (int)(tc[5].Value.y * 255), (int)(tc[5].Value.z * 255),
            (int)(tc[6].Value.x * 255), (int)(tc[6].Value.y * 255), (int)(tc[6].Value.z * 255)
        );
        M_InfoRow("Current Theme Data", themeJson, ThemeColors[s_CurrentTheme][1]);

        {
            float swSize = 20.0f;
            float swSp = 4.0f;
            float cols = 6;
            ImVec2 gridStart = ImGui::GetCursorScreenPos();
            gridStart.x += 6.0f;
            for (int i = 0; i < 12; i++)
            {
                int row = i / (int)cols;
                int col = i % (int)cols;
                ImVec2 sp0(gridStart.x + col * (swSize + swSp), gridStart.y + row * (swSize + swSp + 14.0f));
                ImVec2 sp1(sp0.x + swSize, sp0.y + swSize);
                dl->AddRectFilled(sp0, sp1, C(tc[i]), 3.0f);
                dl->AddRect(sp0, sp1, C(ImColor(60, 60, 80)), 3.0f, 0, 1.0f);
                char lbl[16];
                ImFormatString(lbl, sizeof(lbl), "%s", s_ColorLabels[i]);
                ImVec2 ls = ImGui::CalcTextSize(lbl);
                float lx = gridStart.x + col * (swSize + swSp) + (swSize - ls.x) * 0.5f;
                float ly = sp1.y + 2.0f;
                dl->AddText(ImVec2(lx, ly), C(ImColor(120, 120, 150)), lbl);
            }
            float gridH = 2 * (swSize + 14.0f + swSp);
            ImGui::Dummy(ImVec2(0, gridH + 8.0f));
        }

        {
            static char themeRenameBuf[64] = "";
            if (themeRenameBuf[0] == 0)
                ImFormatString(themeRenameBuf, sizeof(themeRenameBuf), "%s", s_ThemeNames[s_CurrentTheme]);
            ImGui::SetNextItemWidth(availW * 0.6f);
            ImGui::InputText("Theme Name", themeRenameBuf, sizeof(themeRenameBuf));
            ImGui::SameLine();
            if (M_GradientButton("Rename", ImVec2(80, 28.0f), tc[1], tc[2]))
            {
                if (strlen(themeRenameBuf) > 0)
                    s_ThemeNames[s_CurrentTheme] = themeRenameBuf;
            }
        }
        {
            const char* slotList[8] = {
                "Slot 1 (Neon Blue)", "Slot 2 (Rose Red)", "Slot 3 (Emerald)",
                "Slot 4 (Royal Gold)", "Slot 5 (Toxic Green)", "Slot 6 (Frost Ice)",
                "Slot 7 (Royal Purple)", "Slot 8 (Obsidian)"
            };
            static int copyDest = 0;
            M_DropdownSelect("Copy Theme To", &copyDest, slotList, 8, tc[1]);
            if (M_GradientButton("Copy Current Theme", ImVec2(availW * 0.5f, 28.0f), tc[1], tc[2]))
            {
                if (copyDest >= 0 && copyDest < 8 && copyDest != s_CurrentTheme)
                {
                    for (int ci = 0; ci < 12; ci++)
                        ThemeColors[copyDest][ci] = ThemeColors[s_CurrentTheme][ci];
                }
            }
        }
        {
            float lumBg = 0.2126f * tc[0].Value.x + 0.7152f * tc[0].Value.y + 0.0722f * tc[0].Value.z;
            float lumText = 0.2126f * tc[3].Value.x + 0.7152f * tc[3].Value.y + 0.0722f * tc[3].Value.z;
            float lumAccent = 0.2126f * tc[1].Value.x + 0.7152f * tc[1].Value.y + 0.0722f * tc[1].Value.z;
            float contText = (ImMax(lumText, lumBg) + 0.05f) / (ImMin(lumText, lumBg) + 0.05f);
            float contAccent = (ImMax(lumAccent, lumBg) + 0.05f) / (ImMin(lumAccent, lumBg) + 0.05f);
            char statsBuf[256];
            ImFormatString(statsBuf, sizeof(statsBuf),
                "Text contrast: %.1f:1  |  Accent contrast: %.1f:1  |  BG luminance: %.2f",
                contText, contAccent, lumBg);
            M_InfoRow("Contrast Analysis", statsBuf, lumText > 0.5f ? tc[11] : tc[1]);
            ImGui::Dummy(ImVec2(0, 4.0f));
            ImGui::TextDisabled("Tip: Use Ctrl+C to copy theme data, Ctrl+V to import");
        }
    }

    M_CyberHeader("ALL THEMES OVERVIEW", ThemeColors[s_CurrentTheme][1]);
    {
        float ovSwSize = 16.0f;
        float ovSwSp = 3.0f;
        float ovLabelW = 80.0f;
        float ovColW = ovSwSize * 4.0f + ovSwSp * 3.0f;
        float ovRowH = ovSwSize + 4.0f;
        float ovTotalW = ovLabelW + ovColW + 12.0f;
        float ovOffX = (availW - ovTotalW) * 0.5f;
        if (ovOffX < 0.0f) ovOffX = 0.0f;
        dl->AddText(ImVec2(ImGui::GetCursorScreenPos().x + ovOffX, ImGui::GetCursorScreenPos().y),
            C(ImColor(120, 120, 150)), "Theme");
        for (int hi = 0; hi < 4; hi++)
        {
            const char* hLabels[4] = { "BG", "Acc", "A2", "Txt" };
            float hx = ImGui::GetCursorScreenPos().x + ovOffX + ovLabelW + hi * (ovSwSize + ovSwSp) + (ovSwSize - ImGui::CalcTextSize(hLabels[hi]).x) * 0.5f;
            dl->AddText(ImVec2(hx, ImGui::GetCursorScreenPos().y), C(ImColor(120, 120, 150)), hLabels[hi]);
        }
        ImGui::Dummy(ImVec2(0, ImGui::GetTextLineHeight() + 4.0f));
        for (int ti = 0; ti < 8; ti++)
        {
            ImVec2 rowPos = ImGui::GetCursorScreenPos();
            float ry = rowPos.y;
            float lx = rowPos.x + ovOffX;
            ImColor nameCol = ti == s_CurrentTheme ? ThemeColors[ti][1] : ImColor(180, 180, 210);
            nameCol.Value.w = ti == s_CurrentTheme ? 1.0f : 0.7f;
            dl->AddText(ImVec2(lx, ry), C(nameCol), s_ThemeNames[ti]);
            if (ti == s_CurrentTheme)
            {
                float dotSize = 4.0f;
                dl->AddCircleFilled(ImVec2(lx - 8.0f, ry + ovSwSize * 0.5f), dotSize, C(ThemeColors[ti][1]), 8);
            }
            float sx = lx + ovLabelW;
            int colIndices[4] = { 0, 1, 2, 3 };
            for (int ci = 0; ci < 4; ci++)
            {
                ImVec2 sp0(sx + ci * (ovSwSize + ovSwSp), ry);
                ImVec2 sp1(sp0.x + ovSwSize, sp0.y + ovSwSize);
                ImColor swatchCol = ThemeColors[ti][colIndices[ci]];
                dl->AddRectFilled(sp0, sp1, C(swatchCol), 2.0f);
                dl->AddRect(sp0, sp1, C(ImColor(60, 60, 80, 100)), 2.0f, 0, 0.5f);
                if (ti == s_CurrentTheme && ci == 1)
                    dl->AddRect(sp0, sp1, C(ThemeColors[ti][1]), 2.0f, 0, 1.5f);
            }
            ImGui::Dummy(ImVec2(0, ovRowH + 2.0f));
            if (ImGui::IsMouseHoveringRect(rowPos, ImVec2(rowPos.x + ovTotalW, rowPos.y + ovRowH)) && ImGui::IsMouseClicked(0))
            {
                ApplyTheme(ti);
            }
        }
        ImGui::Dummy(ImVec2(0, 6.0f));
        ImGui::TextDisabled("Click any theme row above to apply it instantly");
        ImColor legendCols[4] = { ThemeColors[0][0], ThemeColors[0][1], ThemeColors[0][2], ThemeColors[0][3] };
        const char* legendLabels[4] = { "Background", "Accent", "Accent 2", "Text" };
        float legOffX = (availW - 520.0f) * 0.5f;
        if (legOffX < 0.0f) legOffX = 0.0f;
        for (int li = 0; li < 4; li++)
        {
            ImVec2 lp = ImVec2(ImGui::GetCursorScreenPos().x + legOffX + li * 130.0f, ImGui::GetCursorScreenPos().y);
            ImVec2 ls0(lp.x, lp.y);
            ImVec2 ls1(lp.x + 10.0f, lp.y + 10.0f);
            dl->AddRectFilled(ls0, ls1, C(legendCols[li]), 2.0f);
            dl->AddText(ImVec2(lp.x + 14.0f, lp.y), C(ImColor(140, 140, 170, 200)), legendLabels[li]);
        }
        ImGui::Dummy(ImVec2(0, 16.0f));
    }

    ImGui::EndChild();
}
