#pragma once
#include "Config.h"
#include <cstdint>
#include <string>
#include <vector>
#include <map>

class ConfigSerializer {
public:
    static bool SaveBinary(const std::string& path, Toggles* tog, Config* cfg);
    static bool LoadBinary(const std::string& path, Toggles* tog, Config* cfg);

    static bool SaveJSON(const std::string& path, Toggles* tog, Config* cfg);
    static bool LoadJSON(const std::string& path, Toggles* tog, Config* cfg);

    static std::vector<std::string> ListProfiles(const std::string& directory);
    static bool SaveProfile(const std::string& name, Toggles* tog, Config* cfg);
    static bool LoadProfile(const std::string& name, Toggles* tog, Config* cfg);
    static bool DeleteProfile(const std::string& name);

    static bool ValidateBinary(const std::string& path);

    static const uint32_t MAGIC = 0x434F4E46;
    static const uint32_t VERSION = 0x00020000;
};
