#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "../../../imgui/imgui.h"
#include "../../../imgui/imgui_internal.h"
#include "../../../imgui/mycustom/imgui_Custom.h"
#include <math.h>
#include <string.h>
#include <map>
#include <stdlib.h>

static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }

int M_TabStrip(const char* label, int active, const char** tabs, int count, ImColor accent)
{
    static std::map<const char*, struct { float animPos; float animWidth; int prevActive; float hoverAnim; int hoverIdx; float pulse; }> s_state;
    auto& st = s_state[label];
    ImDrawList* dl = ImGui::GetOverlayDrawList();
    ImGuiIO& io = ImGui::GetIO();
    ImVec2 mouse = io.MousePos;
    int result = active;
    float tabH = 36.0f;
    float totalW = 0.0f;
    float* tabW = (float*)alloca(count * sizeof(float));
    for (int i = 0; i < count; ++i)
    {
        tabW[i] = ImGui::CalcTextSize(tabs[i]).x + 30.0f;
        totalW += tabW[i];
    }
    ImVec2 startPos = ImGui::GetCursorScreenPos();
    ImRect bb(startPos, ImVec2(startPos.x + totalW, startPos.y + tabH));
    ImGui::SetCursorScreenPos(startPos);
    ImGui::InvisibleButton(label, bb.GetSize());
    st.pulse = sinf(io.Time * 2.0f) * 0.08f + 0.92f;
    float xOff = 0.0f;
    float targetPos = 0.0f;
    float targetW = tabW[0];
    for (int i = 0; i < count; ++i)
    {
        if (i == active) { targetPos = xOff; targetW = tabW[i]; }
        ImVec2 p0 = ImVec2(startPos.x + xOff, startPos.y);
        ImVec2 p1 = ImVec2(p0.x + tabW[i], p0.y + tabH);
        bool hovered = (mouse.x >= p0.x && mouse.x <= p1.x && mouse.y >= p0.y && mouse.y <= p1.y);
        if (hovered)
        {
            st.hoverIdx = i;
            if (io.MouseClicked[0]) result = i;
        }
        ImU32 textCol;
        if (i == active) textCol = C(accent);
        else if (hovered) textCol = C(ImColor(210,210,220));
        else textCol = C(ImColor(120,120,135));
        ImVec2 ts = ImGui::CalcTextSize(tabs[i]);
        dl->AddText(ImGui::GetFont(), 13.0f, ImVec2(p0.x + (tabW[i] - ts.x) * 0.5f, p0.y + (tabH - ts.y) * 0.5f), textCol, tabs[i]);
        xOff += tabW[i];
    }
    st.animPos += (targetPos - st.animPos) * ImClamp(io.DeltaTime * 16.0f, 0.0f, 1.0f);
    st.animWidth += (targetW - st.animWidth) * ImClamp(io.DeltaTime * 16.0f, 0.0f, 1.0f);
    st.hoverAnim += ((st.hoverIdx >= 0 ? 1.0f : 0.0f) - st.hoverAnim) * ImClamp(io.DeltaTime * 8.0f, 0.0f, 1.0f);
    dl->AddRectFilled(ImVec2(startPos.x, startPos.y + tabH - 1.0f), ImVec2(startPos.x + totalW, startPos.y + tabH), C(ImColor(38,38,48)));
    float underlineH = 3.0f * st.pulse;
    dl->AddRectFilled(ImVec2(startPos.x + st.animPos, startPos.y + tabH - underlineH), ImVec2(startPos.x + st.animPos + st.animWidth, startPos.y + tabH), C(accent));
    if (st.animWidth > 0)
    {
        ImColor glow = accent;
        glow.Value.w = 0.15f;
        dl->AddRectFilled(ImVec2(startPos.x + st.animPos, startPos.y + tabH - underlineH - 3.0f), ImVec2(startPos.x + st.animPos + st.animWidth, startPos.y + tabH - underlineH), C(glow));
    }
    if (st.hoverAnim > 0.05f && st.hoverIdx >= 0 && st.hoverIdx != active)
    {
        float hx = 0.0f;
        for (int i = 0; i < st.hoverIdx; ++i) hx += tabW[i];
        ImColor hovCol = ImColor(255,255,255, (int)(15 * st.hoverAnim));
        dl->AddRectFilled(ImVec2(startPos.x + hx, startPos.y + 2.0f), ImVec2(startPos.x + hx + tabW[st.hoverIdx], startPos.y + tabH - 2.0f), C(hovCol), 4.0f);
    }
    if (io.MouseClicked[0] && (io.MousePos.y < startPos.y || io.MousePos.y > startPos.y + tabH))
    {
    }
    return result;
}

static bool M_TabCloseButton(ImDrawList* dl, ImVec2 pos, bool hovered)
{
    ImU32 col = hovered ? C(ImColor(255,120,120)) : C(ImColor(150,150,165));
    float s = 3.0f;
    dl->AddLine(ImVec2(pos.x - s, pos.y - s), ImVec2(pos.x + s, pos.y + s), col, 1.5f);
    dl->AddLine(ImVec2(pos.x + s, pos.y - s), ImVec2(pos.x - s, pos.y + s), col, 1.5f);
    return hovered;
}

int M_Pagination(const char* label, int currentPage, int totalPages, ImColor accent)
{
    if (totalPages <= 0) return currentPage;
    ImDrawList* dl = ImGui::GetOverlayDrawList();
    ImGuiIO& io = ImGui::GetIO();
    ImVec2 mouse = io.MousePos;
    ImVec2 startPos = ImGui::GetCursorScreenPos();
    float btnSize = 32.0f;
    float gap = 6.0f;
    int result = currentPage;
    auto drawBtn = [&](int page, float xOff) -> bool {
        ImVec2 p0 = ImVec2(startPos.x + xOff, startPos.y);
        ImVec2 p1 = ImVec2(p0.x + btnSize, p0.y + btnSize);
        bool hovered = (mouse.x >= p0.x && mouse.x <= p1.x && mouse.y >= p0.y && mouse.y <= p1.y);
        bool active = (page == currentPage);
        ImU32 bg;
        if (active) bg = C(accent);
        else if (hovered) bg = C(ImColor(60,60,75));
        else bg = C(ImColor(40,40,52));
        ImU32 col = active ? C(ImColor(255,255,255)) : C(ImColor(180,180,195));
        dl->AddRectFilled(p0, p1, bg, 6.0f);
        if (!active) dl->AddRect(p0, p1, C(ImColor(55,55,68)), 6.0f);
        if (active)
        {
            ImColor glow = accent;
            glow.Value.w = 0.2f;
            dl->AddRect(p0, p1, C(glow), 6.0f, ImDrawFlags_None, 2.0f);
        }
        char txt[8]; snprintf(txt, sizeof(txt), "%d", page + 1);
        ImVec2 ts = ImGui::CalcTextSize(txt);
        dl->AddText(ImVec2(p0.x + (btnSize - ts.x) * 0.5f, p0.y + (btnSize - ts.y) * 0.5f), col, txt);
        if (hovered && io.MouseClicked[0]) result = page;
        return active;
    };
    auto drawArrow = [&](const char* sym, float xOff, bool enabled) -> bool {
        ImVec2 p0 = ImVec2(startPos.x + xOff, startPos.y);
        ImVec2 p1 = ImVec2(p0.x + btnSize, p0.y + btnSize);
        bool hovered = enabled && mouse.x >= p0.x && mouse.x <= p1.x && mouse.y >= p0.y && mouse.y <= p1.y;
        ImU32 bg = hovered ? C(ImColor(50,50,65)) : C(ImColor(35,35,45));
        ImU32 col = enabled ? C(ImColor(200,200,215)) : C(ImColor(60,60,75));
        dl->AddRectFilled(p0, p1, bg, 6.0f);
        dl->AddRect(p0, p1, C(ImColor(55,55,68)), 6.0f);
        ImVec2 ts = ImGui::CalcTextSize(sym);
        dl->AddText(ImVec2(p0.x + (btnSize - ts.x) * 0.5f, p0.y + (btnSize - ts.y) * 0.5f), col, sym);
        if (hovered && io.MouseClicked[0] && enabled) return true;
        return false;
    };
    float xOff = 0.0f;
    if (drawArrow("<", xOff, currentPage > 0)) result = currentPage - 1;
    xOff += btnSize + gap;
    if (totalPages <= 7)
    {
        for (int i = 0; i < totalPages; ++i)
        {
            drawBtn(i, xOff);
            xOff += btnSize + gap;
        }
    }
    else
    {
        drawBtn(0, xOff);
        xOff += btnSize + gap;
        if (currentPage > 2)
        {
            ImVec2 ep0 = ImVec2(startPos.x + xOff, startPos.y);
            dl->AddText(ImGui::GetFont(), 13.0f, ImVec2(ep0.x + (btnSize - ImGui::CalcTextSize("...").x) * 0.5f, ep0.y + (btnSize - ImGui::CalcTextSize("...").y) * 0.5f), C(ImColor(90,90,105)), "...");
            xOff += btnSize + gap;
        }
        int startPg = ImMax(1, currentPage - 1);
        int endPg = ImMin(totalPages - 2, currentPage + 1);
        if (currentPage <= 2) { startPg = 1; endPg = ImMin(3, totalPages - 2); }
        if (currentPage >= totalPages - 3) { startPg = ImMax(1, totalPages - 4); endPg = totalPages - 2; }
        for (int i = startPg; i <= endPg; ++i)
        {
            drawBtn(i, xOff);
            xOff += btnSize + gap;
        }
        if (currentPage < totalPages - 3)
        {
            ImVec2 ep0 = ImVec2(startPos.x + xOff, startPos.y);
            dl->AddText(ImGui::GetFont(), 13.0f, ImVec2(ep0.x + (btnSize - ImGui::CalcTextSize("...").x) * 0.5f, ep0.y + (btnSize - ImGui::CalcTextSize("...").y) * 0.5f), C(ImColor(90,90,105)), "...");
            xOff += btnSize + gap;
        }
        drawBtn(totalPages - 1, xOff);
        xOff += btnSize + gap;
    }
    if (drawArrow(">", xOff, currentPage < totalPages - 1)) result = currentPage + 1;
    float totalW = xOff + btnSize;
    char pageInfo[32];
    snprintf(pageInfo, sizeof(pageInfo), "Page %d/%d", currentPage + 1, totalPages);
    ImVec2 pis = ImGui::CalcTextSize(pageInfo);
    dl->AddText(ImGui::GetFont(), 9.0f, ImVec2(startPos.x + totalW + 8.0f, startPos.y + (btnSize - pis.y) * 0.5f), C(ImColor(90,90,105)), pageInfo);
    ImGui::SetCursorScreenPos(ImVec2(startPos.x, startPos.y + btnSize + 8.0f));
    return result;
}

int M_Breadcrumbs(const char* label, const char** path, int depth, ImColor accent, int* clickTarget)
{
    ImDrawList* dl = ImGui::GetOverlayDrawList();
    ImGuiIO& io = ImGui::GetIO();
    ImVec2 mouse = io.MousePos;
    ImVec2 pos = ImGui::GetCursorScreenPos();
    int result = -1;
    if (clickTarget) *clickTarget = -1;
    float xOff = 0.0f;
    float itemH = 24.0f;
    for (int i = 0; i < depth; ++i)
    {
        ImVec2 ts = ImGui::CalcTextSize(path[i]);
        float itemW = ts.x + 14.0f;
        ImVec2 p0 = ImVec2(pos.x + xOff, pos.y);
        ImVec2 p1 = ImVec2(p0.x + itemW, p0.y + itemH);
        bool hovered = (mouse.x >= p0.x && mouse.x <= p1.x && mouse.y >= p0.y && mouse.y <= p1.y);
        bool isLast = (i == depth - 1);
        if (hovered && !isLast)
        {
            float hovW = ImGui::CalcTextSize(path[i]).x + 14.0f;
            dl->AddRectFilled(p0, p1, C(ImColor(255,255,255,12)), 4.0f);
        }
        if (hovered && io.MouseClicked[0] && !isLast)
        {
            result = i;
            if (clickTarget) *clickTarget = i;
        }
        ImU32 col;
        if (isLast) col = C(accent);
        else if (hovered) col = C(ImColor(230,230,240));
        else col = C(ImColor(140,140,155));
        dl->AddText(ImGui::GetFont(), 12.0f, ImVec2(p0.x + 7.0f, p0.y + (itemH - ts.y) * 0.5f), col, path[i]);
        xOff += itemW;
        if (i < depth - 1)
        {
            float sepW = ImGui::CalcTextSize(">").x + 8.0f;
            ImVec2 sepPos = ImVec2(pos.x + xOff, pos.y + (itemH - ImGui::CalcTextSize(">").y) * 0.5f);
            dl->AddText(ImGui::GetFont(), 12.0f, sepPos, C(ImColor(80,80,95)), ">");
            xOff += sepW;
        }
    }
    float totalW = xOff;
    if (depth > 3)
    {
        char rootPath[64];
        snprintf(rootPath, sizeof(rootPath), "%s/.../%s", path[0], path[depth-1]);
        ImVec2 rts = ImGui::CalcTextSize(rootPath);
        if (rts.x < totalW - 20.0f)
        {
            ImGui::SetCursorScreenPos(ImVec2(pos.x, pos.y + itemH + 6.0f));
            return result;
        }
    }
    ImGui::SetCursorScreenPos(ImVec2(pos.x, pos.y + itemH + 6.0f));
    return result;
}

int M_StepIndicator(const char* label, int currentStep, const char** steps, int count, ImColor accent)
{
    ImDrawList* dl = ImGui::GetOverlayDrawList();
    ImGuiIO& io = ImGui::GetIO();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float dotR = 16.0f;
    float labelGap = 50.0f;
    float totalW = count * dotR * 2.0f + (count - 1) * labelGap;
    float startX = pos.x;
    int result = currentStep;
    float highestLabel = 0.0f;
    for (int i = 0; i < count; ++i)
    {
        ImVec2 ls = ImGui::CalcTextSize(steps[i]);
        if (ls.y > highestLabel) highestLabel = ls.y;
    }
    float totalH = dotR * 2.0f + highestLabel + 12.0f;
    ImVec2 startPos = pos;
    for (int i = 0; i < count; ++i)
    {
        float cx = startX + i * (dotR * 2.0f + labelGap) + dotR;
        float cy = startPos.y + dotR;
        bool completed = (i < currentStep);
        bool active = (i == currentStep);
        bool future = (i > currentStep);
        float pulse = 1.0f;
        if (active) pulse = sinf(io.Time * 3.5f) * 0.12f + 0.88f;
        ImU32 dotCol;
        ImU32 ringCol;
        if (completed)
        {
            dotCol = C(accent);
            ringCol = C(ImColor(accent.Value.x + 0.2f, accent.Value.y + 0.2f, accent.Value.z + 0.2f, 0.4f));
        }
        else if (active)
        {
            float r = accent.Value.x * pulse;
            float g = accent.Value.y * pulse;
            float b = accent.Value.z * pulse;
            dotCol = ImGui::ColorConvertFloat4ToU32(ImVec4(r, g, b, 1.0f));
            ringCol = C(ImColor(90,90,110));
        }
        else
        {
            dotCol = C(ImColor(45,45,55));
            ringCol = C(ImColor(60,60,75));
        }
        dl->AddCircleFilled(ImVec2(cx, cy), dotR + 3.0f, C(ImColor(25,25,35)), 32);
        dl->AddCircleFilled(ImVec2(cx, cy), dotR, dotCol, 32);
        dl->AddCircle(ImVec2(cx, cy), dotR, ringCol, 32, completed ? 2.5f : 1.5f);
        if (active)
        {
            ImColor glow = accent;
            glow.Value.w = 0.2f * pulse;
            dl->AddCircle(ImVec2(cx, cy), dotR + 6.0f, C(glow), 32, 3.0f);
            ImColor glow2 = accent;
            glow2.Value.w = 0.1f * pulse;
            dl->AddCircle(ImVec2(cx, cy), dotR + 10.0f, C(glow2), 32, 2.0f);
        }
        char num[4];
        snprintf(num, sizeof(num), "%d", i + 1);
        char mark[4];
        if (completed) { snprintf(mark, sizeof(mark), "%s", "✓"); }
        else { snprintf(mark, sizeof(mark), "%s", num); }
        ImVec2 ns = ImGui::CalcTextSize(mark);
        dl->AddText(ImGui::GetFont(), completed ? 14.0f : 12.0f, ImVec2(cx - ns.x * 0.5f, cy - ns.y * 0.5f), C(completed ? ImColor(255,255,255) : ImColor(170,170,185)), mark);
        if (i < count - 1)
        {
            float nx = startX + (i + 1) * (dotR * 2.0f + labelGap) + dotR;
            ImU32 lineCol = C(ImColor(42,42,52));
            dl->AddLine(ImVec2(cx + dotR + 3.0f, cy), ImVec2(nx - dotR - 3.0f, cy), lineCol, 3.0f);
            if (completed)
                dl->AddLine(ImVec2(cx + dotR + 3.0f, cy), ImVec2(nx - dotR - 3.0f, cy), C(accent), 3.0f);
            if (i == currentStep - 1 && currentStep < count)
            {
                float frac = fmodf(io.Time * 2.0f, 1.0f);
                float animX = cx + dotR + 3.0f + (nx - cx - dotR * 2.0f - 6.0f) * frac;
                dl->AddCircleFilled(ImVec2(animX, cy), 4.0f, C(accent), 16);
            }
        }
        ImVec2 ts = ImGui::CalcTextSize(steps[i]);
        dl->AddText(ImGui::GetFont(), 11.0f, ImVec2(cx - ts.x * 0.5f, cy + dotR + 8.0f), C(active ? ImColor(220,220,230) : ImColor(110,110,125)), steps[i]);
    }
    ImGui::SetCursorScreenPos(ImVec2(startPos.x, startPos.y + totalH + 8.0f));
    return result;
}

void M_FilterChips(const char* label, bool* active, int count, const char** names, ImColor accent)
{
    ImDrawList* dl = ImGui::GetOverlayDrawList();
    ImGuiIO& io = ImGui::GetIO();
    static std::map<const char*, struct { float scrollX; float scrollTarget; float animScroll; }> s_state;
    auto& st = s_state[label];
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float chipH = 32.0f;
    float gap = 8.0f;
    float totalW = 0.0f;
    float* chipW = (float*)alloca(count * sizeof(float));
    int activeCount = 0;
    for (int i = 0; i < count; ++i)
    {
        float tw = ImGui::CalcTextSize(names[i]).x;
        chipW[i] = tw + 24.0f + (active[i] ? 20.0f : 0.0f);
        totalW += chipW[i] + gap;
        if (active[i]) activeCount++;
    }
    float availW = ImGui::GetContentRegionAvail().x;
    float maxScroll = ImMax(0.0f, totalW - availW);
    ImRect scrollArea(pos, ImVec2(pos.x + availW, pos.y + chipH));
    bool hoverScroll = io.MousePos.x >= scrollArea.Min.x && io.MousePos.x <= scrollArea.Max.x && io.MousePos.y >= scrollArea.Min.y && io.MousePos.y <= scrollArea.Max.y;
    if (hoverScroll && io.MouseWheel != 0.0f)
        st.scrollTarget = ImClamp(st.scrollX - io.MouseWheel * 35.0f, 0.0f, maxScroll);
    st.scrollX += (st.scrollTarget - st.scrollX) * ImClamp(io.DeltaTime * 12.0f, 0.0f, 1.0f);
    st.scrollX = ImClamp(st.scrollX, 0.0f, maxScroll);
    if (maxScroll > 0)
    {
        bool leftHover = hoverScroll && io.MousePos.x < scrollArea.Min.x + 20.0f;
        bool rightHover = hoverScroll && io.MousePos.x > scrollArea.Max.x - 20.0f;
        if (leftHover) st.scrollTarget = ImMax(0.0f, st.scrollTarget - 200.0f * io.DeltaTime);
        if (rightHover) st.scrollTarget = ImMin(maxScroll, st.scrollTarget + 200.0f * io.DeltaTime);
    }
    dl->PushClipRect(scrollArea.Min, scrollArea.Max, true);
    float xOff = -st.scrollX;
    for (int i = 0; i < count; ++i)
    {
        ImVec2 p0 = ImVec2(pos.x + xOff, pos.y);
        ImVec2 p1 = ImVec2(p0.x + chipW[i], p0.y + chipH);
        bool hovered = hoverScroll && io.MousePos.x >= p0.x && io.MousePos.x <= p1.x && io.MousePos.y >= p0.y && io.MousePos.y <= p1.y;
        bool isActive = active[i];
        ImU32 bg;
        float r = chipH * 0.5f;
        if (isActive) bg = C(accent);
        else if (hovered) bg = C(ImColor(55,55,70));
        else bg = C(ImColor(38,38,48));
        dl->AddRectFilled(p0, p1, bg, r);
        if (!isActive) dl->AddRect(p0, p1, C(ImColor(58,58,72)), r);
        else dl->AddRect(p0, p1, C(ImColor(255,255,255,25)), r);
        ImU32 textCol = isActive ? C(ImColor(255,255,255)) : C(ImColor(200,200,215));
        ImVec2 ts = ImGui::CalcTextSize(names[i]);
        float textX = p0.x + 12.0f;
        dl->AddText(ImGui::GetFont(), 12.0f, ImVec2(textX, p0.y + (chipH - ts.y) * 0.5f), textCol, names[i]);
        if (isActive)
        {
            float cx = p0.x + chipW[i] - 14.0f;
            float cy = p0.y + chipH * 0.5f;
            bool closeHover = hovered && fabsf(io.MousePos.x - cx) < 8.0f && fabsf(io.MousePos.y - cy) < 8.0f;
            ImU32 xCol = closeHover ? C(ImColor(255,255,255)) : C(ImColor(255,255,255,140));
            dl->AddCircleFilled(ImVec2(cx, cy), 6.0f, closeHover ? C(ImColor(255,80,80,60)) : C(ImColor(0,0,0,0)));
            dl->AddText(ImGui::GetFont(), 10.0f, ImVec2(cx - 4.0f, cy - 6.0f), xCol, "x");
        }
        if (hovered && io.MouseClicked[0])
        {
            if (isActive)
            {
                float cx = p0.x + chipW[i] - 14.0f;
                if (fabsf(io.MousePos.x - cx) < 10.0f) active[i] = false;
                else active[i] = false;
            }
            else
            {
                active[i] = true;
            }
        }
        xOff += chipW[i] + gap;
    }
    dl->PopClipRect();
    if (maxScroll > 0)
    {
        if (st.scrollX > 5.0f)
            dl->AddRectFilled(ImVec2(scrollArea.Min.x, scrollArea.Min.y), ImVec2(scrollArea.Min.x + 8.0f, scrollArea.Max.y), C(ImColor(0,0,0,60)), 4.0f);
        if (st.scrollX < maxScroll - 5.0f)
            dl->AddRectFilled(ImVec2(scrollArea.Max.x - 8.0f, scrollArea.Min.y), ImVec2(scrollArea.Max.x, scrollArea.Max.y), C(ImColor(0,0,0,60)), 4.0f);
    }
    char acStr[32];
    snprintf(acStr, sizeof(acStr), "%d/%d active", activeCount, count);
    ImVec2 acs = ImGui::CalcTextSize(acStr);
    dl->AddText(ImGui::GetFont(), 9.0f, ImVec2(scrollArea.Max.x - acs.x, scrollArea.Max.y + 4.0f), C(ImColor(90,90,105)), acStr);
    ImGui::SetCursorScreenPos(ImVec2(pos.x, pos.y + chipH + 22.0f));
}

void M_NavRail(const char* label, int active, const char** items, int count, ImVec2 pos, float width, float itemHeight, ImColor accent)
{
    ImDrawList* dl = ImGui::GetOverlayDrawList();
    ImGuiIO& io = ImGui::GetIO();
    ImVec2 mouse = io.MousePos;
    int result = active;
    for (int i = 0; i < count; ++i)
    {
        ImVec2 p0 = ImVec2(pos.x, pos.y + i * itemHeight);
        ImVec2 p1 = ImVec2(pos.x + width, p0.y + itemHeight);
        bool hovered = mouse.x >= p0.x && mouse.x <= p1.x && mouse.y >= p0.y && mouse.y <= p1.y;
        bool act = (i == active);
        ImU32 bg = act ? C(accent) : C(ImColor(hovered ? 50 : 35, hovered ? 50 : 35, hovered ? 60 : 45));
        ImU32 col = act ? C(ImColor(255,255,255)) : C(ImColor(hovered ? 200 : 140, hovered ? 200 : 140, hovered ? 210 : 150));
        dl->AddRectFilled(p0, p1, bg);
        if (act)
            dl->AddRectFilled(ImVec2(pos.x, p0.y), ImVec2(pos.x + 3.0f, p1.y), C(accent));
        ImVec2 ts = ImGui::CalcTextSize(items[i]);
        dl->AddText(ImGui::GetFont(), 13.0f, ImVec2(p0.x + width * 0.5f - ts.x * 0.5f, p0.y + itemHeight * 0.5f - ts.y * 0.5f), col, items[i]);
        if (hovered && io.MouseClicked[0]) result = i;
    }
    float totalH = count * itemHeight;
    ImGui::SetCursorScreenPos(ImVec2(pos.x, pos.y + totalH + 4.0f));
}

int M_SegmentedControl(const char* label, int active, const char** segments, int count, ImColor accent)
{
    ImDrawList* dl = ImGui::GetOverlayDrawList();
    ImGuiIO& io = ImGui::GetIO();
    ImVec2 mouse = io.MousePos;
    int result = active;
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float maxW = 0.0f;
    for (int i = 0; i < count; ++i)
    {
        float tw = ImGui::CalcTextSize(segments[i]).x;
        if (tw > maxW) maxW = tw;
    }
    float segW = maxW + 24.0f;
    float segH = 30.0f;
    float totalW = segW * count;
    for (int i = 0; i < count; ++i)
    {
        ImVec2 p0 = ImVec2(pos.x + i * segW, pos.y);
        ImVec2 p1 = ImVec2(p0.x + segW, p0.y + segH);
        bool hovered = mouse.x >= p0.x && mouse.x <= p1.x && mouse.y >= p0.y && mouse.y <= p1.y;
        bool act = (i == active);
        ImU32 bg = act ? C(accent) : C(ImColor(hovered ? 50 : 38, hovered ? 50 : 38, hovered ? 60 : 48));
        ImU32 col = act ? C(ImColor(255,255,255)) : C(ImColor(180,180,195));
        dl->AddRectFilled(p0, p1, bg);
        dl->AddRect(p0, p1, C(ImColor(55,55,68)));
        ImVec2 ts = ImGui::CalcTextSize(segments[i]);
        dl->AddText(ImGui::GetFont(), 12.0f, ImVec2(p0.x + segW * 0.5f - ts.x * 0.5f, p0.y + segH * 0.5f - ts.y * 0.5f), col, segments[i]);
        if (hovered && io.MouseClicked[0]) result = i;
    }
    ImGui::SetCursorScreenPos(ImVec2(pos.x, pos.y + segH + 4.0f));
    return result;
}
