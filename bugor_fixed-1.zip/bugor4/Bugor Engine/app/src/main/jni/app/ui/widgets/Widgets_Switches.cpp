#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "../../../../imgui/imgui.h"
#include "../../../../imgui/imgui_internal.h"
#include "../../../../imgui/mycustom/imgui_Custom.h"

#include <map>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <cstdlib>

static ImU32 CToU32(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }

static float lerpf(float a, float b, float t) { return a + (b - a) * ImClamp(t, 0.0f, 1.0f); }
static float clamp01f(float v) { return v < 0.0f ? 0.0f : (v > 1.0f ? 1.0f : v); }
static float easeInOutQuad(float t) { return t < 0.5f ? 2.0f * t * t : 1.0f - powf(-2.0f * t + 2.0f, 2.0f) * 0.5f; }
static float easeOutBack(float t) { float c1 = 1.70158f; float c3 = c1 + 1.0f; return 1.0f + c3 * powf(t - 1.0f, 3.0f) + c1 * powf(t - 1.0f, 2.0f); }

bool M_ModernSwitch(const char* label, bool* value, ImColor accent) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImVec2 winSize = ImGui::GetContentRegionAvail();
    float rowHeight = 60.0f;
    float trackW = 44.0f;
    float trackH = 24.0f;
    float knobR = 10.0f;
    float trackRadius = trackH * 0.5f;
    float textW = ImGui::CalcTextSize(label).x;
    float textH = ImGui::CalcTextSize(label).y;
    float trackX = pos.x + winSize.x - trackW - 4.0f;
    float trackY = pos.y + (rowHeight - trackH) * 0.5f;
    float knobCY = trackY + trackH * 0.5f;
    float trackCX = trackX + trackW * 0.5f;
    float trackCY = trackY + trackH * 0.5f;
    float labelX = pos.x + 8.0f;
    float labelY = pos.y + (rowHeight - textH) * 0.5f;
    ImRect hitRect(pos, ImVec2(pos.x + winSize.x, pos.y + rowHeight));
    bool hovered = ImGui::IsMouseHoveringRect(hitRect.Min, hitRect.Max);
    bool clicked = false;
    if (hovered && ImGui::IsMouseClicked(0)) {
        *value = !*value;
        clicked = true;
    }
    static std::map<const char*, ImGui::AnimFloat> animMap;
    static std::map<const char*, ImGui::AnimFloat> hoverAnimMap;
    auto it = animMap.find(label);
    if (it == animMap.end()) {
        it = animMap.emplace(label, ImGui::AnimFloat(*value ? 1.0f : 0.0f, 8.0f)).first;
    }
    auto hit = hoverAnimMap.find(label);
    if (hit == hoverAnimMap.end()) {
        hit = hoverAnimMap.emplace(label, ImGui::AnimFloat(0.0f, 6.0f)).first;
    }
    hit->second.SetTarget(hovered ? 1.0f : 0.0f);
    hit->second.Update();
    float hoverT = hit->second.Get();
    ImGui::AnimFloat& anim = it->second;
    anim.SetTarget(*value ? 1.0f : 0.0f);
    anim.Update();
    float t = anim.Get();
    float easeT = t * t * (3.0f - 2.0f * t);
    float knobOffset = easeT * (trackW - knobR * 2.0f);
    float kx = trackX + knobR + knobOffset;
    float trackOffR = 50.0f; float trackOffG = 50.0f; float trackOffB = 60.0f;
    float trackOnR = accent.Value.x; float trackOnG = accent.Value.y; float trackOnB = accent.Value.z;
    float curTrackR = trackOffR + (trackOnR - trackOffR) * t;
    float curTrackG = trackOffG + (trackOnG - trackOffG) * t;
    float curTrackB = trackOffB + (trackOnB - trackOffB) * t;
    float hr = curTrackR + 18.0f * hoverT; if (hr > 255.0f) hr = 255.0f;
    float hg = curTrackG + 18.0f * hoverT; if (hg > 255.0f) hg = 255.0f;
    float hb = curTrackB + 18.0f * hoverT; if (hb > 255.0f) hb = 255.0f;
    ImColor trackCol((int)curTrackR, (int)curTrackG, (int)curTrackB, 255);
    ImColor trackHov((int)hr, (int)hg, (int)hb, 255);
    ImColor trackDraw = hoverT > 0.01f ? trackHov : trackCol;
    ImColor trackShadow(0, 0, 0, 60);
    dl->AddRectFilled(ImVec2(trackX, trackY + 2.0f), ImVec2(trackX + trackW, trackY + trackH + 2.0f), CToU32(trackShadow), trackRadius);
    dl->AddRectFilled(ImVec2(trackX, trackY), ImVec2(trackX + trackW, trackY + trackH), CToU32(trackDraw), trackRadius);
    ImColor trackInner(0, 0, 0, 25);
    dl->AddRectFilled(ImVec2(trackX + 2, trackY + 2), ImVec2(trackX + trackW - 2, trackY + trackH - 2), CToU32(trackInner), trackRadius - 2);
    ImColor accentGlow = ImColor((int)trackOnR, (int)trackOnG, (int)trackOnB, (int)(55 * t));
    dl->AddRectFilled(ImVec2(trackX + 2, trackY + 2), ImVec2(trackX + trackW - 2, trackY + trackH - 2), CToU32(accentGlow), trackRadius - 2);
    ImColor trackBorder(255, 255, 255, (int)(10 + 15 * t + 10 * hoverT));
    dl->AddRect(ImVec2(trackX + 1, trackY + 1), ImVec2(trackX + trackW - 1, trackY + trackH - 1), CToU32(trackBorder), trackRadius, ImDrawFlags_RoundCornersAll, 0.5f);
    float glowBaseR = knobR + 4.0f;
    for (int i = 0; i < 5; i++) {
        float layerR = glowBaseR + i * 3.5f;
        float layerA = (0.22f - i * 0.035f) * t;
        if (layerA > 0.005f) {
            ImColor glowCol = ImColor((int)trackOnR, (int)trackOnG, (int)trackOnB, (int)(layerA * 255));
            dl->AddCircleFilled(ImVec2(kx, knobCY), layerR, CToU32(glowCol));
        }
    }
    ImColor knobShadow2(0, 0, 0, (int)(40 + t * 30 + hoverT * 10));
    dl->AddCircleFilled(ImVec2(kx + 1.0f, knobCY + 1.5f), knobR + 0.5f, CToU32(knobShadow2));
    float knobBright = 245.0f + 10.0f * hoverT;
    ImColor knobCol((int)knobBright, (int)knobBright, 255);
    if (t > 0.5f) { knobCol = ImColor(255, 255, 255); }
    dl->AddCircleFilled(ImVec2(kx, knobCY), knobR, CToU32(knobCol));
    ImColor knobEdge(0, 0, 0, 30);
    dl->AddCircle(ImVec2(kx, knobCY), knobR, CToU32(knobEdge), 0, 1.0f);
    ImColor knobHighlight(255, 255, 255, 140);
    dl->AddCircleFilled(ImVec2(kx - 2.5f, knobCY - 2.5f), knobR * 0.4f, CToU32(knobHighlight));
    ImColor knobArc(255, 255, 255, 60);
    dl->AddArc(ImVec2(kx - 1.0f, knobCY - 1.0f), knobR * 0.7f, IM_PI * 0.1f, IM_PI * 0.9f, CToU32(knobArc), 1.5f);
    ImColor knobMid(0, 0, 0, 15);
    dl->AddCircleFilled(ImVec2(kx, knobCY), knobR * 0.5f, CToU32(knobMid));
    ImColor knobBottomGlow = ImColor((int)trackOnR, (int)trackOnG, (int)trackOnB, (int)(20 * t));
    dl->AddCircleFilled(ImVec2(kx, knobCY + 2), knobR * 0.6f, CToU32(knobBottomGlow));
    ImColor knobTrackGlow = ImColor((int)trackOnR, (int)trackOnG, (int)trackOnB, (int)(15 * t * hoverT));
    dl->AddCircleFilled(ImVec2(kx, knobCY), knobR + 3.0f, CToU32(knobTrackGlow));
    ImColor knobCenterDot = ImColor(255, 255, 255, (int)(80 * t));
    dl->AddCircleFilled(ImVec2(kx, knobCY), knobR * 0.2f, CToU32(knobCenterDot));
    ImColor labelCol(180, 180, 200);
    if (hoverT > 0.01f) labelCol = ImColor(225, 225, 245);
    if (*value) labelCol = ImColor(210, 210, 240);
    dl->AddText(ImVec2(labelX, labelY), CToU32(labelCol), label);
    if (hoverT > 0.01f) {
        ImColor labelBg(255, 255, 255, (int)(6 * hoverT));
        dl->AddRectFilled(ImVec2(pos.x, pos.y), ImVec2(pos.x + winSize.x, pos.y + rowHeight), CToU32(labelBg), 4.0f);
    }
    ImColor labelShadow(0, 0, 0, 30);
    dl->AddText(ImVec2(labelX + 0.5f, labelY + 0.5f), CToU32(labelShadow), label);
    dl->AddText(ImVec2(labelX, labelY), CToU32(labelCol), label);
    ImVec2 tSize = ImGui::CalcTextSize(label);
    float tCX = labelX + tSize.x * 0.5f;
    float tCY = labelY + tSize.y * 0.5f;
    float labelGlowR = tSize.x * 0.5f + 8.0f;
    if (t > 0.1f) {
        ImColor labelGlow = ImColor((int)trackOnR, (int)trackOnG, (int)trackOnB, (int)(6 * t));
        dl->AddCircleFilled(ImVec2(tCX, tCY), labelGlowR, CToU32(labelGlow));
    }
    if (t > 0.5f && hoverT > 0.5f) {
        ImColor accentLabelBg = ImColor((int)trackOnR, (int)trackOnG, (int)trackOnB, (int)(8 * t * hoverT));
        dl->AddRectFilled(ImVec2(labelX - 4, labelY - 2), ImVec2(labelX + tSize.x + 4, labelY + tSize.y + 2), CToU32(accentLabelBg), 4.0f);
    }
    ImGui::SetCursorScreenPos(ImVec2(pos.x, pos.y + rowHeight));
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + rowHeight);
    return clicked;
}

bool M_ClassicToggle(const char* label, bool* value, ImColor accent) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImVec2 winSize = ImGui::GetContentRegionAvail();
    float rowHeight = 48.0f;
    float trackW = 36.0f;
    float trackH = 20.0f;
    float knobR = 8.0f;
    float trackRadius = trackH * 0.5f;
    float textW = ImGui::CalcTextSize(label).x;
    float textH = ImGui::CalcTextSize(label).y;
    float trackX = pos.x + winSize.x - trackW - 4.0f;
    float trackY = pos.y + (rowHeight - trackH) * 0.5f;
    float knobCY = trackY + trackH * 0.5f;
    float trackCX = trackX + trackW * 0.5f;
    float trackCY = trackY + trackH * 0.5f;
    float labelX = pos.x + 8.0f;
    float labelY = pos.y + (rowHeight - textH) * 0.5f;
    ImRect hitRect(pos, ImVec2(pos.x + winSize.x, pos.y + rowHeight));
    bool hovered = ImGui::IsMouseHoveringRect(hitRect.Min, hitRect.Max);
    bool clicked = false;
    if (hovered && ImGui::IsMouseClicked(0)) {
        *value = !*value;
        clicked = true;
    }
    static std::map<const char*, ImGui::AnimFloat> animMap;
    static std::map<const char*, ImGui::AnimFloat> hoverAnimMap;
    auto it = animMap.find(label);
    if (it == animMap.end()) {
        it = animMap.emplace(label, ImGui::AnimFloat(*value ? 1.0f : 0.0f, 8.0f)).first;
    }
    auto hit = hoverAnimMap.find(label);
    if (hit == hoverAnimMap.end()) {
        hit = hoverAnimMap.emplace(label, ImGui::AnimFloat(0.0f, 6.0f)).first;
    }
    hit->second.SetTarget(hovered ? 1.0f : 0.0f);
    hit->second.Update();
    float hoverT = hit->second.Get();
    ImGui::AnimFloat& anim = it->second;
    anim.SetTarget(*value ? 1.0f : 0.0f);
    anim.Update();
    float t = anim.Get();
    float easeT = t * (2.0f - t);
    float knobOffset = easeT * (trackW - knobR * 2.0f);
    float kx = trackX + knobR + knobOffset;
    float bgOffR = 55.0f; float bgOffG = 55.0f; float bgOffB = 65.0f;
    float bgOnR = accent.Value.x; float bgOnG = accent.Value.y; float bgOnB = accent.Value.z;
    float bgR = bgOffR + (bgOnR - bgOffR) * t;
    float bgG = bgOffG + (bgOnG - bgOffG) * t;
    float bgB = bgOffB + (bgOnB - bgOffB) * t;
    float bghR = bgR + 14.0f * hoverT; if (bghR > 255.0f) bghR = 255.0f;
    float bghG = bgG + 14.0f * hoverT; if (bghG > 255.0f) bghG = 255.0f;
    float bghB = bgB + 14.0f * hoverT; if (bghB > 255.0f) bghB = 255.0f;
    ImColor bgCol((int)bgR, (int)bgG, (int)bgB, 255);
    ImColor bgHov((int)bghR, (int)bghG, (int)bghB, 255);
    ImColor bgDraw = hoverT > 0.01f ? bgHov : bgCol;
    ImColor shadowCol(0, 0, 0, 45);
    dl->AddRectFilled(ImVec2(trackX, trackY + 1.5f), ImVec2(trackX + trackW, trackY + trackH + 1.5f), CToU32(shadowCol), trackRadius);
    dl->AddRectFilled(ImVec2(trackX, trackY), ImVec2(trackX + trackW, trackY + trackH), CToU32(bgDraw), trackRadius);
    ImColor innerShadow(0, 0, 0, 35);
    dl->AddRectFilled(ImVec2(trackX + 1.5f, trackY + 1.5f), ImVec2(trackX + trackW - 1.5f, trackY + trackH - 1.5f), CToU32(innerShadow), trackRadius - 1);
    ImColor topGlow(255, 255, 255, 12);
    dl->AddRectFilled(ImVec2(trackX + 2, trackY + 1), ImVec2(trackX + trackW - 2, trackY + trackH * 0.35f), CToU32(topGlow), trackRadius - 2);
    ImColor knobShadow2(0, 0, 0, 55);
    dl->AddCircleFilled(ImVec2(kx + 1.0f, knobCY + 1.0f), knobR, CToU32(knobShadow2));
    float knobBright = 235.0f + 15.0f * hoverT;
    ImColor knobColor((int)knobBright, (int)knobBright, 250);
    dl->AddCircleFilled(ImVec2(kx, knobCY), knobR, CToU32(knobColor));
    ImColor arcShadow(0, 0, 0, 70);
    dl->AddArc(ImVec2(kx - 1.0f, knobCY - 1.0f), knobR - 0.5f, IM_PI * 0.5f, IM_PI * 1.8f, CToU32(arcShadow), 2.0f);
    ImColor knobShine(255, 255, 255, 110);
    dl->AddCircleFilled(ImVec2(kx - 2.0f, knobCY - 2.5f), knobR * 0.3f, CToU32(knobShine));
    ImColor knobDeep(0, 0, 0, 25);
    dl->AddCircleFilled(ImVec2(kx + 0.5f, knobCY + 0.5f), knobR * 0.6f, CToU32(knobDeep));
    dl->AddCircleFilled(ImVec2(kx, knobCY), knobR - 0.5f, CToU32(knobColor));
    ImColor knobRim(255, 255, 255, 40);
    dl->AddCircle(ImVec2(kx - 0.5f, knobCY - 0.5f), knobR - 1.0f, CToU32(knobRim), 0, 0.5f);
    ImColor trackRim(255, 255, 255, (int)(8 + 8 * hoverT));
    dl->AddRect(ImVec2(trackX, trackY), ImVec2(trackX + trackW, trackY + trackH), CToU32(trackRim), trackRadius, ImDrawFlags_RoundCornersAll, 0.5f);
    ImColor labelCol(175, 175, 195);
    if (hoverT > 0.01f) labelCol = ImColor(215, 215, 235);
    if (*value) labelCol = ImColor(220, 220, 245);
    dl->AddText(ImVec2(labelX, labelY), CToU32(labelCol), label);
    ImColor labelShadow(0, 0, 0, 25);
    dl->AddText(ImVec2(labelX + 0.5f, labelY + 0.5f), CToU32(labelShadow), label);
    dl->AddText(ImVec2(labelX, labelY), CToU32(labelCol), label);
    if (hoverT > 0.01f) {
        ImColor rowGlow(255, 255, 255, (int)(5 * hoverT));
        dl->AddRectFilled(ImVec2(pos.x, pos.y), ImVec2(pos.x + winSize.x, pos.y + rowHeight), CToU32(rowGlow), 3.0f);
    }
    ImGui::SetCursorScreenPos(ImVec2(pos.x, pos.y + rowHeight));
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + rowHeight);
    return clicked;
}

bool M_FancyCheckbox(const char* label, bool* value, ImColor accent) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImVec2 winSize = ImGui::GetContentRegionAvail();
    float rowHeight = 44.0f;
    float boxSize = 22.0f;
    float rounding = 4.0f;
    float halfBox = boxSize * 0.5f;
    float textH = ImGui::CalcTextSize(label).y;
    float boxX = pos.x + 4.0f;
    float boxY = pos.y + (rowHeight - boxSize) * 0.5f;
    float boxCX = boxX + halfBox;
    float boxCY = boxY + halfBox;
    float labelX = boxX + boxSize + 10.0f;
    ImRect hitRect(pos, ImVec2(pos.x + winSize.x, pos.y + rowHeight));
    bool hovered = ImGui::IsMouseHoveringRect(hitRect.Min, hitRect.Max);
    bool clicked = false;
    if (hovered && ImGui::IsMouseClicked(0)) {
        *value = !*value;
        clicked = true;
    }
    static std::map<const char*, ImGui::AnimFloat> fillAnimMap;
    static std::map<const char*, ImGui::AnimFloat> checkAnimMap;
    static std::map<const char*, ImGui::AnimFloat> rippleAnimMap;
    auto fillIt = fillAnimMap.find(label);
    if (fillIt == fillAnimMap.end()) {
        fillIt = fillAnimMap.emplace(label, ImGui::AnimFloat(*value ? 1.0f : 0.0f, 7.0f)).first;
    }
    auto checkIt = checkAnimMap.find(label);
    if (checkIt == checkAnimMap.end()) {
        checkIt = checkAnimMap.emplace(label, ImGui::AnimFloat(*value ? 1.0f : 0.0f, 8.0f)).first;
    }
    auto rippleIt = rippleAnimMap.find(label);
    if (rippleIt == rippleAnimMap.end()) {
        rippleIt = rippleAnimMap.emplace(label, ImGui::AnimFloat(0.0f, 5.0f)).first;
    }
    if (clicked) {
        rippleIt->second.Set(0.0f);
        rippleIt->second.SetTarget(1.0f);
    }
    ImGui::AnimFloat& fillAnim = fillIt->second;
    ImGui::AnimFloat& checkAnim = checkIt->second;
    ImGui::AnimFloat& rippleAnim = rippleIt->second;
    fillAnim.SetTarget(*value ? 1.0f : 0.0f);
    checkAnim.SetTarget(*value ? 1.0f : 0.0f);
    fillAnim.Update();
    checkAnim.Update();
    rippleAnim.Update();
    float fillT = fillAnim.Get();
    float checkT = checkAnim.Get();
    float rippleT = rippleAnim.Get();
    float fillEase = fillT * fillT * (3.0f - 2.0f * fillT);
    ImColor borderCol(100, 100, 120);
    if (hovered) borderCol = ImColor(145, 145, 175);
    if (fillEase > 0.01f) {
        float fr = accent.Value.x * fillEase + borderCol.Value.x * (1.0f - fillEase);
        float fg = accent.Value.y * fillEase + borderCol.Value.y * (1.0f - fillEase);
        float fb = accent.Value.z * fillEase + borderCol.Value.z * (1.0f - fillEase);
        ImColor fillCol((int)fr, (int)fg, (int)fb, 255);
        dl->AddRectFilled(ImVec2(boxX, boxY), ImVec2(boxX + boxSize, boxY + boxSize), CToU32(fillCol), rounding);
        ImColor fillShine = ImColor(255, 255, 255, 40);
        dl->AddRectFilled(ImVec2(boxX + 1, boxY + 1), ImVec2(boxX + boxSize - 1, boxY + boxSize * 0.4f), CToU32(fillShine), rounding - 1);
        ImColor fillBorder2 = ImColor(255, 255, 255, 30);
        dl->AddRect(ImVec2(boxX, boxY), ImVec2(boxX + boxSize, boxY + boxSize), CToU32(fillBorder2), rounding, ImDrawFlags_RoundCornersAll, 0.5f);
    } else {
        dl->AddRect(ImVec2(boxX, boxY), ImVec2(boxX + boxSize, boxY + boxSize), CToU32(borderCol), rounding, ImDrawFlags_RoundCornersAll, 1.5f);
        ImColor bgFill(35, 35, 45);
        dl->AddRectFilled(ImVec2(boxX + 1.5f, boxY + 1.5f), ImVec2(boxX + boxSize - 1.5f, boxY + boxSize - 1.5f), CToU32(bgFill), rounding - 1);
        ImColor innerBorder(0, 0, 0, 30);
        dl->AddRect(ImVec2(boxX + 1, boxY + 1), ImVec2(boxX + boxSize - 1, boxY + boxSize - 1), CToU32(innerBorder), rounding - 1, ImDrawFlags_RoundCornersAll, 0.5f);
    }
    if (fillEase > 0.4f || *value) {
        float checkProgress = checkT;
        if (checkProgress > 0.01f) {
            float cx = boxX + boxSize * 0.22f;
            float cy = boxY + boxSize * 0.42f;
            float cw = boxSize * 0.18f;
            float ch = boxSize * 0.28f;
            float ex = boxX + boxSize * 0.72f;
            float ey = boxY + boxSize * 0.72f;
            ImVec2 p1(cx, cy + ch);
            ImVec2 p2(cx + cw, cy + ch + ch);
            ImVec2 p3(ex, ey);
            float dx1 = p2.x - p1.x;
            float dy1 = p2.y - p1.y;
            float dx2 = p3.x - p2.x;
            float dy2 = p3.y - p2.y;
            float len1 = sqrtf(dx1 * dx1 + dy1 * dy1);
            float len2 = sqrtf(dx2 * dx2 + dy2 * dy2);
            float totalLen = len1 + len2;
            float prog = clamp01f(checkProgress * 1.4f);
            float dist = prog * totalLen;
            float thick = 1.8f + checkProgress * 0.8f;
            ImColor checkCol(255, 255, 255);
            if (dist <= len1 && len1 > 0.01f) {
                float segT = dist / len1;
                ImVec2 ep(p1.x + dx1 * segT, p1.y + dy1 * segT);
                dl->AddLine(p1, ep, CToU32(checkCol), thick);
            } else if (dist > len1) {
                dl->AddLine(p1, p2, CToU32(checkCol), thick);
                float rem = dist - len1;
                float segT2 = len2 > 0.01f ? rem / len2 : 1.0f;
                ImVec2 ep2(p2.x + dx2 * segT2, p2.y + dy2 * segT2);
                dl->AddLine(p2, ep2, CToU32(checkCol), thick);
            }
            ImColor checkGlow = ImColor(255, 255, 255, (int)(60 * checkProgress));
            dl->AddLine(p1, p3, CToU32(checkGlow), thick * 0.3f);
        }
    }
    if (rippleT > 0.01f && rippleT < 1.0f) {
        float rippleMaxR = boxSize * 3.5f;
        float rippleR = rippleT * rippleMaxR;
        float rippleA = (1.0f - rippleT) * 0.30f;
        if (rippleA > 0.005f) {
            ImColor rippleCol = ImColor((int)accent.Value.x, (int)accent.Value.y, (int)accent.Value.z, (int)(rippleA * 255));
            dl->AddCircleFilled(ImVec2(boxCX, boxCY), rippleR, CToU32(rippleCol));
            ImColor rippleBorder = ImColor((int)accent.Value.x, (int)accent.Value.y, (int)accent.Value.z, (int)(rippleA * 180));
            dl->AddCircle(ImVec2(boxCX, boxCY), rippleR * 0.8f, CToU32(rippleBorder), 0, 1.5f);
            ImColor rippleInner = ImColor((int)accent.Value.x, (int)accent.Value.y, (int)accent.Value.z, (int)(rippleA * 100));
            dl->AddCircle(ImVec2(boxCX, boxCY), rippleR * 0.5f, CToU32(rippleInner), 0, 0.5f);
        }
    }
    ImColor labelCol(175, 175, 195);
    if (hovered) labelCol = ImColor(220, 220, 240);
    if (*value) labelCol = ImColor(215, 215, 245);
    dl->AddText(ImVec2(labelX, pos.y + (rowHeight - textH) * 0.5f), CToU32(labelCol), label);
    ImGui::SetCursorScreenPos(ImVec2(pos.x, pos.y + rowHeight));
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + rowHeight);
    return clicked;
}

bool M_RadioSelector(const char* label, bool active, ImColor accent) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImVec2 winSize = ImGui::GetContentRegionAvail();
    float rowHeight = 44.0f;
    float outerR = 10.0f;
    float innerR = 6.5f;
    float textH = ImGui::CalcTextSize(label).y;
    float circleX = pos.x + outerR + 6.0f;
    float circleY = pos.y + rowHeight * 0.5f;
    ImRect hitRect(pos, ImVec2(pos.x + winSize.x, pos.y + rowHeight));
    bool hovered = ImGui::IsMouseHoveringRect(hitRect.Min, hitRect.Max);
    bool clicked = false;
    if (hovered && ImGui::IsMouseClicked(0)) {
        clicked = true;
    }
    static std::map<const char*, ImGui::AnimFloat> scaleAnimMap;
    static std::map<const char*, ImGui::AnimFloat> pulseAnimMap;
    auto scaleIt = scaleAnimMap.find(label);
    if (scaleIt == scaleAnimMap.end()) {
        scaleIt = scaleAnimMap.emplace(label, ImGui::AnimFloat(active ? 1.0f : 0.0f, 8.0f)).first;
    }
    auto pulseIt = pulseAnimMap.find(label);
    if (pulseIt == pulseAnimMap.end()) {
        pulseIt = pulseAnimMap.emplace(label, ImGui::AnimFloat(0.0f, 4.0f)).first;
    }
    ImGui::AnimFloat& scaleAnim = scaleIt->second;
    ImGui::AnimFloat& pulseAnim = pulseIt->second;
    if (active) {
        scaleAnim.SetTarget(1.0f);
        pulseAnim.SetTarget(1.0f);
    } else {
        scaleAnim.SetTarget(0.0f);
        pulseAnim.SetTarget(0.0f);
    }
    scaleAnim.Update();
    pulseAnim.Update();
    float scaleT = scaleAnim.Get();
    float pulseT = pulseAnim.Get();
    float scaleEase = scaleT * (2.0f - scaleT);
    ImColor outerCol(100, 100, 120);
    if (hovered) outerCol = ImColor(140, 140, 170);
    if (active) outerCol = ImColor((int)accent.Value.x, (int)accent.Value.y, (int)accent.Value.z, 230);
    dl->AddCircle(ImVec2(circleX, circleY), outerR, CToU32(outerCol), 0, 2.0f);
    ImColor outerBg(35, 35, 45);
    dl->AddCircleFilled(ImVec2(circleX, circleY), outerR - 1.5f, CToU32(outerBg));
    ImColor outerGlow(255, 255, 255, 15);
    dl->AddCircle(ImVec2(circleX - 0.5f, circleY - 0.5f), outerR - 1.0f, CToU32(outerGlow), 0, 0.5f);
    if (scaleEase > 0.01f) {
        float fillR = innerR * scaleEase;
        if (fillR > 1.0f) {
            dl->AddCircleFilled(ImVec2(circleX, circleY), fillR, CToU32(accent));
            ImColor innerShine = ImColor(255, 255, 255, 70);
            dl->AddCircleFilled(ImVec2(circleX - 1.5f, circleY - 1.5f), fillR * 0.5f, CToU32(innerShine));
            ImColor innerDeep = ImColor(0, 0, 0, 30);
            dl->AddCircleFilled(ImVec2(circleX + 0.5f, circleY + 0.5f), fillR * 0.3f, CToU32(innerDeep));
        }
    }
    if (active && pulseT > 0.01f) {
        float pulseA = (1.0f - pulseT) * 0.25f;
        if (pulseA > 0.01f) {
            float pulseR1 = outerR + pulseT * 6.0f;
            ImColor pulseCol1 = ImColor((int)accent.Value.x, (int)accent.Value.y, (int)accent.Value.z, (int)(pulseA * 255));
            dl->AddCircle(ImVec2(circleX, circleY), pulseR1, CToU32(pulseCol1), 0, 1.5f);
            float pulseR2 = outerR + pulseT * 12.0f;
            float pulseA2 = pulseA * 0.5f;
            ImColor pulseCol2 = ImColor((int)accent.Value.x, (int)accent.Value.y, (int)accent.Value.z, (int)(pulseA2 * 255));
            dl->AddCircle(ImVec2(circleX, circleY), pulseR2, CToU32(pulseCol2), 0, 1.0f);
            float pulseR3 = outerR + pulseT * 18.0f;
            float pulseA3 = pulseA * 0.25f;
            ImColor pulseCol3 = ImColor((int)accent.Value.x, (int)accent.Value.y, (int)accent.Value.z, (int)(pulseA3 * 255));
            dl->AddCircle(ImVec2(circleX, circleY), pulseR3, CToU32(pulseCol3), 0, 0.5f);
        }
    }
    float textX = circleX + outerR + 14.0f;
    ImColor labelCol(175, 175, 195);
    if (hovered) labelCol = ImColor(215, 215, 235);
    if (active) labelCol = ImColor(220, 220, 245);
    dl->AddText(ImVec2(textX, pos.y + (rowHeight - textH) * 0.5f), CToU32(labelCol), label);
    if (hovered) {
        ImColor bgGlow(255, 255, 255, 5);
        dl->AddRectFilled(ImVec2(pos.x, pos.y), ImVec2(pos.x + winSize.x, pos.y + rowHeight), CToU32(bgGlow), 4.0f);
    }
    ImColor labelShadow(0, 0, 0, 20);
    dl->AddText(ImVec2(textX + 0.5f, pos.y + (rowHeight - textH) * 0.5f + 0.5f), CToU32(labelShadow), label);
    dl->AddText(ImVec2(textX, pos.y + (rowHeight - textH) * 0.5f), CToU32(labelCol), label);
    ImGui::SetCursorScreenPos(ImVec2(pos.x, pos.y + rowHeight));
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + rowHeight);
    return clicked;
}

int M_SegmentedToggle(const char* label, int* activeIndex, const char** options, int optionCount, ImColor accent) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImVec2 winSize = ImGui::GetContentRegionAvail();
    float height = 36.0f;
    float width = winSize.x;
    float segW = width / (float)optionCount;
    float rounding = 8.0f;
    if (optionCount < 2) optionCount = 2;
    if (optionCount > 6) optionCount = 6;
    if (*activeIndex < 0) *activeIndex = 0;
    if (*activeIndex >= optionCount) *activeIndex = optionCount - 1;
    ImRect hitRect(pos, ImVec2(pos.x + width, pos.y + height));
    bool hovered = ImGui::IsMouseHoveringRect(hitRect.Min, hitRect.Max);
    int clickedIndex = -1;
    if (hovered && ImGui::IsMouseClicked(0)) {
        ImVec2 mousePos = ImGui::GetIO().MousePos;
        float relX = mousePos.x - pos.x;
        int idx = (int)(relX / segW);
        if (idx >= 0 && idx < optionCount) {
            if (idx != *activeIndex) {
                clickedIndex = idx;
            }
        }
    }
    char idBuf[256];
    snprintf(idBuf, sizeof(idBuf), "%s_seg_%d", label, optionCount);
    static std::map<const char*, ImGui::AnimFloat> animMap;
    auto it = animMap.find(idBuf);
    if (it == animMap.end()) {
        it = animMap.emplace(strdup(idBuf), ImGui::AnimFloat((float)(*activeIndex) * segW, 8.0f)).first;
    }
    ImGui::AnimFloat& anim = it->second;
    float targetPos = (float)(*activeIndex) * segW;
    anim.SetTarget(targetPos);
    anim.Update();
    float highlightX = anim.Get();
    ImColor bgCol(40, 40, 52);
    dl->AddRectFilled(pos, ImVec2(pos.x + width, pos.y + height), CToU32(bgCol), rounding);
    ImColor borderCol(55, 55, 70);
    dl->AddRect(pos, ImVec2(pos.x + width, pos.y + height), CToU32(borderCol), rounding, ImDrawFlags_RoundCornersAll, 1.0f);
    ImColor innerShadow(0, 0, 0, 25);
    dl->AddRectFilled(ImVec2(pos.x + 2, pos.y + 2), ImVec2(pos.x + width - 2, pos.y + height - 2), CToU32(innerShadow), rounding - 2);
    float hlW = segW * 0.90f;
    float hlH = height * 0.86f;
    float hlX = pos.x + highlightX + (segW - hlW) * 0.5f;
    float hlY = pos.y + (height - hlH) * 0.5f;
    float hlRounding = rounding - 2.0f;
    ImColor hlCol = ImColor((int)accent.Value.x, (int)accent.Value.y, (int)accent.Value.z, 235);
    dl->AddRectFilled(ImVec2(hlX, hlY), ImVec2(hlX + hlW, hlY + hlH), CToU32(hlCol), hlRounding);
    ImColor hlTop = ImColor(255, 255, 255, 50);
    dl->AddRectFilled(ImVec2(hlX + 2, hlY + 2), ImVec2(hlX + hlW - 2, hlY + hlH * 0.5f), CToU32(hlTop), hlRounding - 1);
    ImColor hlGlow = ImColor((int)accent.Value.x, (int)accent.Value.y, (int)accent.Value.z, 60);
    dl->AddRectFilled(ImVec2(hlX - 2, hlY), ImVec2(hlX, hlY + hlH), CToU32(hlGlow), hlRounding);
    dl->AddRectFilled(ImVec2(hlX + hlW, hlY), ImVec2(hlX + hlW + 2, hlY + hlH), CToU32(hlGlow), hlRounding);
    ImColor hlBorder = ImColor(255, 255, 255, 30);
    dl->AddRect(ImVec2(hlX, hlY), ImVec2(hlX + hlW, hlY + hlH), CToU32(hlBorder), hlRounding, ImDrawFlags_RoundCornersAll, 0.5f);
    ImColor hlShadow(0, 0, 0, 20);
    dl->AddRectFilled(ImVec2(hlX + hlW, hlY + 2), ImVec2(hlX + hlW + 2, hlY + hlH - 2), CToU32(hlShadow), 1);
    ImColor hlAccentOverlay = ImColor((int)accent.Value.x, (int)accent.Value.y, (int)accent.Value.z, (int)(20 * (1.0f - fabsf(highlightX / segW - 0.5f) * 2.0f)));
    dl->AddRectFilled(ImVec2(hlX - hlW * 0.2f, hlY), ImVec2(hlX + hlW + hlW * 0.2f, hlY + hlH), CToU32(hlAccentOverlay), hlRounding);
    float textCenterY = pos.y + height * 0.5f;
    float barGlowT = fabsf(sinf(ImGui::GetTime() * 2.0f));
    ImColor barPulse = ImColor((int)accent.Value.x, (int)accent.Value.y, (int)accent.Value.z, (int)(6 * barGlowT));
    dl->AddRect(pos, ImVec2(pos.x + width, pos.y + height), CToU32(barPulse), rounding, ImDrawFlags_RoundCornersAll, 1.5f);
    for (int i = 0; i < optionCount; i++) {
        float segX = pos.x + segW * (float)i;
        float segCenterX = segX + segW * 0.5f;
        bool segHovered = false;
        if (hovered) {
            float mx = ImGui::GetIO().MousePos.x;
            segHovered = (mx >= segX && mx < segX + segW);
        }
        ImColor textCol(160, 160, 180);
        if (i == *activeIndex) {
            textCol = ImColor(255, 255, 255);
        } else if (segHovered) {
            textCol = ImColor(205, 205, 225);
        }
        ImVec2 textSize = ImGui::CalcTextSize(options[i]);
        float textX = segCenterX - textSize.x * 0.5f;
        float textY = textCenterY - textSize.y * 0.5f;
        dl->AddText(ImVec2(textX, textY), CToU32(textCol), options[i]);
        if (segHovered && i != *activeIndex) {
            ImColor segGlow(255, 255, 255, 12);
            dl->AddRectFilled(ImVec2(segX + 2, pos.y + 2), ImVec2(segX + segW - 2, pos.y + height - 2), CToU32(segGlow), rounding - 2);
            ImColor segBorder(255, 255, 255, 20);
            dl->AddRect(ImVec2(segX + 1, pos.y + 1), ImVec2(segX + segW - 1, pos.y + height - 1), CToU32(segBorder), rounding - 1, ImDrawFlags_RoundCornersAll, 0.5f);
            ImColor segOverlay = ImColor((int)accent.Value.x, (int)accent.Value.y, (int)accent.Value.z, 6);
            dl->AddRectFilled(ImVec2(segX + 4, pos.y + 4), ImVec2(segX + segW - 4, pos.y + height - 4), CToU32(segOverlay), rounding - 3);
        }
        if (i < optionCount - 1) {
            ImColor dividerCol(60, 60, 75);
            float divX = segX + segW;
            float divY1 = pos.y + height * 0.25f;
            float divY2 = pos.y + height * 0.75f;
            dl->AddLine(ImVec2(divX, divY1), ImVec2(divX, divY2), CToU32(dividerCol), 1.0f);
            ImColor dividerHighlight(255, 255, 255, 8);
            dl->AddLine(ImVec2(divX + 1, divY1), ImVec2(divX + 1, divY2), CToU32(dividerHighlight), 0.5f);
        }
        if (i == *activeIndex) {
            ImColor activeTextGlow = ImColor(255, 255, 255, 30);
            ImVec2 gMin(segCenterX - textSize.x * 0.5f - 4, textY - 2);
            ImVec2 gMax(segCenterX + textSize.x * 0.5f + 4, textY + textSize.y + 2);
            dl->AddRectFilled(gMin, gMax, CToU32(activeTextGlow), 3.0f);
            ImColor activeTextBorder(255, 255, 255, 15);
            dl->AddRect(gMin, gMax, CToU32(activeTextBorder), 3.0f, ImDrawFlags_RoundCornersAll, 0.5f);
        }
    }
    if (hovered) {
        ImColor hoverBorder(255, 255, 255, 20);
        dl->AddRect(pos, ImVec2(pos.x + width, pos.y + height), CToU32(hoverBorder), rounding, ImDrawFlags_RoundCornersAll, 1.0f);
    }
    if (clickedIndex >= 0) {
        *activeIndex = clickedIndex;
    }
    ImGui::SetCursorScreenPos(ImVec2(pos.x, pos.y + height + 4.0f));
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + height + 4.0f);
    return clickedIndex >= 0 ? *activeIndex : -1;
}

bool M_Switch3D(const char* label, bool* value, ImColor accent) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImVec2 winSize = ImGui::GetContentRegionAvail();
    float rowHeight = 52.0f;
    float trackW = 48.0f;
    float trackH = 26.0f;
    float knobR = 10.0f;
    float trackRadius = trackH * 0.5f;
    float textH = ImGui::CalcTextSize(label).y;
    float textW = ImGui::CalcTextSize(label).x;
    float trackX = pos.x + winSize.x - trackW - 4.0f;
    float trackY = pos.y + (rowHeight - trackH) * 0.5f;
    float knobCY = trackY + trackH * 0.5f;
    ImRect hitRect(pos, ImVec2(pos.x + winSize.x, pos.y + rowHeight));
    bool hovered = ImGui::IsMouseHoveringRect(hitRect.Min, hitRect.Max);
    bool clicked = false;
    if (hovered && ImGui::IsMouseClicked(0)) {
        *value = !*value;
        clicked = true;
    }
    static std::map<const char*, ImGui::AnimFloat> animMap;
    auto it = animMap.find(label);
    if (it == animMap.end()) {
        it = animMap.emplace(label, ImGui::AnimFloat(*value ? 1.0f : 0.0f, 8.0f)).first;
    }
    ImGui::AnimFloat& anim = it->second;
    anim.SetTarget(*value ? 1.0f : 0.0f);
    anim.Update();
    float t = anim.Get();
    float easeT = t * t * (3.0f - 2.0f * t);
    float knobOffset = easeT * (trackW - knobR * 2.0f);
    float kx = trackX + knobR + knobOffset;
    ImColor trackTopOff(65, 65, 75);
    ImColor trackBotOff(40, 40, 50);
    float topMul = 1.2f;
    ImColor trackTopOn(
        ImMin(255, (int)(accent.Value.x * topMul)),
        ImMin(255, (int)(accent.Value.y * topMul)),
        ImMin(255, (int)(accent.Value.z * topMul)),
        255
    );
    ImColor trackBotOn = accent;
    if (hovered) {
        trackTopOff = ImColor(80, 80, 92);
        trackBotOff = ImColor(50, 50, 62);
    }
    float topR = trackTopOff.Value.x + (trackTopOn.Value.x - trackTopOff.Value.x) * t;
    float topG = trackTopOff.Value.y + (trackTopOn.Value.y - trackTopOff.Value.y) * t;
    float topB = trackTopOff.Value.z + (trackTopOn.Value.z - trackTopOff.Value.z) * t;
    float botR = trackBotOff.Value.x + (trackBotOn.Value.x - trackBotOff.Value.x) * t;
    float botG = trackBotOff.Value.y + (trackBotOn.Value.y - trackBotOff.Value.y) * t;
    float botB = trackBotOff.Value.z + (trackBotOn.Value.z - trackBotOff.Value.z) * t;
    ImColor trackTop((int)topR, (int)topG, (int)topB, 255);
    ImColor trackBot((int)botR, (int)botG, (int)botB, 255);
    ImColor dropShadow(0, 0, 0, 55);
    dl->AddRectFilled(ImVec2(trackX, trackY + 2.0f), ImVec2(trackX + trackW, trackY + trackH + 2.0f), CToU32(dropShadow), trackRadius);
    dl->AddRectFilled(ImVec2(trackX, trackY), ImVec2(trackX + trackW, trackY + trackH * 0.5f + 1.0f), CToU32(trackTop), trackRadius);
    dl->AddRectFilled(ImVec2(trackX, trackY + trackH * 0.5f), ImVec2(trackX + trackW, trackY + trackH), CToU32(trackBot), trackRadius);
    ImColor bevelLight(255, 255, 255, 35);
    dl->AddRect(ImVec2(trackX + 1, trackY + 1), ImVec2(trackX + trackW - 1, trackY + trackH * 0.5f), CToU32(bevelLight), trackRadius);
    ImColor bevelDark(0, 0, 0, 45);
    dl->AddRect(ImVec2(trackX + 1, trackY + trackH * 0.5f), ImVec2(trackX + trackW - 1, trackY + trackH - 1), CToU32(bevelDark), trackRadius);
    ImColor trackEdge(255, 255, 255, 10);
    dl->AddRect(ImVec2(trackX, trackY), ImVec2(trackX + trackW, trackY + trackH), CToU32(trackEdge), trackRadius, ImDrawFlags_RoundCornersAll, 0.5f);
    float shadowOff = t * 3.5f;
    ImColor knobShadow(0, 0, 0, (int)(70 + t * 70));
    dl->AddCircleFilled(ImVec2(kx + 1.0f + shadowOff * 0.5f, knobCY + 1.5f + shadowOff), knobR + 1.5f, CToU32(knobShadow));
    ImColor knobCenter(245, 245, 255);
    ImColor knobEdge(175, 175, 195);
    int gradSteps = 14;
    for (int i = 0; i < gradSteps; i++) {
        float frac = (float)i / (float)gradSteps;
        float r = knobR * (1.0f - frac * 0.08f);
        float blend = frac;
        float cr = knobCenter.Value.x * (1.0f - blend) + knobEdge.Value.x * blend;
        float cg = knobCenter.Value.y * (1.0f - blend) + knobEdge.Value.y * blend;
        float cb = knobCenter.Value.z * (1.0f - blend) + knobEdge.Value.z * blend;
        ImColor ringCol((int)cr, (int)cg, (int)cb, 255);
        dl->AddCircleFilled(ImVec2(kx, knobCY), r, CToU32(ringCol));
    }
    ImColor shineSpot(255, 255, 255, 160);
    dl->AddCircleFilled(ImVec2(kx - 2.5f, knobCY - 2.5f), knobR * 0.3f, CToU32(shineSpot));
    ImColor rimEdge(0, 0, 0, 40);
    dl->AddCircle(ImVec2(kx, knobCY), knobR, CToU32(rimEdge), 0, 1.0f);
    ImColor accentRim = ImColor((int)accent.Value.x, (int)accent.Value.y, (int)accent.Value.z, (int)(50 * t));
    dl->AddCircle(ImVec2(kx, knobCY), knobR + 0.5f, CToU32(accentRim), 0, 1.0f);
    ImColor knobRingHighlight(255, 255, 255, 25);
    dl->AddCircle(ImVec2(kx - 0.5f, knobCY - 0.5f), knobR * 0.8f, CToU32(knobRingHighlight), 0, 0.5f);
    ImColor labelBg(0, 0, 0, 75);
    ImVec2 labelSize = ImGui::CalcTextSize(label);
    float pillW = labelSize.x + 18.0f;
    float pillH = labelSize.y + 8.0f;
    float pillX = pos.x + 4.0f;
    float pillY = pos.y + (rowHeight - pillH) * 0.5f;
    dl->AddRectFilled(ImVec2(pillX, pillY), ImVec2(pillX + pillW, pillY + pillH), CToU32(labelBg), pillH * 0.5f);
    ImColor labelBorder(255, 255, 255, 15);
    dl->AddRect(ImVec2(pillX, pillY), ImVec2(pillX + pillW, pillY + pillH), CToU32(labelBorder), pillH * 0.5f, ImDrawFlags_RoundCornersAll, 0.5f);
    ImColor labelCol(220, 220, 230);
    dl->AddText(ImVec2(pillX + 9.0f, pos.y + (rowHeight - textH) * 0.5f), CToU32(labelCol), label);
    ImGui::SetCursorScreenPos(ImVec2(pos.x, pos.y + rowHeight));
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + rowHeight);
    return clicked;
}

void M_BooleanIndicator(const char* label, bool value, ImColor activeColor, ImColor inactiveColor) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImVec2 winSize = ImGui::GetContentRegionAvail();
    float height = 28.0f;
    float dotR = 5.0f;
    float dotX = pos.x + dotR + 6.0f;
    float dotY = pos.y + height * 0.5f;
    float textH = ImGui::CalcTextSize(label).y;
    float currentTime = ImGui::GetTime();
    float sinPhase = sinf(currentTime * 3.0f);
    float pulse = value ? (sinPhase * 0.5f + 0.5f) : 0.0f;
    float actR = activeColor.Value.x;
    float actG = activeColor.Value.y;
    float actB = activeColor.Value.z;
    ImColor dotCol;
    if (value) {
        int alpha = (int)(180 + 75 * pulse);
        dotCol = ImColor((int)actR, (int)actG, (int)actB, alpha);
    } else {
        dotCol = inactiveColor;
    }
    ImColor dotShadow(0, 0, 0, 40);
    dl->AddCircleFilled(ImVec2(dotX + 0.5f, dotY + 0.5f), dotR, CToU32(dotShadow));
    dl->AddCircleFilled(ImVec2(dotX, dotY), dotR, CToU32(dotCol));
    ImColor dotShine(255, 255, 255, 60);
    dl->AddCircleFilled(ImVec2(dotX - 1.5f, dotY - 1.5f), dotR * 0.4f, CToU32(dotShine));
    ImColor dotRing(255, 255, 255, 30);
    dl->AddCircle(ImVec2(dotX, dotY), dotR, CToU32(dotRing), 0, 0.5f);
    if (value) {
        float glowR1 = dotR + 4.0f + pulse * 5.0f;
        float glowA1 = 0.12f + pulse * 0.18f;
        if (glowA1 > 0.02f) {
            ImColor glowCol1 = ImColor((int)actR, (int)actG, (int)actB, (int)(glowA1 * 255));
            dl->AddCircleFilled(ImVec2(dotX, dotY), glowR1, CToU32(glowCol1));
        }
        float glowR2 = dotR + 9.0f + pulse * 6.0f;
        float glowA2 = 0.04f + pulse * 0.08f;
        if (glowA2 > 0.02f) {
            ImColor glowCol2 = ImColor((int)actR, (int)actG, (int)actB, (int)(glowA2 * 255));
            dl->AddCircleFilled(ImVec2(dotX, dotY), glowR2, CToU32(glowCol2));
        }
        float glowR3 = dotR + 14.0f + pulse * 5.0f;
        float glowA3 = 0.02f + pulse * 0.04f;
        if (glowA3 > 0.02f) {
            ImColor glowCol3 = ImColor((int)actR, (int)actG, (int)actB, (int)(glowA3 * 255));
            dl->AddCircleFilled(ImVec2(dotX, dotY), glowR3, CToU32(glowCol3));
        }
    }
    float textX = dotX + dotR + 10.0f;
    ImColor labelCol(170, 170, 190);
    if (value) labelCol = ImColor(210, 210, 235);
    dl->AddText(ImVec2(textX, pos.y + (height - textH) * 0.5f), CToU32(labelCol), label);
    ImColor labelShadow2(0, 0, 0, 20);
    dl->AddText(ImVec2(textX + 0.5f, pos.y + (height - textH) * 0.5f + 0.5f), CToU32(labelShadow2), label);
    dl->AddText(ImVec2(textX, pos.y + (height - textH) * 0.5f), CToU32(labelCol), label);
    const char* statusText = value ? "Active" : "Inactive";
    ImVec2 statusSize = ImGui::CalcTextSize(statusText);
    float statusX = pos.x + winSize.x - statusSize.x - 4.0f;
    float statusY = pos.y + (height - statusSize.y) * 0.5f;
    ImColor statusCol;
    if (value) {
        int sa = (int)(180 + 75 * pulse);
        statusCol = ImColor((int)actR, (int)actG, (int)actB, sa);
    } else {
        statusCol = ImColor(100, 100, 110);
    }
    dl->AddText(ImVec2(statusX, statusY), CToU32(statusCol), statusText);
    if (value) {
        float statusGlow = 0.1f + pulse * 0.15f;
        if (statusGlow > 0.02f) {
            ImColor sGlowCol = ImColor((int)actR, (int)actG, (int)actB, (int)(statusGlow * 255));
            ImVec2 sMin(statusX - 4, statusY - 2);
            ImVec2 sMax(statusX + statusSize.x + 4, statusY + statusSize.y + 2);
            dl->AddRectFilled(sMin, sMax, CToU32(sGlowCol), 4.0f);
        }
    }
    ImGui::SetCursorScreenPos(ImVec2(pos.x, pos.y + height));
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + height);
}

bool M_ToggleRow(const char* icon, const char* label, const char* subtitle, bool* value, ImColor accent) {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImVec2 winSize = ImGui::GetContentRegionAvail();
    float rowHeight = 52.0f;
    float iconR = 16.0f;
    float iconCX = pos.x + iconR + 10.0f;
    float iconCY = pos.y + rowHeight * 0.5f;
    float trackW = 40.0f;
    float trackH = 22.0f;
    float knobR = 9.0f;
    float trackRadius = trackH * 0.5f;
    float trackX = pos.x + winSize.x - trackW - 4.0f;
    float trackY = pos.y + (rowHeight - trackH) * 0.5f;
    float knobCY = trackY + trackH * 0.5f;
    ImRect hitRect(pos, ImVec2(pos.x + winSize.x, pos.y + rowHeight));
    bool hovered = ImGui::IsMouseHoveringRect(hitRect.Min, hitRect.Max);
    bool clicked = false;
    if (hovered && ImGui::IsMouseClicked(0)) {
        *value = !*value;
        clicked = true;
    }
    if (hovered) {
        ImColor hoverBg(255, 255, 255, 10);
        dl->AddRectFilled(pos, ImVec2(pos.x + winSize.x, pos.y + rowHeight), CToU32(hoverBg), 6.0f);
        ImColor hoverBorder(255, 255, 255, 18);
        dl->AddRect(pos, ImVec2(pos.x + winSize.x, pos.y + rowHeight), CToU32(hoverBorder), 6.0f, ImDrawFlags_RoundCornersAll, 1.0f);
    }
    ImColor iconBg = accent;
    iconBg.Value.w = 0.22f;
    dl->AddCircleFilled(ImVec2(iconCX, iconCY), iconR, CToU32(iconBg));
    ImColor iconBorder = accent;
    iconBorder.Value.w = 0.5f;
    dl->AddCircle(ImVec2(iconCX, iconCY), iconR, CToU32(iconBorder), 0, 1.0f);
    ImColor iconCol(220, 220, 235);
    if (hovered) iconCol = ImColor(245, 245, 255);
    ImVec2 iconSize = ImGui::CalcTextSize(icon);
    dl->AddText(ImVec2(iconCX - iconSize.x * 0.5f, iconCY - iconSize.y * 0.5f), CToU32(iconCol), icon);
    float textX = iconCX + iconR + 14.0f;
    float labelY = pos.y + rowHeight * 0.5f;
    ImVec2 labelSize = ImGui::CalcTextSize(label);
    float labelTopY = labelY - labelSize.y - 1.0f;
    dl->AddText(ImVec2(textX, labelTopY), CToU32(ImColor(210, 210, 230)), label);
    if (subtitle && subtitle[0] != '\0') {
        ImVec2 subSize = ImGui::CalcTextSize(subtitle);
        float subY = labelY + 2.0f;
        ImColor subCol(130, 130, 155);
        if (hovered) subCol = ImColor(160, 160, 185);
        dl->AddText(ImVec2(textX, subY), CToU32(subCol), subtitle);
    }
    static std::map<const char*, ImGui::AnimFloat> animMap;
    auto it = animMap.find(label);
    if (it == animMap.end()) {
        it = animMap.emplace(label, ImGui::AnimFloat(*value ? 1.0f : 0.0f, 8.0f)).first;
    }
    ImGui::AnimFloat& anim = it->second;
    anim.SetTarget(*value ? 1.0f : 0.0f);
    anim.Update();
    float t = anim.Get();
    float easeT = t * t * (3.0f - 2.0f * t);
    float knobOffset = easeT * (trackW - knobR * 2.0f);
    float kx = trackX + knobR + knobOffset;
    float trackOffR = 50.0f; float trackOffG = 50.0f; float trackOffB = 60.0f;
    float trackOnR = accent.Value.x; float trackOnG = accent.Value.y; float trackOnB = accent.Value.z;
    float tr = trackOffR + (trackOnR - trackOffR) * t;
    float tg = trackOffG + (trackOnG - trackOffG) * t;
    float tb = trackOffB + (trackOnB - trackOffB) * t;
    ImColor trackCol((int)tr, (int)tg, (int)tb, 255);
    if (hovered) {
        trackCol = ImColor(
            ImMin(255, (int)(tr + 12)),
            ImMin(255, (int)(tg + 12)),
            ImMin(255, (int)(tb + 12)),
            255
        );
    }
    ImColor trackShadow2(0, 0, 0, 50);
    dl->AddRectFilled(ImVec2(trackX, trackY + 1.5f), ImVec2(trackX + trackW, trackY + trackH + 1.5f), CToU32(trackShadow2), trackRadius);
    dl->AddRectFilled(ImVec2(trackX, trackY), ImVec2(trackX + trackW, trackY + trackH), CToU32(trackCol), trackRadius);
    ImColor trackInner2(0, 0, 0, 20);
    dl->AddRectFilled(ImVec2(trackX + 2, trackY + 2), ImVec2(trackX + trackW - 2, trackY + trackH - 2), CToU32(trackInner2), trackRadius - 2);
    ImColor knobShadow3(0, 0, 0, 50);
    dl->AddCircleFilled(ImVec2(kx + 0.5f, knobCY + 1.0f), knobR + 0.5f, CToU32(knobShadow3));
    ImColor knobCol(240, 240, 255);
    if (hovered) knobCol = ImColor(255, 255, 255);
    dl->AddCircleFilled(ImVec2(kx, knobCY), knobR, CToU32(knobCol));
    ImColor knobEdge2(0, 0, 0, 25);
    dl->AddCircle(ImVec2(kx, knobCY), knobR, CToU32(knobEdge2), 0, 1.0f);
    ImColor knobMid1 = ImColor(0, 0, 0, 10);
    dl->AddCircleFilled(ImVec2(kx, knobCY), knobR * 0.4f, CToU32(knobMid1));
    ImColor knobShine2(255, 255, 255, 110);
    dl->AddCircleFilled(ImVec2(kx - 2.0f, knobCY - 2.0f), knobR * 0.35f, CToU32(knobShine2));
    if (hovered) {
        ImColor highlightGlow(255, 255, 255, 8);
        dl->AddCircleFilled(ImVec2(kx, knobCY), knobR + 2.0f, CToU32(highlightGlow));
    }
    ImGui::SetCursorScreenPos(ImVec2(pos.x, pos.y + rowHeight));
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + rowHeight);
    return clicked;
}
