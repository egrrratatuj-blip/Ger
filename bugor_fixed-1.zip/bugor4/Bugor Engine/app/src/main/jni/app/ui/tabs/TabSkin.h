#pragma once
#include <imgui.h>

void DrawTabSkin(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize);
void InitTabSkin();
void ShutdownTabSkin();
