#include "ConfigSystem.h"
#include <cstring>
#include <cstdio>

static const uint32_t CONFIG_MAGIC = 0x434F4E46;
static const uint32_t CONFIG_VERSION = 1;

ConfigSystem::ConfigSystem() {
    ResetToDefaults();
}

bool ConfigSystem::SaveToFile(const char* path) {
    FILE* f = fopen(path, "wb");
    if (!f) return false;
    uint32_t magic = CONFIG_MAGIC;
    uint32_t version = CONFIG_VERSION;
    fwrite(&magic, sizeof(magic), 1, f);
    fwrite(&version, sizeof(version), 1, f);
    fwrite(&toggles, sizeof(toggles), 1, f);
    fwrite(&config, sizeof(config), 1, f);
    fclose(f);
    return true;
}

bool ConfigSystem::LoadFromFile(const char* path) {
    FILE* f = fopen(path, "rb");
    if (!f) return false;
    uint32_t magic, version;
    if (fread(&magic, sizeof(magic), 1, f) != 1 || magic != CONFIG_MAGIC) {
        fclose(f);
        return false;
    }
    if (fread(&version, sizeof(version), 1, f) != 1 || version != CONFIG_VERSION) {
        fclose(f);
        return false;
    }
    if (fread(&toggles, sizeof(toggles), 1, f) != 1) {
        fclose(f);
        return false;
    }
    if (fread(&config, sizeof(config), 1, f) != 1) {
        fclose(f);
        return false;
    }
    fclose(f);
    return true;
}

void ConfigSystem::ResetToDefaults() {
    toggles = Toggles();
    config = Config();
}

Toggles& ConfigSystem::GetToggles() {
    return toggles;
}

Config& ConfigSystem::GetConfig() {
    return config;
}
