#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "../../../imgui/imgui.h"
#include "../../../imgui/imgui_internal.h"
#include "../../../imgui/mycustom/imgui_Custom.h"
#include <math.h>
#include <string.h>
#include <map>
#include <stdlib.h>

static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }

bool M_ConfirmDialog(const char* title, const char* message, const char* confirmText, const char* cancelText, ImColor accent, bool danger)
{
    static std::map<const char*, struct { bool open; bool result; float anim; float scaleAnim; float btnHoverL; float btnHoverR; }> s_dialogs;
    auto& d = s_dialogs[title];
    if (!d.open) { d.open = true; d.result = false; d.anim = 0.0f; d.scaleAnim = 0.0f; d.btnHoverL = 0.0f; d.btnHoverR = 0.0f; }
    ImDrawList* dl = ImGui::GetOverlayDrawList();
    ImGuiIO& io = ImGui::GetIO();
    ImVec2 ss = io.DisplaySize;
    d.anim += (1.0f - d.anim) * ImClamp(io.DeltaTime * 9.0f, 0.0f, 1.0f);
    d.scaleAnim += (1.0f - d.scaleAnim) * ImClamp(io.DeltaTime * 6.0f, 0.0f, 1.0f);
    float o = d.anim;
    float scale = 0.7f + 0.3f * d.scaleAnim;
    dl->AddRectFilled(ImVec2(0,0), ss, C(ImColor(0,0,0,(int)(160 * o))));
    float w = 340.0f;
    float msgH = ImGui::CalcTextSize(message, NULL, false, w - 40.0f).y + 16.0f;
    float h = 65.0f + msgH + 56.0f;
    ImVec2 center = ImVec2(ss.x * 0.5f, ss.y * 0.5f);
    ImVec2 p0 = ImVec2((ss.x - w * scale) * 0.5f, (ss.y - h * scale) * 0.5f);
    ImVec2 p1 = ImVec2(p0.x + w * scale, p0.y + h * scale);
    dl->AddRectFilled(p0, p1, C(ImColor(28,28,36)), 12.0f * o);
    dl->AddRect(p0, p1, C(ImColor(55,55,70)), 12.0f * o);
    if (danger)
    {
        dl->AddRectFilled(ImVec2(p0.x + 2.0f, p0.y + 2.0f), ImVec2(p0.x + 5.0f, p1.y - 2.0f), C(ImColor(220,50,50)), 2.0f);
    }
    else
    {
        dl->AddRectFilled(ImVec2(p0.x + 2.0f, p0.y + 2.0f), ImVec2(p0.x + 5.0f, p1.y - 2.0f), C(accent), 2.0f);
    }
    ImVec2 ts = ImGui::CalcTextSize(title);
    dl->AddText(ImGui::GetFont(), 18.0f * o, ImVec2(p0.x + 20.0f * o, p0.y + 18.0f * o), C(accent), title);
    dl->AddText(ImGui::GetFont(), 13.0f * o, ImVec2(p0.x + 20.0f * o, p0.y + 52.0f * o), C(ImColor(200,200,215,(int)(255*o))), message, NULL, w - 40.0f);
    float btnW = 95.0f;
    float btnH = 34.0f;
    float btnY = p1.y - 18.0f - btnH;
    float btnGap = 16.0f;
    float totalBtnW = btnW * 2.0f + btnGap;
    float btnStartX = center.x - totalBtnW * 0.5f;
    bool clickedConfirm = false;
    bool clickedCancel = false;
    ImVec2 mouse = io.MousePos;
    ImColor confirmCol = danger ? ImColor(200,45,45) : accent;
    ImVec2 cb0 = ImVec2(btnStartX, btnY);
    ImVec2 cb1 = ImVec2(btnStartX + btnW, btnY + btnH);
    bool ch = (mouse.x >= cb0.x && mouse.x <= cb1.x && mouse.y >= cb0.y && mouse.y <= cb1.y);
    d.btnHoverL += (ch ? 1.0f : 0.0f) * ImClamp(io.DeltaTime * 10.0f, 0.0f, 1.0f);
    d.btnHoverR += (mouse.x >= (btnStartX + btnW + btnGap) && mouse.x <= (btnStartX + btnW + btnGap + btnW) && mouse.y >= btnY && mouse.y <= btnY + btnH) ? 1.0f - d.btnHoverR : -d.btnHoverR * 0.1f;
    d.btnHoverR = ImClamp(d.btnHoverR, 0.0f, 1.0f);
    ImColor cbBg;
    if (danger)
    {
        float r = 200 + 55 * ch;
        float g = 45 - 15 * ch;
        float b = 45 - 15 * ch;
        cbBg = ImColor((int)r, (int)g, (int)b);
    }
    else
    {
        cbBg = ch ? ImColor(accent.Value.x * 1.2f, accent.Value.y * 1.2f, accent.Value.z * 1.2f) : accent;
    }
    cbBg.Value.w = o;
    float corr = danger ? 6.0f : 5.0f;
    dl->AddRectFilled(cb0, cb1, C(cbBg), corr * o);
    if (danger)
        dl->AddRect(cb0, cb1, C(ImColor(255,120,120,60)), corr * o);
    ImVec2 cts = ImGui::CalcTextSize(confirmText);
    dl->AddText(ImGui::GetFont(), 14.0f * o, ImVec2(cb0.x + (btnW - cts.x) * 0.5f * o, cb0.y + (btnH - cts.y) * 0.5f * o), C(ImColor(255,255,255,(int)(255*o))), confirmText);
    if (ch && io.MouseClicked[0]) clickedConfirm = true;
    ImVec2 ncb0 = ImVec2(btnStartX + btnW + btnGap, btnY);
    ImVec2 ncb1 = ImVec2(ncb0.x + btnW, ncb0.y + btnH);
    bool nh = (mouse.x >= ncb0.x && mouse.x <= ncb1.x && mouse.y >= ncb0.y && mouse.y <= ncb1.y);
    ImColor ncBg = nh ? ImColor(55,55,70) : ImColor(42,42,55);
    ncBg.Value.w = o;
    dl->AddRectFilled(ncb0, ncb1, C(ncBg), 5.0f * o);
    dl->AddRect(ncb0, ncb1, C(ImColor(65,65,80)), 5.0f * o);
    ImVec2 nts = ImGui::CalcTextSize(cancelText);
    dl->AddText(ImGui::GetFont(), 14.0f * o, ImVec2(ncb0.x + (btnW - nts.x) * 0.5f * o, ncb0.y + (btnH - nts.y) * 0.5f * o), C(ImColor(200,200,215,(int)(255*o))), cancelText);
    if (nh && io.MouseClicked[0]) clickedCancel = true;
    if (clickedConfirm) { d.open = false; d.result = true; }
    if (clickedCancel) { d.open = false; d.result = false; }
    if (io.MouseClicked[0] && !ch && !nh)
    {
        ImVec2 dp0 = ImVec2((ss.x - w) * 0.5f, (ss.y - h) * 0.5f);
        ImVec2 dp1 = ImVec2(dp0.x + w, dp0.y + h);
        if (mouse.x < dp0.x || mouse.x > dp1.x || mouse.y < dp0.y || mouse.y > dp1.y)
        { d.open = false; d.result = false; }
    }
    if (ImGui::IsKeyPressed(ImGuiKey_Escape)) { d.open = false; d.result = false; }
    if (ImGui::IsKeyPressed(ImGuiKey_Enter)) { d.open = false; d.result = true; }
    if (d.open)
    {
        ImGui::SetCursorScreenPos(ImVec2(center.x - w * 0.5f, center.y - h * 0.5f));
        ImGui::InvisibleButton("##confirm_block", ImVec2(w, h));
        if (ImGui::IsItemActive())
        {
            int key = ImGui::GetIO().KeyMap[ImGuiKey_Enter];
            if (key >= 0 && ImGui::IsKeyPressed(key)) { d.open = false; d.result = true; }
        }
    }
    return d.result;
}

bool M_InputDialog(const char* title, const char* message, char* buf, int bufSize, const char* confirmText, const char* cancelText)
{
    static std::map<const char*, struct { bool open; bool result; float anim; float btnHoverL; float btnHoverR; bool wasFocused; }> s_dialogs;
    auto& d = s_dialogs[title];
    if (!d.open)
    {
        d.open = true;
        d.result = false;
        d.anim = 0.0f;
        d.btnHoverL = 0.0f;
        d.btnHoverR = 0.0f;
        d.wasFocused = false;
    }
    ImDrawList* dl = ImGui::GetOverlayDrawList();
    ImGuiIO& io = ImGui::GetIO();
    ImVec2 ss = io.DisplaySize;
    d.anim += (1.0f - d.anim) * ImClamp(io.DeltaTime * 8.0f, 0.0f, 1.0f);
    float o = d.anim;
    dl->AddRectFilled(ImVec2(0,0), ss, C(ImColor(0,0,0,(int)(150 * o))));
    float w = 380.0f;
    float h = 235.0f;
    ImVec2 center = ImVec2(ss.x * 0.5f, ss.y * 0.5f);
    ImVec2 p0 = ImVec2((ss.x - w) * 0.5f, (ss.y - h) * 0.5f);
    ImVec2 p1 = ImVec2(p0.x + w, p0.y + h);
    dl->AddRectFilled(p0, p1, C(ImColor(28,28,36)), 10.0f * o);
    dl->AddRect(p0, p1, C(ImColor(55,55,70)), 10.0f * o);
    dl->AddRectFilled(ImVec2(p0.x + 2.0f, p0.y + 2.0f), ImVec2(p0.x + 5.0f, p1.y - 2.0f), C(ImColor(0,190,240)), 2.0f);
    dl->AddText(ImGui::GetFont(), 18.0f * o, ImVec2(p0.x + 20.0f * o, p0.y + 16.0f), C(ImColor(0,200,255,(int)(255*o))), title);
    dl->AddText(ImGui::GetFont(), 13.0f * o, ImVec2(p0.x + 20.0f, p0.y + 50.0f), C(ImColor(200,200,215,(int)(255*o))), message);
    float inputY = p0.y + 82.0f;
    ImVec2 inputP0 = ImVec2(p0.x + 20.0f, inputY);
    ImVec2 inputP1 = ImVec2(p1.x - 20.0f, inputY + 36.0f);
    dl->AddRectFilled(inputP0, inputP1, C(ImColor(16,16,24)), 6.0f * o);
    bool hasFocus = false;
    char id[64];
    snprintf(id, sizeof(id), "##input_%s", title);
    ImGui::SetCursorScreenPos(ImVec2(inputP0.x + 8.0f, inputP0.y + 6.0f));
    ImGui::SetNextItemWidth(inputP1.x - inputP0.x - 20.0f);
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.85f, 0.85f, 0.92f, o));
    ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0,0,0,0));
    ImGui::PushStyleColor(ImGuiCol_FrameBgHovered, ImVec4(0,0,0,0));
    ImGui::PushStyleColor(ImGuiCol_FrameBgActive, ImVec4(0,0,0,0));
    ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 0.0f);
    ImGui::InputText(id, buf, bufSize);
    hasFocus = ImGui::IsItemActive();
    ImGui::PopStyleVar(1);
    ImGui::PopStyleColor(4);
    if (hasFocus) { d.wasFocused = true; dl->AddRect(inputP0, inputP1, C(ImColor(0,200,255,(int)(200*o))), 6.0f * o); }
    else { dl->AddRect(inputP0, inputP1, C(ImColor(65,65,80)), 6.0f * o); }
    if (hasFocus && (io.MouseClicked[0] || ImGui::IsKeyPressed(ImGuiKey_A, false)))
    {
        ImGui::SetKeyboardFocusHere(-1);
    }
    int len = (int)strlen(buf);
    char charCount[16];
    snprintf(charCount, sizeof(charCount), "%d/%d", len, bufSize - 1);
    ImVec2 ccs = ImGui::CalcTextSize(charCount);
    dl->AddText(ImGui::GetFont(), 9.0f * o, ImVec2(inputP1.x - ccs.x - 6.0f, inputP1.y + 4.0f), C(ImColor(90,90,105,(int)(255*o))), charCount);
    dl->AddText(ImGui::GetFont(), 9.0f * o, ImVec2(inputP0.x + 4.0f, inputP1.y + 4.0f), C(ImColor(90,90,105,(int)(255*o))), hasFocus ? "typing..." : "click to focus");
    if (len > bufSize - 4)
    {
        ImColor warn = ImColor(255,180,60,(int)(200*o));
        dl->AddText(ImGui::GetFont(), 9.0f * o, ImVec2(inputP0.x + ccs.x + 10.0f, inputP1.y + 4.0f), C(warn), "max");
    }
    float btnW = 95.0f;
    float btnH = 34.0f;
    float btnY = p1.y - 18.0f - btnH;
    float btnGap = 16.0f;
    float totalBtnW = btnW * 2.0f + btnGap;
    float btnStartX = center.x - totalBtnW * 0.5f;
    ImVec2 mouse = io.MousePos;
    bool clickedConfirm = false;
    bool clickedCancel = false;
    bool hasValid = len > 0;
    ImVec2 cb0 = ImVec2(btnStartX, btnY);
    ImVec2 cb1 = ImVec2(btnStartX + btnW, btnY + btnH);
    bool ch = (mouse.x >= cb0.x && mouse.x <= cb1.x && mouse.y >= cb0.y && mouse.y <= cb1.y);
    ImColor confirmColor = hasValid ? (ch ? ImColor(0,215,255) : ImColor(0,200,255)) : ImColor(45,45,58);
    confirmColor.Value.w = o;
    dl->AddRectFilled(cb0, cb1, C(confirmColor), 5.0f * o);
    if (hasValid)
        dl->AddRect(cb0, cb1, C(ImColor(255,255,255,25)), 5.0f * o);
    ImVec2 cts = ImGui::CalcTextSize(confirmText);
    dl->AddText(ImGui::GetFont(), 14.0f * o, ImVec2(cb0.x + (btnW - cts.x) * 0.5f, cb0.y + (btnH - cts.y) * 0.5f), C(ImColor(255,255,255,(int)(255*o*(hasValid?1.0f:0.35f)))), confirmText);
    if (ch && io.MouseClicked[0] && hasValid) clickedConfirm = true;
    ImVec2 ncb0 = ImVec2(btnStartX + btnW + btnGap, btnY);
    ImVec2 ncb1 = ImVec2(ncb0.x + btnW, ncb0.y + btnH);
    bool nh = (mouse.x >= ncb0.x && mouse.x <= ncb1.x && mouse.y >= ncb0.y && mouse.y <= ncb1.y);
    dl->AddRectFilled(ncb0, ncb1, C(nh ? ImColor(55,55,70) : ImColor(42,42,55)), 5.0f * o);
    dl->AddRect(ncb0, ncb1, C(ImColor(65,65,80)), 5.0f * o);
    ImVec2 nts = ImGui::CalcTextSize(cancelText);
    dl->AddText(ImGui::GetFont(), 14.0f * o, ImVec2(ncb0.x + (btnW - nts.x) * 0.5f, ncb0.y + (btnH - nts.y) * 0.5f), C(ImColor(200,200,215,(int)(255*o))), cancelText);
    if (nh && io.MouseClicked[0]) clickedCancel = true;
    if (clickedConfirm && hasValid) { d.open = false; d.result = true; }
    if (ImGui::IsKeyPressed(ImGuiKey_Enter) && hasValid) { d.open = false; d.result = true; }
    if (clickedCancel) { d.open = false; d.result = false; }
    if (ImGui::IsKeyPressed(ImGuiKey_Escape)) { d.open = false; d.result = false; }
    if (io.MouseClicked[0] && !ch && !nh)
    {
        bool inside = mouse.x >= p0.x && mouse.x <= p1.x && mouse.y >= p0.y && mouse.y <= p1.y;
        if (!inside) { d.open = false; d.result = false; }
    }
    return d.result;
}

void M_MessageDialog(const char* title, const char* message, ImColor type)
{
    static std::map<const char*, struct { bool open; float anim; float scale; }> s_dialogs;
    auto& d = s_dialogs[title];
    if (!d.open) { d.open = true; d.anim = 0.0f; d.scale = 0.0f; }
    ImDrawList* dl = ImGui::GetOverlayDrawList();
    ImGuiIO& io = ImGui::GetIO();
    ImVec2 ss = io.DisplaySize;
    d.anim += (1.0f - d.anim) * ImClamp(io.DeltaTime * 9.0f, 0.0f, 1.0f);
    d.scale += (1.0f - d.scale) * ImClamp(io.DeltaTime * 7.0f, 0.0f, 1.0f);
    float o = d.anim;
    dl->AddRectFilled(ImVec2(0,0), ss, C(ImColor(0,0,0,(int)(130 * o))));
    float w = 310.0f;
    float msgH = ImGui::CalcTextSize(message, NULL, false, w - 40.0f).y + 12.0f;
    float h = 65.0f + msgH + 56.0f;
    ImVec2 center = ImVec2(ss.x * 0.5f, ss.y * 0.5f);
    float sc = 0.8f + 0.2f * d.scale;
    ImVec2 p0 = ImVec2((ss.x - w * sc) * 0.5f, (ss.y - h * sc) * 0.5f);
    ImVec2 p1 = ImVec2(p0.x + w * sc, p0.y + h * sc);
    dl->AddRectFilled(p0, p1, C(ImColor(26,26,34)), 10.0f * o);
    dl->AddRect(p0, p1, C(ImColor(52,52,65)), 10.0f * o);
    dl->AddRectFilled(ImVec2(p0.x + 2.0f, p0.y + 2.0f), ImVec2(p0.x + 5.0f, p1.y - 2.0f), C(type), 2.0f);
    dl->AddText(ImGui::GetFont(), 17.0f * o, ImVec2(p0.x + 20.0f * o, p0.y + 16.0f), C(type), title);
    dl->AddText(ImGui::GetFont(), 13.0f * o, ImVec2(p0.x + 20.0f, p0.y + 46.0f), C(ImColor(200,200,215,(int)(255*o))), message, NULL, w - 40.0f);
    float btnW = 85.0f;
    float btnH = 32.0f;
    ImVec2 cb0 = ImVec2(center.x - btnW * 0.5f, p1.y - 18.0f - btnH);
    ImVec2 cb1 = ImVec2(cb0.x + btnW, cb0.y + btnH);
    ImVec2 mouse = io.MousePos;
    bool ch = (mouse.x >= cb0.x && mouse.x <= cb1.x && mouse.y >= cb0.y && mouse.y <= cb1.y);
    dl->AddRectFilled(cb0, cb1, C(ch ? ImColor(55,55,70) : ImColor(42,42,55)), 5.0f * o);
    dl->AddRect(cb0, cb1, C(ImColor(65,65,80)), 5.0f * o);
    ImVec2 okTs = ImGui::CalcTextSize("OK");
    dl->AddText(ImGui::GetFont(), 14.0f * o, ImVec2(cb0.x + (btnW - okTs.x) * 0.5f, cb0.y + (btnH - okTs.y) * 0.5f), C(ImColor(200,200,215,(int)(255*o))), "OK");
    if ((ch && io.MouseClicked[0]) || ImGui::IsKeyPressed(ImGuiKey_Escape) || ImGui::IsKeyPressed(ImGuiKey_Enter))
        d.open = false;
}

bool M_BottomDrawer(const char* title, ImVec2 screenSize, float heightPercent, ImColor accent)
{
    static std::map<const char*, struct { bool open; float anim; float dragOffset; bool dragging; float dragStartY; float dragVelocity; float contentScroll; }> s_drawers;
    auto& d = s_drawers[title];
    ImDrawList* dl = ImGui::GetOverlayDrawList();
    ImGuiIO& io = ImGui::GetIO();
    ImVec2 ss = screenSize;
    float targetH = ss.y * ImClamp(heightPercent, 0.1f, 0.9f);
    if (!d.open)
    {
        d.open = true;
        d.anim = 0.0f;
        d.dragOffset = 0.0f;
        d.dragging = false;
        d.dragVelocity = 0.0f;
    }
    d.anim += (1.0f - d.anim) * ImClamp(io.DeltaTime * 8.0f, 0.0f, 1.0f);
    d.dragVelocity *= 0.9f;
    if (!io.MouseDown[0]) d.dragging = false;
    float drawH = targetH * d.anim + d.dragOffset + d.dragVelocity;
    if (drawH < 0.0f) drawH = 0.0f;
    if (drawH > ss.y * 0.95f) drawH = ss.y * 0.95f;
    dl->AddRectFilled(ImVec2(0,0), ss, C(ImColor(0,0,0,(int)(110 * d.anim))));
    float y0 = ss.y - drawH;
    ImVec2 p0 = ImVec2(0, y0);
    ImVec2 p1 = ImVec2(ss.x, ss.y);
    dl->AddRectFilled(p0, p1, C(ImColor(26,26,34)), 16.0f * d.anim, ImDrawFlags_RoundCornersTop);
    dl->AddLine(ImVec2(1.0f, y0), ImVec2(ss.x - 1.0f, y0), C(ImColor(48,48,60)));
    float handleW = 55.0f;
    float handleH = 5.0f;
    ImVec2 handlePos = ImVec2(ss.x * 0.5f - handleW * 0.5f, y0 + 12.0f);
    dl->AddRectFilled(handlePos, ImVec2(handlePos.x + handleW, handlePos.y + handleH), C(ImColor(85,85,100)), 3.0f);
    ImRect handleRect(handlePos, ImVec2(handlePos.x + handleW, handlePos.y + handleH + 14.0f));
    if (io.MouseDown[0] && handleRect.Contains(io.MousePos))
    {
        if (!d.dragging) { d.dragging = true; d.dragStartY = io.MousePos.y; d.dragVelocity = 0.0f; }
    }
    if (d.dragging && io.MouseDown[0])
    {
        d.dragOffset = io.MousePos.y - d.dragStartY;
        d.dragVelocity = d.dragOffset * 0.1f;
        if (d.dragOffset < -targetH * 0.3f)
        {
            d.open = false;
            d.dragging = false;
            d.dragOffset = 0.0f;
            d.dragVelocity = 0.0f;
        }
    }
    if (d.dragging && !io.MouseDown[0])
    {
        if (d.dragOffset > targetH * 0.15f)
        {
            d.open = false;
            d.dragging = false;
            d.dragOffset = 0.0f;
            d.dragVelocity = 0.0f;
        }
        else
        {
            d.dragging = false;
            d.dragOffset = 0.0f;
            d.dragVelocity = 0.0f;
        }
    }
    ImVec2 ts = ImGui::CalcTextSize(title);
    dl->AddText(ImGui::GetFont(), 16.0f * d.anim, ImVec2(18.0f, y0 + 16.0f), C(accent), title);
    float closeX = ss.x - 34.0f;
    float closeY = y0 + 14.0f;
    bool ch = io.MousePos.x >= closeX - 14.0f && io.MousePos.x <= closeX + 14.0f && io.MousePos.y >= closeY - 10.0f && io.MousePos.y <= closeY + 18.0f;
    ImU32 closeCol = ch ? C(ImColor(255,90,90)) : C(ImColor(130,130,150));
    dl->AddCircleFilled(ImVec2(closeX, closeY + 2.0f), 10.0f, ch ? C(ImColor(255,60,60,30)) : C(ImColor(0,0,0,0)));
    dl->AddText(ImGui::GetFont(), 18.0f * d.anim, ImVec2(closeX - 7.0f, closeY - 9.0f), closeCol, "X");
    if (ch && io.MouseClicked[0]) { d.open = false; d.dragging = false; d.dragOffset = 0.0f; }
    if (ImGui::IsKeyPressed(ImGuiKey_Escape)) { d.open = false; d.dragging = false; }
    bool hoverContent = io.MousePos.y > y0 + 50.0f && io.MousePos.y < ss.y && io.MousePos.x > 0 && io.MousePos.x < ss.x;
    if (hoverContent && !d.dragging)
    {
        d.contentScroll -= io.MouseWheel * 10.0f;
        float maxContentScroll = ImMax(0.0f, ss.y * 0.5f - drawH + 60.0f);
        d.contentScroll = ImClamp(d.contentScroll, 0.0f, maxContentScroll);
    }
    ImVec2 contentArea = ImVec2(ss.x - 36.0f, drawH - 60.0f);
    if (d.open && contentArea.y > 0)
    {
        ImVec2 caPos = ImVec2(18.0f, y0 + 50.0f);
        dl->PushClipRect(caPos, ImVec2(caPos.x + contentArea.x, caPos.y + contentArea.y), true);
        ImVec2 caEnd = ImVec2(caPos.x + contentArea.x, caPos.y + contentArea.y);
        dl->AddRectFilled(caPos, caEnd, C(ImColor(22,22,30)));
        dl->AddText(ImGui::GetFont(), 12.0f, ImVec2(caPos.x + 10.0f, caPos.y + 10.0f - d.contentScroll), C(ImColor(150,150,165)), "Drawer content area");
        dl->PopClipRect();
    }
    return d.open;
}

int M_ContextMenu(const char* label, ImVec2 position, const char** items, int count, int selected)
{
    static std::map<const char*, struct { bool open; int result; float anim; float hoverAnim[32]; int hoverIdx; int kbIdx; }> s_menus;
    auto& m = s_menus[label];
    if (!m.open) { m.open = true; m.result = -1; m.anim = 0.0f; m.hoverIdx = -1; m.kbIdx = 0; for (int i = 0; i < 32 && i < count; ++i) m.hoverAnim[i] = 0.0f; }
    m.anim += (1.0f - m.anim) * ImClamp(ImGui::GetIO().DeltaTime * 12.0f, 0.0f, 1.0f);
    ImDrawList* dl = ImGui::GetOverlayDrawList();
    ImGuiIO& io = ImGui::GetIO();
    ImVec2 mouse = io.MousePos;
    float itemH = 30.0f;
    float maxW = 140.0f;
    float* itemTextW = (float*)alloca(count * sizeof(float));
    int nonSepCount = 0;
    for (int i = 0; i < count; ++i)
    {
        if (items[i][0] == '-') { itemTextW[i] = 0; continue; }
        float tw = ImGui::CalcTextSize(items[i]).x;
        itemTextW[i] = tw;
        maxW = ImMax(maxW, tw + 56.0f);
        nonSepCount++;
    }
    float w = maxW;
    int sepCount = 0;
    for (int i = 0; i < count; ++i) if (items[i][0] == '-') sepCount++;
    float h = (count - sepCount) * itemH + sepCount * 10.0f;
    ImVec2 p0 = ImVec2(position.x, position.y);
    ImVec2 p1 = ImVec2(p0.x + w, p0.y + h);
    if (p1.x > io.DisplaySize.x - 4.0f) { p0.x = io.DisplaySize.x - w - 6.0f; p1.x = io.DisplaySize.x - 6.0f; }
    if (p1.y > io.DisplaySize.y - 4.0f) { p0.y = io.DisplaySize.y - h - 6.0f; p1.y = io.DisplaySize.y - 6.0f; }
    if (p0.x < 4.0f) { p0.x = 4.0f; p1.x = p0.x + w; }
    if (p0.y < 4.0f) { p0.y = 4.0f; p1.y = p0.y + h; }
    dl->AddRectFilled(p0, p1, C(ImColor(30,30,40)), 6.0f * m.anim);
    dl->AddRect(p0, p1, C(ImColor(60,60,75)), 6.0f * m.anim);
    dl->AddShadowRect(p0, p1, C(ImColor(0,0,0,140)), 14.0f, ImVec2(4,4));
    int result = -1;
    float yOff = 0.0f;
    int visIdx = 0;
    for (int i = 0; i < count; ++i)
    {
        bool isSep = (items[i][0] == '-');
        if (isSep)
        {
            float sepY = p0.y + yOff + 5.0f;
            dl->AddLine(ImVec2(p0.x + 12.0f, sepY), ImVec2(p1.x - 12.0f, sepY), C(ImColor(50,50,65)));
            yOff += 10.0f;
            continue;
        }
        ImVec2 ip0 = ImVec2(p0.x, p0.y + yOff);
        ImVec2 ip1 = ImVec2(p1.x, ip0.y + itemH);
        bool hovered = (mouse.x >= ip0.x && mouse.x <= ip1.x && mouse.y >= ip0.y && mouse.y <= ip1.y);
        bool sel = (i == selected);
        if (hovered) m.hoverIdx = i;
        if (i < 32) m.hoverAnim[i] += ((i == m.hoverIdx ? 1.0f : 0.0f) - m.hoverAnim[i]) * ImClamp(io.DeltaTime * 12.0f, 0.0f, 1.0f);
        if (hovered || (m.hoverAnim[i] > 0.05f && i < 32))
        {
            float hov = (i < 32) ? m.hoverAnim[i] : (hovered ? 1.0f : 0.0f);
            ImColor hovBg = ImColor(50,50,68, (int)(255 * hov));
            dl->AddRectFilled(ip0, ip1, C(hovBg), 3.0f);
        }
        if (hovered)
            dl->AddRect(ip0, ip1, C(ImColor(70,70,90,80)), 3.0f);
        ImU32 textCol;
        if (sel) textCol = C(ImColor(70,210,255));
        else textCol = C(ImColor(220,220,235));
        float textX = ip0.x + 16.0f;
        dl->AddText(ImGui::GetFont(), 13.0f * m.anim, ImVec2(textX, ip0.y + (itemH - ImGui::CalcTextSize(items[i]).y) * 0.5f), textCol, items[i]);
        if (sel)
        {
            ImU32 checkCol = C(ImColor(70,210,255));
            dl->AddText(ImGui::GetFont(), 13.0f * m.anim, ImVec2(ip1.x - 24.0f, ip0.y + (itemH - 13.0f) * 0.5f), checkCol, "✓");
        }
        if (io.MouseDown[0] && hovered && !io.MouseDownOwned[0])
            io.MouseDownOwned[0] = true;
        if (hovered && io.MouseReleased[0])
        {
            result = i;
            m.open = false;
        }
        if (isSep) continue;
        ImU32 shortCutCol = C(ImColor(100,100,115));
        if (i < 10)
        {
            char sc[4];
            snprintf(sc, sizeof(sc), "^%d", (i + 1) % 10);
            ImVec2 scs = ImGui::CalcTextSize(sc);
            dl->AddText(ImGui::GetFont(), 10.0f * m.anim, ImVec2(ip1.x - 22.0f - scs.x, ip0.y + (itemH - scs.y) * 0.5f), shortCutCol, sc);
        }
        yOff += itemH;
        visIdx++;
    }
    if (m.open)
    {
        if (ImGui::IsKeyPressed(ImGuiKey_DownArrow) || ImGui::IsKeyPressed(ImGuiKey_UpArrow))
        {
            int dir = ImGui::IsKeyPressed(ImGuiKey_DownArrow) ? 1 : -1;
            int newIdx = m.kbIdx;
            do {
                newIdx += dir;
                if (newIdx < 0) newIdx = count - 1;
                if (newIdx >= count) newIdx = 0;
            } while (items[newIdx][0] == '-' && newIdx != m.kbIdx);
            if (items[newIdx][0] != '-') m.kbIdx = newIdx;
        }
        bool kbEnter = ImGui::IsKeyPressed(ImGuiKey_Enter) || ImGui::IsKeyPressed(ImGuiKey_Space);
        if (kbEnter && items[m.kbIdx][0] != '-')
        {
            result = m.kbIdx;
            m.open = false;
        }
        if (m.kbIdx >= 0 && m.kbIdx < count && items[m.kbIdx][0] != '-')
        {
            float kbY = 0.0f;
            for (int i = 0; i < m.kbIdx; ++i) { if (items[i][0] == '-') kbY += 10.0f; else kbY += itemH; }
            ImVec2 kp0 = ImVec2(p0.x, p0.y + kbY);
            ImVec2 kp1 = ImVec2(p1.x, kp0.y + itemH);
            dl->AddRect(kp0, kp1, C(ImColor(0,200,255,180)), 3.0f, ImDrawFlags_None, 2.0f);
        }
    }
    if (io.MouseClicked[0])
    {
        bool inside = mouse.x >= p0.x && mouse.x <= p1.x && mouse.y >= p0.y && mouse.y <= p1.y;
        if (!inside) { m.open = false; result = -1; }
    }
    if (ImGui::IsKeyPressed(ImGuiKey_Escape)) { m.open = false; result = -1; }
    return result;
}

void M_TooltipPopup(const char* text, ImVec2 position, float maxWidth)
{
    static std::map<const char*, struct { bool open; float timer; float alpha; float scale; ImVec2 lastPos; }> s_tooltips;
    auto& t = s_tooltips[text];
    if (!t.open) { t.open = true; t.timer = 0.0f; t.alpha = 0.0f; t.scale = 0.0f; t.lastPos = position; }
    ImGuiIO& io = ImGui::GetIO();
    float mouseDist = sqrtf((io.MousePos.x - t.lastPos.x) * (io.MousePos.x - t.lastPos.x) + (io.MousePos.y - t.lastPos.y) * (io.MousePos.y - t.lastPos.y));
    if (mouseDist > 8.0f) { t.open = false; t.alpha = 0.0f; return; }
    t.timer += io.DeltaTime;
    if (t.timer < 0.2f)
    {
        t.alpha = t.timer / 0.2f;
        t.scale = t.timer / 0.2f;
    }
    else if (t.timer > 4.0f)
    {
        t.alpha = ImMax(0.0f, 1.0f - (t.timer - 4.0f) * 1.2f);
        t.scale = 1.0f;
        if (t.alpha <= 0.0f) { t.open = false; t.alpha = 0.0f; }
    }
    else
    {
        t.alpha = 1.0f;
        t.scale = 1.0f;
    }
    if (t.alpha <= 0.01f) return;
    ImDrawList* dl = ImGui::GetOverlayDrawList();
    ImVec2 textSize = ImGui::CalcTextSize(text, NULL, false, maxWidth);
    float w = textSize.x + 22.0f;
    float h = textSize.y + 16.0f;
    ImVec2 pos = position;
    ImVec2 ss = io.DisplaySize;
    bool flipUp = pos.y + h + 16.0f > ss.y;
    if (!flipUp)
        pos.y += 16.0f;
    else
        pos.y -= h + 6.0f;
    if (pos.x + w > ss.x - 6.0f) pos.x = ss.x - w - 6.0f;
    if (pos.x < 6.0f) pos.x = 6.0f;
    if (pos.y < 6.0f) pos.y = 6.0f;
    if (pos.y + h > ss.y - 6.0f) pos.y = ss.y - h - 6.0f;
    ImVec2 p0 = pos;
    ImVec2 p1 = ImVec2(p0.x + w, p0.y + h);
    float sc = 0.9f + 0.1f * t.scale;
    ImVec2 cp0 = ImVec2(pos.x - w * (sc - 1.0f) * 0.5f, pos.y - h * (sc - 1.0f) * 0.5f);
    ImVec2 cp1 = ImVec2(cp0.x + w * sc, cp0.y + h * sc);
    ImColor bg(14, 14, 20, (int)(220 * t.alpha));
    ImColor border(65, 65, 80, (int)(130 * t.alpha));
    dl->AddRectFilled(cp0, cp1, C(bg), 9.0f);
    dl->AddRect(cp0, cp1, C(border), 9.0f);
    float arrowSize = 7.0f;
    ImVec2 arrowTip = ImVec2(position.x, flipUp ? position.y - 2.0f : position.y);
    if (arrowTip.x < cp0.x + 12.0f) arrowTip.x = cp0.x + 12.0f;
    if (arrowTip.x > cp1.x - 12.0f) arrowTip.x = cp1.x - 12.0f;
    if (!flipUp)
    {
        ImVec2 ab = ImVec2(arrowTip.x, arrowTip.y + arrowSize);
        dl->AddTriangleFilled(arrowTip, ImVec2(arrowTip.x - arrowSize, ab.y), ImVec2(arrowTip.x + arrowSize, ab.y), C(ImColor(14,14,20,(int)(220*t.alpha))));
        dl->AddLine(ImVec2(arrowTip.x - arrowSize + 1.0f, ab.y), ImVec2(arrowTip.x + arrowSize - 1.0f, ab.y), C(ImColor(65,65,80,(int)(130*t.alpha))));
    }
    else
    {
        ImVec2 ab = ImVec2(arrowTip.x, arrowTip.y - arrowSize);
        dl->AddTriangleFilled(arrowTip, ImVec2(arrowTip.x - arrowSize, ab.y), ImVec2(arrowTip.x + arrowSize, ab.y), C(ImColor(14,14,20,(int)(220*t.alpha))));
        dl->AddLine(ImVec2(arrowTip.x - arrowSize + 1.0f, ab.y), ImVec2(arrowTip.x + arrowSize - 1.0f, ab.y), C(ImColor(65,65,80,(int)(130*t.alpha))));
    }
    ImColor txtColor(220, 220, 235, (int)(255 * t.alpha));
    dl->AddText(ImGui::GetFont(), 12.0f, ImVec2(cp0.x + 11.0f, cp0.y + 8.0f), C(txtColor), text, NULL, maxWidth);
    if (t.timer < 2.0f)
    {
        float pulse = sinf(t.timer * 4.0f) * 0.3f + 0.7f;
        ImColor pulseCol = ImColor(100,100,120,(int)(30 * t.alpha * pulse));
        dl->AddRect(cp0, cp1, C(pulseCol), 9.0f);
    }
    if (t.timer > 3.0f && t.alpha < 0.5f)
    {
        dl->AddRectFilled(cp0, cp1, C(ImColor(14,14,20,(int)(220 * t.alpha))), 9.0f);
        dl->AddRect(cp0, cp1, C(ImColor(65,65,80,(int)(130 * t.alpha))), 9.0f);
        dl->AddText(ImGui::GetFont(), 12.0f, ImVec2(cp0.x + 11.0f, cp0.y + 8.0f), C(txtColor), text, NULL, maxWidth);
    }
}

bool M_LoadingOverlay(const char* label, const char* message)
{
    static bool s_open = false;
    static float s_spin = 0.0f;
    if (!s_open) { s_open = true; s_spin = 0.0f; }
    ImDrawList* dl = ImGui::GetOverlayDrawList();
    ImGuiIO& io = ImGui::GetIO();
    s_spin += io.DeltaTime * 4.0f;
    ImVec2 ss = io.DisplaySize;
    dl->AddRectFilled(ImVec2(0,0), ss, C(ImColor(0,0,0,180)));
    ImVec2 center = ImVec2(ss.x * 0.5f, ss.y * 0.5f);
    float spinR = 20.0f;
    int numDots = 8;
    for (int i = 0; i < numDots; ++i)
    {
        float angle = s_spin + (float)i / (float)numDots * IM_PI * 2.0f;
        float x = center.x + cosf(angle) * spinR;
        float y = center.y + sinf(angle) * spinR;
        float a = (float)i / (float)numDots;
        dl->AddCircleFilled(ImVec2(x, y), 3.0f, C(ImColor(200,200,215,(int)(255 * a))), 16);
    }
    dl->AddCircle(center, spinR + 5.0f, C(ImColor(80,80,95,100)), 32, 1.0f);
    ImVec2 ts = ImGui::CalcTextSize(message);
    dl->AddText(ImGui::GetFont(), 14.0f, ImVec2(center.x - ts.x * 0.5f, center.y + spinR + 16.0f), C(ImColor(200,200,215)), message);
    return s_open;
}

bool M_ToastNotification(const char* message, float duration, ImColor type)
{
    static bool s_open = false;
    static float s_timer = 0.0f;
    if (!s_open) { s_open = true; s_timer = 0.0f; }
    s_timer += ImGui::GetIO().DeltaTime;
    float alpha = 1.0f;
    if (s_timer < 0.3f)
        alpha = s_timer / 0.3f;
    else if (s_timer > duration - 0.5f && duration > 0)
        alpha = (duration - s_timer + 0.5f) / 0.5f;
    alpha = ImClamp(alpha, 0.0f, 1.0f);
    if (alpha <= 0.01f) { s_open = false; return false; }
    ImDrawList* dl = ImGui::GetOverlayDrawList();
    ImVec2 ss = ImGui::GetIO().DisplaySize;
    ImVec2 ts = ImGui::CalcTextSize(message);
    float w = ts.x + 40.0f;
    float h = ts.y + 24.0f;
    ImVec2 toPos = ImVec2(ss.x * 0.5f - w * 0.5f, 20.0f);
    dl->AddRectFilled(toPos, ImVec2(toPos.x + w, toPos.y + h), C(ImColor(28,28,36,(int)(230*alpha))), 8.0f);
    dl->AddRect(toPos, ImVec2(toPos.x + w, toPos.y + h), C(ImColor(55,55,70,(int)(200*alpha))), 8.0f);
    dl->AddRectFilled(ImVec2(toPos.x, toPos.y), ImVec2(toPos.x + 4.0f, toPos.y + h), C(type), 4.0f);
    dl->AddText(ImGui::GetFont(), 13.0f, ImVec2(toPos.x + 20.0f, toPos.y + (h - ts.y) * 0.5f), C(ImColor(220,220,235,(int)(255*alpha))), message);
    return true;
}
