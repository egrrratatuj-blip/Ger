#include "TabPlayers.h"
#include "../ui_integration.h"
#include "../../../imgui/imgui.h"
#include "../../../imgui/imgui_internal.h"
#include "../widgets/Widgets_Switches.h"
#include "../widgets/Widgets_Buttons.h"
#include "../widgets/Widgets_Containers.h"
#include "../widgets/Widgets_Sliders.h"
#include "../widgets/Widgets_Input.h"

static ImU32 C(const ImColor& c)
{
    return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w));
}

extern Config g_Cfg;
extern Toggles g_Tog;
extern ESP g_Esp;
extern Aimbot g_Bot;

static const char* s_filterOptions[] = {"All", "Enemies", "Teammates", "Visible", "Alive"};
static int s_filterIndex = 0;
static char s_searchBuf[128] = "";
static int s_selectedIndex = -1;
static bool s_initialScroll = true;

static float clampF(float v, float lo, float hi)
{
    return v < lo ? lo : (v > hi ? hi : v);
}

static ImColor healthColor(float health, float maxHealth)
{
    if (maxHealth <= 0.0f) return ImColor(100, 100, 100, 255);
    float t = clampF(health / maxHealth, 0.0f, 1.0f);
    float r, g, b;
    if (t < 0.5f)
    {
        float s = t / 0.5f;
        r = 255.0f;
        g = 255.0f * s;
        b = 0.0f;
    }
    else
    {
        float s = (t - 0.5f) / 0.5f;
        r = 255.0f * (1.0f - s);
        g = 255.0f;
        b = 0.0f;
    }
    return ImColor((int)r, (int)g, (int)b, 255);
}

static bool isRowHovered(ImVec2 rowPos, float rowH, float contentW)
{
    return ImGui::IsMouseHoveringRect(
        rowPos,
        ImVec2(rowPos.x + contentW, rowPos.y + rowH)
    );
}

void DrawTabPlayers(ImDrawList* dl, ImVec2 contentArea, ImVec2 contentPos)
{
    bool hasPlayers = (&g_Esp != nullptr && g_Esp.PlayerCount > 0);
    if (!hasPlayers)
    {
        ImGui::SetCursorScreenPos(ImVec2(contentPos.x, contentPos.y));
        ImColor msgCol(150, 150, 180, 180);
        dl->AddText(ImVec2(contentPos.x + 20.0f, contentPos.y + 20.0f), C(msgCol), "No player data available.");
        dl->AddText(ImVec2(contentPos.x + 20.0f, contentPos.y + 44.0f), C(ImColor(110, 110, 140, 140)), "Waiting for ESP module to initialize...");
        ImGui::Dummy(ImVec2(0, 80.0f));
        return;
    }

    ImColor accent = g_Cfg.AccentColor;
    ImColor accent2 = g_Cfg.AccentColor2;
    float time = ImGui::GetTime();
    float pulse = sinf(time * 3.0f) * 0.5f + 0.5f;

    int maxPlayers = g_Esp.PlayerCount;
    if (maxPlayers > 5000) maxPlayers = 5000;
    int localTeam = (maxPlayers > 0) ? g_Esp.Players[0].TeamID : 0;

    int filtered[5000];
    int filteredCount = 0;
    for (int i = 0; i < maxPlayers; i++)
    {
        PlayerData& p = g_Esp.Players[i];
        if (s_searchBuf[0] != 0)
        {
            bool nameMatch = (strstr(p.PlayerName, s_searchBuf) != NULL);
            bool wepMatch = (strstr(p.WeaponName, s_searchBuf) != NULL);
            char idStr[16];
            snprintf(idStr, sizeof(idStr), "%d", p.PlayerID);
            bool idMatch = (strstr(idStr, s_searchBuf) != NULL);
            if (!nameMatch && !wepMatch && !idMatch)
                continue;
        }
        switch (s_filterIndex)
        {
            case 1:
                if (p.TeamID == localTeam) continue;
                break;
            case 2:
                if (p.TeamID != localTeam) continue;
                break;
            case 3:
                if (!p.IsVisible) continue;
                break;
            case 4:
                if (!p.IsAlive) continue;
                break;
            default:
                break;
        }
        filtered[filteredCount++] = i;
    }

    if (s_selectedIndex >= maxPlayers) s_selectedIndex = -1;
    bool selectedStillValid = false;
    for (int fi = 0; fi < filteredCount; fi++)
    {
        if (filtered[fi] == s_selectedIndex) { selectedStillValid = true; break; }
    }
    if (!selectedStillValid) s_selectedIndex = -1;

    {
        ImVec2 cp = ImGui::GetCursorScreenPos();
        (void)cp;
        M_CyberHeader("PLAYER LIST", accent, "Browse and manage detected players");
    }

    M_SearchBar("##plyrSearch", s_searchBuf, sizeof(s_searchBuf), accent);

    {
        int prev = s_filterIndex;
        ImGui::SetCursorScreenPos(ImVec2(contentPos.x + 4.0f, ImGui::GetCursorScreenPos().y + 2.0f));
        M_SegmentedToggle("Filter", &s_filterIndex, s_filterOptions, 5, accent);
        if (prev != s_filterIndex)
            s_selectedIndex = -1;
        ImGui::Dummy(ImVec2(0, 4.0f));
    }

    {
        ImVec2 btnPos = ImGui::GetCursorScreenPos();
        ImGui::SetCursorScreenPos(ImVec2(btnPos.x + 4.0f, btnPos.y));
        if (M_GradientButton("Refresh List", ImVec2(contentArea.x * 0.28f, 30.0f), accent, accent2, 5.0f))
        {
            s_selectedIndex = -1;
            s_initialScroll = true;
        }
        char countStr[32];
        snprintf(countStr, sizeof(countStr), "%d / %d", filteredCount, maxPlayers);
        ImVec2 countPos = ImGui::GetCursorScreenPos();
        if (countPos.y < btnPos.y + 4.0f)
        {
            float lblX = btnPos.x + contentArea.x * 0.32f;
            float lblY = btnPos.y + 4.0f;
            ImColor countLabelCol(180, 180, 220, 220);
            dl->AddText(ImVec2(lblX, lblY), C(countLabelCol), "Players:");
            ImVec2 cvSize = ImGui::CalcTextSize(countStr);
            float cvX = lblX + ImGui::CalcTextSize("Players:").x + 6.0f;
            ImColor countValCol = accent;
            countValCol.Value.w *= 0.9f;
            dl->AddText(ImVec2(cvX, lblY), C(countValCol), countStr);
            ImGui::Dummy(ImVec2(0, 30.0f));
        }
        else
        {
            M_InfoRow("Players", countStr, accent, nullptr);
        }
    }

    float listH = contentArea.y * 0.42f;
    if (listH < 140.0f) listH = 140.0f;
    if (listH > contentArea.y - 260.0f) listH = contentArea.y - 260.0f;
    if (listH < 80.0f) listH = 80.0f;

    ImVec2 divPos = ImGui::GetCursorScreenPos();
    ImColor divCol = accent;
    divCol.Value.w *= 0.12f;
    dl->AddLine(ImVec2(divPos.x + 4.0f, divPos.y), ImVec2(divPos.x + contentArea.x - 4.0f, divPos.y), C(divCol), 1.0f);
    ImGui::Dummy(ImVec2(0, 6.0f));

    ImGui::BeginChild("##PlayerList", ImVec2(contentArea.x, listH), false,
        ImGuiWindowFlags_AlwaysVerticalScrollbar);

    float rowH = 38.0f;
    float contentW = ImGui::GetContentRegionAvail().x;
    ImGuiIO& io = ImGui::GetIO();

    if (filteredCount == 0)
    {
        float emptyY = ImGui::GetCursorScreenPos().y + 16.0f;
        ImColor emptyCol(130, 130, 160, 160);
        const char* emptyMsg = "No players match the current filter.";
        if (s_searchBuf[0] != 0)
            emptyMsg = "No players match your search query.";
        else if (s_filterIndex > 0)
            emptyMsg = "No players match the selected filter.";
        dl->AddText(ImVec2(contentPos.x + 20.0f, emptyY), C(emptyCol), emptyMsg);
        ImGui::Dummy(ImVec2(0, 50.0f));
    }

    for (int fi = 0; fi < filteredCount; fi++)
    {
        int pi = filtered[fi];
        PlayerData& p = g_Esp.Players[pi];
        ImVec2 rowPos = ImGui::GetCursorScreenPos();
        ImVec2 rowEnd = ImVec2(rowPos.x + contentW, rowPos.y + rowH);
        bool isSelf = (pi == 0);
        bool isSelected = (pi == s_selectedIndex);
        bool isHovered = isRowHovered(rowPos, rowH, contentW);

        if (isSelected)
        {
            ImColor selBg(
                (int)(accent.Value.x * 255.0f * 0.12f),
                (int)(accent.Value.y * 255.0f * 0.12f),
                (int)(accent.Value.z * 255.0f * 0.12f),
                200
            );
            dl->AddRectFilled(rowPos, rowEnd, C(selBg), 4.0f);
            ImColor selBorder = accent;
            selBorder.Value.w = 0.25f + pulse * 0.15f;
            dl->AddRect(rowPos, rowEnd, C(selBorder), 4.0f, ImDrawFlags_RoundCornersAll, 1.5f);
        }
        else if (isHovered)
        {
            dl->AddRectFilled(rowPos, rowEnd, C(ImColor(255, 255, 255, 8)), 4.0f);
        }

        ImColor dotColor;
        if (isSelf)
            dotColor = ImColor(0, 255, 120);
        else if (p.TeamID == localTeam)
            dotColor = ImColor(0, 150, 255);
        else
            dotColor = ImColor(255, 60, 60);

        if (p.IsVisible && !isSelf)
        {
            dotColor.Value.x = dotColor.Value.x * 0.7f + 0.3f;
            dotColor.Value.y = dotColor.Value.y * 0.7f + 0.3f;
            dotColor.Value.z = dotColor.Value.z * 0.7f + 0.3f;
        }

        dl->AddCircleFilled(ImVec2(rowPos.x + 14.0f, rowPos.y + rowH * 0.5f), 5.0f, C(dotColor), 12);
        ImColor dotGlow = dotColor;
        dotGlow.Value.w = 0.2f;
        dl->AddCircleFilled(ImVec2(rowPos.x + 14.0f, rowPos.y + rowH * 0.5f), 8.0f, C(dotGlow), 12);

        float nameX = rowPos.x + 28.0f;
        float nameY = rowPos.y + (rowH - ImGui::GetTextLineHeight()) * 0.5f - 2.0f;
        ImColor nameCol = isSelf ? ImColor(255, 255, 255) : (isSelected ? ImColor(240, 240, 255) : ImColor(200, 200, 230));
        if (isSelf)
        {
            ImColor boldGlow = ImColor(0, 255, 120, (int)(30 + pulse * 20));
            dl->AddText(ImVec2(nameX + 1.0f, nameY + 1.0f), C(boldGlow), p.PlayerName);
        }
        dl->AddText(ImVec2(nameX, nameY), C(nameCol), p.PlayerName);

        float nameEndX = nameX + ImGui::CalcTextSize(p.PlayerName).x + 6.0f;
        if (p.IsBot && nameEndX < rowPos.x + contentW * 0.5f)
        {
            ImColor botBadge(255, 150, 50, 200);
            dl->AddText(ImVec2(nameEndX, nameY), C(botBadge), "[BOT]");
        }

        {
            char distBuf[24];
            snprintf(distBuf, sizeof(distBuf), "%.0fm", p.Distance);
            ImVec2 distSize = ImGui::CalcTextSize(distBuf);
            float distX = rowPos.x + contentW - distSize.x - 80.0f;
            float distY = rowPos.y + (rowH - distSize.y) * 0.5f;
            ImColor distCol(130, 130, 165, isHovered ? 220 : 180);
            dl->AddText(ImVec2(distX, distY), C(distCol), distBuf);
        }

        {
            float hpBarX = rowPos.x + contentW - 74.0f;
            float hpBarY = rowPos.y + (rowH - 6.0f) * 0.5f;
            float hpW = 60.0f;
            float hpH = 6.0f;
            ImColor hpBg(20, 20, 35, 220);
            dl->AddRectFilled(ImVec2(hpBarX, hpBarY), ImVec2(hpBarX + hpW, hpBarY + hpH), C(hpBg), 3.0f);
            float hpPct = 0.0f;
            if (p.MaxHealth > 0.0f) hpPct = clampF(p.Health / p.MaxHealth, 0.0f, 1.0f);
            if (hpPct > 0.005f)
            {
                ImColor hpCol = healthColor(p.Health, p.MaxHealth);
                float fillW = (hpW - 2.0f) * hpPct;
                dl->AddRectFilled(ImVec2(hpBarX + 1.0f, hpBarY + 1.0f),
                    ImVec2(hpBarX + 1.0f + fillW, hpBarY + hpH - 1.0f), C(hpCol), 2.0f);
            }
        }

        {
            float iconX = rowPos.x + contentW - 14.0f;
            float iconY = rowPos.y + (rowH - 10.0f) * 0.5f;
            if (p.IsBot) iconX -= 14.0f;
            if (p.IsAlive) iconX -= 14.0f;
            if (p.IsVisible) iconX -= 14.0f;
            if (p.IsVisible)
            {
                ImColor vCol(0, 200, 100, 200);
                dl->AddText(ImVec2(iconX, iconY), C(vCol), "V");
                iconX += 14.0f;
            }
            if (p.IsAlive)
            {
                ImColor aCol(100, 200, 255, 200);
                dl->AddText(ImVec2(iconX, iconY), C(aCol), "A");
                iconX += 14.0f;
            }
            if (p.IsBot)
            {
                ImColor bCol(255, 160, 60, 200);
                dl->AddText(ImVec2(iconX, iconY), C(bCol), "B");
                iconX += 14.0f;
            }
        }

        ImColor sepCol(255, 255, 255, 3);
        dl->AddLine(ImVec2(rowPos.x + 8.0f, rowPos.y + rowH),
            ImVec2(rowPos.x + contentW - 8.0f, rowPos.y + rowH), C(sepCol), 1.0f);

        if (isHovered)
        {
            if (ImGui::IsMouseClicked(0))
            {
                s_selectedIndex = pi;
            }
            if (ImGui::IsMouseDoubleClicked(0))
            {
                s_selectedIndex = pi;
                g_Cfg.SelectedTarget = pi;
                ImColor flashCol = accent;
                flashCol.Value.w = 0.4f;
                dl->AddRectFilled(rowPos, rowEnd, C(flashCol), 4.0f);
            }
        }

        ImGui::Dummy(ImVec2(0, rowH));
    }

    if (filteredCount > 0 && ImGui::IsWindowFocused())
    {
        bool arrowUp = ImGui::IsKeyPressed(ImGuiKey_UpArrow);
        bool arrowDown = ImGui::IsKeyPressed(ImGuiKey_DownArrow);
        if (arrowUp || arrowDown)
        {
            if (s_selectedIndex < 0 || !selectedStillValid)
            {
                s_selectedIndex = filtered[0];
            }
            else
            {
                int curIdx = -1;
                for (int fi = 0; fi < filteredCount; fi++)
                {
                    if (filtered[fi] == s_selectedIndex) { curIdx = fi; break; }
                }
                if (curIdx >= 0)
                {
                    if (arrowDown) curIdx = (curIdx + 1) % filteredCount;
                    else curIdx = (curIdx - 1 + filteredCount) % filteredCount;
                    s_selectedIndex = filtered[curIdx];
                }
            }
        }
    }

    ImGui::EndChild();

    {
        ImVec2 sepPos = ImGui::GetCursorScreenPos();
        ImColor sepCol2 = accent;
        sepCol2.Value.w *= 0.10f;
        dl->AddLine(ImVec2(sepPos.x + 4.0f, sepPos.y), ImVec2(sepPos.x + contentArea.x - 4.0f, sepPos.y), C(sepCol2), 1.0f);
        ImGui::Dummy(ImVec2(0, 6.0f));
    }

    // --- Selected Player Details ---
    if (s_selectedIndex >= 0 && s_selectedIndex < maxPlayers)
    {
        PlayerData& sel = g_Esp.Players[s_selectedIndex];
        bool selIsSelf = (s_selectedIndex == 0);
        ImColor selAccent = accent;
        if (selIsSelf) selAccent = ImColor(0, 255, 120);

        M_CyberHeader("PLAYER DETAILS", selAccent, sel.PlayerName);

        M_InfoRow("Name", sel.PlayerName, ImColor(255, 255, 255, 240), nullptr);

        {
            char hpBuf[32];
            ImColor hpCol = healthColor(sel.Health, sel.MaxHealth);
            snprintf(hpBuf, sizeof(hpBuf), "%.0f / %.0f", sel.Health, sel.MaxHealth);
            M_InfoRow("Health", hpBuf, hpCol, nullptr);
        }

        {
            char armBuf[32];
            snprintf(armBuf, sizeof(armBuf), "%.0f", sel.Armor);
            M_InfoRow("Armor", armBuf, ImColor(100, 180, 255, 220), nullptr);
        }

        {
            char shdBuf[32];
            snprintf(shdBuf, sizeof(shdBuf), "%.0f", sel.Shield);
            M_InfoRow("Shield", shdBuf, ImColor(0, 200, 255, 220), nullptr);
        }

        {
            char distBuf[32];
            snprintf(distBuf, sizeof(distBuf), "%.0f m", sel.Distance);
            M_InfoRow("Distance", distBuf, ImColor(255, 200, 80, 220), nullptr);
        }

        M_InfoRow("Weapon", sel.WeaponName, ImColor(200, 150, 255, 220), nullptr);

        {
            char teamBuf[16];
            snprintf(teamBuf, sizeof(teamBuf), "%d", sel.TeamID);
            ImColor teamCol = (sel.TeamID == localTeam) ? ImColor(0, 150, 255, 220) : ImColor(255, 100, 100, 220);
            M_InfoRow("Team", teamBuf, teamCol, nullptr);
        }

        {
            char idBuf[16];
            snprintf(idBuf, sizeof(idBuf), "%d", sel.PlayerID);
            M_InfoRow("Player ID", idBuf, ImColor(180, 180, 220, 200), nullptr);
        }

        {
            char posBuf[64];
            snprintf(posBuf, sizeof(posBuf), "%.1f, %.1f, %.1f",
                sel.Position.X, sel.Position.Y, sel.Position.Z);
            M_InfoRow("Position", posBuf, ImColor(170, 170, 210, 200), nullptr);
        }

        M_BooleanIndicator("Visible", sel.IsVisible, ImColor(0, 255, 100, 230), ImColor(80, 80, 100, 180));

        {
            const char* statusText;
            ImColor statusCol;
            if (!sel.IsAlive)
            {
                statusText = "Dead";
                statusCol = ImColor(255, 60, 60, 220);
            }
            else if (sel.IsBot)
            {
                statusText = "Bot";
                statusCol = ImColor(255, 200, 50, 220);
            }
            else
            {
                statusText = "Alive";
                statusCol = ImColor(0, 255, 120, 220);
            }
            M_InfoRow("Status", statusText, statusCol, nullptr);
        }

        ImGui::Dummy(ImVec2(0, 6.0f));

        float buttonY = ImGui::GetCursorScreenPos().y;

        float btnW = (contentArea.x - 20.0f) * 0.5f;
        float btnH = 34.0f;
        float btnGap = 8.0f;
        bool isTarget = (g_Cfg.SelectedTarget == s_selectedIndex);

        {
            ImColor targetAccent = isTarget ? ImColor(0, 255, 100) : accent;
            ImColor targetAccent2 = isTarget ? ImColor(0, 200, 80) : accent2;
            ImGui::SetCursorScreenPos(ImVec2(contentPos.x + 4.0f, buttonY));
            if (M_GradientButton(isTarget ? "Set as Target [ACTIVE]" : "Set as Target",
                ImVec2(btnW, btnH), targetAccent, targetAccent2, 6.0f))
            {
                g_Cfg.SelectedTarget = s_selectedIndex;
            }
        }

        {
            ImGui::SetCursorScreenPos(ImVec2(contentPos.x + 4.0f + btnW + btnGap, buttonY));
            if (M_GradientButton("Spectate", ImVec2(btnW, btnH), accent, accent2, 6.0f))
            {
                // stub: spectate functionality placeholder
            }
        }

        {
            float row2Y = ImGui::GetCursorScreenPos().y + 4.0f;
            ImGui::SetCursorScreenPos(ImVec2(contentPos.x + 4.0f, row2Y));
            if (M_GradientButton("Teleport To", ImVec2(btnW, btnH), accent, accent2, 6.0f))
            {
                // stub: teleport functionality placeholder
            }
        }

        {
            float row2Y2 = ImGui::GetCursorScreenPos().y;
            if (row2Y2 < buttonY + btnH + 8.0f) row2Y2 = buttonY + btnH + 8.0f;
            ImGui::SetCursorScreenPos(ImVec2(contentPos.x + 4.0f + btnW + btnGap, row2Y2));
            if (M_GradientButton("Add to Whitelist", ImVec2(btnW, btnH), accent, accent2, 6.0f))
            {
                // stub: whitelist functionality placeholder
            }
        }

        ImGui::Dummy(ImVec2(0, 10.0f));

        {
            ImVec2 infoPos = ImGui::GetCursorScreenPos();
            ImColor infoBg(0, 0, 0, 40);
            dl->AddRectFilled(
                ImVec2(infoPos.x + 4.0f, infoPos.y),
                ImVec2(infoPos.x + contentArea.x - 4.0f, infoPos.y + 26.0f),
                C(infoBg), 4.0f);
            char summary[128];
            snprintf(summary, sizeof(summary),
                "HP: %.0f/%.0f | Dist: %.0fm | Team: %d | %s | %s",
                sel.Health, sel.MaxHealth, sel.Distance, sel.TeamID,
                sel.IsVisible ? "Visible" : "Hidden",
                sel.IsAlive ? (sel.IsBot ? "Bot" : "Alive") : "Dead");
            ImVec2 sumSize = ImGui::CalcTextSize(summary);
            float sumX = infoPos.x + (contentArea.x - sumSize.x) * 0.5f;
            ImColor sumCol(160, 160, 200, 180);
            dl->AddText(ImVec2(sumX, infoPos.y + (26.0f - sumSize.y) * 0.5f), C(sumCol), summary);
            ImGui::Dummy(ImVec2(0, 28.0f));
        }

        {
            ImVec2 addrPos = ImGui::GetCursorScreenPos();
            if (sel.Address != 0)
            {
                char addrStr[32];
                snprintf(addrStr, sizeof(addrStr), "0x%08X", (unsigned int)sel.Address);
                M_InfoRow("Address", addrStr, ImColor(140, 140, 180, 160), nullptr);
            }
            if (sel.BoneAddress != 0)
            {
                char boneStr[32];
                snprintf(boneStr, sizeof(boneStr), "0x%08X", (unsigned int)sel.BoneAddress);
                M_InfoRow("Bone Address", boneStr, ImColor(140, 140, 180, 160), nullptr);
            }
            (void)addrPos;
        }
    }
    else
    {
        ImVec2 noSelPos = ImGui::GetCursorScreenPos();
        ImColor noSelCol(120, 120, 150, 160);
        dl->AddText(ImVec2(noSelPos.x + 20.0f, noSelPos.y + 10.0f), C(noSelCol),
            "Select a player from the list above to view details.");
        dl->AddText(ImVec2(noSelPos.x + 20.0f, noSelPos.y + 32.0f), C(ImColor(100, 100, 130, 130)),
            "Double-click to set as aimbot target. Use arrow keys to navigate.");
        ImGui::Dummy(ImVec2(0, 60.0f));
    }

    // Bottom bar
    {
        ImVec2 bottomPos = ImGui::GetCursorScreenPos();
        float bottomY = bottomPos.y + 2.0f;
        ImColor bottomBg(0, 0, 0, 30);
        dl->AddRectFilled(
            ImVec2(contentPos.x, bottomY),
            ImVec2(contentPos.x + contentArea.x, bottomY + 2.0f),
            C(bottomBg), 0.0f);
        char footerBuf[64];
        int aliveCount = 0;
        int visibleCount = 0;
        int enemyCount = 0;
        for (int i = 0; i < maxPlayers; i++)
        {
            if (g_Esp.Players[i].IsAlive) aliveCount++;
            if (g_Esp.Players[i].IsVisible) visibleCount++;
            if (g_Esp.Players[i].TeamID != localTeam) enemyCount++;
        }
        snprintf(footerBuf, sizeof(footerBuf),
            "Total: %d  |  Alive: %d  |  Visible: %d  |  Enemies: %d",
            maxPlayers, aliveCount, visibleCount, enemyCount);
        ImVec2 footerSize = ImGui::CalcTextSize(footerBuf);
        float footerX = contentPos.x + (contentArea.x - footerSize.x) * 0.5f;
        ImColor footerCol(100, 100, 130, 120);
        dl->AddText(ImVec2(footerX, bottomY + 4.0f), C(footerCol), footerBuf);
        ImGui::Dummy(ImVec2(0, footerSize.y + 8.0f));
    }
}
