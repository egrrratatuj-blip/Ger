#include "GameOffsets.h"
#include <cmath>

GameOffsets::GameOffsets(MemoryIO *mem) {
    Mem = mem;
    Initialized = false;
    UnityBase = 0;
    UWorld = 0;
    GameInstance = 0;
    LocalPlayer = 0;
    PlayerController = 0;
    CameraManager = 0;
    EntityListPtr = 0;
    EntityCount = 0;
    CurrentGameID = -1;
    CameraFOV = 90.0f;
    CameraYaw = 0.0f;
    memset(ViewMatrix, 0, sizeof(ViewMatrix));
    memset(GamesTable, 0, sizeof(GamesTable));
    
    GamesTable[0].GamePackage = "com.catsbit.oxidesurvivalisland";
    GamesTable[0].GameModule = "libil2cpp.so";
    GamesTable[0].GameName = "Oxide Survival Island";
    GamesTable[0].OffsetUWorld = 0x0;
    GamesTable[0].OffsetGameInstance = 0x0;
    GamesTable[0].OffsetLocalPlayer = 0x0;
    GamesTable[0].OffsetPlayerController = 0x0;
    GamesTable[0].OffsetCameraManager = 0x70;
    GamesTable[0].OffsetEntityList = 0x0;
    GamesTable[0].OffsetEntityCount = 0x0;
    GamesTable[0].OffsetEntityBase = 0x0;
    GamesTable[0].OffsetEntityPos = 0xA0;
    GamesTable[0].OffsetEntityHead = 0x30;
    GamesTable[0].OffsetEntityHealth = 0x110;
    GamesTable[0].OffsetEntityMaxHealth = 0x114;
    GamesTable[0].OffsetEntityArmor = 0x118;
    GamesTable[0].OffsetEntityShield = 0x114;
    GamesTable[0].OffsetEntityName = 0xA0;
    GamesTable[0].OffsetEntityWeapon = 0x4A8;
    GamesTable[0].OffsetEntityTeam = 0x1C0;
    GamesTable[0].OffsetEntityAlive = 0xC0;
    GamesTable[0].OffsetEntityBone = 0x1E0;
    GamesTable[0].OffsetEntityMesh = 0x1A0;
    GamesTable[0].OffsetMatrix = 0x0;
    GamesTable[0].OffsetViewMatrix = 0x0;
    GamesTable[0].OffsetCameraPos = 0x0;
    GamesTable[0].OffsetCameraFOV = 0x0;
    GamesTable[0].OffsetRecoil = 0x2A0;
    GamesTable[0].OffsetSpread = 0x2A4;
    GamesTable[0].OffsetFireRate = 0x2A8;
    GamesTable[0].OffsetFireFlag = 0x28;
    GamesTable[0].OffsetAmmo = 0x1C0;
    GamesTable[0].OffsetMaxAmmo = 0x1C4;
    GamesTable[0].OffsetVelocity = 0x90;
    GamesTable[0].OffsetIsVisible = 0x0;
    GamesTable[0].TraceUWorld = {};
    GamesTable[0].TraceEntityList = {};
    
    GamesTable[1].GamePackage = "com.catsbit.oxidesurvivalisland";
    GamesTable[1].GameModule = "libunity.so";
    GamesTable[1].GameName = "Oxide Survival Island (Unity)";
    GamesTable[1].OffsetUWorld = 0x90E558;
    GamesTable[1].OffsetGameInstance = 0x310;
    GamesTable[1].OffsetLocalPlayer = 0x208;
    GamesTable[1].OffsetPlayerController = 0x2F0;
    GamesTable[1].OffsetCameraManager = 0x70;
    GamesTable[1].OffsetEntityList = 0x911078;
    GamesTable[1].OffsetEntityCount = 0x8;
    GamesTable[1].OffsetEntityBase = 0x3F8;
    GamesTable[1].OffsetEntityPos = 0xA0;
    GamesTable[1].OffsetEntityHead = 0x30;
    GamesTable[1].OffsetEntityHealth = 0x110;
    GamesTable[1].OffsetEntityMaxHealth = 0x114;
    GamesTable[1].OffsetEntityArmor = 0x118;
    GamesTable[1].OffsetEntityShield = 0x114;
    GamesTable[1].OffsetEntityName = 0xA0;
    GamesTable[1].OffsetEntityWeapon = 0x4A8;
    GamesTable[1].OffsetEntityTeam = 0x1C0;
    GamesTable[1].OffsetEntityAlive = 0xC0;
    GamesTable[1].OffsetEntityBone = 0x1E0;
    GamesTable[1].OffsetEntityMesh = 0x1A0;
    GamesTable[1].OffsetMatrix = 0x0;
    GamesTable[1].OffsetViewMatrix = 0x2FC;
    GamesTable[1].OffsetCameraPos = 0x0;
    GamesTable[1].OffsetCameraFOV = 0x0;
    GamesTable[1].OffsetRecoil = 0x2A0;
    GamesTable[1].OffsetSpread = 0x2A4;
    GamesTable[1].OffsetFireRate = 0x2A8;
    GamesTable[1].OffsetFireFlag = 0x28;
    GamesTable[1].OffsetAmmo = 0x1C0;
    GamesTable[1].OffsetMaxAmmo = 0x1C4;
    GamesTable[1].OffsetVelocity = 0x90;
    GamesTable[1].OffsetIsVisible = 0x0;
    GamesTable[1].TraceUWorld = {0x90E558, 0x120, 0x10, 0x2FC};
    GamesTable[1].TraceEntityList = {0x911078, 0x3F8, 0x8};
    
    GamesTable[2].GamePackage = "com.catsbit.oxidesurvivalisland";
    GamesTable[2].GameModule = "libil2cpp.so";
    GamesTable[2].GameName = "Oxide Survival Island v2";
    GamesTable[2].OffsetUWorld = 0x14D788;
    GamesTable[2].OffsetGameInstance = 0x310;
    GamesTable[2].OffsetLocalPlayer = 0x208;
    GamesTable[2].OffsetPlayerController = 0x2F0;
    GamesTable[2].OffsetCameraManager = 0x70;
    GamesTable[2].OffsetEntityList = 0x14D788;
    GamesTable[2].OffsetEntityCount = 0x8;
    GamesTable[2].OffsetEntityBase = 0x3F8;
    GamesTable[2].OffsetEntityPos = 0xA0;
    GamesTable[2].OffsetEntityHead = 0x30;
    GamesTable[2].OffsetEntityHealth = 0x110;
    GamesTable[2].OffsetEntityMaxHealth = 0x114;
    GamesTable[2].OffsetEntityArmor = 0x118;
    GamesTable[2].OffsetEntityShield = 0x114;
    GamesTable[2].OffsetEntityName = 0xA0;
    GamesTable[2].OffsetEntityWeapon = 0x4A8;
    GamesTable[2].OffsetEntityTeam = 0x1C0;
    GamesTable[2].OffsetEntityAlive = 0xC0;
    GamesTable[2].OffsetEntityBone = 0x1E0;
    GamesTable[2].OffsetEntityMesh = 0x1A0;
    GamesTable[2].OffsetMatrix = 0x0;
    GamesTable[2].OffsetViewMatrix = 0x2FC;
    GamesTable[2].OffsetCameraPos = 0x0;
    GamesTable[2].OffsetCameraFOV = 0x0;
    GamesTable[2].OffsetRecoil = 0x2A0;
    GamesTable[2].OffsetSpread = 0x2A4;
    GamesTable[2].OffsetFireRate = 0x2A8;
    GamesTable[2].OffsetFireFlag = 0x28;
    GamesTable[2].OffsetAmmo = 0x1C0;
    GamesTable[2].OffsetMaxAmmo = 0x1C4;
    GamesTable[2].OffsetVelocity = 0x90;
    GamesTable[2].OffsetIsVisible = 0x0;
    GamesTable[2].TraceUWorld = {0x14D788, 0x310, 0x208, 0x2F0, 0x60, 0x18, 0x2FC};
    GamesTable[2].TraceEntityList = {0x14D788, 0x310, 0x208, 0x2F0, 0x8};
    
    GamesTable[3] = GamesTable[0];
}

int GameOffsets::DetectGame() {
    int pid = Mem->GetPID("com.catsbit.oxidesurvivalisland");
    if (pid <= 0) {
        pid = Mem->GetPID("com.catsbit.oxidesurvivalisland.b");
        if (pid <= 0) return -1;
    }
    Mem->Init(pid);
    uintptr_t base = Mem->GetModuleBase("libunity.so");
    if (base) { CurrentGameID = 1; return 1; }
    base = Mem->GetModuleBase("libil2cpp.so");
    if (base) { CurrentGameID = 0; return 0; }
    return -1;
}

void GameOffsets::InitGame(int gameID) {
    if (gameID < 0 || gameID >= 4) return;
    CurrentGameID = gameID;
    GamesOffsetTable *gt = &GamesTable[gameID];
    int pid = Mem->GetPID(gt->GamePackage);
    if (pid <= 0) return;
    Mem->Init(pid);
    UnityBase = Mem->GetModuleBase(gt->GameModule);
    if (!UnityBase) return;
    Initialized = UpdateOffsets();
}

bool GameOffsets::UpdateOffsets() {
    if (CurrentGameID < 0) return false;
    GamesOffsetTable *gt = &GamesTable[CurrentGameID];
    if (gt->TraceUWorld.size() > 0) {
        UWorld = TraceChain(UnityBase, gt->TraceUWorld);
    } else {
        UWorld = Mem->ReadPtr64(UnityBase + gt->OffsetUWorld);
    }
    if (!UWorld) return false;
    if (gt->TraceEntityList.size() > 0) {
        EntityListPtr = TraceChain(UnityBase, gt->TraceEntityList);
    } else {
        uintptr_t entityBase = Mem->ReadPtr64(UnityBase + gt->OffsetEntityList);
        if (!entityBase) return false;
        EntityListPtr = Mem->ReadPtr64(entityBase + gt->OffsetEntityBase) + gt->OffsetEntityCount;
    }
    if (!EntityListPtr) return false;
    ViewMatrixAddr = UWorld + gt->OffsetViewMatrix;
    return true;
}

uintptr_t GameOffsets::TraceChain(uintptr_t base, std::vector<uintptr_t> chain) {
    uintptr_t ptr = base;
    for (size_t i = 0; i < chain.size(); i++) {
        if (i == chain.size() - 1) {
            ptr += chain[i];
        } else {
            ptr = Mem->ReadPtr64(ptr + chain[i]);
            if (!ptr) return 0;
        }
    }
    return ptr;
}

void GameOffsets::UpdateViewMatrix() {
    if (!Initialized || !UWorld) return;
    GamesOffsetTable *gt = &GamesTable[CurrentGameID];
    uintptr_t matrixAddr = UWorld + gt->OffsetViewMatrix;
    Mem->Read(matrixAddr, ViewMatrix, 16 * 4);
}

void GameOffsets::UpdateCamera() {
    if (!Initialized) return;
    if (!LocalPlayer) return;

    GameProfile* gt = &GamesTable[CurrentGameID];

    // Читаем позицию камеры из lastTickPosition (+0x1C0) локального игрока
    float pos[3] = {};
    if (Mem->Read(LocalPlayer + 0x1C0, pos, 12)) {
        if (std::isfinite(pos[0]) && std::isfinite(pos[1]) && std::isfinite(pos[2])) {
            CameraPos.X = pos[0];
            CameraPos.Y = pos[1];
            CameraPos.Z = pos[2];
        }
    }

    // Читаем углы из MouseLook (+0x70 → +0x60 = Vector2 yaw/pitch)
    uintptr_t mlPtr = Mem->ReadPtr64(LocalPlayer + 0x70);
    if (mlPtr) {
        float angles[2] = {};
        if (Mem->Read(mlPtr + 0x60, angles, 8)) {
            if (std::isfinite(angles[0]) && std::isfinite(angles[1])) {
                CameraYaw   = angles[0];
                float pitch = angles[1];
                (void)pitch;
            }
        }
    }

    // FOV из CameraManager если есть
    if (gt->OffsetCameraFOV && UWorld) {
        uintptr_t camMgr = Mem->ReadPtr64(UWorld + 0x2F0);
        if (camMgr) {
            float fov = Mem->ReadFloat(camMgr + gt->OffsetCameraFOV);
            if (fov > 1.0f && fov < 180.0f) CameraFOV = fov;
        }
    }
    if (CameraFOV < 1.0f) CameraFOV = 90.0f;
}

bool GameOffsets::UpdateEntityList() {
    if (!Initialized || !EntityListPtr) return false;
    EntityCount = Mem->ReadInt(EntityListPtr);
    if (EntityCount > 256) EntityCount = 256;
    return EntityCount > 0;
}

bool GameOffsets::ReadEntityData(int index, PlayerData *data) {
    if (!Initialized || !EntityListPtr || index >= EntityCount) return false;
    GamesOffsetTable *gt = &GamesTable[CurrentGameID];
    uintptr_t entityPtr = Mem->ReadPtr64(EntityListPtr + 0x8 + (index * 8));
    if (!entityPtr) return false;
    uintptr_t entity = Mem->ReadPtr64(entityPtr + 0x10);
    if (!entity) return false;
    data->Address = entity;
    D3DVector pos;
    pos.X = Mem->ReadFloat(entity + gt->OffsetEntityPos);
    pos.Y = Mem->ReadFloat(entity + gt->OffsetEntityPos + 0x4);
    pos.Z = Mem->ReadFloat(entity + gt->OffsetEntityPos + 0x8);
    data->Position = pos;
    data->Health = 100.0f;
    if (gt->OffsetEntityHealth) data->Health = Mem->ReadFloat(entity + gt->OffsetEntityHealth);
    data->MaxHealth = data->Health;
    if (gt->OffsetEntityMaxHealth) data->MaxHealth = Mem->ReadFloat(entity + gt->OffsetEntityMaxHealth);
    data->Armor = 0;
    if (gt->OffsetEntityArmor) data->Armor = Mem->ReadFloat(entity + gt->OffsetEntityArmor);
    data->Shield = 0;
    if (gt->OffsetEntityShield) data->Shield = Mem->ReadFloat(entity + gt->OffsetEntityShield);
    data->TeamID = 0;
    if (gt->OffsetEntityTeam) data->TeamID = Mem->ReadInt(entity + gt->OffsetEntityTeam);
    data->IsAlive = true;
    if (gt->OffsetEntityAlive) data->IsAlive = Mem->ReadByte(entity + gt->OffsetEntityAlive) > 0;
    data->IsVisible = true;
    if (gt->OffsetIsVisible) data->IsVisible = Mem->ReadByte(entity + gt->OffsetIsVisible) > 0;
    data->PlayerID = index;
    data->IsBot = false;
    data->BoneAddress = 0;
    if (gt->OffsetEntityBone) data->BoneAddress = Mem->ReadPtr64(entity + gt->OffsetEntityBone);
    data->Distance = 0;
    return true;
}

D3DVector GameOffsets::GetBonePosition(uintptr_t boneAddr, int boneID) {
    if (!boneAddr || boneID < 0) return {0, 0, 0};
    uintptr_t boneMatrix = Mem->ReadPtr64(boneAddr + 0x20);
    if (!boneMatrix) boneMatrix = boneAddr;
    uintptr_t bone = boneMatrix + (uintptr_t)(boneID * 0x20);
    float x = Mem->ReadFloat(bone + 0x10);
    float y = Mem->ReadFloat(bone + 0x14);
    float z = Mem->ReadFloat(bone + 0x18);
    return {x, y, z};
}

void GameOffsets::Reset() {
    Initialized = false;
    UnityBase = 0;
    UWorld = 0;
    GameInstance = 0;
    LocalPlayer = 0;
    PlayerController = 0;
    CameraManager = 0;
    EntityListPtr = 0;
    ViewMatrixAddr = 0;
    CameraAddr = 0;
    EntityCount = 0;
    CurrentGameID = -1;
    CameraFOV = 90.0f;
    CameraYaw = 0.0f;
    ForceAttackAddr = 0;
    memset(ViewMatrix, 0, sizeof(ViewMatrix));
    memset(&CameraPos, 0, sizeof(CameraPos));
}
