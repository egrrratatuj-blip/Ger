#pragma once
#include "../../../../imgui/imgui.h"

bool M_GradientButton(const char* label, ImVec2 size, ImColor colorA, ImColor colorB, float rounding = 15.0f);
bool M_CyberButton(const char* label, ImVec2 size, ImColor accent = ImColor(0, 180, 255));
bool M_IconButton(const char* icon, const char* tooltip, ImVec2 size, ImColor accent = ImColor(0, 180, 255), bool hasBadge = false, int badgeCount = 0);
bool M_ActionButton(const char* icon, const char* label, ImVec2 size, ImColor accent = ImColor(0, 180, 255), const char* shortcut = nullptr);
int M_ButtonGroup(const char* label, int* active, const char** options, int count, ImColor accent = ImColor(0, 180, 255));
bool M_FloatingActionButton(const char* icon, ImVec2 position, float size, ImColor accent = ImColor(0, 180, 255));
bool M_MenuButton(const char* label, bool isOpen, ImColor accent = ImColor(0, 180, 255));
bool M_SplitButton(const char* label, ImVec2 size, ImColor accent = ImColor(0, 180, 255));
bool M_CloseButton(ImVec2 position, float size, ImColor color = ImColor(255, 80, 80));
