#pragma once
#include "../../../../imgui/imgui.h"

int M_TabStrip(const char* label, int active, const char** tabs, int count, ImColor accent = ImColor(0, 180, 255));
int M_Pagination(const char* label, int currentPage, int totalPages, ImColor accent = ImColor(0, 180, 255));
void M_Breadcrumbs(const char* label, const char** path, int depth, ImColor accent = ImColor(0, 180, 255), int* clickTarget = nullptr);
int M_StepIndicator(const char* label, int currentStep, const char** steps, int count, ImColor accent = ImColor(0, 180, 255));
void M_FilterChips(const char* label, bool* active, int count, const char** names, ImColor accent = ImColor(0, 180, 255));
void M_NavRail(const char* label, int active, const char** items, int count, ImVec2 pos, float width, float itemHeight, ImColor accent = ImColor(0, 180, 255));
int M_SegmentedControl(const char* label, int active, const char** segments, int count, ImColor accent = ImColor(0, 180, 255));
