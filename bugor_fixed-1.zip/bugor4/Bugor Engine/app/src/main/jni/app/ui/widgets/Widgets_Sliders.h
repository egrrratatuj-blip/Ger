#pragma once
#include "../../../../imgui/imgui.h"

bool M_GradientSlider(const char* label, float* value, float min, float max, const char* format = "%.1f", ImColor accent = ImColor(0, 180, 255));
bool M_IntSlider(const char* label, int* value, int min, int max, const char* format = "%d", ImColor accent = ImColor(0, 180, 255));
bool M_RangeSlider(const char* label, float* minVal, float* maxVal, float absMin, float absMax, const char* format = "%.1f", ImColor accent = ImColor(0, 180, 255));
bool M_KnobDial(const char* label, float* value, float min, float max, const char* format = "%.1f", ImColor accent = ImColor(0, 180, 255));
bool M_DropdownSelect(const char* label, int* selected, const char** items, int count, ImColor accent = ImColor(0, 180, 255));
bool M_ColorSlider(const char* label, float* value, ImColor colorA, ImColor colorB, ImColor accent = ImColor(0, 180, 255));
bool M_MultiSlider(const char* label, float* values[], int count, float min, float max, ImColor* colors, const char** names, ImColor accent = ImColor(0, 180, 255));
