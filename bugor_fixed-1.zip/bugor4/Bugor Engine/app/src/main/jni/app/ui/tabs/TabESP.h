#pragma once
#include <imgui.h>

void DrawTabESP(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize);
void InitTabESP();
void ShutdownTabESP();
