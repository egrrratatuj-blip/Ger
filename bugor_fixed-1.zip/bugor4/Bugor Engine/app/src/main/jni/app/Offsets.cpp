#include "Offsets.h"
#include <cstdio>
#include <cstring>
#include <cstdlib>

namespace Offsets {

static int s_ActiveProfile = -1;
static GameProfile s_mutableProfiles[5];
static bool s_mutableInit = false;

// ---- canonical, single-shot, in-TU definitions declared by header ----
extern const GameProfile OXIDE_SURVIVAL_DEFAULT = {
    "com.catsbit.oxidesurvivalisland",
    "libil2cpp.so",
    "Oxide Survival Island",
    0x00000000,

    0x00000000, 0x310, 0x208, 0x2F0, 0x60,
    0x00000000, 0x8, 0x3F8, 0x10, 0x0,

    0xA0, 0xA4, 0xA8, 0x30, 0xAC,

    0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000,

    0x0, 0x20, 0x0, 0x0, 0x0,

    0x00000000, 0x0, 0x1A0, 0x0, 0x0, 0x0, 0x0, 0x0,

    0x1E0, 0x20, 0x30,

    0x0, 0x0, 0x0, 0x0, 0x0, 0x0,

    0x0, 0x0,

    0x0, 0x0, 0x0,

    0x00000000, 0x00000000, 0x0, 0x328,

    {0x0}, {0x0}, {0x0},
    0, 0, 0,

    0, 0
};

extern const GameProfile OXIDE_SURVIVAL_V1 = {
    "com.catsbit.oxidesurvivalisland",
    "libunity.so",
    "Oxide Survival Island (Unity)",
    0x00010000,

    0x90E558, 0x310, 0x208, 0x2F0, 0x60,
    0x911078, 0x8, 0x3F8, 0x10, 0x0,

    0xA0, 0xA4, 0xA8, 0x30, 0xAC,

    0x0, 0x0, 0x0, 0x0, 0x0,

    0x0, 0x20, 0x0, 0x0, 0x0,

    0x0, 0x0, 0x0, 0x0,

    0x1E0, 0x20, 0x30,

    0x0, 0x0, 0x0, 0x0, 0x0, 0x0,

    0x0, 0x0,

    0x0, 0x0, 0x0,

    0x0, 0x0, 0x0, 0x328,

    {0x90E558, 0x120, 0x10, 0x2FC, 0x0},
    {0x911078, 0x3F8, 0x8, 0x0},
    {0x0},
    4, 3, 0,

    0, 0
};

extern const GameProfile OXIDE_SURVIVAL_V2 = {
    "com.catsbit.oxidesurvivalisland",
    "libil2cpp.so",
    "Oxide Survival Island v2",
    0x00020001,

    0x14D788, 0x310, 0x208, 0x2F0, 0x60,
    0x14D788, 0x8, 0x3F8, 0x10, 0x0,

    0xA0, 0xA4, 0xA8, 0x30, 0xAC,

    0xC8, 0xCC, 0xD0, 0xD4, 0x0,

    0x50, 0x20, 0x1A0, 0x1C0, 0x0, 0xC0, 0x0, 0x0,

    0x1E0, 0x20, 0x30,

    0x0, 0x0, 0x0, 0x0, 0x0, 0x0,

    0x0, 0x0,

    0x0, 0x0, 0x0,

    0x0, 0x0, 0x0, 0x328,

    {0x14D788, 0x310, 0x208, 0x2F0, 0x60, 0x18, 0x2FC, 0x0},
    {0x14D788, 0x310, 0x208, 0x2F0, 0x8, 0x0},
    {0x0},
    7, 5, 0,

    0, 0
};

extern const GameProfile OXIDE_SURVIVAL_V3 = {
    "com.catsbit.oxidesurvivalisland",
    "libunity.so",
    "Oxide Survival Island v3",
    0x00030002,

    0x90E558, 0x310, 0x208, 0x2F0, 0x60,
    0x911078, 0x8, 0x3F8, 0x10, 0x0,

    0xA0, 0xA4, 0xA8, 0x30, 0xAC,

    0xC8, 0xCC, 0xD0, 0xD4, 0x0,

    0x50, 0x20, 0x1A0, 0x1C0, 0x0, 0xC0, 0x0, 0x0,

    0x1E0, 0x20, 0x30,

    0x0, 0x0, 0x0, 0x0, 0x0, 0x0,

    0x0, 0x0,

    0x0, 0x0, 0x0,

    0x0, 0x0, 0x0, 0x328,

    {0x90E558, 0x120, 0x10, 0x2FC, 0x310, 0x200, 0x0},
    {0x911078, 0x3F8, 0x8, 0x0},
    {0x0},
    6, 3, 0,

    0, 0
};

extern const GameProfile OXIDE_SURVIVAL_LATEST = {
    "com.catsbit.oxidesurvivalisland",
    "libil2cpp.so",
    "Oxide Survival Island (Latest)",
    0x00040003,

    0x14D788, 0x310, 0x208, 0x2F0, 0x60,
    0x14D788, 0x8, 0x3F8, 0x10, 0x0,

    0xA0, 0xA4, 0xA8, 0x30, 0xAC,

    0xC8, 0xCC, 0xD0, 0xD4, 0x0,

    0x50, 0x20, 0x1A0, 0x1C0, 0x0, 0xC0, 0x0, 0x0,

    0x1E0, 0x20, 0x30,

    0x0, 0x0, 0x0, 0x0, 0x0, 0x0,

    0x0, 0x0,

    0x0, 0x0, 0x0,

    0x0, 0x0, 0x0, 0x328,

    {0x14D788, 0x310, 0x208, 0x2F0, 0x60, 0x18, 0x2FC, 0x0},
    {0x14D788, 0x310, 0x208, 0x2F0, 0x8, 0x0},
    {0x14D788, 0x310, 0x208, 0x2F0, 0x0},
    7, 5, 5,

    0, 0
};

extern const GameProfile PROFILES[5] = {
    OXIDE_SURVIVAL_DEFAULT,
    OXIDE_SURVIVAL_V1,
    OXIDE_SURVIVAL_V2,
    OXIDE_SURVIVAL_V3,
    OXIDE_SURVIVAL_LATEST
};



static GameProfile *GetMutableProfile(int index) {
    if (!s_mutableInit) {
        for (int i = 0; i < PROFILE_COUNT && i < 5; i++) {
            s_mutableProfiles[i] = PROFILES[i];
        }
        s_mutableInit = true;
    }
    if (index < 0 || index >= PROFILE_COUNT || index >= 5) return nullptr;
    return &s_mutableProfiles[index];
}

int FindProfileByPackage(const char* packageName) {
    if (!packageName) return -1;
    for (int i = 0; i < PROFILE_COUNT; i++) {
        if (PROFILES[i].package && strcmp(PROFILES[i].package, packageName) == 0) {
            return i;
        }
    }
    return -1;
}

int FindProfileByID(u32 gameID) {
    for (int i = 0; i < PROFILE_COUNT; i++) {
        if (PROFILES[i].gameID == gameID) return i;
    }
    return -1;
}

const GameProfile* GetActiveProfile() {
    if (s_ActiveProfile < 0 || s_ActiveProfile >= PROFILE_COUNT) return nullptr;
    return &PROFILES[s_ActiveProfile];
}

void SetActiveProfile(int index) {
    if (index < 0 || index >= PROFILE_COUNT) return;
    s_ActiveProfile = index;
}

bool ValidateProfile(const GameProfile* profile) {
    if (!profile) return false;
    if (!profile->package || !profile->module) return false;
    if (profile->UWorld == 0 && profile->TraceUWorldLen == 0) return false;
    if (profile->EntityList == 0 && profile->TraceEntityListLen == 0) return false;
    return true;
}

static constexpr u32 OFFSETS_MAGIC = 0x55464553u; // 'SEFU' little-endian

bool LoadOffsetsFromFile(const char* path) {
    if (!path) return false;
    FILE* f = fopen(path, "rb");
    if (!f) return false;

    u32 magic = 0;
    if (fread(&magic, sizeof(u32), 1, f) != 1) {
        fclose(f);
        return false;
    }
    if (magic != OFFSETS_MAGIC) {
        fclose(f);
        return false;
    }

    GameProfile profile;
    memset(&profile, 0, sizeof(profile));
    if (fread(&profile, sizeof(GameProfile), 1, f) != 1) {
        fclose(f);
        return false;
    }

    if (!ValidateProfile(&profile)) {
        fclose(f);
        return false;
    }

    GameProfile* target = GetMutableProfile(0);
    if (!target) {
        fclose(f);
        return false;
    }
    *target = profile;
    s_ActiveProfile = 0;
    fclose(f);
    return true;
}

bool SaveOffsetsToFile(const char* path) {
    if (!path) return false;
    FILE* f = fopen(path, "wb");
    if (!f) return false;

    const GameProfile* profile = GetActiveProfile();
    if (!profile) {
        fclose(f);
        return false;
    }

    u32 magic = OFFSETS_MAGIC;
    fwrite(&magic, sizeof(u32), 1, f);
    fwrite(profile, sizeof(GameProfile), 1, f);

    fclose(f);
    return true;
}

}
