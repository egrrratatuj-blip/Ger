#include "MemoryIO.h"

#ifndef IOV_MAX
#define IOV_MAX 1024
#endif

static void TimeoutHandler(int) {}

static bool IsValidPtr(uintptr_t p) {
    return p > 0x10000ULL && p < 0x7FFFFFFFFFFFULL && (p & 3) == 0;
}

MemoryIO::MemoryIO() {
    pid = 0;
    m_TimeoutMs = 5000;
    pthread_mutex_init(&m_mutex, NULL);
}

void MemoryIO::Init(int pid1) {
    if (pid1 <= 0) return;
    pid = pid1;
}

void MemoryIO::SetTimeout(int ms) {
    if (ms < 0) ms = 0;
    m_TimeoutMs = ms;
}

int MemoryIO::GetPID(const char *packageName) {
    if (!packageName) return -1;
    int id = -1;
    DIR *dir = opendir("/proc");
    if (!dir) return -1;
    struct dirent *entry;
    char filename[128], cmdline[256];
    while ((entry = readdir(dir)) != NULL) {
        id = atoi(entry->d_name);
        if (id <= 0) continue;
        snprintf(filename, sizeof(filename), "/proc/%d/cmdline", id);
        FILE *fp = fopen(filename, "r");
        if (!fp) continue;
        cmdline[0] = 0;
        size_t n = fread(cmdline, 1, sizeof(cmdline) - 1, fp);
        fclose(fp);
        if (n == 0) continue;
        cmdline[n] = 0;
        size_t len = strlen(packageName);
        if (n >= len && strncmp(packageName, cmdline, len) == 0) {
            closedir(dir);
            return id;
        }
    }
    closedir(dir);
    return -1;
}

ssize_t MemoryIO::ProcessVM(pid_t pid, const struct iovec *local, unsigned long lcnt,
                            const struct iovec *remote, unsigned long rcnt,
                            unsigned long flags, bool write) {
#ifdef __aarch64__
    return syscall(write ? 271 : 270, pid, local, lcnt, remote, rcnt, flags);
#else
    return syscall(write ? 311 : 310, pid, local, lcnt, remote, rcnt, flags);
#endif
}

bool MemoryIO::PVM(void *addr, void *buf, size_t size, bool write) {
    if (pid <= 0 || !addr || !buf || size == 0) return false;
    struct iovec local[1], remote[1];
    local[0].iov_base = buf;
    local[0].iov_len = size;
    remote[0].iov_base = addr;
    remote[0].iov_len = size;
    if (local[0].iov_len != size || remote[0].iov_len != size) return false;
    if (m_TimeoutMs > 0) {
        struct sigaction sa, old;
        memset(&sa, 0, sizeof(sa));
        sa.sa_handler = TimeoutHandler;
        sigemptyset(&sa.sa_mask);
        sa.sa_flags = 0;
        sigaction(SIGALRM, &sa, &old);
        struct itimerval it;
        it.it_value.tv_sec = m_TimeoutMs / 1000;
        it.it_value.tv_usec = (m_TimeoutMs % 1000) * 1000;
        it.it_interval.tv_sec = 0;
        it.it_interval.tv_usec = 0;
        setitimer(ITIMER_REAL, &it, NULL);
        ssize_t ret = ProcessVM(pid, local, 1, remote, 1, 0, write);
        struct itimerval zero;
        memset(&zero, 0, sizeof(zero));
        setitimer(ITIMER_REAL, &zero, NULL);
        sigaction(SIGALRM, &old, NULL);
        if (ret == (ssize_t)size) return true;
    } else {
        ssize_t ret = ProcessVM(pid, local, 1, remote, 1, 0, write);
        if (ret == (ssize_t)size) return true;
    }
    if (!write) {
        static int s_memFd = -1;
        static pid_t s_memPid = 0;
        if (s_memPid != pid) {
            if (s_memFd >= 0) close(s_memFd);
            char path[64];
            snprintf(path, sizeof(path), "/proc/%d/mem", pid);
            s_memFd = open(path, O_RDONLY);
            s_memPid = pid;
        }
        if (s_memFd >= 0) {
            ssize_t r = pread64(s_memFd, buf, size, (off64_t)(uintptr_t)addr);
            return r == (ssize_t)size;
        }
    }
    return false;
}

bool MemoryIO::Read(uintptr_t addr, void *buf, size_t size) {
    if (pid <= 0) return false;
    pthread_mutex_lock(&m_mutex);
    bool ret = PVM((void*)addr, buf, size, false);
    pthread_mutex_unlock(&m_mutex);
    return ret;
}

bool MemoryIO::Write(uintptr_t addr, void *buf, size_t size) {
    if (pid <= 0) return false;
    pthread_mutex_lock(&m_mutex);
    bool ret = PVM((void*)addr, buf, size, true);
    pthread_mutex_unlock(&m_mutex);
    return ret;
}

float MemoryIO::ReadFloat(uintptr_t addr) {
    if (pid <= 0) return 0;
    float v = 0; Read(addr, &v, 4); return v;
}

int MemoryIO::ReadInt(uintptr_t addr) {
    if (pid <= 0) return 0;
    int v = 0; Read(addr, &v, 4); return v;
}

uint32_t MemoryIO::ReadDword(uintptr_t addr) {
    if (pid <= 0) return 0;
    uint32_t v = 0; Read(addr, &v, 4); return v;
}

uint64_t MemoryIO::ReadQword(uintptr_t addr) {
    if (pid <= 0) return 0;
    uint64_t v = 0; Read(addr, &v, 8); return v;
}

uint8_t MemoryIO::ReadByte(uintptr_t addr) {
    if (pid <= 0) return 0;
    uint8_t v = 0; Read(addr, &v, 1); return v;
}

uintptr_t MemoryIO::ReadPtr64(uintptr_t addr) {
    if (pid <= 0) return 0;
    if (!IsValidPtr(addr)) return 0;
    uint64_t v = 0;
    Read(addr, &v, 8);
    return (uintptr_t)v;
}

uintptr_t MemoryIO::ReadPtr32(uintptr_t addr) {
    if (pid <= 0) return 0;
    if (!IsValidPtr(addr)) return 0;
    uint32_t v = 0;
    Read(addr, &v, 4);
    return (uintptr_t)v;
}

void MemoryIO::WriteFloat(uintptr_t addr, float val) {
    if (pid <= 0) return;
    Write(addr, &val, 4);
}

void MemoryIO::WriteInt(uintptr_t addr, int val) {
    if (pid <= 0) return;
    Write(addr, &val, 4);
}

void MemoryIO::WriteDword(uintptr_t addr, uint32_t val) {
    if (pid <= 0) return;
    Write(addr, &val, 4);
}

void MemoryIO::WriteQword(uintptr_t addr, uint64_t val) {
    if (pid <= 0) return;
    Write(addr, &val, 8);
}

static bool LineMatchesLibrary(const char *line, const char *name) {
    if (!line || !name) return false;
    const char *p = strstr(line, name);
    if (!p) return false;
    const char *end = p + strlen(name);
    char c = *end;
    return (c == 0 || c == '\n' || c == ' ' || c == '\t');
}

uintptr_t MemoryIO::GetModuleBase(const char *name) {
    return GetModuleBase(name, false);
}

uintptr_t MemoryIO::GetModuleBase(const char *name, bool exactMatch) {
    if (pid <= 0 || !name) return 0;
    char path[256], line[1024];
    uintptr_t addr = 0;
    snprintf(path, sizeof(path), "/proc/%d/maps", pid);
    FILE *fp = fopen(path, "r");
    if (!fp) return 0;
    while (fgets(line, sizeof(line), fp)) {
        if (exactMatch) {
            const char *lib = strrchr(line, '/');
            if (!lib) continue;
            lib++;
            const char *e = lib;
            while (*e && *e != '\n' && *e != ' ' && *e != '\t') e++;
            size_t libLen = e - lib;
            if (libLen != strlen(name)) continue;
            if (strncmp(lib, name, libLen) != 0) continue;
        } else {
            if (!LineMatchesLibrary(line, name)) continue;
        }
        uintptr_t s = 0, e = 0;
        if (sscanf(line, "%lx-%lx", &s, &e) == 2) {
            addr = s;
            break;
        }
    }
    fclose(fp);
    return addr;
}

uintptr_t MemoryIO::GetBSS(const char *name) {
    if (pid <= 0 || !name) return 0;
    char path[256], line[1024];
    uintptr_t bssAddr = 0;
    snprintf(path, sizeof(path), "/proc/%d/maps", pid);
    FILE *fp = fopen(path, "r");
    if (!fp) return 0;
    while (fgets(line, sizeof(line), fp)) {
        if (!LineMatchesLibrary(line, name)) continue;
        if (!strstr(line, "rw-p")) continue;
        uintptr_t s = 0, e = 0;
        if (sscanf(line, "%lx-%lx", &s, &e) == 2) {
            if (s > bssAddr) bssAddr = s;
        }
    }
    fclose(fp);
    return bssAddr;
}

size_t MemoryIO::GetModuleSize(const char *name) {
    if (pid <= 0 || !name) return 0;
    char path[256], line[1024];
    uintptr_t start = 0, end = 0;
    snprintf(path, sizeof(path), "/proc/%d/maps", pid);
    FILE *fp = fopen(path, "r");
    if (!fp) return 0;
    while (fgets(line, sizeof(line), fp)) {
        if (!LineMatchesLibrary(line, name)) continue;
        uintptr_t s = 0, e = 0;
        if (sscanf(line, "%lx-%lx", &s, &e) != 2) continue;
        if (!start || s < start) start = s;
        if (e > end) end = e;
    }
    fclose(fp);
    if (end < start) return 0;
    return end - start;
}

bool MemoryIO::ReadString(uintptr_t addr, char *buf, size_t maxLen) {
    if (pid <= 0 || !addr || !buf || maxLen == 0) return false;
    if (maxLen > 256) maxLen = 256;
    memset(buf, 0, maxLen);
    size_t readSize = maxLen - 1;
    if (!Read(addr, buf, readSize)) return false;
    buf[readSize] = 0;
    return true;
}

bool MemoryIO::ReadUTF8String(uintptr_t addr, char *buf, size_t maxLen) {
    if (pid <= 0 || !addr || !buf || maxLen == 0) return false;
    if (maxLen > 512) maxLen = 512;
    if (maxLen == 1) { buf[0] = 0; return true; }
    int32_t length = 0;
    if (!Read(addr + 0x10, &length, 4)) { buf[0] = 0; return false; }
    if (length < 0) { buf[0] = 0; return false; }
    if (length > 512) length = 512;
    size_t count = (size_t)length;
    uint16_t buf16[512];
    if (!Read(addr + 0x14, buf16, count * 2)) {
        buf[0] = 0;
        return false;
    }
    char *dst = buf;
    char *end = buf + maxLen - 1;
    for (size_t i = 0; i < count && dst < end; i++) {
        uint32_t cp = buf16[i];
        if (cp >= 0xD800 && cp <= 0xDBFF) {
            i++;
            if (i < count) {
                uint32_t lo = buf16[i];
                if (lo >= 0xDC00 && lo <= 0xDFFF) {
                    cp = ((cp - 0xD800) << 10) + (lo - 0xDC00) + 0x10000;
                } else {
                    cp = 0xFFFD;
                    i--;
                }
            } else {
                cp = 0xFFFD;
            }
        } else if (cp >= 0xDC00 && cp <= 0xDFFF) {
            cp = 0xFFFD;
        }
        if (cp <= 0x007F) {
            *dst++ = (char)cp;
        } else if (cp <= 0x07FF && (dst + 1) < end) {
            *dst++ = (char)(((cp >> 6) & 0x1F) | 0xC0);
            *dst++ = (char)((cp & 0x3F) | 0x80);
        } else if (cp <= 0xFFFF && (dst + 2) < end) {
            *dst++ = (char)(((cp >> 12) & 0x0F) | 0xE0);
            *dst++ = (char)(((cp >> 6) & 0x3F) | 0x80);
            *dst++ = (char)((cp & 0x3F) | 0x80);
        } else if (cp <= 0x10FFFF && (dst + 3) < end) {
            *dst++ = (char)(((cp >> 18) & 0x07) | 0xF0);
            *dst++ = (char)(((cp >> 12) & 0x3F) | 0x80);
            *dst++ = (char)(((cp >> 6) & 0x3F) | 0x80);
            *dst++ = (char)((cp & 0x3F) | 0x80);
        } else {
            if (dst < end) *dst++ = '?';
        }
    }
    *dst = 0;
    return true;
}

bool MemoryIO::ReadBatch(std::vector<BatchEntry>& entries) {
    if (pid <= 0 || entries.empty()) return false;
    pthread_mutex_lock(&m_mutex);
    bool ok = true;
    size_t total = entries.size();
    size_t pos = 0;
    while (pos < total) {
        size_t count = total - pos;
        if (count > IOV_MAX) count = IOV_MAX;
        std::vector<struct iovec> local(count), remote(count);
        for (size_t i = 0; i < count; i++) {
            local[i].iov_base = entries[pos + i].buf;
            local[i].iov_len = entries[pos + i].size;
            remote[i].iov_base = (void*)entries[pos + i].addr;
            remote[i].iov_len = entries[pos + i].size;
        }
        ssize_t ret = ProcessVM(pid, local.data(), count, remote.data(), count, 0, false);
        if (ret < 0) {
            ok = false;
            break;
        }
        pos += count;
    }
    pthread_mutex_unlock(&m_mutex);
    return ok;
}

static bool MaskMatch(const uint8_t *mem, const uint8_t *pat, const char *mask,
                      size_t len) {
    for (size_t j = 0; j < len; j++) {
        if (mask[j] == 'x' && mem[j] != pat[j]) return false;
    }
    return true;
}

static std::vector<uint8_t> ReadRegion(MemoryIO *self, uintptr_t base, size_t size) {
    std::vector<uint8_t> buf(size);
    if (size == 0) return buf;
    self->Read(base, buf.data(), size);
    return buf;
}

uintptr_t MemoryIO::FindSignature(const char *module, const char *pattern, const char *mask) {
    if (pid <= 0 || !module || !pattern || !mask) return 0;
    size_t patternLen = strlen(mask);
    if (patternLen == 0) return 0;
    uintptr_t base = GetModuleBase(module);
    size_t size = GetModuleSize(module);
    if (!base || !size || size < patternLen) return 0;
    std::vector<uint8_t> data = ReadRegion(this, base, size);
    const uint8_t *pat = (const uint8_t *)pattern;
    for (size_t i = 0; i <= size - patternLen; i++) {
        if (MaskMatch(data.data() + i, pat, mask, patternLen)) {
            return base + i;
        }
    }
    return 0;
}

std::vector<uintptr_t> MemoryIO::FindSignatures(const char *module, const char *pattern, const char *mask) {
    std::vector<uintptr_t> results;
    if (pid <= 0 || !module || !pattern || !mask) return results;
    size_t patternLen = strlen(mask);
    if (patternLen == 0) return results;
    uintptr_t base = GetModuleBase(module);
    size_t size = GetModuleSize(module);
    if (!base || !size || size < patternLen) return results;
    std::vector<uint8_t> data = ReadRegion(this, base, size);
    const uint8_t *pat = (const uint8_t *)pattern;
    for (size_t i = 0; i <= size - patternLen; i++) {
        if (MaskMatch(data.data() + i, pat, mask, patternLen)) {
            results.push_back(base + i);
        }
    }
    return results;
}

uintptr_t MemoryIO::TracePointer(uintptr_t addr, std::vector<uintptr_t> offsets) {
    if (pid <= 0 || !addr) return 0;
    if (offsets.empty()) return addr;
    uintptr_t ptr = addr;
    for (size_t i = 0; i < offsets.size(); i++) {
        ptr += offsets[i];
        if (i == offsets.size() - 1) break;
        ptr = ReadPtr64(ptr);
        if (!ptr) return 0;
    }
    return ptr;
}
