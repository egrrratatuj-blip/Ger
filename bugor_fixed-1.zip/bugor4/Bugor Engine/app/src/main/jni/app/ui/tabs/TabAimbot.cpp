#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "TabAimbot.h"
#include "TabHelpers.h"
#include "../ui_integration.h"
#include "../widgets/Widgets_Switches.h"
#include "../widgets/Widgets_Buttons.h"
#include "../widgets/Widgets_Containers.h"
#include "../widgets/Widgets_Sliders.h"

static const char* aimBoneOptions[] = {"Head", "Body", "Neck", "Pelvis", "Feet"};
static const char* priorityOptions[] = {"Distance", "Crosshair", "Health", "Armor"};
static const char* aimModeOptions[] = {"Memory", "Silent", "Rage"};
static const char* triggerModeOptions[] = {"On Sight", "On Crosshair", "Both"};
static const char* rcsModeOptions[] = {"Aim Only", "Always", "Dynamic"};

void DrawTabAimbot(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize)
{
    (void)contentSize;
    Config& c = g_Cfg;
    Toggles& t = g_Tog;
    float leftColX = contentPos.x;
    float rightColX = contentPos.x + contentSize.x * 0.5f + 8.0f;
    float cardW = contentSize.x * 0.5f - 12.0f;
    float leftY = contentPos.y + 4.0f;
    float rightY = contentPos.y + 4.0f;
    float time = ImGui::GetTime();
    float sinT1 = sinf(time * 1.7f) * 0.5f + 0.5f;
    float sinT2 = sinf(time * 2.3f) * 0.5f + 0.5f;
    float sinT3 = sinf(time * 3.1f) * 0.5f + 0.5f;
    float sinT4 = sinf(time * 1.3f) * 0.5f + 0.5f;
    float sinT5 = sinf(time * 4.7f) * 0.5f + 0.5f;
    float cosT1 = cosf(time * 0.9f) * 0.5f + 0.5f;

    ImColor accent = c.AccentColor;
    ImColor accent2 = c.AccentColor2;
    float ar = accent.Value.x;
    float ag = accent.Value.y;
    float ab = accent.Value.z;
    float a2r = accent2.Value.x;
    float a2g = accent2.Value.y;
    float a2b = accent2.Value.z;

    ImColor accentBright(
        ar * 1.3f > 1.0f ? 1.0f : ar * 1.3f,
        ag * 1.3f > 1.0f ? 1.0f : ag * 1.3f,
        ab * 1.3f > 1.0f ? 1.0f : ab * 1.3f,
        accent.Value.w
    );
    ImColor accentDim(ar * 0.5f, ag * 0.5f, ab * 0.5f, accent.Value.w);
    ImColor accentPulse(ar, ag, ab, 0.08f + sinT1 * 0.06f);
    ImColor accentGlow(ar, ag, ab, 0.12f);
    ImColor mixedAccent(
        (ar + a2r) * 0.5f,
        (ag + a2g) * 0.5f,
        (ab + a2b) * 0.5f,
        accent.Value.w
    );

    static bool c1col = false;
    static bool c2col = false;
    static bool c3col = false;
    static bool c4col = false;
    static bool c5col = false;
    static bool c6col = false;

    ImGui::SetCursorScreenPos(ImVec2(leftColX, leftY));
    bool c1ch = M_CardBegin("###aimbotCoreCard", &c1col, accent);
    if (!c1col)
    {
        ImVec2 cardStartPos = ImGui::GetCursorScreenPos();
        M_CyberHeader("AIMBOT", accent, "Core targeting configuration");
        {
            ImVec2 bp = ImGui::GetCursorScreenPos();
            bool prevVal = t.Aimbot;
            M_ModernSwitch("Enable", &t.Aimbot, accent);
            if (prevVal != t.Aimbot)
            {
                if (t.Aimbot)
                {
                    ImColor flashCol((int)(ar * 255.0f), (int)(ag * 255.0f), (int)(ab * 255.0f), 35);
                    dl->AddRectFilled(
                        ImVec2(bp.x + 2.0f, bp.y + 2.0f),
                        ImVec2(bp.x + cardW - 2.0f, bp.y + 58.0f),
                        C(flashCol), 4.0f
                    );
                }
            }
            if (t.Aimbot)
            {
                drawActivePulse(dl, ImVec2(leftColX, bp.y), cardW, accent, sinT4, 4.0f);
            }
        }
        {
            float minV = 10.0f;
            float maxV = 800.0f;
            M_GradientSlider("FOV Range", &c.AimbotRange, minV, maxV, "%.0f", accent);
            c.AimbotRange = clampF(c.AimbotRange, minV, maxV);
        }
        {
            float minV = 50.0f;
            float maxV = 1000.0f;
            M_GradientSlider("Max Distance", &c.AimbotMaxDistance, minV, maxV, "%.0f", accent);
            c.AimbotMaxDistance = clampF(c.AimbotMaxDistance, minV, maxV);
        }
        {
            float minV = 1.0f;
            float maxV = 30.0f;
            M_GradientSlider("Smooth Factor", &c.AimbotSmoothValue, minV, maxV, "%.1f", accent);
            c.AimbotSmoothValue = clampF(c.AimbotSmoothValue, minV, maxV);
        }
        {
            int prevBone = c.SelectedAimbotBone;
            M_DropdownSelect("Aim Bone", &c.SelectedAimbotBone, aimBoneOptions, 5, accent);
            if (prevBone != c.SelectedAimbotBone)
            {
                if (c.SelectedAimbotBone < 0) c.SelectedAimbotBone = 0;
                if (c.SelectedAimbotBone >= 5) c.SelectedAimbotBone = 4;
            }
        }
        {
            int prevPri = c.SelectedAimbotPriority;
            M_DropdownSelect("Priority", &c.SelectedAimbotPriority, priorityOptions, 4, accent);
            if (prevPri != c.SelectedAimbotPriority)
            {
                if (c.SelectedAimbotPriority < 0) c.SelectedAimbotPriority = 0;
                if (c.SelectedAimbotPriority >= 4) c.SelectedAimbotPriority = 3;
            }
        }
        {
            int prevMode = c.SelectedAimbotMode;
            M_SegmentedToggle("Aim Mode", &c.SelectedAimbotMode, aimModeOptions, 3, accent);
            if (prevMode != c.SelectedAimbotMode)
            {
                if (c.SelectedAimbotMode < 0) c.SelectedAimbotMode = 0;
                if (c.SelectedAimbotMode >= 3) c.SelectedAimbotMode = 2;
            }
        }
        {
            ImVec2 cp = ImGui::GetCursorScreenPos();
            drawSectionBar(dl, cp, cardW, accent);
        }
        {
            char boneName[32] = "Head";
            int bi = c.SelectedAimbotBone;
            if (bi >= 0 && bi < 5) strncpy(boneName, aimBoneOptions[bi], sizeof(boneName) - 1);
            char priorityName[32] = "Distance";
            int pi = c.SelectedAimbotPriority;
            if (pi >= 0 && pi < 4) strncpy(priorityName, priorityOptions[pi], sizeof(priorityName) - 1);
            char modeName[32] = "Memory";
            int mi = c.SelectedAimbotMode;
            if (mi >= 0 && mi < 3) strncpy(modeName, aimModeOptions[mi], sizeof(modeName) - 1);
            if (t.Aimbot)
            {
                ImVec2 cp2 = ImGui::GetCursorScreenPos();
                ImColor infoBg(0, 0, 0, 60);
                dl->AddRectFilled(
                    ImVec2(cp2.x + 4.0f, cp2.y),
                    ImVec2(cp2.x + cardW - 4.0f, cp2.y + 28.0f),
                    C(infoBg), 4.0f
                );
                ImColor infoBorder = accentDim;
                infoBorder.Value.w = 0.2f;
                dl->AddRect(
                    ImVec2(cp2.x + 4.0f, cp2.y),
                    ImVec2(cp2.x + cardW - 4.0f, cp2.y + 28.0f),
                    C(infoBorder), 4.0f, ImDrawFlags_RoundCornersAll, 1.0f
                );
                char infoBuf[128];
                snprintf(infoBuf, sizeof(infoBuf), "Bone: %s | Priority: %s | Mode: %s",
                    boneName, priorityName, modeName);
                ImVec2 textSize = ImGui::CalcTextSize(infoBuf);
                float textX = cp2.x + (cardW - textSize.x) * 0.5f;
                float textY = cp2.y + (28.0f - textSize.y) * 0.5f;
                ImColor textCol(200, 200, 220, 220);
                dl->AddText(ImVec2(textX, textY), C(textCol), infoBuf);
                ImGui::Dummy(ImVec2(0, 28.0f));
            }
        }
        {
            if (t.Aimbot)
            {
                ImVec2 cp3 = ImGui::GetCursorScreenPos();
                drawActivePulse(dl, ImVec2(leftColX, cp3.y), cardW, mixedAccent, sinT2, 3.0f);
            }
        }
        drawCardGlow(dl, cardStartPos, cardW, ImGui::GetCursorScreenPos().y - cardStartPos.y, accent, 0.6f);
    }
    M_CardEnd();
    float c1end = ImGui::GetCursorScreenPos().y + 8.0f;
    leftY = c1end;

    ImGui::SetCursorScreenPos(ImVec2(rightColX, rightY));
    bool c2ch = M_CardBegin("###aimbotVisCard", &c2col, accent);
    if (!c2col)
    {
        ImVec2 cardStartPos = ImGui::GetCursorScreenPos();
        M_CyberHeader("VISUAL FEEDBACK", accent, "Aimbot visual indicators");
        {
            bool prev = t.AimbotDrawFOV;
            M_ModernSwitch("Show FOV Circle", &t.AimbotDrawFOV, accent);
            if (prev != t.AimbotDrawFOV)
            {
                if (t.AimbotDrawFOV)
                {
                    ImColor flash(ar, ag, ab, 0.3f);
                    ImVec2 cp = ImGui::GetCursorScreenPos();
                    dl->AddRectFilled(ImVec2(cp.x - cardW, cp.y - 56.0f), ImVec2(cp.x, cp.y), C(flash), 4.0f);
                }
            }
        }
        {
            M_ModernSwitch("Show Target", &t.AimbotDrawTarget, accent);
        }
        {
            M_ModernSwitch("Show Target Line", &t.AimbotTargetLine, accent);
        }
        {
            M_ModernSwitch("Show Target Info", &t.ShowInfo, accent);
        }
        {
            float hueVal = c.AimbotFOVHue;
            ImColor hueStartCol = hsvToRgb(0.0f, 0.85f, 1.0f);
            ImColor hueEndCol = hsvToRgb(0.67f, 0.85f, 1.0f);
            M_ColorSlider("FOV Color", &hueVal, hueStartCol, hueEndCol, accent);
            c.AimbotFOVHue = clampF(hueVal, 0.0f, 1.0f);
            float h = c.AimbotFOVHue;
            float s = 0.85f;
            float v = 1.0f;
            float r = v, g = v, b = v;
            if (s >= 0.001f)
            {
                int ii = (int)(h * 6.0f);
                float ff = h * 6.0f - (float)ii;
                float pp = v * (1.0f - s);
                float qq = v * (1.0f - ff * s);
                float tt = v * (1.0f - (1.0f - ff) * s);
                switch (ii % 6)
                {
                    case 0: r = v; g = tt; b = pp; break;
                    case 1: r = qq; g = v; b = pp; break;
                    case 2: r = pp; g = v; b = tt; break;
                    case 3: r = pp; g = qq; b = v; break;
                    case 4: r = tt; g = pp; b = v; break;
                    default: r = v; g = pp; b = qq; break;
                }
            }
            c.AimbotFOVColor = ImColor(r, g, b, 100);
        }
        {
            float minV = 1.0f;
            float maxV = 5.0f;
            M_GradientSlider("Target Line Width", &c.AimbotTargetLineWidth, minV, maxV, "%.0f", accent);
            c.AimbotTargetLineWidth = clampF(c.AimbotTargetLineWidth, minV, maxV);
        }
        {
            if (t.AimbotDrawFOV || t.AimbotDrawTarget || t.AimbotTargetLine || t.ShowInfo)
            {
                ImVec2 cp = ImGui::GetCursorScreenPos();
                drawActivePulse(dl, ImVec2(rightColX, cp.y), cardW, accent, sinT3, 3.0f);
                char visStatus[96];
                int visCount = (t.AimbotDrawFOV ? 1 : 0) + (t.AimbotDrawTarget ? 1 : 0) +
                    (t.AimbotTargetLine ? 1 : 0) + (t.ShowInfo ? 1 : 0);
                snprintf(visStatus, sizeof(visStatus),
                    "Active visuals: %d/4  |  Line width: %.0fpx",
                    visCount, c.AimbotTargetLineWidth);
                ImVec2 textSize = ImGui::CalcTextSize(visStatus);
                float textX = rightColX + (cardW - textSize.x) * 0.5f;
                float textY = cp.y + 6.0f;
                ImColor textCol(180, 180, 210, 200);
                dl->AddText(ImVec2(textX, textY), C(textCol), visStatus);
                ImGui::Dummy(ImVec2(0, textSize.y + 8.0f));
            }
        }
        {
            ImVec2 cp = ImGui::GetCursorScreenPos();
            ImColor fovPreview = c.AimbotFOVColor;
            fovPreview.Value.w = 1.0f;
            dl->AddCircleFilled(ImVec2(rightColX + 14.0f, cp.y + 8.0f), 6.0f, C(fovPreview), 12);
            dl->AddCircle(ImVec2(rightColX + 14.0f, cp.y + 8.0f), 6.0f, C(ImColor(255, 255, 255, 60)), 12, 1.0f);
            char fovHex[16];
            snprintf(fovHex, sizeof(fovHex), "FOV Color");
            ImVec2 fs = ImGui::CalcTextSize(fovHex);
            dl->AddText(ImVec2(rightColX + 26.0f, cp.y + 8.0f - fs.y * 0.5f), C(ImColor(160, 160, 190, 200)), fovHex);
            ImGui::Dummy(ImVec2(0, 20.0f));
        }
        drawCardGlow(dl, cardStartPos, cardW, ImGui::GetCursorScreenPos().y - cardStartPos.y, accent2, 0.5f);
    }
    M_CardEnd();
    float c2end = ImGui::GetCursorScreenPos().y + 8.0f;
    rightY = c2end;

    float targetColY = leftY > c1end ? leftY : c1end;
    ImGui::SetCursorScreenPos(ImVec2(leftColX, targetColY));
    bool c3ch = M_CardBegin("###targetingCard", &c3col, accent);
    if (!c3col)
    {
        ImVec2 cardStartPos = ImGui::GetCursorScreenPos();
        M_CyberHeader("TARGETING", accent, "Target acquisition & filtering");
        {
            bool prev = t.AimbotVisibleCheck;
            M_ModernSwitch("Visible Check", &t.AimbotVisibleCheck, accent);
            if (prev != t.AimbotVisibleCheck)
            {
                ImColor flash(ar, ag, ab, 0.25f);
                ImVec2 cp = ImGui::GetCursorScreenPos();
                dl->AddRectFilled(ImVec2(cp.x - cardW, cp.y - 56.0f), ImVec2(cp.x, cp.y), C(flash), 4.0f);
            }
        }
        {
            bool prev = t.AimbotPrediction;
            M_ModernSwitch("Prediction", &t.AimbotPrediction, accent);
            if (prev != t.AimbotPrediction)
            {
                ImColor flash(ar, ag, ab, 0.15f);
                ImVec2 cp = ImGui::GetCursorScreenPos();
                dl->AddRectFilled(ImVec2(cp.x - cardW + 4.0f, cp.y - 56.0f), ImVec2(cp.x - 4.0f, cp.y), C(flash), 4.0f);
            }
        }
        {
            float minV = 0.0f;
            float maxV = 5.0f;
            M_GradientSlider("Prediction Factor", &c.AimbotPredictionValue, minV, maxV, "%.1f", accent);
            c.AimbotPredictionValue = clampF(c.AimbotPredictionValue, minV, maxV);
        }
        {
            bool prev = t.AimbotAutoFire;
            M_ModernSwitch("Auto Fire", &t.AimbotAutoFire, accent);
            if (prev != t.AimbotAutoFire)
            {
                ImColor flash(ar, ag, ab, 0.25f);
                ImVec2 cp = ImGui::GetCursorScreenPos();
                dl->AddRectFilled(ImVec2(cp.x - cardW, cp.y - 56.0f), ImVec2(cp.x, cp.y), C(flash), 4.0f);
            }
        }
        {
            M_ModernSwitch("Auto Scope", &t.AimbotAutoScope, accent);
        }
        {
            M_ModernSwitch("Auto Wallbang", &t.AimbotAutoWallbang, accent);
        }
        {
            float minV = 50.0f;
            float maxV = 2000.0f;
            M_GradientSlider("Fire Rate (ms)", &c.AimbotFireRate, minV, maxV, "%.0f", accent);
            c.AimbotFireRate = clampF(c.AimbotFireRate, minV, maxV);
        }
        {
            ImVec2 cp = ImGui::GetCursorScreenPos();
            drawSectionBar(dl, cp, cardW, accent);
        }
        {
            if (t.AimbotAutoFire)
            {
                ImVec2 cp = ImGui::GetCursorScreenPos();
                drawActivePulse(dl, ImVec2(leftColX, cp.y), cardW, accent, sinT1, 3.0f);
                char autoFireStatus[64];
                snprintf(autoFireStatus, sizeof(autoFireStatus),
                    "Auto Fire Active | Rate: %.0f ms", c.AimbotFireRate);
                ImVec2 textSize = ImGui::CalcTextSize(autoFireStatus);
                float textX = leftColX + (cardW - textSize.x) * 0.5f;
                float textY = cp.y + 6.0f;
                ImColor textCol(180, 180, 210, 200);
                dl->AddText(ImVec2(textX, textY), C(textCol), autoFireStatus);
                ImGui::Dummy(ImVec2(0, textSize.y + 8.0f));
            }
        }
        drawCardGlow(dl, cardStartPos, cardW, ImGui::GetCursorScreenPos().y - cardStartPos.y, mixedAccent, 0.4f);
    }
    M_CardEnd();
    float c3end = ImGui::GetCursorScreenPos().y + 8.0f;
    leftY = c3end;

    float trigColY = rightY > c2end ? rightY : c2end;
    ImGui::SetCursorScreenPos(ImVec2(rightColX, trigColY));
    bool c4ch = M_CardBegin("###triggerbotCard", &c4col, accent);
    if (!c4col)
    {
        ImVec2 cardStartPos = ImGui::GetCursorScreenPos();
        M_CyberHeader("TRIGGERBOT", accent, "Automatic trigger activation");
        {
            bool prev = t.TriggerbotEnabled;
            M_ModernSwitch("Triggerbot Enabled", &t.TriggerbotEnabled, accent);
            if (prev != t.TriggerbotEnabled)
            {
                ImColor flash(ar, ag, ab, 0.3f);
                ImVec2 cp = ImGui::GetCursorScreenPos();
                dl->AddRectFilled(ImVec2(cp.x - cardW, cp.y - 56.0f), ImVec2(cp.x, cp.y), C(flash), 4.0f);
            }
        }
        {
            float minV = 0.0f;
            float maxV = 500.0f;
            M_GradientSlider("Trigger Delay (ms)", &c.TriggerDelay, minV, maxV, "%.0f", accent);
            c.TriggerDelay = clampF(c.TriggerDelay, minV, maxV);
        }
        {
            M_DropdownSelect("Trigger Mode", &c.TriggerMode, triggerModeOptions, 3, accent);
            if (c.TriggerMode < 0) c.TriggerMode = 0;
            if (c.TriggerMode >= 3) c.TriggerMode = 2;
        }
        {
            M_ModernSwitch("Friendly Fire", &t.TriggerbotFriendlyFire, accent);
        }
        {
            M_ModernSwitch("Visibility Required", &t.AimbotVisibleCheck, accent);
        }
        {
            if (t.TriggerbotEnabled)
            {
                ImVec2 cp = ImGui::GetCursorScreenPos();
                drawActivePulse(dl, ImVec2(rightColX, cp.y), cardW, accent, sinT2, 3.0f);
                char tbStatus[64];
                char tbModeName[32] = "On Sight";
                int tmi = c.TriggerMode;
                if (tmi >= 0 && tmi < 3) strncpy(tbModeName, triggerModeOptions[tmi], sizeof(tbModeName) - 1);
                snprintf(tbStatus, sizeof(tbStatus),
                    "Triggerbot Active | Delay: %.0f ms", c.TriggerDelay);
                ImVec2 textSize = ImGui::CalcTextSize(tbStatus);
                float textX = rightColX + (cardW - textSize.x) * 0.5f;
                float textY = cp.y + 6.0f;
                ImColor textCol(180, 180, 210, 200);
                dl->AddText(ImVec2(textX, textY), C(textCol), tbStatus);
                ImGui::Dummy(ImVec2(0, textSize.y + 8.0f));
                ImVec2 cp2 = ImGui::GetCursorScreenPos();
                char tbModeStr[64];
                snprintf(tbModeStr, sizeof(tbModeStr),
                    "Mode: %s | FF: %s | Vis: %s",
                    tbModeName,
                    t.TriggerbotFriendlyFire ? "ON" : "OFF",
                    t.AimbotVisibleCheck ? "ON" : "OFF");
                ImVec2 ts2 = ImGui::CalcTextSize(tbModeStr);
                float tx2 = rightColX + (cardW - ts2.x) * 0.5f;
                float ty2 = cp2.y + 2.0f;
                ImColor tc2(150, 150, 190, 180);
                dl->AddText(ImVec2(tx2, ty2), C(tc2), tbModeStr);
                ImGui::Dummy(ImVec2(0, ts2.y + 6.0f));
            }
        }
        drawCardGlow(dl, cardStartPos, cardW, ImGui::GetCursorScreenPos().y - cardStartPos.y, accent2, 0.4f);
    }
    M_CardEnd();
    float c4end = ImGui::GetCursorScreenPos().y + 8.0f;
    rightY = c4end;

    float recColY = leftY > c3end ? leftY : c3end;
    ImGui::SetCursorScreenPos(ImVec2(leftColX, recColY));
    bool c5ch = M_CardBegin("###recoilCard", &c5col, accent);
    if (!c5col)
    {
        ImVec2 cardStartPos = ImGui::GetCursorScreenPos();
        M_CyberHeader("RECOIL CONTROL", accent, "Recoil compensation system");
        {
            bool prev = t.NoRecoil;
            M_ModernSwitch("No Recoil", &t.NoRecoil, accent);
            if (prev != t.NoRecoil)
            {
                ImColor flash(ar, ag, ab, 0.25f);
                ImVec2 cp = ImGui::GetCursorScreenPos();
                dl->AddRectFilled(ImVec2(cp.x - cardW, cp.y - 56.0f), ImVec2(cp.x, cp.y), C(flash), 4.0f);
            }
        }
        {
            bool prev = t.NoSpread;
            M_ModernSwitch("No Spread", &t.NoSpread, accent);
            if (prev != t.NoSpread)
            {
                ImColor flash(ar, ag, ab, 0.25f);
                ImVec2 cp = ImGui::GetCursorScreenPos();
                dl->AddRectFilled(ImVec2(cp.x - cardW, cp.y - 56.0f), ImVec2(cp.x, cp.y), C(flash), 4.0f);
            }
        }
        {
            float minV = 0.0f;
            float maxV = 100.0f;
            M_GradientSlider("RCS Vertical %", &c.RCSVerticalValue, minV, maxV, "%.0f", accent);
            c.RCSVerticalValue = clampF(c.RCSVerticalValue, minV, maxV);
        }
        {
            float minV = 0.0f;
            float maxV = 100.0f;
            M_GradientSlider("RCS Horizontal %", &c.RCSHorizontalValue, minV, maxV, "%.0f", accent);
            c.RCSHorizontalValue = clampF(c.RCSHorizontalValue, minV, maxV);
        }
        {
            int prev = c.RCSMode;
            M_SegmentedToggle("RCS Mode", &c.RCSMode, rcsModeOptions, 3, accent);
            if (prev != c.RCSMode)
            {
                if (c.RCSMode < 0) c.RCSMode = 0;
                if (c.RCSMode >= 3) c.RCSMode = 2;
            }
        }
        {
            M_ModernSwitch("RCS Randomization", &t.RCSRandomization, accent);
        }
        {
            ImVec2 cp = ImGui::GetCursorScreenPos();
            drawSectionBar(dl, cp, cardW, accent);
        }
        {
            if (t.NoRecoil || t.NoSpread)
            {
                ImVec2 cp = ImGui::GetCursorScreenPos();
                drawActivePulse(dl, ImVec2(leftColX, cp.y), cardW, accent, sinT3, 3.0f);
                char rcsStatus[64];
                char rcsModeName[32] = "Aim Only";
                int rmi = c.RCSMode;
                if (rmi >= 0 && rmi < 3) strncpy(rcsModeName, rcsModeOptions[rmi], sizeof(rcsModeName) - 1);
                snprintf(rcsStatus, sizeof(rcsStatus), "RCS %s | V: %.0f%% H: %.0f%%",
                    rcsModeName, c.RCSVerticalValue, c.RCSHorizontalValue);
                ImVec2 textSize = ImGui::CalcTextSize(rcsStatus);
                float textX = leftColX + (cardW - textSize.x) * 0.5f;
                float textY = cp.y + 6.0f;
                ImColor textCol(180, 180, 210, 200);
                dl->AddText(ImVec2(textX, textY), C(textCol), rcsStatus);
                ImGui::Dummy(ImVec2(0, textSize.y + 8.0f));
            }
        }
        drawCardGlow(dl, cardStartPos, cardW, ImGui::GetCursorScreenPos().y - cardStartPos.y, mixedAccent, 0.4f);
    }
    M_CardEnd();
    float c5end = ImGui::GetCursorScreenPos().y + 8.0f;
    leftY = c5end;

    float advColY = rightY > c4end ? rightY : c4end;
    ImGui::SetCursorScreenPos(ImVec2(rightColX, advColY));
    bool c6ch = M_CardBegin("###advancedCard", &c6col, accent);
    if (!c6col)
    {
        ImVec2 cardStartPos = ImGui::GetCursorScreenPos();
        M_CyberHeader("ADVANCED", accent, "Additional targeting options");
        {
            M_ModernSwitch("Visibility Check", &t.FilterVisible, accent);
        }
        {
            M_ModernSwitch("Ignore Downed", &t.IgnoreDowned, accent);
        }
        {
            M_ModernSwitch("Target Switch Delay", &t.TargetSwitchDelay, accent);
        }
        {
            float minV = 100.0f;
            float maxV = 2000.0f;
            M_GradientSlider("Switch Delay (ms)", &c.SwitchDelayValue, minV, maxV, "%.0f", accent);
            c.SwitchDelayValue = clampF(c.SwitchDelayValue, minV, maxV);
        }
        {
            float minV = 1.0f;
            float maxV = 10.0f;
            M_GradientSlider("Max Targets", &c.MaxTargetsValue, minV, maxV, "%.0f", accent);
            c.MaxTargetsValue = clampF(c.MaxTargetsValue, minV, maxV);
        }
        {
            if (t.TargetSwitchDelay || t.FilterVisible || t.IgnoreDowned)
            {
                ImVec2 cp = ImGui::GetCursorScreenPos();
                drawActivePulse(dl, ImVec2(rightColX, cp.y), cardW, accent, sinT1, 3.0f);
                char advStatus[64];
                snprintf(advStatus, sizeof(advStatus),
                    "Switch Delay: %.0f ms | Max: %.0f targets",
                    c.SwitchDelayValue, c.MaxTargetsValue);
                ImVec2 textSize = ImGui::CalcTextSize(advStatus);
                float textX = rightColX + (cardW - textSize.x) * 0.5f;
                float textY = cp.y + 6.0f;
                ImColor textCol(180, 180, 210, 200);
                dl->AddText(ImVec2(textX, textY), C(textCol), advStatus);
                ImGui::Dummy(ImVec2(0, textSize.y + 8.0f));
                ImVec2 cp2 = ImGui::GetCursorScreenPos();
                char advDetails[64];
                snprintf(advDetails, sizeof(advDetails),
                    "Vis: %s | Downed: %s | Switch: %s",
                    t.FilterVisible ? "ON" : "OFF",
                    t.IgnoreDowned ? "IGNORE" : "TARGET",
                    t.TargetSwitchDelay ? "ON" : "OFF");
                ImVec2 ts2 = ImGui::CalcTextSize(advDetails);
                float tx2 = rightColX + (cardW - ts2.x) * 0.5f;
                float ty2 = cp2.y + 2.0f;
                ImColor tc2(150, 150, 190, 180);
                dl->AddText(ImVec2(tx2, ty2), C(tc2), advDetails);
                ImGui::Dummy(ImVec2(0, ts2.y + 6.0f));
            }
        }
        {
            ImVec2 cp = ImGui::GetCursorScreenPos();
            drawSectionBar(dl, cp, cardW, accent);
        }
        {
            ImVec2 cp = ImGui::GetCursorScreenPos();
            int enabledCount = (t.FilterVisible ? 1 : 0) + (t.IgnoreDowned ? 1 : 0) + (t.TargetSwitchDelay ? 1 : 0);
            char summaryLine[64];
            snprintf(summaryLine, sizeof(summaryLine),
                "Advanced Options: %d/3 enabled  |  Targets: %.0f",
                enabledCount, c.MaxTargetsValue);
            ImVec2 ts = ImGui::CalcTextSize(summaryLine);
            float tx = rightColX + (cardW - ts.x) * 0.5f;
            ImColor tc(160, 160, 200, 180);
            dl->AddText(ImVec2(tx, cp.y + 2.0f), C(tc), summaryLine);
            ImGui::Dummy(ImVec2(0, ts.y + 6.0f));
        }
        drawCardGlow(dl, cardStartPos, cardW, ImGui::GetCursorScreenPos().y - cardStartPos.y, accent2, 0.3f);
    }
    M_CardEnd();
    float c6end = ImGui::GetCursorScreenPos().y + 8.0f;
    rightY = c6end;

    float bottomMost = leftY > rightY ? leftY : rightY;
    ImGui::SetCursorScreenPos(ImVec2(contentPos.x, bottomMost));

    ImColor summaryBg(0, 0, 0, 30);
    dl->AddRectFilled(
        ImVec2(contentPos.x, bottomMost - 2.0f),
        ImVec2(contentPos.x + contentSize.x, bottomMost + 2.0f),
        C(summaryBg), 1.0f
    );
}
