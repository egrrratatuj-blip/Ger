#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "../../../../imgui/imgui.h"
#include "../../../../imgui/imgui_internal.h"
#include "../../../../imgui/mycustom/imgui_Custom.h"

static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }

bool M_GradientButton(const char* label, ImVec2 size, ImColor colorA, ImColor colorB, float rounding)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    if (size.x == 0.0f)
        size.x = ImGui::CalcTextSize(label).x + 30.0f;
    ImVec2 min = pos;
    ImVec2 max = ImVec2(pos.x + size.x, pos.y + size.y);
    bool hovered = ImGui::IsMouseHoveringRect(min, max);
    bool pressed = ImGui::IsMouseDown(0) && hovered;
    bool clicked = hovered && ImGui::IsMouseClicked(0);
    int shift = 0;
    if (hovered) shift = 20;
    if (pressed) shift = -15;
    float ar = ImClamp(colorA.Value.x * 255.0f + shift, 0.0f, 255.0f) / 255.0f;
    float ag = ImClamp(colorA.Value.y * 255.0f + shift, 0.0f, 255.0f) / 255.0f;
    float ab = ImClamp(colorA.Value.z * 255.0f + shift, 0.0f, 255.0f) / 255.0f;
    float br = ImClamp(colorB.Value.x * 255.0f + shift, 0.0f, 255.0f) / 255.0f;
    float bg = ImClamp(colorB.Value.y * 255.0f + shift, 0.0f, 255.0f) / 255.0f;
    float bb = ImClamp(colorB.Value.z * 255.0f + shift, 0.0f, 255.0f) / 255.0f;
    ImColor ca = ImColor(ar, ag, ab, colorA.Value.w);
    ImColor cb = ImColor(br, bg, bb, colorB.Value.w);
    ImColor shd = ImColor(0, 0, 0, 40);
    ImVec2 shOff = ImVec2(0, 3);
    dl->AddRectFilled(ImVec2(min.x, min.y + shOff.y), ImVec2(max.x, max.y + shOff.y), C(shd), rounding);
    dl->AddRectFilledMultiColor(min, max, C(ca), C(ca), C(cb), C(cb));
    ImColor innerHi = ImColor(255, 255, 255, pressed ? 5 : 25);
    dl->AddRectFilledMultiColor(min, max, C(innerHi), C(innerHi), C(ImColor(0,0,0,0)), C(ImColor(0,0,0,0)));
    ImColor bdCol = ImColor(255, 255, 255, pressed ? 15 : hovered ? 55 : 25);
    dl->AddRect(min, max, C(bdCol), rounding, 0, pressed ? 1.0f : 1.5f);
    ImColor topEdge = ImColor(255, 255, 255, pressed ? 10 : 40);
    ImVec2 teMin = ImVec2(min.x + 2, min.y + 1);
    ImVec2 teMax = ImVec2(max.x - 2, min.y + 2);
    dl->AddRectFilled(teMin, teMax, C(topEdge), rounding * 0.5f);
    {
        static std::map<uintptr_t, AnimFloat> anims;
        auto it = anims.find((uintptr_t)label);
        if (it == anims.end())
            it = anims.emplace((uintptr_t)label, AnimFloat(0.0f)).first;
        auto& a = it->second;
        a.setTarget(hovered ? 1.0f : 0.0f);
        a.update(ImGui::GetIO().DeltaTime);
        float v = a.getValue();
        if (v > 0.01f)
        {
            float al = (sinf(ImGui::GetTime() * 4.0f) * 0.5f + 0.5f) * v * 55.0f;
            dl->AddRect(min, max, C(ImColor(255, 255, 255, (int)al)), rounding, 0, 2.5f);
            float al2 = (sinf(ImGui::GetTime() * 4.0f + 1.0f) * 0.5f + 0.5f) * v * 25.0f;
            dl->AddRect(ImVec2(min.x - 2, min.y - 2), ImVec2(max.x + 2, max.y + 2), C(ImColor(255, 255, 255, (int)al2)), rounding + 1, 0, 1.0f);
        }
    }
    ImVec2 ts = ImGui::CalcTextSize(label);
    ImVec2 tp = ImVec2(pos.x + (size.x - ts.x) * 0.5f, pos.y + (size.y - ts.y) * 0.5f);
    if (pressed) tp.y += 1.0f;
    dl->AddText(ImVec2(tp.x + 1, tp.y + 1), C(ImColor(0, 0, 0, 120)), label);
    ImU32 txtCol = C(hovered ? ImColor(255, 255, 255) : ImColor(240, 240, 255));
    dl->AddText(tp, txtCol, label);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + size.y);
    return clicked;
}

bool M_CyberButton(const char* label, ImVec2 size, ImColor accent)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    if (size.x == 0.0f)
        size.x = ImGui::CalcTextSize(label).x + 36.0f;
    ImVec2 min = pos;
    ImVec2 max = ImVec2(pos.x + size.x, pos.y + size.y);
    float w = size.x;
    float h = size.y;
    bool hovered = ImGui::IsMouseHoveringRect(min, max);
    bool clicked = hovered && ImGui::IsMouseClicked(0);
    dl->AddRectFilled(min, max, C(ImColor(8, 8, 18)));
    ImColor bgHi = ImColor(255, 255, 255, 3);
    dl->AddRectFilled(min, max, C(bgHi));
    ImColor nbCol = hovered ? ImColor(255, 255, 255, 210) : ImColor((int)(accent.Value.x * 255.0f), (int)(accent.Value.y * 255.0f), (int)(accent.Value.z * 255.0f), 180);
    float borderW = hovered ? 3.0f : 2.0f;
    dl->AddRect(min, max, C(nbCol), 0, 0, borderW);
    {
        static std::map<uintptr_t, AnimFloat> glowAnims;
        auto it = glowAnims.find((uintptr_t)label);
        if (it == glowAnims.end())
            it = glowAnims.emplace((uintptr_t)label, AnimFloat(0.0f)).first;
        auto& g = it->second;
        g.setTarget(hovered ? 1.0f : 0.0f);
        g.update(ImGui::GetIO().DeltaTime);
        float gv = g.getValue();
        if (gv > 0.01f)
        {
            ImColor glowCol = ImColor((int)(accent.Value.x * 255.0f), (int)(accent.Value.y * 255.0f), (int)(accent.Value.z * 255.0f), (int)(gv * 45.0f));
            dl->AddRect(min, max, C(glowCol), 0, 0, 8.0f);
            ImColor glowCol2 = ImColor((int)(accent.Value.x * 255.0f), (int)(accent.Value.y * 255.0f), (int)(accent.Value.z * 255.0f), (int)(gv * 20.0f));
            dl->AddRect(ImVec2(min.x - 3, min.y - 3), ImVec2(max.x + 3, max.y + 3), C(glowCol2), 0, 0, 4.0f);
        }
    }
    {
        float perim = 2.0f * (w + h);
        float bracketLen = 10.0f;
        float speed = 0.4f;
        float phase = fmodf(ImGui::GetTime() * speed, 1.0f);
        for (int i = 0; i < 4; i++)
        {
            float ofs = phase + i * 0.25f;
            if (ofs > 1.0f) ofs -= 1.0f;
            float d = ofs * perim;
            float cx, cy;
            int edge;
            if (d < w)
            {
                cx = min.x + d;
                cy = min.y;
                edge = 0;
            }
            else if (d < w + h)
            {
                cx = min.x + w;
                cy = min.y + (d - w);
                edge = 1;
            }
            else if (d < 2.0f * w + h)
            {
                cx = min.x + w - (d - w - h);
                cy = min.y + h;
                edge = 2;
            }
            else
            {
                cx = min.x;
                cy = min.y + h - (d - 2.0f * w - h);
                edge = 3;
            }
            ImU32 bc = C(hovered ? ImColor(255, 255, 255, 240) : ImColor((int)(accent.Value.x * 255.0f), (int)(accent.Value.y * 255.0f), (int)(accent.Value.z * 255.0f), 200));
            float bl = bracketLen;
            float gloLen = bl + 4.0f;
            ImU32 gc = C(ImColor(255, 255, 255, 30));
            switch (edge)
            {
                case 0:
                    dl->AddLine(ImVec2(cx - 1, cy), ImVec2(cx - 1 + gloLen, cy), gc, 3.0f);
                    dl->AddLine(ImVec2(cx, cy - 1), ImVec2(cx, cy - 1 + gloLen), gc, 3.0f);
                    dl->AddLine(ImVec2(cx, cy), ImVec2(cx + bl, cy), bc, 2.0f);
                    dl->AddLine(ImVec2(cx, cy), ImVec2(cx, cy + bl), bc, 2.0f);
                    break;
                case 1:
                    dl->AddLine(ImVec2(cx, cy - 1), ImVec2(cx, cy - 1 + gloLen), gc, 3.0f);
                    dl->AddLine(ImVec2(cx + 1, cy), ImVec2(cx + 1 - gloLen, cy), gc, 3.0f);
                    dl->AddLine(ImVec2(cx, cy), ImVec2(cx, cy + bl), bc, 2.0f);
                    dl->AddLine(ImVec2(cx, cy), ImVec2(cx - bl, cy), bc, 2.0f);
                    break;
                case 2:
                    dl->AddLine(ImVec2(cx + 1, cy), ImVec2(cx + 1 - gloLen, cy), gc, 3.0f);
                    dl->AddLine(ImVec2(cx, cy + 1), ImVec2(cx, cy + 1 - gloLen), gc, 3.0f);
                    dl->AddLine(ImVec2(cx, cy), ImVec2(cx - bl, cy), bc, 2.0f);
                    dl->AddLine(ImVec2(cx, cy), ImVec2(cx, cy - bl), bc, 2.0f);
                    break;
                case 3:
                    dl->AddLine(ImVec2(cx, cy + 1), ImVec2(cx, cy + 1 - gloLen), gc, 3.0f);
                    dl->AddLine(ImVec2(cx - 1, cy), ImVec2(cx - 1 + gloLen, cy), gc, 3.0f);
                    dl->AddLine(ImVec2(cx, cy), ImVec2(cx, cy - bl), bc, 2.0f);
                    dl->AddLine(ImVec2(cx, cy), ImVec2(cx + bl, cy), bc, 2.0f);
                    break;
            }
        }
    }
    {
        for (int i = -(int)h; i < (int)(w + h); i += 4)
        {
            float a = hovered ? 8.0f : 4.0f;
            dl->AddLine(ImVec2(min.x + i, min.y), ImVec2(min.x + i - h, min.y + h), C(ImColor(255, 255, 255, (int)a)));
        }
    }
    {
        ImVec2 ts = ImGui::CalcTextSize(label);
        ImVec2 tp = ImVec2(min.x + (w - ts.x) * 0.5f, min.y + (h - ts.y) * 0.5f);
        ImU32 tc = C(hovered ? ImColor(255, 255, 255) : accent);
        dl->AddText(ImVec2(tp.x + 1, tp.y + 1), C(ImColor(0, 0, 0, 80)), label);
        dl->AddText(tp, tc, label);
    }
    {
        static std::map<uintptr_t, float> ftimes;
        auto fi = ftimes.find((uintptr_t)label);
        if (fi == ftimes.end())
        {
            ftimes[(uintptr_t)label] = -1.0f;
            fi = ftimes.find((uintptr_t)label);
        }
        if (clicked)
            fi->second = ImGui::GetTime();
        if (fi->second > 0.0f)
        {
            float elapsed = (float)(ImGui::GetTime() - fi->second);
            if (elapsed > 0.4f)
                fi->second = -1.0f;
            else
            {
                float fa = (1.0f - elapsed / 0.4f) * 0.55f;
                dl->AddRectFilled(min, max, C(ImColor(accent.Value.x, accent.Value.y, accent.Value.z, fa)));
                float fw = (1.0f - elapsed / 0.4f) * 10.0f;
                dl->AddRect(min, max, C(ImColor(255, 255, 255, (int)(fw * 20.0f))), 0, 0, fw);
            }
        }
    }
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + size.y);
    return clicked;
}

bool M_IconButton(const char* icon, const char* tooltip, ImVec2 size, ImColor accent, bool hasBadge, int badgeCount)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImVec2 min = pos;
    ImVec2 max = ImVec2(pos.x + size.x, pos.y + size.y);
    bool hovered = ImGui::IsMouseHoveringRect(min, max);
    bool pressed = ImGui::IsMouseDown(0) && hovered;
    bool clicked = hovered && ImGui::IsMouseClicked(0);
    float radius = size.x * 0.5f;
    ImVec2 center = ImVec2(pos.x + radius, pos.y + radius);
    {
        static std::map<uintptr_t, AnimFloat> pressAnims;
        auto pa = pressAnims.find((uintptr_t)icon);
        if (pa == pressAnims.end())
            pa = pressAnims.emplace((uintptr_t)icon, AnimFloat(1.0f)).first;
        auto& pAnim = pa->second;
        if (pressed) pAnim.setTarget(0.92f);
        else pAnim.setTarget(1.0f);
        pAnim.update(ImGui::GetIO().DeltaTime);
        float scale = pAnim.getValue();
        if (scale < 0.99f)
        {
            float sw = size.x * scale;
            float sh = size.y * scale;
            float sx = center.x - sw * 0.5f;
            float sy = center.y - sh * 0.5f;
            dl->AddRectFilled(ImVec2(sx, sy), ImVec2(sx + sw, sy + sh), C(ImColor(30, 30, 45)), radius);
        }
    }
    dl->AddRectFilled(min, max, C(ImColor(30, 30, 45)), radius);
    ImColor ac = hovered ? ImColor(255, 255, 255, 90) : ImColor((int)(accent.Value.x * 255.0f), (int)(accent.Value.y * 255.0f), (int)(accent.Value.z * 255.0f), 60);
    dl->AddRect(min, max, C(ac), radius, 0, 1.5f);
    if (hovered)
    {
        ImColor hc = ImColor((int)(accent.Value.x * 255.0f), (int)(accent.Value.y * 255.0f), (int)(accent.Value.z * 255.0f), 35);
        dl->AddRectFilled(min, max, C(hc), radius);
        {
            static std::map<uintptr_t, AnimFloat> tooltipAnims;
            auto tt = tooltipAnims.find((uintptr_t)icon);
            if (tt == tooltipAnims.end())
                tt = tooltipAnims.emplace((uintptr_t)icon, AnimFloat(0.0f)).first;
            tt->second.setTarget(1.0f);
            tt->second.update(ImGui::GetIO().DeltaTime);
            float tta = tt->second.getValue();
            if (tta > 0.01f && tooltip)
            {
                ImVec2 tts = ImGui::CalcTextSize(tooltip);
                float tw = tts.x + 22.0f;
                float th = 28.0f;
                ImVec2 tmin = ImVec2(pos.x + (size.x - tw) * 0.5f, pos.y - th - 10.0f);
                ImVec2 tmax = ImVec2(tmin.x + tw, tmin.y + th);
                ImColor tbg = ImColor(18, 18, 32, (int)(tta * 230.0f));
                dl->AddRectFilled(tmin, tmax, C(tbg), 6.0f);
                ImColor tbd = ImColor(255, 255, 255, (int)(tta * 45.0f));
                dl->AddRect(tmin, tmax, C(tbd), 6.0f, 0, 1.0f);
                ImVec2 ttp = ImVec2(tmin.x + 11.0f, tmin.y + (th - tts.y) * 0.5f);
                ImU32 ttxt = C(ImColor(255, 255, 255, (int)(tta * 255.0f)));
                dl->AddText(ttp, ttxt, tooltip);
                ImVec2 arrP0 = ImVec2(pos.x + size.x * 0.5f - 4.0f, pos.y - 2.0f);
                ImVec2 arrP1 = ImVec2(pos.x + size.x * 0.5f, pos.y - 6.0f);
                ImVec2 arrP2 = ImVec2(pos.x + size.x * 0.5f + 4.0f, pos.y - 2.0f);
                dl->AddTriangleFilled(arrP0, arrP1, arrP2, C(ImColor(18, 18, 32, (int)(tta * 230.0f))));
            }
        }
    }
    else
    {
        static std::map<uintptr_t, AnimFloat> tooltipAnims;
        auto tt = tooltipAnims.find((uintptr_t)icon);
        if (tt != tooltipAnims.end())
        {
            tt->second.setTarget(0.0f);
            tt->second.update(ImGui::GetIO().DeltaTime);
        }
    }
    ImU32 iconCol = C(ImColor(255, 255, 255));
    ImVec2 iconSize = ImGui::CalcTextSize(icon);
    ImVec2 iconPos = ImVec2(center.x - iconSize.x * 0.5f, center.y - iconSize.y * 0.5f);
    dl->AddText(iconPos, iconCol, icon);
    if (hasBadge && badgeCount > 0)
    {
        static std::map<uintptr_t, AnimFloat> badgeAnims;
        static std::map<uintptr_t, int> prevCounts;
        auto ba = badgeAnims.find((uintptr_t)icon);
        if (ba == badgeAnims.end())
            ba = badgeAnims.emplace((uintptr_t)icon, AnimFloat(1.0f)).first;
        auto pc = prevCounts.find((uintptr_t)icon);
        if (pc == prevCounts.end())
        {
            prevCounts[(uintptr_t)icon] = badgeCount;
            pc = prevCounts.find((uintptr_t)icon);
        }
        if (pc->second != badgeCount)
        {
            ba->second.setTarget(1.5f);
            pc->second = badgeCount;
        }
        ba->second.update(ImGui::GetIO().DeltaTime);
        if (ba->second.getValue() > 1.4f)
            ba->second.setTarget(1.0f);
        float bscale = ba->second.getValue();
        ImVec2 bpos = ImVec2(max.x - 9.0f, min.y + 9.0f);
        float brad = 8.0f * bscale;
        dl->AddCircleFilled(bpos, brad, C(ImColor(230, 40, 55)));
        dl->AddCircle(bpos, brad, C(ImColor(255, 100, 100, 80)), 0, 1.5f);
        char buf[16];
        ImFormatString(buf, sizeof(buf), "%d", badgeCount);
        ImVec2 bts = ImGui::CalcTextSize(buf);
        dl->AddText(ImVec2(bpos.x - bts.x * 0.5f, bpos.y - bts.y * 0.5f), C(ImColor(255, 255, 255)), buf);
    }
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + size.y);
    return clicked;
}

bool M_ActionButton(const char* icon, const char* label, ImVec2 size, ImColor accent, const char* shortcut)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    ImVec2 min = pos;
    ImVec2 max = ImVec2(pos.x + size.x, pos.y + size.y);
    bool hovered = ImGui::IsMouseHoveringRect(min, max);
    bool pressed = ImGui::IsMouseDown(0) && hovered;
    bool clicked = hovered && ImGui::IsMouseClicked(0);
    if (hovered)
        dl->AddRectFilled(min, max, C(ImColor(255, 255, 255, 14)));
    dl->AddRect(min, max, C(ImColor(255, 255, 255, 8)), 6.0f, 0, 1.0f);
    float is = 32.0f;
    float iy = min.y + (size.y - is) * 0.5f;
    ImVec2 imin = ImVec2(min.x + 8.0f, iy);
    ImVec2 imax = ImVec2(imin.x + is, imin.y + is);
    ImColor iconBg = pressed ? ImColor(
        ImMax(0, (int)(accent.Value.x * 255.0f) - 30),
        ImMax(0, (int)(accent.Value.y * 255.0f) - 30),
        ImMax(0, (int)(accent.Value.z * 255.0f) - 30)
    ) : hovered ? ImColor(
        ImMin(255, (int)(accent.Value.x * 255.0f) + 15),
        ImMin(255, (int)(accent.Value.y * 255.0f) + 15),
        ImMin(255, (int)(accent.Value.z * 255.0f) + 15)
    ) : accent;
    dl->AddRectFilled(imin, imax, C(iconBg), 5.0f);
    if (hovered)
    {
        ImColor igh = ImColor(255, 255, 255, 25);
        dl->AddRect(imin, imax, C(igh), 5.0f, 0, 1.5f);
    }
    ImVec2 iconSize = ImGui::CalcTextSize(icon);
    dl->AddText(ImVec2(imin.x + (is - iconSize.x) * 0.5f, imin.y + (is - iconSize.y) * 0.5f), C(ImColor(255, 255, 255)), icon);
    ImVec2 lblSize = ImGui::CalcTextSize(label);
    ImVec2 lblPos = ImVec2(imin.x + is + 12.0f, min.y + (size.y - lblSize.y) * 0.5f);
    ImU32 lblCol = C(hovered ? ImColor(240, 240, 255) : ImColor(200, 200, 225));
    dl->AddText(lblPos, lblCol, label);
    if (shortcut && shortcut[0])
    {
        ImVec2 shSize = ImGui::CalcTextSize(shortcut);
        ImVec2 shPos = ImVec2(max.x - shSize.x - 14.0f, min.y + (size.y - shSize.y) * 0.5f);
        ImColor shBg = ImColor(255, 255, 255, 8);
        dl->AddRectFilled(ImVec2(shPos.x - 6, shPos.y - 2), ImVec2(shPos.x + shSize.x + 6, shPos.y + shSize.y + 2), C(shBg), 3.0f);
        dl->AddText(shPos, C(ImColor(130, 130, 160)), shortcut);
    }
    {
        static std::map<uintptr_t, AnimFloat> rippleAnims;
        static std::map<uintptr_t, ImVec2> rippleOrgs;
        auto ri = rippleAnims.find((uintptr_t)label);
        if (ri == rippleAnims.end())
            ri = rippleAnims.emplace((uintptr_t)label, AnimFloat(0.0f)).first;
        if (clicked)
        {
            ri->second.setTarget(1.0f);
            ImVec2 mp = ImGui::GetMousePos();
            rippleOrgs[(uintptr_t)label] = ImVec2(mp.x - min.x, mp.y - min.y);
        }
        ri->second.update(ImGui::GetIO().DeltaTime);
        float rv = ri->second.getValue();
        if (rv > 0.98f)
            ri->second.setTarget(0.0f);
        if (rv > 0.01f)
        {
            ImVec2 ro = rippleOrgs[(uintptr_t)label];
            float maxDist = sqrtf(size.x * size.x + size.y * size.y);
            float rad = rv * maxDist;
            int ra = (int)((1.0f - rv) * 80.0f);
            dl->AddCircleFilled(ImVec2(min.x + ro.x, min.y + ro.y), rad, C(ImColor(255, 255, 255, ra)));
            int ra2 = (int)((1.0f - rv) * 40.0f);
            dl->AddCircle(ImVec2(min.x + ro.x, min.y + ro.y), rad, C(ImColor((int)(accent.Value.x * 255.0f), (int)(accent.Value.y * 255.0f), (int)(accent.Value.z * 255.0f), ra2)), 0, 2.0f);
        }
    }
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + size.y);
    return clicked;
}

int M_ButtonGroup(const char* label, int* active, const char** options, int count, ImColor accent)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float width = ImGui::GetContentRegionAvail().x;
    float itemWidth = width / count;
    float height = 40.0f;
    float rounding = 6.0f;
    int result = -1;
    ImVec2 gmin = pos;
    ImVec2 gmax = ImVec2(pos.x + width, pos.y + height);
    ImColor gbg = ImColor(16, 16, 30);
    dl->AddRectFilled(gmin, gmax, C(gbg), rounding);
    {
        static std::map<uintptr_t, AnimFloat> slideAnims;
        auto si = slideAnims.find((uintptr_t)label);
        if (si == slideAnims.end())
            si = slideAnims.emplace((uintptr_t)label, AnimFloat(*active * itemWidth)).first;
        si->second.setTarget(*active * itemWidth);
        si->second.update(ImGui::GetIO().DeltaTime);
        float slideX = si->second.getValue();
        ImVec2 hlMin = ImVec2(pos.x + slideX, pos.y);
        ImVec2 hlMax = ImVec2(hlMin.x + itemWidth, pos.y + height);
        if (hlMin.x < gmin.x) hlMin.x = gmin.x;
        if (hlMax.x > gmax.x) hlMax.x = gmax.x;
        int vi = (int)(slideX / itemWidth + 0.5f);
        if (vi < 0) vi = 0;
        if (vi >= count) vi = count - 1;
        ImDrawFlags hlf = ImDrawFlags_RoundCornersNone;
        if (hlMin.x <= gmin.x + 0.5f) hlf |= ImDrawFlags_RoundCornersLeft;
        if (hlMax.x >= gmax.x - 0.5f) hlf |= ImDrawFlags_RoundCornersRight;
        dl->AddRectFilled(hlMin, hlMax, C(accent), rounding, hlf);
        ImColor hiTop = ImColor(255, 255, 255, 25);
        dl->AddRectFilled(ImVec2(hlMin.x, hlMin.y), ImVec2(hlMax.x, hlMin.y + 2), C(hiTop), 0.0f);
    }
    for (int i = 0; i < count; i++)
    {
        float bx = pos.x + i * itemWidth;
        ImVec2 bMin = ImVec2(bx, pos.y);
        ImVec2 bMax = ImVec2(bx + itemWidth, pos.y + height);
        bool btnHovered = ImGui::IsMouseHoveringRect(bMin, bMax);
        if (btnHovered && ImGui::IsMouseClicked(0))
        {
            if (i != *active)
            {
                *active = i;
                result = i;
            }
        }
        if (btnHovered)
        {
            ImDrawFlags hvf = ImDrawFlags_RoundCornersNone;
            if (i == 0) hvf |= ImDrawFlags_RoundCornersLeft;
            if (i == count - 1) hvf |= ImDrawFlags_RoundCornersRight;
            dl->AddRectFilled(bMin, bMax, C(ImColor(255, 255, 255, 10)), rounding, hvf);
        }
        if (i < count - 1)
        {
            float sx = bx + itemWidth;
            ImColor sepCol = ImColor(50, 50, 70);
            dl->AddLine(ImVec2(sx, pos.y + 5), ImVec2(sx, pos.y + height - 5), C(sepCol), 1.0f);
            if (*active == i)
            {
                dl->AddLine(ImVec2(sx, pos.y + 3), ImVec2(sx, pos.y + height - 3), C(ImColor(255, 255, 255, 15)), 1.0f);
            }
        }
        ImVec2 ts = ImGui::CalcTextSize(options[i]);
        ImVec2 tp = ImVec2(bx + (itemWidth - ts.x) * 0.5f, pos.y + (height - ts.y) * 0.5f);
        ImU32 tc = C(i == *active ? ImColor(255, 255, 255) : accent);
        dl->AddText(tp, tc, options[i]);
    }
    ImColor gbd = ImColor(60, 60, 80, 100);
    dl->AddRect(gmin, gmax, C(gbd), rounding, 0, 1.0f);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + height);
    return result;
}

bool M_FloatingActionButton(const char* icon, ImVec2 position, float size, ImColor accent)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    float radius = size * 0.5f;
    ImVec2 center = ImVec2(position.x + radius, position.y + radius);
    ImVec2 min = position;
    ImVec2 max = ImVec2(position.x + size, position.y + size);
    bool hovered = ImGui::IsMouseHoveringRect(min, max);
    bool clicked = hovered && ImGui::IsMouseClicked(0);
    static std::map<uintptr_t, AnimFloat> floatAnims;
    auto fi = floatAnims.find((uintptr_t)icon);
    if (fi == floatAnims.end())
        fi = floatAnims.emplace((uintptr_t)icon, AnimFloat(0.0f)).first;
    fi->second.setTarget(hovered ? 1.0f : 0.0f);
    fi->second.update(ImGui::GetIO().DeltaTime);
    float fv = fi->second.getValue();
    float hoverSin = sinf(ImGui::GetTime() * 3.0f) * 2.0f * fv;
    float yOff = -fv * 6.0f + hoverSin;
    ImVec2 fc = ImVec2(center.x, center.y + yOff);
    ImColor shC = ImColor(0, 0, 0, 8);
    dl->AddCircleFilled(ImVec2(fc.x, fc.y + 6.0f), radius + 8.0f, C(shC));
    for (int i = 5; i >= 0; i--)
    {
        float sr = radius + 2.0f + i * 3.0f;
        int sa = 4 + i * 3;
        ImColor sc = ImColor(0, 0, 0, sa);
        dl->AddCircleFilled(ImVec2(fc.x, fc.y + 4.0f), sr, C(sc));
    }
    if (hovered)
    {
        static std::map<uintptr_t, AnimFloat> pulseAnims;
        auto pi = pulseAnims.find((uintptr_t)icon);
        if (pi == pulseAnims.end())
            pi = pulseAnims.emplace((uintptr_t)icon, AnimFloat(0.0f)).first;
        pi->second.setTarget(1.0f);
        pi->second.update(ImGui::GetIO().DeltaTime);
        float pv = pi->second.getValue();
        float pulseR = radius + 4.0f + pv * 14.0f;
        int pa = (int)((1.0f - pv) * 60.0f);
        ImColor pc = ImColor((int)(accent.Value.x * 255.0f), (int)(accent.Value.y * 255.0f), (int)(accent.Value.z * 255.0f), pa);
        dl->AddCircle(fc, pulseR, C(pc), 0, 2.5f);
        if (pi->second.getValue() > 0.95f)
            pi->second.setTarget(0.0f);
    }
    else
    {
        float pulsePhase = fmodf(ImGui::GetTime() * 1.2f, 1.0f);
        float pulseR = radius + 4.0f + pulsePhase * 10.0f;
        int pa = (int)((1.0f - pulsePhase) * 45.0f);
        dl->AddCircle(fc, pulseR, C(ImColor((int)(accent.Value.x * 255.0f), (int)(accent.Value.y * 255.0f), (int)(accent.Value.z * 255.0f), pa)), 0, 2.0f);
    }
    ImColor fabBg = hovered ? ImColor(
        ImMin(255, (int)(accent.Value.x * 255.0f) + 25),
        ImMin(255, (int)(accent.Value.y * 255.0f) + 25),
        ImMin(255, (int)(accent.Value.z * 255.0f) + 25)
    ) : ImColor(
        (int)(accent.Value.x * 255.0f),
        (int)(accent.Value.y * 255.0f),
        (int)(accent.Value.z * 255.0f)
    );
    dl->AddCircleFilled(fc, radius, C(fabBg));
    if (hovered)
    {
        dl->AddCircle(fc, radius, C(ImColor(255, 255, 255, 70)), 0, 2.5f);
        ImColor innerGlow = ImColor(255, 255, 255, 20);
        dl->AddCircleFilled(fc, radius - 2.0f, C(innerGlow));
    }
    ImColor icoCol = hovered ? ImColor(255, 255, 255) : ImColor(240, 240, 255);
    ImVec2 iconSize = ImGui::CalcTextSize(icon);
    dl->AddText(ImVec2(fc.x - iconSize.x * 0.5f, fc.y - iconSize.y * 0.5f), C(icoCol), icon);
    return clicked;
}

bool M_MenuButton(const char* label, bool isOpen, ImColor accent)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float width = ImGui::GetContentRegionAvail().x;
    float height = 40.0f;
    ImVec2 min = pos;
    ImVec2 max = ImVec2(pos.x + width, pos.y + height);
    bool hovered = ImGui::IsMouseHoveringRect(min, max);
    bool pressed = ImGui::IsMouseDown(0) && hovered;
    bool clicked = hovered && ImGui::IsMouseClicked(0);
    if (hovered)
    {
        ImColor ht = ImColor(255, 255, 255, 14);
        if (pressed) ht = ImColor(255, 255, 255, 22);
        dl->AddRectFilled(min, max, C(ht));
    }
    ImVec2 ts = ImGui::CalcTextSize(label);
    ImU32 lblCol = C(hovered ? ImColor(230, 230, 250) : ImColor(190, 190, 215));
    dl->AddText(ImVec2(pos.x + 16.0f, pos.y + (height - ts.y) * 0.5f), lblCol, label);
    ImColor botLine = ImColor(60, 60, 80, 80);
    dl->AddLine(ImVec2(pos.x + 12, pos.y + height - 1), ImVec2(pos.x + width - 12, pos.y + height - 1), C(botLine), 1.0f);
    {
        static std::map<uintptr_t, AnimFloat> chevAnims;
        auto ci = chevAnims.find((uintptr_t)label);
        if (ci == chevAnims.end())
            ci = chevAnims.emplace((uintptr_t)label, AnimFloat(isOpen ? 1.0f : 0.0f)).first;
        ci->second.setTarget(isOpen ? 1.0f : 0.0f);
        ci->second.update(ImGui::GetIO().DeltaTime);
        float rot = ci->second.getValue() * 90.0f;
        float rad = rot * 3.14159265f / 180.0f;
        float cr = 5.0f;
        ImVec2 cc = ImVec2(pos.x + width - 20.0f, pos.y + height * 0.5f);
        float ca = cosf(rad);
        float sa = sinf(rad);
        ImVec2 v0 = ImVec2(cc.x + cr * 1.5f * ca, cc.y + cr * 1.5f * sa);
        ImVec2 v1 = ImVec2(cc.x + cr * ca - (-cr) * sa, cc.y + cr * sa + (-cr) * ca);
        ImVec2 v2 = ImVec2(cc.x + cr * ca - cr * sa, cc.y + cr * sa + cr * ca);
        v0 = ImVec2(cc.x + cr * 1.5f * ca - 0.0f * sa, cc.y + cr * 1.5f * sa + 0.0f * ca);
        v1 = ImVec2(cc.x + 0.0f * ca - (-cr) * sa, cc.y + 0.0f * sa + (-cr) * ca);
        v2 = ImVec2(cc.x + 0.0f * ca - cr * sa, cc.y + 0.0f * sa + cr * ca);
        ImU32 chevCol = C(hovered ? ImColor(180, 180, 210) : ImColor(140, 140, 170));
        dl->AddTriangleFilled(v0, v1, v2, chevCol);
    }
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + height);
    return clicked;
}

bool M_SplitButton(const char* label, ImVec2 size, ImColor accent)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    if (size.x == 0.0f)
        size.x = ImGui::CalcTextSize(label).x + 40.0f;
    ImVec2 min = pos;
    ImVec2 max = ImVec2(pos.x + size.x, pos.y + size.y);
    float mainW = size.x * 0.7f;
    float dropW = size.x * 0.3f;
    ImVec2 mMin = min;
    ImVec2 mMax = ImVec2(pos.x + mainW, max.y);
    ImVec2 dMin = ImVec2(pos.x + mainW, min.y);
    ImVec2 dMax = max;
    bool mHov = ImGui::IsMouseHoveringRect(mMin, mMax);
    bool dHov = ImGui::IsMouseHoveringRect(dMin, dMax);
    bool mPressed = ImGui::IsMouseDown(0) && mHov;
    bool dPressed = ImGui::IsMouseDown(0) && dHov;
    bool mClk = mHov && ImGui::IsMouseClicked(0);
    bool dClk = dHov && ImGui::IsMouseClicked(0);
    ImColor ca = accent;
    ImColor cb = ImColor(
        ImMin(255.0f, accent.Value.x * 255.0f * 0.7f) / 255.0f,
        ImMin(255.0f, accent.Value.y * 255.0f * 0.7f) / 255.0f,
        ImMin(255.0f, accent.Value.z * 255.0f * 0.7f) / 255.0f,
        accent.Value.w
    );
    int shift = 0;
    if (mHov) shift = 20;
    if (mPressed) shift = -15;
    float mar = ImClamp(ca.Value.x * 255.0f + shift, 0.0f, 255.0f) / 255.0f;
    float mag = ImClamp(ca.Value.y * 255.0f + shift, 0.0f, 255.0f) / 255.0f;
    float mab = ImClamp(ca.Value.z * 255.0f + shift, 0.0f, 255.0f) / 255.0f;
    float mbr = ImClamp(cb.Value.x * 255.0f + shift, 0.0f, 255.0f) / 255.0f;
    float mbg = ImClamp(cb.Value.y * 255.0f + shift, 0.0f, 255.0f) / 255.0f;
    float mbb = ImClamp(cb.Value.z * 255.0f + shift, 0.0f, 255.0f) / 255.0f;
    ImColor mca = ImColor(mar, mag, mab, ca.Value.w);
    ImColor mcb = ImColor(mbr, mbg, mbb, cb.Value.w);
    dl->AddRectFilledMultiColor(mMin, mMax, C(mca), C(mca), C(mcb), C(mcb));
    ImColor mbd = ImColor(255, 255, 255, mHov ? 50 : 25);
    dl->AddRect(mMin, mMax, C(mbd), 0, 0, 1.0f);
    ImColor dbg = dHov ? ImColor(255, 255, 255, 20) : ImColor(12, 12, 22, 220);
    dl->AddRectFilled(dMin, dMax, C(dbg));
    float sepX = pos.x + mainW;
    ImColor sepCol = dHov ? ImColor(255, 255, 255, 40) : ImColor(255, 255, 255, 25);
    dl->AddLine(ImVec2(sepX, min.y + 4), ImVec2(sepX, max.y - 4), C(sepCol), 1.5f);
    if (dHov)
    {
        ImColor dgl = ImColor((int)(accent.Value.x * 255.0f), (int)(accent.Value.y * 255.0f), (int)(accent.Value.z * 255.0f), 35);
        dl->AddRectFilled(dMin, dMax, C(dgl));
        dl->AddRect(dMin, dMax, C(ImColor(255, 255, 255, 30)), 0, 0, 1.0f);
    }
    if (dPressed)
    {
        dl->AddRectFilled(dMin, dMax, C(ImColor(0, 0, 0, 40)));
    }
    ImVec2 ts = ImGui::CalcTextSize(label);
    ImVec2 tp = ImVec2(mMin.x + (mainW - ts.x) * 0.5f, mMin.y + (size.y - ts.y) * 0.5f);
    if (mPressed) tp.y += 1.0f;
    dl->AddText(ImVec2(tp.x + 1, tp.y + 1), C(ImColor(0, 0, 0, 100)), label);
    dl->AddText(tp, C(ImColor(255, 255, 255)), label);
    float dr = 4.0f;
    ImVec2 dc = ImVec2(sepX + dropW * 0.5f, min.y + size.y * 0.5f);
    float dRad = 90.0f * 3.14159265f / 180.0f;
    float dca = cosf(dRad);
    float dsa = sinf(dRad);
    ImVec2 dv0 = ImVec2(dc.x + dr * 1.5f * dca - 0.0f * dsa, dc.y + dr * 1.5f * dsa + 0.0f * dca);
    ImVec2 dv1 = ImVec2(dc.x + 0.0f * dca - (-dr) * dsa, dc.y + 0.0f * dsa + (-dr) * dca);
    ImVec2 dv2 = ImVec2(dc.x + 0.0f * dca - dr * dsa, dc.y + 0.0f * dsa + dr * dca);
    ImU32 arrCol = C(dHov ? ImColor(220, 220, 250) : ImColor(160, 160, 200));
    dl->AddTriangleFilled(dv0, dv1, dv2, arrCol);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + size.y);
    return mClk || dClk;
}

bool M_CloseButton(ImVec2 position, float size, ImColor color)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 min = position;
    ImVec2 max = ImVec2(position.x + size, position.y + size);
    bool hovered = ImGui::IsMouseHoveringRect(min, max);
    bool pressed = ImGui::IsMouseDown(0) && hovered;
    bool clicked = hovered && ImGui::IsMouseClicked(0);
    float radius = size * 0.5f;
    ImVec2 center = ImVec2(position.x + radius, position.y + radius);
    if (hovered)
    {
        ImColor hBg = pressed ? ImColor(180, 40, 50, 230) : ImColor(200, 50, 60, 200);
        dl->AddCircleFilled(center, radius, C(hBg));
        dl->AddCircle(center, radius, C(ImColor(230, 90, 100, 120)), 0, 2.5f);
    }
    else
    {
        ImColor bg = ImColor((int)(color.Value.x * 255.0f), (int)(color.Value.y * 255.0f), (int)(color.Value.z * 255.0f), 12);
        dl->AddCircleFilled(center, radius, C(bg));
        dl->AddCircle(center, radius, C(color), 0, 1.5f);
    }
    float in = radius * 0.38f;
    float lx1 = position.x + in;
    float ly1 = position.y + in;
    float lx2 = position.x + size - in;
    float ly2 = position.y + size - in;
    ImU32 lc = C(hovered ? ImColor(255, 255, 255) : color);
    float lw = pressed ? 3.0f : hovered ? 2.5f : 1.8f;
    dl->AddLine(ImVec2(lx1, ly1), ImVec2(lx2, ly2), lc, lw);
    dl->AddLine(ImVec2(lx2, ly1), ImVec2(lx1, ly2), lc, lw);
    return clicked;
}
