#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "../../../imgui/imgui.h"
#include "../../../imgui/imgui_internal.h"
#include "../../../imgui/mycustom/imgui_Custom.h"
#include <math.h>
#include <string.h>
#include <map>
#include <stdlib.h>

static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }

bool M_ColorPicker(const char* label, float col[4], ImColor accent)
{
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGuiContext& g = *GImGui;
    ImGui::PushID(label);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 4.0f);

    ImVec2 pos = ImGui::GetCursorScreenPos();
    float fullWidth = ImGui::GetContentRegionAvail().x;
    if (fullWidth < 200.0f) fullWidth = 200.0f;

    ImVec2 labelSize = ImGui::CalcTextSize(label);
    ImGui::RenderText(ImVec2(pos.x, pos.y), label);

    float previewSize = 40.0f;
    float previewX = pos.x + fullWidth - previewSize - 4.0f;
    float previewY = pos.y + labelSize.y + 6.0f;
    ImVec2 previewMin(previewX, previewY);
    ImVec2 previewMax(previewX + previewSize, previewY + previewSize);

    draw->AddRectFilled(previewMin, previewMax, C(ImColor(col[0], col[1], col[2], col[3])), 4.0f);
    draw->AddRect(previewMin, previewMax, C(ImColor(60, 60, 60)), 4.0f);

    float hueWidth = fullWidth - previewSize - 12.0f;
    float hueY = previewY;
    float hueHeight = 12.0f;

    ImVec2 hueMin(pos.x + 4.0f, hueY);
    ImVec2 hueMax(pos.x + 4.0f + hueWidth, hueY + hueHeight);

    int hueSteps = (int)hueWidth;
    if (hueSteps < 6) hueSteps = 6;
    for (int i = 0; i < hueSteps; i++)
    {
        float f1 = (float)i / (float)(hueSteps - 1);
        float f2 = (float)(i + 1) / (float)(hueSteps - 1);
        float r1, g1, b1, r2, g2, b2;
        ImGui::ColorConvertHSVtoRGB(f1, 1.0f, 1.0f, r1, g1, b1);
        ImGui::ColorConvertHSVtoRGB(f2, 1.0f, 1.0f, r2, g2, b2);
        float x1 = hueMin.x + f1 * hueWidth;
        float x2 = hueMin.x + f2 * hueWidth;
        draw->AddRectFilledMultiColor(ImVec2(x1, hueMin.y), ImVec2(x2, hueMax.y),
            C(ImColor(r1, g1, b1)), C(ImColor(r2, g2, b2)), C(ImColor(r2, g2, b2)), C(ImColor(r1, g1, b1)));
    }
    draw->AddRect(hueMin, hueMax, C(ImColor(60, 60, 60)), 2.0f);

    float hue, s, v;
    ImGui::ColorConvertRGBtoHSV(col[0], col[1], col[2], hue, s, v);

    float hueT = hue;
    float hueGrabberX = hueMin.x + hueT * hueWidth;
    draw->AddCircleFilled(ImVec2(hueGrabberX, hueMin.y + hueHeight * 0.5f), 6.0f, C(ImColor(255, 255, 255)));
    draw->AddCircle(ImVec2(hueGrabberX, hueMin.y + hueHeight * 0.5f), 6.0f, C(ImColor(100, 100, 100)));

    ImRect hueRect(hueMin, hueMax);
    hueRect.Min.y -= 4.0f;
    hueRect.Max.y += 4.0f;
    hueRect.Min.x -= 4.0f;
    hueRect.Max.x += 4.0f;

    float svY = hueY + hueHeight + 8.0f;
    float svSize = 100.0f;
    float svX = pos.x + 4.0f;

    ImVec2 svMin(svX, svY);
    ImVec2 svMax(svX + svSize, svY + svSize);

    int svSteps = (int)svSize;
    if (svSteps < 4) svSteps = 4;
    for (int sy = 0; sy < svSteps; sy++)
    {
        for (int sx = 0; sx < svSteps; sx++)
        {
            float fv = 1.0f - (float)sy / (float)(svSteps - 1);
            float fs = (float)sx / (float)(svSteps - 1);
            float r, g, b;
            ImGui::ColorConvertHSVtoRGB(hue, fs, fv, r, g, b);
            float x1 = svMin.x + (float)sx / (float)(svSteps - 1) * svSize;
            float y1 = svMin.y + (float)sy / (float)(svSteps - 1) * svSize;
            float x2 = svMin.x + (float)(sx + 1) / (float)(svSteps - 1) * svSize;
            float y2 = svMin.y + (float)(sy + 1) / (float)(svSteps - 1) * svSize;
            draw->AddRectFilled(ImVec2(x1, y1), ImVec2(x2, y2), C(ImColor(r, g, b)));
        }
    }
    draw->AddRect(svMin, svMax, C(ImColor(60, 60, 60)), 2.0f);

    float svGrabberX = svMin.x + s * svSize;
    float svGrabberY = svMin.y + (1.0f - v) * svSize;
    draw->AddCircleFilled(ImVec2(svGrabberX, svGrabberY), 5.0f, C(ImColor(255, 255, 255)));
    draw->AddCircle(ImVec2(svGrabberX, svGrabberY), 5.0f, C(ImColor(80, 80, 80)));

    ImRect svRect(svMin, svMax);

    ImRect hueHitRect(hueMin, hueMax);
    bool changed = false;
    ImGuiID id = ImGui::GetID("_picker");

    ImGui::ItemSize(ImVec2(fullWidth, svY + svSize - pos.y));
    ImGui::ItemAdd(hueRect, id);

    if (ImGui::IsItemHovered() && ImGui::IsMouseClicked(0))
    {
        ImGui::SetActiveID(id, window);
    }
    if (g.ActiveId == id && (ImGui::IsMouseDragging(0) || ImGui::IsMouseDown(0)))
    {
        ImVec2 mp = ImGui::GetMousePos();
        float newHue = ImClamp((mp.x - hueMin.x) / hueWidth, 0.0f, 1.0f);
        if (fabsf(hue - newHue) > 0.001f)
        {
            ImGui::ColorConvertHSVtoRGB(newHue, s, v, col[0], col[1], col[2]);
            changed = true;
        }
    }
    if (g.ActiveId == id && !ImGui::IsMouseDown(0))
    {
        ImGui::ClearActiveID();
    }

    ImGuiID svId = ImGui::GetID("_sv");
    ImGui::ItemSize(ImVec2(svSize, svSize));
    ImGui::ItemAdd(svRect, svId);

    if (ImGui::IsItemHovered() && ImGui::IsMouseClicked(0))
    {
        ImGui::SetActiveID(svId, window);
    }
    if (g.ActiveId == svId && (ImGui::IsMouseDragging(0) || ImGui::IsMouseDown(0)))
    {
        ImVec2 mp = ImGui::GetMousePos();
        float newS = ImClamp((mp.x - svMin.x) / svSize, 0.0f, 1.0f);
        float newV = ImClamp(1.0f - (mp.y - svMin.y) / svSize, 0.0f, 1.0f);
        if (fabsf(s - newS) > 0.001f || fabsf(v - newV) > 0.001f)
        {
            ImGui::ColorConvertHSVtoRGB(hue, newS, newV, col[0], col[1], col[2]);
            changed = true;
        }
    }
    if (g.ActiveId == svId && !ImGui::IsMouseDown(0))
    {
        ImGui::ClearActiveID();
    }

    float alphaY = svY + svSize + 6.0f;
    float alphaHeight = 12.0f;
    ImVec2 alphaMin(pos.x + 4.0f, alphaY);
    ImVec2 alphaMax(pos.x + 4.0f + fullWidth - previewSize - 12.0f, alphaY + alphaHeight);

    int alphaSteps = (int)(alphaMax.x - alphaMin.x);
    if (alphaSteps < 4) alphaSteps = 4;
    for (int i = 0; i < alphaSteps; i++)
    {
        float f1 = (float)i / (float)(alphaSteps - 1);
        float f2 = (float)(i + 1) / (float)(alphaSteps - 1);
        ImColor c1(col[0], col[1], col[2], f1);
        ImColor c2(col[0], col[1], col[2], f2);
        float x1 = alphaMin.x + f1 * (alphaMax.x - alphaMin.x);
        float x2 = alphaMin.x + f2 * (alphaMax.x - alphaMin.x);
        draw->AddRectFilledMultiColor(ImVec2(x1, alphaMin.y), ImVec2(x2, alphaMax.y),
            C(c1), C(c2), C(c2), C(c1));
    }
    draw->AddRect(alphaMin, alphaMax, C(ImColor(60, 60, 60)), 2.0f);

    float alphaT = col[3];
    float alphaGrabberX = alphaMin.x + alphaT * (alphaMax.x - alphaMin.x);
    draw->AddCircleFilled(ImVec2(alphaGrabberX, alphaMin.y + alphaHeight * 0.5f), 6.0f, C(ImColor(255, 255, 255)));
    draw->AddCircle(ImVec2(alphaGrabberX, alphaMin.y + alphaHeight * 0.5f), 6.0f, C(ImColor(100, 100, 100)));

    ImRect alphaRect(alphaMin, alphaMax);
    alphaRect.Min.y -= 4.0f;
    alphaRect.Max.y += 4.0f;
    ImGuiID alphaId = ImGui::GetID("_alpha");
    ImGui::ItemAdd(alphaRect, alphaId);

    if (ImGui::IsItemHovered() && ImGui::IsMouseClicked(0))
    {
        ImGui::SetActiveID(alphaId, window);
    }
    if (g.ActiveId == alphaId && (ImGui::IsMouseDragging(0) || ImGui::IsMouseDown(0)))
    {
        ImVec2 mp = ImGui::GetMousePos();
        float newAlpha = ImClamp((mp.x - alphaMin.x) / (alphaMax.x - alphaMin.x), 0.0f, 1.0f);
        if (fabsf(col[3] - newAlpha) > 0.001f)
        {
            col[3] = newAlpha;
            changed = true;
        }
    }
    if (g.ActiveId == alphaId && !ImGui::IsMouseDown(0))
    {
        ImGui::ClearActiveID();
    }

    char hexBuf[16];
    ImFormatString(hexBuf, IM_ARRAYSIZE(hexBuf), "#%02X%02X%02X",
        (int)(col[0] * 255), (int)(col[1] * 255), (int)(col[2] * 255));
    ImVec2 hexSize = ImGui::CalcTextSize(hexBuf);
    float hexY = alphaY + alphaHeight + 6.0f;
    draw->AddText(ImVec2(pos.x + 4.0f, hexY), C(ImColor(180, 180, 180)), hexBuf);

    float rgbaY = hexY + hexSize.y + 4.0f;
    char rgbaBuf[64];
    ImFormatString(rgbaBuf, IM_ARRAYSIZE(rgbaBuf), "R:%.0f G:%.0f B:%.0f A:%.2f",
        col[0] * 255, col[1] * 255, col[2] * 255, col[3]);
    draw->AddText(ImVec2(pos.x + 4.0f, rgbaY), C(ImColor(140, 140, 140)), rgbaBuf);

    float totalH = rgbaY + ImGui::CalcTextSize(rgbaBuf).y - pos.y;
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + totalH + 6.0f);
    ImGui::PopID();
    return changed;
}

bool M_ColorPalette(const char* label, int* selected, const ImColor* palette, int count, ImColor accent)
{
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGui::PushID(label);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 4.0f);

    ImVec2 pos = ImGui::GetCursorScreenPos();
    float fullWidth = ImGui::GetContentRegionAvail().x;
    if (fullWidth < 50.0f) fullWidth = 50.0f;

    ImGui::RenderText(ImVec2(pos.x, pos.y), label);
    ImVec2 labelSize = ImGui::CalcTextSize(label);

    float swatchSize = 20.0f;
    float gap = 4.0f;
    int cols = (int)((fullWidth - 8.0f) / (swatchSize + gap));
    if (cols < 1) cols = 1;

    float startY = pos.y + labelSize.y + 6.0f;
    bool changed = false;

    for (int i = 0; i < count; i++)
    {
        int row = i / cols;
        int col = i % cols;
        float x = pos.x + 4.0f + col * (swatchSize + gap);
        float y = startY + row * (swatchSize + gap);

        ImVec2 swMin(x, y);
        ImVec2 swMax(x + swatchSize, y + swatchSize);

        draw->AddRectFilled(swMin, swMax, C(palette[i]), 3.0f);
        if (i == *selected)
        {
            draw->AddRect(swMin, swMax, C(accent), 3.0f, 0, 2.0f);
        }
        else
        {
            draw->AddRect(swMin, swMax, C(ImColor(50, 50, 50)), 3.0f);
        }

        ImRect swRect(swMin, swMax);
        ImGui::ItemSize(ImVec2(swatchSize, swatchSize));
        ImGui::ItemAdd(swRect, ImGui::GetID((void*)(intptr_t)i));

        if (ImGui::IsItemHovered() && ImGui::IsMouseClicked(0))
        {
            if (*selected != i)
            {
                *selected = i;
                changed = true;
            }
        }
    }

    int totalRows = (count + cols - 1) / cols;
    float totalH = startY + totalRows * (swatchSize + gap) - pos.y;
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + totalH + 6.0f);
    ImGui::PopID();
    return changed;
}

bool M_SearchBar(const char* label, char* buf, int bufSize, ImColor accent)
{
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGui::PushID(label);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 4.0f);

    ImVec2 pos = ImGui::GetCursorScreenPos();
    float fullWidth = ImGui::GetContentRegionAvail().x;
    if (fullWidth < 80.0f) fullWidth = 80.0f;

    float height = 32.0f;
    ImVec2 boxMin(pos.x, pos.y);
    ImVec2 boxMax(pos.x + fullWidth, pos.y + height);

    draw->AddRectFilled(boxMin, boxMax, C(ImColor(30, 30, 40)), 6.0f);
    draw->AddRect(boxMin, boxMax, C(ImColor(50, 50, 65)), 6.0f);

    draw->AddText(ImVec2(pos.x + 8.0f, pos.y + (height - ImGui::GetTextLineHeight()) * 0.5f),
        C(ImColor(100, 100, 120)), "\xF0\x9F\x94\x8D");

    float textX = pos.x + 30.0f;
    float textW = fullWidth - 38.0f;

    bool changed = false;
    ImGuiID id = ImGui::GetID("_search");
    ImRect boxRect(boxMin, boxMax);
    ImGui::ItemSize(ImVec2(fullWidth, height));
    ImGui::ItemAdd(boxRect, id);

    if (ImGui::IsItemHovered() && ImGui::IsMouseClicked(0))
    {
        ImGui::SetActiveID(id, window);
        ImGui::SetKeyboardFocusHere(-1);
    }

    bool isActive = (g.ActiveId == id);
    if (isActive)
    {
        ImGuiIO& io = ImGui::GetIO();
        for (int i = 0; i < io.InputQueueCharacters.Size; i++)
        {
            unsigned int c = (unsigned int)io.InputQueueCharacters[i];
            if (c >= 32 && c <= 126)
            {
                int len = (int)strlen(buf);
                if (len < bufSize - 1)
                {
                    buf[len] = (char)c;
                    buf[len + 1] = 0;
                    changed = true;
                }
            }
        }
        io.InputQueueCharacters.resize(0);

        if (ImGui::IsKeyPressed(ImGuiKey_Backspace) && !ImGui::IsKeyDown(ImGuiKey_LeftCtrl) && !ImGui::IsKeyDown(ImGuiKey_RightCtrl))
        {
            int len = (int)strlen(buf);
            if (len > 0)
            {
                buf[len - 1] = 0;
                changed = true;
            }
        }
        if (ImGui::IsKeyPressed(ImGuiKey_Escape))
        {
            ImGui::ClearActiveID();
            buf[0] = 0;
            changed = true;
        }
    }

    ImColor textCol = isActive ? ImColor(220, 220, 220) : ImColor(140, 140, 140);
    ImVec2 textSize = ImGui::CalcTextSize(buf);
    if (textSize.x > textW)
    {
        float scrollOffset = textSize.x - textW;
        ImGui::PushClipRect(ImVec2(textX, pos.y), ImVec2(textX + textW, pos.y + height), true);
        draw->AddText(ImVec2(textX - scrollOffset, pos.y + (height - ImGui::GetTextLineHeight()) * 0.5f),
            C(textCol), buf);
        ImGui::PopClipRect();
    }
    else
    {
        draw->AddText(ImVec2(textX, pos.y + (height - ImGui::GetTextLineHeight()) * 0.5f),
            C(textCol), buf);
    }

    if (isActive)
    {
        float blink = sinf(ImGui::GetTime() * 6.0f) * 0.5f + 0.5f;
        if (blink > 0.3f)
        {
            float cursorX = textX + ImGui::CalcTextSize(buf).x;
            if (cursorX > textX + textW) cursorX = textX + textW;
            draw->AddLine(ImVec2(cursorX, pos.y + 6.0f), ImVec2(cursorX, pos.y + height - 6.0f),
                C(ImColor(200, 200, 200, (int)(200 * blink))), 1.5f);
        }
    }

    if (buf[0] != 0)
    {
        float clearX = boxMax.x - 22.0f;
        float clearY = pos.y + height * 0.5f;
        bool clearHov = fabsf(ImGui::GetMousePos().x - clearX) < 8.0f && fabsf(ImGui::GetMousePos().y - clearY) < 8.0f;
        draw->AddCircleFilled(ImVec2(clearX, clearY), 7.0f,
            C(clearHov ? ImColor(180, 60, 60) : ImColor(60, 60, 60)));
        draw->AddText(ImVec2(clearX - 4.0f, clearY - 7.0f),
            C(clearHov ? ImColor(255, 255, 255) : ImColor(140, 140, 140)), "x");
        if (clearHov && ImGui::IsMouseClicked(0))
        {
            buf[0] = 0;
            changed = true;
        }
    }

    if (!ImGui::IsMouseDown(0) && g.ActiveId == id && !ImGui::IsItemHovered() && !ImGui::IsMouseHoveringRect(boxMin, boxMax))
    {
        ImGui::ClearActiveID();
    }

    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + height + 6.0f);
    ImGui::PopID();
    return changed;
}
