#pragma once
#include "Config.h"
#include "GameOffsets.h"
#include "MemoryIO.h"

class MiscFeatures {
    MemoryIO* Mem;
    GameOffsets* Offsets;
    Toggles* Tog;
    Config* Cfg;
    
public:
    MiscFeatures(MemoryIO* mem, GameOffsets* offsets, Config* cfg, Toggles* tog);
    
    void Update();
    
    void SetSpeed(float multiplier);
    void SetJumpHeight(float height);
    void SetGravity(float gravity);
    void SetSwimSpeed(float speed);
    void NoClip(bool enable);
    
    void GodMode(bool enable);
    void InfiniteAmmo(bool enable);
    void NoRecoil(bool enable);
    void NoSpread(bool enable);
    void RapidFire(bool enable);
    void OneHitKill(bool enable);
    
    void NightVision(bool enable);
    void ThermalVision(bool enable);
    void Wireframe(bool enable);
    void Chams(bool enable);
    void XRay(bool enable);
    
    void SetTime(float hour);
    void SetWeather(int weather);
    void NoFog(bool enable);
    void DayTime(bool enable);
    void CleanScreen(bool enable);
    
    void SetHealth(int hp);
    void SetShield(int shield);
    void SetArmor(int armor);
    void SetMoney(int money);
    void TeleportTo(float x, float y, float z);
    void TeleportUp(float dist);
    void TeleportForward(float dist);
    
    void ShowAllOnRadar(bool enable);
    void SetRadarRange(float range);
    
    void AutoLoot(bool enable, int radius);
    void AutoPickup(bool enable);
    void AutoHeal(bool enable, float hpPercent);
    void AutoReload(bool enable);
    void AutoRespawn(bool enable);
    void AutoCraft(bool enable);
    void AutoFarm(bool enable, int range);
    
    void InfiniteStamina(bool enable);
    void InfiniteOxygen(bool enable);
    void NoFallDamage(bool enable);
    void NoHunger(bool enable);
    void NoThirst(bool enable);
    void MagicBullet(bool enable);
    void Airstrike(float x, float y, float z);
    void SpawnItem(int itemID, int count);
    
private:
    uintptr_t FindLocalPlayer();
    uintptr_t FindWeaponManager();
    uintptr_t FindMovementController();
    uintptr_t FindInventory();
    uintptr_t FindWeatherSystem();
    uintptr_t FindTimeSystem();
    bool WriteValue(uintptr_t addr, uint32_t offset, float value);
    bool WriteValue(uintptr_t addr, uint32_t offset, int value);
    bool WriteFlag(uintptr_t addr, uint32_t offset, bool value);
};

extern MiscFeatures g_Misc;
