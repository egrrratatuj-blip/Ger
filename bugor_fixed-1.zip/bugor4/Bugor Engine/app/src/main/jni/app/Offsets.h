#pragma once
#include <cstdint>
#include <vector>
#include <string>

typedef uint64_t u64;
typedef int32_t i32;
typedef int64_t i64;
typedef uint8_t u8;

namespace Offsets {

struct GameProfile {
    const char* package;
    const char* module;
    const char* displayName;
    uint32_t gameID;
    
    uintptr_t UWorld;
    uintptr_t GameInstance;
    uintptr_t LocalPlayer;
    uintptr_t PlayerController;
    uintptr_t CameraManager;
    uintptr_t EntityList;
    uintptr_t EntityCount;
    uintptr_t EntityBase;
    uintptr_t EntityRootComponent;
    uintptr_t EntityPawn;
    uintptr_t EntityMesh;

    uintptr_t PosX;
    uintptr_t PosY;
    uintptr_t PosZ;
    uintptr_t HeadPos;
    uintptr_t FeetPos;
    
    uintptr_t Health;
    uintptr_t MaxHealth;
    uintptr_t Armor;
    uintptr_t Shield;
    uintptr_t Stamina;
    
    uintptr_t Name;
    uintptr_t NameLen;
    uintptr_t WeaponName;
    uintptr_t TeamID;
    uintptr_t FactionID;
    uintptr_t AliveFlag;
    uintptr_t BotFlag;
    uintptr_t VisibleFlag;
    
    uintptr_t BoneAddress;
    uintptr_t BoneMatrix;
    uintptr_t BoneStride;
    
    uintptr_t Recoil;
    uintptr_t Spread;
    uintptr_t Ammo;
    uintptr_t MaxAmmo;
    uintptr_t Reload;
    uintptr_t FireRate;
    uintptr_t FireFlag;
    
    uintptr_t Velocity;
    uintptr_t Speed;
    
    uintptr_t CameraPos;
    uintptr_t CameraRot;
    uintptr_t CameraFOV;
    
    uintptr_t ViewMatrix;
    uintptr_t ProjectionMatrix;
    uintptr_t ViewportSize;
    uintptr_t ScreenSize;
    
    uintptr_t TraceUWorld[16];
    uintptr_t TraceEntityList[16];
    uintptr_t TraceLocalPlayer[16];
    
    u8 TraceUWorldLen;
    u8 TraceEntityListLen;
    u8 TraceLocalPlayerLen;
    
    uintptr_t LocalPlayerIndex;
    uintptr_t TeamSelf;
};

constexpr int PROFILE_COUNT = 5;
extern const GameProfile PROFILES[];

extern const GameProfile OXIDE_SURVIVAL_DEFAULT;
extern const GameProfile OXIDE_SURVIVAL_V1;
extern const GameProfile OXIDE_SURVIVAL_V2;
extern const GameProfile OXIDE_SURVIVAL_V3;
extern const GameProfile OXIDE_SURVIVAL_LATEST;

int FindProfileByPackage(const char* packageName);
int FindProfileByID(uint32_t gameID);
const GameProfile* GetActiveProfile();
void SetActiveProfile(int index);

bool LoadOffsetsFromFile(const char* path);
bool SaveOffsetsToFile(const char* path);
bool ValidateProfile(const GameProfile* profile);

}
