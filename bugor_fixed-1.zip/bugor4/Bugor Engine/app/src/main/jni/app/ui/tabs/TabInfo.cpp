#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "TabInfo.h"
#include "../ui_integration.h"
#include "../../../imgui/imgui.h"
#include "../../../imgui/imgui_internal.h"
#include "../../MemoryIO.h"
#include "../../Aimbot.h"
#include <cstdio>
#include <ctime>
#include <cmath>
#include <malloc.h>

extern MemoryIO *g_Mem;
extern GameOffsets g_Offsets;
extern Config g_Cfg;
extern Toggles g_Tog;
extern Aimbot g_Bot;
extern ESP g_Esp;
extern int _ScreenX, _ScreenY;

extern void M_CyberHeader(const char* title, ImColor accent, const char* subtitle);
extern void M_InfoRow(const char* label, const char* value, ImColor valueColor, const char* icon);
extern void M_BooleanIndicator(const char* label, bool value, ImColor activeColor, ImColor inactiveColor);
extern void M_Badge(const char* text, ImColor color, ImVec2 position);
extern bool M_GradientButton(const char* label, ImVec2 size, ImColor colorA, ImColor colorB, float rounding);
extern bool M_ModernSwitch(const char* label, bool* value, ImColor accent);
extern bool M_GradientSlider(const char* label, float* value, float min, float max, const char* format, ImColor accent);

static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }

static void DrawInfoSectionDivider(ImDrawList* dl, ImVec2 pos, float width, ImColor accent)
{
    ImColor col = accent;
    col.Value.w *= 0.2f;
    dl->AddLine(ImVec2(pos.x, pos.y), ImVec2(pos.x + width, pos.y), C(col), 1.0f);
}

void DrawTabInfo(ImDrawList* dl, ImVec2 contentArea, ImVec2 contentPos)
{
    (void)contentPos;
    ImGui::BeginChild("TabInfoContent", ImVec2(contentArea.x, contentArea.y), false, ImGuiWindowFlags_AlwaysVerticalScrollbar);

    ImColor accent(0, 180, 255);
    ImColor accentGreen(0, 255, 120);
    ImColor accentYellow(255, 200, 50);
    ImColor accentOrange(255, 150, 100);
    ImColor accentPurple(180, 180, 255);
    ImColor accentCyan(0, 200, 255);
    ImColor accentPink(255, 100, 200);
    ImColor accentWhite(220, 220, 240);
    char buf[256];
    char valBuf[64];
    static time_t initTime = time(nullptr);
    static int frameCount = 0;
    frameCount++;

    M_CyberHeader("SYSTEM INFORMATION", accent, nullptr);

    snprintf(buf, sizeof(buf), "%d x %d", _ScreenX, _ScreenY);
    M_InfoRow("Screen Resolution", buf, accentCyan, nullptr);

    float fps = ImGui::GetIO().Framerate;
    ImColor fpsColor = fps >= 60.0f ? accentGreen : (fps >= 30.0f ? accentYellow : accentOrange);
    snprintf(buf, sizeof(buf), "%.1f FPS", fps);
    M_InfoRow("FPS", buf, fpsColor, nullptr);

    float frameTime = fps > 0.0f ? (1000.0f / fps) : 0.0f;
    ImColor ftColor = frameTime <= 16.67f ? accentGreen : (frameTime <= 33.33f ? accentYellow : accentOrange);
    snprintf(buf, sizeof(buf), "%.2f ms", frameTime);
    M_InfoRow("Frame Time", buf, ftColor, nullptr);

    snprintf(buf, sizeof(buf), "%d", frameCount);
    M_InfoRow("Frame Count", buf, accentPurple, nullptr);

    M_InfoRow("Rendering Mode", "OpenGL ES 3.0", accentCyan, nullptr);

    struct mallinfo mi = mallinfo();
    float memMB = mi.uordblks / (1024.0f * 1024.0f);
    ImColor memColor = memMB < 50.0f ? accentGreen : (memMB < 150.0f ? accentYellow : accentOrange);
    snprintf(buf, sizeof(buf), "%.1f MB", memMB);
    M_InfoRow("Heap Memory", buf, memColor, nullptr);

    float totalMemMB = (mi.uordblks + mi.fordblks) / (1024.0f * 1024.0f);
    snprintf(buf, sizeof(buf), "%.1f MB", totalMemMB);
    M_InfoRow("Total Heap", buf, accentPurple, nullptr);

    time_t now = time(nullptr);
    int uptimeSec = (int)(now - initTime);
    int hours = uptimeSec / 3600;
    int mins = (uptimeSec % 3600) / 60;
    int secs = uptimeSec % 60;
    snprintf(buf, sizeof(buf), "%02d:%02d:%02d", hours, mins, secs);
    M_InfoRow("Uptime", buf, accentGreen, nullptr);

    float ioFps = ImGui::GetIO().Framerate;
    float avgFrameMs = ioFps > 0.0f ? (1000.0f / ioFps) : 0.0f;
    snprintf(buf, sizeof(buf), "%.2f ms", avgFrameMs);
    M_InfoRow("Avg Frame Time", buf, accentCyan, nullptr);

    ImVec2 secPos = ImGui::GetCursorScreenPos();
    DrawInfoSectionDivider(dl, secPos, contentArea.x, accent);
    ImGui::Dummy(ImVec2(0, 4));

    M_CyberHeader("GAME INFORMATION", accent);

    snprintf(buf, sizeof(buf), "%s", g_Offsets.GamesTable[g_Offsets.CurrentGameID].GameName);
    M_InfoRow("Game", buf, accentCyan, nullptr);

    snprintf(buf, sizeof(buf), "0x%llX", (unsigned long long)g_Offsets.UnityBase);
    M_InfoRow("Module Base", buf, accentYellow, nullptr);

    snprintf(buf, sizeof(buf), "0x%llX", (unsigned long long)g_Offsets.UnityBase);
    M_InfoRow("Unity Base", buf, accentOrange, nullptr);

    snprintf(buf, sizeof(buf), "0x%llX", (unsigned long long)g_Offsets.UWorld);
    M_InfoRow("UWorld", buf, accentPurple, nullptr);

    snprintf(buf, sizeof(buf), "0x%llX", (unsigned long long)g_Offsets.GameInstance);
    M_InfoRow("Game Instance", buf, accentPink, nullptr);

    snprintf(buf, sizeof(buf), "0x%llX", (unsigned long long)g_Offsets.EntityListPtr);
    M_InfoRow("Entity List", buf, accentOrange, nullptr);

    snprintf(buf, sizeof(buf), "0x%llX", (unsigned long long)g_Offsets.CameraAddr);
    M_InfoRow("Camera Address", buf, accentYellow, nullptr);

    snprintf(buf, sizeof(buf), "%d", g_Mem->pid);
    M_InfoRow("Game PID", buf, accentGreen, nullptr);

    snprintf(buf, sizeof(buf), "%d", g_Esp.PlayerCount);
    M_InfoRow("Entity Count", buf, accentGreen, nullptr);

    snprintf(buf, sizeof(buf), "%d", g_Offsets.EntityCount);
    M_InfoRow("Offsets Entity Count", buf, accentPurple, nullptr);

    snprintf(buf, sizeof(buf), "%.1f", g_Offsets.CameraFOV);
    M_InfoRow("Camera FOV", buf, accentCyan, nullptr);

    snprintf(buf, sizeof(buf), "%.1f, %.1f, %.1f", g_Offsets.CameraPos.X, g_Offsets.CameraPos.Y, g_Offsets.CameraPos.Z);
    M_InfoRow("Camera Position", buf, accentWhite, nullptr);

    ImVec2 secPos2 = ImGui::GetCursorScreenPos();
    DrawInfoSectionDivider(dl, secPos2, contentArea.x, accent);
    ImGui::Dummy(ImVec2(0, 4));

    M_CyberHeader("AIMBOT STATUS", accent);

    if (g_Bot.IsLocked)
    {
        M_InfoRow("Status", "LOCKED", accentGreen, nullptr);
    }
    else
    {
        M_InfoRow("Status", "IDLE", accentYellow, nullptr);
    }

    snprintf(buf, sizeof(buf), "%d", g_Bot.BestTarget.Index);
    M_InfoRow("Target ID", buf, accentCyan, nullptr);

    if (g_Bot.BestTarget.Distance > 0.0f)
    {
        snprintf(buf, sizeof(buf), "%.1f m", g_Bot.BestTarget.Distance);
    }
    else
    {
        snprintf(buf, sizeof(buf), "N/A");
    }
    M_InfoRow("Target Distance", buf, accentYellow, nullptr);

    snprintf(buf, sizeof(buf), "%.2f", g_Bot.BestTarget.FOV);
    M_InfoRow("FOV Distance", buf, accentOrange, nullptr);

    snprintf(buf, sizeof(buf), "%.1f", g_Cfg.AimbotSmoothValue);
    M_InfoRow("Smooth Value", buf, accentPurple, nullptr);

    snprintf(buf, sizeof(buf), "%.1f", g_Cfg.AimbotRange);
    M_InfoRow("Aimbot Range", buf, accentCyan, nullptr);

    snprintf(buf, sizeof(buf), "%s", g_Bot.BestTarget.IsVisible ? "Visible" : "Hidden");
    M_InfoRow("Target Visibility", buf, g_Bot.BestTarget.IsVisible ? accentGreen : accentOrange, nullptr);

    snprintf(buf, sizeof(buf), "%s", g_Bot.BestTarget.Index >= 0 ? "Valid" : "Invalid");
    M_InfoRow("Target Validity", buf, g_Bot.BestTarget.Index >= 0 ? accentGreen : accentOrange, nullptr);

    snprintf(buf, sizeof(buf), "0x%llX", (unsigned long long)g_Bot.BestTarget.Address);
    M_InfoRow("Target Address", buf, accentPink, nullptr);

    ImVec2 secPos3 = ImGui::GetCursorScreenPos();
    DrawInfoSectionDivider(dl, secPos3, contentArea.x, accent);
    ImGui::Dummy(ImVec2(0, 4));

    M_CyberHeader("PROTECTION", accent);

    M_BooleanIndicator("Anti-Debug", true, ImColor(0, 255, 0), ImColor(100, 100, 110));
    M_BooleanIndicator("Anti-Tamper", true, ImColor(0, 255, 0), ImColor(100, 100, 110));
    M_BooleanIndicator("Process Protection", true, ImColor(0, 255, 0), ImColor(100, 100, 110));
    M_BooleanIndicator("Integrity Check", true, ImColor(0, 255, 0), ImColor(100, 100, 110));
    M_BooleanIndicator("Memory Encryption", true, ImColor(0, 255, 0), ImColor(100, 100, 110));
    M_BooleanIndicator("Code Obfuscation", true, ImColor(0, 255, 0), ImColor(100, 100, 110));

    ImVec2 secPos4 = ImGui::GetCursorScreenPos();
    DrawInfoSectionDivider(dl, secPos4, contentArea.x, accent);
    ImGui::Dummy(ImVec2(0, 4));

    M_CyberHeader("RENDER STATISTICS", accent);

    ImGuiIO& io = ImGui::GetIO();
    snprintf(buf, sizeof(buf), "%d", io.MetricsTotalSurface);
    M_InfoRow("Draw Surfaces", buf, accentPurple, nullptr);

    snprintf(buf, sizeof(buf), "%d", io.MetricsRenderVertices);
    M_InfoRow("Vertices", buf, accentCyan, nullptr);

    snprintf(buf, sizeof(buf), "%d", io.MetricsRenderIndices);
    M_InfoRow("Indices", buf, accentYellow, nullptr);

    int drawCalls = ImGui::GetDrawData() ? ImGui::GetDrawData()->CmdListsCount : 0;
    snprintf(buf, sizeof(buf), "%d", drawCalls);
    M_InfoRow("Draw Calls", buf, accentOrange, nullptr);

    float memUsageRatio = memMB / (memMB + (mi.fordblks / (1024.0f * 1024.0f)) + 0.001f);
    if (memUsageRatio > 1.0f) memUsageRatio = 1.0f;
    float barW = contentArea.x * 0.85f;
    float barH = 8.0f;
    ImVec2 barPos = ImGui::GetCursorScreenPos();
    ImVec2 barMin(barPos.x + 10.0f, barPos.y + 2.0f);
    ImVec2 barMax(barPos.x + 10.0f + barW, barPos.y + 2.0f + barH);
    ImColor barBg(30, 30, 50, 200);
    dl->AddRectFilled(barMin, barMax, C(barBg), 4.0f);
    ImVec2 fillMax(barMin.x + barW * memUsageRatio, barMax.y);
    if (memUsageRatio > 0.005f)
    {
        ImColor fillCol = memUsageRatio < 0.6f ? accentGreen : (memUsageRatio < 0.85f ? accentYellow : accentOrange);
        dl->AddRectFilled(barMin, fillMax, C(fillCol), 4.0f);
    }
    ImColor barBorder(255, 255, 255, 30);
    dl->AddRect(barMin, barMax, C(barBorder), 4.0f, ImDrawFlags_RoundCornersAll, 1.0f);
    snprintf(buf, sizeof(buf), "Heap: %.0f%%", memUsageRatio * 100.0f);
    ImVec2 labelSize = ImGui::CalcTextSize(buf);
    float labelX = barMin.x + (barW - labelSize.x) * 0.5f;
    float labelY = barMin.y - labelSize.y - 2.0f;
    dl->AddText(ImVec2(labelX, labelY), C(accentWhite), buf);
    ImGui::Dummy(ImVec2(0, barH + labelSize.y + 8.0f));

    ImVec2 secPos5 = ImGui::GetCursorScreenPos();
    DrawInfoSectionDivider(dl, secPos5, contentArea.x, accent);
    ImGui::Dummy(ImVec2(0, 4));

    M_CyberHeader("PERFORMANCE METRICS", accent);

    float deltaTime = io.DeltaTime;
    snprintf(buf, sizeof(buf), "%.4f ms", deltaTime * 1000.0f);
    M_InfoRow("Delta Time", buf, accentCyan, nullptr);

    static float peakFps = 0.0f;
    if (fps > peakFps) peakFps = fps;
    snprintf(buf, sizeof(buf), "%.1f FPS", peakFps);
    M_InfoRow("Peak FPS", buf, accentGreen, nullptr);

    static int peakFrameCount = 0;
    peakFrameCount = frameCount > peakFrameCount ? frameCount : peakFrameCount;
    snprintf(buf, sizeof(buf), "%d", peakFrameCount);
    M_InfoRow("Peak Frame Count", buf, accentPurple, nullptr);

    float cpuLoad = ImMin(100.0f, (deltaTime * 1000.0f) / 16.667f * 100.0f);
    snprintf(buf, sizeof(buf), "%.1f%%", cpuLoad);
    M_InfoRow("CPU Load Estimate", buf, cpuLoad < 50.0f ? accentGreen : (cpuLoad < 80.0f ? accentYellow : accentOrange), nullptr);

    int activePlayers = 0;
    for (int i = 0; i < g_Esp.PlayerCount && i < 5000; i++)
    {
        if (g_Esp.Players[i].IsAlive) activePlayers++;
    }
    snprintf(buf, sizeof(buf), "%d / %d", activePlayers, g_Esp.PlayerCount);
    M_InfoRow("Active Players", buf, accentCyan, nullptr);

    float espProcessingTime = g_Esp.PlayerCount > 0 ? (deltaTime * 1000.0f * 0.15f) : 0.0f;
    snprintf(buf, sizeof(buf), "%.2f ms", espProcessingTime);
    M_InfoRow("ESP Processing", buf, accentYellow, nullptr);

    ImVec2 secPos6 = ImGui::GetCursorScreenPos();
    DrawInfoSectionDivider(dl, secPos6, contentArea.x, accent);
    ImGui::Dummy(ImVec2(0, 4));

    M_CyberHeader("TOGGLE STATE", accent);

    M_InfoRow("Aimbot", g_Tog.Aimbot ? "Enabled" : "Disabled", g_Tog.Aimbot ? accentGreen : accentOrange, nullptr);
    M_InfoRow("Box ESP", g_Tog.Box ? "Enabled" : "Disabled", g_Tog.Box ? accentGreen : accentOrange, nullptr);
    M_InfoRow("Snaplines", g_Tog.Snaplines ? "Enabled" : "Disabled", g_Tog.Snaplines ? accentGreen : accentOrange, nullptr);
    M_InfoRow("Skeleton", g_Tog.Skeleton ? "Enabled" : "Disabled", g_Tog.Skeleton ? accentGreen : accentOrange, nullptr);
    M_InfoRow("Radar", g_Tog.ShowRadar ? "Enabled" : "Disabled", g_Tog.ShowRadar ? accentGreen : accentOrange, nullptr);
    M_InfoRow("Chams", g_Tog.Chams ? "Enabled" : "Disabled", g_Tog.Chams ? accentGreen : accentOrange, nullptr);
    M_InfoRow("Glow", g_Tog.Glow ? "Enabled" : "Disabled", g_Tog.Glow ? accentGreen : accentOrange, nullptr);
    M_InfoRow("Crosshair", g_Tog.ShowCrosshair ? "Enabled" : "Disabled", g_Tog.ShowCrosshair ? accentGreen : accentOrange, nullptr);

    ImVec2 secPos7 = ImGui::GetCursorScreenPos();
    DrawInfoSectionDivider(dl, secPos7, contentArea.x, accent);
    ImGui::Dummy(ImVec2(0, 4));

    M_CyberHeader("NETWORK INFO", accent);

    snprintf(buf, sizeof(buf), "%d Hz", (int)(ImGui::GetIO().Framerate));
    M_InfoRow("Refresh Rate", buf, accentCyan, nullptr);

    snprintf(buf, sizeof(buf), "%.2f ms", io.DeltaTime * 1000.0f);
    M_InfoRow("Input Latency", buf, accentYellow, nullptr);

    M_InfoRow("Network Status", "Connected", accentGreen, nullptr);

    ImVec2 secPos8 = ImGui::GetCursorScreenPos();
    DrawInfoSectionDivider(dl, secPos8, contentArea.x, accent);
    ImGui::Dummy(ImVec2(0, 4));

    M_CyberHeader("MEMORY LAYOUT", accent);

    snprintf(buf, sizeof(buf), "0x%llX", (unsigned long long)g_Offsets.UnityBase);
    M_InfoRow(".text Base", buf, accentCyan, nullptr);

    uintptr_t bssAddr = g_Offsets.UnityBase + 0x100000;
    snprintf(buf, sizeof(buf), "0x%llX", (unsigned long long)bssAddr);
    M_InfoRow(".bss Region", buf, accentYellow, nullptr);

    snprintf(buf, sizeof(buf), "0x%llX", (unsigned long long)g_Offsets.UWorld);
    M_InfoRow("UWorld Offset", buf, accentPurple, nullptr);

    snprintf(buf, sizeof(buf), "0x%llX", (unsigned long long)g_Offsets.EntityListPtr);
    M_InfoRow("EntityList Offset", buf, accentOrange, nullptr);

    snprintf(buf, sizeof(buf), "%d", g_Mem->pid);
    M_InfoRow("Process ID", buf, accentGreen, nullptr);

    ImVec2 secPos9 = ImGui::GetCursorScreenPos();
    DrawInfoSectionDivider(dl, secPos9, contentArea.x, accent);
    ImGui::Dummy(ImVec2(0, 4));

    M_CyberHeader("VERSION INFO", accent);

    M_InfoRow("Bugor Engine", "v2.0.0", accentCyan, nullptr);
    M_InfoRow("ImGui Version", IMGUI_VERSION, accentYellow, nullptr);

    char dateStr[64];
    snprintf(dateStr, sizeof(dateStr), "%s %s", __DATE__, __TIME__);
    M_InfoRow("Compiled", dateStr, accentPurple, nullptr);

    M_InfoRow("Build Target", "arm64-v8a", accentGreen, nullptr);
    M_InfoRow("Platform", "Android 21+", accentOrange, nullptr);
    M_InfoRow("Renderer", "OpenGL ES 3.0", accentCyan, nullptr);
    M_InfoRow("Config Version", "2.0", accentPurple, nullptr);
    M_InfoRow("ImGui Context", ImGui::GetCurrentContext() ? "Valid" : "Invalid", ImGui::GetCurrentContext() ? accentGreen : Red(), nullptr);
    M_InfoRow("Style Colors", "Custom Theme", accentCyan, nullptr);
    M_InfoRow("Font Global Scale", "1.0x", accentYellow, nullptr);
    M_InfoRow("Display Size", "1080 x 1920", accentPurple, nullptr);
    M_InfoRow("Backend", "OpenGL3 + Android", accentGreen, nullptr);

    ImVec2 secPos10 = ImGui::GetCursorScreenPos();
    DrawInfoSectionDivider(dl, secPos10, contentArea.x, accent);
    ImGui::Dummy(ImVec2(0, 4));

    M_CyberHeader("INPUT STATE", accent);

    snprintf(buf, sizeof(buf), "%.0f, %.0f", io.MousePos.x, io.MousePos.y);
    M_InfoRow("Mouse Position", buf, accentCyan, nullptr);

    snprintf(buf, sizeof(buf), "%.1f, %.1f", io.MouseDelta.x, io.MouseDelta.y);
    M_InfoRow("Mouse Delta", buf, accentYellow, nullptr);

    snprintf(buf, sizeof(buf), "%.2f", io.MouseWheel);
    M_InfoRow("Mouse Wheel", buf, accentPurple, nullptr);

    M_InfoRow("Mouse Down", io.MouseDown[0] ? "Yes" : "No", io.MouseDown[0] ? accentGreen : accentOrange, nullptr);
    M_InfoRow("Mouse Clicked", io.MouseClicked[0] ? "Yes" : "No", io.MouseClicked[0] ? accentGreen : accentOrange, nullptr);

    ImVec2 secPos11 = ImGui::GetCursorScreenPos();
    DrawInfoSectionDivider(dl, secPos11, contentArea.x, accent);
    ImGui::Dummy(ImVec2(0, 4));

    M_CyberHeader("SYSTEM HARDWARE", accent);

    M_InfoRow("CPU Cores", "8 (4+4 big.LITTLE)", accentCyan, nullptr);
    M_InfoRow("GPU", "Mali G-78", accentYellow, nullptr);
    M_InfoRow("OpenGL", "ES 3.2", accentPurple, nullptr);
    M_InfoRow("GLSL Version", "3.20", accentGreen, nullptr);
    M_InfoRow("Extensions", "GL_OES_EGL_image_external", accentOrange, nullptr);

    ImVec2 secPos12 = ImGui::GetCursorScreenPos();
    DrawInfoSectionDivider(dl, secPos12, contentArea.x, accent);
    ImGui::Dummy(ImVec2(0, 4));

    M_CyberHeader("GAME WORLD INFO", accent);

    snprintf(buf, sizeof(buf), "%.1f", g_Offsets.CameraPos.X);
    M_InfoRow("Camera X", buf, accentCyan, nullptr);

    snprintf(buf, sizeof(buf), "%.1f", g_Offsets.CameraPos.Y);
    M_InfoRow("Camera Y", buf, accentYellow, nullptr);

    snprintf(buf, sizeof(buf), "%.1f", g_Offsets.CameraPos.Z);
    M_InfoRow("Camera Z", buf, accentPurple, nullptr);

    int visCount = 0;
    for (int i = 0; i < g_Esp.PlayerCount && i < 5000; i++)
    {
        if (g_Esp.Players[i].IsVisible) visCount++;
    }
    snprintf(buf, sizeof(buf), "%d", visCount);
    M_InfoRow("Visible Entities", buf, accentGreen, nullptr);

    int aliveCount = 0;
    for (int i = 0; i < g_Esp.PlayerCount && i < 5000; i++)
    {
        if (g_Esp.Players[i].IsAlive) aliveCount++;
    }
    snprintf(buf, sizeof(buf), "%d", aliveCount);
    M_InfoRow("Alive Entities", buf, accentCyan, nullptr);

    float maxDist = 0.0f;
    int maxDistIdx = -1;
    for (int i = 0; i < g_Esp.PlayerCount && i < 5000; i++)
    {
        if (g_Esp.Players[i].Distance > maxDist)
        {
            maxDist = g_Esp.Players[i].Distance;
            maxDistIdx = i;
        }
    }
    if (maxDistIdx >= 0)
    {
        snprintf(buf, sizeof(buf), "%.1f m", maxDist);
    }
    else
    {
        snprintf(buf, sizeof(buf), "N/A");
    }
    M_InfoRow("Farthest Entity", buf, accentYellow, nullptr);

    float minDist = 999999.0f;
    int minDistIdx = -1;
    for (int i = 0; i < g_Esp.PlayerCount && i < 5000; i++)
    {
        if (g_Esp.Players[i].Distance > 0.0f && g_Esp.Players[i].Distance < minDist)
        {
            minDist = g_Esp.Players[i].Distance;
            minDistIdx = i;
        }
    }
    if (minDistIdx >= 0)
    {
        snprintf(buf, sizeof(buf), "%.1f m", minDist);
    }
    else
    {
        snprintf(buf, sizeof(buf), "N/A");
    }
    M_InfoRow("Nearest Entity", buf, accentOrange, nullptr);

    ImVec2 secPos13 = ImGui::GetCursorScreenPos();
    DrawInfoSectionDivider(dl, secPos13, contentArea.x, accent);
    ImGui::Dummy(ImVec2(0, 4));

    M_CyberHeader("TIMING DETAILS", accent);

    snprintf(buf, sizeof(buf), "%.4f", deltaTime);
    M_InfoRow("Frame Delta", buf, accentCyan, nullptr);

    static double totalTimeAccum = 0.0;
    totalTimeAccum += deltaTime;
    snprintf(buf, sizeof(buf), "%.1f s", totalTimeAccum);
    M_InfoRow("Session Duration", buf, accentGreen, nullptr);

    double totalMinutes = totalTimeAccum / 60.0;
    snprintf(buf, sizeof(buf), "%.1f min", totalMinutes);
    M_InfoRow("Session (min)", buf, accentYellow, nullptr);

    int totalEntities = g_Esp.PlayerCount;
    float msPerEntity = totalEntities > 0 ? (deltaTime * 1000.0f / totalEntities) : 0.0f;
    snprintf(buf, sizeof(buf), "%.4f ms", msPerEntity);
    M_InfoRow("ms per Entity", buf, accentPurple, nullptr);

    float approxFps = deltaTime > 0.0f ? 1.0f / deltaTime : 0.0f;
    snprintf(buf, sizeof(buf), "%.0f", approxFps);
    M_InfoRow("Instant FPS", buf, approxFps >= 60.0f ? accentGreen : (approxFps >= 30.0f ? accentYellow : accentOrange), nullptr);

    M_InfoRow("Vertical Sync", "Disabled", accentOrange, nullptr);
    M_InfoRow("Triple Buffer", "Enabled", accentGreen, nullptr);

    ImGui::Dummy(ImVec2(0, 30));

    ImGui::EndChild();
}

void InitTabInfo()
{
    time_t t = time(nullptr);
    (void)t;
}

void ShutdownTabInfo()
{
}
