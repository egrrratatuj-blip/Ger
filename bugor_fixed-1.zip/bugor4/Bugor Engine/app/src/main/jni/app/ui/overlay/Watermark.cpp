#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "../../Config.h"
#include "../../../imgui/imgui.h"
#include "../../../imgui/imgui_internal.h"
#include "../../ESP.h"

static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }

extern Config g_Cfg;
extern Toggles g_Tog;
extern ESP g_Esp;
extern GameOffsets g_Offsets;

static float s_wmTime = 0.0f;
static float s_wmAlpha = 0.0f;
static int s_wmAlphaDir = 1;
static float s_wmGlowPhase = 0.0f;
static float s_wmPeakFps = 0.0f;
static float s_wmAvgFps = 0.0f;
static float s_wmFpsSum = 0.0f;
static int s_wmFpsCount = 0;
static float s_wmLastFrameFps = 0.0f;
static float s_fpsHistory[120] = {0};
static int s_fpsHistIdx = 0;
static float s_wmPulseIntensity = 0.0f;
static float s_wmScanlinePhase = 0.0f;
static bool s_wmWasHidden = false;

static ImVec2 CheckDisplaySize() {
    ImVec2 sz = ImGui::GetIO().DisplaySize;
    if (sz.x < 1.0f) sz.x = 1.0f;
    if (sz.y < 1.0f) sz.y = 1.0f;
    return sz;
}

void DrawWatermark(ImDrawList* dl, float fps, int playerCount, int ping) {
    if (!g_Tog.ShowWatermark) {
        s_wmAlpha -= ImGui::GetIO().DeltaTime * 3.0f;
        if (s_wmAlpha < 0.0f) s_wmAlpha = 0.0f;
        s_wmPulseIntensity = 0.0f;
        s_wmWasHidden = true;
        return;
    }
    if (s_wmWasHidden) {
        s_wmTime = 0.0f;
        s_wmGlowPhase = 0.0f;
        s_wmScanlinePhase = 0.0f;
        s_wmWasHidden = false;
    }
    s_wmAlpha += ImGui::GetIO().DeltaTime * 3.0f;
    if (s_wmAlpha > 1.0f) s_wmAlpha = 1.0f;
    s_wmTime += ImGui::GetIO().DeltaTime;
    if (s_wmTime > 1000.0f) s_wmTime -= 1000.0f;
    s_wmGlowPhase += ImGui::GetIO().DeltaTime * 2.0f;
    if (s_wmGlowPhase > 1000.0f) s_wmGlowPhase -= 1000.0f;
    s_wmScanlinePhase += ImGui::GetIO().DeltaTime * 0.5f;
    if (s_wmScanlinePhase > 1000.0f) s_wmScanlinePhase -= 1000.0f;
    float floatOffset = sinf(s_wmTime * 3.14159f) * 2.0f;
    ImVec2 screenSize = CheckDisplaySize();
    ImVec2 wmPos(12.0f, 10.0f + floatOffset);
    ImVec2 wmSize(220.0f, 38.0f);
    ImColor bgCol(5, 5, 15, (int)(180 * s_wmAlpha));
    dl->AddRectFilled(wmPos, ImVec2(wmPos.x + wmSize.x, wmPos.y + wmSize.y), C(bgCol), 6.0f);
    float glowAlpha = (sinf(s_wmGlowPhase) * 0.3f + 0.7f) * s_wmAlpha;
    ImColor accentCol = g_Cfg.AccentColor;
    ImColor glowCol = ImColor(accentCol.Value.x, accentCol.Value.y, accentCol.Value.z, glowAlpha * 0.5f);
    dl->AddRect(wmPos, ImVec2(wmPos.x + wmSize.x, wmPos.y + wmSize.y), C(glowCol), 6.0f, 0, 2.5f);
    dl->AddRect(wmPos, ImVec2(wmPos.x + wmSize.x, wmPos.y + wmSize.y), C(accentCol), 6.0f, 0, 1.5f);
    ImColor fpsColor;
    if (fps > 60.0f) fpsColor = ImColor(0, 255, 0, (int)(255 * s_wmAlpha));
    else if (fps > 30.0f) fpsColor = ImColor(255, 255, 0, (int)(255 * s_wmAlpha));
    else fpsColor = ImColor(255, 0, 0, (int)(255 * s_wmAlpha));
    char wmText[96];
    snprintf(wmText, sizeof(wmText), "BUGOR ENGINE v3.0 | FPS: %.0f", fps);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 13.0f,
        ImVec2(wmPos.x + 12.0f, wmPos.y + 4.0f),
        C(ImColor(200, 200, 230, (int)(255 * s_wmAlpha))), wmText);
    char infoText[96];
    snprintf(infoText, sizeof(infoText), "Players: %d | Ping: %d", playerCount, ping);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 10.0f,
        ImVec2(wmPos.x + 12.0f, wmPos.y + 22.0f),
        C(ImColor(150, 150, 180, (int)(200 * s_wmAlpha))), infoText);
    s_wmPulseIntensity = sinf(s_wmGlowPhase) * 0.5f + 0.5f;
}

void DrawWatermarkFade(ImDrawList* dl, float fps, int playerCount, int ping) {
    DrawWatermark(dl, fps, playerCount, ping);
}

void SetWatermarkAlpha(float alpha) {
    s_wmAlpha = alpha;
}

float GetWatermarkAlpha() {
    return s_wmAlpha;
}

void ResetWatermarkAnim() {
    s_wmTime = 0.0f;
    s_wmGlowPhase = 0.0f;
    s_wmPulseIntensity = 0.0f;
    s_wmScanlinePhase = 0.0f;
    s_wmWasHidden = false;
}

void DrawWatermarkAdvanced(ImDrawList* dl, float fps, int playerCount, int ping) {
    if (!g_Tog.ShowWatermark) return;
    s_fpsHistory[s_fpsHistIdx % 120] = fps;
    s_fpsHistIdx++;
    DrawWatermark(dl, fps, playerCount, ping);
    ImVec2 screenSize = CheckDisplaySize();
    ImVec2 graphPos(screenSize.x - 160.0f, 10.0f);
    ImVec2 graphSize(150.0f, 40.0f);
    dl->AddRectFilled(graphPos, ImVec2(graphPos.x + graphSize.x, graphPos.y + graphSize.y),
        C(ImColor(5, 5, 15, 140)), 4.0f);
    int count = s_fpsHistIdx < 120 ? s_fpsHistIdx : 120;
    if (count > 1) {
        for (int i = 0; i < count - 1; i++) {
            int idx1 = (s_fpsHistIdx - count + i) % 120;
            int idx2 = (s_fpsHistIdx - count + i + 1) % 120;
            float x1 = graphPos.x + (float)i / (float)(count - 1) * graphSize.x;
            float x2 = graphPos.x + (float)(i + 1) / (float)(count - 1) * graphSize.x;
            float y1 = graphPos.y + graphSize.y - (s_fpsHistory[idx1] / 120.0f) * graphSize.y;
            float y2 = graphPos.y + graphSize.y - (s_fpsHistory[idx2] / 120.0f) * graphSize.y;
            dl->AddLine(ImVec2(x1, y1), ImVec2(x2, y2), C(ImColor(0, 180, 255, 180)), 1.5f);
        }
    }
    char peakText[32];
    snprintf(peakText, sizeof(peakText), "Peak: %.0f", s_wmPeakFps);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 9.0f,
        ImVec2(graphPos.x + 4.0f, graphPos.y + 4.0f),
        C(ImColor(100, 200, 100, 180)), peakText);
    char avgText[32];
    snprintf(avgText, sizeof(avgText), "Avg: %.0f", s_wmAvgFps);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 9.0f,
        ImVec2(graphPos.x + 4.0f, graphPos.y + 14.0f),
        C(ImColor(200, 200, 100, 180)), avgText);
}

void DrawWatermarkGL(ImDrawList* dl, float fps, int playerCount, int ping) {
    if (!g_Tog.ShowWatermark) return;
    DrawWatermark(dl, fps, playerCount, ping);
    ImVec2 screenSize = CheckDisplaySize();
    ImVec2 glPos(12.0f, 52.0f);
    float wmGlow = sinf(s_wmGlowPhase * 0.5f) * 0.2f + 0.8f;
    ImColor glCol = ImColor(0, 180, 255, (int)(180 * wmGlow));
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 9.0f, glPos, C(glCol), "OpenGL ES 3.2 | 1920x1080");
    ImVec2 dtPos(12.0f, 64.0f);
    char dtText[64];
    snprintf(dtText, sizeof(dtText), "DT: %.2fms", ImGui::GetIO().DeltaTime * 1000.0f);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 9.0f, dtPos, C(ImColor(120, 120, 150, 160)), dtText);
}

void DrawWatermarkStats(ImDrawList* dl, float fps, int playerCount, int ping) {
    if (!g_Tog.ShowWatermark) return;
    if (fps > s_wmPeakFps) s_wmPeakFps = fps;
    s_wmFpsSum += fps;
    s_wmFpsCount++;
    s_wmAvgFps = s_wmFpsSum / (float)s_wmFpsCount;
    DrawWatermark(dl, fps, playerCount, ping);
    ImVec2 wmPos(12.0f, 10.0f + sinf(s_wmTime * 3.14159f) * 2.0f);
    char statsText[96];
    snprintf(statsText, sizeof(statsText), "Peak: %.0f | Avg: %.0f", s_wmPeakFps, s_wmAvgFps);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 10.0f,
        ImVec2(wmPos.x + 140.0f, wmPos.y + 4.0f),
        C(ImColor(100, 200, 100, 200)), statsText);
}

void ResetWatermarkStats() {
    s_wmPeakFps = 0.0f;
    s_wmAvgFps = 0.0f;
    s_wmFpsSum = 0.0f;
    s_wmFpsCount = 0;
    s_wmTime = 0.0f;
    s_wmPulseIntensity = 0.0f;
    s_wmGlowPhase = 0.0f;
    s_wmScanlinePhase = 0.0f;
    s_wmWasHidden = false;
}

void DrawWatermarkSmooth(ImDrawList* dl, float fps, int playerCount, int ping) {
    if (!g_Tog.ShowWatermark) return;
    s_wmLastFrameFps += (fps - s_wmLastFrameFps) * 0.1f;
    DrawWatermark(dl, s_wmLastFrameFps, playerCount, ping);
}

void DrawWatermarkFull(ImDrawList* dl, float fps, int playerCount, int ping, const char* version, const char* build) {
    if (!g_Tog.ShowWatermark) return;
    DrawWatermark(dl, fps, playerCount, ping);
    ImVec2 wmPos(12.0f, 10.0f + sinf(s_wmTime * 3.14159f) * 2.0f);
    char buildText[128];
    snprintf(buildText, sizeof(buildText), "%s | %s", version ? version : "release", build ? build : "today");
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 9.0f,
        ImVec2(wmPos.x + 140.0f, wmPos.y + 22.0f),
        C(ImColor(120, 120, 150, 160)), buildText);
}

void DrawWatermarkBottom(ImDrawList* dl, float fps, int playerCount, int ping) {
    if (!g_Tog.ShowWatermark) return;
    float alpha = 1.0f;
    ImVec2 screenSize = CheckDisplaySize();
    float bottomOffset = sinf(s_wmTime * 2.0f) * 1.5f;
    ImVec2 wmPos(screenSize.x * 0.5f - 110.0f, screenSize.y - 40.0f + bottomOffset);
    ImVec2 wmSize(220.0f, 30.0f);
    ImColor bgCol(5, 5, 15, (int)(160 * alpha));
    dl->AddRectFilled(wmPos, ImVec2(wmPos.x + wmSize.x, wmPos.y + wmSize.y), C(bgCol), 6.0f);
    ImColor accentCol = g_Cfg.AccentColor;
    ImColor borderCol = ImColor(accentCol.Value.x, accentCol.Value.y, accentCol.Value.z, (int)(200 * alpha));
    dl->AddRect(wmPos, ImVec2(wmPos.x + wmSize.x, wmPos.y + wmSize.y), C(borderCol), 6.0f, 0, 1.0f);
    char wmText[96];
    snprintf(wmText, sizeof(wmText), "BUGOR ENGINE v3.0 | FPS: %.0f", fps);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 12.0f,
        ImVec2(wmPos.x + 12.0f, wmPos.y + 7.0f),
        C(ImColor(200, 200, 230, (int)(255 * alpha))), wmText);
}

void DrawWatermarkCornerTL(ImDrawList* dl, float fps, int playerCount, int ping) {
    DrawWatermark(dl, fps, playerCount, ping);
}

void DrawWatermarkCornerTR(ImDrawList* dl, float fps, int playerCount, int ping) {
    if (!g_Tog.ShowWatermark) return;
    ImVec2 screenSize = CheckDisplaySize();
    float floatOffset = sinf(s_wmTime * 3.0f) * 2.0f;
    ImVec2 wmSize(220.0f, 38.0f);
    ImVec2 wmPos(screenSize.x - wmSize.x - 12.0f, 10.0f + floatOffset);
    ImColor bgCol(5, 5, 15, (int)(180 * s_wmAlpha));
    dl->AddRectFilled(wmPos, ImVec2(wmPos.x + wmSize.x, wmPos.y + wmSize.y), C(bgCol), 6.0f);
    float glowAlpha = (sinf(s_wmGlowPhase) * 0.3f + 0.7f) * s_wmAlpha;
    ImColor accentCol = g_Cfg.AccentColor;
    ImColor glowCol = ImColor(accentCol.Value.x, accentCol.Value.y, accentCol.Value.z, glowAlpha * 0.5f);
    dl->AddRect(wmPos, ImVec2(wmPos.x + wmSize.x, wmPos.y + wmSize.y), C(glowCol), 6.0f, 0, 2.5f);
    dl->AddRect(wmPos, ImVec2(wmPos.x + wmSize.x, wmPos.y + wmSize.y), C(accentCol), 6.0f, 0, 1.5f);
    char wmText[96];
    snprintf(wmText, sizeof(wmText), "BUGOR ENGINE v3.0 | FPS: %.0f", fps);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 13.0f,
        ImVec2(wmPos.x + 12.0f, wmPos.y + 4.0f),
        C(ImColor(200, 200, 230, (int)(255 * s_wmAlpha))), wmText);
    char infoText[96];
    snprintf(infoText, sizeof(infoText), "Players: %d | Ping: %d", playerCount, ping);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 10.0f,
        ImVec2(wmPos.x + 12.0f, wmPos.y + 22.0f),
        C(ImColor(150, 150, 180, (int)(200 * s_wmAlpha))), infoText);
}

void DrawWatermarkCornerBL(ImDrawList* dl, float fps, int playerCount, int ping) {
    if (!g_Tog.ShowWatermark) return;
    ImVec2 screenSize = CheckDisplaySize();
    float floatOffset = sinf(s_wmTime * 2.5f) * 1.5f;
    ImVec2 wmSize(220.0f, 38.0f);
    ImVec2 wmPos(12.0f, screenSize.y - wmSize.y - 10.0f + floatOffset);
    ImColor bgCol(5, 5, 15, (int)(160 * s_wmAlpha));
    dl->AddRectFilled(wmPos, ImVec2(wmPos.x + wmSize.x, wmPos.y + wmSize.y), C(bgCol), 6.0f);
    ImColor accentCol = g_Cfg.AccentColor;
    dl->AddRect(wmPos, ImVec2(wmPos.x + wmSize.x, wmPos.y + wmSize.y), C(accentCol), 6.0f, 0, 1.5f);
    char wmText[96];
    snprintf(wmText, sizeof(wmText), "BUGOR ENGINE v3.0 | FPS: %.0f", fps);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 13.0f,
        ImVec2(wmPos.x + 12.0f, wmPos.y + 4.0f),
        C(ImColor(200, 200, 230, (int)(255 * s_wmAlpha))), wmText);
    char infoText[96];
    snprintf(infoText, sizeof(infoText), "Players: %d | Ping: %d", playerCount, ping);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 10.0f,
        ImVec2(wmPos.x + 12.0f, wmPos.y + 22.0f),
        C(ImColor(150, 150, 180, (int)(200 * s_wmAlpha))), infoText);
}

void DrawWatermarkCornerBR(ImDrawList* dl, float fps, int playerCount, int ping) {
    if (!g_Tog.ShowWatermark) return;
    ImVec2 screenSize = CheckDisplaySize();
    float floatOffset = sinf(s_wmTime * 2.0f) * 1.5f;
    ImVec2 wmSize(220.0f, 38.0f);
    ImVec2 wmPos(screenSize.x - wmSize.x - 12.0f, screenSize.y - wmSize.y - 10.0f + floatOffset);
    ImColor bgCol(5, 5, 15, (int)(160 * s_wmAlpha));
    dl->AddRectFilled(wmPos, ImVec2(wmPos.x + wmSize.x, wmPos.y + wmSize.y), C(bgCol), 6.0f);
    ImColor accentCol = g_Cfg.AccentColor;
    dl->AddRect(wmPos, ImVec2(wmPos.x + wmSize.x, wmPos.y + wmSize.y), C(accentCol), 6.0f, 0, 1.5f);
    char wmText[96];
    snprintf(wmText, sizeof(wmText), "BUGOR ENGINE v3.0 | FPS: %.0f", fps);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 13.0f,
        ImVec2(wmPos.x + 12.0f, wmPos.y + 4.0f),
        C(ImColor(200, 200, 230, (int)(255 * s_wmAlpha))), wmText);
}

void DrawWatermarkWithGraph(ImDrawList* dl, float fps, int playerCount, int ping) {
    DrawWatermarkAdvanced(dl, fps, playerCount, ping);
}

float GetWatermarkPulse() {
    return s_wmPulseIntensity;
}

void DrawWatermarkScanline(ImDrawList* dl, float fps, int playerCount, int ping) {
    if (!g_Tog.ShowWatermark) return;
    DrawWatermark(dl, fps, playerCount, ping);
    ImVec2 wmPos(12.0f, 10.0f + sinf(s_wmTime * 3.14159f) * 2.0f);
    ImVec2 wmSize(220.0f, 38.0f);
    float scanY = fmodf(s_wmScanlinePhase * 38.0f, 38.0f);
    ImColor scanCol(255, 255, 255, 20);
    dl->AddLine(
        ImVec2(wmPos.x, wmPos.y + scanY),
        ImVec2(wmPos.x + wmSize.x, wmPos.y + scanY),
        C(scanCol), 2.0f
    );
}
