#pragma once
#include "imgui/imgui.h"

void DrawTabConfig(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize);
void InitTabConfig();
void ShutdownTabConfig();
void SaveConfig();
void LoadConfig();
void ResetConfig();
