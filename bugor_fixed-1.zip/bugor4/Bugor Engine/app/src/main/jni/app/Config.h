#pragma once
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <dirent.h>
#include <pthread.h>
#include <fstream>
#include <string.h>
#include <time.h>
#include <malloc.h>
#include <android/log.h>
#include <thread>
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES/gl.h>
#include <GLES3/gl3platform.h>
#include <GLES3/gl3ext.h>
#include <GLES3/gl32.h>
#include <android/native_window_jni.h>
#include <iostream>
#include <fstream>
#include <ctime>
#include <map>
#include <cmath>
#include <vector>
#include <algorithm>
#include <random>
#include "imgui.h"
#include "imgui_internal.h"
#include "imgui_impl_opengl3.h"
#include "imgui_impl_android.h"
#include "imgui_Input_android.h"
#include "mycustom/imgui_Custom.h"

extern ImGuiWindow *Window;
#include <atomic>
#include <mutex>
extern std::atomic<bool> g_Initialized;
extern std::atomic<bool> g_EngineInitialized;
extern std::atomic<bool> g_ShuttingDown;
extern std::mutex g_ConfigMutex;
extern std::mutex g_EngineStateMutex;
extern ANativeWindow *window_sv;
extern EGLDisplay g_EglDisplay;
extern EGLSurface g_EglSurface;
extern EGLContext g_EglContext;
extern void initGui();
extern void shutdownGui();
extern void initializeEGLContext();
extern void cleanupEngine();
extern bool Android_LoadSystemFont();
extern void ImGuiMainWinStart();
extern void ImGuiMainMenuWind();
extern void ImGuiMainWinEnded();
extern int _ScreenX, _ScreenY;
extern int abs_ScreenX, abs_ScreenY;

struct D2DVector {
    float X, Y;
    D2DVector() : X(0), Y(0) {}
    D2DVector(float x, float y) : X(x), Y(y) {}
};

struct D3DVector {
    float X, Y, Z;
    D3DVector() : X(0), Y(0), Z(0) {}
    D3DVector(float x, float y, float z) : X(x), Y(y), Z(z) {}
};

struct D4DVector {
    float X, Y, Z, W;
    D4DVector() : X(0), Y(0), Z(0), W(0) {}
    D4DVector(float x, float y, float z, float w) : X(x), Y(y), Z(z), W(w) {}
};

struct Toggles {
    bool Rendering = false;
    bool Box = true;
    bool BoxFilled = false;
    bool CornerBox = false;
    bool Line = true;
    bool LineFromBottom = false;
    bool Distance = true;
    bool Name = true;
    bool Health = true;
    bool HealthBar = true;
    bool Armor = true;
    bool Shield = true;
    bool Weapon = true;
    bool Faction = true;
    bool Snaplines = false;
    bool Skeleton = false;
    bool AimLine = false;
    bool Aimbot = false;
    bool AimbotCircle = true;
    bool AimbotAutoFire = false;
    bool AimbotVisibleCheck = true;
    bool AimbotPrediction = true;
    bool AimbotSmooth = true;
    bool AimbotTargetLine = false;
    bool AimbotDrawFOV = true;
    bool AimbotDrawTarget = true;
    bool AimbotOn = false;
    bool ItemESP = false;
    bool VehicleESP = false;
    bool SupplyESP = false;
    bool TrapESP = false;
    bool CollectibleESP = false;
    bool NpcESP = false;
    bool PlayerESP = true;
    bool Chams = false;
    bool Glow = false;
    bool NightVision = false;
    bool ThermalVision = false;
    bool Wireframe = false;
    bool NoFog = false;
    bool NoRecoil = false;
    bool NoSpread = false;
    bool Wallhack = false;
    bool XRay = false;
    bool SpeedHack = false;
    bool FlyHack = false;
    bool Teleport = false;
    bool GodMode = false;
    bool UnlimitedAmmo = false;
    bool InfiniteAmmo = false;
    bool OneHitKill = false;
    bool NoClip = false;
    bool FilterTeam = true;
    bool FilterSelf = true;
    bool FilterEnemy = true;
    bool FilterVisible = false;
    bool FilterDistance = false;
    bool ShowCrosshair = true;
    bool ShowRadar = false;
    bool ShowCompass = false;
    bool ShowInfo = true;
    bool ShowFPS = true;
    bool ShowWatermark = true;
    bool SafeMode = false;
    bool StreamMode = false;
    bool AimbotAutoScope = false;
    bool AimbotAutoWallbang = false;
    bool TriggerbotEnabled = false;
    bool TriggerbotFriendlyFire = false;
    bool RCSRandomization = false;
    bool IgnoreDowned = true;
    bool TargetSwitchDelay = true;
    bool RadarRotate = true;
    bool RadarNames = true;
    bool RadarDistance = true;
    bool RadarSnaplines = false;
    bool RadarScan = true;
    bool LootWeapons = true;
    bool LootAmmo = true;
    bool LootConsumables = true;
    bool LootAttachments = true;
    bool LootArmor = true;
    bool LootThrowables = true;
    bool LootSpecial = true;
    bool RarityCommon = true;
    bool RarityUncommon = true;
    bool RarityRare = true;
    bool RarityEpic = true;
    bool RarityLegendary = true;
    bool ItemName = true;
    bool ItemDistance = true;
    bool ItemRarity = true;
    bool ItemGlow = false;
    bool ItemIcons = true;
    bool RadarShowEnemy = true;
    bool RadarShowTeam = true;
    bool LootESP = false;
    bool LootSortAscending = true;
    bool LootSortBy = false;
    bool AutoSprint = false;
    bool BunnyHop = false;
    bool NoFallDamage = false;
    bool InfiniteStamina = false;
    bool NoHunger = false;
    bool NoThirst = false;
    bool NoBreath = false;
    bool InfiniteOxygen = false;
    bool Invisible = false;
    bool InstantADS = false;
    bool RapidFire = false;
    bool ShowPlayerCount = true;
    bool ShowServerInfo = true;
    bool ShowAllOnRadar = false;
    bool MagicBullet = false;
    bool Triggerbot = false;
    bool AutoLoot = false;
    bool AutoPickup = false;
    bool AutoHeal = false;
    bool AutoReload = false;
    bool AutoRespawn = false;
    bool AutoCraft = false;
    bool AutoFarm = false;
    bool NoSmoke = false;
    bool NoFlash = false;
    bool NightMode = false;
    bool DayTime = false;
    bool CleanScreen = false;
    bool AntiScreenshot = false;
    bool StreamProof = false;
    bool Animations = true;
    bool Particles = true;
    bool ShowNotifications = true;
    bool ESPBox = true;
    bool ESPSnaplines = false;
    bool ESPHealthBar = true;
    bool ESPNameTags = true;
    bool ESPDistance = true;
    bool ESPWeapon = true;
    bool AimbotEnabled = true;
    bool MiscBunnyHop = false;
    bool MiscNoRecoil = false;
};

struct Config {
    float AimbotRange = 350.0f;
    float AimbotSmoothValue = 5.0f;
    float AimbotMaxDistance = 500.0f;
    float AimbotMaxDelta = 5.0f;
    float AimbotPredictionValue = 1.0f;
    float ESPMaxDistance = 400.0f;
    float ESPMaxRender = 1000.0f;
    float BoxWidth = 2.0f;
    float LineWidth = 1.5f;
    float TextSize = 22.0f;
    float CrosshairSize = 20.0f;
    float CrosshairThickness = 2.0f;
    float RadarRange = 200.0f;
    float RadarScale = 150.0f;
    float RadarOpacity = 0.8f;
    float RadarDotSize = 3.0f;
    float HealthBarWidth = 4.0f;
    float FOV = 90.0f;
    float LootMaxDistance = 100.0f;
    float UIScale = 1.0f;
    int SelectedAimbotBone = 0;
    int SelectedAimbotPriority = 0;
    int SelectedTarget = -1;
    int SelectedColorTheme = 0;
    int Theme = 0;
    int SelectedAimbotMode = 0;
    int TriggerMode = 0;
    int RCSMode = 0;
    int SelectedCrosshair = 0;
    int CrosshairStyle = 0;
    int LootSortBy = 0;
    int RadarShowEnemy = 0;
    int RadarShowTeam = 0;
    float AimbotFOVHue = 0.0f;
    float AimbotTargetLineWidth = 2.0f;
    float AimbotFireRate = 600.0f;
    float TriggerDelay = 50.0f;
    float RCSVerticalValue = 50.0f;
    float RCSHorizontalValue = 30.0f;
    float SwitchDelayValue = 500.0f;
    float MaxTargetsValue = 5.0f;
    float WalkSpeed = 200.0f;
    float RunSpeed = 500.0f;
    float SpeedMultiplier = 2.0f;
    float JumpHeight = 2.0f;
    float Gravity = 1.0f;
    float SwimSpeed = 300.0f;
    float FlySpeed = 10.0f;
    float FireRateMult = 1.0f;
    float AutoHealHP = 30.0f;
    float TimeOfDay = 12.0f;
    int Weather = 0;
    int LootRadius = 10;
    int FarmRange = 20;
    float HealPercent = 30.0f;
    float WorldBrightness = 1.0f;
    ImColor ESPBoxColor = ImColor(255, 255, 255);
    ImColor ESPWallColor = ImColor(0, 100, 255);
    ImColor ESPVisibleColor = ImColor(0, 255, 0);
    ImColor ESPEnemyColor = ImColor(255, 0, 0);
    ImColor ESPTeamColor = ImColor(0, 150, 255);
    ImColor ESPLineColor = ImColor(255, 255, 255);
    ImColor ESPNameColor = ImColor(255, 255, 255);
    ImColor ESPDistanceColor = ImColor(255, 255, 255);
    ImColor AimbotFOVColor = ImColor(255, 0, 0, 100);
    ImColor AimbotTargetColor = ImColor(255, 50, 50);
    ImColor AimLineColor = ImColor(0, 255, 0);
    ImColor CrosshairColor = ImColor(255, 255, 255);
    ImColor CrosshairColorPick = ImColor(255, 100, 100);
    ImColor WatermarkColor = ImColor(0, 200, 255);
    ImColor BackgroundColor = ImColor(15, 15, 20);
    ImColor AccentColor = ImColor(0, 180, 255);
    ImColor AccentColor2 = ImColor(100, 50, 255);
};

struct BoneJoint {
    int Parent;
    int Child;
    BoneJoint(int p, int c) : Parent(p), Child(c) {}
};

struct PlayerData {
    D3DVector Position;
    D3DVector Head;
    D3DVector Feet;
    float Health;
    float MaxHealth;
    float Armor;
    float Shield;
    float Distance;
    bool IsVisible;
    bool IsAlive;
    bool IsBot;
    int TeamID;
    int PlayerID;
    char PlayerName[64];
    char WeaponName[32];
    uintptr_t Address;
    uintptr_t BoneAddress;
    uintptr_t WeaponAddr;
};

struct EnhancedPlayerData : PlayerData {
    D3DVector bonePositions[128];
    int boneCount;
    float aimPitch;
    float aimYaw;
    bool isScoping;
    bool isReloading;
    bool isShooting;
    bool isCrouching;
    bool isProne;
    bool isJumping;
    bool isRunning;
    bool isSwimming;
    bool isDriving;
    bool isParachuting;
    bool hasWeapon;
    int currentWeaponID;
    float fireRate;
    float lastFireTime;
    D3DVector velocity;
    D3DVector aimDirection;
    float boundingRadius;
    int kills;
    int deaths;
    int assists;
    int level;
    int rank;
    char clanTag[32];
    char country[32];
    uint64_t playerId;
    float latency;
    int ping;
};
