#include "NetworkSystem.h"
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <random>
#include <array>
#include <zlib.h>
#include <sodium.h>

namespace BugorNetwork {

std::mutex TLSSocket::globalSSLMutex;
int TLSSocket::sslInstanceCount = 0;

TLSSocket::TLSSocket()
    : ctx(nullptr), ssl(nullptr), sock(-1), connected(false), initOpenSSL(false) {
    memset(&hostname, 0, sizeof(hostname));
}

TLSSocket::~TLSSocket() {
    cleanup();
}

bool TLSSocket::initialize() {
    std::lock_guard<std::mutex> lock(globalSSLMutex);
    if (sslInstanceCount == 0) {
        SSL_library_init();
        OpenSSL_add_all_algorithms();
        SSL_load_error_strings();
        OpenSSL_add_all_ciphers();
        OpenSSL_add_all_digests();
    }
    sslInstanceCount++;
    initOpenSSL = true;
    return createContext();
}

bool TLSSocket::createContext() {
    ctx = SSL_CTX_new(TLS_client_method());
    if (!ctx) return false;
    SSL_CTX_set_mode(ctx, SSL_MODE_AUTO_RETRY);
    SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, nullptr);
    SSL_CTX_set_default_verify_paths(ctx);
    SSL_CTX_load_verify_locations(ctx, "/system/etc/security/cacerts/*", nullptr);
    SSL_CTX_set_options(ctx, SSL_OP_NO_SSLv2 | SSL_OP_NO_SSLv3 |
                              SSL_OP_NO_TLSv1 | SSL_OP_NO_TLSv1_1 |
                              SSL_OP_SINGLE_DH_USE);
    SSL_CTX_set_cipher_list(ctx, "ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:"
                                  "ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:"
                                  "DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384:"
                                  "ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305");
    SSL_CTX_set_ecdh_auto(ctx, 1);
    SSL_CTX_set_security_level(ctx, 1);
    return true;
}

bool TLSSocket::configureContext() {
    if (!ctx) return false;
    if (!caCertPath.empty()) {
        SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, nullptr);
        SSL_CTX_load_verify_locations(ctx, caCertPath.c_str(), nullptr);
    }
    if (!clientCertPath.empty() && !clientKeyPath.empty()) {
        SSL_CTX_use_certificate_file(ctx, clientCertPath.c_str(), SSL_FILETYPE_PEM);
        SSL_CTX_use_PrivateKey_file(ctx, clientKeyPath.c_str(), SSL_FILETYPE_PEM);
    }
    return true;
}

bool TLSSocket::connect(const std::string &host, uint16_t port) {
    std::lock_guard<std::mutex> lock(sslMutex);
    hostname = host;
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) return false;
    struct hostent *server = gethostbyname(host.c_str());
    if (!server) { close(sock); sock = -1; return false; }
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    memcpy(&addr.sin_addr.s_addr, server->h_addr, server->h_length);
    if (::connect(sock, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        close(sock);
        sock = -1;
        return false;
    }
    ssl = SSL_new(ctx);
    if (!ssl) { close(sock); sock = -1; return false; }
    SSL_set_fd(ssl, sock);
    SSL_set_tlsext_host_name(ssl, host.c_str());
    int ret = SSL_connect(ssl);
    if (ret != 1) {
        SSL_free(ssl);
        ssl = nullptr;
        close(sock);
        sock = -1;
        return false;
    }
    connected = true;
    return true;
}

bool TLSSocket::connectWithProxy(const std::string &host, uint16_t port,
                                  const std::string &proxyHost, uint16_t proxyPort) {
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) return false;
    struct hostent *proxy = gethostbyname(proxyHost.c_str());
    if (!proxy) { close(sock); return false; }
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(proxyPort);
    memcpy(&addr.sin_addr.s_addr, proxy->h_addr, proxy->h_length);
    if (::connect(sock, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        close(sock);
        return false;
    }
    std::string connectReq = "CONNECT " + host + ":" + std::to_string(port) +
                             " HTTP/1.1\r\nHost: " + host + "\r\n\r\n";
    send(sock, connectReq.c_str(), connectReq.length(), 0);
    char buffer[4096];
    int n = recv(sock, buffer, sizeof(buffer) - 1, 0);
    if (n <= 0) { close(sock); return false; }
    buffer[n] = 0;
    if (strstr(buffer, "200") == NULL) { close(sock); return false; }
    ssl = SSL_new(ctx);
    if (!ssl) { close(sock); return false; }
    SSL_set_fd(ssl, sock);
    SSL_set_tlsext_host_name(ssl, host.c_str());
    if (SSL_connect(ssl) != 1) {
        SSL_free(ssl); ssl = nullptr;
        close(sock);
        return false;
    }
    connected = true;
    hostname = host;
    return true;
}

bool TLSSocket::handshake() {
    if (!ssl) return false;
    int ret = SSL_do_handshake(ssl);
    return ret == 1;
}

ssize_t TLSSocket::send(const uint8_t *data, size_t length) {
    std::lock_guard<std::mutex> lock(sslMutex);
    if (!ssl || !connected) return -1;
    int ret = SSL_write(ssl, data, length);
    if (ret <= 0) {
        int err = SSL_get_error(ssl, ret);
        if (err == SSL_ERROR_WANT_WRITE || err == SSL_ERROR_WANT_READ) {
            return 0;
        }
        connected = false;
        return -1;
    }
    return ret;
}

ssize_t TLSSocket::recv(uint8_t *buffer, size_t length) {
    std::lock_guard<std::mutex> lock(sslMutex);
    if (!ssl || !connected) return -1;
    int ret = SSL_read(ssl, buffer, length);
    if (ret <= 0) {
        int err = SSL_get_error(ssl, ret);
        if (err == SSL_ERROR_WANT_READ || err == SSL_ERROR_WANT_WRITE) {
            return 0;
        }
        connected = false;
        return -1;
    }
    return ret;
}

bool TLSSocket::shutdown() {
    std::lock_guard<std::mutex> lock(sslMutex);
    if (ssl) {
        SSL_shutdown(ssl);
    }
    connected = false;
    return true;
}

void TLSSocket::cleanup() {
    std::lock_guard<std::mutex> lock(sslMutex);
    if (ssl) {
        SSL_free(ssl);
        ssl = nullptr;
    }
    if (sock >= 0) {
        close(sock);
        sock = -1;
    }
    if (ctx) {
        SSL_CTX_free(ctx);
        ctx = nullptr;
    }
    connected = false;
    std::lock_guard<std::mutex> globalLock(globalSSLMutex);
    sslInstanceCount--;
    if (sslInstanceCount <= 0) {
        EVP_cleanup();
        ERR_free_strings();
    }
}

bool TLSSocket::isConnected() const {
    return connected;
}

int TLSSocket::getSocket() const {
    return sock;
}

SSL* TLSSocket::getSSL() const {
    return ssl;
}

std::string TLSSocket::getCipher() const {
    if (!ssl) return "";
    return SSL_get_cipher(ssl);
}

std::string TLSSocket::getVersion() const {
    if (!ssl) return "";
    return SSL_get_version(ssl);
}

bool TLSSocket::verifyCertificate() {
    if (!ssl) return false;
    X509 *cert = SSL_get_peer_certificate(ssl);
    if (!cert) return false;
    long result = SSL_get_verify_result(ssl);
    X509_free(cert);
    return result == X509_V_OK;
}

void TLSSocket::setTimeout(uint32_t seconds) {
    if (sock >= 0) {
        struct timeval tv;
        tv.tv_sec = seconds;
        tv.tv_usec = 0;
        setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
        setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    }
}

void TLSSocket::setNonBlocking(bool enable) {
    if (sock < 0) return;
    int flags = fcntl(sock, F_GETFL, 0);
    if (enable) {
        fcntl(sock, F_SETFL, flags | O_NONBLOCK);
    } else {
        fcntl(sock, F_SETFL, flags & ~O_NONBLOCK);
    }
}

bool TLSSocket::setCertificate(const std::string &ca, const std::string &cert,
                                const std::string &key) {
    caCertPath = ca;
    clientCertPath = cert;
    clientKeyPath = key;
    return configureContext();
}

bool TLSSocket::loadCertificate(const std::string &path) {
    return true;
}

bool TLSSocket::setSNI(const std::string &hostname) {
    if (ssl) {
        SSL_set_tlsext_host_name(ssl, hostname.c_str());
        return true;
    }
    return false;
}

HTTPClient::HTTPClient() : timeout(30), keepAlive(false) {
    userAgent = "BugorEngine/7.3.0";
}

HTTPClient::~HTTPClient() {}

HTTPClient::Response HTTPClient::get(const std::string &url) {
    return sendRequest("GET", url, {}, {});
}

HTTPClient::Response HTTPClient::post(const std::string &url, const std::vector<uint8_t> &data) {
    return sendRequest("POST", url, {}, data);
}

HTTPClient::Response HTTPClient::put(const std::string &url, const std::vector<uint8_t> &data) {
    return sendRequest("PUT", url, {}, data);
}

HTTPClient::Response HTTPClient::del(const std::string &url) {
    return sendRequest("DELETE", url, {}, {});
}

HTTPClient::Response HTTPClient::head(const std::string &url) {
    return sendRequest("HEAD", url, {}, {});
}

HTTPClient::Response HTTPClient::options(const std::string &url) {
    return sendRequest("OPTIONS", url, {}, {});
}

HTTPClient::Response HTTPClient::patch(const std::string &url, const std::vector<uint8_t> &data) {
    return sendRequest("PATCH", url, {}, data);
}

HTTPClient::Response HTTPClient::execute(const Request &req) {
    return sendRequest(req.method, req.url, req.headers, req.body);
}

void HTTPClient::setBaseUrl(const std::string &url) { baseUrl = url; }
void HTTPClient::setDefaultHeader(const std::string &key, const std::string &value) {
    defaultHeaders[key] = value;
}

void HTTPClient::setProxy(const std::string &host, uint16_t port) {
    proxyHost = host;
    proxyPort = port;
}

void HTTPClient::setCertificate(const std::string &ca, const std::string &cert,
                                 const std::string &key) {
    caPath = ca; certPath = cert; keyPath = key;
}

void HTTPClient::setTimeout(uint32_t sec) { timeout = sec; }
void HTTPClient::setUserAgent(const std::string &ua) { userAgent = ua; }

void HTTPClient::setBearerToken(const std::string &token) {
    defaultHeaders["Authorization"] = "Bearer " + token;
}

void HTTPClient::setApiKey(const std::string &key) {
    defaultHeaders["X-API-Key"] = key;
}

void HTTPClient::enableKeepAlive(bool enable) { keepAlive = enable; }

std::string HTTPClient::urlEncode(const std::string &value) {
    std::ostringstream escaped;
    for (char c : value) {
        if (isalnum(c) || c == '-' || c == '_' || c == '.' || c == '~') {
            escaped << c;
        } else {
            escaped << '%' << std::hex << std::uppercase << std::setw(2)
                    << static_cast<int>(static_cast<unsigned char>(c));
        }
    }
    return escaped.str();
}

std::map<std::string, std::string> HTTPClient::urlDecode(const std::string &encoded) {
    std::map<std::string, std::string> params;
    std::stringstream ss(encoded);
    std::string pair;
    while (std::getline(ss, pair, '&')) {
        auto pos = pair.find('=');
        if (pos != std::string::npos) {
            params[pair.substr(0, pos)] = pair.substr(pos + 1);
        }
    }
    return params;
}

std::string HTTPClient::buildQueryString(const std::map<std::string, std::string> &params) {
    std::string query;
    for (auto &[key, value] : params) {
        if (!query.empty()) query += "&";
        query += urlEncode(key) + "=" + urlEncode(value);
    }
    return query;
}

HTTPClient::Response HTTPClient::sendRequest(const std::string &method,
                                              const std::string &url,
                                              const std::map<std::string, std::string> &headers,
                                              const std::vector<uint8_t> &body) {
    Response resp;
    resp.success = false;
    std::string host, path;
    uint16_t port;
    bool isTLS;
    std::string fullUrl = url;
    if (!baseUrl.empty() && url.find("://") == std::string::npos) {
        fullUrl = baseUrl + url;
    }
    std::string parsedUrl = parseURL(fullUrl, host, port, path, isTLS);
    std::map<std::string, std::string> reqHeaders = defaultHeaders;
    for (auto &[k, v] : headers) reqHeaders[k] = v;
    if (reqHeaders.find("User-Agent") == reqHeaders.end())
        reqHeaders["User-Agent"] = userAgent;
    if (reqHeaders.find("Host") == reqHeaders.end())
        reqHeaders["Host"] = host;
    if (!body.empty() && reqHeaders.find("Content-Type") == reqHeaders.end())
        reqHeaders["Content-Type"] = "application/octet-stream";
    if (keepAlive) reqHeaders["Connection"] = "keep-alive";
    else reqHeaders["Connection"] = "close";
    std::string request = buildRequest(method, path, reqHeaders, body);
    bool useTLS = isTLS;
    int rawSock = -1;
    if (!proxyHost.empty()) {
        rawSock = socket(AF_INET, SOCK_STREAM, 0);
        struct hostent *proxy = gethostbyname(proxyHost.c_str());
        if (!proxy) { resp.error = "Proxy DNS failed"; return resp; }
        struct sockaddr_in proxyAddr;
        memset(&proxyAddr, 0, sizeof(proxyAddr));
        proxyAddr.sin_family = AF_INET;
        proxyAddr.sin_port = htons(proxyPort);
        memcpy(&proxyAddr.sin_addr.s_addr, proxy->h_addr, proxy->h_length);
        if (::connect(rawSock, (struct sockaddr*)&proxyAddr, sizeof(proxyAddr)) < 0) {
            resp.error = "Proxy connection failed";
            close(rawSock);
            return resp;
        }
        std::string connectReq = "CONNECT " + host + ":" + std::to_string(port) +
                                 " HTTP/1.1\r\nHost: " + host + "\r\n\r\n";
        send(rawSock, connectReq.c_str(), connectReq.length(), 0);
        char buf[4096];
        int n = recv(rawSock, buf, sizeof(buf) - 1, 0);
        if (n <= 0) { close(rawSock); resp.error = "Proxy CONNECT failed"; return resp; }
        buf[n] = 0;
        if (!strstr(buf, "200")) { close(rawSock); resp.error = "Proxy rejected"; return resp; }
        if (useTLS) {
            tlsSocket = std::make_unique<TLSSocket>();
            tlsSocket->initialize();
            SSL *ssl = SSL_new(tlsSocket->getSSL());
            if (ssl) {
                SSL_set_fd(ssl, rawSock);
                SSL_connect(ssl);
                SSL_write(ssl, request.c_str(), request.length());
                std::string rawResponse;
                char rbuf[8192];
                while ((n = SSL_read(ssl, rbuf, sizeof(rbuf))) > 0) {
                    rawResponse.append(rbuf, n);
                }
                resp = parseResponse(rawResponse);
                SSL_free(ssl);
            }
            close(rawSock);
            return resp;
        } else {
            send(rawSock, request.c_str(), request.length(), 0);
            std::string rawResponse;
            char rbuf[8192];
            while ((n = recv(rawSock, rbuf, sizeof(rbuf), 0)) > 0) {
                rawResponse.append(rbuf, n);
            }
            close(rawSock);
            return parseResponse(rawResponse);
        }
    }
    rawSock = socket(AF_INET, SOCK_STREAM, 0);
    if (rawSock < 0) { resp.error = "Socket creation failed"; return resp; }
    struct hostent *server = gethostbyname(host.c_str());
    if (!server) { close(rawSock); resp.error = "DNS resolution failed"; return resp; }
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    memcpy(&addr.sin_addr.s_addr, server->h_addr, server->h_length);
    struct timeval tv;
    tv.tv_sec = timeout;
    tv.tv_usec = 0;
    setsockopt(rawSock, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(rawSock, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    if (::connect(rawSock, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        close(rawSock);
        resp.error = "Connection failed: " + std::string(strerror(errno));
        return resp;
    }
    auto startTime = std::chrono::steady_clock::now();
    if (useTLS) {
        tlsSocket = std::make_unique<TLSSocket>();
        if (!tlsSocket->initialize()) {
            close(rawSock);
            resp.error = "TLS init failed";
            return resp;
        }
        SSL *ssl = SSL_new(tlsSocket->getSSL());
        if (!ssl) { close(rawSock); resp.error = "SSL new failed"; return resp; }
        SSL_set_fd(ssl, rawSock);
        SSL_set_tlsext_host_name(ssl, host.c_str());
        int ret = SSL_connect(ssl);
        if (ret != 1) {
            SSL_free(ssl);
            close(rawSock);
            resp.error = "SSL handshake failed";
            return resp;
        }
        SSL_write(ssl, request.c_str(), request.length());
        std::string rawResponse;
        char rbuf[8192];
        while ((n = SSL_read(ssl, rbuf, sizeof(rbuf))) > 0) {
            rawResponse.append(rbuf, n);
        }
        SSL_free(ssl);
        close(rawSock);
        resp = parseResponse(rawResponse);
    } else {
        send(rawSock, request.c_str(), request.length(), 0);
        std::string rawResponse;
        char rbuf[8192];
        while ((n = recv(rawSock, rbuf, sizeof(rbuf), 0)) > 0) {
            rawResponse.append(rbuf, n);
        }
        close(rawSock);
        resp = parseResponse(rawResponse);
    }
    auto endTime = std::chrono::steady_clock::now();
    resp.elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
        endTime - startTime).count();
    resp.success = resp.statusCode >= 200 && resp.statusCode < 400;
    return resp;
}

std::string HTTPClient::buildRequest(const std::string &method, const std::string &path,
                                      const std::map<std::string, std::string> &headers,
                                      const std::vector<uint8_t> &body) {
    std::string request = method + " " + path + " HTTP/1.1\r\n";
    for (auto &[key, value] : headers) {
        request += key + ": " + value + "\r\n";
    }
    if (!body.empty()) {
        request += "Content-Length: " + std::to_string(body.size()) + "\r\n";
    }
    request += "\r\n";
    if (!body.empty()) {
        request.append(reinterpret_cast<const char*>(body.data()), body.size());
    }
    return request;
}

HTTPClient::Response HTTPClient::parseResponse(const std::string &raw) {
    Response resp;
    resp.statusCode = 0;
    resp.success = false;
    if (raw.empty()) return resp;
    size_t headerEnd = raw.find("\r\n\r\n");
    if (headerEnd == std::string::npos) {
        headerEnd = raw.find("\n\n");
        if (headerEnd == std::string::npos) return resp;
    }
    std::string headerPart = raw.substr(0, headerEnd);
    if (raw[headerEnd] == '\r') headerEnd += 4;
    else headerEnd += 2;
    std::vector<uint8_t> bodyData(raw.begin() + headerEnd, raw.end());
    resp.body = bodyData;
    resp.text = std::string(bodyData.begin(), bodyData.end());
    std::stringstream ss(headerPart);
    std::string line;
    bool firstLine = true;
    while (std::getline(ss, line)) {
        if (line.back() == '\r') line.pop_back();
        if (firstLine) {
            size_t pos = line.find(' ');
            if (pos != std::string::npos) {
                resp.statusCode = std::stoi(line.substr(pos + 1, 3));
            }
            firstLine = false;
        } else {
            size_t pos = line.find(": ");
            if (pos != std::string::npos) {
                resp.headers[line.substr(0, pos)] = line.substr(pos + 2);
            }
        }
    }
    return resp;
}

std::string HTTPClient::parseURL(const std::string &url, std::string &host,
                                  uint16_t &port, std::string &path, bool &isTLS) {
    isTLS = url.find("https://") == 0;
    std::string temp = url;
    if (temp.find("https://") == 0) temp = temp.substr(8);
    else if (temp.find("http://") == 0) temp = temp.substr(7);
    size_t pathPos = temp.find('/');
    if (pathPos == std::string::npos) {
        host = temp;
        path = "/";
    } else {
        host = temp.substr(0, pathPos);
        path = temp.substr(pathPos);
    }
    size_t portPos = host.find(':');
    if (portPos != std::string::npos) {
        port = std::stoi(host.substr(portPos + 1));
        host = host.substr(0, portPos);
    } else {
        port = isTLS ? 443 : 80;
    }
    return temp;
}

WebSocketClient::WebSocketClient()
    : sock(-1), port(0), useTLS(false), connected(false),
      autoReconnect(false), reconnectDelay(5000), timeout(30),
      running(false), workerThread(nullptr) {}

WebSocketClient::~WebSocketClient() {
    stop();
}

bool WebSocketClient::connect(const std::string &url) {
    std::string h, p;
    uint16_t pt;
    bool tls;
    if (url.find("wss://") == 0) {
        h = url.substr(6);
        tls = true;
    } else if (url.find("ws://") == 0) {
        h = url.substr(5);
        tls = false;
    } else {
        h = url;
        tls = false;
    }
    size_t pathPos = h.find('/');
    if (pathPos != std::string::npos) {
        p = h.substr(pathPos);
        h = h.substr(0, pathPos);
    } else {
        p = "/";
    }
    size_t portPos = h.find(':');
    if (portPos != std::string::npos) {
        pt = std::stoi(h.substr(portPos + 1));
        h = h.substr(0, portPos);
    } else {
        pt = tls ? 443 : 80;
    }
    return connect(h, pt, p);
}

bool WebSocketClient::connect(const std::string &hostName, uint16_t portNum,
                               const std::string &pathName) {
    std::lock_guard<std::mutex> lock(socketMutex);
    host = hostName;
    port = portNum;
    path = pathName;
    useTLS = (portNum == 443);
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) return false;
    struct hostent *server = gethostbyname(host.c_str());
    if (!server) { close(sock); sock = -1; return false; }
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    memcpy(&addr.sin_addr.s_addr, server->h_addr, server->h_length);
    if (::connect(sock, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        close(sock);
        sock = -1;
        return false;
    }
    if (useTLS) {
        tls = std::make_unique<TLSSocket>();
        tls->initialize();
        SSL *ssl = SSL_new(tls->getSSL());
        SSL_set_fd(ssl, sock);
        SSL_set_tlsext_host_name(ssl, host.c_str());
        if (SSL_connect(ssl) != 1) {
            SSL_free(ssl);
            close(sock);
            return false;
        }
    }
    if (!performHandshake()) {
        disconnect();
        return false;
    }
    connected = true;
    changeState(ProtocolState::Connected);
    return true;
}

bool WebSocketClient::performHandshake() {
    std::string wsKey = generateWebSocketKey();
    std::string request = "GET " + path + " HTTP/1.1\r\n";
    request += "Host: " + host + ":" + std::to_string(port) + "\r\n";
    request += "Upgrade: websocket\r\n";
    request += "Connection: Upgrade\r\n";
    request += "Sec-WebSocket-Key: " + wsKey + "\r\n";
    request += "Sec-WebSocket-Version: 13\r\n";
    for (auto &[k, v] : headers) {
        request += k + ": " + v + "\r\n";
    }
    request += "\r\n";
    if (useTLS && tls) {
        SSL_write(tls->getSSL(), request.c_str(), request.length());
    } else {
        send(sock, request.c_str(), request.length(), 0);
    }
    char buffer[4096];
    int n;
    if (useTLS && tls) {
        n = SSL_read(tls->getSSL(), buffer, sizeof(buffer) - 1);
    } else {
        n = recv(sock, buffer, sizeof(buffer) - 1, 0);
    }
    if (n <= 0) return false;
    buffer[n] = 0;
    return strstr(buffer, "101") != NULL;
}

std::string WebSocketClient::generateWebSocketKey() {
    std::array<uint8_t, 16> key;
    std::random_device rd;
    for (int i = 0; i < 16; ++i) key[i] = rd() % 256;
    static const char table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string result;
    for (int i = 0; i < 16; i += 3) {
        uint32_t val = (key[i] << 16) | (key[i+1] << 8) | key[i+2];
        result += table[(val >> 18) & 0x3F];
        result += table[(val >> 12) & 0x3F];
        result += table[(val >> 6) & 0x3F];
        result += table[val & 0x3F];
    }
    return result;
}

bool WebSocketClient::disconnect() {
    std::lock_guard<std::mutex> lock(socketMutex);
    connected = false;
    if (sock >= 0) {
        close(sock);
        sock = -1;
    }
    changeState(ProtocolState::Disconnected);
    return true;
}

bool WebSocketClient::send(const std::vector<uint8_t> &data, bool binary) {
    uint8_t opcode = binary ? 0x02 : 0x01;
    return sendFrame(opcode, data);
}

bool WebSocketClient::sendText(const std::string &text) {
    std::vector<uint8_t> data(text.begin(), text.end());
    return sendFrame(0x01, data);
}

bool WebSocketClient::sendPing() {
    return sendFrame(0x09, {});
}

bool WebSocketClient::sendPong() {
    return sendFrame(0x0A, {});
}

bool WebSocketClient::isConnected() const {
    return connected;
}

void WebSocketClient::setMessageCallback(MessageCallback cb) {
    std::lock_guard<std::mutex> lock(callbackMutex);
    onMessage = cb;
}

void WebSocketClient::setStateCallback(StateCallback cb) {
    std::lock_guard<std::mutex> lock(callbackMutex);
    onState = cb;
}

void WebSocketClient::setErrorCallback(ErrorCallback cb) {
    std::lock_guard<std::mutex> lock(callbackMutex);
    onError = cb;
}

void WebSocketClient::setProxy(const std::string &h, uint16_t p) {
    proxyHost = h; proxyPort = p;
}

void WebSocketClient::setTimeout(uint32_t t) { timeout = t; }
void WebSocketClient::setAutoReconnect(bool enable) { autoReconnect = enable; }
void WebSocketClient::setReconnectDelay(uint32_t ms) { reconnectDelay = ms; }
void WebSocketClient::setHeader(const std::string &key, const std::string &value) {
    headers[key] = value;
}

void WebSocketClient::start() {
    if (running) return;
    running = true;
    workerThread = new std::thread(&WebSocketClient::workerLoop, this);
}

void WebSocketClient::stop() {
    running = false;
    disconnect();
    if (workerThread && workerThread->joinable()) {
        workerThread->join();
        delete workerThread;
        workerThread = nullptr;
    }
}

void WebSocketClient::workerLoop() {
    while (running) {
        if (!connected) {
            if (autoReconnect) {
                std::this_thread::sleep_for(std::chrono::milliseconds(reconnectDelay));
                connect(host, port, path);
            } else {
                break;
            }
        }
        if (connected) {
            uint8_t header[2];
            int n;
            if (useTLS && tls) {
                n = SSL_read(tls->getSSL(), header, 2);
            } else {
                n = recv(sock, header, 2, 0);
            }
            if (n != 2) {
                connected = false;
                changeState(ProtocolState::Disconnected);
                continue;
            }
            uint8_t opcode = header[0] & 0x0F;
            uint8_t masked = (header[1] & 0x80) != 0;
            uint64_t payloadLength = header[1] & 0x7F;
            if (payloadLength == 126) {
                uint8_t ext[2];
                if (useTLS && tls) SSL_read(tls->getSSL(), ext, 2);
                else recv(sock, ext, 2, 0);
                payloadLength = (ext[0] << 8) | ext[1];
            } else if (payloadLength == 127) {
                uint8_t ext[8];
                if (useTLS && tls) SSL_read(tls->getSSL(), ext, 8);
                else recv(sock, ext, 8, 0);
                payloadLength = 0;
                for (int i = 0; i < 8; ++i)
                    payloadLength = (payloadLength << 8) | ext[i];
            }
            uint8_t maskKey[4] = {0};
            if (masked) {
                if (useTLS && tls) SSL_read(tls->getSSL(), maskKey, 4);
                else recv(sock, maskKey, 4, 0);
            }
            std::vector<uint8_t> payload(payloadLength);
            if (payloadLength > 0) {
                if (useTLS && tls) SSL_read(tls->getSSL(), payload.data(), payloadLength);
                else recv(sock, payload.data(), payloadLength, 0);
                if (masked) {
                    for (uint64_t i = 0; i < payloadLength; ++i) {
                        payload[i] ^= maskKey[i % 4];
                    }
                }
            }
            handleFrame(opcode, payload);
        }
    }
}

void WebSocketClient::handleFrame(uint8_t opcode, const std::vector<uint8_t> &payload) {
    switch (opcode) {
        case 0x01:
        case 0x02: {
            std::lock_guard<std::mutex> lock(callbackMutex);
            if (onMessage) onMessage(payload, opcode == 0x02);
            break;
        }
        case 0x08:
            connected = false;
            changeState(ProtocolState::Disconnected);
            break;
        case 0x09:
            sendFrame(0x0A, {});
            break;
        case 0x0A:
            break;
    }
}

bool WebSocketClient::sendFrame(uint8_t opcode, const std::vector<uint8_t> &payload) {
    std::lock_guard<std::mutex> lock(socketMutex);
    if (!connected) return false;
    std::vector<uint8_t> frame;
    frame.push_back(0x80 | opcode);
    if (payload.size() < 126) {
        frame.push_back(payload.size());
    } else if (payload.size() < 65536) {
        frame.push_back(126);
        frame.push_back((payload.size() >> 8) & 0xFF);
        frame.push_back(payload.size() & 0xFF);
    } else {
        frame.push_back(127);
        uint64_t len = payload.size();
        for (int i = 7; i >= 0; --i) {
            frame.push_back((len >> (i * 8)) & 0xFF);
        }
    }
    frame.insert(frame.end(), payload.begin(), payload.end());
    int n;
    if (useTLS && tls) {
        n = SSL_write(tls->getSSL(), frame.data(), frame.size());
    } else {
        n = send(sock, frame.data(), frame.size(), 0);
    }
    return n > 0;
}

void WebSocketClient::changeState(ProtocolState state) {
    std::lock_guard<std::mutex> lock(callbackMutex);
    if (onState) onState(state);
}

EncryptedProtocol::EncryptedProtocol() : sequenceNumber(0), initialized(false) {
    memset(nonce, 0, sizeof(nonce));
    generateNonce();
}

EncryptedProtocol::~EncryptedProtocol() {}

bool EncryptedProtocol::initialize(const std::vector<uint8_t> &key) {
    if (key.size() < 32) return false;
    encryptionKey = key;
    initialized = true;
    sequenceNumber = 0;
    generateNonce();
    return true;
}

std::vector<uint8_t> EncryptedProtocol::encrypt(const std::vector<uint8_t> &data) {
    std::lock_guard<std::mutex> lock(cryptoMutex);
    if (!initialized) return data;
    std::vector<uint8_t> padded = padData(data);
    std::vector<uint8_t> ciphertext(padded.size() + crypto_secretbox_MACBYTES);
    unsigned long long clen;
    crypto_secretbox_easy(ciphertext.data(), padded.data(), padded.size(),
                          nonce, encryptionKey.data());
    incrementNonce();
    return ciphertext;
}

std::vector<uint8_t> EncryptedProtocol::decrypt(const std::vector<uint8_t> &data) {
    std::lock_guard<std::mutex> lock(cryptoMutex);
    if (!initialized) return data;
    if (data.size() < crypto_secretbox_MACBYTES) return {};
    std::vector<uint8_t> decrypted(data.size() - crypto_secretbox_MACBYTES);
    if (crypto_secretbox_open_easy(decrypted.data(), data.data(), data.size(),
                                   nonce, encryptionKey.data()) != 0) {
        return {};
    }
    incrementNonce();
    return unpadData(decrypted);
}

std::vector<uint8_t> EncryptedProtocol::encryptPacket(const NetworkPacket &packet) {
    std::vector<uint8_t> serialized;
    serialized.resize(sizeof(PacketHeader));
    memcpy(serialized.data(), &packet.header, sizeof(PacketHeader));
    std::vector<uint8_t> encBody = encrypt(packet.body);
    serialized.insert(serialized.end(), encBody.begin(), encBody.end());
    uint32_t *headerSize = reinterpret_cast<uint32_t*>(serialized.data() + 8);
    *headerSize = serialized.size() - sizeof(PacketHeader);
    return serialized;
}

NetworkPacket EncryptedProtocol::decryptPacket(const std::vector<uint8_t> &data) {
    NetworkPacket packet;
    if (data.size() < sizeof(PacketHeader)) return packet;
    memcpy(&packet.header, data.data(), sizeof(PacketHeader));
    std::vector<uint8_t> encBody(data.begin() + sizeof(PacketHeader), data.end());
    packet.body = decrypt(encBody);
    return packet;
}

std::vector<uint8_t> EncryptedProtocol::compress(const std::vector<uint8_t> &data) {
    uLongf compressedSize = compressBound(data.size());
    std::vector<uint8_t> compressed(compressedSize);
    if (compress2(compressed.data(), &compressedSize, data.data(), data.size(), Z_BEST_COMPRESSION) == Z_OK) {
        compressed.resize(compressedSize);
        return compressed;
    }
    return data;
}

std::vector<uint8_t> EncryptedProtocol::decompress(const std::vector<uint8_t> &data) {
    uLongf decompressedSize = data.size() * 10;
    std::vector<uint8_t> decompressed(decompressedSize);
    int ret = uncompress(decompressed.data(), &decompressedSize, data.data(), data.size());
    if (ret == Z_OK) {
        decompressed.resize(decompressedSize);
        return decompressed;
    }
    if (ret == Z_BUF_ERROR) {
        decompressedSize = data.size() * 100;
        decompressed.resize(decompressedSize);
        ret = uncompress(decompressed.data(), &decompressedSize, data.data(), data.size());
        if (ret == Z_OK) {
            decompressed.resize(decompressedSize);
            return decompressed;
        }
    }
    return data;
}

std::vector<uint8_t> EncryptedProtocol::sign(const std::vector<uint8_t> &data) {
    std::vector<uint8_t> signature(crypto_sign_BYTES);
    unsigned long long sigLen;
    crypto_sign_detached(signature.data(), &sigLen, data.data(), data.size(),
                         privateKey.data());
    signature.resize(sigLen);
    return signature;
}

bool EncryptedProtocol::verify(const std::vector<uint8_t> &data, const std::vector<uint8_t> &signature) {
    if (signature.size() != crypto_sign_BYTES) return false;
    return crypto_sign_verify_detached(signature.data(), data.data(), data.size(),
                                       publicKey.data()) == 0;
}

void EncryptedProtocol::setKey(const std::vector<uint8_t> &key) {
    encryptionKey = key;
}

void EncryptedProtocol::rotateKey() {
    generateKeyPair();
}

std::vector<uint8_t> EncryptedProtocol::getPublicKey() const {
    return publicKey;
}

bool EncryptedProtocol::generateKeyPair() {
    publicKey.resize(crypto_box_PUBLICKEYBYTES);
    privateKey.resize(crypto_box_SECRETKEYBYTES);
    crypto_box_keypair(publicKey.data(), privateKey.data());
    return true;
}

std::vector<uint8_t> EncryptedProtocol::keyExchange(const std::vector<uint8_t> &peerPublicKey) {
    std::vector<uint8_t> shared(crypto_box_BEFORENMBYTES);
    crypto_box_beforenm(shared.data(), peerPublicKey.data(), privateKey.data());
    return shared;
}

uint64_t EncryptedProtocol::getSequenceNumber() const {
    return sequenceNumber;
}

void EncryptedProtocol::resetSequence() {
    sequenceNumber = 0;
}

void EncryptedProtocol::incrementNonce() {
    for (int i = 0; i < 24; ++i) {
        nonce[i]++;
        if (nonce[i] != 0) break;
    }
}

void EncryptedProtocol::generateNonce() {
    randombytes_buf(nonce, sizeof(nonce));
}

std::vector<uint8_t> EncryptedProtocol::padData(const std::vector<uint8_t> &data) {
    size_t blockSize = 16;
    size_t padding = blockSize - (data.size() % blockSize);
    if (padding == 0) padding = blockSize;
    std::vector<uint8_t> padded(data.size() + padding);
    memcpy(padded.data(), data.data(), data.size());
    memset(padded.data() + data.size(), padding, padding);
    return padded;
}

std::vector<uint8_t> EncryptedProtocol::unpadData(const std::vector<uint8_t> &data) {
    if (data.empty()) return data;
    size_t padding = data.back();
    if (padding > data.size() || padding > 16) return data;
    std::vector<uint8_t> unpadded(data.begin(), data.end() - padding);
    return unpadded;
}

RemoteConfigFetcher::RemoteConfigFetcher() : cacheEnabled(true), cacheTTL(300) {}
RemoteConfigFetcher::~RemoteConfigFetcher() {}

bool RemoteConfigFetcher::fetch(const std::string &url, std::string &config) {
    if (cacheEnabled) {
        std::lock_guard<std::mutex> lock(cacheMutex);
        auto it = cache.find(url);
        if (it != cache.end()) {
            auto now = std::chrono::steady_clock::now();
            if (std::chrono::duration_cast<std::chrono::seconds>(now - it->second.second).count() < cacheTTL) {
                config = it->second.first;
                return true;
            }
        }
    }
    auto resp = client.get(url);
    if (resp.success) {
        config = resp.text;
        if (cacheEnabled) {
            std::lock_guard<std::mutex> lock(cacheMutex);
            cache[url] = {config, std::chrono::steady_clock::now()};
        }
        return true;
    }
    for (auto &fallback : fallbackUrls) {
        auto fbResp = client.get(fallback);
        if (fbResp.success) {
            config = fbResp.text;
            return true;
        }
    }
    if (!defaultConfig.empty()) {
        config = defaultConfig;
        return true;
    }
    return false;
}

bool RemoteConfigFetcher::fetchWithAuth(const std::string &url, const std::string &token,
                                         std::string &config) {
    client.setBearerToken(token);
    return fetch(url, config);
}

bool RemoteConfigFetcher::fetchWithSignature(const std::string &url,
                                              const std::vector<uint8_t> &key,
                                              std::string &config) {
    return fetch(url, config);
}

bool RemoteConfigFetcher::upload(const std::string &url, const std::string &config) {
    std::vector<uint8_t> data(config.begin(), config.end());
    auto resp = client.post(url, data);
    return resp.success;
}

bool RemoteConfigFetcher::uploadEncrypted(const std::string &url, const std::string &config,
                                           const std::vector<uint8_t> &key) {
    EncryptedProtocol crypto;
    if (!crypto.initialize(key)) return false;
    std::vector<uint8_t> data(config.begin(), config.end());
    auto encrypted = crypto.encrypt(data);
    auto resp = client.post(url, encrypted);
    return resp.success;
}

void RemoteConfigFetcher::setCacheEnabled(bool enable) { cacheEnabled = enable; }
void RemoteConfigFetcher::setCacheTTL(uint32_t seconds) { cacheTTL = seconds; }
void RemoteConfigFetcher::clearCache() {
    std::lock_guard<std::mutex> lock(cacheMutex);
    cache.clear();
}

bool RemoteConfigFetcher::getFromCache(const std::string &key, std::string &data) {
    std::lock_guard<std::mutex> lock(cacheMutex);
    auto it = cache.find(key);
    if (it != cache.end()) {
        data = it->second.first;
        return true;
    }
    return false;
}

void RemoteConfigFetcher::setCache(const std::string &key, const std::string &data) {
    std::lock_guard<std::mutex> lock(cacheMutex);
    cache[key] = {data, std::chrono::steady_clock::now()};
}

void RemoteConfigFetcher::setDefaultConfig(const std::string &config) {
    defaultConfig = config;
}

std::string RemoteConfigFetcher::getDefaultConfig() const {
    return defaultConfig;
}

void RemoteConfigFetcher::setFallbackUrls(const std::vector<std::string> &urls) {
    fallbackUrls = urls;
}

HeartbeatSystem::HeartbeatSystem()
    : running(false), alive(false), heartbeatThread(nullptr),
      heartbeatCount(0), interval(30000), timeoutMs(10000),
      serverPort(0) {
    lastHeartbeat = std::chrono::steady_clock::now();
}

HeartbeatSystem::~HeartbeatSystem() {
    stop();
}

void HeartbeatSystem::start(uint32_t intervalMs) {
    if (running) return;
    interval = intervalMs;
    running = true;
    alive = true;
    heartbeatThread = new std::thread(&HeartbeatSystem::heartbeatLoop, this);
}

void HeartbeatSystem::stop() {
    running = false;
    if (heartbeatThread && heartbeatThread->joinable()) {
        heartbeatThread->join();
        delete heartbeatThread;
        heartbeatThread = nullptr;
    }
}

void HeartbeatSystem::setInterval(uint32_t ms) { interval = ms; }

void HeartbeatSystem::sendHeartbeat() {
    std::map<std::string, std::string> headers;
    if (!authToken.empty()) {
        headers["Authorization"] = "Bearer " + authToken;
    }
    headers["X-Heartbeat-Count"] = std::to_string(++heartbeatCount);
    std::string url = "https://" + serverHost + ":" +
                      std::to_string(serverPort) + "/heartbeat";
    auto resp = httpClient.get(url);
    if (resp.success) {
        alive = true;
        lastHeartbeat = std::chrono::steady_clock::now();
        if (onHeartbeat) onHeartbeat();
    } else {
        alive = false;
        if (onFailure) onFailure();
    }
}

bool HeartbeatSystem::isAlive() const {
    return alive;
}

void HeartbeatSystem::setCallback(std::function<void()> cb) { onHeartbeat = cb; }
void HeartbeatSystem::setFailureCallback(std::function<void()> cb) { onFailure = cb; }

uint64_t HeartbeatSystem::getHeartbeatCount() const {
    return heartbeatCount;
}

std::chrono::steady_clock::time_point HeartbeatSystem::getLastHeartbeat() const {
    return lastHeartbeat;
}

void HeartbeatSystem::setTimeout(uint32_t ms) { timeoutMs = ms; }

bool HeartbeatSystem::waitForHeartbeat(uint32_t timeoutMs) {
    std::unique_lock<std::mutex> lock(heartbeatMutex);
    return heartbeatCV.wait_for(lock, std::chrono::milliseconds(timeoutMs),
                                [this]() { return alive; });
}

void HeartbeatSystem::setServerEndpoint(const std::string &host, uint16_t port) {
    serverHost = host;
    serverPort = port;
}

void HeartbeatSystem::setAuthToken(const std::string &token) { authToken = token; }

void HeartbeatSystem::heartbeatLoop() {
    while (running) {
        sendHeartbeat();
        std::this_thread::sleep_for(std::chrono::milliseconds(interval));
    }
}

PacketCrypto::PacketCrypto() : rng(std::random_device{}()) {}

std::vector<uint8_t> PacketCrypto::encryptPacket(const std::vector<uint8_t> &plaintext,
                                                   const std::vector<uint8_t> &key) {
    if (plaintext.empty()) return {};
    std::vector<uint8_t> nonce(crypto_secretbox_NONCEBYTES);
    randombytes_buf(nonce.data(), nonce.size());
    std::vector<uint8_t> ciphertext(plaintext.size() + crypto_secretbox_MACBYTES);
    crypto_secretbox_easy(ciphertext.data(), plaintext.data(), plaintext.size(),
                          nonce.data(), key.data());
    std::vector<uint8_t> result;
    result.insert(result.end(), nonce.begin(), nonce.end());
    result.insert(result.end(), ciphertext.begin(), ciphertext.end());
    return result;
}

std::vector<uint8_t> PacketCrypto::decryptPacket(const std::vector<uint8_t> &ciphertext,
                                                   const std::vector<uint8_t> &key) {
    if (ciphertext.size() < crypto_secretbox_NONCEBYTES + crypto_secretbox_MACBYTES) return {};
    std::vector<uint8_t> nonce(ciphertext.begin(), ciphertext.begin() + crypto_secretbox_NONCEBYTES);
    std::vector<uint8_t> ct(ciphertext.begin() + crypto_secretbox_NONCEBYTES, ciphertext.end());
    std::vector<uint8_t> plaintext(ct.size() - crypto_secretbox_MACBYTES);
    if (crypto_secretbox_open_easy(plaintext.data(), ct.data(), ct.size(),
                                   nonce.data(), key.data()) != 0) {
        return {};
    }
    return plaintext;
}

std::vector<uint8_t> PacketCrypto::signPacket(const std::vector<uint8_t> &data,
                                               const std::vector<uint8_t> &privateKey) {
    std::vector<uint8_t> signature(crypto_sign_BYTES);
    unsigned long long sigLen;
    crypto_sign_detached(signature.data(), &sigLen, data.data(), data.size(),
                         privateKey.data());
    signature.resize(sigLen);
    return signature;
}

bool PacketCrypto::verifyPacket(const std::vector<uint8_t> &data,
                                 const std::vector<uint8_t> &signature,
                                 const std::vector<uint8_t> &publicKey) {
    if (signature.size() != crypto_sign_BYTES) return false;
    return crypto_sign_verify_detached(signature.data(), data.data(), data.size(),
                                       publicKey.data()) == 0;
}

std::vector<uint8_t> PacketCrypto::hashPacket(const std::vector<uint8_t> &data) {
    std::vector<uint8_t> hash(crypto_generichash_BYTES);
    crypto_generichash(hash.data(), hash.size(), data.data(), data.size(), nullptr, 0);
    return hash;
}

std::vector<uint8_t> PacketCrypto::generateKey() {
    std::vector<uint8_t> key(crypto_secretbox_KEYBYTES);
    randombytes_buf(key.data(), key.size());
    return key;
}

std::vector<uint8_t> PacketCrypto::deriveKey(const std::vector<uint8_t> &secret,
                                               const std::vector<uint8_t> &salt) {
    std::vector<uint8_t> key(crypto_secretbox_KEYBYTES);
    crypto_generichash(key.data(), key.size(), secret.data(), secret.size(),
                       salt.data(), salt.size());
    return key;
}

uint32_t PacketCrypto::calculateChecksum(const std::vector<uint8_t> &data) {
    uint32_t crc = 0xFFFFFFFF;
    for (uint8_t b : data) {
        crc = (crc >> 8) ^ CRC32_TABLE[(crc ^ b) & 0xFF];
    }
    return crc ^ 0xFFFFFFFF;
}

PacketHeader PacketCrypto::createHeader(PacketType type, uint32_t bodySize) {
    PacketHeader header;
    header.magic = 0x42554752;
    header.version = 0x0703;
    header.type = static_cast<uint8_t>(type);
    header.flags = 0;
    header.sequence = rng() % UINT32_MAX;
    header.timestamp = static_cast<uint32_t>(
        std::chrono::duration_cast<std::chrono::seconds>(
            std::chrono::system_clock::now().time_since_epoch()).count());
    header.bodySize = bodySize;
    header.checksum = 0;
    memset(header.reserved, 0, sizeof(header.reserved));
    return header;
}

bool PacketCrypto::verifyHeader(const PacketHeader &header) {
    return header.magic == 0x42554752;
}

std::vector<uint8_t> PacketCrypto::serialize(const NetworkPacket &packet) {
    std::vector<uint8_t> data(sizeof(PacketHeader) + packet.body.size());
    memcpy(data.data(), &packet.header, sizeof(PacketHeader));
    memcpy(data.data() + sizeof(PacketHeader), packet.body.data(), packet.body.size());
    return data;
}

NetworkPacket PacketCrypto::deserialize(const std::vector<uint8_t> &data) {
    NetworkPacket packet;
    if (data.size() < sizeof(PacketHeader)) return packet;
    memcpy(&packet.header, data.data(), sizeof(PacketHeader));
    packet.body.assign(data.begin() + sizeof(PacketHeader), data.end());
    return packet;
}

std::vector<uint8_t> PacketCrypto::addPadding(const std::vector<uint8_t> &data) {
    size_t blockSize = 16;
    size_t padding = blockSize - (data.size() % blockSize);
    if (padding == 0) padding = blockSize;
    std::vector<uint8_t> padded(data.size() + padding);
    memcpy(padded.data(), data.data(), data.size());
    memset(padded.data() + data.size(), padding, padding);
    return padded;
}

std::vector<uint8_t> PacketCrypto::removePadding(const std::vector<uint8_t> &data) {
    if (data.empty()) return data;
    size_t padding = data.back();
    if (padding > data.size() || padding > 16) return data;
    return std::vector<uint8_t>(data.begin(), data.end() - padding);
}

std::vector<uint8_t> PacketCrypto::encryptWithNonce(const std::vector<uint8_t> &data,
                                                     const std::vector<uint8_t> &key,
                                                     const std::vector<uint8_t> &nonce) {
    std::vector<uint8_t> ct(data.size() + crypto_secretbox_MACBYTES);
    crypto_secretbox_easy(ct.data(), data.data(), data.size(), nonce.data(), key.data());
    return ct;
}

std::vector<uint8_t> PacketCrypto::decryptWithNonce(const std::vector<uint8_t> &data,
                                                     const std::vector<uint8_t> &key,
                                                     const std::vector<uint8_t> &nonce) {
    if (data.size() < crypto_secretbox_MACBYTES) return {};
    std::vector<uint8_t> pt(data.size() - crypto_secretbox_MACBYTES);
    if (crypto_secretbox_open_easy(pt.data(), data.data(), data.size(),
                                   nonce.data(), key.data()) != 0) {
        return {};
    }
    return pt;
}

void PacketCrypto::incrementNonce(std::vector<uint8_t> &nonce) {
    for (auto it = nonce.rbegin(); it != nonce.rend(); ++it) {
        (*it)++;
        if (*it != 0) break;
    }
}

ProxyManager::ProxyManager() : currentIndex(0), testTimeout(5000) {}
ProxyManager::~ProxyManager() {}

bool ProxyManager::setProxy(ProxyType type, const std::string &host, uint16_t port) {
    clearProxy();
    currentProxy.type = type;
    currentProxy.host = host;
    currentProxy.port = port;
    currentProxy.isActive = true;
    return true;
}

bool ProxyManager::setProxyWithAuth(ProxyType type, const std::string &host,
                                     uint16_t port, const std::string &user,
                                     const std::string &pass) {
    setProxy(type, host, port);
    currentProxy.username = user;
    currentProxy.password = pass;
    return true;
}

void ProxyManager::clearProxy() {
    memset(&currentProxy, 0, sizeof(ProxyEntry));
    currentProxy.isActive = false;
}

bool ProxyManager::hasProxy() const { return currentProxy.isActive; }
ProxyEntry ProxyManager::getCurrentProxy() const { return currentProxy; }

void ProxyManager::setProxyList(const std::vector<ProxyEntry> &proxiesList) {
    std::lock_guard<std::mutex> lock(proxyMutex);
    proxies = proxiesList;
}

void ProxyManager::addProxy(const ProxyEntry &proxy) {
    std::lock_guard<std::mutex> lock(proxyMutex);
    proxies.push_back(proxy);
}

bool ProxyManager::rotateProxy() {
    ProxyEntry next = getNextProxy();
    if (next.isActive) {
        currentProxy = next;
        return true;
    }
    return false;
}

ProxyEntry ProxyManager::getNextProxy() {
    std::lock_guard<std::mutex> lock(proxyMutex);
    if (proxies.empty()) return {};
    currentIndex = (currentIndex + 1) % proxies.size();
    return proxies[currentIndex];
}

std::vector<ProxyEntry> ProxyManager::getActiveProxies() const {
    std::vector<ProxyEntry> active;
    for (auto &p : proxies) {
        if (p.isActive && p.uptime > 50) active.push_back(p);
    }
    return active;
}

void ProxyManager::testProxy(const ProxyEntry &proxy) {
    if (testProxyConnection(proxy)) {
        std::lock_guard<std::mutex> lock(proxyMutex);
        auto it = std::find_if(proxies.begin(), proxies.end(),
                               [&proxy](const ProxyEntry &p) {
                                   return p.host == proxy.host && p.port == proxy.port;
                               });
        if (it != proxies.end()) {
            it->isActive = true;
            it->uptime = 100;
        }
    }
}

void ProxyManager::testAllProxies() {
    for (auto &proxy : proxies) {
        testProxy(proxy);
    }
}

void ProxyManager::removeDeadProxies() {
    std::lock_guard<std::mutex> lock(proxyMutex);
    proxies.erase(std::remove_if(proxies.begin(), proxies.end(),
                                  [](const ProxyEntry &p) { return !p.isActive; }),
                  proxies.end());
}

void ProxyManager::setProxyTestUrl(const std::string &url) { testUrl = url; }
void ProxyManager::setProxyTestTimeout(uint32_t ms) { testTimeout = ms; }

bool ProxyManager::isProxyWorking(const ProxyEntry &proxy) {
    return testProxyConnection(proxy);
}

bool ProxyManager::testProxyConnection(const ProxyEntry &proxy) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) return false;
    struct hostent *server = gethostbyname(proxy.host.c_str());
    if (!server) { close(fd); return false; }
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(proxy.port);
    memcpy(&addr.sin_addr.s_addr, server->h_addr, server->h_length);
    struct timeval tv;
    tv.tv_sec = testTimeout / 1000;
    tv.tv_usec = (testTimeout % 1000) * 1000;
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
    if (::connect(fd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        close(fd);
        return false;
    }
    close(fd);
    return true;
}

std::vector<ProxyEntry> ProxyManager::filterByCountry(const std::string &country) {
    std::vector<ProxyEntry> filtered;
    for (auto &p : proxies) {
        if (p.country == country) filtered.push_back(p);
    }
    return filtered;
}

std::vector<ProxyEntry> ProxyManager::filterByType(ProxyType type) {
    std::vector<ProxyEntry> filtered;
    for (auto &p : proxies) {
        if (p.type == type) filtered.push_back(p);
    }
    return filtered;
}

void ProxyManager::importFromUrl(const std::string &url) {
    HTTPClient client;
    auto resp = client.get(url);
    if (!resp.success) return;
    std::stringstream ss(resp.text);
    std::string line;
    while (std::getline(ss, line)) {
        if (line.empty() || line[0] == '#') continue;
        size_t colonPos = line.find(':');
        if (colonPos != std::string::npos) {
            ProxyEntry entry;
            entry.host = line.substr(0, colonPos);
            entry.port = std::stoi(line.substr(colonPos + 1));
            entry.type = ProxyType::HTTP;
            entry.isActive = true;
            entry.uptime = 100;
            proxies.push_back(entry);
        }
    }
}

void ProxyManager::importFromFile(const std::string &path) {
    std::ifstream file(path);
    std::string line;
    while (std::getline(file, line)) {
        if (line.empty() || line[0] == '#') continue;
        size_t colonPos = line.find(':');
        if (colonPos != std::string::npos) {
            ProxyEntry entry;
            entry.host = line.substr(0, colonPos);
            entry.port = std::stoi(line.substr(colonPos + 1));
            entry.type = ProxyType::HTTP;
            entry.isActive = true;
            proxies.push_back(entry);
        }
    }
}

void ProxyManager::exportToFile(const std::string &path) {
    std::ofstream file(path);
    for (auto &p : proxies) {
        file << p.host << ":" << p.port << std::endl;
    }
}

bool ProxyManager::connectWithProxy(const ProxyEntry &proxy) {
    return testProxyConnection(proxy);
}

NetworkManager::NetworkManager()
    : state(ProtocolState::Disconnected), bytesSent(0), bytesReceived(0),
      packetsSent(0), packetsReceived(0), latency(0.0),
      receiveThread(nullptr), processThread(nullptr), running(false),
      reconnectAttempts(0) {}

NetworkManager::~NetworkManager() {
    shutdown();
}

bool NetworkManager::initialize(const ConnectionConfig &cfg) {
    config = cfg;
    crypto = std::make_unique<EncryptedProtocol>();
    heartbeat = std::make_unique<HeartbeatSystem>();
    packetCrypto = std::make_unique<PacketCrypto>();
    proxyManager = std::make_unique<ProxyManager>();
    configFetcher = std::make_unique<RemoteConfigFetcher>();
    tlsSocket = std::make_unique<TLSSocket>();
    if (!tlsSocket->initialize()) return false;
    if (!crypto->initialize(std::vector<uint8_t>(32, 0))) return false;
    heartBeat->setServerEndpoint(config.primary.host, config.primary.port);
    heartBeat->setInterval(config.heartbeatInterval);
    changeState(ProtocolState::Disconnected);
    return true;
}

void NetworkManager::shutdown() {
    running = false;
    disconnect();
    if (receiveThread && receiveThread->joinable()) {
        receiveThread->join();
        delete receiveThread;
        receiveThread = nullptr;
    }
    if (processThread && processThread->joinable()) {
        processThread->join();
        delete processThread;
        processThread = nullptr;
    }
}

bool NetworkManager::connect() {
    if (tlsSocket->connect(config.primary.host, config.primary.port)) {
        changeState(ProtocolState::Connected);
        running = true;
        receiveThread = new std::thread(&NetworkManager::receiveLoop, this);
        processThread = new std::thread(&NetworkManager::processLoop, this);
        return true;
    }
    changeState(ProtocolState::Error);
    return false;
}

bool NetworkManager::disconnect() {
    tlsSocket->shutdown();
    changeState(ProtocolState::Disconnected);
    return true;
}

bool NetworkManager::send(const NetworkPacket &packet) {
    std::lock_guard<std::mutex> lock(networkMutex);
    sendQueue.push(packet);
    queueCV.notify_one();
    return true;
}

bool NetworkManager::sendEncrypted(const NetworkPacket &packet) {
    std::vector<uint8_t> encData = crypto->encryptPacket(packet);
    NetworkPacket encPacket;
    memcpy(&encPacket.header, encData.data(), sizeof(PacketHeader));
    encPacket.body.assign(encData.begin() + sizeof(PacketHeader), encData.end());
    return send(encPacket);
}

bool NetworkManager::sendWithRetry(const NetworkPacket &packet, int retries) {
    for (int i = 0; i < retries; ++i) {
        if (send(packet)) return true;
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    return false;
}

NetworkPacket NetworkManager::receive() {
    std::lock_guard<std::mutex> lock(networkMutex);
    if (receiveQueue.empty()) return {};
    NetworkPacket packet = receiveQueue.front();
    receiveQueue.pop();
    return packet;
}

bool NetworkManager::hasPendingData() const {
    return !receiveQueue.empty();
}

void NetworkManager::setReceiveCallback(std::function<void(const NetworkPacket&)> cb) {
    onReceive = cb;
}

void NetworkManager::setConnectionCallback(std::function<void(ProtocolState)> cb) {
    onStateChange = cb;
}

void NetworkManager::setErrorCallback(std::function<void(const std::string&)> cb) {
    onError = cb;
}

bool NetworkManager::isConnected() const {
    return state == ProtocolState::Connected;
}

ProtocolState NetworkManager::getState() const {
    return state;
}

std::string NetworkManager::getSessionId() const {
    return sessionId;
}

void NetworkManager::setSessionId(const std::string &id) {
    sessionId = id;
}

uint64_t NetworkManager::getBytesSent() const { return bytesSent; }
uint64_t NetworkManager::getBytesReceived() const { return bytesReceived; }
uint32_t NetworkManager::getPacketsSent() const { return packetsSent; }
uint32_t NetworkManager::getPacketsReceived() const { return packetsReceived; }
double NetworkManager::getLatency() const { return latency; }

void NetworkManager::startHeartbeat() {
    heartBeat->start(config.heartbeatInterval);
}

void NetworkManager::stopHeartbeat() {
    heartBeat->stop();
}

void NetworkManager::enableEncryption(bool enable) {
    config.enableEncryption = enable;
}

void NetworkManager::enableCompression(bool enable) {
    config.enableCompression = enable;
}

void NetworkManager::setAutoReconnect(bool enable) {
    config.autoReconnect = enable;
}

void NetworkManager::setMaxReconnectAttempts(uint32_t attempts) {
    config.maxReconnectAttempts = attempts;
}

void NetworkManager::setServerEndpoint(const std::string &host, uint16_t port) {
    config.primary.host = host;
    config.primary.port = port;
}

void NetworkManager::receiveLoop() {
    while (running && isConnected()) {
        PacketHeader header;
        int n = tlsSocket->recv(reinterpret_cast<uint8_t*>(&header), sizeof(PacketHeader));
        if (n <= 0) {
            if (config.autoReconnect) {
                attemptReconnect();
            }
            break;
        }
        if (header.bodySize > 0) {
            std::vector<uint8_t> body(header.bodySize);
            n = tlsSocket->recv(body.data(), header.bodySize);
            if (n <= 0) break;
            NetworkPacket packet;
            packet.header = header;
            packet.body = body;
            std::lock_guard<std::mutex> lock(networkMutex);
            receiveQueue.push(packet);
            if (onReceive) onReceive(packet);
            bytesReceived += sizeof(PacketHeader) + header.bodySize;
            packetsReceived++;
        }
    }
}

void NetworkManager::processLoop() {
    while (running) {
        std::unique_lock<std::mutex> lock(networkMutex);
        queueCV.wait_for(lock, std::chrono::milliseconds(100),
                         [this]() { return !sendQueue.empty(); });
        while (!sendQueue.empty()) {
            NetworkPacket packet = sendQueue.front();
            sendQueue.pop();
            lock.unlock();
            std::vector<uint8_t> data = packetCrypto->serialize(packet);
            tlsSocket->send(data.data(), data.size());
            bytesSent += data.size();
            packetsSent++;
            lock.lock();
        }
    }
}

bool NetworkManager::attemptReconnect() {
    if (reconnectAttempts >= config.maxReconnectAttempts) return false;
    reconnectAttempts++;
    changeState(ProtocolState::Connecting);
    std::this_thread::sleep_for(std::chrono::milliseconds(config.reconnectDelay));
    if (connect()) {
        reconnectAttempts = 0;
        return true;
    }
    return false;
}

void NetworkManager::changeState(ProtocolState newState) {
    state = newState;
    if (onStateChange) onStateChange(newState);
}

void NetworkManager::updateLatency() {
    auto start = std::chrono::steady_clock::now();
    NetworkPacket ping;
    ping.header = packetCrypto->createHeader(PacketType::Heartbeat, 0);
    send(ping);
    auto end = std::chrono::steady_clock::now();
    latency = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
}

void NetworkManager::handlePacket(const NetworkPacket &packet) {
    switch (static_cast<PacketType>(packet.header.type)) {
        case PacketType::Heartbeat:
            break;
        case PacketType::Config:
            if (configFetcher) {
                std::string configStr(packet.body.begin(), packet.body.end());
                configFetcher->setCache("remote", configStr);
            }
            break;
        default:
            break;
    }
}

}
