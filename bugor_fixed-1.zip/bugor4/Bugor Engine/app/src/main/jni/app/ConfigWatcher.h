#pragma once
#include "Config.h"
#include <string>
#include <thread>
#include <atomic>
#include <functional>
#include <mutex>
#include <condition_variable>

class ConfigWatcher {
    std::thread watchThread;
    std::atomic<bool> running;
    std::atomic<bool> stopFlag;
    std::string lastConfigFile;
    time_t lastModified;
    std::mutex startMutex;
    std::condition_variable cv;
    void WatchLoop(Toggles* tog, Config* cfg);
public:
    ConfigWatcher();
    ~ConfigWatcher();
    void Start(const std::string& path, Toggles* tog, Config* cfg);
    void Stop();
    std::function<void()> OnChanged;
};
