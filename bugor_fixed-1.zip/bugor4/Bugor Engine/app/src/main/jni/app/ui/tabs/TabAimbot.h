#pragma once
#include <imgui.h>

void DrawTabAimbot(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize);
void InitTabAimbot();
void ShutdownTabAimbot();
