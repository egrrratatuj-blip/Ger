#pragma once
#include <string>
#include <vector>
#include <map>
#include <memory>
#include <functional>
#include <atomic>
#include <mutex>
#include <shared_mutex>
#include <thread>
#include <chrono>
#include <fstream>
#include <sstream>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <ctime>
#include <iomanip>
#include <queue>
#include <tuple>
#include <filesystem>
#include <spdlog/spdlog.h>
#include <spdlog/sinks/basic_file_sink.h>
#include <spdlog/sinks/rotating_file_sink.h>
#include <spdlog/sinks/stdout_color_sinks.h>
#include <spdlog/sinks/base_sink.h>
#include <spdlog/async.h>
#include <fmt/format.h>
#include <fmt/chrono.h>

namespace BugorLogging {

enum class LogLevel {
    Trace = 0,
    Debug = 1,
    Info = 2,
    Warn = 3,
    Error = 4,
    Critical = 5,
    Fatal = 6,
    Off = 7
};

enum class LogSinkType {
    Console = 0,
    File = 1,
    RotatingFile = 2,
    Network = 3,
    Remote = 4,
    Crash = 5,
    Android = 6,
    Syslog = 7,
    Callback = 8,
    Encrypted = 9
};

struct LogEntry {
    std::string logger;
    std::string message;
    LogLevel level;
    std::string thread;
    std::string file;
    std::string function;
    int line;
    std::chrono::system_clock::time_point timestamp;
    uint64_t timestamp_ms;
    uint32_t processId;
    uint32_t threadId;
    std::map<std::string, std::string> tags;
    std::vector<uint8_t> extraData;
    std::string formatted;
    bool encrypted;
    bool compressed;
};

struct LogSinkConfig {
    LogSinkType type;
    std::string name;
    std::string path;
    std::string host;
    uint16_t port;
    uint32_t maxFileSize;
    uint32_t maxFiles;
    LogLevel level;
    bool async;
    bool buffered;
    bool encrypted;
    bool compressed;
    std::string format;
    std::string pattern;
    std::string encryptionKey;
    std::map<std::string, std::string> options;
};

struct LoggerConfig {
    std::string name;
    std::string pattern;
    LogLevel level;
    bool async;
    uint32_t queueSize;
    uint32_t flushInterval;
    bool enableBacktrace;
    uint32_t backtraceSize;
    std::vector<LogSinkConfig> sinks;
    std::map<std::string, LogLevel> categoryLevels;
    std::vector<std::string> enabledCategories;
    std::vector<std::string> disabledCategories;
};

class LogFormatter {
public:
    static std::string format(const LogEntry &entry, const std::string &pattern);
    static std::string defaultPattern();
    static std::string detailedPattern();
    static std::string compactPattern();
    static std::string jsonPattern();
    static std::string encryptedPattern();
    static std::string formatTimestamp(const std::chrono::system_clock::time_point &tp, const std::string &format = "%Y-%m-%d %H:%M:%S");
    static std::string formatLevel(LogLevel level);
    static std::string formatThread();
    static std::string formatLocation(const std::string &file, int line, const std::string &function);
    static std::vector<uint8_t> encryptFormat(const LogEntry &entry, const std::vector<uint8_t> &key);
    static LogEntry parseFromString(const std::string &formatted);
    static std::string colorize(const std::string &text, LogLevel level);
    static std::string stripColor(const std::string &text);
};

class LogSink {
public:
    virtual ~LogSink() = default;
    virtual bool initialize(const LogSinkConfig &config) = 0;
    virtual void shutdown() = 0;
    virtual void write(const LogEntry &entry) = 0;
    virtual void flush() = 0;
    virtual bool isInitialized() const = 0;
    virtual LogSinkType getType() const = 0;
    virtual std::string getName() const = 0;
    virtual void setLevel(LogLevel level) = 0;
    virtual LogLevel getLevel() const = 0;
};

class ConsoleSink : public LogSink {
public:
    ConsoleSink();
    ~ConsoleSink() override;
    bool initialize(const LogSinkConfig &config) override;
    void shutdown() override;
    void write(const LogEntry &entry) override;
    void flush() override;
    bool isInitialized() const override;
    LogSinkType getType() const override;
    std::string getName() const override;
    void setLevel(LogLevel level) override;
    LogLevel getLevel() const override;
private:
    LogSinkConfig config;
    bool initialized;
    FILE *output;
    std::mutex writeMutex;
    void writeToConsole(const std::string &formatted, LogLevel level);
};

class FileSink : public LogSink {
public:
    FileSink();
    ~FileSink() override;
    bool initialize(const LogSinkConfig &config) override;
    void shutdown() override;
    void write(const LogEntry &entry) override;
    void flush() override;
    bool isInitialized() const override;
    LogSinkType getType() const override;
    std::string getName() const override;
    void setLevel(LogLevel level) override;
    LogLevel getLevel() const override;
private:
    LogSinkConfig config;
    bool initialized;
    std::ofstream fileStream;
    size_t currentSize;
    std::mutex fileMutex;
    std::string currentPath;
    void rotateFile();
    std::string generateFileName();
    bool openFile(const std::string &path);
    void closeFile();
    size_t getFileSize(const std::string &path);
};

class RotatingFileSink : public LogSink {
public:
    RotatingFileSink();
    ~RotatingFileSink() override;
    bool initialize(const LogSinkConfig &config) override;
    void shutdown() override;
    void write(const LogEntry &entry) override;
    void flush() override;
    bool isInitialized() const override;
    LogSinkType getType() const override;
    std::string getName() const override;
    void setLevel(LogLevel level) override;
    LogLevel getLevel() const override;
private:
    LogSinkConfig config;
    bool initialized;
    std::ofstream fileStream;
    size_t currentSize;
    int currentFileIndex;
    std::mutex fileMutex;
    std::string basePath;
    void rotateFiles();
    std::string getRotationPath(int index);
    void cleanupOldFiles();
    void removeFile(const std::string &path);
};

class NetworkSink : public LogSink {
public:
    NetworkSink();
    ~NetworkSink() override;
    bool initialize(const LogSinkConfig &config) override;
    void shutdown() override;
    void write(const LogEntry &entry) override;
    void flush() override;
    bool isInitialized() const override;
    LogSinkType getType() const override;
    std::string getName() const override;
    void setLevel(LogLevel level) override;
    LogLevel getLevel() const override;
private:
    LogSinkConfig config;
    bool initialized;
    int sock;
    std::mutex networkMutex;
    bool connect();
    void disconnect();
    bool sendData(const std::vector<uint8_t> &data);
};

class RemoteSink : public LogSink {
public:
    RemoteSink();
    ~RemoteSink() override;
    bool initialize(const LogSinkConfig &config) override;
    void shutdown() override;
    void write(const LogEntry &entry) override;
    void flush() override;
    bool isInitialized() const override;
    LogSinkType getType() const override;
    std::string getName() const override;
    void setLevel(LogLevel level) override;
    LogLevel getLevel() const override;
private:
    LogSinkConfig config;
    bool initialized;
    std::string apiEndpoint;
    std::string authToken;
    std::mutex remoteMutex;
    std::queue<LogEntry> pendingEntries;
    std::thread *senderThread;
    std::atomic<bool> running;
    void senderLoop();
    bool sendToServer(const LogEntry &entry);
    bool authenticate();
    std::string buildPayload(const LogEntry &entry);
};

class EncryptedSink : public LogSink {
public:
    EncryptedSink();
    ~EncryptedSink() override;
    bool initialize(const LogSinkConfig &config) override;
    void shutdown() override;
    void write(const LogEntry &entry) override;
    void flush() override;
    bool isInitialized() const override;
    LogSinkType getType() const override;
    std::string getName() const override;
    void setLevel(LogLevel level) override;
    LogLevel getLevel() const override;
private:
    LogSinkConfig config;
    bool initialized;
    std::vector<uint8_t> encryptionKey;
    std::unique_ptr<LogSink> innerSink;
    std::mutex encryptMutex;
    std::vector<uint8_t> encryptData(const std::vector<uint8_t> &data);
    std::vector<uint8_t> decryptData(const std::vector<uint8_t> &data);
};

class CallbackSink : public LogSink {
public:
    CallbackSink();
    ~CallbackSink() override;
    bool initialize(const LogSinkConfig &config) override;
    void shutdown() override;
    void write(const LogEntry &entry) override;
    void flush() override;
    bool isInitialized() const override;
    LogSinkType getType() const override;
    std::string getName() const override;
    void setLevel(LogLevel level) override;
    LogLevel getLevel() const override;
    void setCallback(std::function<void(const LogEntry&)> callback);
private:
    LogSinkConfig config;
    bool initialized;
    std::function<void(const LogEntry&)> callback;
    std::mutex callbackMutex;
};

class LoggingSystem {
public:
    LoggingSystem();
    ~LoggingSystem();
    bool initialize(const std::string &configPath = "");
    void shutdown();
    void log(LogLevel level, const std::string &message);
    void log(LogLevel level, const std::string &logger, const std::string &message);
    void log(LogLevel level, const std::string &logger, const std::string &file, int line, const std::string &function, const std::string &message);
    void log(const LogEntry &entry);
    void trace(const std::string &message);
    void debug(const std::string &message);
    void info(const std::string &message);
    void warn(const std::string &message);
    void error(const std::string &message);
    void critical(const std::string &message);
    void fatal(const std::string &message);
    void flush();
    void flushAll();
    void setLevel(LogLevel level);
    LogLevel getLevel() const;
    void setPattern(const std::string &pattern);
    std::string getPattern() const;
    void addSink(std::shared_ptr<LogSink> sink);
    void removeSink(const std::string &name);
    void removeAllSinks();
    std::vector<std::shared_ptr<LogSink>> getSinks() const;
    void setAsync(bool enable);
    bool isAsync() const;
    void setAsyncQueueSize(uint32_t size);
    void setFlushInterval(uint32_t ms);
    void enableBacktrace(bool enable);
    void setBacktraceSize(uint32_t size);
    void dumpBacktrace();
    void enableCrashHandler(bool enable);
    void enableEncryption(bool enable);
    void setEncryptionKey(const std::vector<uint8_t> &key);
    bool loadConfiguration(const std::string &configPath);
    bool saveConfiguration(const std::string &configPath);
    void registerLogger(const std::string &name, const LoggerConfig &config);
    void unregisterLogger(const std::string &name);
    bool hasLogger(const std::string &name) const;
    std::vector<std::string> getLoggerNames() const;
    void setLoggerLevel(const std::string &logger, LogLevel level);
    LogLevel getLoggerLevel(const std::string &logger) const;
    void setCategoryLevel(const std::string &category, LogLevel level);
    void enableCategory(const std::string &category);
    void disableCategory(const std::string &category);
    bool isCategoryEnabled(const std::string &category) const;
    void startAutoFlush(uint32_t intervalMs);
    void stopAutoFlush();
    bool isAutoFlushEnabled() const;
    uint64_t getLogCount() const;
    uint64_t getErrorCount() const;
    uint64_t getWarningCount() const;
    void resetCounters();
    void clearLogFile(const std::string &path);
    void clearAllLogFiles();
    void setLogPath(const std::string &path);
    std::string getLogPath() const;
    void addRemoteEndpoint(const std::string &host, uint16_t port, const std::string &token = "");
    void removeRemoteEndpoint(const std::string &host, uint16_t port);
    void setRemoteEnabled(bool enable);
    bool isRemoteEnabled() const;
    size_t getQueueSize() const;
    size_t getMaxQueueSize() const;
    void setMaxQueueSize(size_t size);
    void setMaxLogAge(uint32_t hours);
    void enableCompression(bool enable);

private:
    std::string logPath;
    std::string pattern;
    LogLevel globalLevel;
    std::vector<std::shared_ptr<LogSink>> sinks;
    std::map<std::string, LoggerConfig> loggers;
    std::map<std::string, LogLevel> categoryLevels;
    std::vector<std::string> enabledCategories;
    std::vector<std::string> disabledCategories;
    std::atomic<bool> initialized;
    std::atomic<bool> async;
    std::atomic<bool> autoFlushEnabled;
    std::atomic<bool> remoteEnabled;
    std::atomic<bool> encryptionEnabled;
    std::atomic<bool> crashHandlerEnabled;
    std::atomic<bool> compressionEnabled;
    std::atomic<uint64_t> logCount;
    std::atomic<uint64_t> errorCount;
    std::atomic<uint64_t> warningCount;
    uint32_t asyncQueueSize;
    uint32_t flushInterval;
    uint32_t autoFlushInterval;
    uint32_t backtraceSize;
    size_t maxQueueSize;
    uint32_t maxLogAge;
    std::vector<uint8_t> encryptionKey;
    std::thread *autoFlushThread;
    std::thread *asyncWorkerThread;
    mutable std::shared_mutex sinkMutex;
    mutable std::shared_mutex loggerMutex;
    std::mutex queueMutex;
    std::queue<LogEntry> asyncQueue;
    std::condition_variable queueCV;
    std::shared_ptr<spdlog::logger> spdLogger;
    void processAsyncQueue();
    void autoFlushLoop();
    LogEntry createEntry(LogLevel level, const std::string &logger, const std::string &file, int line, const std::string &function, const std::string &message);
    void dispatchToSinks(const LogEntry &entry);
    bool shouldLog(const std::string &logger, LogLevel level) const;
    std::string formatMessage(const LogEntry &entry) const;
};

}
