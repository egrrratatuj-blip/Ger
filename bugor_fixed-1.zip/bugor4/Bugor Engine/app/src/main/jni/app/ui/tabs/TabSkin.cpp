#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "TabSkin.h"
#include "../ui_integration.h"
#include "../../SkinChanger.h"

void DrawTabSkin(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize) {
    (void)dl;
    g_Skin.RefreshSkinList();
    auto& skins = g_Skin.GetSkins();
    if (ImGui::BeginChild("SkinPanel", contentSize, true)) {
        ImGui::Text("Skin Changer v3.0");
        ImGui::Separator();
        for (int i = 0; i < (int)skins.size(); i++) {
            auto& s = skins[i];
            ImGui::PushID(i);
            ImGui::Text("%s [%s]", s.Name.c_str(), s.Category.c_str());
            ImGui::SameLine();
            ImGui::Text("Q:%d W:%.2f", s.Quality, s.Wear);
            ImGui::SameLine();
            if (ImGui::Button("Apply")) g_Skin.ApplySkin(i);
            ImGui::SameLine();
            if (ImGui::Button("Force")) g_Skin.ApplyAllSkins();
            ImGui::PopID();
        }
        ImGui::Separator();
        if (ImGui::Button("Apply All")) g_Skin.ApplyAllSkins();
        ImGui::SameLine();
        if (ImGui::Button("Reset All")) g_Skin.ResetSkins();
    }
    ImGui::EndChild();
}
