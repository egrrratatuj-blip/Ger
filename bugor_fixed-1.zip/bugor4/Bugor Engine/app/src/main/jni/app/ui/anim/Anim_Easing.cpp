#include "Anim_Easing.h"

namespace Easing {

float Linear(float t) {
    return t;
}

float InQuad(float t) {
    return t * t;
}

float OutQuad(float t) {
    return t * (2.0f - t);
}

float InOutQuad(float t) {
    if (t < 0.5f) {
        return 2.0f * t * t;
    }
    return -1.0f + (4.0f - 2.0f * t) * t;
}

float InCubic(float t) {
    return t * t * t;
}

float OutCubic(float t) {
    float p = t - 1.0f;
    return p * p * p + 1.0f;
}

float InOutCubic(float t) {
    if (t < 0.5f) {
        return 4.0f * t * t * t;
    }
    float p = 2.0f * t - 2.0f;
    return 0.5f * p * p * p + 1.0f;
}

float InQuart(float t) {
    return t * t * t * t;
}

float OutQuart(float t) {
    float p = t - 1.0f;
    return 1.0f - p * p * p * p;
}

float InOutQuart(float t) {
    if (t < 0.5f) {
        return 8.0f * t * t * t * t;
    }
    float p = t - 1.0f;
    return 1.0f - 8.0f * p * p * p * p;
}

float InQuint(float t) {
    return t * t * t * t * t;
}

float OutQuint(float t) {
    float p = t - 1.0f;
    return 1.0f + p * p * p * p * p;
}

float InOutQuint(float t) {
    if (t < 0.5f) {
        return 16.0f * t * t * t * t * t;
    }
    float p = 2.0f * t - 2.0f;
    return 0.5f * p * p * p * p * p + 1.0f;
}

float InSine(float t) {
    return 1.0f - cosf(t * M_PI * 0.5f);
}

float OutSine(float t) {
    return sinf(t * M_PI * 0.5f);
}

float InOutSine(float t) {
    return -(cosf(M_PI * t) - 1.0f) * 0.5f;
}

float InExpo(float t) {
    if (t == 0.0f) {
        return 0.0f;
    }
    return powf(2.0f, 10.0f * (t - 1.0f));
}

float OutExpo(float t) {
    if (t == 1.0f) {
        return 1.0f;
    }
    return 1.0f - powf(2.0f, -10.0f * t);
}

float InOutExpo(float t) {
    if (t == 0.0f || t == 1.0f) {
        return t;
    }
    if (t < 0.5f) {
        return powf(2.0f, 20.0f * t - 10.0f) * 0.5f;
    }
    return (2.0f - powf(2.0f, -20.0f * t + 10.0f)) * 0.5f;
}

float InCirc(float t) {
    return 1.0f - sqrtf(1.0f - t * t);
}

float OutCirc(float t) {
    float p = t - 1.0f;
    return sqrtf(1.0f - p * p);
}

float InOutCirc(float t) {
    if (t < 0.5f) {
        return (1.0f - sqrtf(1.0f - 4.0f * t * t)) * 0.5f;
    }
    float p = -2.0f * t + 2.0f;
    return (sqrtf(1.0f - p * p) + 1.0f) * 0.5f;
}

float InElastic(float t) {
    if (t == 0.0f || t == 1.0f) {
        return t;
    }
    float p = t - 1.0f;
    float s = M_PI * 2.0f / 3.0f;
    return -powf(2.0f, 10.0f * p) * sinf((p * 10.0f - 0.75f) * s);
}

float OutElastic(float t) {
    if (t == 0.0f || t == 1.0f) {
        return t;
    }
    float s = M_PI * 2.0f / 3.0f;
    float r = powf(2.0f, -10.0f * t) * sinf((t * 10.0f - 0.75f) * s) + 1.0f;
    if (r < -2.0f) r = -2.0f;
    if (r > 2.0f) r = 2.0f;
    return r;
}

float InOutElastic(float t) {
    if (t == 0.0f || t == 1.0f) {
        return t;
    }
    float s = M_PI * 2.0f / 3.0f;
    if (t < 0.5f) {
        float p = 2.0f * t - 1.0f;
        return -0.5f * powf(2.0f, 10.0f * p) * sinf((p * 10.0f - 0.75f) * s);
    }
    float p = 2.0f * t - 1.0f;
    return 0.5f * powf(2.0f, -10.0f * p) * sinf((p * 10.0f - 0.75f) * s) + 1.0f;
}

float InBack(float t, float overshoot) {
    return t * t * ((overshoot + 1.0f) * t - overshoot);
}

float OutBack(float t, float overshoot) {
    float p = t - 1.0f;
    return p * p * ((overshoot + 1.0f) * p + overshoot) + 1.0f;
}

float InOutBack(float t, float overshoot) {
    float s = overshoot * 1.525f;
    if (t < 0.5f) {
        float p = 2.0f * t;
        return 0.5f * (p * p * ((s + 1.0f) * p - s));
    }
    float p = 2.0f * t - 2.0f;
    return 0.5f * (p * p * ((s + 1.0f) * p + s) + 2.0f);
}

static float BounceOutCalc(float t) {
    if (t < 1.0f / 2.75f) {
        return 7.5625f * t * t;
    }
    if (t < 2.0f / 2.75f) {
        float p = t - 1.5f / 2.75f;
        return 7.5625f * p * p + 0.75f;
    }
    if (t < 2.5f / 2.75f) {
        float p = t - 2.25f / 2.75f;
        return 7.5625f * p * p + 0.9375f;
    }
    float p = t - 2.625f / 2.75f;
    return 7.5625f * p * p + 0.984375f;
}

float InBounce(float t) {
    return 1.0f - BounceOutCalc(1.0f - t);
}

float OutBounce(float t) {
    return BounceOutCalc(t);
}

float InOutBounce(float t) {
    if (t < 0.5f) {
        return (1.0f - BounceOutCalc(1.0f - 2.0f * t)) * 0.5f;
    }
    return (1.0f + BounceOutCalc(2.0f * t - 1.0f)) * 0.5f;
}

float OutElasticBounce(float t) {
    if (t < 0.7f) {
        float p = t / 0.7f;
        float s = M_PI * 2.0f / 3.0f;
        return powf(2.0f, -10.0f * p) * sinf((p * 10.0f - 0.75f) * s) + 1.0f;
    }
    float p = (t - 0.7f) / 0.3f;
    return BounceOutCalc(p);
}

float SoftSpot(float t) {
    return 4.0f * t * (1.0f - t);
}

float Pulse(float t) {
    if (t < 0.5f) {
        float p = t * 2.0f;
        return 0.5f * OutQuad(p);
    }
    float p = (t - 0.5f) * 2.0f;
    return 1.0f - 0.5f * OutQuad(p);
}

float Lerp(float a, float b, float t) {
    return a + (b - a) * t;
}

float LerpEased(float a, float b, float t, float (*easingFunc)(float)) {
    return Lerp(a, b, easingFunc(t));
}

ImVec2 LerpVec2(ImVec2 a, ImVec2 b, float t, float (*easingFunc)(float)) {
    float et = easingFunc(t);
    return ImVec2(a.x + (b.x - a.x) * et, a.y + (b.y - a.y) * et);
}

ImColor LerpColor(ImColor a, ImColor b, float t, float (*easingFunc)(float)) {
    float et = easingFunc(t);
    return ImColor(
        a.Value.x + (b.Value.x - a.Value.x) * et,
        a.Value.y + (b.Value.y - a.Value.y) * et,
        a.Value.z + (b.Value.z - a.Value.z) * et,
        a.Value.w + (b.Value.w - a.Value.w) * et
    );
}

}

float ApplyEasing(float t, int easingType) {
    if (t <= 0.0f) {
        return 0.0f;
    }
    if (t >= 1.0f) {
        return 1.0f;
    }
    switch (easingType) {
        case 0: return Easing::Linear(t);
        case 1: return Easing::InQuad(t);
        case 2: return Easing::OutQuad(t);
        case 3: return Easing::InOutQuad(t);
        case 4: return Easing::InCubic(t);
        case 5: return Easing::OutCubic(t);
        case 6: return Easing::InOutCubic(t);
        case 7: return Easing::InQuart(t);
        case 8: return Easing::OutQuart(t);
        case 9: return Easing::InOutQuart(t);
        case 10: return Easing::InQuint(t);
        case 11: return Easing::OutQuint(t);
        case 12: return Easing::InOutQuint(t);
        case 13: return Easing::InSine(t);
        case 14: return Easing::OutSine(t);
        case 15: return Easing::InOutSine(t);
        case 16: return Easing::InExpo(t);
        case 17: return Easing::OutExpo(t);
        case 18: return Easing::InOutExpo(t);
        case 19: return Easing::InCirc(t);
        case 20: return Easing::OutCirc(t);
        case 21: return Easing::InOutCirc(t);
        case 22: return Easing::InElastic(t);
        case 23: return Easing::OutElastic(t);
        case 24: return Easing::InOutElastic(t);
        case 25: return Easing::InBack(t);
        case 26: return Easing::OutBack(t);
        case 27: return Easing::InOutBack(t);
        case 28: return Easing::InBounce(t);
        case 29: return Easing::OutBounce(t);
        case 30: return Easing::InOutBounce(t);
        case 31: return Easing::OutElasticBounce(t);
        case 32: return Easing::SoftSpot(t);
        case 33: return Easing::Pulse(t);
        default: return Easing::Linear(t);
    }
}

const char* GetEasingName(int easingType) {
    switch (easingType) {
        case 0: return "Linear";
        case 1: return "InQuad";
        case 2: return "OutQuad";
        case 3: return "InOutQuad";
        case 4: return "InCubic";
        case 5: return "OutCubic";
        case 6: return "InOutCubic";
        case 7: return "InQuart";
        case 8: return "OutQuart";
        case 9: return "InOutQuart";
        case 10: return "InQuint";
        case 11: return "OutQuint";
        case 12: return "InOutQuint";
        case 13: return "InSine";
        case 14: return "OutSine";
        case 15: return "InOutSine";
        case 16: return "InExpo";
        case 17: return "OutExpo";
        case 18: return "InOutExpo";
        case 19: return "InCirc";
        case 20: return "OutCirc";
        case 21: return "InOutCirc";
        case 22: return "InElastic";
        case 23: return "OutElastic";
        case 24: return "InOutElastic";
        case 25: return "InBack";
        case 26: return "OutBack";
        case 27: return "InOutBack";
        case 28: return "InBounce";
        case 29: return "OutBounce";
        case 30: return "InOutBounce";
        case 31: return "OutElasticBounce";
        case 32: return "SoftSpot";
        case 33: return "Pulse";
        default: return "Unknown";
    }
}
