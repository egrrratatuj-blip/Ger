#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "TabMisc.h"
#include "../ui_integration.h"
#include "../../MiscFeatures.h"
extern Toggles g_Tog;
extern MiscFeatures g_Misc;

void DrawTabMisc(ImDrawList* dl, ImVec2 contentArea, ImVec2 contentPos) {
    (void)dl;
    (void)contentPos;
    ImGui::BeginChild("TabMiscContent", ImVec2(contentArea.x, contentArea.y), true);

    ImGui::Text("Player");
    ImGui::Checkbox("God Mode", &g_Tog.GodMode);
    ImGui::Checkbox("Infinite Ammo", &g_Tog.InfiniteAmmo);
    ImGui::Checkbox("No Recoil", &g_Tog.NoRecoil);
    ImGui::Checkbox("No Spread", &g_Tog.NoSpread);
    ImGui::Checkbox("Rapid Fire", &g_Tog.RapidFire);
    ImGui::Checkbox("One Hit Kill", &g_Tog.OneHitKill);
    ImGui::Checkbox("Infinite Stamina", &g_Tog.InfiniteStamina);
    ImGui::Checkbox("Infinite Oxygen", &g_Tog.InfiniteOxygen);
    ImGui::Checkbox("No Fall Damage", &g_Tog.NoFallDamage);
    ImGui::Checkbox("No Hunger", &g_Tog.NoHunger);
    ImGui::Checkbox("No Thirst", &g_Tog.NoThirst);

    ImGui::Separator();
    ImGui::Text("Movement");
    ImGui::Checkbox("No Clip", &g_Tog.NoClip);
    ImGui::SliderFloat("Speed Multiplier", &g_Cfg.SpeedMultiplier, 1.0f, 10.0f, "%.1fx");
    ImGui::SliderFloat("Jump Height", &g_Cfg.JumpHeight, 1.0f, 10.0f, "%.1f");
    ImGui::SliderFloat("Gravity", &g_Cfg.Gravity, -10.0f, 10.0f, "%.1f");

    ImGui::Separator();
    ImGui::Text("Visual");
    ImGui::Checkbox("Night Vision", &g_Tog.NightVision);
    ImGui::Checkbox("Thermal Vision", &g_Tog.ThermalVision);
    ImGui::Checkbox("Wireframe", &g_Tog.Wireframe);
    ImGui::Checkbox("Chams", &g_Tog.Chams);
    ImGui::Checkbox("X-Ray", &g_Tog.XRay);

    ImGui::Separator();
    ImGui::Text("World");
    ImGui::SliderFloat("Time", &g_Cfg.TimeOfDay, 0.0f, 24.0f, "%.1f");
    ImGui::SliderInt("Weather", &g_Cfg.Weather, 0, 5);
    ImGui::Checkbox("No Fog", &g_Tog.NoFog);
    ImGui::Checkbox("Day Time", &g_Tog.DayTime);
    ImGui::Checkbox("Clean Screen", &g_Tog.CleanScreen);

    ImGui::Separator();
    ImGui::Text("Auto");
    ImGui::Checkbox("Auto Loot", &g_Tog.AutoLoot);
    ImGui::SliderInt("Loot Radius", &g_Cfg.LootRadius, 1, 50, "%dm");
    ImGui::Checkbox("Auto Pickup", &g_Tog.AutoPickup);
    ImGui::Checkbox("Auto Heal", &g_Tog.AutoHeal);
    ImGui::SliderFloat("Heal %", &g_Cfg.HealPercent, 10.0f, 90.0f, "%.0f%%");
    ImGui::Checkbox("Auto Reload", &g_Tog.AutoReload);
    ImGui::Checkbox("Auto Respawn", &g_Tog.AutoRespawn);
    ImGui::Checkbox("Auto Craft", &g_Tog.AutoCraft);
    ImGui::Checkbox("Auto Farm", &g_Tog.AutoFarm);
    ImGui::SliderInt("Farm Range", &g_Cfg.FarmRange, 1, 100, "%dm");

    ImGui::Separator();
    ImGui::Text("Teleport");
    if (ImGui::Button("Teleport Up 10m")) g_Misc.TeleportUp(10.0f);
    ImGui::SameLine();
    if (ImGui::Button("Teleport Forward 20m")) g_Misc.TeleportForward(20.0f);

    ImGui::Separator();
    ImGui::Text("Exploits");
    if (ImGui::Button("Airstrike")) g_Misc.Airstrike(0, 0, 0);
    ImGui::SameLine();
    static int spawnItemID = 1;
    static int spawnCount = 1;
    ImGui::InputInt("Item ID", &spawnItemID);
    ImGui::InputInt("Count", &spawnCount);
    if (ImGui::Button("Spawn Item")) g_Misc.SpawnItem(spawnItemID, spawnCount);

    ImGui::Separator();
    ImGui::Checkbox("Magic Bullet", &g_Tog.MagicBullet);
    ImGui::Checkbox("Show All on Radar", &g_Tog.ShowAllOnRadar);
    ImGui::SliderFloat("Radar Range", &g_Cfg.RadarRange, 50.0f, 500.0f, "%.0fm");

    if (ImGui::Button("Print LocalPlayer Addr")) {
        uintptr_t addr = g_Misc.FindLocalPlayer();
        LOGI("LocalPlayer: 0x%lX", addr);
    }

    ImGui::EndChild();
}
