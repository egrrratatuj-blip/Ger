#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "../../../../imgui/imgui.h"
#include "../../../../imgui/imgui_internal.h"
#include "../../../../imgui/mycustom/imgui_Custom.h"
#include <string.h>
#include <map>

static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }

bool M_GradientSlider(const char* label, float* value, float min, float max, const char* format, ImColor accent)
{
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImVec2 labelSize = ImGui::CalcTextSize(label, NULL, true);
    const ImVec2 valueLabel = ImGui::CalcTextSize("", NULL, true);

    ImGui::PushID(label);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 4.0f);

    ImVec2 pos = ImGui::GetCursorScreenPos();
    float fullWidth = ImGui::GetContentRegionAvail().x;
    if (fullWidth < 50.0f) fullWidth = 50.0f;

    ImVec2 labelPos(pos.x, pos.y);
    ImGui::RenderText(labelPos, label);

    char buf[64];
    if (format)
        ImFormatString(buf, IM_ARRAYSIZE(buf), format, *value);
    else
        ImFormatString(buf, IM_ARRAYSIZE(buf), "%.1f", *value);

    ImVec2 valSize = ImGui::CalcTextSize(buf);
    ImVec2 valPos(pos.x + fullWidth - valSize.x, pos.y);
    ImGui::RenderText(valPos, buf);

    float trackY = pos.y + labelSize.y + 6.0f;
    float trackHeight = 8.0f;
    float grabberRadius = 7.0f;
    float padding = grabberRadius + 4.0f;
    float trackWidth = fullWidth - padding * 2.0f;
    if (trackWidth < 10.0f) trackWidth = 10.0f;

    ImVec2 trackMin(pos.x + padding, trackY);
    ImVec2 trackMax(pos.x + padding + trackWidth, trackY + trackHeight);

    float t = (*value - min) / (max - min);
    t = ImClamp(t, 0.0f, 1.0f);

    ImColor accent2 = ImColor(255, 100, 50);

    draw->AddRectFilled(trackMin, trackMax, C(ImColor(40, 40, 40)), 4.0f);

    ImVec2 fillMax(trackMin.x + trackWidth * t, trackMax.y);
    if (t > 0.001f)
    {
        draw->AddRectFilledMultiColor(trackMin, fillMax, C(accent), C(accent2), C(accent2), C(accent));
    }

    draw->AddRect(trackMin, trackMax, C(ImColor(60, 60, 60)), 4.0f);

    float grabberX = trackMin.x + trackWidth * t;
    float grabberY = trackY + trackHeight * 0.5f;
    ImVec2 grabberCenter(grabberX, grabberY);

    draw->AddCircleFilled(grabberCenter, grabberRadius + 1.0f, C(ImColor(0, 0, 0, 60)));
    draw->AddCircleFilled(grabberCenter, grabberRadius, C(ImColor(255, 255, 255)));
    draw->AddCircle(grabberCenter, grabberRadius, C(ImColor(200, 200, 200)));

    ImRect trackRect(trackMin, trackMax);
    trackRect.Min.x -= grabberRadius;
    trackRect.Max.x += grabberRadius;
    trackRect.Min.y -= grabberRadius;
    trackRect.Max.y += grabberRadius;

    bool changed = false;
    ImGuiID id = ImGui::GetID(label);

    ImGui::ItemSize(ImVec2(fullWidth, trackY + trackHeight + grabberRadius - pos.y));
    ImGui::ItemAdd(trackRect, id);

    if (ImGui::IsItemHovered() && ImGui::IsMouseClicked(0))
    {
        ImGui::SetActiveID(id, window);
    }

    if (g.ActiveId == id && (ImGui::IsMouseDragging(0) || ImGui::IsMouseDown(0)))
    {
        ImVec2 mousePos = ImGui::GetMousePos();
        float newT = (mousePos.x - trackMin.x) / trackWidth;
        newT = ImClamp(newT, 0.0f, 1.0f);
        float newVal = min + newT * (max - min);
        newVal = ImClamp(newVal, min, max);
        if (*value != newVal)
        {
            *value = newVal;
            changed = true;
        }
    }

    if (g.ActiveId == id && !ImGui::IsMouseDown(0))
    {
        ImGui::ClearActiveID();
    }

    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 6.0f);
    ImGui::PopID();
    return changed;
}

bool M_IntSlider(const char* label, int* value, int min, int max, const char* format, ImColor accent)
{
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImVec2 labelSize = ImGui::CalcTextSize(label, NULL, true);

    ImGui::PushID(label);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 4.0f);

    ImVec2 pos = ImGui::GetCursorScreenPos();
    float fullWidth = ImGui::GetContentRegionAvail().x;
    if (fullWidth < 80.0f) fullWidth = 80.0f;

    ImVec2 labelPos(pos.x, pos.y);
    ImGui::RenderText(labelPos, label);

    char buf[64];
    if (format)
        ImFormatString(buf, IM_ARRAYSIZE(buf), format, *value);
    else
        ImFormatString(buf, IM_ARRAYSIZE(buf), "%d", *value);

    ImVec2 valSize = ImGui::CalcTextSize(buf);
    ImVec2 valPos(pos.x + fullWidth - valSize.x, pos.y);
    ImGui::RenderText(valPos, buf);

    float btnRadius = 9.0f;
    float trackY = pos.y + labelSize.y + 8.0f;
    float trackHeight = 8.0f;
    float grabberRadius = 7.0f;
    float btnArea = btnRadius * 2.0f + 6.0f;
    float padding = 4.0f;
    float trackWidth = fullWidth - btnArea * 2.0f - padding * 2.0f;
    if (trackWidth < 10.0f) trackWidth = 10.0f;

    float leftBtnX = pos.x + btnRadius + 2.0f;
    float leftBtnY = trackY + trackHeight * 0.5f;
    ImVec2 leftBtnCenter(leftBtnX, leftBtnY);

    float trackStartX = pos.x + btnArea + padding;
    float trackEndX = trackStartX + trackWidth;
    ImVec2 trackMin(trackStartX, trackY);
    ImVec2 trackMax(trackEndX, trackY + trackHeight);

    float rightBtnX = pos.x + fullWidth - btnRadius - 2.0f;
    float rightBtnY = trackY + trackHeight * 0.5f;
    ImVec2 rightBtnCenter(rightBtnX, rightBtnY);

    draw->AddCircleFilled(leftBtnCenter, btnRadius, C(ImColor(50, 50, 50)));
    draw->AddCircleFilled(rightBtnCenter, btnRadius, C(ImColor(50, 50, 50)));

    ImVec2 minusTextSize = ImGui::CalcTextSize("-");
    ImVec2 minusPos(leftBtnCenter.x - minusTextSize.x * 0.5f, leftBtnCenter.y - minusTextSize.y * 0.5f);
    draw->AddText(minusPos, C(ImColor(200, 200, 200)), "-");

    ImVec2 plusTextSize = ImGui::CalcTextSize("+");
    ImVec2 plusPos(rightBtnCenter.x - plusTextSize.x * 0.5f, rightBtnCenter.y - plusTextSize.y * 0.5f);
    draw->AddText(plusPos, C(ImColor(200, 200, 200)), "+");

    int range = max - min;
    if (range <= 0) range = 1;
    float t = (float)(*value - min) / (float)range;
    t = ImClamp(t, 0.0f, 1.0f);

    draw->AddRectFilled(trackMin, trackMax, C(ImColor(40, 40, 40)), 4.0f);

    ImVec2 fillMax(trackMin.x + trackWidth * t, trackMax.y);
    if (t > 0.001f)
    {
        draw->AddRectFilled(trackMin, fillMax, C(accent), 4.0f);
    }

    float grabberX = trackMin.x + trackWidth * t;
    float grabberY = trackY + trackHeight * 0.5f;
    ImVec2 grabberCenter(grabberX, grabberY);

    draw->AddCircleFilled(grabberCenter, grabberRadius + 1.0f, C(ImColor(0, 0, 0, 60)));
    draw->AddCircleFilled(grabberCenter, grabberRadius, C(ImColor(255, 255, 255)));
    draw->AddCircle(grabberCenter, grabberRadius, C(ImColor(200, 200, 200)));

    ImRect leftBtnRect(ImVec2(leftBtnCenter.x - btnRadius, leftBtnCenter.y - btnRadius),
                       ImVec2(leftBtnCenter.x + btnRadius, leftBtnCenter.y + btnRadius));
    ImRect rightBtnRect(ImVec2(rightBtnCenter.x - btnRadius, rightBtnCenter.y - btnRadius),
                        ImVec2(rightBtnCenter.x + btnRadius, rightBtnCenter.y + btnRadius));

    ImRect trackRect(trackMin, trackMax);
    trackRect.Min.x -= grabberRadius;
    trackRect.Max.x += grabberRadius;
    trackRect.Min.y -= grabberRadius;
    trackRect.Max.y += grabberRadius;

    bool changed = false;
    ImGuiID id = ImGui::GetID(label);
    ImGuiID minusId = ImGui::GetID("_minus");
    ImGuiID plusId = ImGui::GetID("_plus");

    ImGui::ItemSize(ImVec2(fullWidth, trackY + trackHeight + grabberRadius - pos.y));
    ImGui::ItemAdd(trackRect, id);
    ImGui::ItemAdd(leftBtnRect, minusId);
    ImGui::ItemAdd(rightBtnRect, plusId);

    if (ImGui::IsItemHovered() && ImGui::IsMouseClicked(0))
    {
        ImGui::SetActiveID(id, window);
    }

    ImVec2 mousePos = ImGui::GetMousePos();
    if (leftBtnRect.Contains(mousePos) && ImGui::IsMouseClicked(0))
    {
        if (*value > min) { *value = *value - 1; changed = true; }
    }
    if (rightBtnRect.Contains(mousePos) && ImGui::IsMouseClicked(0))
    {
        if (*value < max) { *value = *value + 1; changed = true; }
    }

    if (g.ActiveId == id && (ImGui::IsMouseDragging(0) || ImGui::IsMouseDown(0)))
    {
        mousePos = ImGui::GetMousePos();
        float newT = (mousePos.x - trackMin.x) / trackWidth;
        newT = ImClamp(newT, 0.0f, 1.0f);
        int newVal = min + (int)(newT * range + 0.5f);
        newVal = ImClamp(newVal, min, max);
        if (*value != newVal)
        {
            *value = newVal;
            changed = true;
        }
    }

    if (g.ActiveId == id && !ImGui::IsMouseDown(0))
    {
        ImGui::ClearActiveID();
    }

    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 6.0f);
    ImGui::PopID();
    return changed;
}

bool M_RangeSlider(const char* label, float* minVal, float* maxVal, float absMin, float absMax, const char* format, ImColor accent)
{
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGuiContext& g = *GImGui;
    ImGui::PushID(label);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 4.0f);

    ImVec2 pos = ImGui::GetCursorScreenPos();
    float fullWidth = ImGui::GetContentRegionAvail().x;
    if (fullWidth < 80.0f) fullWidth = 80.0f;

    char minBuf[64], maxBuf[64];
    if (format)
    {
        ImFormatString(minBuf, IM_ARRAYSIZE(minBuf), format, *minVal);
        ImFormatString(maxBuf, IM_ARRAYSIZE(maxBuf), format, *maxVal);
    }
    else
    {
        ImFormatString(minBuf, IM_ARRAYSIZE(minBuf), "%.0f", *minVal);
        ImFormatString(maxBuf, IM_ARRAYSIZE(maxBuf), "%.0f", *maxVal);
    }

    ImVec2 labelSize = ImGui::CalcTextSize(label, NULL, true);
    ImVec2 minLabelSize = ImGui::CalcTextSize(minBuf);
    ImVec2 maxLabelSize = ImGui::CalcTextSize(maxBuf);

    ImVec2 labelPos(pos.x, pos.y);
    ImGui::RenderText(labelPos, label);

    float valY = pos.y + labelSize.y + 4.0f;
    ImVec2 minValPos(pos.x, valY);
    ImVec2 maxValPos(pos.x + fullWidth - maxLabelSize.x, valY);
    ImGui::RenderText(minValPos, minBuf);
    ImGui::RenderText(maxValPos, maxBuf);

    float trackY = valY + ImMax(minLabelSize.y, maxLabelSize.y) + 4.0f;
    float trackHeight = 8.0f;
    float grabberRadius = 7.0f;
    float padding = grabberRadius + 4.0f;
    float trackWidth = fullWidth - padding * 2.0f;
    if (trackWidth < 10.0f) trackWidth = 10.0f;

    ImVec2 trackMin(pos.x + padding, trackY);
    ImVec2 trackMax(pos.x + padding + trackWidth, trackY + trackHeight);

    float range = absMax - absMin;
    if (range <= 0.0f) range = 1.0f;

    float tMin = (*minVal - absMin) / range;
    float tMax = (*maxVal - absMin) / range;
    tMin = ImClamp(tMin, 0.0f, 1.0f);
    tMax = ImClamp(tMax, 0.0f, 1.0f);

    draw->AddRectFilled(trackMin, trackMax, C(ImColor(40, 40, 40)), 4.0f);

    ImVec2 fillMin(trackMin.x + trackWidth * tMin, trackY);
    ImVec2 fillMax(trackMin.x + trackWidth * tMax, trackY + trackHeight);
    if (tMax > tMin)
    {
        draw->AddRectFilled(fillMin, fillMax, C(accent), 4.0f);
    }

    draw->AddRect(trackMin, trackMax, C(ImColor(60, 60, 60)), 4.0f);

    float grabberMinX = trackMin.x + trackWidth * tMin;
    float grabberMaxX = trackMin.x + trackWidth * tMax;
    float grabberY = trackY + trackHeight * 0.5f;

    ImVec2 gMinCenter(grabberMinX, grabberY);
    ImVec2 gMaxCenter(grabberMaxX, grabberY);

    draw->AddCircleFilled(gMinCenter, grabberRadius + 1.0f, C(ImColor(0, 0, 0, 60)));
    draw->AddCircleFilled(gMinCenter, grabberRadius, C(ImColor(255, 255, 255)));
    draw->AddCircle(gMinCenter, grabberRadius, C(ImColor(200, 200, 200)));

    draw->AddCircleFilled(gMaxCenter, grabberRadius + 1.0f, C(ImColor(0, 0, 0, 60)));
    draw->AddCircleFilled(gMaxCenter, grabberRadius, C(ImColor(255, 255, 255)));
    draw->AddCircle(gMaxCenter, grabberRadius, C(ImColor(200, 200, 200)));

    ImRect trackRect(trackMin, trackMax);
    trackRect.Min.x -= grabberRadius;
    trackRect.Max.x += grabberRadius;
    trackRect.Min.y -= grabberRadius;
    trackRect.Max.y += grabberRadius;

    ImRect gMinRect(ImVec2(gMinCenter.x - grabberRadius - 2.0f, gMinCenter.y - grabberRadius - 2.0f),
                    ImVec2(gMinCenter.x + grabberRadius + 2.0f, gMinCenter.y + grabberRadius + 2.0f));
    ImRect gMaxRect(ImVec2(gMaxCenter.x - grabberRadius - 2.0f, gMaxCenter.y - grabberRadius - 2.0f),
                    ImVec2(gMaxCenter.x + grabberRadius + 2.0f, gMaxCenter.y + grabberRadius + 2.0f));

    *minVal = ImClamp(*minVal, absMin, *maxVal);
    *maxVal = ImClamp(*maxVal, *minVal, absMax);

    bool changed = false;
    enum DragType { DRAG_NONE, DRAG_MIN, DRAG_MAX };
    DragType dragType = DRAG_NONE;
    ImGuiID id = ImGui::GetID(label);

    ImGui::ItemSize(ImVec2(fullWidth, trackY + trackHeight + grabberRadius - pos.y));
    ImGui::ItemAdd(trackRect, id);

    if (ImGui::IsMouseClicked(0))
    {
        ImVec2 mp = ImGui::GetMousePos();
        if (gMinRect.Contains(mp))
        {
            ImGui::SetActiveID(id, window);
            dragType = DRAG_MIN;
        }
        else if (gMaxRect.Contains(mp))
        {
            ImGui::SetActiveID(id, window);
            dragType = DRAG_MAX;
        }
        else if (trackRect.Contains(mp))
        {
            ImGui::SetActiveID(id, window);
            float clickT = (mp.x - trackMin.x) / trackWidth;
            clickT = ImClamp(clickT, 0.0f, 1.0f);
            float clickVal = absMin + clickT * range;
            float distMin = ImAbs(clickVal - *minVal);
            float distMax = ImAbs(clickVal - *maxVal);
            dragType = (distMin < distMax) ? DRAG_MIN : DRAG_MAX;
        }
        else
        {
            dragType = DRAG_NONE;
        }
    }

    if (g.ActiveId == id && (ImGui::IsMouseDragging(0) || ImGui::IsMouseDown(0)))
    {
        ImVec2 mp = ImGui::GetMousePos();
        float newT = (mp.x - trackMin.x) / trackWidth;
        newT = ImClamp(newT, 0.0f, 1.0f);
        float newVal = absMin + newT * range;
        newVal = ImClamp(newVal, absMin, absMax);

        if (dragType == DRAG_MIN)
        {
            newVal = ImMin(newVal, *maxVal);
            if (*minVal != newVal) { *minVal = newVal; changed = true; }
        }
        else if (dragType == DRAG_MAX)
        {
            newVal = ImMax(newVal, *minVal);
            if (*maxVal != newVal) { *maxVal = newVal; changed = true; }
        }
    }

    if (g.ActiveId == id && !ImGui::IsMouseDown(0))
    {
        ImGui::ClearActiveID();
        dragType = DRAG_NONE;
    }

    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 6.0f);
    ImGui::PopID();
    return changed;
}

bool M_KnobDial(const char* label, float* value, float min, float max, const char* format, ImColor accent)
{
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGuiContext& g = *GImGui;
    ImGui::PushID(label);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 4.0f);

    float dialRadius = 32.0f;
    float dialDiameter = dialRadius * 2.0f;
    float startAngle = -135.0f * IM_PI / 180.0f;
    float endAngle = 135.0f * IM_PI / 180.0f;
    float arcRange = endAngle - startAngle;

    ImVec2 pos = ImGui::GetCursorScreenPos();
    float fullWidth = ImGui::GetContentRegionAvail().x;
    if (fullWidth < dialDiameter + 10.0f) fullWidth = dialDiameter + 10.0f;

    float centerX = pos.x + fullWidth * 0.5f;
    float centerY = pos.y + dialRadius + 4.0f;
    ImVec2 center(centerX, centerY);

    float t = (*value - min) / (max - min);
    t = ImClamp(t, 0.0f, 1.0f);
    float angle = startAngle + t * arcRange;

    draw->AddCircleFilled(center, dialRadius, C(ImColor(30, 30, 30)), 48);
    draw->AddCircle(center, dialRadius, C(ImColor(60, 60, 60)), 48);

    float outerR = dialRadius + 6.0f;
    int numTicks = 12;
    for (int i = 0; i < numTicks; i++)
    {
        float tickAngle = startAngle + (float)i / (float)(numTicks - 1) * arcRange;
        float tickInner = dialRadius - 6.0f;
        float tickOuter = dialRadius - 2.0f;
        ImVec2 inner = ImVec2(center.x + cosf(tickAngle) * tickInner, center.y + sinf(tickAngle) * tickInner);
        ImVec2 outer = ImVec2(center.x + cosf(tickAngle) * tickOuter, center.y + sinf(tickAngle) * tickOuter);
        ImColor tickColor = (i <= (int)(t * (numTicks - 1))) ? accent : ImColor(60, 60, 60);
        draw->AddLine(inner, outer, C(tickColor), 1.5f);
    }

    int arcSegments = 48;
    float arcRadius = dialRadius - 4.0f;
    ImVec2 arcStart(center.x + cosf(startAngle) * arcRadius, center.y + sinf(startAngle) * arcRadius);
    ImVec2 arcEnd(center.x + cosf(angle) * arcRadius, center.y + sinf(angle) * arcRadius);
    draw->PathLineTo(center);
    draw->PathArcTo(&center, arcRadius, startAngle, angle, arcSegments);
    draw->PathLineTo(center);
    draw->PathFillConvex(C(ImColor(accent.Value.x, accent.Value.y, accent.Value.z, 0.3f)));

    draw->PathClear();
    draw->PathArcTo(&center, arcRadius, startAngle, angle, arcSegments);
    draw->PathStroke(C(accent), false, 3.0f);

    ImVec2 pointer(center.x + cosf(angle) * (dialRadius - 8.0f), center.y + sinf(angle) * (dialRadius - 8.0f));
    draw->AddCircleFilled(center, 5.0f, C(accent));
    draw->AddLine(center, pointer, C(accent), 2.5f);

    draw->AddCircleFilled(center, dialRadius - 12.0f, C(ImColor(20, 20, 20)), 24);

    char buf[64];
    if (format)
        ImFormatString(buf, IM_ARRAYSIZE(buf), format, *value);
    else
        ImFormatString(buf, IM_ARRAYSIZE(buf), "%.0f", *value);
    ImVec2 textSize = ImGui::CalcTextSize(buf);
    ImVec2 textPos(center.x - textSize.x * 0.5f, center.y - textSize.y * 0.5f);
    draw->AddText(textPos, C(ImColor(220, 220, 220)), buf);

    ImVec2 labelSize = ImGui::CalcTextSize(label);
    ImVec2 labelPos(pos.x + (fullWidth - labelSize.x) * 0.5f, centerY + dialRadius + 6.0f);
    draw->AddText(labelPos, C(ImColor(160, 160, 160)), label);

    ImRect dialRect(ImVec2(center.x - dialRadius - 4.0f, center.y - dialRadius - 4.0f),
                    ImVec2(center.x + dialRadius + 4.0f, center.y + dialRadius + 4.0f));

    bool changed = false;
    ImGuiID id = ImGui::GetID(label);

    ImGui::ItemSize(ImVec2(fullWidth, centerY + dialRadius + labelSize.y + 10.0f - pos.y));
    ImGui::ItemAdd(dialRect, id);

    if (ImGui::IsItemHovered() && ImGui::IsMouseClicked(0))
    {
        ImGui::SetActiveID(id, window);
    }

    if (g.ActiveId == id && (ImGui::IsMouseDragging(0) || ImGui::IsMouseDown(0)))
    {
        ImVec2 mouseDelta = ImGui::GetMouseDragDelta(0);
        float dragSensitivity = 0.005f;
        float delta = mouseDelta.y * -dragSensitivity;
        float newVal = *value + delta * (max - min);
        newVal = ImClamp(newVal, min, max);
        if (*value != newVal)
        {
            *value = newVal;
            changed = true;
        }
        ImGui::ResetMouseDragDelta(0);
    }

    if (g.ActiveId == id && !ImGui::IsMouseDown(0))
    {
        ImGui::ClearActiveID();
    }

    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 6.0f);
    ImGui::PopID();
    return changed;
}

bool M_DropdownSelect(const char* label, int* selected, const char** items, int count, ImColor accent)
{
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGuiContext& g = *GImGui;
    ImGui::PushID(label);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 4.0f);

    ImVec2 pos = ImGui::GetCursorScreenPos();
    float fullWidth = ImGui::GetContentRegionAvail().x;
    if (fullWidth < 80.0f) fullWidth = 80.0f;

    ImVec2 labelSize = ImGui::CalcTextSize(label);
    ImGui::RenderText(ImVec2(pos.x, pos.y), label);

    ImGuiID id = ImGui::GetID(label);
    struct DropdownState {
        bool isOpen;
        char filterBuf[128];
    };
    static std::map<ImGuiID, DropdownState> s_dropdownStates;
    auto stateIt = s_dropdownStates.find(id);
    if (stateIt == s_dropdownStates.end()) {
        stateIt = s_dropdownStates.emplace(id, DropdownState()).first;
    }
    bool isOpen = stateIt->second.isOpen;
    char filterBuf[128];
    memcpy(filterBuf, stateIt->second.filterBuf, 128);
    float boxY = pos.y + labelSize.y + 4.0f;
    float boxHeight = 30.0f;
    ImVec2 boxMin(pos.x, boxY);
    ImVec2 boxMax(pos.x + fullWidth, boxY + boxHeight);

    const char* currentText = (*selected >= 0 && *selected < count) ? items[*selected] : "";
    ImVec2 textSize = ImGui::CalcTextSize(currentText);
    ImVec2 textPos(boxMin.x + 8.0f, boxMin.y + (boxHeight - textSize.y) * 0.5f);

    ImColor bgColor = isOpen ? ImColor(50, 50, 50) : ImColor(35, 35, 35);
    draw->AddRectFilled(boxMin, boxMax, C(bgColor), 4.0f);
    draw->AddRect(boxMin, boxMax, C(isOpen ? accent : ImColor(60, 60, 60)), 4.0f);
    draw->AddText(textPos, C(ImColor(200, 200, 200)), currentText);

    float chevronSize = 8.0f;
    ImVec2 chevronCenter(boxMax.x - 16.0f, boxMin.y + boxHeight * 0.5f);
    float chevronAngle = isOpen ? IM_PI : 0.0f;
    ImVec2 c1(chevronCenter.x - chevronSize * cosf(chevronAngle) * 0.5f,
              chevronCenter.y - chevronSize * 0.5f);
    ImVec2 c2(chevronCenter.x + chevronSize * 0.5f,
              chevronCenter.y + chevronSize * 0.5f);
    ImVec2 c3(chevronCenter.x - chevronSize * 0.5f,
              chevronCenter.y + chevronSize * 0.5f);
    if (isOpen)
    {
        draw->AddTriangleFilled(c2, c1, c3, C(ImColor(200, 200, 200)));
    }
    else
    {
        draw->AddTriangleFilled(c1, c2, c3, C(ImColor(200, 200, 200)));
    }

    ImRect boxRect(boxMin, boxMax);

    ImGui::ItemSize(ImVec2(fullWidth, boxMax.y - pos.y));
    ImGui::ItemAdd(boxRect, id);

    if (ImGui::IsItemHovered() && ImGui::IsMouseClicked(0))
    {
        if (!isOpen) { isOpen = true; filterBuf[0] = 0; }
        else { isOpen = false; }
    }

    ImVec2 mp = ImGui::GetMousePos();
    if (isOpen && ImGui::IsMouseClicked(0) && !boxRect.Contains(mp))
    {
        float dropItemHeight = 26.0f;
        int maxVisible = 8;
        int visibleCount = (count < maxVisible) ? count : maxVisible;
        float dropHeight = visibleCount * dropItemHeight;
        float screenBottom = ImGui::GetIO().DisplaySize.y;
        float maxDropY = boxMax.y + dropHeight;
        if (maxDropY > screenBottom - 4.0f)
            maxDropY = screenBottom - 4.0f;
        float actualDropH = maxDropY - boxMax.y;
        if (actualDropH < 0.0f) actualDropH = 0.0f;
        ImRect dropRect(ImVec2(boxMin.x, boxMax.y), ImVec2(boxMax.x, boxMax.y + actualDropH));
        if (!dropRect.Contains(mp))
        {
            isOpen = false;
        }
    }

    bool changed = false;
    if (isOpen)
    {
        int maxVisible = 8;
        int scrollOffset = 0;
        int visibleCount = (count < maxVisible) ? count : maxVisible;
        float itemHeight = 26.0f;

        int filteredCount = 0;
        int* filteredIndices = (int*)ImGui::MemAlloc(sizeof(int) * count);
        for (int i = 0; i < count; i++)
        {
            bool match = true;
            if (filterBuf[0] != 0)
            {
                const char* item = items[i];
                match = false;
                while (*item)
                {
                    const char* f = filterBuf;
                    const char* s = item;
                    while (*s && *f && ImToUpper(*s) == ImToUpper(*f)) { s++; f++; }
                    if (!*f) { match = true; break; }
                    item++;
                }
            }
            if (match) { filteredIndices[filteredCount++] = i; }
        }

        float dropHeight = (filteredCount < maxVisible ? filteredCount : maxVisible) * itemHeight;
        if (dropHeight < 0.0f) dropHeight = 0.0f;

        float screenBottom = ImGui::GetIO().DisplaySize.y;
        float maxDropY = boxMax.y + dropHeight;
        if (maxDropY > screenBottom - 4.0f)
            maxDropY = screenBottom - 4.0f;
        float clampedDropHeight = maxDropY - boxMax.y;
        if (clampedDropHeight < 0.0f) clampedDropHeight = 0.0f;

        ImVec2 dropMin(boxMin.x, boxMax.y);
        ImVec2 dropMax(boxMax.x, boxMax.y + clampedDropHeight);

        draw->AddRectFilled(dropMin, dropMax, C(ImColor(40, 40, 40)), 4.0f);
        draw->AddRect(dropMin, dropMax, C(ImColor(60, 60, 60)), 4.0f);

        ImGui::SetCursorScreenPos(ImVec2(dropMin.x + 4.0f, dropMin.y + 2.0f));

        int maxDrawCount = (int)(clampedDropHeight / itemHeight);
        if (maxDrawCount > filteredCount) maxDrawCount = filteredCount;

        for (int i = 0; i < maxDrawCount; i++)
        {
            int idx = filteredIndices[i];
            ImVec2 itemMin(dropMin.x, dropMin.y + i * itemHeight);
            ImVec2 itemMax(dropMax.x, dropMin.y + (i + 1) * itemHeight);
            ImRect itemRect(itemMin, itemMax);

            bool hovered = itemRect.Contains(ImGui::GetMousePos());
            if (hovered)
            {
                draw->AddRectFilled(itemMin, itemMax, C(ImColor(60, 60, 60)), 0.0f);
            }
            if (idx == *selected)
            {
                draw->AddRectFilled(itemMin, itemMax, C(ImColor(accent.Value.x, accent.Value.y, accent.Value.z, 0.25f)), 0.0f);
            }

            ImVec2 itemTextPos(itemMin.x + 8.0f, itemMin.y + (itemHeight - ImGui::CalcTextSize(items[idx]).y) * 0.5f);
            draw->AddText(itemTextPos, C(ImColor(200, 200, 200)), items[idx]);

            if (hovered && ImGui::IsMouseClicked(0))
            {
                if (*selected != idx) { *selected = idx; changed = true; }
                isOpen = false;
            }
        }

        ImGui::MemFree(filteredIndices);

        ImGui::SetCursorScreenPos(ImVec2(boxMin.x, dropMax.y));
    }

    DropdownState& ds = stateIt->second;
    ds.isOpen = isOpen;
    memcpy(ds.filterBuf, filterBuf, 128);

    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 6.0f);
    ImGui::PopID();
    return changed;
}

bool M_ColorSlider(const char* label, float* value, ImColor colorA, ImColor colorB, ImColor accent)
{
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImVec2 labelSize = ImGui::CalcTextSize(label, NULL, true);

    ImGui::PushID(label);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 4.0f);

    ImVec2 pos = ImGui::GetCursorScreenPos();
    float fullWidth = ImGui::GetContentRegionAvail().x;
    if (fullWidth < 50.0f) fullWidth = 50.0f;

    ImVec2 labelPos(pos.x, pos.y);
    ImGui::RenderText(labelPos, label);

    char buf[64];
    ImFormatString(buf, IM_ARRAYSIZE(buf), "%.2f", *value);
    ImVec2 valSize = ImGui::CalcTextSize(buf);
    ImVec2 valPos(pos.x + fullWidth - valSize.x, pos.y);
    ImGui::RenderText(valPos, buf);

    float trackY = pos.y + labelSize.y + 6.0f;
    float trackHeight = 10.0f;
    float grabberRadius = 8.0f;
    float padding = grabberRadius + 4.0f;
    float trackWidth = fullWidth - padding * 2.0f;
    if (trackWidth < 10.0f) trackWidth = 10.0f;

    ImVec2 trackMin(pos.x + padding, trackY);
    ImVec2 trackMax(pos.x + padding + trackWidth, trackY + trackHeight);

    float t = ImClamp(*value, 0.0f, 1.0f);

    int gradSteps = (int)trackWidth / 2;
    if (gradSteps < 2) gradSteps = 2;
    for (int i = 0; i < gradSteps; i++)
    {
        float f1 = (float)i / (float)(gradSteps - 1);
        float f2 = (float)(i + 1) / (float)(gradSteps - 1);
        if (f2 > 1.0f) f2 = 1.0f;

        ImColor c1, c2;
        c1.Value.x = colorA.Value.x + (colorB.Value.x - colorA.Value.x) * f1;
        c1.Value.y = colorA.Value.y + (colorB.Value.y - colorA.Value.y) * f1;
        c1.Value.z = colorA.Value.z + (colorB.Value.z - colorA.Value.z) * f1;
        c1.Value.w = colorA.Value.w + (colorB.Value.w - colorA.Value.w) * f1;

        c2.Value.x = colorA.Value.x + (colorB.Value.x - colorA.Value.x) * f2;
        c2.Value.y = colorA.Value.y + (colorB.Value.y - colorA.Value.y) * f2;
        c2.Value.z = colorA.Value.z + (colorB.Value.z - colorA.Value.z) * f2;
        c2.Value.w = colorA.Value.w + (colorB.Value.w - colorA.Value.w) * f2;

        float x1 = trackMin.x + (float)i / (float)(gradSteps - 1) * trackWidth;
        float x2 = trackMin.x + (float)(i + 1) / (float)(gradSteps - 1) * trackWidth;
        ImVec2 rMin(x1, trackMin.y);
        ImVec2 rMax(x2, trackMax.y);
        draw->AddRectFilledMultiColor(rMin, rMax, C(c1), C(c2), C(c2), C(c1));
    }

    draw->AddRect(trackMin, trackMax, C(ImColor(60, 60, 60)), 2.0f);

    float grabberX = trackMin.x + trackWidth * t;
    float grabberY = trackY + trackHeight * 0.5f;
    ImVec2 grabberCenter(grabberX, grabberY);

    ImColor currentColor;
    currentColor.Value.x = colorA.Value.x + (colorB.Value.x - colorA.Value.x) * t;
    currentColor.Value.y = colorA.Value.y + (colorB.Value.y - colorA.Value.y) * t;
    currentColor.Value.z = colorA.Value.z + (colorB.Value.z - colorA.Value.z) * t;
    currentColor.Value.w = 1.0f;

    draw->AddCircleFilled(grabberCenter, grabberRadius + 1.0f, C(ImColor(0, 0, 0, 80)));
    draw->AddCircleFilled(grabberCenter, grabberRadius - 1.0f, C(currentColor));
    draw->AddCircle(grabberCenter, grabberRadius, C(ImColor(220, 220, 220)));

    ImRect trackRect(trackMin, trackMax);
    trackRect.Min.x -= grabberRadius;
    trackRect.Max.x += grabberRadius;
    trackRect.Min.y -= grabberRadius;
    trackRect.Max.y += grabberRadius;

    bool changed = false;
    ImGuiID id = ImGui::GetID(label);

    ImGui::ItemSize(ImVec2(fullWidth, trackY + trackHeight + grabberRadius - pos.y));
    ImGui::ItemAdd(trackRect, id);

    if (ImGui::IsItemHovered() && ImGui::IsMouseClicked(0))
    {
        ImGui::SetActiveID(id, window);
    }

    if (g.ActiveId == id && (ImGui::IsMouseDragging(0) || ImGui::IsMouseDown(0)))
    {
        ImVec2 mousePos = ImGui::GetMousePos();
        float newT = (mousePos.x - trackMin.x) / trackWidth;
        newT = ImClamp(newT, 0.0f, 1.0f);
        if (*value != newT)
        {
            *value = newT;
            changed = true;
        }
    }

    if (g.ActiveId == id && !ImGui::IsMouseDown(0))
    {
        ImGui::ClearActiveID();
    }

    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 8.0f);
    ImGui::PopID();
    return changed;
}

bool M_MultiSlider(const char* label, float* values[], int count, float min, float max, ImColor* colors, const char** names, ImColor accent)
{
    ImDrawList* draw = ImGui::GetWindowDrawList();
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGuiContext& g = *GImGui;
    ImGui::PushID(label);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 4.0f);

    ImVec2 pos = ImGui::GetCursorScreenPos();
    float fullWidth = ImGui::GetContentRegionAvail().x;
    if (fullWidth < 80.0f) fullWidth = 80.0f;

    ImVec2 labelSize = ImGui::CalcTextSize(label);
    ImGui::RenderText(ImVec2(pos.x, pos.y), label);

    float range = max - min;
    if (range <= 0.0f) range = 1.0f;

    float barHeight = 18.0f;
    float barSpacing = 4.0f;
    float labelWidth = 60.0f;
    float barStartX = pos.x + labelWidth;
    float barWidth = fullWidth - labelWidth;
    if (barWidth < 20.0f) barWidth = 20.0f;

    float barsStartY = pos.y + labelSize.y + 6.0f;

    ImGuiID id = ImGui::GetID(label);

    bool changed = false;
    int activeBar = -1;
    int* pActiveBar = &activeBar;

    for (int i = 0; i < count; i++)
    {
        float barY = barsStartY + i * (barHeight + barSpacing);
        ImVec2 barMin(barStartX, barY);
        ImVec2 barMax(barStartX + barWidth, barY + barHeight);

        float t = (*(values[i]) - min) / range;
        t = ImClamp(t, 0.0f, 1.0f);

        ImColor barColor = colors ? colors[i] : accent;
        if (i % 2 == 0 && !colors)
            barColor = ImColor(200, 100, 100);

        draw->AddRectFilled(barMin, barMax, C(ImColor(35, 35, 35)), 3.0f);

        if (t > 0.001f)
        {
            ImVec2 fillMin(barMin.x, barMin.y);
            ImVec2 fillMax(barMin.x + barWidth * t, barMax.y);
            draw->AddRectFilled(fillMin, fillMax, C(barColor), 3.0f);
        }

        draw->AddRect(barMin, barMax, C(ImColor(50, 50, 50)), 3.0f);

        if (names && names[i])
        {
            ImVec2 nameSize = ImGui::CalcTextSize(names[i]);
            ImVec2 namePos(pos.x + 4.0f, barY + (barHeight - nameSize.y) * 0.5f);
            draw->AddText(namePos, C(ImColor(180, 180, 180)), names[i]);
        }
        else
        {
            char idxBuf[16];
            ImFormatString(idxBuf, IM_ARRAYSIZE(idxBuf), "[%d]", i);
            ImVec2 idxSize = ImGui::CalcTextSize(idxBuf);
            ImVec2 idxPos(pos.x + 4.0f, barY + (barHeight - idxSize.y) * 0.5f);
            draw->AddText(idxPos, C(ImColor(180, 180, 180)), idxBuf);
        }

        char valBuf[32];
        ImFormatString(valBuf, IM_ARRAYSIZE(valBuf), "%.1f", *(values[i]));
        ImVec2 valSize = ImGui::CalcTextSize(valBuf);
        ImVec2 valPos(barMax.x - 4.0f - valSize.x, barY + (barHeight - valSize.y) * 0.5f);
        draw->AddText(valPos, C(ImColor(200, 200, 200)), valBuf);

        ImRect barRect(barMin, barMax);
        ImGui::ItemSize(ImVec2(fullWidth, barHeight + barSpacing));
        ImGui::ItemAdd(barRect, id + i + 1);

        if (ImGui::IsMouseClicked(0))
        {
            ImVec2 mp = ImGui::GetMousePos();
            if (barRect.Contains(mp))
            {
                ImGui::SetActiveID(id, window);
                activeBar = i;
            }
        }

        if (g.ActiveId == id && activeBar == i && (ImGui::IsMouseDragging(0) || ImGui::IsMouseDown(0)))
        {
            ImVec2 mp = ImGui::GetMousePos();
            float newT = (mp.x - barMin.x) / barWidth;
            newT = ImClamp(newT, 0.0f, 1.0f);
            float newVal = min + newT * range;
            newVal = ImClamp(newVal, min, max);
            if (*(values[i]) != newVal)
            {
                *(values[i]) = newVal;
                changed = true;
            }
        }

        if (activeBar == i && g.ActiveId == id && !ImGui::IsMouseDown(0))
        {
            ImGui::ClearActiveID();
            activeBar = -1;
        }
    }

    if (g.ActiveId == id && activeBar == -1 && !ImGui::IsMouseDown(0))
    {
        ImGui::ClearActiveID();
    }

    float totalHeight = count * (barHeight + barSpacing);
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + totalHeight + 4.0f);
    ImGui::PopID();
    return changed;
}
