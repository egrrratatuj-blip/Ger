#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "../../../imgui/imgui.h"
#include "../../../imgui/imgui_internal.h"
#include <math.h>
static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }

void DrawBlurredRect(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor baseColor, ImColor edgeColor, float radius, float blurSize) {
    const int layers = 8;
    float maxExpand = blurSize * 2.0f;
    for (int i = 0; i < layers; i++) {
        float t = (float)i / (float)layers;
        float expand = maxExpand * t;
        float alpha = (1.0f - t) * (1.0f - t) * 0.3f;
        ImColor layerCol = baseColor;
        layerCol.Value.w = ImClamp(alpha, 0.0f, 1.0f);
        ImVec2 ep1 = ImVec2(p1.x - expand, p1.y - expand);
        ImVec2 ep2 = ImVec2(p2.x + expand, p2.y + expand);
        float layerRadius = radius + expand * 0.5f;
        dl->AddRectFilled(ep1, ep2, C(layerCol), layerRadius);
    }
    for (int i = 0; i < layers; i++) {
        float t = (float)i / (float)layers;
        float expand = maxExpand * t;
        float alpha = (1.0f - t) * 0.15f;
        ImColor layerCol = edgeColor;
        layerCol.Value.w = ImClamp(alpha, 0.0f, 1.0f);
        float thickness = (1.0f - t) * blurSize * 0.3f;
        dl->AddRect(p1, p2, C(layerCol), radius, 0, thickness);
    }
    dl->AddRectFilled(p1, p2, C(baseColor), radius);
    dl->AddRect(p1, p2, C(edgeColor), radius, 0, 1.5f);
}

void DrawFrostedGlass(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor tint, float blurSize) {
    const int layers = 6;
    float maxExpand = blurSize * 1.5f;
    for (int i = 0; i < layers; i++) {
        float t = (float)i / (float)layers;
        float expand = maxExpand * t;
        float alpha = (1.0f - t) * (1.0f - t) * 0.12f;
        ImColor layerCol = ImColor(255, 255, 255, (int)(alpha * 255.0f));
        ImVec2 ep1 = ImVec2(p1.x - expand, p1.y - expand);
        ImVec2 ep2 = ImVec2(p2.x + expand, p2.y + expand);
        dl->AddRectFilled(ep1, ep2, C(layerCol), 4.0f + expand * 0.3f);
    }
    dl->AddRectFilled(p1, p2, C(tint), 4.0f);
    dl->AddRect(p1, p2, C(ImColor(255, 255, 255, 76)), 4.0f, 0, 1.0f);
    for (int i = 0; i < 4; i++) {
        float t = (float)i / 4.0f;
        float expand = maxExpand * t;
        float alpha = (1.0f - t) * 0.15f;
        ImColor borderCol = ImColor(255, 255, 255, (int)(alpha * 255.0f));
        dl->AddRect(p1, p2, C(borderCol), 4.0f, 0, 0.5f);
    }
}

void DrawDepthFade(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor color, float fadeStart) {
    int steps = 20;
    float h = p2.y - p1.y;
    float fadeRegion = 1.0f - fadeStart;
    if (fadeRegion <= 0.001f) {
        dl->AddRectFilled(p1, p2, C(color));
        return;
    }
    float fadeStartY = p1.y + h * fadeStart;
    for (int i = 0; i < steps; i++) {
        float t0 = (float)i / (float)steps;
        float t1 = (float)(i + 1) / (float)steps;
        float y0 = p1.y + h * t0;
        float y1 = p1.y + h * t1;
        if (y0 < fadeStartY) {
            dl->AddRectFilled(
                ImVec2(p1.x, y0),
                ImVec2(p2.x, y1),
                C(color)
            );
        } else {
            float fadeT = (y0 - fadeStartY) / (h * fadeRegion);
            fadeT = ImClamp(fadeT, 0.0f, 1.0f);
            float alpha = color.Value.w * (1.0f - fadeT);
            ImColor c = color;
            c.Value.w = ImClamp(alpha, 0.0f, 1.0f);
            dl->AddRectFilled(
                ImVec2(p1.x, y0),
                ImVec2(p2.x, y1),
                C(c)
            );
        }
    }
}

void DrawGlowMorph(ImDrawList* dl, ImVec2 center, float radius, ImColor colorA, ImColor colorB, float time) {
    int numPoints = 24;
    ImVector<ImVec2> points;
    points.reserve(numPoints);
    for (int i = 0; i < numPoints; i++) {
        float angle = (float)i / (float)numPoints * IM_PI * 2.0f;
        float r = radius;
        r += sinf(angle * 3.0f + time * 2.0f) * radius * 0.2f;
        r += cosf(angle * 5.0f + time * 1.3f) * radius * 0.1f;
        r += sinf(angle * 7.0f + time * 0.7f) * radius * 0.05f;
        points.push_back(ImVec2(
            center.x + cosf(angle) * r,
            center.y + sinf(angle) * r
        ));
    }

    const int glowLayers = 5;
    for (int layer = 0; layer < glowLayers; layer++) {
        float layerT = (float)layer / (float)glowLayers;
        float expand = radius * layerT * 0.5f;
        float alpha = (1.0f - layerT) * 0.25f;
        ImColor c;
        float blend = sinf(time * 0.5f + (float)layer * 0.5f) * 0.5f + 0.5f;
        c = ImColor(
            colorA.Value.x + (colorB.Value.x - colorA.Value.x) * blend,
            colorA.Value.y + (colorB.Value.y - colorA.Value.y) * blend,
            colorA.Value.z + (colorB.Value.z - colorA.Value.z) * blend,
            alpha
        );
        ImVector<ImVec2> layerPoints;
        layerPoints.reserve(numPoints);
        for (int i = 0; i < numPoints; i++) {
            float angle = (float)i / (float)numPoints * IM_PI * 2.0f;
            float r = radius + expand;
            r += sinf(angle * 3.0f + time * 2.0f + layerT) * (radius + expand) * 0.2f;
            r += cosf(angle * 5.0f + time * 1.3f + layerT) * (radius + expand) * 0.1f;
            layerPoints.push_back(ImVec2(
                center.x + cosf(angle) * r,
                center.y + sinf(angle) * r
            ));
        }
        dl->AddConvexPolyFilled(layerPoints.Data, numPoints, C(c));
    }

    ImColor innerCol;
    float blendInner = sinf(time * 0.7f) * 0.5f + 0.5f;
    innerCol = ImColor(
        colorA.Value.x + (colorB.Value.x - colorA.Value.x) * blendInner,
        colorA.Value.y + (colorB.Value.y - colorA.Value.y) * blendInner,
        colorA.Value.z + (colorB.Value.z - colorA.Value.z) * blendInner,
        1.0f
    );
    dl->AddConvexPolyFilled(points.Data, numPoints, C(innerCol));

    for (int i = 0; i < numPoints; i++) {
        int ni = (i + 1) % numPoints;
        ImVec2 mid = ImVec2(
            (points[i].x + points[ni].x) * 0.5f,
            (points[i].y + points[ni].y) * 0.5f
        );
        float dist = ImSqrt(
            (mid.x - center.x) * (mid.x - center.x) +
            (mid.y - center.y) * (mid.y - center.y)
        );
        float brightness = dist / radius;
        ImColor lineCol = ImColor(
            255, 255, 255,
            (int)(brightness * 60)
        );
        dl->AddLine(points[i], points[ni], C(lineCol), 1.0f);
    }
}
