#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "../../../imgui/imgui.h"
#include "../../../imgui/imgui_internal.h"
#include "../../../imgui/mycustom/imgui_Custom.h"
#include <math.h>
#include <string.h>
#include <map>
#include <stdlib.h>
#include <stdio.h>

static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }

static float g_floatLabelGlobalPhase = 0.0f;

void M_FloatLabel(const char* label, ImVec2 pos, ImColor color, float size)
{
    static std::map<const char*, struct { float timer; float yOff; float alpha; float startX; float startY; int phase; float delay; float driftPhase; int burstCount; float burstTimer; }> s_states;
    auto& s = s_states[label];
    g_floatLabelGlobalPhase += ImGui::GetIO().DeltaTime * 0.5f;
    s.timer += ImGui::GetIO().DeltaTime;
    float t = s.timer;
    if (t > 3.0f)
    {
        s.timer = 0.0f;
        s.phase++;
        s.delay = 0.0f;
        t = 0.0f;
        s.driftPhase = (float)(rand() % 1000) * 0.001f;
        s.burstCount = rand() % 3;
        s.burstTimer = 0.0f;
    }
    if (s.delay < 0.08f)
    {
        s.delay += ImGui::GetIO().DeltaTime;
        t = 0.0f;
    }
    float ease = t * t * (3.0f - 2.0f * t);
    s.yOff = -ease * 75.0f;
    if (t < 0.2f)
    {
        float fadeIn = t / 0.2f;
        s.alpha = fadeIn * fadeIn * (3.0f - 2.0f * fadeIn);
    }
    else if (t < 1.6f)
    {
        s.alpha = 1.0f;
    }
    else if (t < 2.4f)
    {
        float fadeOut = (t - 1.6f) / 0.8f;
        s.alpha = 1.0f - fadeOut * fadeOut * (3.0f - 2.0f * fadeOut);
    }
    else
    {
        s.alpha = 0.0f;
    }
    if (s.alpha < 0.0f) s.alpha = 0.0f;
    if (s.alpha > 1.0f) s.alpha = 1.0f;
    ImColor c = color;
    c.Value.w *= s.alpha;
    ImDrawList* dl = ImGui::GetOverlayDrawList();
    float drift = sinf(t * 3.5f + s.driftPhase * IM_PI * 2.0f + g_floatLabelGlobalPhase) * 7.0f;
    drift *= (1.0f - ease * 0.6f);
    float xOff = sinf(t * 2.0f + s.driftPhase * 3.0f + g_floatLabelGlobalPhase * 0.5f) * 5.0f;
    float yJitter = sinf(t * 12.0f + s.driftPhase * 5.0f) * 1.0f * s.alpha;
    ImVec2 p = ImVec2(pos.x + drift + xOff, pos.y + s.yOff + yJitter);
    ImVec2 ts = ImGui::CalcTextSize(label);
    p.x -= ts.x * 0.5f;
    if (s.alpha > 0.05f)
    {
        if (t < 0.35f && t > 0.05f)
        {
            float scale = 0.5f + 0.5f * (t / 0.35f);
            dl->AddText(ImGui::GetFont(), size * scale, ImVec2(p.x - ts.x * (scale - 1.0f) * 0.5f, p.y), C(c), label);
        }
        else
        {
            dl->AddText(ImGui::GetFont(), size, p, C(c), label);
        }
        if (t < 0.5f && s.alpha > 0.5f)
        {
            ImColor glow = c;
            glow.Value.w *= 0.15f;
            dl->AddText(ImGui::GetFont(), size, ImVec2(p.x + 2.0f, p.y + 2.0f), C(glow), label);
            dl->AddText(ImGui::GetFont(), size, ImVec2(p.x - 2.0f, p.y - 2.0f), C(glow), label);
            dl->AddText(ImGui::GetFont(), size, ImVec2(p.x, p.y + 3.0f), C(glow), label);
        }
    }
}

void M_GradientText(ImDrawList* dl, const char* text, ImVec2 pos, ImColor colorA, ImColor colorB, float size)
{
    if (!text || !*text) return;
    int len = (int)strlen(text);
    if (len == 0) return;
    float totalWidth = 0.0f;
    float* charW = (float*)alloca(len * sizeof(float));
    for (int i = 0; i < len; ++i)
    {
        char ch[2] = { text[i], 0 };
        charW[i] = ImGui::CalcTextSize(ch).x;
        totalWidth += charW[i];
    }
    ImVec2 p = pos;
    for (int i = 0; i < len; ++i)
    {
        float f = (len > 1) ? (float)i / (float)(len - 1) : 0.5f;
        float invF = 1.0f - f;
        ImColor col;
        col.Value.x = colorA.Value.x * invF + colorB.Value.x * f;
        col.Value.y = colorA.Value.y * invF + colorB.Value.y * f;
        col.Value.z = colorA.Value.z * invF + colorB.Value.z * f;
        col.Value.w = colorA.Value.w * invF + colorB.Value.w * f;
        if (i == 0) col = colorA;
        if (i == len - 1) col = colorB;
        float chH = ImGui::GetFont()->FontSize * size / 13.0f;
        float yOff = sinf(f * IM_PI * 3.0f) * 2.0f;
        float rotOff = sinf(f * IM_PI * 2.0f + 0.5f) * 0.5f;
        char ch[2] = { text[i], 0 };
        dl->AddText(ImGui::GetFont(), size, ImVec2(p.x + rotOff, p.y + yOff), C(col), ch);
        float advance = ImGui::GetFont()->GetCharAdvance((unsigned char)text[i]) * size / 13.0f;
        p.x += advance;
    }
    ImColor shadowCol = colorA;
    shadowCol.Value.x *= 0.3f;
    shadowCol.Value.y *= 0.3f;
    shadowCol.Value.z *= 0.3f;
    shadowCol.Value.w *= 0.15f;
    dl->AddText(ImGui::GetFont(), size, ImVec2(pos.x + 1.5f, pos.y + 1.5f), C(shadowCol), text);
    if (len > 1)
    {
        ImColor sparkA = colorA;
        sparkA.Value.w *= 0.3f;
        ImColor sparkB = colorB;
        sparkB.Value.w *= 0.3f;
        dl->AddLine(pos, ImVec2(pos.x + totalWidth, pos.y + ImGui::GetFont()->FontSize * size / 13.0f + 2.0f), C(sparkA), 1.0f);
    }
}

void M_GlitchText(ImDrawList* dl, const char* text, ImVec2 pos, ImColor color, float size, float glitchAmount)
{
    if (!text || !*text) return;
    float time = ImGui::GetTime();
    int len = (int)strlen(text);
    ImVec2 p = pos;
    for (int i = 0; i < len; ++i)
    {
        float noise1 = sinf(time * 7.3f + (float)i * 1.7f + cosf(time * 2.1f) * 0.5f) * 0.5f + 0.5f;
        float noise2 = cosf(time * 5.7f + (float)i * 2.3f + sinf(time * 3.7f) * 0.3f) * 0.5f + 0.5f;
        float noise3 = sinf(time * 11.3f + (float)i * 0.7f + cosf(time * 5.1f) * 0.4f) * 0.5f + 0.5f;
        float noise4 = sinf(time * 3.1f + (float)i * 3.1f) * 0.5f + 0.5f;
        float offset = 0.0f;
        float yShift = 0.0f;
        float alphaMod = 1.0f;
        float scaleX = 1.0f;
        if (glitchAmount > 0.01f)
        {
            float threshold = 0.75f - glitchAmount * 0.25f;
            if (noise1 > threshold)
                offset = (noise1 - threshold) / (1.0f - threshold) * glitchAmount * 14.0f;
            if (noise2 > threshold + 0.05f)
                yShift = (noise2 - threshold - 0.05f) / (1.0f - threshold - 0.05f) * glitchAmount * 5.0f;
            if (noise3 > 0.92f && glitchAmount > 0.4f)
                alphaMod = 0.2f + noise1 * 0.8f;
            if (noise4 > 0.9f && glitchAmount > 0.6f)
                scaleX = 0.6f + noise1 * 0.8f;
        }
        char ch[2] = { text[i], 0 };
        float charAdvance = ImGui::GetFont()->GetCharAdvance((unsigned char)text[i]) * size / 13.0f;
        ImVec2 cpos = ImVec2(p.x + offset, p.y + yShift);
        if (glitchAmount > 0.25f && noise2 > 0.8f)
        {
            ImColor rCol = ImColor(255, 60, 60, (int)(color.Value.w * 255 * 0.5f * glitchAmount));
            ImColor gCol = ImColor(60, 200, 60, (int)(color.Value.w * 255 * 0.5f * glitchAmount));
            ImColor bCol = ImColor(60, 60, 255, (int)(color.Value.w * 255 * 0.4f * glitchAmount));
            dl->AddText(ImGui::GetFont(), size, ImVec2(cpos.x + offset * 0.4f + 3.0f, cpos.y - yShift * 0.3f), C(rCol), ch);
            dl->AddText(ImGui::GetFont(), size, ImVec2(cpos.x - offset * 0.4f - 3.0f, cpos.y + yShift * 0.3f), C(gCol), ch);
            if (glitchAmount > 0.6f && noise3 > 0.7f)
                dl->AddText(ImGui::GetFont(), size, ImVec2(cpos.x + 1.0f, cpos.y - 1.0f), C(bCol), ch);
        }
        ImColor c = color;
        c.Value.w *= alphaMod;
        dl->AddText(ImGui::GetFont(), size, cpos, C(c), ch);
        if (glitchAmount > 0.4f && noise1 > 0.88f)
        {
            int sliceLen = (int)(noise2 * 5.0f) + 1;
            if (i + sliceLen > len) sliceLen = len - i;
            if (sliceLen > 0)
            {
                char slice[16];
                strncpy(slice, text + i, sliceLen);
                slice[sliceLen] = 0;
                float sliceY = p.y + 10.0f * glitchAmount * noise3;
                float sliceX = p.x + offset * 1.8f + sinf(time * 8.0f + i) * 3.0f;
                ImColor slCol = ImColor(180, 180, 200, (int)(color.Value.w * 255 * 0.25f * glitchAmount));
                dl->AddText(ImGui::GetFont(), size, ImVec2(sliceX, sliceY), C(slCol), slice);
            }
        }
        if (glitchAmount > 0.6f && noise4 > 0.92f)
        {
            int j = len - 1 - i;
            if (j >= 0 && j < len && j != i)
            {
                char ch2[2] = { text[j], 0 };
                ImColor swapCol = ImColor(120, 120, 120, (int)(color.Value.w * 255 * 0.15f));
                dl->AddText(ImGui::GetFont(), size, ImVec2(p.x + 2.0f, p.y + 3.0f * glitchAmount), C(swapCol), ch2);
            }
        }
        p.x += charAdvance;
    }
    if (glitchAmount > 0.7f)
    {
        float scanLine = sinf(time * 15.0f) * 0.5f + 0.5f;
        float sy = pos.y + scanLine * (ImGui::CalcTextSize(text).y + 8.0f);
        float sx = pos.x;
        float sw = ImGui::CalcTextSize(text).x;
        dl->AddRectFilled(ImVec2(sx, sy), ImVec2(sx + sw, sy + 1.0f), C(ImColor(255,255,255,(int)(color.Value.w * 255 * 0.15f * glitchAmount))));
    }
    if (glitchAmount > 0.5f && sinf(time * 3.0f) > 0.95f)
    {
        ImColor flash = color;
        flash.Value.w *= 0.5f * glitchAmount;
        dl->AddText(ImGui::GetFont(), size, ImVec2(pos.x + 1.0f, pos.y + 1.0f), C(flash), text);
        dl->AddText(ImGui::GetFont(), size, ImVec2(pos.x - 1.0f, pos.y - 1.0f), C(flash), text);
    }
}

void M_OutlinedText(ImDrawList* dl, const char* text, ImVec2 pos, ImColor textColor, ImColor outlineColor, float size)
{
    ImU32 outline = C(outlineColor);
    ImU32 fill = C(textColor);
    dl->AddText(ImGui::GetFont(), size, ImVec2(pos.x - 1.5f, pos.y), outline, text);
    dl->AddText(ImGui::GetFont(), size, ImVec2(pos.x + 1.5f, pos.y), outline, text);
    dl->AddText(ImGui::GetFont(), size, ImVec2(pos.x, pos.y - 1.5f), outline, text);
    dl->AddText(ImGui::GetFont(), size, ImVec2(pos.x, pos.y + 1.5f), outline, text);
    dl->AddText(ImGui::GetFont(), size, ImVec2(pos.x - 1.5f, pos.y - 1.5f), outline, text);
    dl->AddText(ImGui::GetFont(), size, ImVec2(pos.x + 1.5f, pos.y - 1.5f), outline, text);
    dl->AddText(ImGui::GetFont(), size, ImVec2(pos.x - 1.5f, pos.y + 1.5f), outline, text);
    dl->AddText(ImGui::GetFont(), size, ImVec2(pos.x + 1.5f, pos.y + 1.5f), outline, text);
    dl->AddText(ImGui::GetFont(), size, pos, fill, text);
    ImColor glowLow = outlineColor;
    glowLow.Value.w *= 0.25f;
    ImU32 glowCol = C(glowLow);
    dl->AddText(ImGui::GetFont(), size, ImVec2(pos.x - 3.5f, pos.y), glowCol, text);
    dl->AddText(ImGui::GetFont(), size, ImVec2(pos.x + 3.5f, pos.y), glowCol, text);
    dl->AddText(ImGui::GetFont(), size, ImVec2(pos.x, pos.y - 3.5f), glowCol, text);
    dl->AddText(ImGui::GetFont(), size, ImVec2(pos.x, pos.y + 3.5f), glowCol, text);
    ImColor glowHigh = outlineColor;
    glowHigh.Value.w *= 0.1f;
    ImU32 glowCol2 = C(glowHigh);
    dl->AddText(ImGui::GetFont(), size, ImVec2(pos.x - 5.0f, pos.y), glowCol2, text);
    dl->AddText(ImGui::GetFont(), size, ImVec2(pos.x + 5.0f, pos.y), glowCol2, text);
    dl->AddText(ImGui::GetFont(), size, ImVec2(pos.x, pos.y - 5.0f), glowCol2, text);
    dl->AddText(ImGui::GetFont(), size, ImVec2(pos.x, pos.y + 5.0f), glowCol2, text);
}

void M_TypewriterText(ImDrawList* dl, const char* text, ImVec2 pos, ImColor color, float size, float speed)
{
    static std::map<const char*, struct { float timer; float cursorBlink; bool done; int lastLen; float perChar[256]; }> s_states;
    auto& s = s_states[text];
    int len = (int)strlen(text);
    if (len != s.lastLen)
    {
        s.lastLen = len;
        s.timer = 0.0f;
        s.cursorBlink = 0.0f;
        s.done = false;
    }
    if (!s.done)
        s.timer += ImGui::GetIO().DeltaTime * speed;
    if (len > 255) len = 255;
    int visible = (int)s.timer;
    if (visible > len) { visible = len; s.done = true; }
    if (s.done && s.timer < (float)len)
        s.timer = (float)len;
    float totalW = 0.0f;
    for (int i = 0; i < len; ++i)
    {
        char ch[2] = { text[i], 0 };
        float cw = ImGui::CalcTextSize(ch).x;
        s.perChar[i] = cw;
        totalW += cw;
    }
    ImVec2 p = pos;
    for (int i = 0; i < len; ++i)
    {
        float appearT = s.timer - (float)i;
        if (appearT > 0.0f && i < visible)
        {
            float alpha = 1.0f;
            float yOff = 0.0f;
            if (appearT < 0.3f)
            {
                alpha = appearT / 0.3f;
                yOff = (1.0f - alpha) * 6.0f;
            }
            float scale = 1.0f;
            if (appearT < 0.15f)
            {
                scale = 0.5f + 0.5f * (appearT / 0.15f);
            }
            ImColor c = color;
            c.Value.w *= alpha;
            char ch[2] = { text[i], 0 };
            float advance = s.perChar[i];
            if (fabsf(scale - 1.0f) > 0.01f)
            {
                dl->AddText(ImGui::GetFont(), size * scale, ImVec2(p.x - advance * (scale - 1.0f) * 0.5f, p.y + yOff), C(c), ch);
            }
            else
            {
                dl->AddText(ImGui::GetFont(), size, ImVec2(p.x, p.y + yOff), C(c), ch);
            }
            if (appearT < 0.5f && alpha > 0.3f)
            {
                ImColor glow = c;
                glow.Value.w *= 0.2f;
                dl->AddText(ImGui::GetFont(), size, ImVec2(p.x + 1.0f, p.y + yOff + 1.0f), C(glow), ch);
            }
            p.x += advance;
        }
        else
        {
            p.x += s.perChar[i];
        }
    }
    ImVec2 cursorPos = p;
    if (visible < len)
    {
        s.cursorBlink += ImGui::GetIO().DeltaTime * 5.0f;
        float blink = sinf(s.cursorBlink * IM_PI * 2.0f) * 0.5f + 0.5f;
        if (blink > 0.3f)
        {
            ImColor cursorCol = color;
            cursorCol.Value.w *= blink * 0.8f + 0.2f;
            dl->AddText(ImGui::GetFont(), size, cursorPos, C(cursorCol), "|");
        }
    }
    else if (s.done)
    {
        s.cursorBlink += ImGui::GetIO().DeltaTime * 3.0f;
        float blink = sinf(s.cursorBlink * IM_PI * 2.0f) * 0.5f + 0.5f;
        if (blink > 0.3f)
        {
            ImColor cursorCol = color;
            cursorCol.Value.w *= 0.5f * blink;
            dl->AddText(ImGui::GetFont(), size, cursorPos, C(cursorCol), "|");
        }
    }
}

void M_ScrollingText(ImDrawList* dl, const char* text, ImVec2 pos, float width, ImColor color, float size, float speed)
{
    ImVec2 textSize = ImGui::CalcTextSize(text);
    ImVec2 clipMin = pos;
    ImVec2 clipMax = ImVec2(pos.x + width, pos.y + textSize.y + 6.0f);
    dl->PushClipRect(clipMin, clipMax, true);
    if (textSize.x <= width)
    {
        float time = ImGui::GetTime() * speed * 0.3f;
        float drift = sinf(time) * 4.0f;
        ImColor c = color;
        dl->AddText(ImGui::GetFont(), size, ImVec2(pos.x + drift, pos.y), C(c), text);
        dl->PopClipRect();
        return;
    }
    float time = ImGui::GetTime() * speed;
    float fullScroll = textSize.x + width * 0.4f;
    float offset = fmodf(time, fullScroll);
    float easeInDist = width * 0.12f;
    float easeOutStart = fullScroll - easeInDist;
    float x1 = pos.x - offset + width * 0.2f;
    float alpha1 = 1.0f;
    if (offset < easeInDist)
    {
        float progress = offset / easeInDist;
        alpha1 = progress * progress * (3.0f - 2.0f * progress);
    }
    else if (offset > easeOutStart)
    {
        float progress = (offset - easeOutStart) / easeInDist;
        alpha1 = 1.0f - progress * progress * (3.0f - 2.0f * progress);
    }
    ImColor c1 = color;
    c1.Value.w *= alpha1;
    ImU32 col1 = C(c1);
    dl->AddText(ImGui::GetFont(), size, ImVec2(x1, pos.y), col1, text);
    float gap = 40.0f;
    float x2 = x1 + textSize.x + gap;
    float alpha2 = 1.0f;
    float offset2 = offset;
    float easeDist2 = easeInDist;
    if (offset2 < easeDist2)
    {
        alpha2 = 1.0f;
    }
    else if (offset2 > fullScroll - easeDist2)
    {
        float endPart = x2 + textSize.x - (pos.x + width);
        if (endPart > 0)
        {
            float fadeProgress = endPart / textSize.x;
            alpha2 = 1.0f - fadeProgress * fadeProgress;
        }
    }
    ImColor c2 = color;
    c2.Value.w *= alpha2;
    ImU32 col2 = C(c2);
    dl->AddText(ImGui::GetFont(), size, ImVec2(x2, pos.y), col2, text);
    if (textSize.y > 8.0f)
    {
        float gradientBarH = 2.0f;
        dl->AddRectFilledMultiColor(ImVec2(pos.x, pos.y + textSize.y + 2.0f), ImVec2(pos.x + width, pos.y + textSize.y + 2.0f + gradientBarH),
            C(ImColor(color.Value.x, color.Value.y, color.Value.z, 0)),
            C(ImColor(color.Value.x, color.Value.y, color.Value.z, (int)(color.Value.w * 60))),
            C(ImColor(color.Value.x, color.Value.y, color.Value.z, (int)(color.Value.w * 60))),
            C(ImColor(color.Value.x, color.Value.y, color.Value.z, 0)));
    }
    dl->PopClipRect();
}

void M_RainbowText(ImDrawList* dl, const char* text, ImVec2 pos, float saturation, float value, float speed, float size)
{
    if (!text || *text == 0) return;
    float time = ImGui::GetTime() * speed;
    ImVec2 p = pos;
    for (int i = 0; text[i]; ++i)
    {
        float hue = fmodf(time + (float)i * 0.15f, 1.0f);
        float r, g, b;
        ImGui::ColorConvertHSVtoRGB(hue, saturation, value, r, g, b);
        ImColor col(r, g, b, 1.0f);
        char ch[2] = { text[i], 0 };
        dl->AddText(ImGui::GetFont(), size, p, C(col), ch);
        float advance = ImGui::GetFont()->GetCharAdvance((unsigned char)text[i]) * size / 13.0f;
        p.x += advance;
    }
}

void M_WavyText(ImDrawList* dl, const char* text, ImVec2 pos, ImColor color, float amplitude, float frequency, float size)
{
    if (!text || !*text) return;
    float time = ImGui::GetTime();
    ImVec2 p = pos;
    for (int i = 0; text[i]; ++i)
    {
        char ch[2] = { text[i], 0 };
        float wave = sinf(time * frequency + (float)i * 0.8f) * amplitude;
        dl->AddText(ImGui::GetFont(), size, ImVec2(p.x, p.y + wave), C(color), ch);
        float advance = ImGui::GetFont()->GetCharAdvance((unsigned char)text[i]) * size / 13.0f;
        p.x += advance;
    }
}

void M_FadeText(ImDrawList* dl, const char* text, ImVec2 pos, ImColor color, float fadeLeft, float fadeRight, float size)
{
    ImVec2 textSize = ImGui::CalcTextSize(text);
    dl->PushClipRect(pos, ImVec2(pos.x + textSize.x, pos.y + textSize.y), true);
    int steps = 20;
    for (int i = 0; i < steps; ++i)
    {
        float f = (float)i / (float)(steps - 1);
        float x0 = pos.x + f * textSize.x;
        float x1 = pos.x + (f + 1.0f / steps) * textSize.x;
        float alpha = 1.0f;
        float fadeStart = fadeLeft;
        float fadeEnd = 1.0f - fadeRight;
        if (f < fadeStart && fadeStart > 0)
            alpha = f / fadeStart;
        else if (f > fadeEnd && fadeEnd < 1.0f)
            alpha = (1.0f - f) / (1.0f - fadeEnd);
        ImColor c = color;
        c.Value.w *= alpha;
        dl->AddRectFilled(ImVec2(x0, pos.y), ImVec2(x1, pos.y + textSize.y), C(c));
    }
    dl->PopClipRect();
    ImColor fullCol = color;
    dl->AddText(ImGui::GetFont(), size, pos, C(fullCol), text);
}
