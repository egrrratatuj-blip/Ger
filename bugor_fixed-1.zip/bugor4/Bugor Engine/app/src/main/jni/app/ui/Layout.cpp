#include "Layout.h"

const int WINDOW_WIDTH = 960;
const int WINDOW_HEIGHT = 640;
const int TITLEBAR_HEIGHT = 48;
const int TABBAR_WIDTH = 72;
const int FOOTER_HEIGHT = 44;
const int MAX_TABS = 10;
const int CONTENT_PADDING = 12;
const float EDGE_SNAP_THRESHOLD = 20.0f;
const float MIN_WINDOW_SCALE = 0.60f;
const float MAX_WINDOW_SCALE = 1.40f;
const float FADE_ANIM_SPEED = 6.0f;
const int WINDOW_BORDER_RADIUS = 10;

WindowState g_WindowState;
ImVec2 g_ScreenSize(1080, 1920);
FrameTiming g_FrameTiming;
RenderMetrics g_RenderMetrics;
InputState g_InputState;
DirtyFlags g_DirtyFlags;
int g_ActiveTab = 0;
int g_HoveredTab = -1;
int g_PreviousTab = -1;
float g_TabTransitionProgress = 0.0f;
bool g_TabTransitionActive = false;
ContentGridLayout g_CurrentGridLayout = ContentGridLayout::FOUR_COLUMN;
float g_ContentScrollPositions[MAX_TABS] = {0};
IntegrationCallbacks g_Callbacks;
std::vector<LayoutEventCallback> g_EventListeners;
std::vector<EffectDrawFunction> g_ExternalOverlays;
bool g_LayoutInitialized = false;
float g_GlobalTime = 0.0f;
float g_PulsePhase = 0.0f;
float g_BreathPhase = 0.0f;
int g_ActiveThemePreset = 0;
bool g_ConfigNeedsSave = false;
char g_VersionString[32] = "v2.0.0";
char g_BuildDate[32] = "2026-06-14";
bool g_FooterToggleState = false;
float g_FooterPulseTime = 0.0f;
ImGui::AnimFloat g_FooterPulseAnim(0.0f, 4.0f);
ImColor g_TabIconColors[MAX_TABS];
ImGui::AnimColor g_TabIconAnimColors[MAX_TABS];
LayoutEngine g_Layout;

static ImU32 ColToU32(const ImColor &c) {
    return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w));
}

static float easeOutQuad(float t) { return t * (2.0f - t); }
static float easeOutCubic(float t) { float v = t - 1.0f; return v * v * v + 1.0f; }
static float easeInOutCubic(float t) { return t < 0.5f ? 4.0f * t * t * t : 1.0f - powf(-2.0f * t + 2.0f, 3.0f) * 0.5f; }
static float lerp(float a, float b, float t) { return a + (b - a) * ImClamp(t, 0.0f, 1.0f); }
static float clamp01(float v) { return ImClamp(v, 0.0f, 1.0f); }

ImColor ThemeColors[5][10] = {
    { ImColor(10, 10, 20), ImColor(0, 180, 255), ImColor(255, 255, 255), ImColor(30, 30, 50), ImColor(0, 120, 200), ImColor(20, 20, 35), ImColor(0, 200, 255), ImColor(100, 50, 255), ImColor(0, 80, 160), ImColor(50, 50, 80) },
    { ImColor(20, 15, 25), ImColor(255, 80, 120), ImColor(255, 255, 255), ImColor(40, 25, 40), ImColor(200, 50, 80), ImColor(30, 20, 30), ImColor(255, 100, 150), ImColor(200, 50, 150), ImColor(150, 30, 60), ImColor(60, 30, 50) },
    { ImColor(10, 25, 15), ImColor(0, 255, 120), ImColor(255, 255, 255), ImColor(20, 40, 25), ImColor(0, 200, 80), ImColor(15, 30, 20), ImColor(0, 255, 150), ImColor(50, 200, 100), ImColor(0, 150, 60), ImColor(30, 60, 40) },
    { ImColor(25, 20, 10), ImColor(255, 200, 50), ImColor(255, 255, 255), ImColor(40, 30, 20), ImColor(200, 150, 30), ImColor(30, 25, 15), ImColor(255, 220, 80), ImColor(200, 150, 50), ImColor(150, 120, 20), ImColor(60, 50, 30) },
    { ImColor(15, 10, 30), ImColor(150, 50, 255), ImColor(255, 255, 255), ImColor(30, 20, 50), ImColor(100, 30, 200), ImColor(20, 15, 40), ImColor(180, 80, 255), ImColor(150, 50, 200), ImColor(80, 20, 160), ImColor(50, 30, 70) }
};

int CurrentTheme = 0;
int TargetTheme = 0;
bool themeAnimating = false;
AnimTheme g_ThemeAnim;
float g_ThemeTransitionTime = 0.0f;
const float THEME_TRANSITION_DURATION = 0.5f;

void AnimTheme::SetTarget(int themeID) {
    for (int i = 0; i < 10; i++) {
        colors[i].SetTarget(ThemeColors[themeID][i]);
        colors[i].speed = 6.0f;
    }
    active = true;
}

void AnimTheme::Update() {
    if (!active) return;
    bool allDone = true;
    for (int i = 0; i < 10; i++) {
        colors[i].Update();
        if (!colors[i].IsDone()) allDone = false;
    }
    if (allDone) active = false;
}

ImColor AnimTheme::Get(int idx) { return colors[idx].Get(); }
ImVec4 AnimTheme::GetV4(int idx) { return colors[idx].GetVec4(); }

static ImColor GetAccent() {
    if (themeAnimating) return g_ThemeAnim.Get(1);
    return ThemeColors[CurrentTheme][1];
}

static ImColor GetAccent2() {
    if (themeAnimating) return g_ThemeAnim.Get(7);
    return ThemeColors[CurrentTheme][7];
}

static ImColor GetTextCol() {
    if (themeAnimating) return g_ThemeAnim.Get(2);
    return ThemeColors[CurrentTheme][2];
}

static ImColor GetFrameBg() {
    if (themeAnimating) return g_ThemeAnim.Get(5);
    return ThemeColors[CurrentTheme][5];
}

static void ApplyTheme(int themeID) {
    if (themeID < 0 || themeID >= 5) themeID = 0;
    if (themeID == CurrentTheme && !themeAnimating) return;
    if (themeID != TargetTheme) {
        TargetTheme = themeID;
        g_ThemeAnim.SetTarget(themeID);
        themeAnimating = true;
        g_ThemeTransitionTime = 0.0f;
    }
}

static void FinalizeTheme() {
    if (!themeAnimating) return;
    g_ThemeTransitionTime += ImGui::GetIO().DeltaTime;
    g_ThemeAnim.Update();
    if (g_ThemeTransitionTime >= THEME_TRANSITION_DURATION || g_ThemeAnim.active == false) {
        CurrentTheme = TargetTheme;
        themeAnimating = false;
        for (int i = 0; i < 10; i++)
            g_ThemeAnim.colors[i].Set(ThemeColors[CurrentTheme][i]);
    }
    ImColor c0 = g_ThemeAnim.active ? g_ThemeAnim.Get(0) : ThemeColors[CurrentTheme][0];
    ImColor c1 = g_ThemeAnim.active ? g_ThemeAnim.Get(1) : ThemeColors[CurrentTheme][1];
    ImColor c2 = g_ThemeAnim.active ? g_ThemeAnim.Get(2) : ThemeColors[CurrentTheme][2];
    ImColor c3 = g_ThemeAnim.active ? g_ThemeAnim.Get(3) : ThemeColors[CurrentTheme][3];
    ImColor c4 = g_ThemeAnim.active ? g_ThemeAnim.Get(4) : ThemeColors[CurrentTheme][4];
    ImColor c5 = g_ThemeAnim.active ? g_ThemeAnim.Get(5) : ThemeColors[CurrentTheme][5];
    ImColor c6 = g_ThemeAnim.active ? g_ThemeAnim.Get(6) : ThemeColors[CurrentTheme][6];
    ImColor c7 = g_ThemeAnim.active ? g_ThemeAnim.Get(7) : ThemeColors[CurrentTheme][7];
    ImColor c8 = g_ThemeAnim.active ? g_ThemeAnim.Get(8) : ThemeColors[CurrentTheme][8];
    ImColor c9 = g_ThemeAnim.active ? g_ThemeAnim.Get(9) : ThemeColors[CurrentTheme][9];
    ImGuiStyle *s = &ImGui::GetStyle();
    ImVec4 *c = s->Colors;
    c[ImGuiCol_WindowBg] = ImVec4(c0.Value.x, c0.Value.y, c0.Value.z, 0.92f);
    c[ImGuiCol_TitleBg] = ImVec4(c3.Value.x, c3.Value.y, c3.Value.z, 1.0f);
    c[ImGuiCol_TitleBgActive] = ImVec4(c1.Value.x, c1.Value.y, c1.Value.z, 0.8f);
    c[ImGuiCol_Button] = ImVec4(c4.Value.x, c4.Value.y, c4.Value.z, 0.9f);
    c[ImGuiCol_ButtonHovered] = ImVec4(c6.Value.x, c6.Value.y, c6.Value.z, 1.0f);
    c[ImGuiCol_ButtonActive] = ImVec4(c7.Value.x, c7.Value.y, c7.Value.z, 1.0f);
    c[ImGuiCol_FrameBg] = ImVec4(c5.Value.x, c5.Value.y, c5.Value.z, 0.7f);
    c[ImGuiCol_FrameBgHovered] = ImVec4(c5.Value.x, c5.Value.y, c5.Value.z, 0.9f);
    c[ImGuiCol_FrameBgActive] = ImVec4(c4.Value.x, c4.Value.y, c4.Value.z, 0.8f);
    c[ImGuiCol_CheckMark] = ImVec4(c6.Value.x, c6.Value.y, c6.Value.z, 1.0f);
    c[ImGuiCol_SliderGrab] = ImVec4(c6.Value.x, c6.Value.y, c6.Value.z, 1.0f);
    c[ImGuiCol_SliderGrabActive] = ImVec4(c7.Value.x, c7.Value.y, c7.Value.z, 1.0f);
    c[ImGuiCol_Header] = ImVec4(c4.Value.x, c4.Value.y, c4.Value.z, 0.6f);
    c[ImGuiCol_HeaderHovered] = ImVec4(c6.Value.x, c6.Value.y, c6.Value.z, 0.7f);
    c[ImGuiCol_HeaderActive] = ImVec4(c7.Value.x, c7.Value.y, c7.Value.z, 0.8f);
    c[ImGuiCol_Text] = ImVec4(c2.Value.x, c2.Value.y, c2.Value.z, 1.0f);
    c[ImGuiCol_Border] = ImVec4(c8.Value.x, c8.Value.y, c8.Value.z, 0.5f);
    c[ImGuiCol_ResizeGrip] = ImVec4(c6.Value.x, c6.Value.y, c6.Value.z, 0.6f);
    c[ImGuiCol_ResizeGripHovered] = ImVec4(c6.Value.x, c6.Value.y, c6.Value.z, 0.8f);
    c[ImGuiCol_ResizeGripActive] = ImVec4(c7.Value.x, c7.Value.y, c7.Value.z, 1.0f);
    c[ImGuiCol_ScrollbarBg] = ImVec4(c5.Value.x, c5.Value.y, c5.Value.z, 0.5f);
    c[ImGuiCol_ScrollbarGrab] = ImVec4(c4.Value.x, c4.Value.y, c4.Value.z, 0.7f);
    c[ImGuiCol_ScrollbarGrabHovered] = ImVec4(c6.Value.x, c6.Value.y, c6.Value.z, 0.8f);
    c[ImGuiCol_ScrollbarGrabActive] = ImVec4(c7.Value.x, c7.Value.y, c7.Value.z, 1.0f);
    c[ImGuiCol_Tab] = ImVec4(c3.Value.x, c3.Value.y, c3.Value.z, 0.8f);
    c[ImGuiCol_TabHovered] = ImVec4(c6.Value.x, c6.Value.y, c6.Value.z, 0.9f);
    c[ImGuiCol_TabActive] = ImVec4(c1.Value.x, c1.Value.y, c1.Value.z, 1.0f);
    c[ImGuiCol_Separator] = ImVec4(c8.Value.x, c8.Value.y, c8.Value.z, 0.5f);
}

static void DrawGlowRect(ImDrawList *dl, ImVec2 p1, ImVec2 p2, ImColor col, float radius, float glowSize) {
    for (int i = 5; i >= 0; i--) {
        float t = (float)i / 5.0f;
        float expand = glowSize * t;
        float alpha = col.Value.w * t * 0.12f;
        ImU32 c = ColToU32(ImVec4(col.Value.x, col.Value.y, col.Value.z, alpha));
        dl->AddRect(
            ImVec2(p1.x - expand, p1.y - expand),
            ImVec2(p2.x + expand, p2.y + expand),
            c, radius + expand * 0.3f, 0, 1.0f + t * 1.5f);
    }
}

TabManager::TabManager() : tabCount(0), activeTab(0), previousTab(-1), hoveredTab(-1),
    transitioning(false), transitionProgress(0.0f), transitionTimer(0.0f),
    indicatorPos(AnimFloat(0.0f, 8.0f)), contentSlideX(AnimFloat(0.0f, 5.0f)),
    contentFade(AnimFloat(1.0f, 6.0f)) {}

TabManager::~TabManager() { ShutdownAll(); }

int TabManager::RegisterTab(const char *icon, const char *label, const char *tooltip,
                             TabDrawFunction drawFunc, void (*initFunc)(), void (*shutdownFunc)()) {
    if (tabCount >= MAX_TABS) return -1;
    int idx = tabCount++;
    tabs[idx].icon = icon;
    tabs[idx].label = label;
    tabs[idx].tooltip = tooltip;
    tabs[idx].drawFunc = drawFunc;
    tabs[idx].initFunc = initFunc;
    tabs[idx].shutdownFunc = shutdownFunc;
    tabs[idx].isInitialized = false;
    tabs[idx].isEnabled = true;
    tabs[idx].scrollPosY = 0.0f;
    tabs[idx].badgeCount = 0;
    return idx;
}

bool TabManager::SetActive(int index) {
    if (index < 0 || index >= tabCount) return false;
    if (!tabs[index].isEnabled) return false;
    if (index == activeTab) return true;
    previousTab = activeTab;
    activeTab = index;
    transitioning = true;
    transitionProgress = 0.0f;
    transitionTimer = 0.0f;
    contentSlideX.Set(-30.0f);
    contentSlideX.SetTarget(0.0f);
    contentFade.Set(0.5f);
    contentFade.SetTarget(1.0f);
    g_PreviousTab = previousTab;
    g_ActiveTab = index;
    g_TabTransitionActive = true;
    g_TabTransitionProgress = 0.0f;
    if (g_Callbacks.onTabChange) {
        LayoutEvent ev;
        ev.type = LayoutEvent::TAB_CHANGE;
        ev.data.tabIndex = index;
        ev.timestamp = g_GlobalTime;
        g_Callbacks.onTabChange(ev);
    }
    return true;
}

int TabManager::GetActive() const { return activeTab; }
int TabManager::GetCount() const { return tabCount; }

int TabManager::GetEnabledCount() const {
    int count = 0;
    for (int i = 0; i < tabCount; i++)
        if (tabs[i].isEnabled) count++;
    return count;
}

TabDefinition* TabManager::GetTab(int index) {
    if (index < 0 || index >= tabCount) return nullptr;
    return &tabs[index];
}

bool TabManager::EnableTab(int index, bool enable) {
    if (index < 0 || index >= tabCount) return false;
    tabs[index].isEnabled = enable;
    return true;
}

bool TabManager::IsTabEnabled(int index) const {
    if (index < 0 || index >= tabCount) return false;
    return tabs[index].isEnabled;
}

bool TabManager::IsTabVisible(int index) const {
    if (index < 0 || index >= tabCount) return false;
    return tabs[index].isEnabled;
}

void TabManager::AnimateSwitch(int newIndex) {
    SetActive(newIndex);
}

float TabManager::GetTransitionProgress() const { return transitionProgress; }
bool TabManager::IsTransitioning() const { return transitioning; }

const char* TabManager::GetTabLabel(int index) const {
    if (index < 0 || index >= tabCount) return "";
    return tabs[index].label;
}

const char* TabManager::GetTabIcon(int index) const {
    if (index < 0 || index >= tabCount) return "";
    return tabs[index].icon;
}

void TabManager::SetBadge(int index, int count) {
    if (index >= 0 && index < tabCount) tabs[index].badgeCount = count;
}

int TabManager::GetBadge(int index) const {
    if (index < 0 || index >= tabCount) return 0;
    return tabs[index].badgeCount;
}

void TabManager::UpdateAnimations() {
    indicatorPos.Update();
    contentSlideX.Update();
    contentFade.Update();
    if (transitioning) {
        transitionTimer += ImGui::GetIO().DeltaTime;
        transitionProgress = ImMin(transitionTimer / 0.25f, 1.0f);
        g_TabTransitionProgress = transitionProgress;
        if (transitionProgress >= 1.0f) {
            transitioning = false;
            transitionProgress = 1.0f;
            g_TabTransitionActive = false;
        }
    }
}

void TabManager::ShutdownAll() {
    for (int i = 0; i < tabCount; i++) {
        if (tabs[i].isInitialized && tabs[i].shutdownFunc) {
            tabs[i].shutdownFunc();
            tabs[i].isInitialized = false;
        }
    }
}

void TabManager::InitAll() {
    for (int i = 0; i < tabCount; i++) {
        if (tabs[i].isEnabled && tabs[i].initFunc && !tabs[i].isInitialized) {
            tabs[i].initFunc();
            tabs[i].isInitialized = true;
        }
    }
}

LayoutEngine::LayoutEngine()
    : initialized(false), globalTime(0.0f), pulsePhase(0.0f), breathPhase(0.0f)
    , activeThemePreset(0), configNeedsSave(false)
    , footerToggleState(false), footerPulseTime(0.0f)
    , footerPulseAnim(0.0f, 4.0f)
    , currentGridLayout(ContentGridLayout::FOUR_COLUMN)
    , previousTouchDist(0.0f), wasPinching(false)
    , lastFrameTouchCount(0)
    , dragStarted(false), lastFrameBeginTime(0.0f), lastFrameEndTime(0.0f)
    , frameSkipCounter(0), skipThisFrame(false)
    , espToggleChecksum(0), lastEspToggleChecksum(0), espDirtyFlag(true)
{
    strcpy(versionString, "v2.0.0");
    strcpy(buildDate, "2026-06-14");
    for (int i = 0; i < MAX_TABS; i++) {
        contentScrollPositions[i] = 0.0f;
        tabIconColors[i] = ImColor(100, 100, 130);
        tabIconAnimColors[i] = ImGui::AnimColor(tabIconColors[i], 5.0f);
    }
    for (int i = 0; i < 10; i++) {
        touchStartPos[i] = ImVec2(0, 0);
        touchStartTimes[i] = 0.0f;
        longPressFired[i] = false;
        touchMovedSignificantly[i] = false;
    }
}

LayoutEngine::~LayoutEngine() { Shutdown(); }

bool LayoutEngine::Init() {
    if (initialized) return true;
    initialized = true;
    g_LayoutInitialized = true;
    windowState.size = ImVec2(WINDOW_WIDTH, WINDOW_HEIGHT);
    windowState.animAlpha.Set(0.0f);
    windowState.animAlpha.SetTarget(0.0f);
    windowState.animScale.Set(0.85f);
    windowState.animScale.SetTarget(1.0f);
    windowState.animCorner.Set((float)WINDOW_BORDER_RADIUS);
    windowState.animCorner.SetTarget((float)WINDOW_BORDER_RADIUS);
    CenterWindow();
    return true;
}

void LayoutEngine::Shutdown() {
    if (!initialized) return;
    tabManager.ShutdownAll();
    LayoutEvent ev;
    ev.type = LayoutEvent::WINDOW_CLOSE;
    ev.timestamp = globalTime;
    EmitEvent(ev);
    initialized = false;
    g_LayoutInitialized = false;
}

void LayoutEngine::ToggleWindow() {
    if (windowState.phase == WindowPhase::CLOSED || windowState.phase == WindowPhase::CLOSING) {
        OpenWindow();
    } else {
        CloseWindow();
    }
}

void LayoutEngine::OpenWindow() {
    if (windowState.phase == WindowPhase::OPEN) return;
    windowState.phase = WindowPhase::OPENING;
    windowState.isOpen = true;
    windowState.targetAlpha = 1.0f;
    windowState.targetScale = 1.0f;
    windowState.animAlpha.SetTarget(1.0f);
    windowState.animScale.SetTarget(1.0f);
    if (windowState.position.x == 0 && windowState.position.y == 0)
        CenterWindow();
}

void LayoutEngine::CloseWindow() {
    if (windowState.phase == WindowPhase::CLOSED) return;
    windowState.phase = WindowPhase::CLOSING;
    windowState.targetAlpha = 0.0f;
    windowState.animAlpha.SetTarget(0.0f);
    windowState.animScale.SetTarget(0.85f);
    LayoutEvent ev;
    ev.type = LayoutEvent::WINDOW_CLOSE;
    ev.timestamp = globalTime;
    EmitEvent(ev);
}

bool LayoutEngine::IsWindowOpen() const { return windowState.isOpen; }
WindowPhase LayoutEngine::GetWindowPhase() const { return windowState.phase; }

void LayoutEngine::SetPosition(ImVec2 pos) { windowState.position = pos; }
void LayoutEngine::SetSize(ImVec2 size) {
    windowState.size = ImVec2(
        ImMax(size.x, (float)WINDOW_WIDTH * 0.5f),
        ImMax(size.y, (float)WINDOW_HEIGHT * 0.5f)
    );
    windowState.lastFrameSize = windowState.size;
    dirtyFlags.SetAll();
}

ImVec2 LayoutEngine::GetPosition() const { return windowState.position; }
ImVec2 LayoutEngine::GetSize() const { return windowState.size; }

void LayoutEngine::SetScale(float s) {
    windowState.targetScale = ImClamp(s, MIN_WINDOW_SCALE, MAX_WINDOW_SCALE);
    windowState.animScale.SetTarget(windowState.targetScale);
}

float LayoutEngine::GetScale() const { return windowState.animScale.Get(); }

void LayoutEngine::SetCornerRadius(float r) {
    windowState.cornerRadius = r;
    windowState.animCorner.SetTarget(r);
}

float LayoutEngine::GetCornerRadius() const { return windowState.animCorner.Get(); }

void LayoutEngine::CenterWindow() {
    windowState.position = ImVec2(
        (g_ScreenSize.x - windowState.size.x * windowState.animScale.Get()) * 0.5f,
        (g_ScreenSize.y - windowState.size.y * windowState.animScale.Get()) * 0.5f
    );
}

void LayoutEngine::SnapToEdges() {
    if (!windowState.snapEnabled) return;
    float margin = (float)windowState.snapMargin;
    float w = windowState.size.x * windowState.animScale.Get();
    float h = windowState.size.y * windowState.animScale.Get();
    bool snapped = false;
    if (fabsf(windowState.position.x) < margin) {
        windowState.position.x = 0;
        snapped = true;
    }
    if (fabsf(windowState.position.x + w - g_ScreenSize.x) < margin) {
        windowState.position.x = g_ScreenSize.x - w;
        snapped = true;
    }
    if (fabsf(windowState.position.y) < margin) {
        windowState.position.y = 0;
        snapped = true;
    }
    if (fabsf(windowState.position.y + h - g_ScreenSize.y) < margin) {
        windowState.position.y = g_ScreenSize.y - h;
        snapped = true;
    }
    if (snapped) {
        LayoutEvent ev;
        ev.type = LayoutEvent::SNAP_OCCURRED;
        ev.timestamp = globalTime;
        EmitEvent(ev);
    }
}

void LayoutEngine::ApplyWindowConstraints() {
    float margin = (float)windowState.snapMargin;
    float w = windowState.size.x * windowState.animScale.Get();
    float h = windowState.size.y * windowState.animScale.Get();
    windowState.position.x = ImMax(-w + 50.0f, ImMin(windowState.position.x, g_ScreenSize.x - 50.0f));
    windowState.position.y = ImMax(-h + 50.0f, ImMin(windowState.position.y, g_ScreenSize.y - 50.0f));
}

void LayoutEngine::BeginFrame() {
    skipThisFrame = false;
    if (frameTiming.fps < 30.0f && frameTiming.fps > 0.0f) {
        frameSkipCounter++;
        if (frameSkipCounter & 1) {
            skipThisFrame = true;
            return;
        }
    } else {
        frameSkipCounter = 0;
    }
    lastFrameBeginTime = ImGui::GetTime();
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame();
    ImGui::NewFrame();
    UpdateFrameTiming();
    UpdateGlobalTime();
    UpdateAnimations();
    HandleInput();
}

void LayoutEngine::EndFrame() {
    if (skipThisFrame) {
        if (!(frameSkipCounter & 1)) {
            lastFrameEndTime = ImGui::GetTime();
        }
        return;
    }
    double renderStart = ImGui::GetTime();
    ImGui::Render();
    g_RenderMetrics.drawCallCount = ImGui::GetDrawData() ? ImGui::GetDrawData()->CmdListsCount : 0;
    int vtxCount = 0;
    int idxCount = 0;
    if (ImGui::GetDrawData()) {
        for (int i = 0; i < ImGui::GetDrawData()->CmdListsCount; i++) {
            vtxCount += ImGui::GetDrawData()->CmdLists[i]->VtxBuffer.Size;
            idxCount += ImGui::GetDrawData()->CmdLists[i]->IdxBuffer.Size;
        }
    }
    g_RenderMetrics.vertexCount = (float)vtxCount;
    g_RenderMetrics.indexCount = (float)idxCount;
    glClear(GL_COLOR_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    if (eglSwapBuffers(g_EglDisplay, g_EglSurface)) {}
    lastFrameEndTime = ImGui::GetTime();
    g_RenderMetrics.renderTime = (float)((ImGui::GetTime() - renderStart) * 1000.0);
    g_RenderMetrics.eglSwapTime = (lastFrameEndTime - lastFrameBeginTime) * 1000.0f;
    g_RenderMetrics.totalFrameTime = g_RenderMetrics.uiBuildTime + g_RenderMetrics.espRenderTime + g_RenderMetrics.aimbotUpdateTime + g_RenderMetrics.renderTime + g_RenderMetrics.eglSwapTime;
}

void LayoutEngine::MainLayout() {
    if (!initialized || skipThisFrame) return;
    ImGuiIO &io = ImGui::GetIO();
    io.ConfigWindowsMoveFromTitleBarOnly = false;
    if (windowState.phase == WindowPhase::CLOSED) return;
    UpdateDirtyFlags();
    if (windowState.phase == WindowPhase::OPENING) {
        windowState.animAlpha.Update();
        windowState.animScale.Update();
        windowState.animCorner.Update();
        windowState.alpha = windowState.animAlpha.Get();
        windowState.scale = windowState.animScale.Get();
        if (windowState.animAlpha.IsDone() && windowState.animScale.IsDone()) {
            windowState.phase = WindowPhase::OPEN;
            windowState.alpha = 1.0f;
            windowState.scale = 1.0f;
        }
    }
    if (windowState.phase == WindowPhase::CLOSING) {
        windowState.animAlpha.Update();
        windowState.animScale.Update();
        windowState.animCorner.Update();
        windowState.alpha = windowState.animAlpha.Get();
        windowState.scale = windowState.animScale.Get();
        if (windowState.animAlpha.IsDone() && windowState.animScale.IsDone()) {
            windowState.phase = WindowPhase::CLOSED;
            windowState.isOpen = false;
            windowState.alpha = 0.0f;
            return;
        }
    }
    if (windowState.phase == WindowPhase::OPEN) {
        windowState.animAlpha.Update();
        windowState.animScale.Update();
        windowState.animCorner.Update();
        windowState.alpha = windowState.animAlpha.Get();
        windowState.scale = windowState.animScale.Get();
    }
    ApplyWindowConstraints();
    bool isOpen = true;
    float winW = windowState.size.x * windowState.scale;
    float winH = windowState.size.y * windowState.scale;
    ImVec2 scaledPos = windowState.position;
    ImGui::SetNextWindowSize(ImVec2(winW, winH), ImGuiCond_Always);
    ImGui::SetNextWindowPos(scaledPos, ImGuiCond_Always);
    ImGui::SetNextWindowBgAlpha(0.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, windowState.alpha);
    ImGui::Begin("Bugor Engine###LayoutMain", &isOpen,
        ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize);
    g_WindowState = windowState;
    ImDrawList *dl = ImGui::GetWindowDrawList();
    ImVec2 winPos = ImGui::GetWindowPos();
    ImVec2 winSize = ImGui::GetWindowSize();
    DrawBackground(dl);
    DrawTitleBar(dl);
    DrawTabBar(dl);
    DrawContentArea(dl);
    DrawFooter(dl);
    DrawOverlays(dl);
    DrawESPOverlay(dl);
    ImGui::End();
    ImGui::PopStyleVar();
    tabManager.UpdateAnimations();
    ProcessEvents();
    g_RenderMetrics.uiBuildTime = (float)((ImGui::GetTime() - lastFrameBeginTime) * 1000.0);
    if (windowState.lastFrameSize.x != winSize.x || windowState.lastFrameSize.y != winSize.y) {
        LayoutEvent ev;
        ev.type = LayoutEvent::WINDOW_RESIZE;
        ev.timestamp = globalTime;
        EmitEvent(ev);
        windowState.lastFrameSize = winSize;
    }
}

ImVec2 LayoutEngine::GetContentArea() const {
    float scale = windowState.animScale.Get();
    return ImVec2(
        windowState.position.x + TABBAR_WIDTH * scale + CONTENT_PADDING,
        windowState.position.y + TITLEBAR_HEIGHT * scale + CONTENT_PADDING
    );
}

ImVec2 LayoutEngine::GetTabBarArea() const {
    float scale = windowState.animScale.Get();
    return ImVec2(
        windowState.position.x,
        windowState.position.y + TITLEBAR_HEIGHT * scale
    );
}

ImVec2 LayoutEngine::GetTitleBarArea() const {
    return windowState.position;
}

ImVec2 LayoutEngine::GetFooterArea() const {
    float scale = windowState.animScale.Get();
    return ImVec2(
        windowState.position.x,
        windowState.position.y + windowState.size.y * scale - FOOTER_HEIGHT * scale
    );
}

ImRect LayoutEngine::GetContentRect() const {
    float scale = windowState.animScale.Get();
    ImVec2 min(
        windowState.position.x + TABBAR_WIDTH * scale + CONTENT_PADDING,
        windowState.position.y + TITLEBAR_HEIGHT * scale + CONTENT_PADDING
    );
    ImVec2 max(
        windowState.position.x + windowState.size.x * scale - CONTENT_PADDING,
        windowState.position.y + windowState.size.y * scale - FOOTER_HEIGHT * scale - CONTENT_PADDING
    );
    return ImRect(min, max);
}

ImRect LayoutEngine::GetWindowRect() const {
    float scale = windowState.animScale.Get();
    return ImRect(windowState.position,
        ImVec2(
            windowState.position.x + windowState.size.x * scale,
            windowState.position.y + windowState.size.y * scale
        ));
}

float LayoutEngine::GetContentWidth() const {
    float scale = windowState.animScale.Get();
    return windowState.size.x * scale - TABBAR_WIDTH * scale - CONTENT_PADDING * 2;
}

float LayoutEngine::GetContentHeight() const {
    float scale = windowState.animScale.Get();
    return windowState.size.y * scale - TITLEBAR_HEIGHT * scale - FOOTER_HEIGHT * scale - CONTENT_PADDING * 2;
}

float LayoutEngine::GetWindowAlpha() const { return windowState.alpha; }

void LayoutEngine::DrawBackground(ImDrawList *dl) {
    ImVec2 winPos = ImGui::GetWindowPos();
    ImVec2 winSize = ImGui::GetWindowSize();
    float radius = windowState.animCorner.Get();
    ImVec2 br(winPos.x + winSize.x, winPos.y + winSize.y);
    ImGui::PushClipRect(winPos, br, true);
    DrawGlowRect(dl, winPos, br, GetAccent(), radius, 14.0f);
    ImColor bgColor(0.04f, 0.04f, 0.08f, 0.94f * windowState.alpha);
    dl->AddRectFilled(winPos, br, ColToU32(bgColor), radius);
    dl->AddRect(winPos, br,
        ColToU32(ImVec4(1, 1, 1, 0.06f)), radius, 0, 1.0f);
    DrawEffectScanline(dl, winPos, winSize, globalTime * 0.5f);
    DrawEffectVignette(dl, winPos, winSize, 0.3f);
    ImGui::PopClipRect();
}

void LayoutEngine::DrawTitleBar(ImDrawList *dl) {
    ImVec2 winPos = ImGui::GetWindowPos();
    ImVec2 winSize = ImGui::GetWindowSize();
    float titleH = TITLEBAR_HEIGHT * windowState.scale;
    ImVec2 titleEnd(winPos.x + winSize.x, winPos.y + titleH);
    dl->AddRectFilled(winPos, titleEnd,
        ColToU32(ImColor(0.05f, 0.05f, 0.09f, 0.95f * windowState.alpha)), WINDOW_BORDER_RADIUS);
    ImGui::PushClipRect(winPos, titleEnd, true);
    dl->AddRectFilled(ImVec2(winPos.x, winPos.y + WINDOW_BORDER_RADIUS), titleEnd,
        ColToU32(ImColor(0.05f, 0.05f, 0.09f, 0.95f * windowState.alpha)), 0);
    ImGui::PopClipRect();
    dl->AddRectFilledMultiColor(
        ImVec2(winPos.x, winPos.y + titleH - 3),
        ImVec2(winPos.x + winSize.x, winPos.y + titleH),
        ColToU32(ImVec4(GetAccent().Value.x, GetAccent().Value.y, GetAccent().Value.z, windowState.alpha)),
        ColToU32(ImVec4(GetAccent2().Value.x, GetAccent2().Value.y, GetAccent2().Value.z, windowState.alpha)),
        ColToU32(ImVec4(GetAccent2().Value.x, GetAccent2().Value.y, GetAccent2().Value.z, windowState.alpha)),
        ColToU32(ImVec4(GetAccent().Value.x, GetAccent().Value.y, GetAccent().Value.z, windowState.alpha)));
    float glowAlpha = 0.3f + 0.1f * sinf(globalTime * 2.0f);
    dl->AddRectFilledMultiColor(
        ImVec2(winPos.x, winPos.y + titleH - 5),
        ImVec2(winPos.x + winSize.x, winPos.y + titleH - 3),
        ColToU32(ImVec4(GetAccent().Value.x, GetAccent().Value.y, GetAccent().Value.z, glowAlpha * 0.3f * windowState.alpha)),
        ColToU32(ImVec4(GetAccent2().Value.x, GetAccent2().Value.y, GetAccent2().Value.z, glowAlpha * 0.3f * windowState.alpha)),
        ColToU32(ImVec4(GetAccent2().Value.x, GetAccent2().Value.y, GetAccent2().Value.z, glowAlpha * 0.3f * windowState.alpha)),
        ColToU32(ImVec4(GetAccent().Value.x, GetAccent().Value.y, GetAccent().Value.z, glowAlpha * 0.3f * windowState.alpha)));
    ImVec2 titlePos(winPos.x + 16, winPos.y + (titleH - 18.0f) * 0.5f - 2);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 18.0f, titlePos,
        ColToU32(ImVec4(GetAccent().Value.x, GetAccent().Value.y, GetAccent().Value.z, windowState.alpha)), "BUGOR ENGINE");
    ImVec2 verPos(titlePos.x + ImGui::CalcTextSize("BUGOR ENGINE").x + 8, titlePos.y + 2);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 11.0f, verPos,
        ColToU32(ImVec4(100.0f/255, 100.0f/255, 140.0f/255, windowState.alpha)), versionString);
    float rightOffset = 50.0f;
    ImVec2 closePos(winPos.x + winSize.x - rightOffset, winPos.y + (titleH - 26.0f) * 0.5f);
    ImVec2 closeSize(28, 26);
    bool closeHovered = ImGui::IsMouseHoveringRect(closePos, ImVec2(closePos.x + closeSize.x, closePos.y + closeSize.y));
    ImU32 closeCol = closeHovered ? ColToU32(ImVec4(1, 0.3f, 0.3f, windowState.alpha)) : ColToU32(ImVec4(0.47f, 0.47f, 0.63f, windowState.alpha));
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 16.0f,
        ImVec2(closePos.x + 6, closePos.y + 3), closeCol, "\xe2\x9c\x96");
    if (closeHovered && ImGui::IsMouseClicked(0)) {
        CloseWindow();
    }
    ImVec2 settingsPos(winPos.x + winSize.x - rightOffset - 36, winPos.y + (titleH - 26.0f) * 0.5f);
    bool setsHovered = ImGui::IsMouseHoveringRect(settingsPos, ImVec2(settingsPos.x + closeSize.x, settingsPos.y + closeSize.y));
    ImU32 setsCol = setsHovered ? ColToU32(ImVec4(0.7f, 0.7f, 1.0f, windowState.alpha)) : ColToU32(ImVec4(0.47f, 0.47f, 0.63f, windowState.alpha));
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 14.0f,
        ImVec2(settingsPos.x + 7, settingsPos.y + 4), setsCol, "\xe2\x9a\x99");
    if (setsHovered && ImGui::IsMouseClicked(0)) {
        tabManager.SetActive(7);
    }
    float titleDragW = winSize.x - 120;
    ImRect titleDragRect(winPos, ImVec2(winPos.x + titleDragW, winPos.y + titleH));
    if (ImGui::IsMouseHoveringRect(titleDragRect.Min, titleDragRect.Max) && ImGui::IsMouseDown(0)) {
        if (!windowState.isDragging) {
            windowState.isDragging = true;
            windowState.dragOffset = ImVec2(
                ImGui::GetIO().MousePos.x - windowState.position.x,
                ImGui::GetIO().MousePos.y - windowState.position.y);
        }
    }
    HandleDrag();
}

void LayoutEngine::DrawTabBar(ImDrawList *dl) {
    ImVec2 winPos = ImGui::GetWindowPos();
    ImVec2 winSize = ImGui::GetWindowSize();
    float scale = windowState.scale;
    float titleH = TITLEBAR_HEIGHT * scale;
    float tabW = TABBAR_WIDTH * scale;
    float contentH = winSize.y - titleH - FOOTER_HEIGHT * scale;
    ImVec2 tabStart(winPos.x, winPos.y + titleH);
    ImVec2 tabEnd(winPos.x + tabW, winPos.y + titleH + contentH);
    ImGui::PushClipRect(tabStart, tabEnd, true);
    dl->AddRectFilled(tabStart, tabEnd,
        ColToU32(ImVec4(0.06f, 0.06f, 0.1f, 0.6f * windowState.alpha)), 0);
    dl->AddLine(ImVec2(tabEnd.x, tabStart.y), ImVec2(tabEnd.x, tabEnd.y),
        ColToU32(ImVec4(1, 1, 1, 0.06f * windowState.alpha)), 1.0f);
    float tabHeight = 54.0f * scale;
    float tabGap = 2.0f;
    float startY = tabStart.y + 8.0f * scale;
    int visCount = tabManager.GetEnabledCount();
    float targetIndicator = (float)tabManager.GetActive() * (tabHeight + tabGap);
    tabManager.indicatorPos.SetTarget(targetIndicator);
    tabManager.indicatorPos.Update();
    for (int i = 0; i < tabManager.GetCount(); i++) {
        if (!tabManager.IsTabEnabled(i)) continue;
        ImVec2 tabPos(tabStart.x, startY + i * (tabHeight + tabGap));
        ImVec2 tabSize(tabW, tabHeight);
        bool isActive = (tabManager.GetActive() == i);
        bool isHovered = false;
        ImRect tabRect(tabPos, ImVec2(tabPos.x + tabSize.x, tabPos.y + tabSize.y));
        if (ImGui::IsMouseHoveringRect(tabRect.Min, tabRect.Max)) {
            isHovered = true;
            g_HoveredTab = i;
        }
        if (isActive) {
            ImColor activeBg = GetAccent();
            activeBg.Value.w = 0.15f * windowState.alpha;
            dl->AddRectFilled(tabPos, ImVec2(tabPos.x + tabSize.x, tabPos.y + tabSize.y),
                ColToU32(activeBg), 0);
            dl->AddRectFilled(
                ImVec2(tabPos.x, tabPos.y + 4),
                ImVec2(tabPos.x + 3, tabPos.y + tabSize.y - 4),
                ColToU32(GetAccent()), 2.0f);
        } else if (isHovered) {
            dl->AddRectFilled(tabPos, ImVec2(tabPos.x + tabSize.x, tabPos.y + tabSize.y),
                ColToU32(ImVec4(1, 1, 1, 0.04f * windowState.alpha)), 0);
        }
        {
            int visIdx = 0;
            for (int j = 0; j < i; j++) if (tabManager.IsTabEnabled(j)) visIdx++;
            tabIconAnimColors[i].SetTarget(isActive ? GetAccent() : ImColor(100, 100, 130));
            tabIconAnimColors[i].Update();
            ImColor iconCol = tabIconAnimColors[i].Get();
            ImColor textCol = isActive ? GetTextCol() : ImColor(130, 130, 160);
            textCol.Value.w *= windowState.alpha;
            iconCol.Value.w *= windowState.alpha;
            float iconSize = 16.0f * scale;
            float labelSize = 11.0f * scale;
            ImVec2 iconPos(tabPos.x + 14 * scale, tabPos.y + 10 * scale);
            dl->AddText(ImGui::GetIO().Fonts->Fonts[0], iconSize, iconPos,
                ColToU32(iconCol), tabManager.GetTabIcon(i));
            ImVec2 labelPos(tabPos.x + 14 * scale, tabPos.y + 30 * scale);
            dl->AddText(ImGui::GetIO().Fonts->Fonts[0], labelSize, labelPos,
                ColToU32(textCol), tabManager.GetTabLabel(i));
            if (tabManager.GetBadge(i) > 0) {
                char badgeStr[8];
                snprintf(badgeStr, sizeof(badgeStr), "%d", tabManager.GetBadge(i));
                ImVec2 badgePos(tabPos.x + tabSize.x - 18 * scale, tabPos.y + 4 * scale);
                float badgeR = 8.0f * scale;
                dl->AddCircleFilled(
                    ImVec2(badgePos.x + badgeR, badgePos.y + badgeR),
                    badgeR, ColToU32(ImColor(255, 50, 50, (int)(255 * windowState.alpha))), 16);
                dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 9.0f * scale,
                    ImVec2(badgePos.x + badgeR * 0.5f, badgePos.y + badgeR * 0.3f),
                    ColToU32(ImColor(255, 255, 255, (int)(255 * windowState.alpha))), badgeStr);
            }
            if (isHovered && tabManager.GetTab(i)->tooltip) {
                ImGui::BeginTooltip();
                ImGui::Text("%s", tabManager.GetTab(i)->tooltip);
                ImGui::EndTooltip();
            }
        }
    }
    float indY = startY + tabManager.indicatorPos.Get();
    ImColor indCol = GetAccent();
    indCol.Value.w = 0.5f * windowState.alpha;
    dl->AddRectFilled(
        ImVec2(tabStart.x + 2, indY + tabHeight - 2),
        ImVec2(tabEnd.x - 2, indY + tabHeight),
        ColToU32(indCol), 1.0f);
    ImGui::PopClipRect();
}

void LayoutEngine::DrawContentArea(ImDrawList *dl) {
    ImVec2 winPos = ImGui::GetWindowPos();
    ImVec2 winSize = ImGui::GetWindowSize();
    float scale = windowState.scale;
    float titleH = TITLEBAR_HEIGHT * scale;
    float tabW = TABBAR_WIDTH * scale;
    float footerH = FOOTER_HEIGHT * scale;
    float contentX = winPos.x + tabW + CONTENT_PADDING * scale;
    float contentY = winPos.y + titleH + CONTENT_PADDING * scale;
    float contentW = winSize.x - tabW - CONTENT_PADDING * 2 * scale;
    float contentH = winSize.y - titleH - footerH - CONTENT_PADDING * 2 * scale;
    ImVec2 contentTL(contentX, contentY);
    ImVec2 contentBR(contentX + contentW, contentY + contentH);
    dl->PushClipRect(contentTL, contentBR, true);
    float transProgress = tabManager.GetTransitionProgress();
    bool transActive = tabManager.IsTransitioning();
    float slideOffset = tabManager.contentSlideX.Get();
    float fadeVal = tabManager.contentFade.Get();
    ImGui::SetCursorScreenPos(ImVec2(
        contentX + CONTENT_PADDING * scale + (transActive ? slideOffset : 0),
        contentY + CONTENT_PADDING * scale
    ));
    ImGui::BeginGroup();
    if (transActive) {
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, fadeVal * windowState.alpha);
    } else {
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, windowState.alpha);
    }
    ImVec2 childSize(contentW - CONTENT_PADDING * 2 * scale, contentH - CONTENT_PADDING * 2 * scale);
    ImGui::BeginChild("ContentArea", childSize, false,
        ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoTitleBar);
    if (g_Callbacks.onFrameBegin) g_Callbacks.onFrameBegin();
    int activeIdx = tabManager.GetActive();
    TabDefinition *tab = tabManager.GetTab(activeIdx);
    if (tab && tab->drawFunc) {
        ImVec2 cPos = ImGui::GetCursorScreenPos();
        ImVec2 cSize = ImGui::GetContentRegionAvail();
        tab->drawFunc(dl, cPos, cSize);
    }
    if (g_Callbacks.onFrameEnd) g_Callbacks.onFrameEnd();
    if (tab) contentScrollPositions[activeIdx] = ImGui::GetScrollY();
    ImGui::EndChild();
    ImGui::PopStyleVar();
    ImGui::EndGroup();
    dl->PopClipRect();
}

void LayoutEngine::DrawFooter(ImDrawList *dl) {
    ImVec2 winPos = ImGui::GetWindowPos();
    ImVec2 winSize = ImGui::GetWindowSize();
    float scale = windowState.scale;
    float footerH = FOOTER_HEIGHT * scale;
    float footY = winPos.y + winSize.y - footerH;
    ImVec2 footTL(winPos.x, footY);
    ImVec2 footBR(winPos.x + winSize.x, footY + footerH);
    ImGui::PushClipRect(footTL, footBR, true);
    dl->AddRectFilled(footTL, footBR,
        ColToU32(ImVec4(0.05f, 0.05f, 0.09f, 0.92f * windowState.alpha)), 0);
    dl->AddLine(footTL, ImVec2(footBR.x, footTL.y),
        ColToU32(ImVec4(1, 1, 1, 0.05f * windowState.alpha)), 1.0f);
    footerPulseTime += ImGui::GetIO().DeltaTime;
    footerPulseAnim.SetTarget(0.5f + 0.5f * sinf(footerPulseTime * 3.0f));
    footerPulseAnim.Update();
    float pulse = footerPulseAnim.Get();
    float btnWidth = 140.0f * scale;
    float btnHeight = 30.0f * scale;
    float btnX = footTL.x + 12.0f * scale;
    float btnY = footTL.y + (footerH - btnHeight) * 0.5f;
    ImColor btnActiveCol = ImColor(0, 200, 80, (int)(255 * windowState.alpha));
    ImColor btnInactiveCol = ImColor(200, 50, 50, (int)(255 * windowState.alpha));
    bool isActive = g_FooterToggleState;
    dl->AddRectFilled(ImVec2(btnX, btnY), ImVec2(btnX + btnWidth, btnY + btnHeight),
        ColToU32(isActive ?
            ImVec4(0, 0.78f * pulse, 0.3f * pulse, 0.9f * windowState.alpha) :
            ImVec4(0.78f * pulse, 0, 0, 0.9f * windowState.alpha)),
        6.0f * scale);
    if (isActive) {
        dl->AddRectFilledMultiColor(
            ImVec2(btnX, btnY), ImVec2(btnX + btnWidth, btnY + btnHeight),
            ColToU32(ImVec4(0, 0.9f, 0.4f, 0.3f * windowState.alpha)),
            ColToU32(ImVec4(0, 0.5f, 0.2f, 0.1f * windowState.alpha)),
            ColToU32(ImVec4(0, 0.9f, 0.4f, 0.3f * windowState.alpha)),
            ColToU32(ImVec4(0, 0.5f, 0.2f, 0.1f * windowState.alpha)));
    }
    dl->AddRect(ImVec2(btnX, btnY), ImVec2(btnX + btnWidth, btnY + btnHeight),
        ColToU32(ImVec4(1, 1, 1, 0.15f * windowState.alpha)), 6.0f * scale, 0, 1.0f);
    const char *btnLabel = isActive ? "ACTIVE" : "INACTIVE";
    ImVec2 btnLabelSize = ImGui::CalcTextSize(btnLabel);
    ImVec2 btnLabelPos(btnX + (btnWidth - btnLabelSize.x) * 0.5f,
                       btnY + (btnHeight - btnLabelSize.y) * 0.5f);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 12.0f * scale, btnLabelPos,
        ColToU32(ImVec4(1, 1, 1, windowState.alpha)), btnLabel);
    ImRect btnRect(ImVec2(btnX, btnY), ImVec2(btnX + btnWidth, btnY + btnHeight));
    if (ImGui::IsMouseHoveringRect(btnRect.Min, btnRect.Max) && ImGui::IsMouseClicked(0)) {
        g_FooterToggleState = !g_FooterToggleState;
        LayoutEvent ev;
        ev.type = LayoutEvent::TOGGLE_ACTIVE;
        ev.data.toggleState = g_FooterToggleState;
        ev.timestamp = globalTime;
        EmitEvent(ev);
        if (g_Callbacks.onToggleActive) g_Callbacks.onToggleActive(ev);
    }
    float infoX = btnX + btnWidth + 16.0f * scale;
    char fpsStr[64];
    snprintf(fpsStr, sizeof(fpsStr), "FPS:%d DC:%.0f Vtx:%.0f", (int)frameTiming.fps,
        g_RenderMetrics.drawCallCount, g_RenderMetrics.vertexCount);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 10.0f * scale,
        ImVec2(infoX, btnY + 2),
        ColToU32(ImVec4(0, 1, 0.5f, windowState.alpha)), fpsStr);
    char timeStr[64];
    snprintf(timeStr, sizeof(timeStr), "UI:%.1f ESP:%.1f Aim:%.1f",
        g_RenderMetrics.uiBuildTime, g_RenderMetrics.espRenderTime, g_RenderMetrics.aimbotUpdateTime);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 10.0f * scale,
        ImVec2(infoX, btnY + 14),
        ColToU32(ImVec4(0.5f, 0.8f, 1, windowState.alpha)), timeStr);
    float memX = infoX;
    float memY = btnY + btnHeight * 0.55f;
    float memW = 120 * scale;
    float memH = 6 * scale;
    dl->AddRectFilled(ImVec2(memX, memY), ImVec2(memX + memW, memY + memH),
        ColToU32(ImVec4(0.08f, 0.08f, 0.12f, 0.8f * windowState.alpha)), 3 * scale);
    float memUsage = 0.62f;
    ImVec2 memFillEnd(memX + memW * memUsage, memY + memH);
    ImColor memGradA = GetAccent();
    memGradA.Value.w *= windowState.alpha;
    ImColor memGradB = GetAccent2();
    memGradB.Value.w *= windowState.alpha;
    dl->AddRectFilledMultiColor(ImVec2(memX, memY), memFillEnd,
        ColToU32(memGradA), ColToU32(memGradB), ColToU32(memGradB), ColToU32(memGradA), 3 * scale);
    float verX = footBR.x - 10 * scale - ImGui::CalcTextSize(versionString).x;
    float verY = btnY + (btnHeight - 12 * scale) * 0.5f;
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 11.0f * scale,
        ImVec2(verX, verY),
        ColToU32(ImVec4(0.5f, 0.5f, 0.7f, windowState.alpha)), versionString);
    float saveBtnX = verX - 50 * scale;
    ImVec2 saveBtnPos(saveBtnX, btnY);
    ImVec2 saveBtnSize(40 * scale, btnHeight);
    dl->AddRectFilled(saveBtnPos, ImVec2(saveBtnPos.x + saveBtnSize.x, saveBtnPos.y + saveBtnSize.y),
        ColToU32(ImVec4(0.2f, 0.5f, 0.8f, 0.7f * windowState.alpha)), 6 * scale);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 9.0f * scale,
        ImVec2(saveBtnPos.x + 6 * scale, saveBtnPos.y + 6 * scale),
        ColToU32(ImVec4(1, 1, 1, windowState.alpha)), "\xe2\x86\x93");
    ImRect saveRect(saveBtnPos, ImVec2(saveBtnPos.x + saveBtnSize.x, saveBtnPos.y + saveBtnSize.y));
    if (ImGui::IsMouseHoveringRect(saveRect.Min, saveRect.Max) && ImGui::IsMouseClicked(0)) {
        RequestConfigSave();
        LayoutEvent ev;
        ev.type = LayoutEvent::CONFIG_SAVE;
        ev.timestamp = globalTime;
        EmitEvent(ev);
        if (g_Callbacks.onConfigSave) g_Callbacks.onConfigSave(ev);
    }
    ImGui::PopClipRect();
}

void LayoutEngine::DrawOverlays(ImDrawList *dl) {
    DrawWatermarkOverlay(dl);
    DrawNotificationOverlay(dl);
    DrawCompassOverlay(dl);
    for (auto &overlay : externalOverlays) {
        overlay(dl, ImVec2(0,0), g_ScreenSize, windowState.alpha);
    }
    if (g_Callbacks.onOverlayPre) g_Callbacks.onOverlayPre(dl);
    DrawEffectParticleSpawn(dl, ImVec2(0,0), g_ScreenSize, 0.3f);
    DrawEffectDataStream(dl, ImVec2(0,0), g_ScreenSize, 8);
    if (g_Tog.Particles) {
        float dt = ImGui::GetIO().DeltaTime;
        UpdateFireworks(dl);
        RenderTrail(dl);
    }
    if (g_Callbacks.onOverlayPost) g_Callbacks.onOverlayPost(dl);
}

void LayoutEngine::DrawESPOverlay(ImDrawList *dl) {
    if (!ImGui::IsRectVisible(ImVec2(0,0), ImGui::GetIO().DisplaySize)) return;
    if (g_Callbacks.onOverlayPost) {
        g_Callbacks.onOverlayPost(dl);
    }
}

void LayoutEngine::DrawWatermarkOverlay(ImDrawList *dl) {
    if (!g_Tog.ShowWatermark) return;
    g_WatermarkTime += ImGui::GetIO().DeltaTime;
    g_WatermarkFloat.SetTarget(sinf(g_WatermarkTime * 1.5f) * 1.5f);
    g_WatermarkFloat.Update();
    float floatOffset = g_WatermarkFloat.Get();
    ImVec2 wmPos(12, 10 + floatOffset);
    ImVec2 wmSize(240, 36);
    ImColor bgCol(5, 5, 15, 180);
    dl->AddRectFilled(wmPos, ImVec2(wmPos.x + wmSize.x, wmPos.y + wmSize.y), ColToU32(bgCol), 6.0f);
    dl->AddRect(wmPos, ImVec2(wmPos.x + wmSize.x, wmPos.y + wmSize.y),
        ColToU32(GetAccent()), 6.0f, 0, 1.5f);
    char wmText[64];
    snprintf(wmText, sizeof(wmText), "BUGOR ENGINE %s  |  %d FPS",
        versionString, (int)frameTiming.fps);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 13.0f,
        ImVec2(wmPos.x + 12, wmPos.y + 9),
        ColToU32(ImColor(200, 200, 230)), wmText);
}

static float g_WatermarkTime = 0.0f;
static ImGui::AnimFloat g_WatermarkFloat(0.0f, 3.0f);

void LayoutEngine::DrawNotificationOverlay(ImDrawList *dl) {
    static float notifTime = 0.0f;
    static char notifText[128] = {0};
    static ImColor notifColor;
    static bool hasNotif = false;
    static ImGui::AnimFloat notifSlide(0.0f, 5.0f);
    static ImGui::AnimFloat notifAlpha(0.0f, 4.0f);
    static float notifDuration = 2.5f;
    notifSlide.Update();
    notifAlpha.Update();
    if (!hasNotif) {
        if (windowState.phase == WindowPhase::OPEN) {
            strncpy(notifText, "Bugor Engine Loaded", sizeof(notifText) - 1);
            notifColor = GetAccent();
            notifTime = 0.0f;
            hasNotif = true;
            notifSlide.Set(-80.0f);
            notifSlide.SetTarget(12.0f);
            notifAlpha.Set(0.0f);
            notifAlpha.SetTarget(1.0f);
        }
    }
    if (!hasNotif) return;
    notifTime += ImGui::GetIO().DeltaTime;
    ImVec2 screenSize = ImGui::GetIO().DisplaySize;
    ImVec2 textSize = ImGui::CalcTextSize(notifText);
    float notifWidth = textSize.x + 32.0f;
    float notifHeight = 40.0f;
    ImVec2 notifPos(notifSlide.Get(), 60.0f);
    ImVec2 notifEnd(notifPos.x + notifWidth, notifPos.y + notifHeight);
    ImColor bg(5, 5, 15, (int)(200 * notifAlpha.Get()));
    dl->AddRectFilled(notifPos, notifEnd, ColToU32(bg), 8.0f);
    dl->AddRect(notifPos, notifEnd, ColToU32(notifColor), 8.0f, 0, 1.5f);
    dl->AddRectFilled(notifPos, ImVec2(notifPos.x + 3, notifEnd.y), ColToU32(notifColor), 8.0f);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 14.0f,
        ImVec2(notifPos.x + 16, notifPos.y + (notifHeight - 16.0f) * 0.5f),
        ColToU32(ImVec4(1, 1, 1, notifAlpha.Get())), notifText);
    if (notifTime >= notifDuration) {
        notifAlpha.SetTarget(0.0f);
        notifSlide.SetTarget(-notifWidth - 20.0f);
        if (notifAlpha.IsDone() && notifSlide.IsDone()) {
            hasNotif = false;
        }
    }
}

void LayoutEngine::DrawCompassOverlay(ImDrawList *dl) {
    DrawCompass(dl, g_Offsets.CameraYaw);
}

void LayoutEngine::HandleInput() {
    ImGuiIO &io = ImGui::GetIO();
    inputState.anyDown = io.MouseDown[0];
    inputState.anyPressed = io.MouseClicked[0];
    inputState.anyReleased = io.MouseReleased[0];
    inputState.mousePos = io.MousePos;
    inputState.mouseDelta = io.MouseDelta;
    inputState.mouseWheel = io.MouseWheel;
    inputState.backButtonDown = io.NavInputs[ImGuiNavInput_Input];
    if (inputState.anyPressed) {
        inputState.touch.tapDetected = true;
        inputState.touch.tapPosition = io.MousePos;
        inputState.touch.tapTime = globalTime;
    } else {
        inputState.touch.tapDetected = false;
    }
    HandleTouchInput();
    HandleTabInput();
}

void LayoutEngine::HandleTouchInput() {
    ImGuiIO &io = ImGui::GetIO();
    int rawCount = 0;
    const TouchPoint* pts = ImGui_GetTouchPoints(&rawCount);

    TouchState& ts = inputState.touch;
    ts.touchCount = rawCount;
    ts.isPinching = (rawCount >= 2);

    for (int i = 0; i < rawCount && i < MAX_TOUCH_POINTS; i++) {
        const TouchPoint& pt = pts[i];
        if (!pt.active) continue;
        int idx = pt.id;
        if (idx >= 10) continue;
        ts.lastPositions[idx] = ts.positions[idx];
        ts.positions[idx] = pt.pos;
        ts.active[idx] = true;
        if (touchStartTimes[idx] == 0.0f) {
            touchStartTimes[idx] = globalTime;
            touchStartPos[idx] = pt.pos;
            longPressFired[idx] = false;
            touchMovedSignificantly[idx] = false;
        }
        float moveDist = sqrtf(powf(pt.pos.x - touchStartPos[idx].x, 2) + powf(pt.pos.y - touchStartPos[idx].y, 2));
        if (moveDist > 15.0f) touchMovedSignificantly[idx] = true;
    }

    for (int i = 0; i < 10; i++) {
        if (!ts.active[i]) {
            touchStartTimes[i] = 0.0f;
            longPressFired[i] = false;
            touchMovedSignificantly[i] = false;
            ts.lastPositions[i] = ts.positions[i];
            ts.positions[i] = ImVec2(0, 0);
        }
    }

    bool touchWasDown = ts.wasTouching;
    ts.wasTouching = (rawCount > 0);
    ts.wasMultiTouch = (rawCount >= 2);

    if (rawCount == 0 && touchWasDown) {
        ts.swipeActive = false;
        ts.swipeHandled = false;
        ts.rightClickPending = false;
        io.MouseDown[1] = false;
        longPressFired[0] = false;
    }

    HandleLongPress();
    HandleSwipeGesture();
    HandlePinchGesture();

    if (ts.rightClickPending && rawCount == 0) {
        io.MouseDown[1] = false;
        ts.rightClickPending = false;
    }

    ts.pendingSwipeTabDir = 0;
    lastFrameTouchCount = rawCount;
}

void LayoutEngine::HandleLongPress() {
    ImGuiIO& io = ImGui::GetIO();
    TouchState& ts = inputState.touch;
    if (ts.touchCount != 1 || ts.isPinching) {
        ts.rightClickPending = false;
        io.MouseDown[1] = false;
        return;
    }
    const TouchPoint* pts = ImGui_GetTouchPoints(nullptr);
    for (int i = 0; i < MAX_TOUCH_POINTS; i++) {
        if (!pts[i].active) continue;
        int idx = pts[i].id;
        if (idx != 0) continue;
        if (touchMovedSignificantly[idx]) {
            longPressFired[idx] = false;
            ts.rightClickPending = false;
            io.MouseDown[1] = false;
            return;
        }
        float elapsed = globalTime - touchStartTimes[idx];
        if (elapsed > 0.5f && !longPressFired[idx]) {
            longPressFired[idx] = true;
            ts.rightClickPending = true;
            ts.rightClickPos = pts[i].pos;
            io.MouseDown[1] = true;
            io.MousePos = pts[i].pos;
        }
        break;
    }
    if (ts.rightClickPending) {
        io.MouseDown[1] = true;
    }
}

void LayoutEngine::HandleSwipeGesture() {
    ImGuiIO& io = ImGui::GetIO();
    TouchState& ts = inputState.touch;
    if (ts.touchCount != 1 || ts.isPinching) {
        ts.swipeActive = false;
        return;
    }
    const TouchPoint* pts = ImGui_GetTouchPoints(nullptr);
    for (int i = 0; i < MAX_TOUCH_POINTS; i++) {
        if (!pts[i].active) continue;
        int idx = pts[i].id;
        if (idx != 0) continue;
        ImVec2 delta(pts[i].pos.x - touchStartPos[idx].x, pts[i].pos.y - touchStartPos[idx].y);
        float dist = sqrtf(delta.x * delta.x + delta.y * delta.y);
        ts.swipeDeltaX = delta.x;
        ts.swipeDeltaY = delta.y;
        if (dist > 20.0f) {
            ts.swipeActive = true;
            float absX = fabsf(delta.x);
            float absY = fabsf(delta.y);
            float scrollScale = 0.05f;
            if (absX > absY) {
                ts.scrollAccumX += delta.x * scrollScale;
                int scrollDir = (ts.scrollAccumX > 0) ? 1 : -1;
                int scrollSteps = (int)(fabsf(ts.scrollAccumX) / 1.0f);
                if (scrollSteps > 0) {
                    io.MouseWheelH = (float)(-scrollDir * scrollSteps);
                    ts.scrollAccumX -= scrollDir * scrollSteps;
                }
                if (fabsf(delta.x) > 120.0f && !ts.swipeHandled) {
                    ts.swipeHandled = true;
                    ts.pendingSwipeTabDir = (delta.x > 0) ? 1 : -1;
                }
            } else {
                ts.scrollAccumY += delta.y * scrollScale;
                int scrollDir = (ts.scrollAccumY > 0) ? 1 : -1;
                int scrollSteps = (int)(fabsf(ts.scrollAccumY) / 1.0f);
                if (scrollSteps > 0) {
                    io.MouseWheel = (float)(-scrollDir * scrollSteps);
                    ts.scrollAccumY -= scrollDir * scrollSteps;
                }
            }
        } else {
            ts.scrollAccumX = 0;
            ts.scrollAccumY = 0;
        }
        break;
    }

    if (ts.pendingSwipeTabDir != 0 && ts.touchCount == 1) {
        int cur = tabManager.GetActive();
        int next = cur + ts.pendingSwipeTabDir;
        if (next >= 0 && next < tabManager.GetCount() && tabManager.IsTabEnabled(next)) {
            tabManager.AnimateSwitch(next);
        }
        ts.pendingSwipeTabDir = 0;
    }
}

void LayoutEngine::HandlePinchGesture() {
    TouchState& ts = inputState.touch;
    if (ts.touchCount < 2) {
        wasPinching = false;
        previousTouchDist = 0.0f;
        ts.isPinching = false;
        return;
    }
    const TouchPoint* pts = ImGui_GetTouchPoints(nullptr);
    ImVec2 t1, t2;
    bool found1 = false, found2 = false;
    for (int i = 0; i < MAX_TOUCH_POINTS; i++) {
        if (!pts[i].active) continue;
        if (!found1) { t1 = pts[i].pos; found1 = true; }
        else if (!found2) { t2 = pts[i].pos; found2 = true; break; }
    }
    if (!found1 || !found2) return;
    float dist = sqrtf(powf(t2.x - t1.x, 2) + powf(t2.y - t1.y, 2));
    if (previousTouchDist == 0.0f) {
        previousTouchDist = dist;
        ts.pinchCenter = ImVec2((t1.x + t2.x) * 0.5f, (t1.y + t2.y) * 0.5f);
        wasPinching = true;
        return;
    }
    float scaleDelta = dist / previousTouchDist;
    if (fabsf(scaleDelta - 1.0f) > 0.02f) {
        float newScale = windowState.targetScale * scaleDelta;
        newScale = ImClamp(newScale, MIN_WINDOW_SCALE, MAX_WINDOW_SCALE);
        SetScale(newScale);
        LayoutEvent ev;
        ev.type = LayoutEvent::PINCH_SCALE;
        ev.data.scaleFactor = newScale;
        ev.timestamp = globalTime;
        EmitEvent(ev);
    }
    previousTouchDist = dist;
    ts.pinchCenter = ImVec2((t1.x + t2.x) * 0.5f, (t1.y + t2.y) * 0.5f);
    wasPinching = true;
}

void LayoutEngine::HandleDrag() {
    if (!windowState.isDragging) return;
    ImGuiIO &io = ImGui::GetIO();
    if (io.MouseDown[0]) {
        windowState.position.x = io.MousePos.x - windowState.dragOffset.x;
        windowState.position.y = io.MousePos.y - windowState.dragOffset.y;
        SnapToEdges();
        LayoutEvent ev;
        ev.type = LayoutEvent::WINDOW_MOVE;
        ev.timestamp = globalTime;
        EmitEvent(ev);
        if (g_Callbacks.onWindowMove) g_Callbacks.onWindowMove(ev);
    } else {
        windowState.isDragging = false;
    }
}

void LayoutEngine::HandleTabInput() {
    ImGuiIO &io = ImGui::GetIO();
    g_HoveredTab = -1;
    if (!io.MouseClicked[0]) return;
    ImVec2 winPos = ImGui::GetWindowPos();
    float scale = windowState.scale;
    float titleH = TITLEBAR_HEIGHT * scale;
    float tabW = TABBAR_WIDTH * scale;
    float tabHeight = 54.0f * scale;
    float tabGap = 2.0f;
    float startY = winPos.y + titleH + 8.0f * scale;
    for (int i = 0; i < tabManager.GetCount(); i++) {
        if (!tabManager.IsTabEnabled(i)) continue;
        ImVec2 tabPos(winPos.x, startY + i * (tabHeight + tabGap));
        ImVec2 tabSize(tabW, tabHeight);
        ImRect tabRect(tabPos, ImVec2(tabPos.x + tabSize.x, tabPos.y + tabSize.y));
        if (tabRect.Contains(io.MousePos)) {
            if (tabManager.GetActive() != i) {
                tabManager.AnimateSwitch(i);
            }
            break;
        }
    }
}

void LayoutEngine::UpdateFrameTiming() {
    ImGuiIO &io = ImGui::GetIO();
    frameTiming.deltaTime = io.DeltaTime;
    frameTiming.frameTimeMs = io.DeltaTime * 1000.0f;
    frameTiming.frameCount++;
    frameTiming.frameNumber++;
    frameTiming.fpsTimer += io.DeltaTime;
    frameTiming.fpsCounter++;
    if (frameTiming.fpsTimer >= 1.0f) {
        frameTiming.fps = (float)frameTiming.fpsCounter / frameTiming.fpsTimer;
        frameTiming.fpsCounter = 0;
        frameTiming.fpsTimer = 0.0f;
    }
    frameTiming.totalTime += io.DeltaTime;
    frameTiming.maxFrameTime = ImMax(frameTiming.maxFrameTime, frameTiming.frameTimeMs);
    frameTiming.minFrameTime = frameTiming.frameTimeMs < frameTiming.minFrameTime ?
        frameTiming.frameTimeMs : frameTiming.minFrameTime;
    frameTiming.avgFrameTime = frameTiming.avgFrameTime * 0.95f + frameTiming.frameTimeMs * 0.05f;
}

void LayoutEngine::UpdateAnimations() {
    windowState.animAlpha.Update();
    windowState.animScale.Update();
    windowState.animCorner.Update();
    pulsePhase += ImGui::GetIO().DeltaTime * 2.0f;
    breathPhase += ImGui::GetIO().DeltaTime * 1.2f;
    if (pulsePhase > 100.0f) pulsePhase -= 100.0f;
    if (breathPhase > 100.0f) breathPhase -= 100.0f;
    g_PulsePhase = pulsePhase;
    g_BreathPhase = breathPhase;
}

void LayoutEngine::UpdateGlobalTime() {
    globalTime += ImGui::GetIO().DeltaTime;
    g_GlobalTime = globalTime;
}

void LayoutEngine::UpdateDirtyFlags() {
    if (dirtyFlags.fullRedraw) return;
    static float lastTime = 0.0f;
    if (globalTime - lastTime > 0.033f) {
        dirtyFlags.fullRedraw = false;
        lastTime = globalTime;
    }
}

TabManager* LayoutEngine::GetTabManager() { return &tabManager; }
WindowState* LayoutEngine::GetWindowState() { return &windowState; }
FrameTiming* LayoutEngine::GetFrameTiming() { return &frameTiming; }
InputState* LayoutEngine::GetInputState() { return &inputState; }
IntegrationCallbacks* LayoutEngine::GetCallbacks() { return &callbacks; }
DirtyFlags* LayoutEngine::GetDirtyFlags() { return &dirtyFlags; }

void LayoutEngine::RegisterEventListener(LayoutEventCallback callback) {
    eventListeners.push_back(callback);
}

void LayoutEngine::EmitEvent(const LayoutEvent &event) {
    std::lock_guard<std::mutex> lock(eventMutex);
    eventQueue.push_back(event);
}

void LayoutEngine::ProcessEvents() {
    std::lock_guard<std::mutex> lock(eventMutex);
    for (auto &ev : eventQueue) {
        for (auto &listener : eventListeners) {
            listener(ev);
        }
    }
    eventQueue.clear();
}

void LayoutEngine::AddExternalOverlay(EffectDrawFunction func) {
    externalOverlays.push_back(func);
}

void LayoutEngine::RemoveExternalOverlay(EffectDrawFunction func) {
    auto it = std::find(externalOverlays.begin(), externalOverlays.end(), func);
    if (it != externalOverlays.end()) externalOverlays.erase(it);
}

void LayoutEngine::ClearExternalOverlays() { externalOverlays.clear(); }
int LayoutEngine::GetExternalOverlayCount() const { return (int)externalOverlays.size(); }

void LayoutEngine::SetContentGridLayout(ContentGridLayout layout) { currentGridLayout = layout; }
ContentGridLayout LayoutEngine::GetContentGridLayout() const { return currentGridLayout; }

void LayoutEngine::RememberContentScroll(int tabIndex, float scrollY) {
    if (tabIndex >= 0 && tabIndex < MAX_TABS) contentScrollPositions[tabIndex] = scrollY;
}

float LayoutEngine::GetContentScroll(int tabIndex) const {
    if (tabIndex >= 0 && tabIndex < MAX_TABS) return contentScrollPositions[tabIndex];
    return 0.0f;
}

void LayoutEngine::RequestConfigSave() { configNeedsSave = true; g_ConfigNeedsSave = true; }
bool LayoutEngine::IsConfigSaveRequested() const { return configNeedsSave; }
void LayoutEngine::ClearConfigSaveRequest() { configNeedsSave = false; g_ConfigNeedsSave = false; }
float LayoutEngine::GetPulsePhase() const { return pulsePhase; }
float LayoutEngine::GetBreathPhase() const { return breathPhase; }

void LayoutEngine::SetVersion(const char *version) {
    strncpy(versionString, version, sizeof(versionString) - 1);
    strncpy(g_VersionString, version, sizeof(g_VersionString) - 1);
}

const char* LayoutEngine::GetVersion() const { return versionString; }

void LayoutEngine::SetBuildDate(const char *date) {
    strncpy(buildDate, date, sizeof(buildDate) - 1);
    strncpy(g_BuildDate, date, sizeof(g_BuildDate) - 1);
}

const char* LayoutEngine::GetBuildDate() const { return buildDate; }
bool LayoutEngine::IsInitialized() const { return initialized; }

void DrawEffectGlow(ImDrawList *dl, ImVec2 pos, ImVec2 size, float intensity) {
    DrawGlowRect(dl, pos, ImVec2(pos.x + size.x, pos.y + size.y),
        ImColor(1,1,1,(int)(255 * intensity)), 10.0f, 10.0f * intensity);
}

void DrawEffectScanline(ImDrawList *dl, ImVec2 pos, ImVec2 size, float time) {
    float scanY = pos.y + fmodf(time * 80.0f, size.y);
    ImColor scanCol(1, 1, 1, 0.03f);
    dl->AddLine(ImVec2(pos.x, scanY), ImVec2(pos.x + size.x, scanY), ColToU32(scanCol), 1.0f);
    ImColor glowCol(1, 1, 1, 0.02f);
    dl->AddRectFilled(ImVec2(pos.x, scanY - 4), ImVec2(pos.x + size.x, scanY + 4),
        ColToU32(glowCol), 0);
}

void DrawEffectGrid(ImDrawList *dl, ImVec2 pos, ImVec2 size, float alpha) {
    float gridSize = 32.0f;
    ImU32 gridCol = ColToU32(ImVec4(1, 1, 1, 0.02f * alpha));
    for (float x = pos.x; x < pos.x + size.x; x += gridSize)
        dl->AddLine(ImVec2(x, pos.y), ImVec2(x, pos.y + size.y), gridCol, 0.5f);
    for (float y = pos.y; y < pos.y + size.y; y += gridSize)
        dl->AddLine(ImVec2(pos.x, y), ImVec2(pos.x + size.x, y), gridCol, 0.5f);
}

void DrawEffectVignette(ImDrawList *dl, ImVec2 pos, ImVec2 size, float intensity) {
    ImVec2 center(pos.x + size.x * 0.5f, pos.y + size.y * 0.5f);
    float maxDist = sqrtf(size.x * size.x + size.y * size.y) * 0.5f;
    int steps = 20;
    for (int i = 0; i < steps; i++) {
        float t = (float)i / (float)steps;
        float alpha = t * t * 0.15f * intensity;
        float radius = maxDist * (1.0f - t * 0.15f);
        dl->AddCircleFilled(center, radius, ColToU32(ImVec4(0, 0, 0, alpha)), 64);
    }
}

void DrawEffectBorderGlow(ImDrawList *dl, ImVec2 pos, ImVec2 size, ImColor col, float pulse) {
    float glow = 4.0f + 2.0f * sinf(pulse);
    ImColor glowCol = col;
    glowCol.Value.w *= 0.3f;
    dl->AddRect(pos, ImVec2(pos.x + size.x, pos.y + size.y),
        ColToU32(glowCol), 0, 0, glow);
}

void DrawEffectParticleSpawn(ImDrawList *dl, ImVec2 pos, ImVec2 size, float density) {
    static struct Particle { float x, y, vx, vy, life, maxLife, size; } particles[64];
    static bool init = false;
    if (!init) {
        for (int i = 0; i < 64; i++) {
            particles[i].x = (float)(rand() % 1000) / 1000.0f * size.x + pos.x;
            particles[i].y = (float)(rand() % 1000) / 1000.0f * size.y + pos.y;
            particles[i].vx = ((float)(rand() % 200) - 100.0f) * 0.2f;
            particles[i].vy = ((float)(rand() % 200) - 100.0f) * 0.2f;
            particles[i].life = (float)(rand() % 1000) / 1000.0f * 4.0f;
            particles[i].maxLife = 4.0f;
            particles[i].size = 1.0f + (float)(rand() % 100) / 100.0f * 2.0f;
        }
        init = true;
    }
    float dt = ImGui::GetIO().DeltaTime;
    for (int i = 0; i < 64; i++) {
        particles[i].x += particles[i].vx * dt;
        particles[i].y += particles[i].vy * dt;
        particles[i].life -= dt;
        if (particles[i].life <= 0) {
            particles[i].x = (float)(rand() % 1000) / 1000.0f * size.x + pos.x;
            particles[i].y = (float)(rand() % 1000) / 1000.0f * size.y + pos.y;
            particles[i].vx = ((float)(rand() % 200) - 100.0f) * 0.2f;
            particles[i].vy = ((float)(rand() % 200) - 100.0f) * 0.2f;
            particles[i].life = particles[i].maxLife;
        }
        float alpha = (particles[i].life / particles[i].maxLife) * density * 0.3f;
        dl->AddCircleFilled(ImVec2(particles[i].x, particles[i].y),
            particles[i].size, ColToU32(ImVec4(0.5f, 0.5f, 1.0f, alpha)), 8);
    }
}

void DrawEffectRipple(ImDrawList *dl, ImVec2 center, float radius, float alpha) {
    dl->AddCircle(center, radius, ColToU32(ImVec4(0.3f, 0.5f, 1.0f, alpha)), 32, 2.0f);
    dl->AddCircleFilled(center, radius * 0.1f, ColToU32(ImVec4(0.3f, 0.5f, 1.0f, alpha * 0.5f)), 16);
}

void DrawEffectLensFlare(ImDrawList *dl, ImVec2 pos, float brightness) {
    float size = 40.0f * brightness;
    dl->AddCircleFilled(pos, size * 0.5f, ColToU32(ImVec4(1, 1, 1, 0.1f * brightness)), 16);
    dl->AddCircleFilled(pos, size * 0.2f, ColToU32(ImVec4(1, 1, 0.8f, 0.3f * brightness)), 12);
    dl->AddLine(ImVec2(pos.x - size, pos.y), ImVec2(pos.x + size, pos.y),
        ColToU32(ImVec4(1, 1, 1, 0.05f * brightness)), 1.0f);
    dl->AddLine(ImVec2(pos.x, pos.y - size), ImVec2(pos.x, pos.y + size),
        ColToU32(ImVec4(1, 1, 1, 0.05f * brightness)), 1.0f);
}

void DrawEffectNoise(ImDrawList *dl, ImVec2 pos, ImVec2 size, float alpha) {
    ImU32 noiseCol = ColToU32(ImVec4(1, 1, 1, 0.01f * alpha));
    for (int i = 0; i < 30; i++) {
        float nx = pos.x + (float)(rand() % (int)size.x);
        float ny = pos.y + (float)(rand() % (int)size.y);
        dl->AddRectFilled(ImVec2(nx, ny), ImVec2(nx + 2, ny + 2), noiseCol, 0);
    }
}

void DrawEffectGradientOverlay(ImDrawList *dl, ImVec2 pos, ImVec2 size, ImColor a, ImColor b, bool vertical) {
    if (vertical) {
        dl->AddRectFilledMultiColor(pos, ImVec2(pos.x + size.x, pos.y + size.y),
            ColToU32(a), ColToU32(a), ColToU32(b), ColToU32(b));
    } else {
        dl->AddRectFilledMultiColor(pos, ImVec2(pos.x + size.x, pos.y + size.y),
            ColToU32(a), ColToU32(b), ColToU32(b), ColToU32(a));
    }
}

void DrawEffectScanlineHUD(ImDrawList *dl, ImVec2 pos, ImVec2 size, float speed) {
    float t = fmodf(g_GlobalTime * speed, 1.0f);
    float scanY = pos.y + t * size.y;
    ImU32 scanCol = ColToU32(ImVec4(0, 0.7f, 1.0f, 0.06f));
    dl->AddLine(ImVec2(pos.x, scanY), ImVec2(pos.x + size.x, scanY), scanCol, 2.0f);
    ImU32 glowCol = ColToU32(ImVec4(0, 0.7f, 1.0f, 0.03f));
    dl->AddRectFilled(ImVec2(pos.x, scanY - 6), ImVec2(pos.x + size.x, scanY + 6), glowCol, 0);
}

void DrawEffectDataStream(ImDrawList *dl, ImVec2 pos, ImVec2 size, int count) {
    static float offsets[64];
    static bool init = false;
    if (!init) {
        for (int i = 0; i < 64; i++) offsets[i] = (float)(rand() % 1000) / 1000.0f;
        init = true;
    }
    float speed = 40.0f;
    for (int i = 0; i < count && i < 64; i++) {
        float x = pos.x + (float)i / (float)count * size.x;
        float y = pos.y + fmodf(g_GlobalTime * speed + offsets[i] * size.y, size.y);
        ImU32 col = ColToU32(ImVec4(0, 0.6f + 0.4f * sinf(offsets[i] * 6.28f), 0.8f, 0.08f));
        dl->AddRectFilled(ImVec2(x, y), ImVec2(x + 1, y + 8), col, 0);
    }
}

void InitTabESP() {}
void InitTabAimbot() {}
void InitTabMisc() {}
void InitTabSkin() {}
void InitTabRadar() {}
void InitTabLoot() {}
void InitTabPlayers() {}
void InitTabTheme() {}
void ShutdownTabESP() {}
void ShutdownTabAimbot() {}
void ShutdownTabMisc() {}
void ShutdownTabSkin() {}
void ShutdownTabRadar() {}
void ShutdownTabLoot() {}
void ShutdownTabPlayers() {}
void ShutdownTabTheme() {}

static void RegisterDefaultTabs() {
    g_Layout.GetTabManager()->RegisterTab("\xe2\x97\x88", "ESP", "Player & Item ESP settings",
        DrawTabESP, InitTabESP, ShutdownTabESP);
    g_Layout.GetTabManager()->RegisterTab("\xe2\x96\xb6", "AIM", "Aimbot configuration",
        DrawTabAimbot, InitTabAimbot, ShutdownTabAimbot);
    g_Layout.GetTabManager()->RegisterTab("\xe2\x9a\x99", "MISC", "Miscellaneous features",
        DrawTabMisc, InitTabMisc, ShutdownTabMisc);
    g_Layout.GetTabManager()->RegisterTab("\xf0\x9f\x8e\xa8", "SKIN", "Skin changer",
        DrawTabSkin, InitTabSkin, ShutdownTabSkin);
    g_Layout.GetTabManager()->RegisterTab("\xe2\x84\xb9", "INFO", "System information",
        DrawTabInfo, InitTabInfo, ShutdownTabInfo);
    g_Layout.GetTabManager()->RegisterTab("\xe2\x9a\xa1", "CFG", "Configuration management",
        DrawTabConfig, InitTabConfig, ShutdownTabConfig);
    g_Layout.GetTabManager()->RegisterTab("\xe2\x97\x88", "RDR", "Radar overlay",
        DrawTabRadar, InitTabRadar, ShutdownTabRadar);
    g_Layout.GetTabManager()->RegisterTab("\xf0\x9f\x93\xa6", "LOOT", "Loot ESP & filtering",
        DrawTabLoot, InitTabLoot, ShutdownTabLoot);
    g_Layout.GetTabManager()->RegisterTab("\xf0\x9f\x91\xa5", "PLRS", "Player list & info",
        DrawTabPlayers, InitTabPlayers, ShutdownTabPlayers);
    g_Layout.GetTabManager()->RegisterTab("\xf0\x9f\x8e\xa8", "THEME", "Theme customization",
        DrawTabTheme, InitTabTheme, ShutdownTabTheme);
}

static void BeginDrawStyle() {
    static bool initDone = false;
    if (!initDone) {
        for (int i = 0; i < 10; i++)
            g_ThemeAnim.colors[i].Set(ThemeColors[CurrentTheme][i]);
        initDone = true;
    }
    ImGuiStyle *s = &ImGui::GetStyle();
    s->WindowRounding = (float)WINDOW_BORDER_RADIUS;
    s->WindowTitleAlign = ImVec2(0.5f, 0.5f);
    s->FramePadding = ImVec2(12, 9);
    s->FrameRounding = 6.0f;
    s->ItemSpacing = ImVec2(10, 10);
    s->ItemInnerSpacing = ImVec2(8, 6);
    s->IndentSpacing = 20.0f;
    s->ScrollbarSize = 14.0f;
    s->ScrollbarRounding = 7.0f;
    s->GrabMinSize = 10.0f;
    s->GrabRounding = 6.0f;
    s->ChildRounding = 8.0f;
    s->WindowBorderSize = 0.0f;
    s->FrameBorderSize = 0.0f;
    s->ChildBorderSize = 0.0f;
    s->PopupBorderSize = 0.0f;
    s->TabBorderSize = 0.0f;
    s->TabRounding = 6.0f;
    s->WindowMenuButtonPosition = ImGuiDir_None;
    s->Colors[ImGuiCol_ScrollbarBg] = ImVec4(0.05f, 0.05f, 0.08f, 0.5f);
    FinalizeTheme();
}

void ImGuiMainMenuWind() {
    g_Layout.BeginFrame();
    g_Layout.MainLayout();
    DrawRadarOverlay();
    {
        ImDrawList* dl = ImGui::GetOverlayDrawList();
        float dt = ImGui::GetIO().DeltaTime;
        if (g_Tog.ShowCrosshair) DrawCrosshair(dl, dt);
        if (g_Tog.ShowInfo) DrawInfoPanel(dl, dt);
        if (g_Tog.ShowNotifications) DrawNotifications(dl, dt);
    }
    RenderParticles(ImGui::GetOverlayDrawList());
    g_Layout.EndFrame();
}

void initGui() {
    if (g_Layout.IsInitialized()) return;
    initializeEGLContext();
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO &io = ImGui::GetIO();
    ImGui::StyleColorsDark();
    ImGui_ImplAndroid_Init(window_sv);
    ImGui_ImplOpenGL3_Init("#version 300 es");
    io.Fonts->AddFontFromMemoryTTF((void *)font_v, font_v_size, 22.0f, NULL, io.Fonts->GetGlyphRangesChineseFull());
    BeginDrawStyle();
    io.IniFilename = NULL;
    g_Layout.Init();
    RegisterDefaultTabs();
    abs_ScreenX = (_ScreenX > _ScreenY ? _ScreenX : _ScreenY);
    abs_ScreenY = (_ScreenX < _ScreenY ? _ScreenX : _ScreenY);
    g_ScreenSize = ImVec2((float)abs_ScreenX, (float)abs_ScreenY);
    g_Layout.CenterWindow();
    g_Layout.OpenWindow();
    g_Layout.GetTabManager()->InitAll();
    AntiDebug::ProtectProcess();
    AntiDebug::CrashIfDebugged();
    Obfuscator::AntiTamper::startIntegrityMonitor();
}

void shutdownGui() {
    if (!ImGui::GetCurrentContext()) return;
    g_Layout.Shutdown();
    ClearAllParticleSystems();
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplAndroid_Shutdown();
}

void RunLayoutLoop() {
    while (true) {
        ImGuiMainMenuWind();
    }
}
