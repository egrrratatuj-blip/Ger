#include "MathUtils.h"

float Vec3Distance(D3DVector a, D3DVector b) {
    float dx = a.X - b.X;
    float dy = a.Y - b.Y;
    float dz = a.Z - b.Z;
    if (!std::isfinite(dx)) dx = 0.0f;
    if (!std::isfinite(dy)) dy = 0.0f;
    if (!std::isfinite(dz)) dz = 0.0f;
    return sqrtf(dx * dx + dy * dy + dz * dz);
}

float Vec3Length(D3DVector v) {
    if (!std::isfinite(v.X)) v.X = 0.0f;
    if (!std::isfinite(v.Y)) v.Y = 0.0f;
    if (!std::isfinite(v.Z)) v.Z = 0.0f;
    return sqrtf(v.X * v.X + v.Y * v.Y + v.Z * v.Z);
}

D3DVector Vec3Normalize(D3DVector v) {
    if (!std::isfinite(v.X)) v.X = 0.0f;
    if (!std::isfinite(v.Y)) v.Y = 0.0f;
    if (!std::isfinite(v.Z)) v.Z = 0.0f;
    float len = sqrtf(v.X * v.X + v.Y * v.Y + v.Z * v.Z);
    if (len < 0.0001f || !std::isfinite(len)) return D3DVector(0.0f, 0.0f, 0.0f);
    float invLen = 1.0f / len;
    return D3DVector(v.X * invLen, v.Y * invLen, v.Z * invLen);
}

D3DVector Vec3Lerp(D3DVector a, D3DVector b, float t) {
    if (!std::isfinite(t)) t = 0.0f;
    if (t < 0.0f) t = 0.0f;
    if (t > 1.0f) t = 1.0f;
    return D3DVector(
        a.X + (b.X - a.X) * t,
        a.Y + (b.Y - a.Y) * t,
        a.Z + (b.Z - a.Z) * t
    );
}

float AngleNormalize180(float angle) {
    if (!std::isfinite(angle)) return 0.0f;
    angle = fmodf(angle + 180.0f, 360.0f);
    if (angle < 0.0f) angle += 360.0f;
    return angle - 180.0f;
}

float AngleNormalize360(float angle) {
    if (!std::isfinite(angle)) return 0.0f;
    angle = fmodf(angle, 360.0f);
    if (angle < 0.0f) angle += 360.0f;
    return angle;
}

void AnglesToVectors(float pitch, float yaw, D3DVector* forward, D3DVector* right, D3DVector* up) {
    if (!std::isfinite(pitch)) pitch = 0.0f;
    if (!std::isfinite(yaw)) yaw = 0.0f;
    float radPitch = pitch * (3.14159265358979323846f / 180.0f);
    float radYaw = yaw * (3.14159265358979323846f / 180.0f);
    float sp = sinf(radPitch);
    float cp = cosf(radPitch);
    float sy = sinf(radYaw);
    float cy = cosf(radYaw);
    if (forward) *forward = D3DVector(cp * cy, -sp, cp * sy);
    if (right) *right = D3DVector(-sy, 0.0f, cy);
    if (up) *up = D3DVector(sp * cy, cp, sp * sy);
}

D3DVector WorldToViewDir(D3DVector worldPos, D3DVector cameraPos) {
    float dx = worldPos.X - cameraPos.X;
    float dy = worldPos.Y - cameraPos.Y;
    float dz = worldPos.Z - cameraPos.Z;
    if (!std::isfinite(dx)) dx = 0.0f;
    if (!std::isfinite(dy)) dy = 0.0f;
    if (!std::isfinite(dz)) dz = 0.0f;
    float len = sqrtf(dx * dx + dy * dy + dz * dz);
    if (len < 0.0001f || !std::isfinite(len)) return D3DVector(0.0f, 0.0f, 0.0f);
    float invLen = 1.0f / len;
    return D3DVector(dx * invLen, dy * invLen, dz * invLen);
}

bool WorldToScreen(D3DVector world, float *screenX, float *screenY, float *matrix, float screenW, float screenH) {
    if (!screenX || !screenY || !matrix) return false;
    if (!std::isfinite(screenW) || screenW <= 0.0f) return false;
    if (!std::isfinite(screenH) || screenH <= 0.0f) return false;
    float w = matrix[12] * world.X + matrix[13] * world.Y + matrix[14] * world.Z + matrix[15];
    if (!std::isfinite(w)) return false;
    if (w < 0.001f) return false;
    float invW = 1.0f / w;
    float ndcX = (matrix[0] * world.X + matrix[1] * world.Y + matrix[2] * world.Z + matrix[3]) * invW;
    float ndcY = (matrix[4] * world.X + matrix[5] * world.Y + matrix[6] * world.Z + matrix[7]) * invW;
    if (!std::isfinite(ndcX) || !std::isfinite(ndcY)) return false;
    if (ndcX < -2.0f || ndcX > 2.0f || ndcY < -2.0f || ndcY > 2.0f) return false;
    *screenX = screenW * 0.5f + ndcX * screenW * 0.5f;
    *screenY = screenH * 0.5f - ndcY * screenH * 0.5f;
    if (!std::isfinite(*screenX) || !std::isfinite(*screenY)) return false;
    return true;
}
