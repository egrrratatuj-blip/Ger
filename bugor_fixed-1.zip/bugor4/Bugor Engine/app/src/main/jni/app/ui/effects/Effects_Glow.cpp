#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "../../../imgui/imgui.h"
#include "../../../imgui/imgui_internal.h"
static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }

void DrawGlowRect(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor col, float radius, float glowSize, float intensity) {
    if (glowSize < 0.0f) glowSize = 0.0f;
    const int layers = 6;
    float layerStep = glowSize / (float)layers;
    for (int i = 0; i < layers; i++) {
        float t = (float)(i + 1) / (float)layers;
        float offset = layerStep * (float)(i + 1);
        ImVec2 ep1 = ImVec2(p1.x - offset, p1.y - offset);
        ImVec2 ep2 = ImVec2(p2.x + offset, p2.y + offset);
        ImColor layerCol = col;
        float alpha = col.Value.w * (1.0f - t) * intensity;
        layerCol.Value.w = ImClamp(alpha, 0.0f, 1.0f);
        float layerRadius = radius + offset * 0.5f;
        dl->AddRectFilled(ep1, ep2, C(layerCol), layerRadius);
    }
    dl->AddRectFilled(p1, p2, C(col), radius);
}

void DrawGlowCircle(ImDrawList* dl, ImVec2 center, float radius, ImColor col, float glowSize, float intensity) {
    if (glowSize < 0.0f) glowSize = 0.0f;
    const int layers = 8;
    for (int i = 0; i < layers; i++) {
        float t = (float)i / (float)layers;
        float layerRadius = radius + glowSize * t * intensity;
        float alpha = col.Value.w * (1.0f - t);
        ImColor layerCol = col;
        layerCol.Value.w = ImClamp(alpha, 0.0f, 1.0f);
        dl->AddCircleFilled(center, layerRadius, C(layerCol), 36);
    }
    dl->AddCircleFilled(center, radius, C(col), 36);
}

void DrawGlowLine(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor col, float thickness, float glowSize) {
    if (glowSize < 0.0f) glowSize = 0.0f;
    const int layers = 6;
    ImVec2 dir = ImVec2(p2.x - p1.x, p2.y - p1.y);
    float len = ImSqrt(dir.x * dir.x + dir.y * dir.y);
    if (len < 0.001f) return;
    dir.x /= len; dir.y /= len;
    ImVec2 perp = ImVec2(-dir.y, dir.x);
    float step = glowSize / (float)layers;
    for (int i = 0; i < layers; i++) {
        float t = (float)(i + 1) / (float)layers;
        float offset = step * (float)(i + 1);
        ImVec2 op1 = ImVec2(p1.x + perp.x * offset, p1.y + perp.y * offset);
        ImVec2 op2 = ImVec2(p2.x + perp.x * offset, p2.y + perp.y * offset);
        ImVec2 op3 = ImVec2(p1.x - perp.x * offset, p1.y - perp.y * offset);
        ImVec2 op4 = ImVec2(p2.x - perp.x * offset, p2.y - perp.y * offset);
        float alpha = col.Value.w * (1.0f - t);
        ImColor layerCol = col;
        layerCol.Value.w = ImClamp(alpha, 0.0f, 1.0f);
        dl->AddLine(op1, op2, C(layerCol), thickness + offset * 0.3f);
        dl->AddLine(op3, op4, C(layerCol), thickness + offset * 0.3f);
    }
    dl->AddLine(p1, p2, C(col), thickness);
}

void DrawShadowRect(ImDrawList* dl, ImVec2 p1, ImVec2 p2, float radius, float shadowSize, ImColor shadowColor) {
    ImVec2 offset = ImVec2(3.0f, 3.0f);
    const int layers = 5;
    float layerStep = shadowSize / (float)layers;
    for (int i = 0; i < layers; i++) {
        float t = (float)(i + 1) / (float)layers;
        float expand = layerStep * (float)(i + 1);
        ImVec2 sp1 = ImVec2(p1.x + offset.x - expand, p1.y + offset.y - expand);
        ImVec2 sp2 = ImVec2(p2.x + offset.x + expand, p2.y + offset.y + expand);
        float alpha = shadowColor.Value.w * (1.0f - t * 0.8f);
        ImColor layerCol = shadowColor;
        layerCol.Value.w = ImClamp(alpha, 0.0f, 1.0f);
        dl->AddRectFilled(sp1, sp2, C(layerCol), radius + expand * 0.3f);
    }
    dl->AddRectFilled(
        ImVec2(p1.x + offset.x, p1.y + offset.y),
        ImVec2(p2.x + offset.x, p2.y + offset.y),
        C(shadowColor), radius
    );
}

void DrawInnerGlow(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor col, float radius, float glowSize) {
    if (glowSize < 0.0f) glowSize = 0.0f;
    const int layers = 6;
    float layerStep = glowSize / (float)layers;
    for (int i = 0; i < layers; i++) {
        float t = (float)i / (float)layers;
        float inset = layerStep * (float)(layers - i);
        ImVec2 ip1 = ImVec2(p1.x + inset, p1.y + inset);
        ImVec2 ip2 = ImVec2(p2.x - inset, p2.y - inset);
        if (ip1.x >= ip2.x || ip1.y >= ip2.y) continue;
        float alpha = col.Value.w * (1.0f - t) * 0.5f;
        ImColor layerCol = col;
        layerCol.Value.w = ImClamp(alpha, 0.0f, 1.0f);
        float layerRadius = ImMax(0.0f, radius - inset * 0.5f);
        dl->AddRectFilled(ip1, ip2, C(layerCol), layerRadius);
    }
}

void DrawCornerAccents(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor col, float length, float thickness) {
    ImU32 color = C(col);
    float len = length;
    float t = thickness;

    dl->AddLine(ImVec2(p1.x, p1.y), ImVec2(p1.x + len, p1.y), color, t);
    dl->AddLine(ImVec2(p1.x, p1.y), ImVec2(p1.x, p1.y + len), color, t);

    dl->AddLine(ImVec2(p2.x - len, p1.y), ImVec2(p2.x, p1.y), color, t);
    dl->AddLine(ImVec2(p2.x, p1.y), ImVec2(p2.x, p1.y + len), color, t);

    dl->AddLine(ImVec2(p1.x, p2.y - len), ImVec2(p1.x, p2.y), color, t);
    dl->AddLine(ImVec2(p1.x, p2.y), ImVec2(p1.x + len, p2.y), color, t);

    dl->AddLine(ImVec2(p2.x - len, p2.y), ImVec2(p2.x, p2.y), color, t);
    dl->AddLine(ImVec2(p2.x, p2.y - len), ImVec2(p2.x, p2.y), color, t);
}

void DrawScanlines(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor col, float spacing, float alpha) {
    ImColor lineCol = col;
    lineCol.Value.w = ImClamp(alpha, 0.0f, 1.0f);
    ImU32 color = C(lineCol);
    float y = p1.y;
    while (y <= p2.y) {
        dl->AddLine(ImVec2(p1.x, y), ImVec2(p2.x, y), color, 1.0f);
        y += spacing;
    }
}

void DrawGridOverlay(ImDrawList* dl, ImVec2 p1, ImVec2 p2, float spacing, ImColor col) {
    ImU32 color = C(col);
    float x = p1.x;
    while (x <= p2.x) {
        dl->AddLine(ImVec2(x, p1.y), ImVec2(x, p2.y), color, 1.0f);
        x += spacing;
    }
    float y = p1.y;
    while (y <= p2.y) {
        dl->AddLine(ImVec2(p1.x, y), ImVec2(p2.x, y), color, 1.0f);
        y += spacing;
    }
}

void DrawGlowText(ImDrawList* dl, const char* text, ImVec2 pos, ImColor col, float glowSize) {
    if (glowSize < 0.0f) glowSize = 0.0f;
    const int layers = 4;
    for (int i = layers - 1; i >= 0; i--) {
        float t = (float)(i + 1) / (float)layers;
        float alpha = col.Value.w * (1.0f - t) * 0.5f;
        ImColor layerCol = col;
        layerCol.Value.w = ImClamp(alpha, 0.0f, 1.0f);
        float offset = glowSize * t * 0.5f;
        dl->AddText(ImGui::GetFont(), ImGui::GetFontSize(),
            ImVec2(pos.x + offset, pos.y + offset), C(layerCol), text);
        dl->AddText(ImGui::GetFont(), ImGui::GetFontSize(),
            ImVec2(pos.x - offset, pos.y - offset), C(layerCol), text);
        dl->AddText(ImGui::GetFont(), ImGui::GetFontSize(),
            ImVec2(pos.x + offset, pos.y - offset), C(layerCol), text);
        dl->AddText(ImGui::GetFont(), ImGui::GetFontSize(),
            ImVec2(pos.x - offset, pos.y + offset), C(layerCol), text);
    }
    dl->AddText(ImGui::GetFont(), ImGui::GetFontSize(), pos, C(col), text);
}

void DrawGlowTraingle(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImVec2 p3, ImColor col, float glowSize) {
    if (glowSize < 0.0f) glowSize = 0.0f;
    const int layers = 5;
    float layerStep = glowSize / (float)layers;
    ImVec2 center = ImVec2((p1.x + p2.x + p3.x) / 3.0f, (p1.y + p2.y + p3.y) / 3.0f);
    for (int i = 0; i < layers; i++) {
        float t = (float)(i + 1) / (float)layers;
        float offset = layerStep * t;
        ImVec2 ep1 = ImVec2(p1.x + (p1.x - center.x) * t * 0.5f, p1.y + (p1.y - center.y) * t * 0.5f);
        ImVec2 ep2 = ImVec2(p2.x + (p2.x - center.x) * t * 0.5f, p2.y + (p2.y - center.y) * t * 0.5f);
        ImVec2 ep3 = ImVec2(p3.x + (p3.x - center.x) * t * 0.5f, p3.y + (p3.y - center.y) * t * 0.5f);
        float alpha = col.Value.w * (1.0f - t) * 0.6f;
        ImColor layerCol = col;
        layerCol.Value.w = ImClamp(alpha, 0.0f, 1.0f);
        dl->AddTriangleFilled(ep1, ep2, ep3, C(layerCol));
    }
    dl->AddTriangleFilled(p1, p2, p3, C(col));
}

void DrawGlowRoundedRect(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor col, float rounding, float glowSize, float intensity) {
    if (glowSize < 0.0f) glowSize = 0.0f;
    int segments = 0;
    if (rounding > 0) segments = (int)(rounding * 0.5f) + 8;
    const int layers = 6;
    float layerStep = glowSize / (float)layers;
    for (int i = 0; i < layers; i++) {
        float t = (float)(i + 1) / (float)layers;
        float offset = layerStep * t;
        ImVec2 ep1 = ImVec2(p1.x - offset, p1.y - offset);
        ImVec2 ep2 = ImVec2(p2.x + offset, p2.y + offset);
        float alpha = col.Value.w * (1.0f - t) * intensity;
        ImColor layerCol = col;
        layerCol.Value.w = ImClamp(alpha, 0.0f, 1.0f);
        float layerRounding = ImMax(0.0f, rounding + offset * 0.3f);
        dl->AddRectFilled(ep1, ep2, C(layerCol), layerRounding);
    }
    dl->AddRectFilled(p1, p2, C(col), rounding);
}

void DrawGlowBezier(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImVec2 cp1, ImVec2 cp2, ImColor col, float thickness, float glowSize) {
    if (glowSize < 0.0f) glowSize = 0.0f;
    const int layers = 6;
    float step = glowSize / (float)layers;
    for (int i = 0; i < layers; i++) {
        float t = (float)(i + 1) / (float)layers;
        float offset = step * t;
        float alpha = col.Value.w * (1.0f - t) * 0.5f;
        ImColor layerCol = col;
        layerCol.Value.w = ImClamp(alpha, 0.0f, 1.0f);
        ImVec2 off = ImVec2(offset, offset);
        dl->AddBezierCubic(
            ImVec2(p1.x - off.x, p1.y - off.y),
            ImVec2(cp1.x - off.x, cp1.y - off.y),
            ImVec2(cp2.x - off.x, cp2.y - off.y),
            ImVec2(p2.x - off.x, p2.y - off.y),
            C(layerCol), thickness + offset * 0.3f, 0
        );
        dl->AddBezierCubic(
            ImVec2(p1.x + off.x, p1.y + off.y),
            ImVec2(cp1.x + off.x, cp1.y + off.y),
            ImVec2(cp2.x + off.x, cp2.y + off.y),
            ImVec2(p2.x + off.x, p2.y + off.y),
            C(layerCol), thickness + offset * 0.3f, 0
        );
    }
    dl->AddBezierCubic(p1, cp1, cp2, p2, C(col), thickness, 0);
}

void DrawDirectionalGlow(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor col, float radius, ImVec2 direction, float glowSize, float intensity) {
    if (glowSize < 0.0f) glowSize = 0.0f;
    float dirLen = ImSqrt(direction.x * direction.x + direction.y * direction.y);
    if (dirLen < 0.001f) { DrawGlowRect(dl, p1, p2, col, radius, glowSize, intensity); return; }
    direction.x /= dirLen; direction.y /= dirLen;
    const int layers = 8;
    float layerStep = glowSize / (float)layers;
    for (int i = 0; i < layers; i++) {
        float t = (float)(i + 1) / (float)layers;
        float dist = layerStep * t;
        ImVec2 dp1 = ImVec2(p1.x + direction.x * dist, p1.y + direction.y * dist);
        ImVec2 dp2 = ImVec2(p2.x + direction.x * dist, p2.y + direction.y * dist);
        float alpha = col.Value.w * (1.0f - t) * intensity;
        ImColor layerCol = col;
        layerCol.Value.w = ImClamp(alpha, 0.0f, 1.0f);
        dl->AddRectFilled(dp1, dp2, C(layerCol), radius + dist * 0.2f);
    }
    dl->AddRectFilled(p1, p2, C(col), radius);
}

void DrawPulsingGlowRect(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor col, float radius, float glowSize, float speed) {
    if (glowSize < 0.0f) glowSize = 0.0f;
    float pulse = sinf(ImGui::GetTime() * speed) * 0.5f + 0.5f;
    float intensity = 0.5f + pulse * 0.5f;
    DrawGlowRect(dl, p1, p2, col, radius, glowSize + pulse * glowSize * 0.3f, intensity);
}

void DrawGlowRing(ImDrawList* dl, ImVec2 center, float radius, float thickness, ImColor col, float glowSize) {
    if (glowSize < 0.0f) glowSize = 0.0f;
    const int layers = 6;
    float layerStep = glowSize / (float)layers;
    for (int i = 0; i < layers; i++) {
        float t = (float)(i + 1) / (float)layers;
        float expand = layerStep * t;
        float alpha = col.Value.w * (1.0f - t) * 0.7f;
        ImColor layerCol = col;
        layerCol.Value.w = ImClamp(alpha, 0.0f, 1.0f);
        dl->AddCircle(center, radius + expand, C(layerCol), 36, 0, thickness + expand * 0.2f);
    }
    dl->AddCircle(center, radius, C(col), 36, 0, thickness);
}

void DrawGlowPoints(ImDrawList* dl, ImVec2* pts, int numPts, ImColor col, float pointSize, float glowSize) {
    for (int i = 0; i < numPts; i++) {
        DrawGlowCircle(dl, pts[i], pointSize, col, glowSize, 0.6f);
    }
}

void DrawGlowPoly(ImDrawList* dl, ImVec2* verts, int numVerts, ImColor col, float glowSize) {
    if (glowSize < 0.0f) glowSize = 0.0f;
    const int layers = 5;
    float layerStep = glowSize / (float)layers;
    ImVec2 center = ImVec2(0, 0);
    for (int i = 0; i < numVerts; i++) { center.x += verts[i].x; center.y += verts[i].y; }
    center.x /= (float)numVerts; center.y /= (float)numVerts;
    for (int i = 0; i < layers; i++) {
        float t = (float)(i + 1) / (float)layers;
        float expand = layerStep * t;
        float alpha = col.Value.w * (1.0f - t) * 0.5f;
        ImColor layerCol = col;
        layerCol.Value.w = ImClamp(alpha, 0.0f, 1.0f);
        ImVector<ImVec2> layerVerts;
        layerVerts.reserve(numVerts);
        for (int j = 0; j < numVerts; j++) {
            float dx = verts[j].x - center.x;
            float dy = verts[j].y - center.y;
            float d = ImSqrt(dx * dx + dy * dy);
            if (d < 0.001f) { layerVerts.push_back(verts[j]); continue; }
            layerVerts.push_back(ImVec2(
                verts[j].x + dx / d * expand,
                verts[j].y + dy / d * expand
            ));
        }
        dl->AddConvexPolyFilled(layerVerts.Data, numVerts, C(layerCol));
    }
    dl->AddConvexPolyFilled(verts, numVerts, C(col));
}

void DrawNeonGlow(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor col, float radius) {
    for (int i = 5; i >= 0; i--) {
        float t = (float)i / 6.0f;
        float offset = (float)i * 2.5f;
        float alpha = (1.0f - t) * col.Value.w * 0.35f;
        ImColor layer = col;
        layer.Value.w = ImClamp(alpha, 0.0f, 1.0f);
        dl->AddRect(
            ImVec2(p1.x - offset, p1.y - offset),
            ImVec2(p2.x + offset, p2.y + offset),
            C(layer), radius + offset, 0, (float)i * 0.8f + 1.0f
        );
    }
    dl->AddRect(p1, p2, C(col), radius, 0, 2.0f);
}

static float gCornerAnim[4] = {0, 0, 0, 0};

void UpdateCornerAnimations(float speed) {
    float dt = ImGui::GetIO().DeltaTime;
    for (int i = 0; i < 4; i++) {
        gCornerAnim[i] += dt * speed;
        if (gCornerAnim[i] > 1.0f) gCornerAnim[i] = 0;
    }
}

void DrawAnimatedCornerAccents(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor col, float maxLength, float thickness) {
    ImU32 color = C(col);
    float len = maxLength;
    float t = thickness;
    for (int i = 0; i < 4; i++) {
        float animLen = len * (sinf(gCornerAnim[i] * IM_PI * 2.0f) * 0.5f + 0.5f);
        switch (i) {
            case 0:
                dl->AddLine(ImVec2(p1.x, p1.y), ImVec2(p1.x + animLen, p1.y), color, t);
                dl->AddLine(ImVec2(p1.x, p1.y), ImVec2(p1.x, p1.y + animLen), color, t);
                break;
            case 1:
                dl->AddLine(ImVec2(p2.x - animLen, p1.y), ImVec2(p2.x, p1.y), color, t);
                dl->AddLine(ImVec2(p2.x, p1.y), ImVec2(p2.x, p1.y + animLen), color, t);
                break;
            case 2:
                dl->AddLine(ImVec2(p1.x, p2.y - animLen), ImVec2(p1.x, p2.y), color, t);
                dl->AddLine(ImVec2(p1.x, p2.y), ImVec2(p1.x + animLen, p2.y), color, t);
                break;
            case 3:
                dl->AddLine(ImVec2(p2.x - animLen, p2.y), ImVec2(p2.x, p2.y), color, t);
                dl->AddLine(ImVec2(p2.x, p2.y - animLen), ImVec2(p2.x, p2.y), color, t);
                break;
        }
    }
}

void DrawGlowCross(ImDrawList* dl, ImVec2 center, float armLength, float armThickness, ImColor col, float glowSize) {
    if (glowSize < 0.0f) glowSize = 0.0f;
    const int layers = 5;
    float layerStep = glowSize / (float)layers;
    for (int i = 0; i < layers; i++) {
        float t = (float)(i + 1) / (float)layers;
        float expand = layerStep * t;
        float alpha = col.Value.w * (1.0f - t) * 0.5f;
        ImColor layerCol = col;
        layerCol.Value.w = ImClamp(alpha, 0.0f, 1.0f);
        float th = armThickness + expand * 0.5f;
        dl->AddRectFilled(
            ImVec2(center.x - armLength - expand, center.y - th * 0.5f),
            ImVec2(center.x + armLength + expand, center.y + th * 0.5f),
            C(layerCol)
        );
        dl->AddRectFilled(
            ImVec2(center.x - th * 0.5f, center.y - armLength - expand),
            ImVec2(center.x + th * 0.5f, center.y + armLength + expand),
            C(layerCol)
        );
    }
    dl->AddRectFilled(
        ImVec2(center.x - armLength, center.y - armThickness * 0.5f),
        ImVec2(center.x + armLength, center.y + armThickness * 0.5f),
        C(col)
    );
    dl->AddRectFilled(
        ImVec2(center.x - armThickness * 0.5f, center.y - armLength),
        ImVec2(center.x + armThickness * 0.5f, center.y + armLength),
        C(col)
    );
}

void DrawSoftShadow(ImDrawList* dl, ImVec2 p1, ImVec2 p2, float radius, float shadowSize, ImColor shadowColor, ImVec2 offset) {
    const int layers = 8;
    float layerStep = shadowSize / (float)layers;
    for (int i = 0; i < layers; i++) {
        float t = (float)(i + 1) / (float)layers;
        float expand = layerStep * t;
        ImVec2 sp1 = ImVec2(
            p1.x + offset.x * (1.0f + t * 0.3f) - expand,
            p1.y + offset.y * (1.0f + t * 0.3f) - expand
        );
        ImVec2 sp2 = ImVec2(
            p2.x + offset.x * (1.0f + t * 0.3f) + expand,
            p2.y + offset.y * (1.0f + t * 0.3f) + expand
        );
        float alpha = shadowColor.Value.w * (1.0f - t * t * 0.9f);
        ImColor layerCol = shadowColor;
        layerCol.Value.w = ImClamp(alpha, 0.0f, 1.0f);
        dl->AddRectFilled(sp1, sp2, C(layerCol), radius + expand * 0.4f);
    }
    float a = shadowColor.Value.w * 0.9f;
    ImColor baseSh = shadowColor;
    baseSh.Value.w = a;
    dl->AddRectFilled(
        ImVec2(p1.x + offset.x, p1.y + offset.y),
        ImVec2(p2.x + offset.x, p2.y + offset.y),
        C(baseSh), radius
    );
}
