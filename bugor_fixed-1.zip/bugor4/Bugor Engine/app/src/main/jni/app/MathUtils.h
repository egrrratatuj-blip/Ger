#pragma once
#include "Config.h"
#include <cmath>

float Vec3Distance(D3DVector a, D3DVector b);
float Vec3Length(D3DVector v);
D3DVector Vec3Normalize(D3DVector v);
D3DVector Vec3Lerp(D3DVector a, D3DVector b, float t);
float AngleNormalize180(float angle);
float AngleNormalize360(float angle);
void AnglesToVectors(float pitch, float yaw, D3DVector* forward, D3DVector* right, D3DVector* up);
D3DVector WorldToViewDir(D3DVector worldPos, D3DVector cameraPos);
bool WorldToScreen(D3DVector world, float *screenX, float *screenY, float *matrix, float screenW, float screenH);
