#include "AntiDebug.h"
#include <unistd.h>
#include <fcntl.h>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <signal.h>
#include <thread>
#include <atomic>
#include <chrono>
#include <ctime>
#include <sys/prctl.h>
#include <linux/prctl.h>

namespace AntiDebug {

static std::thread g_monitorThread;
static std::atomic<bool> g_monitorRunning(false);

bool IsBeingDebugged() {
    char buf[4096];
    int fd = open("/proc/self/status", O_RDONLY);
    if (fd >= 0) {
        ssize_t n = read(fd, buf, sizeof(buf) - 1);
        close(fd);
        if (n > 0) {
            buf[n] = 0;
            const char* p = strstr(buf, "TracerPid:");
            if (p) {
                p += 10;
                while (*p == ' ' || *p == '\t') p++;
                if (*p != '0') return true;
            }
        }
    }

    fd = open("/proc/self/wchan", O_RDONLY);
    if (fd >= 0) {
        char wchan[64];
        ssize_t n = read(fd, wchan, sizeof(wchan) - 1);
        close(fd);
        if (n > 0) {
            wchan[n] = 0;
            if (strstr(wchan, "ptrace") || strstr(wchan, "wait")) return true;
        }
    }

    struct timespec ts1, ts2;
    clock_gettime(CLOCK_MONOTONIC, &ts1);
    volatile int x = 0;
    for (int i = 0; i < 100000; i++) x += i;
    clock_gettime(CLOCK_MONOTONIC, &ts2);
    long long diff = (ts2.tv_sec - ts1.tv_sec) * 1000000000LL + (ts2.tv_nsec - ts1.tv_nsec);
    if (diff > 10000000) return true;

    return false;
}

void ProtectProcess() {
    const char* targets[] = {
        "frida", "xposed", "substrate", "gameguardian",
        "libfrida", "libxposed", "libsubstrate", nullptr
    };
    FILE* fp = fopen("/proc/self/maps", "r");
    if (fp) {
        char line[1024];
        while (fgets(line, sizeof(line), fp)) {
            for (int i = 0; targets[i]; i++) {
                if (strstr(line, targets[i])) {
                    fclose(fp);
                    raise(SIGKILL);
                    _exit(1);
                }
            }
        }
        fclose(fp);
    }
}

void CrashIfDebugged() {
    if (IsBeingDebugged()) {
        raise(SIGKILL);
        _exit(1);
    }

    FILE* fp = fopen("/proc/self/maps", "r");
    if (fp) {
        char line[1024];
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, "rwxp")) {
                fclose(fp);
                raise(SIGKILL);
                _exit(1);
            }
        }
        fclose(fp);
    }
}

void ObfuscateMemory(void* ptr, size_t size) {
    uint8_t* p = (uint8_t*)ptr;
    uint64_t state = 0x9d3b1a4f5e7c2d8aULL;
    for (size_t i = 0; i < size; i++) {
        state ^= state << 13;
        state ^= state >> 7;
        state ^= state << 17;
        p[i] ^= (uint8_t)(state & 0xFF);
    }
}

void StartMonitoring(int level) {
    if (g_monitorRunning.load()) return;
    g_monitorRunning.store(true);
    g_monitorThread = std::thread([level]() {
        while (g_monitorRunning.load()) {
            if (IsBeingDebugged()) {
                raise(SIGKILL);
                _exit(1);
            }
            FILE* fp = fopen("/proc/self/maps", "r");
            if (fp) {
                char line[1024];
                while (fgets(line, sizeof(line), fp)) {
                    if (level >= PARANOID && strstr(line, "rwxp")) {
                        fclose(fp);
                        raise(SIGKILL);
                        _exit(1);
                    }
                    if (level >= MEDIUM) {
                        const char* cheats[] = {
                            "frida", "xposed", "substrate", "gameguardian",
                            nullptr
                        };
                        for (int i = 0; cheats[i]; i++) {
                            if (strstr(line, cheats[i])) {
                                fclose(fp);
                                raise(SIGKILL);
                                _exit(1);
                            }
                        }
                    }
                }
                fclose(fp);
            }
            std::this_thread::sleep_for(std::chrono::seconds(5));
        }
    });
}

void StopMonitoring() {
    g_monitorRunning.store(false);
    if (g_monitorThread.joinable()) {
        g_monitorThread.join();
    }
}

}
