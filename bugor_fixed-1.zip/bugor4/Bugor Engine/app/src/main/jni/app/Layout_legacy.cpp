// DEPRECATED REFERENCE FILE - NOT COMPILED - KEPT FOR HISTORICAL CONTEXT
// The canonical layout implementation is in app/ui/Layout.cpp
// This file is intentionally excluded from Android.mk to avoid duplicate symbols.
// It is preserved as a reference for understanding the legacy UI architecture only.
// DO NOT ADD THIS FILE BACK TO Android.mk. The symbols here are defined in:
//   - Globals.cpp (globals: g_Mem, g_Offsets, g_Cfg, g_Tog, g_Bot, g_Esp, _ScreenX, etc.)
//   - app/ui/Layout.cpp (UI: initGui, shutdownGui, ImGuiMainMenuWind, ImGuiMainWinStart, ImGuiMainWinEnded)
#if 0
#include "Config.h"
#include "MemoryIO.h"
#include "GameOffsets.h"
#include "ESP.h"
#include "Aimbot.h"
#include "AntiDebug.h"
#include "imgui/Font.h"
#include "imgui/window_icon.h"
#include "imgui/safe_icon.h"

MemoryIO g_Mem;
GameOffsets g_Offsets(&g_Mem);
Config g_Cfg;
Toggles g_Tog;
Aimbot g_Bot(&g_Mem, &g_Offsets, &g_Cfg, &g_Tog);
ESP g_Esp(&g_Mem, &g_Offsets, &g_Cfg, &g_Tog, &g_Bot);

int _ScreenX = 0, _ScreenY = 0;
int abs_ScreenX = 0, abs_ScreenY = 0;
bool g_Initialized = false;
ImGuiWindow *Window = nullptr;
ANativeWindow *window_sv = nullptr;
EGLDisplay g_EglDisplay = EGL_NO_DISPLAY;
EGLSurface g_EglSurface = EGL_NO_SURFACE;
EGLContext g_EglContext = EGL_NO_CONTEXT;

void initializeEGLContext() {
    const EGLint attribs[] = {
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_BLUE_SIZE, 8,
        EGL_GREEN_SIZE, 8,
        EGL_RED_SIZE, 8,
        EGL_ALPHA_SIZE, 8,
        EGL_DEPTH_SIZE, 24,
        EGL_STENCIL_SIZE, 8,
        EGL_NONE
    };
    ANativeWindow_acquire(window_sv);
    g_EglDisplay = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (g_EglDisplay == EGL_NO_DISPLAY) return;
    eglInitialize(g_EglDisplay, 0, 0);
    EGLint numConfigs = 0;
    eglChooseConfig(g_EglDisplay, attribs, nullptr, 0, &numConfigs);
    if (numConfigs == 0) return;
    EGLConfig eglConfig;
    eglChooseConfig(g_EglDisplay, attribs, &eglConfig, 1, &numConfigs);
    EGLint eglFormat;
    eglGetConfigAttrib(g_EglDisplay, eglConfig, EGL_NATIVE_VISUAL_ID, &eglFormat);
    ANativeWindow_setBuffersGeometry(window_sv, 0, 0, eglFormat);
    EGLint ctxAttribs[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };
    g_EglContext = eglCreateContext(g_EglDisplay, eglConfig, EGL_NO_CONTEXT, ctxAttribs);
    g_EglSurface = eglCreateWindowSurface(g_EglDisplay, eglConfig, window_sv, NULL);
    eglMakeCurrent(g_EglDisplay, g_EglSurface, g_EglSurface, g_EglContext);
}

bool Android_LoadSystemFont() {
    char path[64] = {0};
    char *filename = nullptr;
    const char *fontPaths[] = { "/system/fonts", "/system/font", "/data/fonts" };
    for (auto tmp : fontPaths) {
        if (access(tmp, R_OK) == 0) {
            strcpy(path, tmp);
            filename = path + strlen(tmp);
            break;
        }
    }
    if (!filename) return false;
    *filename++ = '/';
    strcpy(filename, "NotoSansCJK-Regular.ttc");
    if (access(path, R_OK) != 0) {
        strcpy(filename, "NotoSerifCJK-Regular.ttc");
        if (access(path, R_OK) != 0) return false;
    }
    return true;
}

void ImGuiMainWinStart() {
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame();
    ImGui::NewFrame();
}

void ImGuiMainWinEnded() {
    ImGui::Render();
    glClear(GL_COLOR_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    if (eglSwapBuffers(g_EglDisplay, g_EglSurface)) {}
}

static ImU32 ColToU32(const ImColor &c) {
    return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w));
}

static float easeOutQuad(float t) { return t * (2.0f - t); }
static float easeOutCubic(float t) { float v = t - 1.0f; return v * v * v + 1.0f; }

ImColor ThemeColors[5][10] = {
    { ImColor(10, 10, 20), ImColor(0, 180, 255), ImColor(255, 255, 255), ImColor(30, 30, 50), ImColor(0, 120, 200), ImColor(20, 20, 35), ImColor(0, 200, 255), ImColor(100, 50, 255), ImColor(0, 80, 160), ImColor(50, 50, 80) },
    { ImColor(20, 15, 25), ImColor(255, 80, 120), ImColor(255, 255, 255), ImColor(40, 25, 40), ImColor(200, 50, 80), ImColor(30, 20, 30), ImColor(255, 100, 150), ImColor(200, 50, 150), ImColor(150, 30, 60), ImColor(60, 30, 50) },
    { ImColor(10, 25, 15), ImColor(0, 255, 120), ImColor(255, 255, 255), ImColor(20, 40, 25), ImColor(0, 200, 80), ImColor(15, 30, 20), ImColor(0, 255, 150), ImColor(50, 200, 100), ImColor(0, 150, 60), ImColor(30, 60, 40) },
    { ImColor(25, 20, 10), ImColor(255, 200, 50), ImColor(255, 255, 255), ImColor(40, 30, 20), ImColor(200, 150, 30), ImColor(30, 25, 15), ImColor(255, 220, 80), ImColor(200, 150, 50), ImColor(150, 120, 20), ImColor(60, 50, 30) },
    { ImColor(15, 10, 30), ImColor(150, 50, 255), ImColor(255, 255, 255), ImColor(30, 20, 50), ImColor(100, 30, 200), ImColor(20, 15, 40), ImColor(180, 80, 255), ImColor(150, 50, 200), ImColor(80, 20, 160), ImColor(50, 30, 70) }
};

struct ThemeColorSet {
    ImColor bg, accent, text, titleBg, button, frameBg, accentHover, accentActive, borderAlt, frameAlt;
};

struct AnimTheme {
    ImGui::AnimColor colors[10];
    bool active;
    AnimTheme() : active(false) {}
    void SetTarget(int themeID) {
        for (int i = 0; i < 10; i++) {
            colors[i].SetTarget(ThemeColors[themeID][i]);
            colors[i].speed = 6.0f;
        }
        active = true;
    }
    void Update() {
        if (!active) return;
        bool allDone = true;
        for (int i = 0; i < 10; i++) {
            colors[i].Update();
            if (!colors[i].IsDone()) allDone = false;
        }
        if (allDone) active = false;
    }
    ImColor Get(int idx) { return colors[idx].Get(); }
    ImVec4 GetV4(int idx) { return colors[idx].GetVec4(); }
};

int CurrentTheme = 0;
int TargetTheme = 0;
bool themeAnimating = false;
AnimTheme g_ThemeAnim;
float g_ThemeTransitionTime = 0.0f;
const float THEME_TRANSITION_DURATION = 0.5f;

void ApplyTheme(int themeID) {
    if (themeID < 0 || themeID >= 5) themeID = 0;
    if (themeID == CurrentTheme && !themeAnimating) return;
    if (themeID != TargetTheme) {
        TargetTheme = themeID;
        g_ThemeAnim.SetTarget(themeID);
        themeAnimating = true;
        g_ThemeTransitionTime = 0.0f;
    }
}

void FinalizeTheme() {
    if (!themeAnimating) return;
    g_ThemeTransitionTime += ImGui::GetIO().DeltaTime;
    g_ThemeAnim.Update();
    if (g_ThemeTransitionTime >= THEME_TRANSITION_DURATION || g_ThemeAnim.active == false) {
        CurrentTheme = TargetTheme;
        themeAnimating = false;
        for (int i = 0; i < 10; i++) {
            g_ThemeAnim.colors[i].Set(ThemeColors[CurrentTheme][i]);
        }
    }
    ImColor c0 = g_ThemeAnim.active ? g_ThemeAnim.Get(0) : ThemeColors[CurrentTheme][0];
    ImColor c1 = g_ThemeAnim.active ? g_ThemeAnim.Get(1) : ThemeColors[CurrentTheme][1];
    ImColor c2 = g_ThemeAnim.active ? g_ThemeAnim.Get(2) : ThemeColors[CurrentTheme][2];
    ImColor c3 = g_ThemeAnim.active ? g_ThemeAnim.Get(3) : ThemeColors[CurrentTheme][3];
    ImColor c4 = g_ThemeAnim.active ? g_ThemeAnim.Get(4) : ThemeColors[CurrentTheme][4];
    ImColor c5 = g_ThemeAnim.active ? g_ThemeAnim.Get(5) : ThemeColors[CurrentTheme][5];
    ImColor c6 = g_ThemeAnim.active ? g_ThemeAnim.Get(6) : ThemeColors[CurrentTheme][6];
    ImColor c7 = g_ThemeAnim.active ? g_ThemeAnim.Get(7) : ThemeColors[CurrentTheme][7];
    ImColor c8 = g_ThemeAnim.active ? g_ThemeAnim.Get(8) : ThemeColors[CurrentTheme][8];
    ImColor c9 = g_ThemeAnim.active ? g_ThemeAnim.Get(9) : ThemeColors[CurrentTheme][9];

    ImGuiStyle *s = &ImGui::GetStyle();
    ImVec4 *c = s->Colors;
    c[ImGuiCol_WindowBg] = ImVec4(c0.Value.x, c0.Value.y, c0.Value.z, 0.92f);
    c[ImGuiCol_TitleBg] = ImVec4(c3.Value.x, c3.Value.y, c3.Value.z, 1.0f);
    c[ImGuiCol_TitleBgActive] = ImVec4(c1.Value.x, c1.Value.y, c1.Value.z, 0.8f);
    c[ImGuiCol_Button] = ImVec4(c4.Value.x, c4.Value.y, c4.Value.z, 0.9f);
    c[ImGuiCol_ButtonHovered] = ImVec4(c6.Value.x, c6.Value.y, c6.Value.z, 1.0f);
    c[ImGuiCol_ButtonActive] = ImVec4(c7.Value.x, c7.Value.y, c7.Value.z, 1.0f);
    c[ImGuiCol_FrameBg] = ImVec4(c5.Value.x, c5.Value.y, c5.Value.z, 0.7f);
    c[ImGuiCol_FrameBgHovered] = ImVec4(c5.Value.x, c5.Value.y, c5.Value.z, 0.9f);
    c[ImGuiCol_FrameBgActive] = ImVec4(c4.Value.x, c4.Value.y, c4.Value.z, 0.8f);
    c[ImGuiCol_CheckMark] = ImVec4(c6.Value.x, c6.Value.y, c6.Value.z, 1.0f);
    c[ImGuiCol_SliderGrab] = ImVec4(c6.Value.x, c6.Value.y, c6.Value.z, 1.0f);
    c[ImGuiCol_SliderGrabActive] = ImVec4(c7.Value.x, c7.Value.y, c7.Value.z, 1.0f);
    c[ImGuiCol_Header] = ImVec4(c4.Value.x, c4.Value.y, c4.Value.z, 0.6f);
    c[ImGuiCol_HeaderHovered] = ImVec4(c6.Value.x, c6.Value.y, c6.Value.z, 0.7f);
    c[ImGuiCol_HeaderActive] = ImVec4(c7.Value.x, c7.Value.y, c7.Value.z, 0.8f);
    c[ImGuiCol_Text] = ImVec4(c2.Value.x, c2.Value.y, c2.Value.z, 1.0f);
    c[ImGuiCol_Border] = ImVec4(c8.Value.x, c8.Value.y, c8.Value.z, 0.5f);
    c[ImGuiCol_ResizeGrip] = ImVec4(c6.Value.x, c6.Value.y, c6.Value.z, 0.6f);
    c[ImGuiCol_ResizeGripHovered] = ImVec4(c6.Value.x, c6.Value.y, c6.Value.z, 0.8f);
    c[ImGuiCol_ResizeGripActive] = ImVec4(c7.Value.x, c7.Value.y, c7.Value.z, 1.0f);
    c[ImGuiCol_ScrollbarBg] = ImVec4(c5.Value.x, c5.Value.y, c5.Value.z, 0.5f);
    c[ImGuiCol_ScrollbarGrab] = ImVec4(c4.Value.x, c4.Value.y, c4.Value.z, 0.7f);
    c[ImGuiCol_ScrollbarGrabHovered] = ImVec4(c6.Value.x, c6.Value.y, c6.Value.z, 0.8f);
    c[ImGuiCol_ScrollbarGrabActive] = ImVec4(c7.Value.x, c7.Value.y, c7.Value.z, 1.0f);
    c[ImGuiCol_Tab] = ImVec4(c3.Value.x, c3.Value.y, c3.Value.z, 0.8f);
    c[ImGuiCol_TabHovered] = ImVec4(c6.Value.x, c6.Value.y, c6.Value.z, 0.9f);
    c[ImGuiCol_TabActive] = ImVec4(c1.Value.x, c1.Value.y, c1.Value.z, 1.0f);
    c[ImGuiCol_Separator] = ImVec4(c8.Value.x, c8.Value.y, c8.Value.z, 0.5f);
}

ImColor GetAccent() {
    if (themeAnimating) return g_ThemeAnim.Get(1);
    return ThemeColors[CurrentTheme][1];
}

ImColor GetAccent2() {
    if (themeAnimating) return g_ThemeAnim.Get(7);
    return ThemeColors[CurrentTheme][7];
}

ImColor GetTextCol() {
    if (themeAnimating) return g_ThemeAnim.Get(2);
    return ThemeColors[CurrentTheme][2];
}

ImColor GetFrameBg() {
    if (themeAnimating) return g_ThemeAnim.Get(5);
    return ThemeColors[CurrentTheme][5];
}

void InitThemeAnim() {
    for (int i = 0; i < 10; i++) {
        g_ThemeAnim.colors[i].Set(ThemeColors[CurrentTheme][i]);
    }
}

void BeginDrawStyle() {
    static bool initDone = false;
    if (!initDone) { InitThemeAnim(); initDone = true; }
    ImGuiStyle *s = &ImGui::GetStyle();
    s->WindowRounding = 10.0f;
    s->WindowTitleAlign = ImVec2(0.5f, 0.5f);
    s->FramePadding = ImVec2(12, 9);
    s->FrameRounding = 6.0f;
    s->ItemSpacing = ImVec2(10, 10);
    s->ItemInnerSpacing = ImVec2(8, 6);
    s->IndentSpacing = 20.0f;
    s->ScrollbarSize = 14.0f;
    s->ScrollbarRounding = 7.0f;
    s->GrabMinSize = 10.0f;
    s->GrabRounding = 6.0f;
    s->ChildRounding = 8.0f;
    s->WindowBorderSize = 0.0f;
    s->FrameBorderSize = 0.0f;
    s->ChildBorderSize = 0.0f;
    s->PopupBorderSize = 0.0f;
    s->TabBorderSize = 0.0f;
    s->TabRounding = 6.0f;
    s->WindowMenuButtonPosition = ImGuiDir_None;
    s->Colors[ImGuiCol_ScrollbarBg] = ImVec4(0.05f, 0.05f, 0.08f, 0.5f);
    FinalizeTheme();
}

struct TabItem {
    const char *icon;
    const char *label;
};

static const TabItem tabDefs[] = {
    {"\xe2\x97\x88", "ESP"},
    {"\xe2\x97\x88", "AIM"},
    {"\xe2\x9a\x99", "MISC"},
    {"\xf0\x9f\x8e\xa8", "SKIN"},
    {"\xe2\x84\xb9", "INFO"},
    {"\xe2\x9a\xa1", "CFG"}
};

int ActiveTab = 0;
int HoveredTab = -1;

ImGui::AnimFloat g_PanelOpacity(1.0f, 6.0f);
ImGui::AnimFloat g_PanelSlideX(0.0f, 5.0f);
float g_LastTabSwitch = 0.0f;

struct TabAnim {
    ImGui::AnimFloat indicatorPos;
    TabAnim() : indicatorPos(AnimFloat(0.0f, 8.0f)) {}
};

TabAnim g_TabAnim;
ImGui::AnimFloat g_FovPulse(1.0f, 2.0f);
float g_FovPulseTime = 0.0f;
ImGui::AnimFloat g_WatermarkFloat(0.0f, 3.0f);
float g_WatermarkTime = 0.0f;

ImColor TabIconColors[6];
ImGui::AnimColor g_TabIconColors[6];

void DrawTabBar(ImDrawList *dl, ImVec2 winPos, float tabBarWidth, float contentTop, float contentHeight) {
    ImVec2 tabBarStart = ImVec2(winPos.x, contentTop);
    ImVec2 tabBarEnd = ImVec2(winPos.x + tabBarWidth, contentTop + contentHeight);

    dl->AddRectFilled(tabBarStart, tabBarEnd, ColToU32(ImVec4(0.06f, 0.06f, 0.1f, 0.6f)), 0);

    dl->AddLine(ImVec2(tabBarEnd.x, tabBarStart.y), ImVec2(tabBarEnd.x, tabBarEnd.y),
        ColToU32(ImVec4(1, 1, 1, 0.06f)), 1.0f);

    float tabHeight = 54.0f;
    float tabGap = 2.0f;
    float totalTabs = 6;
    float startY = tabBarStart.y + 8.0f;

    float targetIndicator = ActiveTab * (tabHeight + tabGap);
    g_TabAnim.indicatorPos.SetTarget((float)targetIndicator);
    g_TabAnim.indicatorPos.Update();

    for (int i = 0; i < totalTabs; i++) {
        ImVec2 tabPos(tabBarStart.x, startY + i * (tabHeight + tabGap));
        ImVec2 tabSize(tabBarWidth, tabHeight);
        bool isActive = (ActiveTab == i);
        bool isHovered = (HoveredTab == i);

        ImRect tabRect(tabPos, ImVec2(tabPos.x + tabSize.x, tabPos.y + tabSize.y));
        if (ImGui::IsMouseHoveringRect(tabRect.Min, tabRect.Max)) {
            HoveredTab = i;
        }

        if (isActive) {
            ImColor activeBg = GetAccent();
            activeBg.Value.w = 0.15f;
            dl->AddRectFilled(tabPos, ImVec2(tabPos.x + tabSize.x, tabPos.y + tabSize.y),
                ColToU32(activeBg), 0);
            dl->AddRectFilled(
                ImVec2(tabPos.x, tabPos.y + 4),
                ImVec2(tabPos.x + 3, tabPos.y + tabSize.y - 4),
                ColToU32(GetAccent()), 2.0f);
        } else if (isHovered) {
            dl->AddRectFilled(tabPos, ImVec2(tabPos.x + tabSize.x, tabPos.y + tabSize.y),
                ColToU32(ImVec4(1, 1, 1, 0.04f)), 0);
        }

        ImColor iconCol = isActive ? GetAccent() : ImColor(100, 100, 130);
        ImColor textCol = isActive ? GetTextCol() : ImColor(130, 130, 160);

        ImVec2 iconPos(tabPos.x + 14, tabPos.y + 10);
        dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 16.0f, iconPos, ColToU32(iconCol), tabDefs[i].icon);

        ImVec2 labelPos(tabPos.x + 14, tabPos.y + 30);
        dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 11.0f, labelPos, ColToU32(textCol), tabDefs[i].label);
    }

    float indY = startY + g_TabAnim.indicatorPos.Get();
    ImColor indCol = GetAccent();
    indCol.Value.w = 0.5f;
    dl->AddRectFilled(
        ImVec2(tabBarStart.x + 2, indY + tabHeight - 2),
        ImVec2(tabBarEnd.x - 2, indY + tabHeight),
        ColToU32(indCol), 1.0f);
}

ImColor GetThemeAccent(int themeID) {
    return ThemeColors[themeID][1];
}

void DrawGlowRect(ImDrawList *dl, ImVec2 p1, ImVec2 p2, ImColor col, float radius, float glowSize) {
    for (int i = 5; i >= 0; i--) {
        float t = (float)i / 5.0f;
        float expand = glowSize * t;
        float alpha = col.Value.w * t * 0.12f;
        ImU32 c = ColToU32(ImVec4(col.Value.x, col.Value.y, col.Value.z, alpha));
        dl->AddRect(
            ImVec2(p1.x - expand, p1.y - expand),
            ImVec2(p2.x + expand, p2.y + expand),
            c, radius + expand * 0.3f, 0, 1.0f + t * 1.5f);
    }
}

void DrawESPControls() {
    ImDrawList *dl = ImGui::GetWindowDrawList();
    ImVec2 winPos = ImGui::GetWindowPos();
    ImVec2 cursor = ImGui::GetCursorScreenPos();

    ImGui::M_CyberHeader("PLAYER ESP", GetAccent());

    ImGui::BeginGroup();
    ImGui::M_SwitchCircle("Box", &g_Tog.Box);
    ImGui::SameLine();
    ImGui::M_SwitchCircle("Corner", &g_Tog.CornerBox);
    ImGui::M_SwitchCircle("Filled", &g_Tog.BoxFilled);
    ImGui::SameLine();
    ImGui::M_SwitchCircle("Line", &g_Tog.Line);
    ImGui::M_SwitchCircle("Bottom Line", &g_Tog.LineFromBottom);
    ImGui::SameLine();
    ImGui::M_SwitchCircle("Health Bar", &g_Tog.HealthBar);
    ImGui::M_SwitchCircle("Name", &g_Tog.Name);
    ImGui::SameLine();
    ImGui::M_SwitchCircle("Distance", &g_Tog.Distance);
    ImGui::M_SwitchCircle("Faction", &g_Tog.Faction);
    ImGui::SameLine();
    ImGui::M_SwitchCircle("Skeleton", &g_Tog.Skeleton);
    ImGui::M_SwitchCircle("Snapline", &g_Tog.Snaplines);
    ImGui::EndGroup();

    ImGui::Spacing();
    ImGui::PushItemWidth(180);
    ImGui::SliderFloat("Max Distance", &g_Cfg.ESPMaxDistance, 50, 2000, "%.0f m");
    ImGui::PopItemWidth();

    ImGui::Spacing();
    ImGui::M_CyberHeader("ITEM ESP", GetAccent2());
    ImGui::BeginGroup();
    ImGui::M_SwitchCircle("Items", &g_Tog.ItemESP);
    ImGui::SameLine();
    ImGui::M_SwitchCircle("Supplies", &g_Tog.SupplyESP);
    ImGui::M_SwitchCircle("Collectibles", &g_Tog.CollectibleESP);
    ImGui::SameLine();
    ImGui::M_SwitchCircle("Vehicles", &g_Tog.VehicleESP);
    ImGui::EndGroup();
}

void DrawAimbotControls() {
    ImGui::M_CyberHeader("AIMBOT SETTINGS", GetAccent());

    ImGui::BeginGroup();
    ImGui::M_SwitchCircle("Enable", &g_Tog.Aimbot);
    ImGui::SameLine();
    ImGui::M_SwitchCircle("Show FOV", &g_Tog.AimbotDrawFOV);
    ImGui::M_SwitchCircle("Smooth", &g_Tog.AimbotSmooth);
    ImGui::SameLine();
    ImGui::M_SwitchCircle("Prediction", &g_Tog.AimbotPrediction);
    ImGui::M_SwitchCircle("Auto Fire", &g_Tog.AimbotAutoFire);
    ImGui::SameLine();
    ImGui::M_SwitchCircle("Target Line", &g_Tog.AimbotTargetLine);
    ImGui::M_SwitchCircle("Visible Check", &g_Tog.AimbotVisibleCheck);
    ImGui::EndGroup();

    ImGui::Spacing();
    ImGui::PushItemWidth(200);
    ImGui::SliderFloat("FOV Range", &g_Cfg.AimbotRange, 10, 800, "%.0f px");
    ImGui::SliderFloat("Smooth Factor", &g_Cfg.AimbotSmoothValue, 1, 30, "%.1f");
    ImGui::SliderFloat("Max Distance", &g_Cfg.AimbotMaxDistance, 50, 1000, "%.0f m");
    const char *bones[] = { "Head", "Body", "Neck" };
    ImGui::Combo("Aim Bone", &g_Cfg.SelectedAimbotBone, bones, IM_ARRAYSIZE(bones));
    ImGui::PopItemWidth();
}

void DrawMiscControls() {
    ImGui::M_CyberHeader("VISUALS", GetAccent());

    ImGui::BeginGroup();
    ImGui::M_SwitchCircle("Crosshair", &g_Tog.ShowCrosshair);
    ImGui::SameLine();
    ImGui::M_SwitchCircle("Watermark", &g_Tog.ShowWatermark);
    ImGui::M_SwitchCircle("FPS", &g_Tog.ShowFPS);
    ImGui::SameLine();
    ImGui::M_SwitchCircle("Info Panel", &g_Tog.ShowInfo);
    ImGui::EndGroup();

    ImGui::Spacing();
    ImGui::M_CyberHeader("MISC FEATURES", GetAccent2());

    ImGui::BeginGroup();
    ImGui::M_SwitchCircle("No Recoil", &g_Tog.NoRecoil);
    ImGui::SameLine();
    ImGui::M_SwitchCircle("No Spread", &g_Tog.NoSpread);
    ImGui::M_SwitchCircle("No Clip", &g_Tog.NoClip);
    ImGui::SameLine();
    ImGui::M_SwitchCircle("God Mode", &g_Tog.GodMode);
    ImGui::M_SwitchCircle("Speed Hack", &g_Tog.SpeedHack);
    ImGui::SameLine();
    ImGui::M_SwitchCircle("Teleport", &g_Tog.Teleport);
    ImGui::EndGroup();

    ImGui::Spacing();
    ImGui::M_CyberHeader("FILTER", GetAccent());

    ImGui::BeginGroup();
    ImGui::M_SwitchCircle("Show Enemies", &g_Tog.FilterEnemy);
    ImGui::SameLine();
    ImGui::M_SwitchCircle("Show Team", &g_Tog.FilterTeam);
    ImGui::M_SwitchCircle("Visible Check", &g_Tog.FilterVisible);
    ImGui::SameLine();
    ImGui::M_SwitchCircle("Show Self", &g_Tog.FilterSelf);
    ImGui::EndGroup();
}

void DrawThemeControls() {
    ImGui::M_CyberHeader("THEME SELECTION", GetAccent());
    ImGui::Spacing();

    const char *themeNames[] = { "Neon Blue", "Rose Red", "Emerald", "Gold", "Royal Purple" };
    const char *themeIcons[] = { "\xe2\x97\x88", "\xe2\x99\xa5", "\xe2\x97\x86", "\xe2\x98\x85", "\xe2\x99\x9b" };
    ImColor themePreviews[] = {
        ImColor(0, 180, 255), ImColor(255, 80, 120),
        ImColor(0, 255, 120), ImColor(255, 200, 50),
        ImColor(150, 50, 255)
    };

    ImDrawList *dl = ImGui::GetWindowDrawList();
    ImVec2 startPos = ImGui::GetCursorScreenPos();
    float availWidth = ImGui::GetContentRegionAvail().x;
    float cardWidth = (availWidth - 20.0f) / 2.0f;
    float cardHeight = 68.0f;

    for (int i = 0; i < 5; i++) {
        int col = i % 2;
        int row = i / 2;
        ImVec2 cardPos(startPos.x + col * (cardWidth + 8.0f), startPos.y + row * (cardHeight + 8.0f));
        ImVec2 cardEnd(cardPos.x + cardWidth, cardPos.y + cardHeight);
        bool isActive = (CurrentTheme == i);
        bool isHovered = ImGui::IsMouseHoveringRect(cardPos, cardEnd);

        if (isActive) {
            ImColor activeBg = ThemeColors[i][1];
            activeBg.Value.w = 0.15f;
            dl->AddRectFilled(cardPos, cardEnd, ColToU32(activeBg), 8.0f);
            dl->AddRect(cardPos, cardEnd, ColToU32(ThemeColors[i][1]), 8.0f, 0, 2.0f);
        } else if (isHovered) {
            dl->AddRectFilled(cardPos, cardEnd, ColToU32(ImVec4(1, 1, 1, 0.05f)), 8.0f);
            dl->AddRect(cardPos, cardEnd, ColToU32(ImVec4(1, 1, 1, 0.1f)), 8.0f, 0, 1.0f);
        } else {
            dl->AddRectFilled(cardPos, cardEnd, ColToU32(ImVec4(0.08f, 0.08f, 0.12f, 0.6f)), 8.0f);
            dl->AddRect(cardPos, cardEnd, ColToU32(ImVec4(1, 1, 1, 0.05f)), 8.0f, 0, 1.0f);
        }

        ImVec2 iconPos(cardPos.x + 14, cardPos.y + 14);
        dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 22.0f, iconPos, ColToU32(themePreviews[i]), themeIcons[i]);

        ImVec2 namePos(cardPos.x + 44, cardPos.y + 14);
        dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 14.0f, namePos, ColToU32(ImColor(220, 220, 240)), themeNames[i]);

        ImVec2 barPos(cardPos.x + 44, cardPos.y + 38);
        for (int j = 0; j < 5; j++) {
            ImColor swatch = ThemeColors[i][j];
            dl->AddRectFilled(
                ImVec2(barPos.x + j * 22.0f, barPos.y),
                ImVec2(barPos.x + j * 22.0f + 18.0f, barPos.y + 12.0f),
                ColToU32(swatch), 3.0f);
        }

        if (isHovered && ImGui::IsMouseClicked(0) && !isActive) {
            ApplyTheme(i);
        }

        if (col == 1) ImGui::SetCursorScreenPos(ImVec2(startPos.x, cardEnd.y + 8.0f));
    }

    ImGui::Spacing();
    ImGui::Spacing();
    ImGui::M_CyberHeader("CUSTOM COLORS", GetAccent2());
    ImGui::Text("Accent: ");
    ImGui::SameLine();
    ImVec4 accentCol(g_Cfg.AccentColor.Value.x, g_Cfg.AccentColor.Value.y, g_Cfg.AccentColor.Value.z, 1.0f);
    if (ImGui::ColorEdit4("##accent", (float*)&accentCol, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel)) {
        g_Cfg.AccentColor = ImColor(accentCol.x, accentCol.y, accentCol.z);
    }
    ImGui::SameLine();
    ImGui::Text("  Secondary: ");
    ImGui::SameLine();
    ImVec4 accent2Col(g_Cfg.AccentColor2.Value.x, g_Cfg.AccentColor2.Value.y, g_Cfg.AccentColor2.Value.z, 1.0f);
    if (ImGui::ColorEdit4("##accent2", (float*)&accent2Col, ImGuiColorEditFlags_NoInputs | ImGuiColorEditFlags_NoLabel)) {
        g_Cfg.AccentColor2 = ImColor(accent2Col.x, accent2Col.y, accent2Col.z);
    }
}

void DrawSystemInfo() {
    ImGui::M_CyberHeader("SYSTEM INFORMATION", GetAccent());

    ImDrawList *dl = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float width = ImGui::GetContentRegionAvail().x;

    auto drawInfoRow = [&](const char *label, const char *value, ImColor valCol) {
        ImVec2 textPos = ImGui::GetCursorScreenPos();
        dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 13.0f, textPos, ColToU32(ImColor(140, 140, 170)), label);
        ImVec2 valSize = ImGui::CalcTextSize(value);
        dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 13.0f,
            ImVec2(textPos.x + width - valSize.x, textPos.y), ColToU32(valCol), value);
        ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 22.0f);
    };

    char buf[128];
    snprintf(buf, sizeof(buf), "%dx%d", _ScreenX, _ScreenY);
    drawInfoRow("Screen:", buf, GetTextCol());

    snprintf(buf, sizeof(buf), "%.1f FPS (%.2f ms)", ImGui::GetIO().Framerate, 1000.0f / ImGui::GetIO().Framerate);
    drawInfoRow("Performance:", buf, ImColor(0, 255, 150));

    snprintf(buf, sizeof(buf), "%d", g_Esp.PlayerCount);
    drawInfoRow("Players:", buf, GetAccent());

    snprintf(buf, sizeof(buf), "%s", g_Offsets.GamesTable[g_Offsets.CurrentGameID].GameName);
    drawInfoRow("Game:", buf, GetTextCol());

    snprintf(buf, sizeof(buf), "0x%lX", g_Offsets.UnityBase);
    drawInfoRow("Module Base:", buf, ImColor(100, 200, 255));

    snprintf(buf, sizeof(buf), "0x%lX", g_Offsets.UWorld);
    drawInfoRow("UWorld:", buf, ImColor(100, 200, 255));

    snprintf(buf, sizeof(buf), "0x%lX", g_Offsets.EntityListPtr);
    drawInfoRow("Entity List:", buf, ImColor(100, 200, 255));

    ImColor aimStatusCol = g_Bot.IsLocked ? ImColor(0, 255, 100) : ImColor(255, 180, 50);
    drawInfoRow("Aimbot:", g_Bot.IsLocked ? "LOCKED" : "IDLE", aimStatusCol);

    snprintf(buf, sizeof(buf), "Target #%d (%.1fm)", g_Bot.BestTarget.Index, g_Bot.BestTarget.Distance);
    drawInfoRow("Target:", buf, GetAccent());

    time_t t = time(nullptr);
    struct tm *now = localtime(&t);
    snprintf(buf, sizeof(buf), "%04d-%02d-%02d %02d:%02d:%02d",
             now->tm_year + 1900, now->tm_mon + 1, now->tm_mday,
             now->tm_hour, now->tm_min, now->tm_sec);
    drawInfoRow("Time:", buf, ImColor(150, 150, 200));

    ImGui::Spacing();
    ImGui::Spacing();
    ImGui::M_CyberHeader("PROTECTION STATUS", GetAccent2());
    ImGui::TextColored(ImColor(0, 255, 150), "  Anti-Debug: ACTIVE");
    ImGui::TextColored(ImColor(0, 255, 150), "  Anti-Tamper: ACTIVE");
    ImGui::TextColored(ImColor(0, 255, 150), "  Process Protection: ENABLED");
}

void DrawDraggableSlider(ImDrawList *dl, const char *label, float *val, float min, float max,
                         const char *fmt, ImVec2 pos, float width, ImColor accent) {
    float height = 28.0f;
    ImVec2 sliderPos(pos.x, pos.y + 20.0f);
    ImVec2 sliderEnd(sliderPos.x + width, sliderPos.y + 6.0f);
    float t = (*val - min) / (max - min);
    t = ImClamp(t, 0.0f, 1.0f);

    dl->AddRectFilled(sliderPos, sliderEnd, ColToU32(ImVec4(0.08f, 0.08f, 0.12f, 0.8f)), 3.0f);

    ImVec2 fillEnd = ImLerp(sliderPos, sliderEnd, t);
    ImColor gradA = accent;
    ImColor gradB = GetAccent2();
    dl->AddRectFilledMultiColor(sliderPos, fillEnd,
        ColToU32(gradA), ColToU32(gradB), ColToU32(gradB), ColToU32(gradA), 3.0f);

    float grabX = ImLerp(sliderPos.x, sliderEnd.x, t);
    float grabY = sliderPos.y + 3.0f;
    dl->AddCircleFilled(ImVec2(grabX, grabY), 8.0f, ColToU32(ImColor(255, 255, 255)), 24);
    dl->AddCircle(ImVec2(grabX, grabY), 8.0f, ColToU32(ImVec4(1, 1, 1, 0.3f)), 24, 1.5f);

    dl->AddText(ImVec2(pos.x, pos.y), ColToU32(ImColor(180, 180, 210)), label);
    char valBuf[32];
    snprintf(valBuf, sizeof(valBuf), fmt, *val);
    ImVec2 valSize = ImGui::CalcTextSize(valBuf);
    dl->AddText(ImVec2(sliderEnd.x - valSize.x, pos.y), ColToU32(GetTextCol()), valBuf);
}

void DrawSettingsPanel() {
    ImGui::M_CyberHeader("SAFETY", GetAccent());

    ImGui::BeginGroup();
    ImGui::M_SwitchCircle("Safe Mode", &g_Tog.SafeMode);
    ImGui::SameLine();
    ImGui::M_SwitchCircle("Stream Mode", &g_Tog.StreamMode);
    ImGui::EndGroup();

    ImGui::Spacing();
    ImGui::M_CyberHeader("RENDER SETTINGS", GetAccent2());

    ImDrawList *dl = ImGui::GetWindowDrawList();
    float availWidth = ImGui::GetContentRegionAvail().x;
    ImVec2 startPos = ImGui::GetCursorScreenPos();

    DrawDraggableSlider(dl, "Box Thickness", &g_Cfg.BoxWidth, 0.5f, 5.0f, "%.1f",
        startPos, availWidth, GetAccent());
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 58.0f);

    startPos = ImGui::GetCursorScreenPos();
    DrawDraggableSlider(dl, "Line Thickness", &g_Cfg.LineWidth, 0.5f, 3.0f, "%.1f",
        startPos, availWidth, GetAccent2());
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 58.0f);

    startPos = ImGui::GetCursorScreenPos();
    DrawDraggableSlider(dl, "Text Size", &g_Cfg.TextSize, 12, 32, "%.0f",
        startPos, availWidth, GetAccent());
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 58.0f);

    startPos = ImGui::GetCursorScreenPos();
    DrawDraggableSlider(dl, "Health Bar Width", &g_Cfg.HealthBarWidth, 2, 10, "%.0f",
        startPos, availWidth, GetAccent2());
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 58.0f);

    startPos = ImGui::GetCursorScreenPos();
    DrawDraggableSlider(dl, "Crosshair Size", &g_Cfg.CrosshairSize, 10, 50, "%.0f",
        startPos, availWidth, GetAccent());
    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 58.0f);

    ImGui::Spacing();
    ImGui::Spacing();

    ImVec2 btnPos = ImGui::GetCursorScreenPos();
    float btnWidth = (availWidth - 8.0f) * 0.5f;

    ImGui::M_GradientButton("Reset Settings", ImVec2(btnWidth, 40),
        ImColor(200, 50, 50), ImColor(150, 30, 30));

    ImGui::SameLine();

    ImGui::M_GradientButton("Save Config", ImVec2(btnWidth, 40),
        ImColor(50, 180, 50), ImColor(30, 130, 30));
}

static float LerpTime = 0.0f;

void DrawTitleBar(ImDrawList *dl, ImVec2 winPos, ImVec2 winSize) {
    float titleBarHeight = 42.0f;
    ImVec2 titleEnd(winPos.x + winSize.x, winPos.y + titleBarHeight);

    dl->AddRectFilled(winPos, titleEnd, ColToU32(ImVec4(0.05f, 0.05f, 0.09f, 0.95f)), 10.0f);
    ImGui::PushClipRect(winPos, titleEnd, true);
    dl->AddRectFilled(ImVec2(winPos.x, winPos.y + 10.0f), titleEnd,
        ColToU32(ImVec4(0.05f, 0.05f, 0.09f, 0.95f)), 0);
    ImGui::PopClipRect();

    dl->AddRectFilledMultiColor(
        ImVec2(winPos.x, winPos.y + titleBarHeight - 3),
        ImVec2(winPos.x + winSize.x, winPos.y + titleBarHeight),
        ColToU32(GetAccent()), ColToU32(GetAccent2()),
        ColToU32(GetAccent2()), ColToU32(GetAccent()));

    float glowAlpha = 0.3f + 0.1f * sinf(LerpTime * 2.0f);
    dl->AddRectFilledMultiColor(
        ImVec2(winPos.x, winPos.y + titleBarHeight - 5),
        ImVec2(winPos.x + winSize.x, winPos.y + titleBarHeight - 3),
        ColToU32(ImVec4(GetAccent().Value.x, GetAccent().Value.y, GetAccent().Value.z, glowAlpha * 0.3f)),
        ColToU32(ImVec4(GetAccent2().Value.x, GetAccent2().Value.y, GetAccent2().Value.z, glowAlpha * 0.3f)),
        ColToU32(ImVec4(GetAccent2().Value.x, GetAccent2().Value.y, GetAccent2().Value.z, glowAlpha * 0.3f)),
        ColToU32(ImVec4(GetAccent().Value.x, GetAccent().Value.y, GetAccent().Value.z, glowAlpha * 0.3f)));

    ImVec2 titlePos(winPos.x + 16, winPos.y + 6);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 18.0f, titlePos, ColToU32(GetAccent()), "BUGOR ENGINE");

    ImVec2 verPos(titlePos.x + ImGui::CalcTextSize("BUGOR ENGINE").x + 8, titlePos.y + 2);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 11.0f, verPos, ColToU32(ImColor(100, 100, 140)), "v2.0");

    float rightOffset = 50.0f;
    ImVec2 closePos(winPos.x + winSize.x - rightOffset, winPos.y + 8);
    ImVec2 closeSize(28, 26);
    bool closeHovered = ImGui::IsMouseHoveringRect(closePos, ImVec2(closePos.x + closeSize.x, closePos.y + closeSize.y));
    ImU32 closeCol = closeHovered ? ColToU32(ImColor(255, 80, 80)) : ColToU32(ImColor(120, 120, 160));
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 16.0f, ImVec2(closePos.x + 6, closePos.y + 3), closeCol, "\xe2\x9c\x96");
    if (closeHovered && ImGui::IsMouseClicked(0)) {
        g_Tog.SafeMode = !g_Tog.SafeMode;
    }
}

void DrawWatermarkOverlay() {
    if (!g_Tog.ShowWatermark) return;
    ImDrawList *dl = ImGui::GetForegroundDrawList();
    ImVec2 screenSize = ImGui::GetIO().DisplaySize;

    g_WatermarkTime += ImGui::GetIO().DeltaTime;
    g_WatermarkFloat.SetTarget(sinf(g_WatermarkTime * 1.5f) * 1.5f);
    g_WatermarkFloat.Update();
    float floatOffset = g_WatermarkFloat.Get();

    ImVec2 wmPos(12, 10 + floatOffset);
    ImVec2 wmSize(220, 36);
    ImColor bgCol(5, 5, 15, 180);
    dl->AddRectFilled(wmPos, ImVec2(wmPos.x + wmSize.x, wmPos.y + wmSize.y), ColToU32(bgCol), 6.0f);
    dl->AddRect(wmPos, ImVec2(wmPos.x + wmSize.x, wmPos.y + wmSize.y), ColToU32(GetAccent()), 6.0f, 0, 1.5f);

    char wmText[64];
    snprintf(wmText, sizeof(wmText), "BUGOR ENGINE v2.0  |  %d FPS", (int)ImGui::GetIO().Framerate);
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 13.0f, ImVec2(wmPos.x + 12, wmPos.y + 9),
        ColToU32(ImColor(200, 200, 230)), wmText);
}

void DrawNotification(const char *text, ImColor accent, float duration) {
    static float notifTime = 0.0f;
    static char notifText[128] = {0};
    static ImColor notifColor;
    static bool hasNotif = false;
    static ImGui::AnimFloat notifSlide(0.0f, 5.0f);
    static ImGui::AnimFloat notifAlpha(0.0f, 4.0f);

    notifSlide.Update();
    notifAlpha.Update();

    if (!hasNotif) {
        strncpy(notifText, text, sizeof(notifText) - 1);
        notifColor = accent;
        notifTime = 0.0f;
        hasNotif = true;
        notifSlide.Set(-80.0f);
        notifSlide.SetTarget(12.0f);
        notifAlpha.Set(0.0f);
        notifAlpha.SetTarget(1.0f);
    }

    notifTime += ImGui::GetIO().DeltaTime;

    ImDrawList *dl = ImGui::GetForegroundDrawList();
    ImVec2 screenSize = ImGui::GetIO().DisplaySize;
    ImVec2 textSize = ImGui::CalcTextSize(notifText);
    float notifWidth = textSize.x + 32.0f;
    float notifHeight = 40.0f;
    ImVec2 notifPos(notifSlide.Get(), 60.0f);
    ImVec2 notifEnd(notifPos.x + notifWidth, notifPos.y + notifHeight);

    ImColor bg(5, 5, 15, (int)(200 * notifAlpha.Get()));
    dl->AddRectFilled(notifPos, notifEnd, ColToU32(bg), 8.0f);
    dl->AddRect(notifPos, notifEnd, ColToU32(notifColor), 8.0f, 0, 1.5f);

    dl->AddRectFilled(notifPos, ImVec2(notifPos.x + 3, notifEnd.y), ColToU32(notifColor), 8.0f);

    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 14.0f,
        ImVec2(notifPos.x + 16, notifPos.y + (notifHeight - 16.0f) * 0.5f),
        ColToU32(ImVec4(1, 1, 1, notifAlpha.Get())), notifText);

    if (notifTime >= duration) {
        notifAlpha.SetTarget(0.0f);
        notifSlide.SetTarget(-notifWidth - 20.0f);
        if (notifAlpha.IsDone() && notifSlide.IsDone()) {
            hasNotif = false;
        }
    }
}

void ImGuiMainMenuWind() {
    ImGuiIO &io = ImGui::GetIO();
    io.ConfigWindowsMoveFromTitleBarOnly = false;
    BeginDrawStyle();

    LerpTime += io.DeltaTime;

    bool isOpen = true;
    ImGui::SetNextWindowSize(ImVec2(820, 560), ImGuiCond_Once);
    ImGui::SetNextWindowBgAlpha(0.0f);

    ImGui::Begin("Bugor Engine", &isOpen,
        ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize);

    Window = ImGui::GetCurrentWindow();
    ImDrawList *dl = ImGui::GetWindowDrawList();
    ImVec2 winPos = ImGui::GetWindowPos();
    ImVec2 winSize = ImGui::GetWindowSize();

    ImVec2 innerPos = winPos;
    ImVec2 innerSize = winSize;

    DrawGlowRect(dl, innerPos, ImVec2(innerPos.x + innerSize.x, innerPos.y + innerSize.y),
        GetAccent(), 10.0f, 14.0f);

    dl->AddRectFilled(innerPos, ImVec2(innerPos.x + innerSize.x, innerPos.y + innerSize.y),
        ColToU32(ImVec4(0.04f, 0.04f, 0.08f, 0.94f)), 10.0f);

    dl->AddRect(innerPos, ImVec2(innerPos.x + innerSize.x, innerPos.y + innerSize.y),
        ColToU32(ImVec4(1, 1, 1, 0.06f)), 10.0f, 0, 1.0f);

    DrawTitleBar(dl, winPos, winSize);

    float titleBarHeight = 42.0f;
    float contentTop = winPos.y + titleBarHeight + 2.0f;
    float contentBottom = winPos.y + winSize.y - 52.0f;
    float contentHeight = contentBottom - contentTop;
    float tabBarWidth = 66.0f;
    float contentX = winPos.x + tabBarWidth;
    float contentWidth = winSize.x - tabBarWidth - 4.0f;

    DrawTabBar(dl, winPos, tabBarWidth, contentTop, contentHeight);

    g_FovPulseTime += io.DeltaTime;
    g_FovPulse.SetTarget(1.0f + 0.02f * sinf(g_FovPulseTime * 3.0f));
    g_FovPulse.Update();

    {
        HoveredTab = -1;
        ImVec2 tabBarStart = ImVec2(winPos.x, contentTop);
        float tabHeight = 54.0f;
        float tabGap = 2.0f;
        float startY = tabBarStart.y + 8.0f;
        for (int i = 0; i < 6; i++) {
            ImVec2 tabPos(tabBarStart.x, startY + i * (tabHeight + tabGap));
            ImVec2 tabSize(tabBarWidth, tabHeight);
            ImRect tabRect(tabPos, ImVec2(tabPos.x + tabSize.x, tabPos.y + tabSize.y));
            if (ImGui::IsMouseHoveringRect(tabRect.Min, tabRect.Max)) {
                HoveredTab = i;
                if (ImGui::IsMouseClicked(0) && ActiveTab != i) {
                    ActiveTab = i;
                    g_LastTabSwitch = LerpTime;
                    g_PanelSlideX.Set(30.0f);
                    g_PanelSlideX.SetTarget(0.0f);
                    g_PanelOpacity.Set(0.6f);
                    g_PanelOpacity.SetTarget(1.0f);
                }
                break;
            }
        }
    }

    g_PanelOpacity.Update();
    g_PanelSlideX.Update();

    ImGui::SetCursorScreenPos(ImVec2(contentX + 12.0f + g_PanelSlideX.Get(), contentTop + 10.0f));

    ImGui::BeginGroup();

    ImVec2 contentArea = ImVec2(contentWidth - 24.0f, contentHeight - 20.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha, g_PanelOpacity.Get());

    ImGui::BeginChild("Content", contentArea, false);
    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(10, 10));

    switch (ActiveTab) {
        case 0: DrawESPControls(); break;
        case 1: DrawAimbotControls(); break;
        case 2: DrawMiscControls(); break;
        case 3: DrawThemeControls(); break;
        case 4: DrawSystemInfo(); break;
        case 5: DrawSettingsPanel(); break;
    }

    ImGui::PopStyleVar();
    ImGui::EndChild();
    ImGui::PopStyleVar();
    ImGui::EndGroup();

    float btnY = winPos.y + winSize.y - 44.0f;
    float btnWidth = 200.0f;
    float btnX = winPos.x + winSize.x * 0.5f - btnWidth * 0.5f;

    ImGui::SetCursorScreenPos(ImVec2(btnX, btnY));
    if (g_Tog.Rendering) {
        ImGui::M_GradientButton("ACTIVE", ImVec2(btnWidth, 36),
            ImColor(0, 200, 80), ImColor(0, 140, 50));
        if (ImGui::IsItemClicked()) {
            g_Tog.Rendering = false;
            g_Offsets.Reset();
        }
    } else {
        ImGui::M_GradientButton("INACTIVE - INIT", ImVec2(btnWidth, 36),
            ImColor(200, 50, 50), ImColor(140, 30, 30));
        if (ImGui::IsItemClicked()) {
            g_Tog.Rendering = true;
            int gameID = g_Offsets.DetectGame();
            if (gameID >= 0) g_Offsets.InitGame(gameID);
            if (!g_Offsets.Initialized) g_Tog.Rendering = false;
        }
    }

    ImGui::End();

    DrawWatermarkOverlay();

    if (g_Tog.Rendering) {
        g_Esp.Render(ImGui::GetForegroundDrawList());
    }
}

void initGui() {
    if (g_Initialized) return;
    initializeEGLContext();
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO &io = ImGui::GetIO();
    ImGui::StyleColorsDark();
    ImGui_ImplAndroid_Init(window_sv);
    ImGui_ImplOpenGL3_Init("#version 300 es");
    io.Fonts->AddFontFromMemoryTTF((void *)font_v, font_v_size, 22.0f, NULL, io.Fonts->GetGlyphRangesChineseFull());
    BeginDrawStyle();
    io.IniFilename = NULL;
    g_Initialized = true;
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    abs_ScreenX = (_ScreenX > _ScreenY ? _ScreenX : _ScreenY);
    abs_ScreenY = (_ScreenX < _ScreenY ? _ScreenX : _ScreenY);

    AntiDebug::ProtectProcess();
    AntiDebug::CrashIfDebugged();
    AntiDebug::AntiTamper();

    while (true) {
        ImGuiMainWinStart();
        ImGuiMainMenuWind();
        ImGuiMainWinEnded();
    }
}
#endif
