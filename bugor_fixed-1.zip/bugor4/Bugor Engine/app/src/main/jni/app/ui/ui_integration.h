#pragma once

#include "../Config.h"
#include "../GameOffsets.h"
#include "../MemoryIO.h"
#include "../ESP.h"
#include "../Aimbot.h"
#include <imgui.h>

extern Config g_Cfg;
extern Toggles g_Tog;
extern GameOffsets g_Offsets;
extern Aimbot g_Bot;
extern ESP g_Esp;
extern MemoryIO *g_Mem;
extern int g_ActiveTab;

void DrawTabESP(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize);
void DrawTabAimbot(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize);
void DrawTabMisc(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize);
void DrawTabSkin(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize);
void DrawTabInfo(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize);
void DrawTabConfig(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize);
void DrawTabRadar(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize);
void DrawTabLoot(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize);
void DrawTabPlayers(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize);
void DrawTabTheme(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize);

void InitTabESP();
void InitTabAimbot();
void InitTabMisc();
void InitTabSkin();
void InitTabInfo();
void InitTabConfig();
void InitTabRadar();
void InitTabLoot();
void InitTabPlayers();
void InitTabTheme();
void ShutdownTabESP();
void ShutdownTabAimbot();
void ShutdownTabMisc();
void ShutdownTabSkin();
void ShutdownTabInfo();
void ShutdownTabConfig();
void ShutdownTabRadar();
void ShutdownTabLoot();
void ShutdownTabPlayers();
void ShutdownTabTheme();
void SaveConfig();
void LoadConfig();
void ResetConfig();

void DrawCompass(ImDrawList* dl, float playerAngle);
void DrawRadarOverlay();
void DrawCrosshair(ImDrawList* dl, float dt);
void DrawInfoPanel(ImDrawList* dl, float dt);
void DrawNotifications(ImDrawList* dl, float dt);
void PushNotification(const char* text, ImColor color, float duration, int type);
void DrawWatermarkFull(ImDrawList* dl, float fps, int playerCount, int ping, const char* version, const char* build);

void DrawGlowRect(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor col, float radius, float glowSize, float intensity);
void DrawGlowCircle(ImDrawList* dl, ImVec2 center, float radius, ImColor col, float glowSize, float intensity);
void DrawGlowLine(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor col, float thickness, float glowSize);
void DrawShadowRect(ImDrawList* dl, ImVec2 p1, ImVec2 p2, float radius, float shadowSize, ImColor shadowColor);
void DrawBlurredRect(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor baseColor, ImColor edgeColor, float radius, float blurSize);
void DrawFrostedGlass(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor tint, float blurSize);
void DrawGradientRect(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor topLeft, ImColor topRight, ImColor bottomLeft, ImColor bottomRight, float rounding);
void DrawGradientLine(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor colA, ImColor colB, float thickness);
void DrawGradientCircle(ImDrawList* dl, ImVec2 center, float radius, ImColor inner, ImColor outer, int segments);
void DrawVignette(ImDrawList* dl, ImVec2 screenSize, float intensity);
void DrawScanlines(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor col, float spacing, float alpha);
void DrawGridOverlay(ImDrawList* dl, ImVec2 p1, ImVec2 p2, float spacing, ImColor col);
void DrawCheckerboard(ImDrawList* dl, ImVec2 p1, ImVec2 p2, float tileSize, ImColor colA, ImColor colB);
void DrawGlowText(ImDrawList* dl, const char* text, ImVec2 pos, ImColor col, float glowSize);
void DrawEffectScanline(ImDrawList* dl, ImVec2 pos, ImVec2 size, float time);
void DrawEffectGrid(ImDrawList* dl, ImVec2 pos, ImVec2 size, float alpha);
void DrawEffectVignette(ImDrawList* dl, ImVec2 pos, ImVec2 size, float intensity);
void DrawEffectBorderGlow(ImDrawList* dl, ImVec2 pos, ImVec2 size, ImColor col, float pulse);
void DrawEffectParticleSpawn(ImDrawList* dl, ImVec2 pos, ImVec2 size, float density);
void DrawEffectDataStream(ImDrawList* dl, ImVec2 pos, ImVec2 size, int count);
void RenderParticles(ImDrawList* dl);
void UpdateFireworks(ImDrawList* dl);
void RenderTrail(ImDrawList* dl);
void ClearAllParticleSystems();
