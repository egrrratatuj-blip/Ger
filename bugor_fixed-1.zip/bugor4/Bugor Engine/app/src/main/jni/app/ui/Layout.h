#pragma once
#include "../Config.h"
#include "../MemoryIO.h"
#include "../GameOffsets.h"
#include "../ESP.h"
#include "../Aimbot.h"
#include "../AntiDebug.h"
#include "imgui/Font.h"
#include "imgui/window_icon.h"
#include "imgui/safe_icon.h"
#include "../../imgui/mycustom/imgui_Custom.h"
#include "../../imgui/backends/imgui_Input_android.h"
#include "ui_integration.h"

struct ThemeColorSet {
    ImColor bg, accent, text, titleBg, button, frameBg, accentHover, accentActive, borderAlt, frameAlt;
};

struct AnimTheme {
    ImGui::AnimColor colors[10];
    bool active;
    AnimTheme() : active(false) {}
    void SetTarget(int themeID);
    void Update();
    ImColor Get(int idx);
    ImVec4 GetV4(int idx);
};

enum class WindowPhase {
    CLOSED,
    OPENING,
    OPEN,
    CLOSING
};

struct WindowState {
    ImVec2 position;
    ImVec2 size;
    ImVec2 dragOffset;
    bool isDragging;
    bool isOpen;
    float alpha;
    float targetAlpha;
    float scale;
    float targetScale;
    float cornerRadius;
    WindowPhase phase;
    ImVec2 lastFrameSize;
    ImVec2 velocity;
    bool snapEnabled;
    int snapMargin;

    ImGui::AnimFloat animAlpha;
    ImGui::AnimFloat animScale;
    ImGui::AnimFloat animCorner;

    WindowState()
        : position(0,0), size(960,640), dragOffset(0,0)
        , isDragging(false), isOpen(false)
        , alpha(0.0f), targetAlpha(0.0f)
        , scale(0.85f), targetScale(1.0f)
        , cornerRadius(10.0f)
        , phase(WindowPhase::CLOSED)
        , lastFrameSize(960,640), velocity(0,0)
        , snapEnabled(true), snapMargin(20)
        , animAlpha(0.0f, 6.0f)
        , animScale(0.85f, 5.0f)
        , animCorner(10.0f, 4.0f)
    {}
};

struct TabDefinition {
    const char *icon;
    const char *label;
    const char *tooltip;
    void (*drawFunc)(ImDrawList*, ImVec2, ImVec2);
    void (*initFunc)();
    void (*shutdownFunc)();
    bool isInitialized;
    bool isEnabled;
    float scrollPosY;
    int badgeCount;

    TabDefinition()
        : icon(nullptr), label(nullptr), tooltip(nullptr)
        , drawFunc(nullptr), initFunc(nullptr), shutdownFunc(nullptr)
        , isInitialized(false), isEnabled(true)
        , scrollPosY(0.0f), badgeCount(0)
    {}
};

struct LayoutEvent {
    enum Type {
        TAB_CHANGE,
        TOGGLE_ACTIVE,
        WINDOW_CLOSE,
        CONFIG_SAVE,
        THEME_CHANGE,
        TAB_INIT,
        TAB_SHUTDOWN,
        WINDOW_RESIZE,
        WINDOW_MOVE,
        SNAP_OCCURRED,
        PINCH_SCALE,
        DIRTY_FLUSH
    };
    Type type;
    union {
        int tabIndex;
        bool toggleState;
        float scaleFactor;
    } data;
    float timestamp;
};

struct FrameTiming {
    float deltaTime;
    float fps;
    float frameTimeMs;
    float avgFrameTime;
    float minFrameTime;
    float maxFrameTime;
    int frameCount;
    int fpsCounter;
    float fpsTimer;
    double totalTime;
    uint64_t frameNumber;

    FrameTiming()
        : deltaTime(0.016f), fps(60.0f), frameTimeMs(16.0f)
        , avgFrameTime(16.0f), minFrameTime(16.0f), maxFrameTime(16.0f)
        , frameCount(0), fpsCounter(0), fpsTimer(0.0f)
        , totalTime(0.0), frameNumber(0)
    {}
};

struct RenderMetrics {
    float drawCallCount;
    float vertexCount;
    float indexCount;
    float uiBuildTime;
    float renderTime;
    float espRenderTime;
    float aimbotUpdateTime;
    float totalFrameTime;
    float eglSwapTime;

    RenderMetrics()
        : drawCallCount(0), vertexCount(0), indexCount(0)
        , uiBuildTime(0), renderTime(0), espRenderTime(0), aimbotUpdateTime(0)
        , totalFrameTime(0), eglSwapTime(0)
    {}
};

struct TouchState {
    ImVec2 positions[10];
    ImVec2 lastPositions[10];
    float pressTimes[10];
    bool active[10];
    int touchCount;
    bool isPinching;
    float pinchDistance;
    float lastPinchDistance;
    float pinchScale;
    ImVec2 pinchCenter;
    bool tapDetected;
    ImVec2 tapPosition;
    float tapTime;
    bool longPressDetected;
    ImVec2 longPressPosition;
    float lastTapTime;
    int tapCount;

    bool wasTouching;
    bool wasMultiTouch;
    float swipeStartX;
    float swipeStartY;
    float swipeDeltaX;
    float swipeDeltaY;
    float swipeVelocityX;
    float swipeVelocityY;
    ImVec2 swipeStartPos;
    bool swipeActive;
    bool swipeHandled;
    int pendingSwipeTabDir;
    float scrollAccumY;
    float scrollAccumX;
    bool rightClickPending;
    ImVec2 rightClickPos;

    TouchState()
        : touchCount(0), isPinching(false)
        , pinchDistance(0), lastPinchDistance(0), pinchScale(1.0f)
        , pinchCenter(0,0)
        , tapDetected(false), tapPosition(0,0), tapTime(0)
        , longPressDetected(false), longPressPosition(0,0)
        , lastTapTime(0), tapCount(0)
        , wasTouching(false), wasMultiTouch(false)
        , swipeStartX(0), swipeStartY(0)
        , swipeDeltaX(0), swipeDeltaY(0)
        , swipeVelocityX(0), swipeVelocityY(0)
        , swipeStartPos(0,0)
        , swipeActive(false), swipeHandled(false)
        , pendingSwipeTabDir(0)
        , scrollAccumY(0), scrollAccumX(0)
        , rightClickPending(false), rightClickPos(0,0)
    {
        for (int i = 0; i < 10; i++) {
            positions[i] = ImVec2(0,0);
            lastPositions[i] = ImVec2(0,0);
            pressTimes[i] = 0.0f;
            active[i] = false;
        }
    }
};

struct InputState {
    TouchState touch;
    bool anyDown;
    bool anyPressed;
    bool anyReleased;
    ImVec2 mousePos;
    ImVec2 lastMousePos;
    ImVec2 mouseDelta;
    float mouseWheel;
    int keyDown[256];
    int keyPressed[256];
    bool backButtonDown;
    bool menuButtonDown;

    InputState()
        : anyDown(false), anyPressed(false), anyReleased(false)
        , mousePos(0,0), lastMousePos(0,0), mouseDelta(0,0)
        , mouseWheel(0)
        , backButtonDown(false), menuButtonDown(false)
    {
        memset(keyDown, 0, sizeof(keyDown));
        memset(keyPressed, 0, sizeof(keyPressed));
    }
};

struct DirtyFlags {
    bool fullRedraw;
    bool tabBarDirty;
    bool contentDirty;
    bool titleBarDirty;
    bool footerDirty;
    bool overlayDirty;
    bool espDirty;
    bool themeDirty;

    DirtyFlags()
        : fullRedraw(true), tabBarDirty(true), contentDirty(true)
        , titleBarDirty(true), footerDirty(true)
        , overlayDirty(true), espDirty(true), themeDirty(true)
    {}
    void SetAll() {
        fullRedraw = tabBarDirty = contentDirty = titleBarDirty =
        footerDirty = overlayDirty = espDirty = themeDirty = true;
    }
    void ClearAll() {
        fullRedraw = tabBarDirty = contentDirty = titleBarDirty =
        footerDirty = overlayDirty = espDirty = themeDirty = false;
    }
};

using LayoutEventCallback = std::function<void(const LayoutEvent&)>;
using TabDrawFunction = void(*)(ImDrawList*, ImVec2, ImVec2);
using EffectDrawFunction = void(*)(ImDrawList*, ImVec2, ImVec2, float);

enum class ContentGridLayout {
    FOUR_COLUMN,
    THREE_COLUMN,
    TWO_COLUMN,
    SINGLE_COLUMN
};

struct ContentSection {
    const char *label;
    bool collapsed;
    float animHeight;
    ImGui::AnimFloat animCollapse;
    ImColor accentColor;

    ContentSection(const char *lbl = "", ImColor acc = ImColor(0,180,255))
        : label(lbl), collapsed(false), animHeight(0)
        , animCollapse(1.0f, 6.0f), accentColor(acc)
    {}
};

struct IntegrationCallbacks {
    LayoutEventCallback onTabChange;
    LayoutEventCallback onToggleActive;
    LayoutEventCallback onWindowClose;
    LayoutEventCallback onConfigSave;
    LayoutEventCallback onThemeChange;
    LayoutEventCallback onWindowResize;
    LayoutEventCallback onWindowMove;
    std::function<void()> onFrameBegin;
    std::function<void()> onFrameEnd;
    std::function<void(ImDrawList*)> onOverlayPre;
    std::function<void(ImDrawList*)> onOverlayPost;
    std::function<bool(const char*)> onPluginCommand;
};

extern const int WINDOW_WIDTH;
extern const int WINDOW_HEIGHT;
extern const int TITLEBAR_HEIGHT;
extern const int TABBAR_WIDTH;
extern const int FOOTER_HEIGHT;
extern const int MAX_TABS;
extern const int CONTENT_PADDING;
extern const float EDGE_SNAP_THRESHOLD;
extern const float MIN_WINDOW_SCALE;
extern const float MAX_WINDOW_SCALE;
extern const float FADE_ANIM_SPEED;
extern const int WINDOW_BORDER_RADIUS;

extern WindowState g_WindowState;
extern ImVec2 g_ScreenSize;
extern FrameTiming g_FrameTiming;
extern RenderMetrics g_RenderMetrics;
extern InputState g_InputState;
extern DirtyFlags g_DirtyFlags;
extern int g_ActiveTab;
extern int g_HoveredTab;
extern int g_PreviousTab;
extern float g_TabTransitionProgress;
extern bool g_TabTransitionActive;
extern ContentGridLayout g_CurrentGridLayout;
extern float g_ContentScrollPositions[MAX_TABS];
extern IntegrationCallbacks g_Callbacks;
extern std::vector<LayoutEventCallback> g_EventListeners;
extern std::vector<EffectDrawFunction> g_ExternalOverlays;
extern bool g_LayoutInitialized;
extern float g_GlobalTime;
extern float g_PulsePhase;
extern float g_BreathPhase;
extern int g_ActiveThemePreset;
extern bool g_ConfigNeedsSave;
extern char g_VersionString[32];
extern char g_BuildDate[32];
extern bool g_FooterToggleState;
extern float g_FooterPulseTime;
extern ImGui::AnimFloat g_FooterPulseAnim;
extern ImColor g_TabIconColors[MAX_TABS];
extern ImGui::AnimColor g_TabIconAnimColors[MAX_TABS];

extern void DrawEffectGlow(ImDrawList *dl, ImVec2 pos, ImVec2 size, float intensity);
extern void DrawEffectScanline(ImDrawList *dl, ImVec2 pos, ImVec2 size, float time);
extern void DrawEffectGrid(ImDrawList *dl, ImVec2 pos, ImVec2 size, float alpha);
extern void DrawEffectVignette(ImDrawList *dl, ImVec2 pos, ImVec2 size, float intensity);
extern void DrawEffectBorderGlow(ImDrawList *dl, ImVec2 pos, ImVec2 size, ImColor col, float pulse);
extern void DrawEffectParticleSpawn(ImDrawList *dl, ImVec2 pos, ImVec2 size, float density);
extern void DrawEffectRipple(ImDrawList *dl, ImVec2 center, float radius, float alpha);
extern void DrawEffectLensFlare(ImDrawList *dl, ImVec2 pos, float brightness);
extern void DrawEffectNoise(ImDrawList *dl, ImVec2 pos, ImVec2 size, float alpha);
extern void DrawEffectGradientOverlay(ImDrawList *dl, ImVec2 pos, ImVec2 size, ImColor a, ImColor b, bool vertical);
extern void DrawEffectScanlineHUD(ImDrawList *dl, ImVec2 pos, ImVec2 size, float speed);
extern void DrawEffectDataStream(ImDrawList *dl, ImVec2 pos, ImVec2 size, int count);

class TabManager {
public:
    TabManager();
    ~TabManager();

    int RegisterTab(const char *icon, const char *label, const char *tooltip,
                    TabDrawFunction drawFunc,
                    void (*initFunc)() = nullptr,
                    void (*shutdownFunc)() = nullptr);
    bool SetActive(int index);
    int GetActive() const;
    int GetCount() const;
    int GetEnabledCount() const;
    TabDefinition* GetTab(int index);
    bool EnableTab(int index, bool enable);
    bool IsTabEnabled(int index) const;
    bool IsTabVisible(int index) const;
    void AnimateSwitch(int newIndex);
    float GetTransitionProgress() const;
    bool IsTransitioning() const;
    const char* GetTabLabel(int index) const;
    const char* GetTabIcon(int index) const;
    void SetBadge(int index, int count);
    int GetBadge(int index) const;
    void UpdateAnimations();
    void ShutdownAll();
    void InitAll();

private:
    TabDefinition tabs[MAX_TABS];
    int tabCount;
    int activeTab;
    int previousTab;
    int hoveredTab;
    bool transitioning;
    float transitionProgress;
    float transitionTimer;
    ImGui::AnimFloat indicatorPos;
    ImGui::AnimFloat contentSlideX;
    ImGui::AnimFloat contentFade;
};

class LayoutEngine {
public:
    LayoutEngine();
    ~LayoutEngine();

    bool Init();
    void Render();
    void Shutdown();

    ImVec2 GetContentArea() const;
    ImVec2 GetTabBarArea() const;
    ImVec2 GetTitleBarArea() const;
    ImVec2 GetFooterArea() const;
    ImRect GetContentRect() const;
    ImRect GetWindowRect() const;
    float GetContentWidth() const;
    float GetContentHeight() const;
    float GetWindowAlpha() const;

    void ToggleWindow();
    void OpenWindow();
    void CloseWindow();
    bool IsWindowOpen() const;
    WindowPhase GetWindowPhase() const;

    void SetPosition(ImVec2 pos);
    void SetSize(ImVec2 size);
    ImVec2 GetPosition() const;
    ImVec2 GetSize() const;

    void SetScale(float s);
    float GetScale() const;

    void SetCornerRadius(float r);
    float GetCornerRadius() const;

    void CenterWindow();
    void SnapToEdges();
    void ApplyWindowConstraints();

    void BeginFrame();
    void EndFrame();
    void MainLayout();

    void DrawBackground(ImDrawList *dl);
    void DrawTitleBar(ImDrawList *dl);
    void DrawTabBar(ImDrawList *dl);
    void DrawContentArea(ImDrawList *dl);
    void DrawFooter(ImDrawList *dl);
    void DrawOverlays(ImDrawList *dl);
    void DrawESPOverlay(ImDrawList *dl);

    void HandleInput();
    void HandleTouchInput();
    void HandlePinchGesture();
    void HandleLongPress();
    void HandleSwipeGesture();
    void HandleDrag();
    void HandleTabInput();

    void UpdateFrameTiming();
    void UpdateAnimations();
    void UpdateGlobalTime();
    void UpdateDirtyFlags();

    TabManager* GetTabManager();
    WindowState* GetWindowState();
    FrameTiming* GetFrameTiming();
    InputState* GetInputState();
    IntegrationCallbacks* GetCallbacks();
    DirtyFlags* GetDirtyFlags();

    void RegisterEventListener(LayoutEventCallback callback);
    void EmitEvent(const LayoutEvent &event);
    void ProcessEvents();

    void AddExternalOverlay(EffectDrawFunction func);
    void RemoveExternalOverlay(EffectDrawFunction func);
    void ClearExternalOverlays();
    int GetExternalOverlayCount() const;

    void SetContentGridLayout(ContentGridLayout layout);
    ContentGridLayout GetContentGridLayout() const;

    void RememberContentScroll(int tabIndex, float scrollY);
    float GetContentScroll(int tabIndex) const;

    void RequestConfigSave();
    bool IsConfigSaveRequested() const;
    void ClearConfigSaveRequest();

    float GetPulsePhase() const;
    float GetBreathPhase() const;

    void SetVersion(const char *version);
    const char* GetVersion() const;

    void SetBuildDate(const char *date);
    const char* GetBuildDate() const;

    bool IsInitialized() const;

private:
    TabManager tabManager;
    WindowState windowState;
    FrameTiming frameTiming;
    RenderMetrics renderMetrics;
    InputState inputState;
    DirtyFlags dirtyFlags;
    IntegrationCallbacks callbacks;
    std::vector<LayoutEventCallback> eventListeners;
    std::vector<EffectDrawFunction> externalOverlays;
    std::vector<LayoutEvent> eventQueue;

    bool initialized;
    float globalTime;
    float pulsePhase;
    float breathPhase;
    int activeThemePreset;
    bool configNeedsSave;
    char versionString[32];
    char buildDate[32];
    bool footerToggleState;
    float footerPulseTime;
    ImGui::AnimFloat footerPulseAnim;
    ContentGridLayout currentGridLayout;
    float contentScrollPositions[MAX_TABS];
    ImColor tabIconColors[MAX_TABS];
    ImGui::AnimColor tabIconAnimColors[MAX_TABS];
    float previousTouchDist;
    bool wasPinching;
    ImVec2 touchStartPos[10];
    float touchStartTimes[10];
    bool longPressFired[10];
    bool touchMovedSignificantly[10];
    int lastFrameTouchCount;
    ImVec2 dragStartMouse;
    ImVec2 dragStartWindow;
    bool dragStarted;
    TitleBarHitResult titleBarHit;
    float lastFrameBeginTime;
    float lastFrameEndTime;
    int frameSkipCounter;
    bool skipThisFrame;
    uint32_t espToggleChecksum;
    uint32_t lastEspToggleChecksum;
    bool espDirtyFlag;
    std::mutex eventMutex;
};

enum class TitleBarHitResult {
    NONE,
    TITLE_BAR,
    CLOSE_BUTTON,
    MINIMIZE_BUTTON,
    SETTINGS_BUTTON
};

extern LayoutEngine g_Layout;
