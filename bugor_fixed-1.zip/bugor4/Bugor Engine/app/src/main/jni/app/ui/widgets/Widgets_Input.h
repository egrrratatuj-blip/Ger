#pragma once
#include "../../../../imgui/imgui.h"

void M_SearchBar(const char* id, char* buf, int bufSize, ImColor accent = ImColor(0, 180, 255));
