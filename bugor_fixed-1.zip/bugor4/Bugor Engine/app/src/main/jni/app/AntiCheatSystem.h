#pragma once

namespace AntiCheatSystem {

bool DetectOtherCheats();
bool DetectHooks();
bool IsEmulator();
void StartMonitoring();
void StopMonitoring();

}
