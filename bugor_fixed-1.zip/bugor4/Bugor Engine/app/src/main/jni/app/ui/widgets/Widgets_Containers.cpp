#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "../../../../imgui/imgui.h"
#include "../../../../imgui/imgui_internal.h"
#include "../../../../imgui/mycustom/imgui_Custom.h"

static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }

void M_CyberHeader(const char* title, ImColor accent, const char* subtitle)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float totalH = 36.0f;
    float barX = pos.x;
    float barY = pos.y + (totalH - 24.0f) * 0.5f;
    float barW = 3.0f;
    float barH = 24.0f;
    dl->AddRectFilled(ImVec2(barX, barY), ImVec2(barX + barW, barY + barH), C(accent), 1.5f);
    ImColor barGlow = accent;
    barGlow.Value.w *= 0.3f;
    dl->AddRectFilled(ImVec2(barX - 2.0f, barY - 2.0f), ImVec2(barX + barW + 2.0f, barY + barH + 2.0f), C(barGlow), 3.5f);
    float titleX = barX + barW + 10.0f;
    float titleY = pos.y + 2.0f;
    ImColor titleCol = accent;
    float brightMul = 1.3f;
    titleCol.Value.x = ImClamp(titleCol.Value.x * brightMul, 0.0f, 1.0f);
    titleCol.Value.y = ImClamp(titleCol.Value.y * brightMul, 0.0f, 1.0f);
    titleCol.Value.z = ImClamp(titleCol.Value.z * brightMul, 0.0f, 1.0f);
    dl->AddText(ImVec2(titleX, titleY), C(titleCol), title);
    float lineY = barY + barH * 0.5f;
    float lineStartX = barX + barW + 4.0f;
    float availW = ImGui::GetContentRegionAvail().x;
    float lineEndX = pos.x + availW - 4.0f;
    ImColor baseLineCol = accent;
    for (int i = 0; i < 5; i++)
    {
        float alpha = 1.0f - i * 0.2f;
        float yOff = (i % 2 == 0) ? -1.0f - i * 0.3f : 1.0f + i * 0.3f;
        float lineLen = (lineEndX - lineStartX) * (1.0f - i * 0.12f);
        ImColor lc = baseLineCol;
        lc.Value.w *= alpha;
        float lw = 1.0f - i * 0.12f;
        if (lw < 0.3f) lw = 0.3f;
        dl->AddLine(ImVec2(lineStartX + 12.0f, lineY + yOff), ImVec2(lineStartX + 12.0f + lineLen, lineY + yOff), C(lc), lw);
        float dotX = lineStartX + 12.0f + lineLen;
        float dotR = 2.0f - i * 0.25f;
        if (dotR < 0.6f) dotR = 0.6f;
        ImColor dotCol = lc;
        dotCol.Value.w *= 0.7f;
        dl->AddCircleFilled(ImVec2(dotX, lineY + yOff), dotR, C(dotCol), 12);
        if (i == 0)
        {
            ImColor dotGlow = dotCol;
            dotGlow.Value.w *= 0.4f;
            dl->AddCircleFilled(ImVec2(dotX, lineY + yOff), dotR * 2.5f, C(dotGlow), 12);
        }
    }
    if (subtitle)
    {
        float subY = titleY + 18.0f;
        ImColor subCol(130, 130, 160, 180);
        dl->AddText(ImVec2(titleX, subY), C(subCol), subtitle);
        ImColor subLine = accent;
        subLine.Value.w *= 0.15f;
        dl->AddLine(ImVec2(titleX, subY + ImGui::GetTextLineHeight() + 2.0f), ImVec2(titleX + ImGui::CalcTextSize(subtitle).x, subY + ImGui::GetTextLineHeight() + 2.0f), C(subLine), 1.0f);
    }
    ImVec2 extraGlowStart(barX - 4.0f, barY + barH * 0.5f - 10.0f);
    ImVec2 extraGlowEnd(barX + 2.0f, barY + barH * 0.5f + 10.0f);
    ImColor extraGlowCol = accent;
    extraGlowCol.Value.w *= 0.15f;
    dl->AddRectFilled(extraGlowStart, extraGlowEnd, C(extraGlowCol), 5.0f);
    ImGui::Dummy(ImVec2(0, totalH));
}

struct CardAnimData
{
    ImGuiID id;
    AnimFloat arrowAngle;
    bool lastCollapsed;
    AnimFloat hoverGlow;
    AnimFloat shadowSpread;
};

static ImVector<CardAnimData> s_CardAnims;

static CardAnimData* FindOrCreateCardAnim(ImGuiID id)
{
    for (int i = 0; i < s_CardAnims.Size; i++)
    {
        if (s_CardAnims[i].id == id) return &s_CardAnims[i];
    }
    CardAnimData d;
    d.id = id;
    d.arrowAngle = AnimFloat(0.0f, 10.0f);
    d.lastCollapsed = false;
    d.hoverGlow = AnimFloat(0.0f, 6.0f);
    d.shadowSpread = AnimFloat(3.0f, 5.0f);
    s_CardAnims.push_back(d);
    return &s_CardAnims[s_CardAnims.Size - 1];
}

bool M_CardBegin(const char* id, bool* collapsed, ImColor accent)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImGuiWindow* win = ImGui::GetCurrentWindow();
    if (win->SkipItems) return false;
    ImGuiID uid = win->GetID(id);
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float fullW = ImGui::GetContentRegionAvail().x;
    if (fullW < 10.0f) fullW = 10.0f;
    float headerH = 38.0f;
    ImRect bb(pos, ImVec2(pos.x + fullW, pos.y + headerH));
    ImGui::ItemSize(ImVec2(fullW, headerH));
    if (!ImGui::ItemAdd(bb, uid)) return false;
    CardAnimData* anim = FindOrCreateCardAnim(uid);
    float dt = ImGui::GetIO().DeltaTime;
    anim->arrowAngle.SetTarget(*collapsed ? 0.0f : 1.0f);
    anim->arrowAngle.Update(dt);
    bool hovered = ImGui::IsMouseHoveringRect(bb.Min, bb.Max);
    anim->hoverGlow.SetTarget(hovered ? 1.0f : 0.0f);
    anim->hoverGlow.Update(dt);
    anim->shadowSpread.SetTarget(hovered ? 6.0f : 3.0f);
    anim->shadowSpread.Update(dt);
    bool changed = false;
    if (hovered && ImGui::IsMouseClicked(0))
    {
        *collapsed = !*collapsed;
        changed = true;
    }
    float shadowOff = anim->shadowSpread.Get();
    ImColor shadowCol(0, 0, 0, (int)(35 * (shadowOff / 6.0f)));
    dl->AddRectFilled(ImVec2(pos.x + shadowOff, pos.y + shadowOff), ImVec2(pos.x + fullW + shadowOff, pos.y + headerH + shadowOff), C(shadowCol), 8.0f);
    ImColor shadowCol2(0, 0, 0, (int)(20 * (shadowOff / 6.0f)));
    dl->AddRectFilled(ImVec2(pos.x + shadowOff * 0.5f, pos.y + shadowOff * 0.5f), ImVec2(pos.x + fullW + shadowOff * 0.5f, pos.y + headerH + shadowOff * 0.5f), C(shadowCol2), 8.0f);
    ImColor bgCol(25, 25, 42, 235);
    dl->AddRectFilled(pos, ImVec2(pos.x + fullW, pos.y + headerH), C(bgCol), 8.0f);
    ImColor borderCol = accent;
    borderCol.Value.w *= 0.3f + 0.2f * anim->hoverGlow.Get();
    dl->AddRect(pos, ImVec2(pos.x + fullW, pos.y + headerH), C(borderCol), 8.0f, ImDrawFlags_RoundCornersAll, 1.0f);
    ImColor innerGlow = accent;
    innerGlow.Value.w *= 0.05f * anim->hoverGlow.Get();
    if (anim->hoverGlow.Get() > 0.01f)
    {
        dl->AddRectFilled(ImVec2(pos.x + 2.0f, pos.y + 2.0f), ImVec2(pos.x + fullW - 2.0f, pos.y + headerH - 2.0f), C(innerGlow), 6.0f);
    }
    float titleX = pos.x + 14.0f;
    float titleY = pos.y + (headerH - ImGui::GetTextLineHeight()) * 0.5f;
    ImColor titleCol(220, 220, 240, 255);
    ImGui::RenderText(ImVec2(titleX, titleY), id, nullptr, false);
    float arrowX = pos.x + fullW - 22.0f;
    float arrowY = pos.y + headerH * 0.5f;
    float angle = anim->arrowAngle.Get() * IM_PI * 0.5f;
    float arrowSize = 5.5f;
    float cosA = cosf(angle);
    float sinA = sinf(angle);
    ImVec2 a0(arrowX - arrowSize * cosA + arrowSize * sinA, arrowY - arrowSize * sinA - arrowSize * cosA);
    ImVec2 a1(arrowX + arrowSize * cosA + arrowSize * sinA, arrowY + arrowSize * sinA - arrowSize * cosA);
    ImVec2 a2(arrowX - arrowSize * sinA, arrowY + arrowSize * cosA);
    ImColor arrowCol(160, 160, 200, 255);
    ImColor arrowGlow = accent;
    arrowGlow.Value.w *= 0.2f * anim->arrowAngle.Get();
    dl->AddTriangleFilled(a0, a1, a2, C(arrowCol));
    dl->AddTriangle(a0, a1, a2, C(arrowGlow), 1.0f);
    if (*collapsed)
    {
        anim->lastCollapsed = true;
        return changed;
    }
    anim->lastCollapsed = false;
    float contentY = pos.y + headerH + 6.0f;
    ImGui::SetCursorScreenPos(ImVec2(pos.x + 10.0f, contentY));
    ImVec2 contentMin(pos.x + 10.0f, contentY);
    ImVec2 contentMax(pos.x + fullW - 10.0f, contentY + 2000.0f);
    ImGui::PushClipRect(contentMin, contentMax, true);
    return changed;
}

void M_CardEnd()
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    if (ImGui::GetCurrentWindow()->ClipRectStack.Size > 0)
        ImGui::PopClipRect();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float fullW = ImGui::GetContentRegionAvail().x;
    if (fullW < 10.0f) fullW = 10.0f;
    float endPad = 10.0f;
    ImVec2 itemMin = ImGui::GetItemRectMin();
    ImVec2 itemMax = ImGui::GetItemRectMax();
    float contentH = itemMax.y - itemMin.y;
    if (contentH > 0.0f && itemMin.x > -1000.0f)
    {
        ImVec2 cardMin(itemMin.x - 10.0f, itemMin.y - 6.0f);
        ImVec2 cardMax(itemMax.x + 10.0f, pos.y + endPad);
        ImColor borderCol(255, 255, 255, 15);
        dl->AddRect(cardMin, cardMax, C(borderCol), 8.0f, ImDrawFlags_RoundCornersBottom, 1.0f);
    }
    ImGui::Dummy(ImVec2(0, endPad));
}

bool M_CardContainer(const char* title, bool* collapsed, ImColor accent, const char* badge)
{
    bool changed = M_CardBegin(title, collapsed, accent);
    if (!*collapsed)
    {
        ImDrawList* dl = ImGui::GetWindowDrawList();
        ImVec2 pos = ImGui::GetCursorScreenPos();
        if (badge)
        {
            ImVec2 textSize = ImGui::CalcTextSize(badge);
            float badgeW = textSize.x + 14.0f;
            float badgeH = 18.0f;
            ImVec2 bp(pos.x + 8.0f, pos.y + 2.0f);
            ImColor shadowBadge(0, 0, 0, 60);
            dl->AddRectFilled(ImVec2(bp.x + 1.0f, bp.y + 1.0f), ImVec2(bp.x + badgeW + 1.0f, bp.y + badgeH + 1.0f), C(shadowBadge), 9.0f);
            ImColor badgeCol(255, 50, 50, 230);
            dl->AddRectFilled(bp, ImVec2(bp.x + badgeW, bp.y + badgeH), C(badgeCol), 9.0f);
            ImColor badgeBorder(255, 255, 255, 40);
            dl->AddRect(bp, ImVec2(bp.x + badgeW, bp.y + badgeH), C(badgeBorder), 9.0f, ImDrawFlags_RoundCornersAll, 1.0f);
            ImColor badgeTextCol(255, 255, 255, 255);
            dl->AddText(ImVec2(bp.x + (badgeW - textSize.x) * 0.5f, bp.y + (badgeH - textSize.y) * 0.5f), C(badgeTextCol), badge);
        }
        ImGui::Dummy(ImVec2(0, 4.0f));
    }
    M_CardEnd();
    return changed;
}

struct ExpandAnimData
{
    ImGuiID id;
    AnimFloat expand;
    AnimFloat hoverGlow;
    bool lastExpanded;
    float contentHeight;
};

static ImVector<ExpandAnimData> s_ExpandAnims;

static ExpandAnimData* FindOrCreateExpandAnim(ImGuiID id)
{
    for (int i = 0; i < s_ExpandAnims.Size; i++)
    {
        if (s_ExpandAnims[i].id == id) return &s_ExpandAnims[i];
    }
    ExpandAnimData d;
    d.id = id;
    d.expand = AnimFloat(0.0f, 9.0f);
    d.hoverGlow = AnimFloat(0.0f, 7.0f);
    d.lastExpanded = false;
    d.contentHeight = 0.0f;
    s_ExpandAnims.push_back(d);
    return &s_ExpandAnims[s_ExpandAnims.Size - 1];
}

bool M_ExpandableSection(const char* title, bool* expanded, ImColor accent)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImGuiWindow* win = ImGui::GetCurrentWindow();
    if (win->SkipItems) return false;
    ImGuiID uid = win->GetID(title);
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float fullW = ImGui::GetContentRegionAvail().x;
    float headerH = 32.0f;
    ImRect bb(pos, ImVec2(pos.x + fullW, pos.y + headerH));
    ImGui::ItemSize(ImVec2(fullW, headerH));
    if (!ImGui::ItemAdd(bb, uid)) return false;
    ExpandAnimData* anim = FindOrCreateExpandAnim(uid);
    float dt = ImGui::GetIO().DeltaTime;
    anim->expand.SetTarget(*expanded ? 1.0f : 0.0f);
    anim->expand.Update(dt);
    bool hovered = ImGui::IsMouseHoveringRect(bb.Min, bb.Max);
    anim->hoverGlow.SetTarget(hovered ? 1.0f : 0.0f);
    anim->hoverGlow.Update(dt);
    bool changed = false;
    if (hovered && ImGui::IsMouseClicked(0))
    {
        *expanded = !*expanded;
        changed = true;
    }
    float borderX = pos.x;
    float borderW = 3.0f;
    dl->AddRectFilled(ImVec2(borderX, pos.y), ImVec2(borderX + borderW, pos.y + headerH), C(accent));
    ImColor borderGlow = accent;
    borderGlow.Value.w *= 0.2f;
    dl->AddRectFilled(ImVec2(borderX - 1.0f, pos.y - 1.0f), ImVec2(borderX + borderW + 1.0f, pos.y + headerH + 1.0f), C(borderGlow), 2.0f);
    ImColor bgCol(18, 18, 32, 220);
    dl->AddRectFilled(bb.Min, bb.Max, C(bgCol));
    ImColor bgHover = accent;
    bgHover.Value.w *= 0.08f * anim->hoverGlow.Get();
    if (anim->hoverGlow.Get() > 0.01f)
    {
        dl->AddRectFilled(bb.Min, bb.Max, C(bgHover));
    }
    ImColor bottomLine = accent;
    bottomLine.Value.w *= 0.15f;
    dl->AddLine(ImVec2(pos.x, pos.y + headerH), ImVec2(pos.x + fullW, pos.y + headerH), C(bottomLine), 1.0f);
    float titleX = pos.x + 16.0f;
    float titleY = pos.y + (headerH - ImGui::GetTextLineHeight()) * 0.5f;
    ImColor titleCol(200, 200, 225, 255);
    dl->AddText(ImVec2(titleX, titleY), C(titleCol), title);
    float arrowX = pos.x + fullW - 18.0f;
    float arrowY = pos.y + headerH * 0.5f;
    float t = anim->expand.Get();
    float angle = t * IM_PI * 0.5f;
    float arrowSize = 4.5f;
    float cosA = cosf(angle);
    float sinA = sinf(angle);
    ImVec2 a0(arrowX - arrowSize * cosA + arrowSize * sinA, arrowY - arrowSize * sinA - arrowSize * cosA);
    ImVec2 a1(arrowX + arrowSize * cosA + arrowSize * sinA, arrowY + arrowSize * sinA - arrowSize * cosA);
    ImVec2 a2(arrowX - arrowSize * sinA, arrowY + arrowSize * cosA);
    ImColor arrowCol(160, 160, 195, 255);
    dl->AddTriangleFilled(a0, a1, a2, C(arrowCol));
    if (t > 0.01f)
    {
        float animH = anim->contentHeight * t;
        float contentX = pos.x + 12.0f;
        float contentY = pos.y + headerH + 4.0f;
        ImVec2 clipMin(contentX, contentY);
        ImVec2 clipMax(pos.x + fullW - 12.0f, contentY + animH + 4.0f);
        ImGui::SetCursorScreenPos(ImVec2(contentX, contentY));
        ImGui::PushClipRect(clipMin, clipMax, true);
        if (*expanded)
        {
            ImGui::Dummy(ImVec2(0, animH));
        }
        ImGui::PopClipRect();
    }
    anim->lastExpanded = *expanded;
    return changed;
}

void M_SectionDivider(const char* label, ImColor accent)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float fullW = ImGui::GetContentRegionAvail().x;
    float lineY = pos.y + 8.0f;
    float lineH = 1.0f;
    float margin = 8.0f;
    float leftEdge = pos.x + margin;
    float rightEdge = pos.x + fullW - margin;
    ImColor clearCol = accent;
    clearCol.Value.w = 0.0f;
    ImColor solidCol = accent;
    solidCol.Value.w *= 0.5f;
    dl->AddRectFilledMultiColor(
        ImVec2(leftEdge, lineY), ImVec2(rightEdge, lineY + lineH),
        C(clearCol), C(solidCol), C(solidCol), C(clearCol)
    );
    ImColor solidCol2 = accent;
    solidCol2.Value.w *= 0.25f;
    dl->AddRectFilledMultiColor(
        ImVec2(leftEdge, lineY - 2.0f), ImVec2(rightEdge, lineY + lineH + 2.0f),
        C(clearCol), C(solidCol2), C(solidCol2), C(clearCol)
    );
    float diamondSize = 4.0f;
    float centerY = lineY + lineH * 0.5f;
    for (int i = 1; i <= 3; i += 2)
    {
        float frac = i * 0.25f;
        float dx = ImLerp(leftEdge, rightEdge, frac);
        ImVec2 d0(dx, centerY - diamondSize);
        ImVec2 d1(dx + diamondSize, centerY);
        ImVec2 d2(dx, centerY + diamondSize);
        ImVec2 d3(dx - diamondSize, centerY);
        ImColor diamondCol = accent;
        diamondCol.Value.w *= 0.6f;
        dl->AddQuadFilled(d0, d1, d2, d3, C(diamondCol));
        ImColor diamondBorder = accent;
        diamondBorder.Value.w *= 0.8f;
        dl->AddQuad(d0, d1, d2, d3, C(diamondBorder), 1.0f);
        ImColor diamondGlow = accent;
        diamondGlow.Value.w *= 0.2f;
        dl->AddCircleFilled(ImVec2(dx, centerY), diamondSize * 1.5f, C(diamondGlow), 12);
    }
    if (label)
    {
        ImVec2 textSize = ImGui::CalcTextSize(label);
        float pillPadX = 16.0f;
        float pillPadY = 5.0f;
        float pillW = textSize.x + pillPadX * 2.0f;
        float pillH = textSize.y + pillPadY * 2.0f;
        float pillX = pos.x + (fullW - pillW) * 0.5f;
        float pillY = lineY - pillH * 0.5f;
        ImColor bgCol(20, 20, 35, 240);
        dl->AddRectFilled(ImVec2(pillX, pillY), ImVec2(pillX + pillW, pillY + pillH), C(bgCol), pillH * 0.5f);
        ImColor pillShadow(0, 0, 0, 50);
        dl->AddRectFilled(ImVec2(pillX + 1.0f, pillY + 1.0f), ImVec2(pillX + pillW + 1.0f, pillY + pillH + 1.0f), C(pillShadow), pillH * 0.5f);
        ImColor pillBorder = accent;
        pillBorder.Value.w *= 0.35f;
        dl->AddRect(ImVec2(pillX, pillY), ImVec2(pillX + pillW, pillY + pillH), C(pillBorder), pillH * 0.5f, ImDrawFlags_RoundCornersAll, 1.0f);
        ImColor labelCol = accent;
        labelCol.Value.x = ImClamp(labelCol.Value.x * 1.2f, 0.0f, 1.0f);
        labelCol.Value.y = ImClamp(labelCol.Value.y * 1.2f, 0.0f, 1.0f);
        labelCol.Value.z = ImClamp(labelCol.Value.z * 1.2f, 0.0f, 1.0f);
        dl->AddText(ImVec2(pillX + pillPadX, pillY + pillPadY), C(labelCol), label);
    }
    ImGui::Dummy(ImVec2(0, 22.0f));
}

void M_InfoRow(const char* label, const char* value, ImColor valueColor, const char* icon)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float fullW = ImGui::GetContentRegionAvail().x;
    float rowH = 30.0f;
    float iconSize = 20.0f;
    float cursorX = pos.x + 4.0f;
    if (icon)
    {
        float cx = cursorX + iconSize * 0.5f;
        float cy = pos.y + rowH * 0.5f;
        ImColor circleFill = valueColor;
        circleFill.Value.w *= 0.2f;
        dl->AddCircleFilled(ImVec2(cx, cy), iconSize * 0.5f + 1.0f, C(circleFill), 24);
        ImColor circleBorder = valueColor;
        circleBorder.Value.w *= 0.3f;
        dl->AddCircle(ImVec2(cx, cy), iconSize * 0.5f + 1.0f, C(circleBorder), 24, 1.0f);
        ImColor iconCol = valueColor;
        iconCol.Value.w = 1.0f;
        float iconTextW = ImGui::CalcTextSize(icon).x;
        dl->AddText(ImVec2(cx - iconTextW * 0.5f, cy - ImGui::GetTextLineHeight() * 0.5f), C(iconCol), icon);
        cursorX += iconSize + 14.0f;
    }
    ImColor labelCol(140, 140, 170, 240);
    float labelW = ImGui::CalcTextSize(label).x;
    dl->AddText(ImVec2(cursorX, pos.y + (rowH - ImGui::GetTextLineHeight()) * 0.5f), C(labelCol), label);
    ImColor labelUnder = labelCol;
    labelUnder.Value.w *= 0.1f;
    dl->AddLine(ImVec2(cursorX, pos.y + rowH - 2.0f), ImVec2(cursorX + labelW, pos.y + rowH - 2.0f), C(labelUnder), 1.0f);
    float valueW = ImGui::CalcTextSize(value).x;
    float valueX = pos.x + fullW - valueW - 8.0f;
    float valueY = pos.y + (rowH - ImGui::GetTextLineHeight()) * 0.5f;
    ImColor valueBg = valueColor;
    valueBg.Value.w *= 0.08f;
    dl->AddRectFilled(ImVec2(valueX - 6.0f, valueY - 2.0f), ImVec2(valueX + valueW + 6.0f, valueY + ImGui::GetTextLineHeight() + 2.0f), C(valueBg), 3.0f);
    dl->AddText(ImVec2(valueX, valueY), C(valueColor), value);
    ImColor separatorCol(255, 255, 255, 10);
    dl->AddLine(ImVec2(pos.x, pos.y + rowH), ImVec2(pos.x + fullW, pos.y + rowH), C(separatorCol), 1.0f);
    ImGui::Dummy(ImVec2(0, rowH));
}

void M_StatCard(const char* label, const char* value, const char* trend, bool trendUp, ImColor accent)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 pos = ImGui::GetCursorScreenPos();
    float cardW = 120.0f;
    float cardH = 72.0f;
    float startX = pos.x;
    ImRect cardBb(startX, pos.y, startX + cardW, pos.y + cardH);
    ImGui::ItemSize(ImVec2(cardW, cardH));
    bool hovered = ImGui::IsMouseHoveringRect(cardBb.Min, cardBb.Max);
    ImColor shadowCol(0, 0, 0, 55);
    dl->AddRectFilled(ImVec2(startX + 2.0f, pos.y + 3.0f), ImVec2(startX + cardW + 2.0f, pos.y + cardH + 3.0f), C(shadowCol), 6.0f);
    ImColor shadowCol2(0, 0, 0, 30);
    dl->AddRectFilled(ImVec2(startX + 4.0f, pos.y + 5.0f), ImVec2(startX + cardW + 4.0f, pos.y + cardH + 5.0f), C(shadowCol2), 6.0f);
    ImColor bgCol(22, 22, 38, 245);
    dl->AddRectFilled(cardBb.Min, cardBb.Max, C(bgCol), 6.0f);
    ImColor innerHighlight(255, 255, 255, 8);
    dl->AddRectFilled(ImVec2(startX + 2.0f, pos.y + 2.0f), ImVec2(startX + cardW - 2.0f, pos.y + 4.0f), C(innerHighlight), 2.0f);
    ImColor borderCol = accent;
    borderCol.Value.w *= 0.25f;
    dl->AddRect(cardBb.Min, cardBb.Max, C(borderCol), 6.0f, ImDrawFlags_RoundCornersAll, 1.0f);
    if (hovered)
    {
        ImColor glowCol = accent;
        glowCol.Value.w *= 0.2f;
        for (int g = 0; g < 3; g++)
        {
            float expand = g * 2.0f;
            ImU32 gCol = C(ImColor(glowCol.Value.x, glowCol.Value.y, glowCol.Value.z, glowCol.Value.w * (1.0f - g * 0.3f)));
            dl->AddRectFilled(ImVec2(startX - 1.0f - expand, pos.y - 1.0f - expand), ImVec2(startX + cardW + 1.0f + expand, pos.y + cardH + 1.0f + expand), gCol, 7.0f + expand);
        }
        ImColor glowBorder = accent;
        glowBorder.Value.w *= 0.45f;
        dl->AddRect(ImVec2(startX - 1.0f, pos.y - 1.0f), ImVec2(startX + cardW + 1.0f, pos.y + cardH + 1.0f), C(glowBorder), 7.0f, ImDrawFlags_RoundCornersAll, 1.5f);
    }
    ImColor labelCol(140, 140, 170, 200);
    float lx = startX + 8.0f;
    float ly = pos.y + 6.0f;
    dl->AddText(ImVec2(lx, ly), C(labelCol), label);
    ImColor valCol(255, 255, 255, 255);
    ImVec2 valSize = ImGui::CalcTextSize(value);
    float vx = startX + (cardW - valSize.x) * 0.5f;
    float vy = pos.y + (cardH - valSize.y) * 0.5f + 2.0f;
    dl->AddText(ImVec2(vx, vy), C(valCol), value);
    if (trend)
    {
        ImColor trendCol = trendUp ? ImColor(60, 220, 100, 230) : ImColor(255, 60, 60, 230);
        const char* arrow = trendUp ? "\xe2\x86\x91" : "\xe2\x86\x93";
        char trendBuf[32];
        ImFormatString(trendBuf, sizeof(trendBuf), "%s %s", arrow, trend);
        ImVec2 trendSize = ImGui::CalcTextSize(trendBuf);
        float tx = startX + cardW - trendSize.x - 8.0f;
        float ty = pos.y + cardH - trendSize.y - 6.0f;
        ImColor trendBg = trendCol;
        trendBg.Value.w *= 0.1f;
        dl->AddRectFilled(ImVec2(tx - 3.0f, ty - 1.0f), ImVec2(tx + trendSize.x + 3.0f, ty + trendSize.y + 1.0f), C(trendBg), 2.0f);
        dl->AddText(ImVec2(tx, ty), C(trendCol), trendBuf);
    }
    ImGui::Dummy(ImVec2(0, cardH));
}

struct TooltipAnimData
{
    static AnimFloat alpha;
    static bool show;
};
AnimFloat TooltipAnimData::alpha = AnimFloat(0.0f, 6.0f);
bool TooltipAnimData::show = false;

void M_GlassTooltip(const char* text, ImVec2 position, ImColor accent)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    float dt = ImGui::GetIO().DeltaTime;
    TooltipAnimData::alpha.SetTarget(TooltipAnimData::show ? 1.0f : 0.0f);
    TooltipAnimData::alpha.Update(dt);
    float alpha = TooltipAnimData::alpha.Get();
    if (alpha < 0.005f) return;
    ImVec2 textSize = ImGui::CalcTextSize(text);
    float padX = 18.0f;
    float padY = 12.0f;
    float tipW = textSize.x + padX * 2.0f;
    float tipH = textSize.y + padY * 2.0f;
    float arrowH = 10.0f;
    float arrowW = 10.0f;
    float radius = 8.0f;
    ImVec2 tipMin(position.x, position.y);
    ImVec2 tipMax(position.x + tipW, position.y + tipH + arrowH);
    ImColor bg0(12, 12, 28, (int)(220 * alpha));
    ImColor bg1(18, 18, 35, (int)(200 * alpha));
    ImColor bg2(24, 24, 45, (int)(180 * alpha));
    ImColor bg3(30, 30, 55, (int)(160 * alpha));
    ImColor bg4(36, 36, 65, (int)(140 * alpha));
    for (int layer = 0; layer < 5; layer++)
    {
        float off = layer * 1.2f;
        ImVec2 lMin(tipMin.x - off, tipMin.y - off);
        ImVec2 lMax(tipMax.x + off, tipMax.y + off);
        ImColor col;
        switch (layer)
        {
            case 0: col = bg0; break;
            case 1: col = bg1; break;
            case 2: col = bg2; break;
            case 3: col = bg3; break;
            default: col = bg4; break;
        }
        col.Value.w *= alpha;
        dl->AddRectFilled(lMin, lMax, C(col), radius + off * 0.3f);
    }
    ImColor borderCol = accent;
    borderCol.Value.w *= 0.5f * alpha;
    dl->AddRect(tipMin, ImVec2(tipMax.x, position.y + tipH), C(borderCol), radius, ImDrawFlags_RoundCornersAll, 1.5f);
    ImColor borderGlow = accent;
    borderGlow.Value.w *= 0.15f * alpha;
    dl->AddRect(ImVec2(tipMin.x - 1.0f, tipMin.y - 1.0f), ImVec2(tipMax.x + 1.0f, position.y + tipH + 1.0f), C(borderGlow), radius + 1.0f, ImDrawFlags_RoundCornersAll, 2.0f);
    float arrowX = position.x + tipW * 0.5f;
    float arrowY = position.y + tipH - 1.0f;
    ImVec2 ap0(arrowX, arrowY + arrowH);
    ImVec2 ap1(arrowX - arrowW, arrowY);
    ImVec2 ap2(arrowX + arrowW, arrowY);
    ImColor arrowFill = bg0;
    arrowFill.Value.w *= alpha;
    dl->AddTriangleFilled(ap0, ap1, ap2, C(arrowFill));
    ImColor arrowBorder = borderCol;
    dl->AddTriangle(ap1, ap2, ap0, C(arrowBorder), 1.5f);
    float shineX = position.x + padX + 4.0f;
    float shineY = position.y + padY + 2.0f;
    float shineW = tipW - padX * 2.0f - 8.0f;
    float shineH = 1.0f;
    ImColor shineCol(255, 255, 255, (int)(30 * alpha));
    dl->AddRectFilled(ImVec2(shineX, shineY), ImVec2(shineX + shineW, shineY + shineH), C(shineCol));
    ImColor textCol(225, 225, 245, (int)(255 * alpha));
    dl->AddText(ImVec2(position.x + padX, position.y + padY), C(textCol), text);
}

void M_Badge(const char* text, ImColor color, ImVec2 position)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 pos = position;
    if (pos.x == 0.0f && pos.y == 0.0f)
    {
        pos = ImGui::GetCursorScreenPos();
    }
    ImVec2 textSize = ImGui::CalcTextSize(text);
    float badgeH = 16.0f;
    float padX = 8.0f;
    float badgeW = textSize.x + padX * 2.0f;
    if (badgeW < badgeH) badgeW = badgeH;
    float radius = badgeH * 0.5f;
    float cy = pos.y + radius;
    float cx = pos.x + badgeW * 0.5f;
    ImColor shadowCol(0, 0, 0, 90);
    dl->AddCircleFilled(ImVec2(cx + 1.0f, cy + 1.0f), radius, C(shadowCol), 24);
    ImColor bgCol = color;
    dl->AddCircleFilled(ImVec2(cx, cy), radius, C(bgCol), 24);
    ImColor innerGlow(255, 255, 255, 30);
    dl->AddCircleFilled(ImVec2(cx, cy), radius * 0.6f, C(innerGlow), 24);
    ImColor borderCol(255, 255, 255, 50);
    dl->AddCircle(ImVec2(cx, cy), radius, C(borderCol), 24, 1.0f);
    ImColor textCol(255, 255, 255, 255);
    dl->AddText(ImVec2(cx - textSize.x * 0.5f, cy - textSize.y * 0.5f), C(textCol), text);
    ImColor pulseCol = color;
    pulseCol.Value.w *= 0.15f;
    dl->AddCircleFilled(ImVec2(cx, cy), radius * 1.8f, C(pulseCol), 24);
    ImColor dotCol = color;
    dotCol.Value.w *= 0.8f;
    dl->AddCircleFilled(ImVec2(cx + radius * 0.6f, cy - radius * 0.4f), 2.0f, C(dotCol), 8);
    ImGui::Dummy(ImVec2(0, badgeH));
}
