#include "ESP.h"
#include <cmath>
#include <cstdio>
#include <cstring>

extern GameOffsets g_Offsets;
extern Config g_Cfg;
extern Toggles g_Tog;
extern Aimbot g_Bot;
extern MiscFeatures g_Misc;

static uint32_t ToggleChecksum(Toggles *tog) {
    if (!tog) return 0;
    uint32_t h = 0;
    const uint32_t *p = reinterpret_cast<const uint32_t*>(tog);
    for (size_t i = 0; i < sizeof(Toggles) / sizeof(uint32_t); i++)
        h ^= p[i] + 0x9e3779b9 + (h << 6) + (h >> 2);
    return h;
}

ESP::ESP(MemoryIO *mem, GameOffsets *offsets, Config *cfg, Toggles *tog, Aimbot *bot) {
    Mem = mem;
    Offsets = offsets;
    Cfg = cfg;
    Tog = tog;
    Bot = bot;
    PlayerCount = 0;
    lastToggleHash = 0;
    Players.reserve(5000);
    Players.resize(5000);
}

bool ESP::WorldToScreen(D3DVector world, float *screenX, float *screenY) {
    if (!screenX || !screenY) return false;
    return ::WorldToScreen(world, screenX, screenY, g_Offsets.ViewMatrix, (float)abs_ScreenX, (float)abs_ScreenY);
}

ImColor ESP::GetPlayerColor(const PlayerData &p) {
    if (p.TeamID != 0) return g_Cfg.ESPTeamColor;
    return g_Cfg.ESPBoxColor;
}

void ESP::UpdatePlayers() {
    if (!g_Offsets.Initialized) return;
    std::lock_guard<std::mutex> lock(playersMutex);
    PlayerCount = 0;
    g_Offsets.UpdateEntityList();
    int count = g_Offsets.EntityCount;
    if (count > 256) count = 256;
    for (int i = 0; i < count; i++) {
        if (PlayerCount >= 256) break;
        PlayerData *p = &Players[PlayerCount];
        if (!g_Offsets.ReadEntityData(i, p)) continue;
        p->Distance = Vec3Distance(g_Offsets.CameraPos, p->Position);
        if (!p->IsAlive) continue;
        PlayerCount++;
    }
}

void ESP::DrawHealthBar(ImDrawList *draw, float x, float y, float w, float h, float health, float maxHealth) {
    if (maxHealth <= 0) return;
    float ratio = fmaxf(0, fminf(health / maxHealth, 1));
    ImColor hpColor;
    if (ratio > 0.75f) hpColor = ImColor(0, 255, 0);
    else if (ratio > 0.3f) hpColor = ImColor(255, 255, 0);
    else hpColor = ImColor(255, 0, 0);
    float barH = h * ratio;
    draw->AddRectFilled(ImVec2(x, y + h - barH), ImVec2(x + w, y + h), hpColor);
    draw->AddRect(ImVec2(x, y), ImVec2(x + w, y + h), ImColor(0, 0, 0, 150), 0, 0, 1);
}

void ESP::DrawPlayerBox(ImDrawList *draw, PlayerData &p, float sx, float sy) {
    if (!g_Tog.PlayerESP) return;
    float headSX, headSY;
    if (!WorldToScreen(p.Head, &headSX, &headSY)) return;
    float height = sy - headSY;
    if (height < 5) height = 30;
    float width = height * 0.5f;
    float boxX = sx - width / 2;
    float boxY = headSY;
    if (boxY > sy) return;

    ImColor boxColor = GetPlayerColor(p);
    if (!p.IsVisible && g_Tog.Wallhack) {
        boxColor = g_Cfg.ESPWallColor;
        boxColor.Value.w = 0.65f;
    }
    if (!p.IsVisible && g_Tog.FilterVisible) boxColor = g_Cfg.ESPWallColor;
    if (p.TeamID != 0) boxColor = g_Cfg.ESPTeamColor;

    float thickness = fmaxf(1.0f, g_Cfg.BoxWidth);

    if (g_Tog.Box)
        draw->AddRect(ImVec2(boxX, boxY), ImVec2(boxX + width, boxY + height), boxColor, 0, 0, thickness);

    if (g_Tog.CornerBox) {
        float l = width / 3;
        draw->AddLine(ImVec2(boxX, boxY), ImVec2(boxX + l, boxY), boxColor, thickness);
        draw->AddLine(ImVec2(boxX, boxY), ImVec2(boxX, boxY + l), boxColor, thickness);
        draw->AddLine(ImVec2(boxX + width, boxY), ImVec2(boxX + width - l, boxY), boxColor, thickness);
        draw->AddLine(ImVec2(boxX + width, boxY), ImVec2(boxX + width, boxY + l), boxColor, thickness);
        draw->AddLine(ImVec2(boxX, boxY + height), ImVec2(boxX + l, boxY + height), boxColor, thickness);
        draw->AddLine(ImVec2(boxX, boxY + height), ImVec2(boxX, boxY + height - l), boxColor, thickness);
        draw->AddLine(ImVec2(boxX + width, boxY + height), ImVec2(boxX + width - l, boxY + height), boxColor, thickness);
        draw->AddLine(ImVec2(boxX + width, boxY + height), ImVec2(boxX + width, boxY + height - l), boxColor, thickness);
    }

    if (g_Tog.HealthBar) {
        float hx = boxX - g_Cfg.HealthBarWidth - 2;
        DrawHealthBar(draw, hx, boxY, g_Cfg.HealthBarWidth, height, p.Health, p.MaxHealth);
    }

    if (g_Tog.Name && p.PlayerName[0]) {
        const char *name = p.PlayerName;
        char buf[64];
        if (!name[0]) {
            snprintf(buf, sizeof(buf), "Player #%d", p.PlayerID);
            name = buf;
        }
        ImVec2 tSize = ImGui::CalcTextSize(name);
        float tx = boxX + width / 2 - tSize.x / 2;
        float ty = boxY - tSize.y - 2;
        if (ty > 0 && tx > 0) draw->AddText(ImVec2(tx, ty), g_Cfg.ESPNameColor, name);
    }

    if (g_Tog.Distance) {
        char dist[32];
        snprintf(dist, sizeof(dist), "%.0fm", p.Distance);
        ImVec2 tSize = ImGui::CalcTextSize(dist);
        float dx = boxX + width / 2 - tSize.x / 2;
        float dy = boxY + height + 2;
        if (dy > 0 && dy < abs_ScreenY) draw->AddText(ImVec2(dx, dy), g_Cfg.ESPDistanceColor, dist);
    }

    if (g_Tog.Weapon && p.WeaponName[0]) {
        const char *wpn = p.WeaponName;
        if (!wpn[0]) wpn = "Unknown";
        draw->AddText(ImVec2(boxX + width + 4, boxY), ImColor(200, 200, 200), wpn);
    }

    draw->AddCircleFilled(ImVec2(sx, headSY), 3, boxColor, 12);
}

void ESP::DrawSkeleton(ImDrawList *draw, uintptr_t boneAddr) {
    if (!boneAddr) return;
    ImColor boneColor = ImColor(255, 255, 255, 180);
    for (int i = 0; i < g_SkeletonJointCount; i++) {
        int p = g_SkeletonJoints[i].Parent;
        int c = g_SkeletonJoints[i].Child;
        D3DVector p1 = g_Offsets.GetBonePosition(boneAddr, p);
        D3DVector p2 = g_Offsets.GetBonePosition(boneAddr, c);
        float sx1, sy1, sx2, sy2;
        if (!WorldToScreen(p1, &sx1, &sy1)) continue;
        if (!WorldToScreen(p2, &sx2, &sy2)) continue;
        draw->AddLine(ImVec2(sx1, sy1), ImVec2(sx2, sy2), boneColor, 1.5f);
    }
}

void ESP::DrawCrosshair(ImDrawList *draw) {
    if (!g_Tog.ShowCrosshair) return;
    float cx = abs_ScreenX / 2.0f;
    float cy = abs_ScreenY / 2.0f;
    float size = g_Cfg.CrosshairSize;
    float thick = g_Cfg.CrosshairThickness;
    ImColor col = g_Cfg.CrosshairColor;
    draw->AddLine(ImVec2(cx - size, cy), ImVec2(cx - size / 3, cy), col, thick);
    draw->AddLine(ImVec2(cx + size / 3, cy), ImVec2(cx + size, cy), col, thick);
    draw->AddLine(ImVec2(cx, cy - size), ImVec2(cx, cy - size / 3), col, thick);
    draw->AddLine(ImVec2(cx, cy + size / 3), ImVec2(cx, cy + size), col, thick);
    draw->AddCircleFilled(ImVec2(cx, cy), 2, ImColor(255, 0, 0), 8);
}

void ESP::DrawWatermark(ImDrawList *draw) {
    if (!g_Tog.ShowWatermark) return;
    char buf[128];
    time_t now = time(NULL);
    struct tm tm_buf;
    localtime_r(&now, &tm_buf);
    snprintf(buf, sizeof(buf), "Bugor Engine v2.0 | %s | %02d:%02d:%02d | FPS: %.0f",
             g_Offsets.GamesTable[g_Offsets.CurrentGameID].GameName,
             tm_buf.tm_hour, tm_buf.tm_min, tm_buf.tm_sec,
             ImGui::GetIO().Framerate);
    ImVec2 ts = ImGui::CalcTextSize(buf);
    float pad = 8;
    draw->AddRectFilled(ImVec2(10, 10), ImVec2(10 + ts.x + pad * 2, 10 + ts.y + pad * 2),
                        ImColor(0, 0, 0, 160), 4);
    draw->AddRect(ImVec2(10, 10), ImVec2(10 + ts.x + pad * 2, 10 + ts.y + pad * 2),
                  g_Cfg.WatermarkColor, 4, 0, 1.5f);
    draw->AddText(ImGui::GetFont(), 18, ImVec2(10 + pad, 10 + pad), g_Cfg.WatermarkColor, buf);
}

void ESP::DrawAimbotFOV(ImDrawList *draw) {
    if (!g_Tog.Aimbot || !g_Tog.AimbotDrawFOV) return;
    float cx = (float)abs_ScreenX / 2.0f;
    float cy = (float)abs_ScreenY / 2.0f;
    float r = g_Cfg.AimbotRange;
    draw->PathArcTo(ImVec2(cx, cy), r, 0, IM_PI * 2, 48);
    draw->PathStroke(g_Cfg.AimbotFOVColor, false, 1.5f);
    draw->PathArcTo(ImVec2(cx, cy), r, 0, IM_PI * 2, 48);
    draw->PathStroke(ImColor(255, 255, 255, 30), false, 0.5f);
}

void ESP::DrawAimbotTarget(ImDrawList *draw) {
    if (!g_Tog.AimbotDrawTarget || !g_Bot.IsLocked) return;
    float sx, sy;
    D3DVector pos = g_Bot.BestTarget.Position;
    pos.Y += 1.0f;
    if (!WorldToScreen(pos, &sx, &sy)) return;
    float radius = 25;
    draw->PathArcTo(ImVec2(sx, sy), radius, 0, IM_PI * 2, 16);
    draw->PathStroke(g_Cfg.AimbotTargetColor, false, 2.5f);
    draw->PathArcTo(ImVec2(sx, sy), radius - 5, 0, IM_PI * 2, 16);
    draw->PathStroke(ImColor(255, 255, 255, 60), false, 1.0f);
    draw->AddLine(ImVec2(sx - radius - 5, sy), ImVec2(sx + radius + 5, sy), g_Cfg.AimbotTargetColor, 1.5f);
    draw->AddLine(ImVec2(sx, sy - radius - 5), ImVec2(sx, sy + radius + 5), g_Cfg.AimbotTargetColor, 1.5f);
}

void ESP::DrawRadar(ImDrawList *draw) {
    if (!g_Tog.ShowRadar) return;
    float radarSize = 200.0f;
    float radarX = 20.0f;
    float radarY = (float)abs_ScreenY - radarSize - 20.0f;
    float cx = radarX + radarSize / 2.0f;
    float cy = radarY + radarSize / 2.0f;
    draw->AddRectFilled(ImVec2(radarX, radarY), ImVec2(radarX + radarSize, radarY + radarSize), ImColor(0, 0, 0, 160), 4);
    draw->AddRect(ImVec2(radarX, radarY), ImVec2(radarX + radarSize, radarY + radarSize), ImColor(255, 255, 255, 200), 4, 0, 2);
    draw->AddCircleFilled(ImVec2(cx, cy), 3, ImColor(0, 255, 0));
    draw->AddLine(ImVec2(cx, radarY), ImVec2(cx, radarY + radarSize), ImColor(255, 255, 255, 60), 1);
    draw->AddLine(ImVec2(radarX, cy), ImVec2(radarX + radarSize, cy), ImColor(255, 255, 255, 60), 1);
    float radarRange = g_Cfg.RadarRange;
    std::lock_guard<std::mutex> lock(playersMutex);
    for (int i = 0; i < PlayerCount; i++) {
        PlayerData *p = &Players[i];
        if (!p->IsAlive) continue;
        float dx = p->Position.X - g_Offsets.CameraPos.X;
        float dz = p->Position.Z - g_Offsets.CameraPos.Z;
        float dist = sqrtf(dx * dx + dz * dz);
        if (dist > radarRange || dist < 0.5f) continue;
        float relDist = (dist / radarRange) * (radarSize / 2.0f);
        float dotX = cx + (dx / dist) * relDist;
        float dotY = cy + (dz / dist) * relDist;
        if (dotX >= radarX + 2 && dotX <= radarX + radarSize - 2 &&
            dotY >= radarY + 2 && dotY <= radarY + radarSize - 2) {
            ImColor dotColor = GetPlayerColor(*p);
            draw->AddCircleFilled(ImVec2(dotX, dotY), 4, dotColor);
        }
    }
}

void ESP::Render(ImDrawList *draw) {
    if (!g_Offsets.Initialized || !draw) return;
    g_Offsets.UpdateViewMatrix();
    g_Offsets.UpdateCamera();
    if (g_Offsets.CameraPos.X == 0 && g_Offsets.CameraPos.Y == 0 && g_Offsets.CameraPos.Z == 0) return;
    g_Offsets.UpdateEntityList();

    uint32_t h = ToggleChecksum(&g_Tog);
    bool togglesChanged = (h != lastToggleHash);
    if (togglesChanged) {
        lastToggleHash = h;
        PlayerCount = 0;
        UpdatePlayers();
    }

    if (g_Tog.Aimbot) {
        g_Bot.Update();
    }

    g_Misc.Update();

    for (int i = 0; i < g_Offsets.EntityCount; i++) {
        PlayerData p;
        if (!g_Offsets.ReadEntityData(i, &p)) continue;
        p.Distance = Vec3Distance(g_Offsets.CameraPos, p.Position);
        if (p.Distance > g_Cfg.ESPMaxDistance) continue;
        float sx, sy;
        if (!WorldToScreen(p.Position, &sx, &sy)) continue;
        DrawPlayerBox(draw, p, sx, sy);
        if (g_Tog.Skeleton && p.BoneAddress) DrawSkeleton(draw, p.BoneAddress);
    }

    DrawCrosshair(draw);
    DrawAimbotFOV(draw);
    DrawAimbotTarget(draw);
    DrawRadar(draw);
    DrawWatermark(draw);
}
