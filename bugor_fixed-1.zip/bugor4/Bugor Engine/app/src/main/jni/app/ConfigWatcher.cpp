#include "ConfigWatcher.h"
#include "ConfigSerializer.h"
#include <sys/stat.h>
#include <unistd.h>

ConfigWatcher::ConfigWatcher() : running(false), stopFlag(false), lastModified(0) {}

ConfigWatcher::~ConfigWatcher() {
    stopFlag.store(true);
    cv.notify_all();
    running.store(false);
    if (watchThread.joinable()) {
        watchThread.join();
    }
}

void ConfigWatcher::Start(const std::string& path, Toggles* tog, Config* cfg) {
    std::lock_guard<std::mutex> lock(startMutex);
    if (running.load()) {
        stopFlag.store(true);
        cv.notify_all();
        if (watchThread.joinable()) {
            watchThread.join();
        }
        running.store(false);
    }
    lastConfigFile = path;
    struct stat st;
    if (stat(path.c_str(), &st) == 0) {
        lastModified = st.st_mtime;
    }
    stopFlag.store(false);
    running.store(true);
    Toggles* tog_copy = tog;
    Config* cfg_copy = cfg;
    watchThread = std::thread([this, tog_copy, cfg_copy]() {
        WatchLoop(tog_copy, cfg_copy);
    });
}

void ConfigWatcher::Stop() {
    stopFlag.store(true);
    cv.notify_all();
    running.store(false);
    if (watchThread.joinable()) {
        watchThread.join();
    }
}

void ConfigWatcher::WatchLoop(Toggles* tog, Config* cfg) {
    while (running.load() && !stopFlag.load()) {
        struct stat st;
        if (stat(lastConfigFile.c_str(), &st) == 0) {
            if (st.st_mtime != lastModified) {
                lastModified = st.st_mtime;
                if (ConfigSerializer::LoadBinary(lastConfigFile, tog, cfg)) {
                    if (OnChanged) OnChanged();
                }
            }
        }
        std::unique_lock<std::mutex> lock(startMutex);
        cv.wait_for(lock, std::chrono::milliseconds(1000),
                    [this] { return stopFlag.load() || !running.load(); });
    }
}
