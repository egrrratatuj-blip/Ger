#include "Config.h"
#include "MemoryIO.h"
#include "GameOffsets.h"
#include "ESP.h"
#include "Aimbot.h"
#include "SkinChanger.h"
#include "MiscFeatures.h"
#include "AntiDebug.h"
#include "imgui/Font.h"
#include "imgui/window_icon.h"
#include "imgui/safe_icon.h"
#include <mutex>
#include <atomic>

std::mutex g_ConfigMutex;
std::mutex g_EngineStateMutex;
std::atomic<bool> g_EngineInitialized{false};
std::atomic<bool> g_ShuttingDown{false};

MemoryIO g_Mem;
GameOffsets g_Offsets(&g_Mem);
Config g_Cfg;
Toggles g_Tog;
Aimbot g_Bot(&g_Mem, &g_Offsets, &g_Cfg, &g_Tog);
ESP g_Esp(&g_Mem, &g_Offsets, &g_Cfg, &g_Tog, &g_Bot);
SkinChanger g_Skin(&g_Mem, &g_Offsets, &g_Cfg, &g_Tog);
MiscFeatures g_Misc(&g_Mem, &g_Offsets, &g_Cfg, &g_Tog);

int _ScreenX = 0, _ScreenY = 0;
int abs_ScreenX = 0, abs_ScreenY = 0;
std::atomic<bool> g_Initialized{false};
ImGuiWindow *Window = nullptr;
ANativeWindow *window_sv = nullptr;
EGLDisplay g_EglDisplay = EGL_NO_DISPLAY;
EGLSurface g_EglSurface = EGL_NO_SURFACE;
EGLContext g_EglContext = EGL_NO_CONTEXT;

void initializeEGLContext() {
    const EGLint attribs[] = {
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT,
        EGL_BLUE_SIZE, 8,
        EGL_GREEN_SIZE, 8,
        EGL_RED_SIZE, 8,
        EGL_ALPHA_SIZE, 8,
        EGL_DEPTH_SIZE, 24,
        EGL_STENCIL_SIZE, 8,
        EGL_NONE
    };
    ANativeWindow_acquire(window_sv);
    g_EglDisplay = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (g_EglDisplay == EGL_NO_DISPLAY) return;
    eglInitialize(g_EglDisplay, 0, 0);
    EGLint numConfigs = 0;
    eglChooseConfig(g_EglDisplay, attribs, nullptr, 0, &numConfigs);
    if (numConfigs == 0) return;
    EGLConfig eglConfig;
    eglChooseConfig(g_EglDisplay, attribs, &eglConfig, 1, &numConfigs);
    EGLint eglFormat;
    eglGetConfigAttrib(g_EglDisplay, eglConfig, EGL_NATIVE_VISUAL_ID, &eglFormat);
    ANativeWindow_setBuffersGeometry(window_sv, 0, 0, eglFormat);
    EGLint ctxAttribs[] = { EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE };
    g_EglContext = eglCreateContext(g_EglDisplay, eglConfig, EGL_NO_CONTEXT, ctxAttribs);
    g_EglSurface = eglCreateWindowSurface(g_EglDisplay, eglConfig, window_sv, NULL);
    eglMakeCurrent(g_EglDisplay, g_EglSurface, g_EglSurface, g_EglContext);
}

void cleanupEngine() {
    if (g_EglDisplay != EGL_NO_DISPLAY) {
        eglMakeCurrent(g_EglDisplay, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (g_EglSurface != EGL_NO_SURFACE) {
            eglDestroySurface(g_EglDisplay, g_EglSurface);
            g_EglSurface = EGL_NO_SURFACE;
        }
        if (g_EglContext != EGL_NO_CONTEXT) {
            eglDestroyContext(g_EglDisplay, g_EglContext);
            g_EglContext = EGL_NO_CONTEXT;
        }
        eglTerminate(g_EglDisplay);
        g_EglDisplay = EGL_NO_DISPLAY;
    }
    if (window_sv) {
        ANativeWindow_release(window_sv);
        window_sv = nullptr;
    }
}

bool Android_LoadSystemFont() {
    char path[64] = {0};
    char *filename = nullptr;
    const char *fontPaths[] = { "/system/fonts", "/system/font", "/data/fonts" };
    for (auto tmp : fontPaths) {
        if (access(tmp, R_OK) == 0) {
            strcpy(path, tmp);
            filename = path + strlen(tmp);
            break;
        }
    }
    if (!filename) return false;
    *filename++ = '/';
    strcpy(filename, "NotoSansCJK-Regular.ttc");
    if (access(path, R_OK) != 0) {
        strcpy(filename, "NotoSerifCJK-Regular.ttc");
        if (access(path, R_OK) != 0) return false;
    }
    return true;
}
