#include "TabRadar.h"
#include "../ui_integration.h"
#include "../../../imgui/imgui.h"
#include "../../../imgui/imgui_internal.h"
#include "../widgets/Widgets_Switches.h"
#include "../widgets/Widgets_Buttons.h"
#include "../widgets/Widgets_Containers.h"
#include "../widgets/Widgets_Sliders.h"

static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }
extern GameOffsets g_Offsets;

static float ClampF(float v, float mn, float mx) { return v < mn ? mn : (v > mx ? mx : v); }

static float DotProduct(const D2DVector& a, const D2DVector& b) { return a.X * b.X + a.Y * b.Y; }

static D2DVector Rotate2D(D2DVector v, float angle)
{
    float s = sinf(angle);
    float c = cosf(angle);
    return D2DVector(v.X * c - v.Y * s, v.X * s + v.Y * c);
}

static float Vec2Len(D2DVector a, D2DVector b)
{
    float dx = a.X - b.X;
    float dy = a.Y - b.Y;
    return sqrtf(dx * dx + dy * dy);
}

void DrawRadarOverlay()
{
    if (!g_Tog.ShowRadar) return;

    ImDrawList* dl = ImGui::GetForegroundDrawList();
    ImVec2 screenSize = ImGui::GetIO().DisplaySize;

    float size = 120.0f;
    float margin = 10.0f;
    ImVec2 pos(screenSize.x - size - margin, margin + 40.0f);
    ImVec2 center(pos.x + size * 0.5f, pos.y + size * 0.5f);
    float radius = size * 0.5f - 3.0f;
    float alpha = g_Cfg.RadarOpacity;

    dl->AddRectFilled(pos, ImVec2(pos.x + size, pos.y + size), C(ImColor(8, 8, 14, (int)(200 * alpha))), 6.0f);
    dl->AddRect(pos, ImVec2(pos.x + size, pos.y + size), C(ImColor(g_Cfg.AccentColor.Value.x * 0.3f, g_Cfg.AccentColor.Value.y * 0.3f, g_Cfg.AccentColor.Value.z * 0.3f, 0.5f * alpha)), 6.0f, 0, 1.5f);

    dl->PushClipRect(pos, ImVec2(pos.x + size, pos.y + size), true);

    ImU32 ringCol = C(ImColor(255, 255, 255, (int)(25 * alpha)));
    dl->PathArcTo(center, radius, 0.0f, 6.2831855f, 32);
    dl->PathStroke(ringCol, false, 1.0f);

    float rings[] = { 0.25f, 0.50f, 0.75f };
    for (int i = 0; i < 3; i++) {
        dl->PathArcTo(center, radius * rings[i], 0.0f, 6.2831855f, 24);
        dl->PathStroke(ringCol, false, 1.0f);
    }

    ImU32 labelC = C(ImColor(180, 180, 200, (int)(100 * alpha)));
    float lOff = radius + 2.0f;
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 9.0f, ImVec2(center.x - 4.0f, center.y - lOff - 5.0f), labelC, "N");
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 9.0f, ImVec2(center.x - 4.0f, center.y + lOff - 5.0f), labelC, "S");
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 9.0f, ImVec2(center.x - lOff - 7.0f, center.y - 5.0f), labelC, "W");
    dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 9.0f, ImVec2(center.x + lOff - 2.0f, center.y - 5.0f), labelC, "E");

    static float s_sweepAngle = 0.0f;
    float dt = ImGui::GetIO().DeltaTime;
    if (dt > 0.1f) dt = 0.016f;
    s_sweepAngle += dt * 2.0f;
    if (s_sweepAngle > 6.2831855f) s_sweepAngle -= 6.2831855f;

    if (g_Tog.RadarScan)
    {
        float sweepEnd = s_sweepAngle + 0.523599f;
        ImU32 scanCol = C(ImColor(g_Cfg.AccentColor.Value.x, g_Cfg.AccentColor.Value.y, g_Cfg.AccentColor.Value.z, (int)(55 * alpha)));
        dl->PathArcTo(center, radius, s_sweepAngle, sweepEnd, 24);
        dl->PathLineTo(center);
        dl->PathFillConvex(scanCol);
        dl->PathArcTo(center, radius, s_sweepAngle, s_sweepAngle + 0.02f, 4);
        dl->PathLineTo(center);
        dl->PathFillConvex(C(ImColor(g_Cfg.AccentColor.Value.x * 255.0f, g_Cfg.AccentColor.Value.y * 255.0f, g_Cfg.AccentColor.Value.z * 255.0f, (int)(90 * alpha))));
    }

    D3DVector localPos = g_Offsets.CameraPos;
    float range = g_Cfg.RadarRange;
    if (range < 1.0f) range = 200.0f;
    float scale = g_Cfg.RadarScale * 0.01f;
    float yaw = g_Offsets.CameraYaw;

    for (int i = 0; i < g_Esp.PlayerCount; i++)
    {
        const PlayerData& p = g_Esp.Players[i];
        if (!p.IsAlive) continue;
        if (p.PlayerID == 0) continue;

        float dx = p.Position.X - localPos.X;
        float dy = p.Position.Y - localPos.Y;
        float dist2D = sqrtf(dx * dx + dy * dy);
        if (dist2D > range || dist2D < 0.1f) continue;

        bool isEnemy = (p.TeamID != 0);
        if (!g_Tog.FilterEnemy && isEnemy) continue;
        if (!g_Tog.FilterTeam && !isEnemy) continue;

        float nx = dx / range;
        float ny = dy / range;

        if (g_Tog.RadarRotate)
        {
            float yawRad = yaw * 3.14159f / 180.0f;
            float rx = nx * cosf(yawRad) + ny * sinf(yawRad);
            float ry = -nx * sinf(yawRad) + ny * cosf(yawRad);
            nx = rx;
            ny = ry;
        }

        float sx = center.x + nx * radius * scale;
        float sy = center.y - ny * radius * scale;

        float dClamp = ClampF(dist2D, 0.0f, range) / range;
        float dotR = g_Cfg.RadarDotSize * (0.8f + (1.0f - dClamp) * 0.6f);
        if (dotR < 1.5f) dotR = 1.5f;
        if (dotR > 6.0f) dotR = 6.0f;

        if (g_Tog.RadarSnaplines)
        {
            dl->AddLine(center, ImVec2(sx, sy), C(ImColor(255, 255, 255, (int)(35 * alpha))), 1.0f);
        }

        ImColor dotCol = isEnemy ? ImColor(255, 40, 40, (int)(220 * alpha)) : ImColor(40, 140, 255, (int)(220 * alpha));
        dl->AddCircleFilled(ImVec2(sx, sy), dotR, C(dotCol), 8);
        dl->AddCircle(ImVec2(sx, sy), dotR + 1.0f, C(ImColor(255, 255, 255, (int)(50 * alpha))), 8, 1.0f);

        if (g_Tog.RadarNames)
        {
            dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 8.0f, ImVec2(sx + dotR + 2.0f, sy - 6.0f), C(ImColor(220, 220, 240, (int)(180 * alpha))), p.PlayerName);
        }

        if (g_Tog.RadarDistance)
        {
            char distBuf[16];
            snprintf(distBuf, sizeof(distBuf), "%.0f", dist2D);
            dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 7.0f, ImVec2(sx + dotR + 2.0f, sy + 2.0f), C(ImColor(180, 180, 200, (int)(140 * alpha))), distBuf);
        }
    }

    float triSize = 5.0f;
    float triAngle = g_Tog.RadarRotate ? 0.0f : (yaw * 3.14159f / 180.0f);
    ImVec2 triTip(center.x + sinf(triAngle) * triSize * 1.8f, center.y - cosf(triAngle) * triSize * 1.8f);
    ImVec2 triLeft(center.x + sinf(triAngle + 2.3f) * triSize, center.y - cosf(triAngle + 2.3f) * triSize);
    ImVec2 triRight(center.x + sinf(triAngle - 2.3f) * triSize, center.y - cosf(triAngle - 2.3f) * triSize);
    dl->AddTriangleFilled(triTip, triLeft, triRight, C(ImColor(0, 255, 80, (int)(240 * alpha))));
    dl->AddCircleFilled(center, 2.0f, C(ImColor(0, 255, 80, (int)(200 * alpha))), 6);

    dl->PopClipRect();
}

void DrawTabRadar(ImDrawList* dl, ImVec2 contentArea, ImVec2 contentPos)
{
    Config& c = g_Cfg;
    Toggles& t = g_Tog;
    ImColor accent = c.AccentColor;
    ImColor accent2 = c.AccentColor2;

    static bool radarPreviewCol = false;
    static bool radarSettingsCol = false;
    static bool radarAppearCol = false;
    static int radarModeIdx = 0;
    static float bgHue = 0.60f;
    static float enemyHue = 0.00f;
    static float teamHue = 0.58f;
    static float scanHue = 0.50f;

    float leftW = (contentArea.x - 12.0f) * 0.60f;
    float rightW = (contentArea.x - 12.0f) * 0.40f;
    float leftX = contentPos.x;
    float rightX = contentPos.x + leftW + 12.0f;
    float yPos = contentPos.y;

    ImGui::SetCursorScreenPos(ImVec2(leftX, yPos));
    ImGui::BeginChild("##radar_preview_card", ImVec2(leftW, 0.0f), false, ImGuiWindowFlags_NoScrollWithinParentChild);
    if (M_CardBegin("Radar Preview", &radarPreviewCol, accent))
    {
        M_CyberHeader("RADAR DISPLAY", accent2, NULL);
        M_SectionDivider("Live Preview", accent);

        ImVec2 childPos = ImGui::GetCursorScreenPos();
        ImVec2 avail = ImGui::GetContentRegionAvail();
        float previewSize = (avail.x < avail.y ? avail.x : avail.y) - 20.0f;
        if (previewSize > 360.0f) previewSize = 360.0f;
        if (previewSize < 60.0f) previewSize = 60.0f;
        float radius = previewSize * 0.5f;
        ImVec2 center(childPos.x + previewSize * 0.5f, childPos.y + previewSize * 0.5f);

        static float s_sweepAngle = 0.0f;
        s_sweepAngle += ImGui::GetIO().DeltaTime * 0.5f;
        if (s_sweepAngle > 6.2831855f) s_sweepAngle -= 6.2831855f;

        ImVec2 circleTL(center.x - radius, center.y - radius);
        ImVec2 circleBR(center.x + radius, center.y + radius);

        dl->PushClipRect(circleTL, circleBR, true);
        dl->PathArcTo(center, radius, 0.0f, 6.2831855f, 64);
        dl->PathFillConvex(C(ImColor(10, 10, 15, (int)(255 * c.RadarOpacity))));
        dl->PathArcTo(center, radius, 0.0f, 6.2831855f, 64);
        dl->PathStroke(C(ImColor(accent.Value.x * 255.0f, accent.Value.y * 255.0f, accent.Value.z * 255.0f, (int)(180 * c.RadarOpacity))), false, 2.0f);

        int ringAlpha = (int)(38 * c.RadarOpacity);
        ImU32 ringCol = C(ImColor(255, 255, 255, ringAlpha));
        float ringPcts[] = { 0.25f, 0.50f, 0.75f };
        for (int i = 0; i < 3; i++) {
            dl->PathArcTo(center, radius * ringPcts[i], 0.0f, 6.2831855f, 48);
            dl->PathStroke(ringCol, false, 1.0f);
        }

        float labelOff = radius + 12.0f;
        ImU32 labelCol = C(ImColor(200, 200, 220, (int)(200 * c.RadarOpacity)));
        dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 10.0f, ImVec2(center.x - 4.0f, center.y - labelOff - 6.0f), labelCol, "N");
        dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 10.0f, ImVec2(center.x - 4.0f, center.y + labelOff - 6.0f), labelCol, "S");
        dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 10.0f, ImVec2(center.x - labelOff - 6.0f, center.y - 6.0f), labelCol, "W");
        dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 10.0f, ImVec2(center.x + labelOff - 6.0f, center.y - 6.0f), labelCol, "E");

        if (t.RadarScan)
        {
            float sweepEnd = s_sweepAngle + 0.785398f;
            dl->PathArcTo(center, radius, s_sweepAngle, sweepEnd, 32);
            dl->PathLineTo(center);
            dl->PathFillConvex(C(ImColor(accent.Value.x, accent.Value.y, accent.Value.z, (int)(60 * c.RadarOpacity))));
            dl->PathArcTo(center, radius, s_sweepAngle, s_sweepAngle + 0.025f, 8);
            dl->PathLineTo(center);
            dl->PathFillConvex(C(ImColor(accent.Value.x * 255.0f, accent.Value.y * 255.0f, accent.Value.z * 255.0f, (int)(100 * c.RadarOpacity))));
        }

        D3DVector localPos = g_Offsets.CameraPos;
        float range = c.RadarRange;
        if (range < 1.0f) range = 200.0f;
        float scale = c.RadarScale * 0.01f;
        float yaw = g_Offsets.CameraYaw;

        for (int i = 0; i < g_Esp.PlayerCount; i++)
        {
            const PlayerData& p = g_Esp.Players[i];
            if (!p.IsAlive) continue;
            if (p.PlayerID == 0) continue;

            float dx = p.Position.X - localPos.X;
            float dy = p.Position.Y - localPos.Y;
            float dz = p.Position.Z - localPos.Z;

            float dist2D = sqrtf(dx * dx + dy * dy);
            if (dist2D > range || dist2D < 0.1f) continue;

            D2DVector rel(dx, dy);
            if (t.RadarRotate)
            {
                float yawRad = yaw * 3.14159f / 180.0f;
                rel = Rotate2D(rel, -yawRad);
            }

            float nx = rel.X / range;
            float ny = rel.Y / range;
            float sx = center.x + nx * radius * scale;
            float sy = center.y - ny * radius * scale;

            if (!t.FilterEnemy && p.TeamID != 0) continue;
            if (!t.FilterTeam && p.TeamID == 0) continue;

            float dClamp = ClampF(dist2D, 0.0f, range) / range;
            float dotR = c.RadarDotSize * (1.0f + (1.0f - dClamp) * 0.8f);
            if (dotR < 2.0f) dotR = 2.0f;
            if (dotR > 10.0f) dotR = 10.0f;

            bool isEnemy = (p.TeamID != 0);
            ImColor dotCol = isEnemy ? ImColor(255, 40, 40, (int)(220 * c.RadarOpacity)) : ImColor(40, 140, 255, (int)(220 * c.RadarOpacity));

            if (t.RadarSnaplines)
            {
                ImU32 lineCol = C(ImColor(255, 255, 255, (int)(40 * c.RadarOpacity)));
                dl->AddLine(center, ImVec2(sx, sy), lineCol, 1.0f);
            }

            dl->AddCircleFilled(ImVec2(sx, sy), dotR, C(dotCol), 12);
            dl->AddCircle(ImVec2(sx, sy), dotR + 1.0f, C(ImColor(255, 255, 255, (int)(60 * c.RadarOpacity))), 12, 1.0f);

            if (t.RadarNames)
            {
                dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 9.0f, ImVec2(sx + dotR + 3.0f, sy - 6.0f), C(ImColor(220, 220, 240, (int)(200 * c.RadarOpacity))), p.PlayerName);
            }

            if (t.RadarDistance)
            {
                char distBuf[32];
                snprintf(distBuf, sizeof(distBuf), "%.0fm", dist2D);
                dl->AddText(ImGui::GetIO().Fonts->Fonts[0], 8.0f, ImVec2(sx + dotR + 3.0f, sy + 4.0f), C(ImColor(180, 180, 200, (int)(160 * c.RadarOpacity))), distBuf);
            }
        }

        float triSize = 8.0f;
        float triAngle = t.RadarRotate ? 0.0f : (yaw * 3.14159f / 180.0f);
        ImVec2 triTip(center.x + sinf(triAngle) * triSize * 1.6f, center.y - cosf(triAngle) * triSize * 1.6f);
        ImVec2 triLeft(center.x + sinf(triAngle + 2.3f) * triSize * 0.8f, center.y - cosf(triAngle + 2.3f) * triSize * 0.8f);
        ImVec2 triRight(center.x + sinf(triAngle - 2.3f) * triSize * 0.8f, center.y - cosf(triAngle - 2.3f) * triSize * 0.8f);
        dl->AddTriangleFilled(triTip, triLeft, triRight, C(ImColor(0, 255, 100, (int)(255 * c.RadarOpacity))));
        dl->AddCircleFilled(center, 3.0f, C(ImColor(0, 255, 100, (int)(200 * c.RadarOpacity))), 8);

        dl->PopClipRect();

        ImGui::SetCursorScreenPos(ImVec2(childPos.x, childPos.y + previewSize + 20.0f));

        M_SectionDivider("Radar Info", accent);
        char valBuf[128];
        snprintf(valBuf, sizeof(valBuf), "%.0f / %.0f", c.RadarRange, c.RadarScale);
        M_InfoRow("Range / Scale", valBuf, accent, "R");
        snprintf(valBuf, sizeof(valBuf), "%d players", g_Esp.PlayerCount);
        M_InfoRow("Tracked", valBuf, accent, "T");
        M_InfoRow("Sweep", t.RadarScan ? "On" : "Off", t.RadarScan ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "S");
        M_InfoRow("Rotation", t.RadarRotate ? "On" : "Off", t.RadarRotate ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "R");

        M_BooleanIndicator("Radar Active", t.ShowRadar, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Scan Active", t.RadarScan, accent, ImColor(60, 60, 70));

        M_Badge("RDR", accent, ImVec2(leftX + 8, ImGui::GetCursorScreenPos().y));
        ImGui::Dummy(ImVec2(0, 4));
    }
    M_CardEnd();
    ImGui::EndChild();
    float yLeft = ImGui::GetCursorScreenPos().y;

    ImGui::SetCursorScreenPos(ImVec2(rightX, yPos));
    ImGui::BeginChild("##radar_settings_card", ImVec2(rightW, 0.0f), false, ImGuiWindowFlags_NoScrollWithinParentChild);
    if (M_CardBegin("Radar Settings", &radarSettingsCol, accent))
    {
        M_CyberHeader("RADAR SETTINGS", accent2, NULL);

        M_SectionDivider("Main Controls", accent);
        M_ModernSwitch("Show Radar", &t.ShowRadar, accent);
        if (!t.ShowRadar)
        {
            M_InfoRow("Status", "HIDDEN", ImColor(255, 80, 80), "!");
            dl->AddRectFilled(
                ImVec2(rightX + 10, ImGui::GetCursorScreenPos().y),
                ImVec2(rightX + rightW - 10, ImGui::GetCursorScreenPos().y + 24),
                C(ImColor(255, 50, 50, 30)), 4.0f);
            dl->AddRect(
                ImVec2(rightX + 10, ImGui::GetCursorScreenPos().y),
                ImVec2(rightX + rightW - 10, ImGui::GetCursorScreenPos().y + 24),
                C(ImColor(255, 50, 50, 60)), 4.0f, 0, 1.0f);
            ImGui::Dummy(ImVec2(0, 28));
        }
        else
        {
            M_InfoRow("Status", "ACTIVE", ImColor(0, 220, 100), "+");
        }

        M_SectionDivider("Range & Scale", accent);
        M_GradientSlider("Range", &c.RadarRange, 50.0f, 500.0f, "%.0f m", accent);
        float scaleVal = c.RadarScale / 100.0f;
        if (M_GradientSlider("Scale", &scaleVal, 0.5f, 3.0f, "%.1fx", accent))
            c.RadarScale = scaleVal * 100.0f;

        M_SectionDivider("Filtering", accent);
        M_ModernSwitch("Show Enemy", &t.FilterEnemy, accent);
        M_ModernSwitch("Show Team", &t.FilterTeam, accent);

        M_SectionDivider("Display Mode", accent);
        const char* radarModeOpts[] = { "2D", "3D", "Hybrid" };
        M_SegmentedToggle("Radar Mode", &radarModeIdx, radarModeOpts, 3, accent);

        M_SectionDivider("Features", accent);
        M_ModernSwitch("Rotate with Player", &t.RadarRotate, accent);
        M_ModernSwitch("Show Names", &t.RadarNames, accent);
        M_ModernSwitch("Show Distance", &t.RadarDistance, accent);
        M_ModernSwitch("Snaplines", &t.RadarSnaplines, accent);
        M_ModernSwitch("Scan Effect", &t.RadarScan, accent);

        M_SectionDivider("State Overview", accent);
        snprintf(valBuf, sizeof(valBuf), "%.0f", c.RadarRange);
        M_InfoRow("Range", valBuf, accent, "G");
        snprintf(valBuf, sizeof(valBuf), "%.1fx", scaleVal);
        M_InfoRow("Scale", valBuf, accent, "S");
        M_InfoRow("Mode", radarModeOpts[radarModeIdx], accent, "M");
        M_InfoRow("Enemies", t.FilterEnemy ? "Shown" : "Hidden", t.FilterEnemy ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "E");
        M_InfoRow("Teammates", t.FilterTeam ? "Shown" : "Hidden", t.FilterTeam ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "T");
        M_InfoRow("Rotation", t.RadarRotate ? "Locked" : "Free", t.RadarRotate ? ImColor(0, 220, 100) : ImColor(200, 180, 0), "O");
        M_InfoRow("Names", t.RadarNames ? "On" : "Off", t.RadarNames ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "N");
        M_InfoRow("Distance", t.RadarDistance ? "On" : "Off", t.RadarDistance ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "D");
        M_InfoRow("Snaplines", t.RadarSnaplines ? "On" : "Off", t.RadarSnaplines ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "L");
        M_InfoRow("Scan Effect", t.RadarScan ? "On" : "Off", t.RadarScan ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "W");

        M_BooleanIndicator("Show Radar", t.ShowRadar, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Show Enemy", t.FilterEnemy, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Show Team", t.FilterTeam, accent, ImColor(60, 60, 70));

        dl->AddRectFilled(
            ImVec2(rightX + 8, ImGui::GetCursorScreenPos().y),
            ImVec2(rightX + rightW - 8, ImGui::GetCursorScreenPos().y + 2),
            C(ImColor(255, 255, 255, 10)), 1.0f);
        ImGui::Dummy(ImVec2(0, 4));

        int featCount = (t.ShowRadar ? 1 : 0) + (t.FilterEnemy ? 1 : 0) + (t.FilterTeam ? 1 : 0) +
                        (t.RadarRotate ? 1 : 0) + (t.RadarNames ? 1 : 0) + (t.RadarDistance ? 1 : 0) +
                        (t.RadarSnaplines ? 1 : 0) + (t.RadarScan ? 1 : 0);
        snprintf(valBuf, sizeof(valBuf), "%d/8", featCount);
        M_StatCard("Active Features", valBuf, NULL, featCount > 4, accent);

        M_ActionButton("R", "Reset Radar Defaults", ImVec2(rightW - 20, 36), accent, NULL);
        M_IconButton("S", "Toggle Scan", ImVec2(36, 36), accent, t.RadarScan, 0);
    }
    M_CardEnd();
    ImGui::EndChild();
    float yRSettings = ImGui::GetCursorScreenPos().y;

    ImGui::SetCursorScreenPos(ImVec2(rightX, yRSettings + 4.0f));
    ImGui::BeginChild("##radar_appear_card", ImVec2(rightW, 0.0f), false, ImGuiWindowFlags_NoScrollWithinParentChild);
    if (M_CardBegin("Appearance", &radarAppearCol, accent))
    {
        M_CyberHeader("RADAR APPEARANCE", accent2, NULL);

        M_SectionDivider("Color Configuration", accent);
        M_ColorSlider("Background", &bgHue, ImColor(10, 10, 20), ImColor(30, 30, 50), accent);
        M_ColorSlider("Enemy Color", &enemyHue, ImColor(255, 40, 40), ImColor(255, 100, 0), accent);
        M_ColorSlider("Team Color", &teamHue, ImColor(40, 140, 255), ImColor(0, 200, 100), accent);
        M_ColorSlider("Scan Color", &scanHue, ImColor(0, 180, 255), ImColor(100, 50, 255), accent);

        M_SectionDivider("Scale & Opacity", accent);
        float op = c.RadarOpacity;
        if (M_GradientSlider("Opacity", &op, 0.10f, 1.0f, "%.2f", accent))
            c.RadarOpacity = op;
        float ds = c.RadarDotSize;
        if (M_GradientSlider("Dot Size", &ds, 2.0f, 10.0f, "%.0f px", accent))
            c.RadarDotSize = ds;

        M_SectionDivider("Appearance Status", accent);
        snprintf(valBuf, sizeof(valBuf), "%.0f%%", c.RadarOpacity * 100.0f);
        M_InfoRow("Opacity", valBuf, accent, "O");
        snprintf(valBuf, sizeof(valBuf), "%.0f px", c.RadarDotSize);
        M_InfoRow("Dot Size", valBuf, accent, "D");
        M_InfoRow("Mode", radarModeOpts[radarModeIdx], accent, "M");
        M_InfoRow("Rotation", t.RadarRotate ? "On" : "Off", t.RadarRotate ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "R");
        M_InfoRow("Names", t.RadarNames ? "On" : "Off", t.RadarNames ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "N");
        M_InfoRow("Distances", t.RadarDistance ? "On" : "Off", t.RadarDistance ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "D");
        M_InfoRow("Snaplines", t.RadarSnaplines ? "On" : "Off", t.RadarSnaplines ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "L");
        M_InfoRow("Scan", t.RadarScan ? "On" : "Off", t.RadarScan ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "W");

        M_BooleanIndicator("Opacity Set", c.RadarOpacity > 0.5f, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Enemy Visible", t.FilterEnemy, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Team Visible", t.FilterTeam, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Scan Active", t.RadarScan, accent, ImColor(60, 60, 70));

        dl->AddRectFilled(
            ImVec2(rightX + 8, ImGui::GetCursorScreenPos().y),
            ImVec2(rightX + rightW - 8, ImGui::GetCursorScreenPos().y + 2),
            C(ImColor(255, 255, 255, 10)), 1.0f);
        ImGui::Dummy(ImVec2(0, 4));

        M_Badge("CLR", accent, ImVec2(rightX + 8, ImGui::GetCursorScreenPos().y));
        ImGui::Dummy(ImVec2(0, 4));

        M_GradientButton("Reset Colors", ImVec2(rightW - 20, 36), accent, accent2, 4.0f);

        int colorCount = 4 + (c.RadarOpacity > 0.5f ? 1 : 0) + (c.RadarDotSize > 3.0f ? 1 : 0);
        snprintf(valBuf, sizeof(valBuf), "%d", colorCount);
        M_StatCard("Active Color Slots", valBuf, NULL, false, accent);

        M_InfoRow("Color Mode", "HSL Custom", accent, "C");
        M_InfoRow("Ring Style", "Concentric", accent, "I");
        M_InfoRow("Sweep Style", "Radial Arc", accent, "W");
        M_InfoRow("Cardinal Labels", "N/S/E/W", accent, "L");
        M_InfoRow("Coordinate System", "World Relative", accent, "C");
        M_InfoRow("Rotation Origin", "Player Yaw", accent, "Y");
    }
    M_CardEnd();
    ImGui::EndChild();
    float yAppear = ImGui::GetCursorScreenPos().y;

    float finalY = (yLeft > yRSettings ? yLeft : yRSettings);
    finalY = (finalY > yAppear ? finalY : yAppear) + 4.0f;
    ImGui::SetCursorScreenPos(ImVec2(contentPos.x, finalY));
}
