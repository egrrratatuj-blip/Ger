#pragma once
#include <string>
#include <vector>
#include <map>
#include <functional>
#include <memory>
#include <atomic>
#include <thread>
#include <mutex>
#include <queue>
#include <chrono>
#include <cstdint>
#include <cstring>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/epoll.h>
#include <netdb.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

namespace BugorNetwork {

enum class SocketType {
    TCP,
    TLS,
    UDP,
    UNIX
};

enum class ProtocolState {
    Disconnected,
    Connecting,
    Connected,
    Disconnecting,
    Error
};

enum class PacketType : uint8_t {
    Heartbeat = 0x01,
    Config = 0x02,
    Command = 0x03,
    Data = 0x04,
    Encrypted = 0x05,
    Compressed = 0x06,
    EncryptedCompressed = 0x07,
    Auth = 0x08,
    Ack = 0x09,
    Error = 0xFF
};

struct PacketHeader {
    uint32_t magic;
    uint16_t version;
    uint8_t type;
    uint16_t flags;
    uint32_t sequence;
    uint32_t timestamp;
    uint32_t bodySize;
    uint32_t checksum;
    uint32_t reserved[4];
};

struct NetworkPacket {
    PacketHeader header;
    std::vector<uint8_t> body;
    std::chrono::steady_clock::time_point created;
    NetworkPacket() : created(std::chrono::steady_clock::now()) {}
};

struct ServerEndpoint {
    std::string host;
    uint16_t port;
    std::string path;
    bool useTLS;
    bool useProxy;
    std::string proxyHost;
    uint16_t proxyPort;
    std::string proxyUsername;
    std::string proxyPassword;
    std::string caCertPath;
    std::string clientCertPath;
    std::string clientKeyPath;
};

struct ConnectionConfig {
    std::string userAgent;
    std::string apiKey;
    std::string deviceId;
    std::string sessionToken;
    uint32_t heartbeatInterval;
    uint32_t reconnectDelay;
    uint32_t maxReconnectAttempts;
    uint32_t timeoutSeconds;
    uint32_t bufferSize;
    bool enableEncryption;
    bool enableCompression;
    bool autoReconnect;
    bool keepAlive;
    ServerEndpoint primary;
    ServerEndpoint backup;
    ServerEndpoint websocket;
    std::vector<ServerEndpoint> endpoints;
};

struct DataChunk {
    uint32_t id;
    uint32_t total;
    uint32_t index;
    std::vector<uint8_t> data;
    bool isLast;
};

class TLSSocket {
public:
    TLSSocket();
    ~TLSSocket();
    bool initialize();
    bool connect(const std::string &host, uint16_t port);
    bool connectWithProxy(const std::string &host, uint16_t port,
                          const std::string &proxyHost, uint16_t proxyPort);
    bool handshake();
    ssize_t send(const uint8_t *data, size_t length);
    ssize_t recv(uint8_t *buffer, size_t length);
    bool shutdown();
    void cleanup();
    bool isConnected() const;
    int getSocket() const;
    SSL* getSSL() const;
    std::string getCipher() const;
    std::string getVersion() const;
    bool verifyCertificate();
    void setTimeout(uint32_t seconds);
    void setNonBlocking(bool enable);
    bool setCertificate(const std::string &caPath,
                        const std::string &certPath,
                        const std::string &keyPath);
    bool loadCertificate(const std::string &path);
    bool setSNI(const std::string &hostname);

private:
    SSL_CTX *ctx;
    SSL *ssl;
    int sock;
    bool connected;
    std::string hostname;
    std::mutex sslMutex;
    bool initOpenSSL;
    bool createContext();
    bool configureContext();
    static std::mutex globalSSLMutex;
    static int sslInstanceCount;
};

class HTTPClient {
public:
    HTTPClient();
    ~HTTPClient();
    struct Response {
        int statusCode;
        std::map<std::string, std::string> headers;
        std::vector<uint8_t> body;
        std::string text;
        double elapsed;
        bool success;
        std::string error;
    };
    struct Request {
        std::string method;
        std::string url;
        std::map<std::string, std::string> headers;
        std::vector<uint8_t> body;
        std::string contentType;
        bool followRedirect;
        uint32_t timeout;
        std::string proxyHost;
        uint16_t proxyPort;
        bool verifySSL;
        std::string caPath;
        std::string certPath;
        std::string keyPath;
        std::map<std::string, std::string> params;
        std::string userAgent;
        bool keepAlive;
    };
    Response get(const std::string &url);
    Response post(const std::string &url, const std::vector<uint8_t> &data);
    Response put(const std::string &url, const std::vector<uint8_t> &data);
    Response del(const std::string &url);
    Response head(const std::string &url);
    Response options(const std::string &url);
    Response patch(const std::string &url, const std::vector<uint8_t> &data);
    Response execute(const Request &req);
    void setBaseUrl(const std::string &url);
    void setDefaultHeader(const std::string &key, const std::string &value);
    void setProxy(const std::string &host, uint16_t port);
    void setCertificate(const std::string &caPath,
                        const std::string &certPath,
                        const std::string &keyPath);
    void setTimeout(uint32_t seconds);
    void setUserAgent(const std::string &ua);
    void setBearerToken(const std::string &token);
    void setApiKey(const std::string &key);
    void enableKeepAlive(bool enable);
    std::string urlEncode(const std::string &value);
    std::map<std::string, std::string> urlDecode(const std::string &encoded);
    std::string buildQueryString(const std::map<std::string, std::string> &params);

private:
    std::string baseUrl;
    std::map<std::string, std::string> defaultHeaders;
    std::string proxyHost;
    uint16_t proxyPort;
    std::string caPath;
    std::string certPath;
    std::string keyPath;
    uint32_t timeout;
    std::string userAgent;
    bool keepAlive;
    std::unique_ptr<TLSSocket> tlsSocket;
    Response sendRequest(const std::string &method, const std::string &path,
                         const std::map<std::string, std::string> &headers,
                         const std::vector<uint8_t> &body);
    std::string parseURL(const std::string &url, std::string &host,
                         uint16_t &port, std::string &path, bool &isTLS);
    std::string buildRequest(const std::string &method, const std::string &path,
                             const std::map<std::string, std::string> &headers,
                             const std::vector<uint8_t> &body);
    Response parseResponse(const std::string &raw);
};

class WebSocketClient {
public:
    WebSocketClient();
    ~WebSocketClient();
    using MessageCallback = std::function<void(const std::vector<uint8_t>&, bool)>;
    using StateCallback = std::function<void(ProtocolState)>;
    using ErrorCallback = std::function<void(const std::string&)>;
    bool connect(const std::string &url);
    bool connect(const std::string &host, uint16_t port, const std::string &path);
    bool disconnect();
    bool send(const std::vector<uint8_t> &data, bool binary = true);
    bool sendText(const std::string &text);
    bool sendPing();
    bool sendPong();
    bool isConnected() const;
    void setMessageCallback(MessageCallback cb);
    void setStateCallback(StateCallback cb);
    void setErrorCallback(ErrorCallback cb);
    void setProxy(const std::string &host, uint16_t port);
    void setTimeout(uint32_t seconds);
    void setAutoReconnect(bool enable);
    void setReconnectDelay(uint32_t ms);
    void start();
    void stop();
    void setHeader(const std::string &key, const std::string &value);

private:
    int sock;
    std::string host;
    uint16_t port;
    std::string path;
    std::string proxyHost;
    uint16_t proxyPort;
    bool useTLS;
    bool connected;
    bool autoReconnect;
    uint32_t reconnectDelay;
    uint32_t timeout;
    std::unique_ptr<TLSSocket> tls;
    MessageCallback onMessage;
    StateCallback onState;
    ErrorCallback onError;
    std::map<std::string, std::string> headers;
    std::atomic<bool> running;
    std::thread *workerThread;
    std::mutex socketMutex;
    std::mutex callbackMutex;
    void workerLoop();
    bool performHandshake();
    std::string generateWebSocketKey();
    std::string computeAcceptKey(const std::string &key);
    std::vector<uint8_t> encodeFrame(uint8_t opcode, const std::vector<uint8_t> &payload);
    std::vector<uint8_t> decodeFrame(const std::vector<uint8_t> &frame, uint8_t &opcode);
    void handleFrame(uint8_t opcode, const std::vector<uint8_t> &payload);
    bool sendFrame(uint8_t opcode, const std::vector<uint8_t> &payload);
    void changeState(ProtocolState state);
};

class EncryptedProtocol {
public:
    EncryptedProtocol();
    ~EncryptedProtocol();
    bool initialize(const std::vector<uint8_t> &key);
    std::vector<uint8_t> encrypt(const std::vector<uint8_t> &data);
    std::vector<uint8_t> decrypt(const std::vector<uint8_t> &data);
    std::vector<uint8_t> encryptPacket(const NetworkPacket &packet);
    NetworkPacket decryptPacket(const std::vector<uint8_t> &data);
    std::vector<uint8_t> compress(const std::vector<uint8_t> &data);
    std::vector<uint8_t> decompress(const std::vector<uint8_t> &data);
    std::vector<uint8_t> sign(const std::vector<uint8_t> &data);
    bool verify(const std::vector<uint8_t> &data, const std::vector<uint8_t> &signature);
    void setKey(const std::vector<uint8_t> &key);
    void rotateKey();
    std::vector<uint8_t> getPublicKey() const;
    bool generateKeyPair();
    std::vector<uint8_t> keyExchange(const std::vector<uint8_t> &peerPublicKey);
    uint64_t getSequenceNumber() const;
    void resetSequence();

private:
    std::vector<uint8_t> encryptionKey;
    std::vector<uint8_t> publicKey;
    std::vector<uint8_t> privateKey;
    std::atomic<uint64_t> sequenceNumber;
    std::mutex cryptoMutex;
    bool initialized;
    uint8_t nonce[24];
    void incrementNonce();
    void generateNonce();
    std::vector<uint8_t> padData(const std::vector<uint8_t> &data);
    std::vector<uint8_t> unpadData(const std::vector<uint8_t> &data);
};

class RemoteConfigFetcher {
public:
    RemoteConfigFetcher();
    ~RemoteConfigFetcher();
    bool fetch(const std::string &url, std::string &config);
    bool fetchWithAuth(const std::string &url, const std::string &token,
                       std::string &config);
    bool fetchWithSignature(const std::string &url,
                            const std::vector<uint8_t> &key,
                            std::string &config);
    bool upload(const std::string &url, const std::string &config);
    bool uploadEncrypted(const std::string &url, const std::string &config,
                         const std::vector<uint8_t> &key);
    void setCacheEnabled(bool enable);
    void setCacheTTL(uint32_t seconds);
    void clearCache();
    bool getFromCache(const std::string &key, std::string &data);
    void setCache(const std::string &key, const std::string &data);
    void setDefaultConfig(const std::string &config);
    std::string getDefaultConfig() const;
    void setFallbackUrls(const std::vector<std::string> &urls);

private:
    HTTPClient client;
    bool cacheEnabled;
    uint32_t cacheTTL;
    std::map<std::string, std::pair<std::string,
             std::chrono::steady_clock::time_point>> cache;
    std::string defaultConfig;
    std::vector<std::string> fallbackUrls;
    std::mutex cacheMutex;
};

class HeartbeatSystem {
public:
    HeartbeatSystem();
    ~HeartbeatSystem();
    void start(uint32_t intervalMs = 30000);
    void stop();
    void setInterval(uint32_t ms);
    void sendHeartbeat();
    bool isAlive() const;
    void setCallback(std::function<void()> cb);
    void setFailureCallback(std::function<void()> cb);
    uint64_t getHeartbeatCount() const;
    std::chrono::steady_clock::time_point getLastHeartbeat() const;
    void setTimeout(uint32_t ms);
    bool waitForHeartbeat(uint32_t timeoutMs);
    void setServerEndpoint(const std::string &host, uint16_t port);
    void setAuthToken(const std::string &token);

private:
    std::atomic<bool> running;
    std::atomic<bool> alive;
    std::thread *heartbeatThread;
    std::function<void()> onHeartbeat;
    std::function<void()> onFailure;
    std::atomic<uint64_t> heartbeatCount;
    std::chrono::steady_clock::time_point lastHeartbeat;
    std::mutex heartbeatMutex;
    std::condition_variable heartbeatCV;
    uint32_t interval;
    uint32_t timeoutMs;
    std::string serverHost;
    uint16_t serverPort;
    std::string authToken;
    HTTPClient httpClient;
    void heartbeatLoop();
};

class PacketCrypto {
public:
    PacketCrypto();
    std::vector<uint8_t> encryptPacket(const std::vector<uint8_t> &plaintext,
                                        const std::vector<uint8_t> &key);
    std::vector<uint8_t> decryptPacket(const std::vector<uint8_t> &ciphertext,
                                        const std::vector<uint8_t> &key);
    std::vector<uint8_t> signPacket(const std::vector<uint8_t> &data,
                                     const std::vector<uint8_t> &privateKey);
    bool verifyPacket(const std::vector<uint8_t> &data,
                      const std::vector<uint8_t> &signature,
                      const std::vector<uint8_t> &publicKey);
    std::vector<uint8_t> hashPacket(const std::vector<uint8_t> &data);
    std::vector<uint8_t> generateKey();
    std::vector<uint8_t> deriveKey(const std::vector<uint8_t> &secret,
                                    const std::vector<uint8_t> &salt);
    uint32_t calculateChecksum(const std::vector<uint8_t> &data);
    PacketHeader createHeader(PacketType type, uint32_t bodySize);
    bool verifyHeader(const PacketHeader &header);
    std::vector<uint8_t> serialize(const NetworkPacket &packet);
    NetworkPacket deserialize(const std::vector<uint8_t> &data);
    std::vector<uint8_t> addPadding(const std::vector<uint8_t> &data);
    std::vector<uint8_t> removePadding(const std::vector<uint8_t> &data);
    std::vector<uint8_t> encryptWithNonce(const std::vector<uint8_t> &data,
                                           const std::vector<uint8_t> &key,
                                           const std::vector<uint8_t> &nonce);
    std::vector<uint8_t> decryptWithNonce(const std::vector<uint8_t> &data,
                                           const std::vector<uint8_t> &key,
                                           const std::vector<uint8_t> &nonce);

private:
    std::mt19937_64 rng;
    std::vector<uint8_t> nonceBuffer;
    void incrementNonce(std::vector<uint8_t> &nonce);
    std::vector<uint8_t> xorWithKey(const std::vector<uint8_t> &data,
                                     const std::vector<uint8_t> &key);
};

class ProxyManager {
public:
    ProxyManager();
    ~ProxyManager();
    enum ProxyType {
        None,
        HTTP,
        HTTPS,
        SOCKS4,
        SOCKS5
    };
    struct ProxyEntry {
        std::string host;
        uint16_t port;
        ProxyType type;
        std::string username;
        std::string password;
        std::string country;
        float speed;
        uint32_t uptime;
        bool isActive;
        bool isAnonymous;
        uint32_t failures;
    };
    bool setProxy(ProxyType type, const std::string &host, uint16_t port);
    bool setProxyWithAuth(ProxyType type, const std::string &host,
                          uint16_t port, const std::string &user,
                          const std::string &pass);
    void clearProxy();
    bool hasProxy() const;
    ProxyEntry getCurrentProxy() const;
    void setProxyList(const std::vector<ProxyEntry> &proxies);
    void addProxy(const ProxyEntry &proxy);
    bool rotateProxy();
    ProxyEntry getNextProxy();
    std::vector<ProxyEntry> getActiveProxies() const;
    void testProxy(const ProxyEntry &proxy);
    void testAllProxies();
    void removeDeadProxies();
    void setProxyTestUrl(const std::string &url);
    void setProxyTestTimeout(uint32_t ms);
    bool isProxyWorking(const ProxyEntry &proxy);
    std::vector<ProxyEntry> filterByCountry(const std::string &country);
    std::vector<ProxyEntry> filterByType(ProxyType type);
    void importFromUrl(const std::string &url);
    void importFromFile(const std::string &path);
    void exportToFile(const std::string &path);

private:
    ProxyEntry currentProxy;
    std::vector<ProxyEntry> proxies;
    size_t currentIndex;
    std::string testUrl;
    uint32_t testTimeout;
    std::mutex proxyMutex;
    bool connectWithProxy(const ProxyEntry &proxy);
    bool testProxyConnection(const ProxyEntry &proxy);
    std::string buildProxyRequest(const std::string &target,
                                  const ProxyEntry &proxy);
    bool parseProxyResponse(const std::string &response);
};

class NetworkManager {
public:
    NetworkManager();
    ~NetworkManager();
    bool initialize(const ConnectionConfig &config);
    void shutdown();
    bool connect();
    bool disconnect();
    bool send(const NetworkPacket &packet);
    bool sendEncrypted(const NetworkPacket &packet);
    bool sendWithRetry(const NetworkPacket &packet, int retries = 3);
    NetworkPacket receive();
    bool hasPendingData() const;
    void setReceiveCallback(std::function<void(const NetworkPacket&)> cb);
    void setConnectionCallback(std::function<void(ProtocolState)> cb);
    void setErrorCallback(std::function<void(const std::string&)> cb);
    bool isConnected() const;
    ProtocolState getState() const;
    std::string getSessionId() const;
    void setSessionId(const std::string &id);
    uint64_t getBytesSent() const;
    uint64_t getBytesReceived() const;
    uint32_t getPacketsSent() const;
    uint32_t getPacketsReceived() const;
    double getLatency() const;
    void startHeartbeat();
    void stopHeartbeat();
    void enableEncryption(bool enable);
    void enableCompression(bool enable);
    void setAutoReconnect(bool enable);
    void setMaxReconnectAttempts(uint32_t attempts);
    void setServerEndpoint(const std::string &host, uint16_t port);

private:
    ConnectionConfig config;
    std::unique_ptr<TLSSocket> tlsSocket;
    std::unique_ptr<EncryptedProtocol> crypto;
    std::unique_ptr<HeartbeatSystem> heartbeat;
    std::unique_ptr<PacketCrypto> packetCrypto;
    std::unique_ptr<ProxyManager> proxyManager;
    std::unique_ptr<RemoteConfigFetcher> configFetcher;
    ProtocolState state;
    std::string sessionId;
    std::atomic<uint64_t> bytesSent;
    std::atomic<uint64_t> bytesReceived;
    std::atomic<uint32_t> packetsSent;
    std::atomic<uint32_t> packetsReceived;
    std::atomic<double> latency;
    std::function<void(const NetworkPacket&)> onReceive;
    std::function<void(ProtocolState)> onStateChange;
    std::function<void(const std::string&)> onError;
    std::thread *receiveThread;
    std::thread *processThread;
    std::mutex networkMutex;
    std::queue<NetworkPacket> receiveQueue;
    std::queue<NetworkPacket> sendQueue;
    std::condition_variable queueCV;
    std::atomic<bool> running;
    uint32_t reconnectAttempts;
    void receiveLoop();
    void processLoop();
    bool attemptReconnect();
    void handlePacket(const NetworkPacket &packet);
    void changeState(ProtocolState newState);
    void updateLatency();
};

}
