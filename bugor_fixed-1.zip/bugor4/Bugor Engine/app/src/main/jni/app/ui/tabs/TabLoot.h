#pragma once
#include <imgui.h>

void DrawTabLoot(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize);
void InitTabLoot();
void ShutdownTabLoot();
