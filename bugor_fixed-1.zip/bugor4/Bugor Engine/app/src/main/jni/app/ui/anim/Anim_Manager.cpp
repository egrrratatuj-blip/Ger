#include "Anim_Manager.h"

SpringAnim::SpringAnim() {
    value = 0.0f;
    velocity = 0.0f;
    target = 0.0f;
    stiffness = 100.0f;
    damping = 10.0f;
    mass = 1.0f;
}

void SpringAnim::SetTarget(float t) {
    target = t;
}

void SpringAnim::Update(float dt) {
    if (dt > 0.05f) dt = 0.05f;
    float force = -stiffness * (value - target);
    float damper = -damping * velocity;
    float accel = (force + damper) / mass;
    velocity += accel * dt;
    value += velocity * dt;
    if (fabsf(velocity) < 0.001f && fabsf(value - target) < 0.001f) {
        value = target;
        velocity = 0.0f;
    }
}

bool SpringAnim::IsDone() {
    return fabsf(velocity) < 0.001f && fabsf(value - target) < 0.001f;
}

AnimationTrack::AnimationTrack() {
    type = FLOAT;
    loop = ONCE;
    duration = 1.0f;
    elapsed = 0.0f;
    delay = 0.0f;
    delayRemaining = 0.0f;
    easingType = 0;
    playing = false;
    completed = false;
    reverse = false;
    name[0] = '\0';
    startFloat = 0.0f;
    endFloat = 0.0f;
    currentFloat = 0.0f;
    startVec2 = ImVec2(0.0f, 0.0f);
    endVec2 = ImVec2(0.0f, 0.0f);
    currentVec2 = ImVec2(0.0f, 0.0f);
    startColor = ImColor(0.0f, 0.0f, 0.0f, 0.0f);
    endColor = ImColor(0.0f, 0.0f, 0.0f, 0.0f);
    currentColor = ImColor(0.0f, 0.0f, 0.0f, 0.0f);
    onComplete = 0;
    onUpdate = 0;
}

void AnimationTrack::Play() {
    playing = true;
    completed = false;
    elapsed = 0.0f;
    delayRemaining = delay;
    if (reverse) {
        float tmp = startFloat;
        startFloat = endFloat;
        endFloat = tmp;
        ImVec2 tmpv = startVec2;
        startVec2 = endVec2;
        endVec2 = tmpv;
        ImColor tmpc = startColor;
        startColor = endColor;
        endColor = tmpc;
    }
}

void AnimationTrack::Stop() {
    playing = false;
    completed = true;
}

void AnimationTrack::Pause() {
    playing = false;
}

void AnimationTrack::Resume() {
    playing = true;
}

void AnimationTrack::Reset() {
    playing = false;
    completed = false;
    elapsed = 0.0f;
    delayRemaining = delay;
    currentFloat = startFloat;
    currentVec2 = startVec2;
    currentColor = startColor;
}

void AnimationTrack::SetFloat(const char* n, float from, float to, float dur, int ease, float d) {
    type = FLOAT;
    strncpy(name, n, 63);
    name[63] = '\0';
    startFloat = from;
    endFloat = to;
    currentFloat = from;
    duration = dur;
    easingType = ease;
    delay = d;
    delayRemaining = d;
    loop = ONCE;
    playing = false;
    completed = false;
    reverse = false;
}

void AnimationTrack::SetVec2(const char* n, ImVec2 from, ImVec2 to, float dur, int ease, float d) {
    type = VEC2;
    strncpy(name, n, 63);
    name[63] = '\0';
    startVec2 = from;
    endVec2 = to;
    currentVec2 = from;
    duration = dur;
    easingType = ease;
    delay = d;
    delayRemaining = d;
    loop = ONCE;
    playing = false;
    completed = false;
    reverse = false;
}

void AnimationTrack::SetColor(const char* n, ImColor from, ImColor to, float dur, int ease, float d) {
    type = COLOR;
    strncpy(name, n, 63);
    name[63] = '\0';
    startColor = from;
    endColor = to;
    currentColor = from;
    duration = dur;
    easingType = ease;
    delay = d;
    delayRemaining = d;
    loop = ONCE;
    playing = false;
    completed = false;
    reverse = false;
}

void AnimationTrack::Update(float dt) {
    if (!playing || completed) {
        return;
    }
    if (delayRemaining > 0.0f) {
        delayRemaining -= dt;
        if (delayRemaining <= 0.0f) {
            dt = -delayRemaining;
            delayRemaining = 0.0f;
        } else {
            return;
        }
    }
    elapsed += dt;
    float progress = elapsed / duration;
    if (progress >= 1.0f) {
        progress = 1.0f;
        completed = true;
        switch (loop) {
            case ONCE: {
                playing = false;
                break;
            }
            case LOOP: {
                elapsed = 0.0f;
                completed = false;
                break;
            }
            case PING_PONG: {
                reverse = !reverse;
                elapsed = 0.0f;
                completed = false;
                float tmp = startFloat;
                startFloat = endFloat;
                endFloat = tmp;
                ImVec2 tmpv = startVec2;
                startVec2 = endVec2;
                endVec2 = tmpv;
                ImColor tmpc = startColor;
                startColor = endColor;
                endColor = tmpc;
                break;
            }
        }
    }
    float eased = ApplyEasing(progress, easingType);
    switch (type) {
        case FLOAT: {
            currentFloat = startFloat + (endFloat - startFloat) * eased;
            break;
        }
        case VEC2: {
            currentVec2.x = startVec2.x + (endVec2.x - startVec2.x) * eased;
            currentVec2.y = startVec2.y + (endVec2.y - startVec2.y) * eased;
            break;
        }
        case COLOR: {
            currentColor.Value.x = startColor.Value.x + (endColor.Value.x - startColor.Value.x) * eased;
            currentColor.Value.y = startColor.Value.y + (endColor.Value.y - startColor.Value.y) * eased;
            currentColor.Value.z = startColor.Value.z + (endColor.Value.z - startColor.Value.z) * eased;
            currentColor.Value.w = startColor.Value.w + (endColor.Value.w - startColor.Value.w) * eased;
            break;
        }
    }
    if (onUpdate) {
        onUpdate(name, GetFloat());
    }
    if (completed && onComplete) {
        onComplete(name);
    }
}

float AnimationTrack::GetFloat() {
    return currentFloat;
}

ImVec2 AnimationTrack::GetVec2() {
    return currentVec2;
}

ImColor AnimationTrack::GetColor() {
    return currentColor;
}

float AnimationTrack::GetProgress() {
    if (duration <= 0.0f) {
        return 0.0f;
    }
    float p = elapsed / duration;
    if (p > 1.0f) {
        p = 1.0f;
    }
    return p;
}

AnimationGroup::AnimationGroup() {
    trackCount = 0;
    parallel = true;
    playing = false;
}

void AnimationGroup::AddTrack(AnimationTrack& track) {
    if (trackCount >= 16) {
        return;
    }
    tracks[trackCount] = track;
    trackCount++;
}

void AnimationGroup::SetParallel(bool p) {
    parallel = p;
}

void AnimationGroup::Play() {
    playing = true;
    for (int i = 0; i < trackCount; i++) {
        tracks[i].Play();
    }
}

void AnimationGroup::Stop() {
    playing = false;
    for (int i = 0; i < trackCount; i++) {
        tracks[i].Stop();
    }
}

void AnimationGroup::Update(float dt) {
    if (!playing) {
        return;
    }
    if (parallel) {
        for (int i = 0; i < trackCount; i++) {
            tracks[i].Update(dt);
        }
    } else {
        for (int i = 0; i < trackCount; i++) {
            if (!tracks[i].completed) {
                tracks[i].Update(dt);
                break;
            }
        }
    }
    bool allDone = true;
    for (int i = 0; i < trackCount; i++) {
        if (!tracks[i].completed) {
            allDone = false;
            break;
        }
    }
    if (allDone) {
        playing = false;
    }
}

bool AnimationGroup::IsPlaying() {
    return playing;
}

AnimationManager::AnimationManager() {
    trackCount = 0;
    groupCount = 0;
}

int AnimationManager::CreateTrack() {
    if (trackCount >= 64) {
        return -1;
    }
    tracks[trackCount] = AnimationTrack();
    trackCount++;
    return trackCount - 1;
}

bool AnimationManager::DestroyTrack(int id) {
    if (id < 0 || id >= trackCount) {
        return false;
    }
    for (int i = id; i < trackCount - 1; i++) {
        tracks[i] = tracks[i + 1];
    }
    trackCount--;
    return true;
}

int AnimationManager::CreateGroup() {
    if (groupCount >= 8) {
        return -1;
    }
    groups[groupCount] = AnimationGroup();
    groupCount++;
    return groupCount - 1;
}

bool AnimationManager::DestroyGroup(int id) {
    if (id < 0 || id >= groupCount) {
        return false;
    }
    for (int i = id; i < groupCount - 1; i++) {
        groups[i] = groups[i + 1];
    }
    groupCount--;
    return true;
}

AnimationTrack* AnimationManager::GetTrack(int id) {
    if (id < 0 || id >= trackCount) {
        return 0;
    }
    return &tracks[id];
}

AnimationGroup* AnimationManager::GetGroup(int id) {
    if (id < 0 || id >= groupCount) {
        return 0;
    }
    return &groups[id];
}

void AnimationManager::UpdateAll(float dt) {
    for (int i = 0; i < trackCount; i++) {
        tracks[i].Update(dt);
    }
    for (int i = 0; i < groupCount; i++) {
        groups[i].Update(dt);
    }
}

void AnimationManager::StopAll() {
    for (int i = 0; i < trackCount; i++) {
        tracks[i].Stop();
    }
    for (int i = 0; i < groupCount; i++) {
        groups[i].Stop();
    }
}

void AnimationManager::PauseAll() {
    for (int i = 0; i < trackCount; i++) {
        tracks[i].Pause();
    }
}

int AnimationManager::GetActiveCount() {
    int count = 0;
    for (int i = 0; i < trackCount; i++) {
        if (tracks[i].playing) {
            count++;
        }
    }
    return count;
}

static char s_animManagerBuffer[sizeof(AnimationManager)];
static AnimationManager* s_animManager = 0;

AnimationManager* GetAnimManager() {
    if (!s_animManager) {
        s_animManager = new (s_animManagerBuffer) AnimationManager();
    }
    return s_animManager;
}

static SimpleTween s_tweens[32];
static int s_tweenCount = 0;

static int FindTween(const char* id) {
    for (int i = 0; i < s_tweenCount; i++) {
        if (strcmp(s_tweens[i].id, id) == 0) {
            return i;
        }
    }
    return -1;
}

void TweenFloat(const char* id, float target, float speed) {
    int idx = FindTween(id);
    if (idx == -1) {
        if (s_tweenCount >= 32) {
            return;
        }
        idx = s_tweenCount;
        s_tweenCount++;
        strncpy(s_tweens[idx].id, id, 63);
        s_tweens[idx].id[63] = '\0';
        s_tweens[idx].currentValue = 0.0f;
        s_tweens[idx].isColor = false;
    }
    s_tweens[idx].targetValue = target;
    s_tweens[idx].speed = speed;
    s_tweens[idx].active = true;
}

float GetTweenedFloat(const char* id) {
    int idx = FindTween(id);
    if (idx == -1) {
        return 0.0f;
    }
    return s_tweens[idx].currentValue;
}

void TweenColor(const char* id, ImColor target, float speed) {
    int idx = FindTween(id);
    if (idx == -1) {
        if (s_tweenCount >= 32) {
            return;
        }
        idx = s_tweenCount;
        s_tweenCount++;
        strncpy(s_tweens[idx].id, id, 63);
        s_tweens[idx].id[63] = '\0';
        s_tweens[idx].currentColor = ImColor(0.0f, 0.0f, 0.0f, 0.0f);
        s_tweens[idx].isColor = true;
    }
    s_tweens[idx].targetColor = target;
    s_tweens[idx].speed = speed;
    s_tweens[idx].active = true;
}

ImColor GetTweenedColor(const char* id) {
    int idx = FindTween(id);
    if (idx == -1) {
        return ImColor(0.0f, 0.0f, 0.0f, 0.0f);
    }
    return s_tweens[idx].currentColor;
}

void UpdateTweens(float dt) {
    for (int i = 0; i < s_tweenCount; i++) {
        if (!s_tweens[i].active) {
            continue;
        }
        if (s_tweens[i].isColor) {
            float dx = s_tweens[i].targetColor.Value.x - s_tweens[i].currentColor.Value.x;
            if (fabsf(dx) > 0.001f) {
                s_tweens[i].currentColor.Value.x += dx * s_tweens[i].speed * dt;
            } else {
                s_tweens[i].currentColor.Value.x = s_tweens[i].targetColor.Value.x;
            }
            float dy = s_tweens[i].targetColor.Value.y - s_tweens[i].currentColor.Value.y;
            if (fabsf(dy) > 0.001f) {
                s_tweens[i].currentColor.Value.y += dy * s_tweens[i].speed * dt;
            } else {
                s_tweens[i].currentColor.Value.y = s_tweens[i].targetColor.Value.y;
            }
            float dz = s_tweens[i].targetColor.Value.z - s_tweens[i].currentColor.Value.z;
            if (fabsf(dz) > 0.001f) {
                s_tweens[i].currentColor.Value.z += dz * s_tweens[i].speed * dt;
            } else {
                s_tweens[i].currentColor.Value.z = s_tweens[i].targetColor.Value.z;
            }
            float dw = s_tweens[i].targetColor.Value.w - s_tweens[i].currentColor.Value.w;
            if (fabsf(dw) > 0.001f) {
                s_tweens[i].currentColor.Value.w += dw * s_tweens[i].speed * dt;
            } else {
                s_tweens[i].currentColor.Value.w = s_tweens[i].targetColor.Value.w;
            }
        } else {
            float diff = s_tweens[i].targetValue - s_tweens[i].currentValue;
            if (fabsf(diff) > 0.001f) {
                s_tweens[i].currentValue += diff * s_tweens[i].speed * dt;
            } else {
                s_tweens[i].currentValue = s_tweens[i].targetValue;
                s_tweens[i].active = false;
            }
        }
    }
}

Sequencer::Sequencer() {
    stepCount = 0;
    currentStep = 0;
    stepTime = 0.0f;
    playing = false;
    loop = false;
}

void Sequencer::AddStep(float dur, int ease, float(*get)(), void(*set)(), float end) {
    if (stepCount >= 32) {
        return;
    }
    steps[stepCount].duration = dur;
    steps[stepCount].easingType = ease;
    steps[stepCount].getValue = get;
    steps[stepCount].setValue = set;
    steps[stepCount].endVal = end;
    stepCount++;
}

void Sequencer::Play() {
    if (stepCount == 0) {
        return;
    }
    playing = true;
    currentStep = 0;
    stepTime = 0.0f;
    for (int i = 0; i < stepCount; i++) {
        if (steps[i].getValue) {
            steps[i].startVal = steps[i].getValue();
        } else {
            steps[i].startVal = 0.0f;
        }
    }
}

void Sequencer::Stop() {
    playing = false;
    currentStep = 0;
    stepTime = 0.0f;
}

void Sequencer::Update(float dt) {
    if (!playing) {
        return;
    }
    if (currentStep >= stepCount) {
        if (loop) {
            currentStep = 0;
            stepTime = 0.0f;
            for (int i = 0; i < stepCount; i++) {
                if (steps[i].getValue) {
                    steps[i].startVal = steps[i].getValue();
                } else {
                    steps[i].startVal = 0.0f;
                }
            }
        } else {
            playing = false;
            return;
        }
    }
    Step& step = steps[currentStep];
    stepTime += dt;
    float progress = stepTime / step.duration;
    if (progress > 1.0f) {
        progress = 1.0f;
    }
    float eased = ApplyEasing(progress, step.easingType);
    float value = step.startVal + (step.endVal - step.startVal) * eased;
    if (step.setValue) {
        step.setValue(value);
    }
    if (progress >= 1.0f) {
        currentStep++;
        stepTime = 0.0f;
    }
}

float Sequencer::GetCurrentValue() {
    if (currentStep < stepCount) {
        Step& step = steps[currentStep];
        float progress = stepTime / step.duration;
        if (progress > 1.0f) {
            progress = 1.0f;
        }
        float eased = ApplyEasing(progress, step.easingType);
        return step.startVal + (step.endVal - step.startVal) * eased;
    }
    return 0.0f;
}
