#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "../../Config.h"
#include "../../../imgui/imgui.h"
#include "../../../imgui/imgui_internal.h"
#include <string.h>

static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }

extern Config g_Cfg;
extern Toggles g_Tog;

#define NOTIF_MAX_TEXT   128
#define NOTIF_MAX_SLOTS  16
#define NOTIF_MAX_DISPLAY 8

struct Notification {
    char text[NOTIF_MAX_TEXT];
    ImColor color;
    float life;
    float maxLife;
    float slideOffset;
    bool active;
    int type;
    int lastPushFrame;
};

static Notification s_notifs[NOTIF_MAX_SLOTS];
static int s_notifCount = 0;
static int s_pushFrameCounter = 0;

static float easeOutBack(float t) {
    float c1 = 1.70158f;
    float c3 = c1 + 1.0f;
    return 1.0f + c3 * powf(t - 1.0f, 3.0f) + c1 * powf(t - 1.0f, 2.0f);
}

static float easeInCubic(float t) {
    return t * t * t;
}

static ImColor GetTypeColor(int type) {
    switch (type) {
        case 0: return ImColor(0, 150, 255);
        case 1: return ImColor(0, 200, 80);
        case 2: return ImColor(255, 200, 0);
        case 3: return ImColor(255, 50, 50);
        default: return ImColor(0, 150, 255);
    }
}

static const char* GetTypeIcon(int type) {
    switch (type) {
        case 0: return "i";
        case 1: return "V";
        case 2: return "!";
        case 3: return "X";
        default: return "i";
    }
}

void PushNotification(const char* text, ImColor color, float duration, int type) {
    if (!text) return;
    if (duration <= 0.0f) duration = 3.0f;

    s_pushFrameCounter++;

    for (int i = 0; i < NOTIF_MAX_SLOTS; i++) {
        if (s_notifs[i].active && s_notifs[i].type == type &&
            strncmp(s_notifs[i].text, text, sizeof(s_notifs[i].text)) == 0) {
            s_notifs[i].life = duration;
            s_notifs[i].maxLife = duration;
            s_notifs[i].color = color;
            return;
        }
    }

    int slot = -1;
    for (int i = 0; i < NOTIF_MAX_SLOTS; i++) {
        if (!s_notifs[i].active) {
            slot = i;
            break;
        }
    }
    if (slot == -1) {
        int oldest = 0;
        float oldestLife = s_notifs[0].life;
        for (int i = 1; i < NOTIF_MAX_SLOTS; i++) {
            if (s_notifs[i].life < oldestLife) {
                oldestLife = s_notifs[i].life;
                oldest = i;
            }
        }
        slot = oldest;
    }

    strncpy(s_notifs[slot].text, text, sizeof(s_notifs[slot].text) - 1);
    s_notifs[slot].text[sizeof(s_notifs[slot].text) - 1] = '\0';
    s_notifs[slot].color = color;
    s_notifs[slot].life = duration;
    s_notifs[slot].maxLife = duration;
    s_notifs[slot].slideOffset = -200.0f;
    s_notifs[slot].active = true;
    s_notifs[slot].type = type;
    s_notifs[slot].lastPushFrame = s_pushFrameCounter;

    int activeCount = 0;
    for (int i = 0; i < NOTIF_MAX_SLOTS; i++) {
        if (s_notifs[i].active) activeCount++;
    }
    if (slot >= s_notifCount) s_notifCount = slot + 1;
    if (s_notifCount > NOTIF_MAX_SLOTS) s_notifCount = NOTIF_MAX_SLOTS;
}

static void UpdateNotificationSlide(Notification* n, float dt) {
    float targetOffset = 12.0f;
    if (n->life > n->maxLife - 0.4f && n->life <= n->maxLife) {
        targetOffset = 12.0f;
    } else if (n->life <= 0.5f) {
        targetOffset = -300.0f;
    }
    float speed = 8.0f;
    n->slideOffset += (targetOffset - n->slideOffset) * dt * speed;
    if (n->slideOffset != n->slideOffset) n->slideOffset = 12.0f;
}

void DrawNotifications(ImDrawList* dl, float dt) {
    ImVec2 screenSize = ImGui::GetIO().DisplaySize;
    float baseY = 60.0f;
    float notifHeight = 44.0f;
    float spacing = 8.0f;
    ImFont* font = ImGui::GetIO().Fonts->Fonts[0];
    int displayed = 0;
    for (int i = 0; i < NOTIF_MAX_SLOTS && displayed < NOTIF_MAX_DISPLAY; i++) {
        if (!s_notifs[i].active) continue;
        displayed++;
        Notification* n = &s_notifs[i];
        n->life -= dt;
        UpdateNotificationSlide(n, dt);
        float alpha = 1.0f;
        if (n->life <= 0.5f) {
            alpha = (n->life / 0.5f);
        } else if (n->life > n->maxLife - 0.4f) {
            alpha = 1.0f - ((n->maxLife - n->life) / 0.4f);
            if (alpha < 0.1f) alpha = 0.1f;
        }
        if (alpha < 0.0f) alpha = 0.0f;
        if (alpha > 1.0f) alpha = 1.0f;
        float yPos = baseY + (float)(displayed - 1) * (notifHeight + spacing);
        float xPos = n->slideOffset;
        ImVec2 notifPos(xPos, yPos);
        ImVec2 textSize = ImGui::CalcTextSize(n->text);
        float notifWidth = textSize.x + 48.0f;
        float notifMinWidth = 200.0f;
        if (notifWidth < notifMinWidth) notifWidth = notifMinWidth;
        ImVec2 notifEnd(xPos + notifWidth, yPos + notifHeight);
        ImColor bgCol(10, 10, 20, (int)(200 * alpha));
        dl->AddRectFilled(notifPos, notifEnd, C(bgCol), 8.0f);
        ImColor borderCol(40, 40, 60, (int)(80 * alpha));
        dl->AddRect(notifPos, notifEnd, C(borderCol), 8.0f, 0, 1.0f);
        ImColor accentBar = GetTypeColor(n->type);
        ImColor accentBarAlpha = ImColor(accentBar.Value.x, accentBar.Value.y, accentBar.Value.z, (int)(255 * alpha));
        dl->AddRectFilled(notifPos, ImVec2(xPos + 4.0f, yPos + notifHeight), C(accentBarAlpha), 8.0f);
        float iconSize = 16.0f;
        ImVec2 iconPos(xPos + 12.0f, yPos + (notifHeight - iconSize) * 0.5f);
        dl->AddText(font, iconSize, iconPos, C(accentBarAlpha), GetTypeIcon(n->type));
        ImColor textCol(255, 255, 255, (int)(255 * alpha));
        dl->AddText(font, 13.0f, ImVec2(xPos + 34.0f, yPos + (notifHeight - 13.0f) * 0.5f), C(textCol), n->text);
        float barWidth = notifWidth - 8.0f;
        float barHeight = 2.0f;
        float barX = xPos + 4.0f;
        float barY = yPos + notifHeight - barHeight - 2.0f;
        ImColor barBg(40, 40, 50, (int)(100 * alpha));
        dl->AddRectFilled(ImVec2(barX, barY), ImVec2(barX + barWidth, barY + barHeight), C(barBg), 1.0f);
        float lifeFrac = (n->maxLife > 0.0f) ? (n->life / n->maxLife) : 0.0f;
        if (lifeFrac < 0.0f) lifeFrac = 0.0f;
        if (lifeFrac > 1.0f) lifeFrac = 1.0f;
        ImColor barFgColor = GetTypeColor(n->type);
        ImColor barFg = ImColor(barFgColor.Value.x, barFgColor.Value.y, barFgColor.Value.z, (int)(200 * alpha));
        dl->AddRectFilled(ImVec2(barX, barY), ImVec2(barX + barWidth * lifeFrac, barY + barHeight), C(barFg), 1.0f);
        if (n->life <= 0.0f) {
            n->active = false;
            n->slideOffset = -300.0f;
        }
    }
    int activeCount = 0;
    for (int i = 0; i < NOTIF_MAX_SLOTS; i++) {
        if (s_notifs[i].active) activeCount++;
    }
    s_notifCount = activeCount;
}

void ClearNotifications() {
    for (int i = 0; i < NOTIF_MAX_SLOTS; i++) {
        s_notifs[i].active = false;
        s_notifs[i].slideOffset = -300.0f;
        s_notifs[i].life = 0.0f;
        s_notifs[i].maxLife = 0.0f;
        s_notifs[i].text[0] = '\0';
        s_notifs[i].type = 0;
    }
    s_notifCount = 0;
}

int GetNotificationCount() {
    int count = 0;
    for (int i = 0; i < NOTIF_MAX_SLOTS; i++) {
        if (s_notifs[i].active) count++;
    }
    return count;
}

void PushInfo(const char* text, float duration) {
    PushNotification(text, ImColor(0, 150, 255), duration, 0);
}

void PushSuccess(const char* text, float duration) {
    PushNotification(text, ImColor(0, 200, 80), duration, 1);
}

void PushWarning(const char* text, float duration) {
    PushNotification(text, ImColor(255, 200, 0), duration, 2);
}

void PushError(const char* text, float duration) {
    PushNotification(text, ImColor(255, 50, 50), duration, 3);
}

static float s_notifGlobalAlpha = 1.0f;

void SetNotificationGlobalAlpha(float alpha) {
    if (alpha < 0.0f) alpha = 0.0f;
    if (alpha > 1.0f) alpha = 1.0f;
    s_notifGlobalAlpha = alpha;
}

void DrawNotificationsQueued(ImDrawList* dl, float dt, int maxDisplay) {
    if (maxDisplay <= 0) maxDisplay = NOTIF_MAX_DISPLAY;
    if (maxDisplay > NOTIF_MAX_DISPLAY) maxDisplay = NOTIF_MAX_DISPLAY;
    ImVec2 screenSize = ImGui::GetIO().DisplaySize;
    float baseY = 60.0f;
    float notifHeight = 44.0f;
    float spacing = 8.0f;
    ImFont* font = ImGui::GetIO().Fonts->Fonts[0];
    int displayed = 0;
    for (int i = 0; i < NOTIF_MAX_SLOTS; i++) {
        if (!s_notifs[i].active) continue;
        if (displayed >= maxDisplay) {
            continue;
        }
        displayed++;
        Notification* n = &s_notifs[i];
        n->life -= dt;
        UpdateNotificationSlide(n, dt);
        float alpha = 1.0f * s_notifGlobalAlpha;
        if (n->life <= 0.5f) {
            alpha = (n->life / 0.5f) * s_notifGlobalAlpha;
        } else if (n->life > n->maxLife - 0.4f) {
            alpha = (1.0f - ((n->maxLife - n->life) / 0.4f)) * s_notifGlobalAlpha;
            if (alpha < 0.1f * s_notifGlobalAlpha) alpha = 0.1f * s_notifGlobalAlpha;
        }
        if (alpha < 0.0f) alpha = 0.0f;
        if (alpha > 1.0f) alpha = 1.0f;
        float yPos = baseY + (float)(displayed - 1) * (notifHeight + spacing);
        float xPos = n->slideOffset;
        ImVec2 notifPos(xPos, yPos);
        ImVec2 textSize = ImGui::CalcTextSize(n->text);
        float notifWidth = textSize.x + 48.0f;
        float notifMinWidth = 200.0f;
        if (notifWidth < notifMinWidth) notifWidth = notifMinWidth;
        ImVec2 notifEnd(xPos + notifWidth, yPos + notifHeight);
        ImColor bgCol(10, 10, 20, (int)(200 * alpha));
        dl->AddRectFilled(notifPos, notifEnd, C(bgCol), 8.0f);
        ImColor borderCol(40, 40, 60, (int)(80 * alpha));
        dl->AddRect(notifPos, notifEnd, C(borderCol), 8.0f, 0, 1.0f);
        ImColor accentBar = GetTypeColor(n->type);
        ImColor accentBarAlpha = ImColor(accentBar.Value.x, accentBar.Value.y, accentBar.Value.z, (int)(255 * alpha));
        dl->AddRectFilled(notifPos, ImVec2(xPos + 4.0f, yPos + notifHeight), C(accentBarAlpha), 8.0f);
        float iconSize = 16.0f;
        ImVec2 iconPos(xPos + 12.0f, yPos + (notifHeight - iconSize) * 0.5f);
        dl->AddText(font, iconSize, iconPos, C(accentBarAlpha), GetTypeIcon(n->type));
        ImColor textCol(255, 255, 255, (int)(255 * alpha));
        dl->AddText(font, 13.0f, ImVec2(xPos + 34.0f, yPos + (notifHeight - 13.0f) * 0.5f), C(textCol), n->text);
        float barWidth = notifWidth - 8.0f;
        float barHeight = 2.0f;
        float barX = xPos + 4.0f;
        float barY = yPos + notifHeight - barHeight - 2.0f;
        ImColor barBg(40, 40, 50, (int)(100 * alpha));
        dl->AddRectFilled(ImVec2(barX, barY), ImVec2(barX + barWidth, barY + barHeight), C(barBg), 1.0f);
        float lifeFrac = (n->maxLife > 0.0f) ? (n->life / n->maxLife) : 0.0f;
        if (lifeFrac < 0.0f) lifeFrac = 0.0f;
        if (lifeFrac > 1.0f) lifeFrac = 1.0f;
        ImColor barFgColor = GetTypeColor(n->type);
        ImColor barFg = ImColor(barFgColor.Value.x, barFgColor.Value.y, barFgColor.Value.z, (int)(200 * alpha));
        dl->AddRectFilled(ImVec2(barX, barY), ImVec2(barX + barWidth * lifeFrac, barY + barHeight), C(barFg), 1.0f);
        if (n->life <= 0.0f) {
            n->active = false;
            n->slideOffset = -300.0f;
        }
    }
}
