#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "../../Config.h"
#include "../../../imgui/imgui.h"
#include "../../../imgui/imgui_internal.h"
#include <math.h>

static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }

extern Config g_Cfg;
extern Toggles g_Tog;

static float s_displayAngle = 0.0f;
static float s_prevPlayerAngle = 0.0f;
static bool s_wasHidden = true;

static const char* s_cardinalDirs[] = { "N", "NE", "E", "SE", "S", "SW", "W", "NW" };
static const float s_cardinalAngles[] = { 0.0f, 45.0f, 90.0f, 135.0f, 180.0f, 225.0f, 270.0f, 315.0f };

static float NormalizeAngleDiff(float diff) {
    while (diff > 180.0f) diff -= 360.0f;
    while (diff < -180.0f) diff += 360.0f;
    return diff;
}

void DrawCompass(ImDrawList* dl, float playerAngle) {
    if (!g_Tog.ShowCompass) {
        s_wasHidden = true;
        return;
    }
    if (s_wasHidden) {
        s_displayAngle = playerAngle;
        s_prevPlayerAngle = playerAngle;
        s_wasHidden = false;
    }
    ImVec2 screenSize = ImGui::GetIO().DisplaySize;
    float compassWidth = screenSize.x * 0.5f;
    if (compassWidth > 400.0f) compassWidth = 400.0f;
    float compassHeight = 32.0f;
    float compassX = (screenSize.x - compassWidth) * 0.5f;
    float compassY = 6.0f;
    float dt = ImGui::GetIO().DeltaTime;
    if (dt > 0.1f) dt = 0.033f;
    float diff = NormalizeAngleDiff(playerAngle - s_displayAngle);
    float lerpSpeed = 8.0f;
    s_displayAngle += diff * lerpSpeed * dt;
    s_displayAngle = fmodf(s_displayAngle, 360.0f);
    if (s_displayAngle < 0.0f) s_displayAngle += 360.0f;
    s_prevPlayerAngle = playerAngle;
    ImVec2 compassPos(compassX, compassY);
    ImVec2 compassEnd(compassX + compassWidth, compassY + compassHeight);
    float alpha = 1.0f;
    ImColor bgCol(5, 5, 15, (int)(180 * alpha));
    dl->AddRectFilled(compassPos, compassEnd, C(bgCol), 4.0f);
    ImColor borderCol(40, 40, 60, (int)(100 * alpha));
    dl->AddRect(compassPos, compassEnd, C(borderCol), 4.0f, 0, 1.0f);
    ImFont* font = ImGui::GetIO().Fonts->Fonts[0];
    if (!font) return;
    float halfWidth = compassWidth * 0.5f;
    float pixelsPerDeg = compassWidth / 60.0f;
    float centerAngle = s_displayAngle;
    for (int deg = -30; deg <= 30; deg++) {
        float relAngle = (float)deg;
        float screenX = halfWidth + relAngle * pixelsPerDeg;
        if (screenX < 0.0f || screenX > compassWidth) continue;
        float tickX = compassX + screenX;
        bool isTen = (deg % 10 == 0);
        bool isThirty = (deg % 30 == 0) && (deg != 0);
        bool isCenter = (deg == 0);
        if (isCenter || isThirty || isTen) {
            float tickHeight = isCenter ? 10.0f : (isThirty ? 8.0f : 4.0f);
            float tickY = compassY + compassHeight - 6.0f;
            ImU32 tickCol;
            if (isCenter) tickCol = C(ImColor(255, 255, 255, (int)(180 * alpha)));
            else tickCol = C(ImColor(100, 100, 130, (int)(100 * alpha)));
            dl->AddLine(ImVec2(tickX, tickY), ImVec2(tickX, tickY + tickHeight), tickCol, isCenter ? 2.0f : 1.0f);
            if (isThirty || isCenter) {
                int displayDeg = (int)centerAngle + deg;
                if (displayDeg < 0) displayDeg += 360;
                if (displayDeg >= 360) displayDeg -= 360;
                char numBuf[8];
                snprintf(numBuf, sizeof(numBuf), "%d", displayDeg);
                ImU32 numCol = isCenter ? C(ImColor(255, 255, 255, (int)(200 * alpha))) : C(ImColor(130, 130, 160, (int)(120 * alpha)));
                dl->AddText(font, 7.0f, ImVec2(tickX - 7.0f, tickY - 10.0f), numCol, numBuf);
            }
        }
    }
    for (int d = 0; d < 8; d++) {
        float angleDeg = s_cardinalAngles[d];
        float relAngle = NormalizeAngleDiff(angleDeg - s_displayAngle);
        float screenX = halfWidth + relAngle * pixelsPerDeg;
        if (screenX < -40.0f || screenX > compassWidth + 40.0f) continue;
        float textX = compassX + screenX;
        float textY = compassY + (compassHeight - 14.0f) * 0.5f;
        bool isCardinal = (d % 2 == 0);
        float textSize = isCardinal ? 14.0f : 10.0f;
        bool isPrimary = (d == 0);
        float absRel = fabsf(relAngle);
        ImColor textColor;
        if (absRel < 5.0f) textColor = g_Cfg.AccentColor;
        else if (isPrimary) textColor = ImColor(200, 200, 230, (int)(200 * alpha));
        else textColor = ImColor(160, 160, 190, (int)(150 * alpha));
        char buf[4];
        buf[0] = s_cardinalDirs[d][0];
        buf[1] = s_cardinalDirs[d][1] ? s_cardinalDirs[d][1] : '\0';
        buf[2] = '\0';
        dl->AddText(font, textSize, ImVec2(textX - textSize * 0.3f, textY), C(textColor), buf);
    }
    float triSize = 7.0f;
    float triX = compassX + halfWidth;
    float triY = compassY + compassHeight + 1.0f;
    ImColor triCol = g_Cfg.AccentColor;
    dl->AddTriangleFilled(
        ImVec2(triX, triY + triSize),
        ImVec2(triX - triSize * 0.5f, triY),
        ImVec2(triX + triSize * 0.5f, triY),
        C(triCol)
    );
    dl->AddLine(ImVec2(triX, triY + triSize + 1.0f), ImVec2(triX, triY + triSize + 10.0f), C(triCol), 1.5f);
}

void DrawCompassAt(ImDrawList* dl, float playerAngle, ImVec2 position, float width, float height) {
    if (!g_Tog.ShowCompass) {
        s_wasHidden = true;
        return;
    }
    if (s_wasHidden) {
        s_displayAngle = playerAngle;
        s_prevPlayerAngle = playerAngle;
        s_wasHidden = false;
    }
    float dt = ImGui::GetIO().DeltaTime;
    if (dt > 0.1f) dt = 0.033f;
    float diff = NormalizeAngleDiff(playerAngle - s_displayAngle);
    float lerpSpeed = 8.0f;
    s_displayAngle += diff * lerpSpeed * dt;
    s_displayAngle = fmodf(s_displayAngle, 360.0f);
    if (s_displayAngle < 0.0f) s_displayAngle += 360.0f;
    s_prevPlayerAngle = playerAngle;
    ImVec2 compassPos = position;
    ImVec2 compassEnd(position.x + width, position.y + height);
    float alpha = 1.0f;
    ImColor bgCol(5, 5, 15, (int)(180 * alpha));
    dl->AddRectFilled(compassPos, compassEnd, C(bgCol), 4.0f);
    ImColor borderCol(40, 40, 60, (int)(100 * alpha));
    dl->AddRect(compassPos, compassEnd, C(borderCol), 4.0f, 0, 1.0f);
    ImFont* font = ImGui::GetIO().Fonts->Fonts[0];
    if (!font) return;
    float halfWidth = width * 0.5f;
    float pixelsPerDeg = width / 60.0f;
    float centerAngle = s_displayAngle;
    for (int deg = -30; deg <= 30; deg++) {
        float relAngle = (float)deg;
        float screenX = halfWidth + relAngle * pixelsPerDeg;
        if (screenX < 0.0f || screenX > width) continue;
        float tickX = position.x + screenX;
        bool isTen = (deg % 10 == 0);
        bool isThirty = (deg % 30 == 0) && (deg != 0);
        bool isCenter = (deg == 0);
        if (isCenter || isThirty || isTen) {
            float tickHeight = isCenter ? 10.0f : (isThirty ? 8.0f : 4.0f);
            float tickY = position.y + height - 6.0f;
            ImU32 tickCol;
            if (isCenter) tickCol = C(ImColor(255, 255, 255, (int)(180 * alpha)));
            else tickCol = C(ImColor(100, 100, 130, (int)(100 * alpha)));
            dl->AddLine(ImVec2(tickX, tickY), ImVec2(tickX, tickY + tickHeight), tickCol, isCenter ? 2.0f : 1.0f);
            if (isThirty || isCenter) {
                int displayDeg = (int)centerAngle + deg;
                if (displayDeg < 0) displayDeg += 360;
                if (displayDeg >= 360) displayDeg -= 360;
                char numBuf[8];
                snprintf(numBuf, sizeof(numBuf), "%d", displayDeg);
                ImU32 numCol = isCenter ? C(ImColor(255, 255, 255, (int)(200 * alpha))) : C(ImColor(130, 130, 160, (int)(120 * alpha)));
                dl->AddText(font, 7.0f, ImVec2(tickX - 7.0f, tickY - 10.0f), numCol, numBuf);
            }
        }
    }
    for (int d = 0; d < 8; d++) {
        float angleDeg = s_cardinalAngles[d];
        float relAngle = NormalizeAngleDiff(angleDeg - s_displayAngle);
        float screenX = halfWidth + relAngle * pixelsPerDeg;
        if (screenX < -40.0f || screenX > width + 40.0f) continue;
        float textX = position.x + screenX;
        float textY = position.y + (height - 14.0f) * 0.5f;
        bool isCardinal = (d % 2 == 0);
        float textSize = isCardinal ? 14.0f : 10.0f;
        float absRel = fabsf(relAngle);
        ImColor textColor;
        if (absRel < 5.0f) textColor = g_Cfg.AccentColor;
        else if (d == 0) textColor = ImColor(200, 200, 230, (int)(200 * alpha));
        else textColor = ImColor(160, 160, 190, (int)(150 * alpha));
        char buf[4];
        buf[0] = s_cardinalDirs[d][0];
        buf[1] = s_cardinalDirs[d][1] ? s_cardinalDirs[d][1] : '\0';
        buf[2] = '\0';
        dl->AddText(font, textSize, ImVec2(textX - textSize * 0.3f, textY), C(textColor), buf);
    }
    float triSize = 7.0f;
    float triX = position.x + halfWidth;
    float triY = position.y + height + 1.0f;
    ImColor triCol = g_Cfg.AccentColor;
    dl->AddTriangleFilled(
        ImVec2(triX, triY + triSize),
        ImVec2(triX - triSize * 0.5f, triY),
        ImVec2(triX + triSize * 0.5f, triY),
        C(triCol)
    );
}

void DrawCompassRadial(ImDrawList* dl, float playerAngle, ImVec2 center, float radius) {
    if (!g_Tog.ShowCompass) {
        s_wasHidden = true;
        return;
    }
    if (s_wasHidden) {
        s_displayAngle = playerAngle;
        s_prevPlayerAngle = playerAngle;
        s_wasHidden = false;
    }
    float dt = ImGui::GetIO().DeltaTime;
    if (dt > 0.1f) dt = 0.033f;
    float diff = NormalizeAngleDiff(playerAngle - s_displayAngle);
    float lerpSpeed = 8.0f;
    s_displayAngle += diff * lerpSpeed * dt;
    s_displayAngle = fmodf(s_displayAngle, 360.0f);
    if (s_displayAngle < 0.0f) s_displayAngle += 360.0f;
    s_prevPlayerAngle = playerAngle;
    float alpha = 1.0f;
    ImColor bgCol(5, 5, 15, (int)(180 * alpha));
    dl->AddCircleFilled(center, radius, C(bgCol), 32);
    ImColor borderCol(40, 40, 60, (int)(100 * alpha));
    dl->AddCircle(center, radius, C(borderCol), 32, 1.5f);
    ImFont* font = ImGui::GetIO().Fonts->Fonts[0];
    if (!font) return;
    for (int d = 0; d < 8; d++) {
        float angleDeg = s_cardinalAngles[d];
        float angleRad = angleDeg * 3.14159f / 180.0f;
        angleRad -= s_displayAngle * 3.14159f / 180.0f;
        float labelRadius = radius - 14.0f;
        float lx = center.x + cosf(angleRad) * labelRadius;
        float ly = center.y + sinf(angleRad) * labelRadius;
        bool isCardinal = (d % 2 == 0);
        float textSize = isCardinal ? 13.0f : 9.0f;
        float absDiff = fabsf(NormalizeAngleDiff(angleDeg - s_displayAngle));
        ImColor textColor;
        if (absDiff < 8.0f) textColor = g_Cfg.AccentColor;
        else if (d == 0) textColor = ImColor(200, 200, 230, (int)(200 * alpha));
        else textColor = ImColor(160, 160, 190, (int)(150 * alpha));
        char buf[4];
        buf[0] = s_cardinalDirs[d][0];
        buf[1] = s_cardinalDirs[d][1] ? s_cardinalDirs[d][1] : '\0';
        buf[2] = '\0';
        dl->AddText(font, textSize, ImVec2(lx - textSize * 0.3f, ly - textSize * 0.3f), C(textColor), buf);
    }
    float triSize = 6.0f;
    dl->AddTriangleFilled(
        ImVec2(center.x, center.y - radius + 4.0f),
        ImVec2(center.x - triSize, center.y - radius - triSize),
        ImVec2(center.x + triSize, center.y - radius - triSize),
        C(g_Cfg.AccentColor)
    );
    dl->AddCircleFilled(center, 3.0f, C(ImColor(255, 255, 255, 200)), 12);
}

void ResetCompassAnim() {
    s_displayAngle = 0.0f;
    s_prevPlayerAngle = 0.0f;
    s_wasHidden = false;
}

float GetCompassAnimOffset() {
    return s_displayAngle;
}
