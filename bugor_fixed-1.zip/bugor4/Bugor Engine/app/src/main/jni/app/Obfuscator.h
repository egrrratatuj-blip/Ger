#pragma once
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>
#include <array>
#include <algorithm>
#include <random>
#include <type_traits>
#include <utility>
#include <atomic>
#include <chrono>
#include <thread>
#include <functional>
#if defined(__x86_64__) || defined(__i386__)
#include <immintrin.h>
#elif defined(__aarch64__) || defined(__arm__)
#include <arm_neon.h>
#endif

template<size_t N>
struct EncryptedString {
    char data[N];
    char key[N];
    size_t length;
    EncryptedString(const char (&str)[N]) : data{}, key{}, length(N - 1) {
        for (size_t i = 0; i < N - 1; ++i) {
            key[i] = static_cast<char>(rand() % 256);
            data[i] = str[i] ^ key[i];
        }
        data[N - 1] = 0;
        key[N - 1] = 0;
    }
    std::string decrypt() const {
        std::string result(length, '\0');
        for (size_t i = 0; i < length; ++i) {
            result[i] = data[i] ^ key[i];
        }
        return result;
    }
};

#define OBFUSCATE(str) EncryptedString<sizeof(str)>(str).decrypt()

#define JUNK_CODE_ASM asm volatile("nop\n\t" ::: "memory")
#define JUNK_CODE_LOOP for(volatile int _junk=0;_junk<rand()%10;_junk++)asm volatile("nop")
#define JUNK_BLOCK { volatile int _x = 0xDEADBEEF; volatile int _y = _x ^ 0xCAFEBABE; _x ^= _y; }

#define CONTROL_FLOW_BEGIN volatile int _cf_state = 0;
#define CONTROL_FLOW_CASE(n) case n: _cf_state = (n);
#define CONTROL_FLOW_SWITCH switch(_cf_state) { default: break;
#define CONTROL_FLOW_END }

#define OBFUSCATE_CALL(func) do { \
    volatile uintptr_t _obf_addr = reinterpret_cast<uintptr_t>(&func); \
    _obf_addr ^= 0xA5A5A5A5A5A5A5A5ULL; \
    _obf_addr ^= 0xA5A5A5A5A5A5A5A5ULL; \
    ((void(*)(void))_obf_addr)(); \
} while(0)

#define STACK_SPOOF_BEGIN uintptr_t _spoof_marker = 0xDEADBEEFCAFEBABEULL;
#define STACK_SPOOF_END if (_spoof_marker != 0xDEADBEEFCAFEBABEULL) _exit(-1);

#define HIDE_STRING_LITERAL(s) OBFUSCATE(s)

namespace Obfuscator {

using namespace std::chrono_literals;

class StringEncryptor {
public:
    static std::vector<uint8_t> encrypt(const std::string &input, const std::vector<uint8_t> &key);
    static std::string decrypt(const std::vector<uint8_t> &input, const std::vector<uint8_t> &key);
    static std::vector<uint8_t> generateKey(size_t length);
    static std::vector<uint8_t> xorData(const std::vector<uint8_t> &data, const std::vector<uint8_t> &key);
    static std::vector<uint8_t> aesEncrypt(const std::vector<uint8_t> &data, const std::vector<uint8_t> &key);
    static std::vector<uint8_t> aesDecrypt(const std::vector<uint8_t> &data, const std::vector<uint8_t> &key);
    static std::string encodeBase64(const std::vector<uint8_t> &data);
    static std::vector<uint8_t> decodeBase64(const std::string &encoded);
    static uint32_t crc32(const uint8_t *data, size_t length);
    static uint64_t xxhash64(const uint8_t *data, size_t length);
};

class ControlFlowFlattener {
public:
    static void flatten(void *func, size_t size);
    static void addJunkBlocks(void *func, size_t size);
    static void opaquePredicate(void *func, size_t size);
    static void splitBasicBlocks(void *func, size_t size);
    static void randomizeRegister(void *func, size_t size);
    static void insertGarbage(void *func, size_t size);
    static void corruptUnusedCode(void *func, size_t size);
    static void redistributeBlocks(void *func, size_t size);
};

class JunkCodeGenerator {
public:
    static void emitNopSled(size_t count);
    static void emitDeadCode();
    static void emitOpaquePredicate();
    static void emitJunkLoop();
    static void emitMeaninglessArithmetic();
    static void emitFakeFunctionCall();
    static void emitJunkCall();
    static void emitGarbageLoad();
    static void emitStackCorruption();
    static void emitFakeBranch();
};

class AntiAnalysis {
public:
    static bool isDebuggerPresent();
    static bool isEmulator();
    static bool isHooked();
    static bool checkTracerPid();
    static bool checkBreakpoints();
    static bool checkTiming();
    static bool checkDebugPort();
    static bool checkVendor();
    static bool checkQemuBreakpoints();
    static bool checkProfiler();
    static bool checkSyscallHooks();
    static bool checkInlineHooks();
    static bool checkLibraryHooks();
    static void spoofReturnAddress();
    static void hideFromDebugger();
    static void antiPtrace();
    static void antiFork();
    static void antiDump();
    static void integrityCheck();
    static void selfModify();
};

extern "C" char integrityCheckEnd();

class StackSpoofer {
public:
    static void spoofStack();
    static void restoreStack();
    static void randomizeStackFrame();
    static void hideReturnAddress();
    static void corruptBacktrace();
    static void fakeCaller();
    static void modifyLinkRegister();
    static void pushFakeFrame();
    static void popFakeFrame();
    static void obfuscateReturnAddress();
};

class ConstantObfuscator {
public:
    template<typename T>
    static T obfuscate(T value) {
        static_assert(std::is_arithmetic_v<T>, "Must be arithmetic type");
        T key = static_cast<T>(rand());
        T encoded = value ^ key;
        return encoded;
    }

    template<typename T>
    static T deobfuscate(T encoded, T key) {
        return encoded ^ key;
    }

    static uint64_t obfuscate64(uint64_t value, uint64_t key);
    static uint64_t deobfuscate64(uint64_t encoded, uint64_t key);
    static uint32_t obfuscate32(uint32_t value, uint32_t key);
    static uint32_t deobfuscate32(uint32_t encoded, uint32_t key);
    static float obfuscateFloat(float value, float key);
    static float deobfuscateFloat(float encoded, float key);
    static double obfuscateDouble(double value, double key);
    static double deobfuscateDouble(double encoded, double key);

    template<typename T, T Key>
    class ObfuscatedValue {
        T encoded;
    public:
        ObfuscatedValue() : encoded(obfuscateStatic<T, Key>(T{})) {}
        explicit ObfuscatedValue(T value) : encoded(obfuscateStatic<T, Key>(value)) {}
        T get() const { return deobfuscateStatic<T, Key>(encoded); }
        void set(T value) { encoded = obfuscateStatic<T, Key>(value); }
        ObfuscatedValue& operator=(T value) { set(value); return *this; }
        operator T() const { return get(); }
        T operator+(T other) const { return get() + other; }
        T operator-(T other) const { return get() - other; }
        T operator*(T other) const { return get() * other; }
        T operator/(T other) const { return get() / other; }
        bool operator==(T other) const { return get() == other; }
        bool operator!=(T other) const { return get() != other; }
        bool operator<(T other) const { return get() < other; }
        bool operator>(T other) const { return get() > other; }
        bool operator<=(T other) const { return get() <= other; }
        bool operator>=(T other) const { return get() >= other; }
    private:
        template<typename U, U K>
        static U obfuscateStatic(U val) {
            return val ^ K;
        }
        template<typename U, U K>
        static U deobfuscateStatic(U enc) {
            return enc ^ K;
        }
    };
};

class MemoryObfuscator {
public:
    static void encryptRegion(void *addr, size_t size);
    static void decryptRegion(void *addr, size_t size);
    static void scrambleMemory(void *addr, size_t size);
    static void clearSecureMemory(void *addr, size_t size);
    static bool verifyMemoryIntegrity(void *addr, size_t size, uint64_t expectedHash);
    static void xorMemory(void *addr, size_t size, uint8_t key);
    static void shuffleMemory(void *addr, size_t size);
    static void corruptPointers(void *addr, size_t size);
    static void restorePointers(void *addr, size_t size, uintptr_t base);
    static void hideAllocation(void *addr, size_t size);
    static void protectMemoryRegion(void *addr, size_t size);
    static void randomizeMemoryLayout(void *addr, size_t size);
};

class InstructionObfuscator {
public:
    static void replaceInstruction(void *addr, const uint8_t *newInstr, size_t size);
    static void insertTrap(void *addr);
    static void insertJunkBytes(void *addr, size_t size);
    static void splitInstruction(void *addr, size_t size);
    static void expandInstruction(void *addr, size_t size);
    static void mergeInstructions(void *addr, size_t size);
    static void randomizeInstructionOrder(void *addr, size_t size);
    static void substituteInstruction(void *addr, size_t size);
    static void insertDeadCode(void *addr, size_t size);
};

class AntiHookObfuscator {
public:
    static bool detectGOTHook(const char *libName, const char *funcName);
    static bool detectPLTHook(const char *libName, const char *funcName);
    static bool detectInlineHook(void *funcAddr);
    static bool detectTrampoline(void *addr);
    static void repairGOT(const char *libName);
    static void repairPLT(const char *libName);
    static void validateImportTable();
    static void checkSectionHashes();
    static void verifyCodeIntegrity();
    static void detectDebuggerBreakpoints();
    static void checkGOTIntegrity();
    static void checkPLTIntegrity();
    static void checkIATIntegrity();
    static void detectSubstrate();
    static void detectCydia();
    static void detectFrida();
    static void detectXposed();
    static void shieldGOT();
    static void encryptGOT();
};

class PolymorphicEngine {
public:
    static std::vector<uint8_t> generateVariant(const std::vector<uint8_t> &code);
    static void mutateCode(void *addr, size_t size);
    static void transformLoop(void *addr, size_t size);
    static void inlineFunction(void *target, void *replacement);
    static void outlineFunction(void *addr, size_t size);
    static void reassembleBlock(void *addr, size_t size);
    static void duplicateBlock(void *addr, size_t size);
    static void mergeBlocks(void *addr, size_t size);
    static void splitBlock(void *addr, size_t size);
    static void shuffleBlocks(void *addr, size_t size);
    static void insertTrampoline(void *from, void *to);
};

class AntiTamper {
public:
    static void calculateHash(const uint8_t *data, size_t size, uint8_t *hash);
    static bool verifyHash(const uint8_t *data, size_t size, const uint8_t *expectedHash);
    static void checksumRegion(void *addr, size_t size);
    static bool verifyRegion(void *addr, size_t size, uint32_t expected);
    static void integrityThread();
    static void startIntegrityMonitor();
    static void stopIntegrityMonitor();
    static void encryptStrings();
    static void decryptStrings();
    static bool isModified();
    static void selfRepair();
    static void dumpProtection();
    static void preventMemoryDump();
};

using ObfInt32 = ConstantObfuscator::ObfuscatedValue<int32_t, 0x7A3B5C1D>;
using ObfInt64 = ConstantObfuscator::ObfuscatedValue<int64_t, (int64_t)0x9F2A4C8E6B1D3F07LL>;
using ObfFloat = ConstantObfuscator::ObfuscatedValue<uint32_t, 0x5C8A3B2F>;
using ObfDouble = ConstantObfuscator::ObfuscatedValue<uint64_t, 0x8A3B5C1D9F2A4C8EULL>;
using ObfUint32 = ConstantObfuscator::ObfuscatedValue<uint32_t, 0xD5E8F3A2>;
using ObfUint64 = ConstantObfuscator::ObfuscatedValue<uint64_t, 0xB7C1D3E5F8A2B4C6ULL>;

}

#define OBF_BEGIN asm volatile("mov x0, x0\n\tmov x1, x1\n\tnop" ::: "x0","x1")
#define OBF_END asm volatile("nop\n\tnop\n\tnop" ::: "memory")
#define OBF_START OBF_BEGIN; JUNK_CODE_LOOP
#define OBF_FINISH JUNK_BLOCK; OBF_END

#define ANTI_DEBUG_BLOCK if(Obfuscator::AntiAnalysis::isDebuggerPresent()) _exit(-1)
#define ANTI_HOOK_CHECK Obfuscator::AntiHookObfuscator::detectInlineHook
#define ANTI_TAMPER_CHECK Obfuscator::AntiTamper::verifyRegion

#define ENCRYPTED_STRING(s) Obfuscator::StringEncryptor::encrypt(std::string(s), \
    Obfuscator::StringEncryptor::generateKey(32)).data()

#define OBFUSCATED_CALL(fn, args...) do { \
    volatile uintptr_t _fn = (uintptr_t)fn; \
    _fn ^= 0xA1B2C3D4E5F6A7B8ULL; \
    _fn ^= 0xA1B2C3D4E5F6A7B8ULL; \
    typedef void (*fn_t)(##args); \
    ((fn_t)_fn)(##args); \
} while(0)

#define FAKE_JUMP_TABLE(name) static uintptr_t name[] = { \
    0xDEADBEEF, 0xCAFEBABE, 0xBAADF00D, 0xFEEDFACE, \
    0xDEADCODE, 0xCAFED00D, 0xABADBABE, 0xDEADC0DE \
}
