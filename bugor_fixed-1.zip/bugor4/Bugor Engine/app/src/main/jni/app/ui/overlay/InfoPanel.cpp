#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "../../Config.h"
#include "../../../imgui/imgui.h"
#include "../../../imgui/imgui_internal.h"
#include "../../ESP.h"
#include "../../Aimbot.h"

static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }

extern Config g_Cfg;
extern Toggles g_Tog;
extern ESP g_Esp;
extern Aimbot g_Bot;
extern GameOffsets g_Offsets;

static float s_slideOffset = 180.0f;
static int s_lastTargetID = -1;
static float s_targetChangeAnim = 0.0f;
static float s_infoAlpha = 0.0f;
static char s_lastTargetName[128] = {0};

static float easeOutCubic(float t) {
    float v = t - 1.0f;
    return v * v * v + 1.0f;
}

static float easeInCubic(float t) {
    return t * t * t;
}

static ImColor GetHealthColor(float hp, float maxHp) {
    float ratio = hp / maxHp;
    if (ratio > 0.6f) return ImColor(0, 200, 80);
    if (ratio > 0.3f) return ImColor(255, 200, 0);
    return ImColor(255, 50, 50);
}

static ImVec2 CheckDisplaySize() {
    ImVec2 sz = ImGui::GetIO().DisplaySize;
    if (sz.x < 1.0f) sz.x = 1.0f;
    if (sz.y < 1.0f) sz.y = 1.0f;
    return sz;
}

void DrawInfoPanel(ImDrawList* dl, float dt) {
    if (!g_Tog.ShowInfo) {
        s_slideOffset += (200.0f - s_slideOffset) * dt * 6.0f;
        if (s_slideOffset > 195.0f) s_slideOffset = 200.0f;
        s_infoAlpha -= dt * 4.0f;
        if (s_infoAlpha < 0.0f) s_infoAlpha = 0.0f;
        return;
    }
    bool hasTarget = g_Bot.IsLocked && g_Bot.BestTarget.Index >= 0;
    int currentTargetID = hasTarget ? g_Bot.BestTarget.Index : -1;
    if (currentTargetID != s_lastTargetID) {
        s_lastTargetID = currentTargetID;
        s_targetChangeAnim = 0.0f;
        if (hasTarget && currentTargetID >= 0 && currentTargetID < g_Esp.PlayerCount) {
            strncpy(s_lastTargetName, g_Esp.Players[currentTargetID].PlayerName, sizeof(s_lastTargetName) - 1);
            s_lastTargetName[sizeof(s_lastTargetName) - 1] = '\0';
        } else {
            s_lastTargetName[0] = '\0';
        }
    }
    if (hasTarget) {
        s_slideOffset += (0.0f - s_slideOffset) * dt * 4.0f;
        if (s_slideOffset < 0.5f) s_slideOffset = 0.0f;
        s_infoAlpha += dt * 4.0f;
        if (s_infoAlpha > 1.0f) s_infoAlpha = 1.0f;
        s_targetChangeAnim += dt;
        if (s_targetChangeAnim > 0.3f) s_targetChangeAnim = 0.3f;
    } else {
        s_slideOffset += (200.0f - s_slideOffset) * dt * 6.0f;
        if (s_slideOffset > 195.0f) s_slideOffset = 200.0f;
        s_infoAlpha -= dt * 4.0f;
        if (s_infoAlpha < 0.0f) s_infoAlpha = 0.0f;
    }
    if (s_slideOffset > 190.0f && s_infoAlpha < 0.01f) return;
    ImVec2 screenSize = CheckDisplaySize();
    float panelWidth = 180.0f;
    float panelX = screenSize.x - panelWidth - s_slideOffset;
    float panelY = 10.0f;
    ImFont* font = ImGui::GetIO().Fonts->Fonts[0];
    float currentY = panelY + 8.0f;
    float lineHeight = 18.0f;
    float smallLine = 14.0f;
    float padding = 8.0f;
    if (hasTarget && currentTargetID >= 0 && currentTargetID < g_Esp.PlayerCount) {
        PlayerData* target = &g_Esp.Players[currentTargetID];
        float nameWidth = ImGui::CalcTextSize(s_lastTargetName).x + 24.0f;
        if (nameWidth > panelWidth) panelWidth = nameWidth;
        float contentHeight = 8.0f + 20.0f + 6.0f + lineHeight * 6.0f + 8.0f;
        float panelHeight = contentHeight;
        ImVec2 panelPos(panelX, panelY);
        ImVec2 panelEnd(panelX + panelWidth, panelY + panelHeight);
        ImColor bgCol(8, 8, 18, (int)(200 * s_infoAlpha));
        dl->AddRectFilled(panelPos, panelEnd, C(bgCol), 8.0f);
        ImColor borderCol(40, 40, 60, (int)(80 * s_infoAlpha));
        dl->AddRect(panelPos, panelEnd, C(borderCol), 8.0f, 0, 1.0f);
        float changePulse = 1.0f;
        if (s_targetChangeAnim < 0.3f) {
            changePulse = easeOutCubic(s_targetChangeAnim / 0.3f);
        }
        ImColor nameCol(255, 255, 255, (int)(255 * s_infoAlpha * changePulse));
        dl->AddText(font, 15.0f, ImVec2(panelX + padding, currentY), C(nameCol), s_lastTargetName);
        currentY += 20.0f;
        ImColor sepCol(60, 60, 80, (int)(100 * s_infoAlpha));
        dl->AddLine(
            ImVec2(panelX + padding, currentY),
            ImVec2(panelX + panelWidth - padding, currentY),
            C(sepCol), 1.0f
        );
        currentY += 6.0f;
        char distText[64];
        snprintf(distText, sizeof(distText), "Distance: %.0f m", target->Distance);
        dl->AddText(font, 12.0f, ImVec2(panelX + padding, currentY),
            C(ImColor(180, 180, 200, (int)(255 * s_infoAlpha))), distText);
        currentY += lineHeight;
        ImColor hpColor = GetHealthColor(target->Health, target->MaxHealth);
        ImColor hpCol = ImColor(hpColor.Value.x, hpColor.Value.y, hpColor.Value.z, (int)(255 * s_infoAlpha));
        char hpText[64];
        snprintf(hpText, sizeof(hpText), "Health: %.0f/%.0f", target->Health, target->MaxHealth);
        dl->AddText(font, 12.0f, ImVec2(panelX + padding, currentY), C(hpCol), hpText);
        currentY += lineHeight;
        char armorText[64];
        snprintf(armorText, sizeof(armorText), "Armor: %.0f | Shield: %.0f", target->Armor, target->Shield);
        dl->AddText(font, 12.0f, ImVec2(panelX + padding, currentY),
            C(ImColor(180, 180, 200, (int)(255 * s_infoAlpha))), armorText);
        currentY += lineHeight;
        char weaponText[96];
        snprintf(weaponText, sizeof(weaponText), "Weapon: %s", target->WeaponName);
        dl->AddText(font, 12.0f, ImVec2(panelX + padding, currentY),
            C(ImColor(180, 180, 200, (int)(255 * s_infoAlpha))), weaponText);
        currentY += lineHeight;
        char factionText[64];
        snprintf(factionText, sizeof(factionText), "Team: %d", target->TeamID);
        dl->AddText(font, 12.0f, ImVec2(panelX + padding, currentY),
            C(ImColor(180, 180, 200, (int)(255 * s_infoAlpha))), factionText);
        currentY += lineHeight;
        float dotPulse = sinf(ImGui::GetIO().FrameCount * 0.1f) * 0.3f + 0.7f;
        ImColor visCol;
        if (target->IsVisible) visCol = ImColor(0, 255, 0, (int)(255 * s_infoAlpha * dotPulse));
        else visCol = ImColor(255, 50, 50, (int)(255 * s_infoAlpha));
        dl->AddCircleFilled(ImVec2(panelX + padding + 4.0f, currentY + 6.0f), 4.0f, C(visCol), 12);
        dl->AddText(font, 12.0f, ImVec2(panelX + padding + 14.0f, currentY),
            C(ImColor(180, 180, 200, (int)(255 * s_infoAlpha))),
            target->IsVisible ? "Visible" : "Hidden");
        currentY += lineHeight;
        char boneText[64];
        snprintf(boneText, sizeof(boneText), "Aim Bone: %d", g_Cfg.SelectedAimbotBone);
        dl->AddText(font, 12.0f, ImVec2(panelX + padding, currentY),
            C(ImColor(150, 150, 180, (int)(200 * s_infoAlpha))), boneText);
        currentY += 8.0f;
    } else {
        if (s_infoAlpha > 0.05f) {
            float panelHeight = 60.0f;
            ImVec2 panelPos(panelX, panelY);
            ImVec2 panelEnd(panelX + panelWidth, panelY + panelHeight);
            ImColor bgCol(8, 8, 18, (int)(180 * s_infoAlpha));
            dl->AddRectFilled(panelPos, panelEnd, C(bgCol), 8.0f);
            ImColor borderCol(40, 40, 60, (int)(60 * s_infoAlpha));
            dl->AddRect(panelPos, panelEnd, C(borderCol), 8.0f, 0, 1.0f);
            const char* noTargetText = (s_lastTargetName[0] != '\0') ? s_lastTargetName : "No Target";
            dl->AddText(font, 13.0f, ImVec2(panelX + padding, panelY + 20.0f),
                C(ImColor(150, 150, 180, (int)(180 * s_infoAlpha))), noTargetText);
        }
    }
}

void DrawInfoPanelCompact(ImDrawList* dl, float dt) {
    if (!g_Tog.ShowInfo) {
        s_slideOffset += (200.0f - s_slideOffset) * dt * 6.0f;
        if (s_slideOffset > 195.0f) s_slideOffset = 200.0f;
        s_infoAlpha -= dt * 4.0f;
        if (s_infoAlpha < 0.0f) s_infoAlpha = 0.0f;
        return;
    }
    bool hasTarget = g_Bot.IsLocked && g_Bot.BestTarget.Index >= 0;
    int currentTargetID = hasTarget ? g_Bot.BestTarget.Index : -1;
    if (currentTargetID != s_lastTargetID) {
        s_lastTargetID = currentTargetID;
        s_targetChangeAnim = 0.0f;
        if (hasTarget && currentTargetID >= 0 && currentTargetID < g_Esp.PlayerCount) {
            strncpy(s_lastTargetName, g_Esp.Players[currentTargetID].PlayerName, sizeof(s_lastTargetName) - 1);
            s_lastTargetName[sizeof(s_lastTargetName) - 1] = '\0';
        } else {
            s_lastTargetName[0] = '\0';
        }
    }
    if (hasTarget) {
        s_slideOffset += (0.0f - s_slideOffset) * dt * 4.0f;
        if (s_slideOffset < 0.5f) s_slideOffset = 0.0f;
        s_infoAlpha += dt * 4.0f;
        if (s_infoAlpha > 1.0f) s_infoAlpha = 1.0f;
    } else {
        s_slideOffset += (200.0f - s_slideOffset) * dt * 6.0f;
        if (s_slideOffset > 195.0f) s_slideOffset = 200.0f;
        s_infoAlpha -= dt * 4.0f;
        if (s_infoAlpha < 0.0f) s_infoAlpha = 0.0f;
    }
    if (s_slideOffset > 190.0f && s_infoAlpha < 0.01f) return;
    ImVec2 screenSize = CheckDisplaySize();
    float panelWidth = 160.0f;
    float panelX = screenSize.x - panelWidth - s_slideOffset;
    float panelY = 10.0f;
    ImFont* font = ImGui::GetIO().Fonts->Fonts[0];
    float currentY = panelY + 6.0f;
    float lineHeight = 16.0f;
    float padding = 6.0f;
    if (hasTarget && currentTargetID >= 0 && currentTargetID < g_Esp.PlayerCount) {
        PlayerData* target = &g_Esp.Players[currentTargetID];
        float contentHeight = 6.0f + 18.0f + 4.0f + lineHeight * 3.0f + 6.0f;
        float panelHeight = contentHeight;
        ImVec2 panelPos(panelX, panelY);
        ImVec2 panelEnd(panelX + panelWidth, panelY + panelHeight);
        ImColor bgCol(8, 8, 18, (int)(200 * s_infoAlpha));
        dl->AddRectFilled(panelPos, panelEnd, C(bgCol), 6.0f);
        ImColor borderCol(40, 40, 60, (int)(80 * s_infoAlpha));
        dl->AddRect(panelPos, panelEnd, C(borderCol), 6.0f, 0, 1.0f);
        dl->AddText(font, 14.0f, ImVec2(panelX + padding, currentY),
            C(ImColor(255, 255, 255, (int)(255 * s_infoAlpha))), s_lastTargetName);
        currentY += 18.0f;
        ImColor sepCol(60, 60, 80, (int)(80 * s_infoAlpha));
        dl->AddLine(ImVec2(panelX + padding, currentY), ImVec2(panelX + panelWidth - padding, currentY), C(sepCol), 1.0f);
        currentY += 4.0f;
        char distText[64];
        snprintf(distText, sizeof(distText), "D: %.0fm | HP: %.0f", target->Distance, target->Health);
        dl->AddText(font, 11.0f, ImVec2(panelX + padding, currentY),
            C(ImColor(180, 180, 200, (int)(255 * s_infoAlpha))), distText);
        currentY += lineHeight;
        char weaponText[96];
        snprintf(weaponText, sizeof(weaponText), "%s | Team: %d", target->WeaponName, target->TeamID);
        dl->AddText(font, 11.0f, ImVec2(panelX + padding, currentY),
            C(ImColor(180, 180, 200, (int)(255 * s_infoAlpha))), weaponText);
        currentY += lineHeight;
        float dotPulse = sinf(ImGui::GetIO().FrameCount * 0.1f) * 0.3f + 0.7f;
        ImColor visCol;
        if (target->IsVisible) visCol = ImColor(0, 255, 0, (int)(255 * s_infoAlpha * dotPulse));
        else visCol = ImColor(255, 50, 50, (int)(255 * s_infoAlpha));
        dl->AddCircleFilled(ImVec2(panelX + padding + 4.0f, currentY + 5.0f), 3.0f, C(visCol), 10);
        dl->AddText(font, 11.0f, ImVec2(panelX + padding + 12.0f, currentY),
            C(ImColor(180, 180, 200, (int)(255 * s_infoAlpha))),
            target->IsVisible ? "Visible" : "Hidden");
        currentY += 6.0f;
    } else {
        if (s_infoAlpha > 0.05f) {
            float panelHeight = 40.0f;
            ImVec2 panelPos(panelX, panelY);
            ImVec2 panelEnd(panelX + panelWidth, panelY + panelHeight);
            ImColor bgCol(8, 8, 18, (int)(180 * s_infoAlpha));
            dl->AddRectFilled(panelPos, panelEnd, C(bgCol), 6.0f);
            ImColor borderCol(40, 40, 60, (int)(60 * s_infoAlpha));
            dl->AddRect(panelPos, panelEnd, C(borderCol), 6.0f, 0, 1.0f);
            const char* noTargetText = (s_lastTargetName[0] != '\0') ? s_lastTargetName : "No Target";
            dl->AddText(font, 12.0f, ImVec2(panelX + padding, panelY + 12.0f),
                C(ImColor(150, 150, 180, (int)(180 * s_infoAlpha))), noTargetText);
        }
    }
}

void ResetInfoPanel() {
    s_slideOffset = 180.0f;
    s_lastTargetID = -1;
    s_targetChangeAnim = 0.0f;
    s_infoAlpha = 0.0f;
    s_lastTargetName[0] = '\0';
}

bool IsInfoPanelVisible() {
    return s_infoAlpha > 0.01f && s_slideOffset < 190.0f;
}

float GetInfoPanelAlpha() {
    return s_infoAlpha;
}

const char* GetInfoPanelTargetName() {
    return s_lastTargetName;
}
