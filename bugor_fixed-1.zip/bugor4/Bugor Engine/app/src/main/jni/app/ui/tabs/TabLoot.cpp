#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "TabLoot.h"
#include "../ui_integration.h"
#include "../widgets/Widgets_Switches.h"
#include "../widgets/Widgets_Buttons.h"
#include "../widgets/Widgets_Containers.h"
#include "../widgets/Widgets_Sliders.h"

static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }
extern Toggles g_Tog;

static const char* s_itemCategories[] = {"Assault Rifles","SMGs","Shotguns","Snipers","Pistols","Melee","Light Ammo","Medium Ammo","Heavy Ammo","Shotgun Ammo","Sniper Ammo","Special Ammo","Health Kits","Bandages","Energy Drinks","Painkillers","Adrenaline","Scopes","Muzzles","Grips","Magazines","Stocks","Level 1 Armor","Level 2 Armor","Level 3 Armor","Backpacks","Helmets","Vests","Grenades","Smoke","Flash","Molotov","Airdrops","Flares","Keys","Crafting"};

void DrawTabLoot(ImDrawList* dl, ImVec2 contentArea, ImVec2 contentPos)
{
    Config& c = g_Cfg;
    Toggles& t = g_Tog;
    ImColor accent = c.AccentColor;
    ImColor accent2 = c.AccentColor2;
    float cardW = (contentArea.x - 12.0f) * 0.5f;
    float leftX = contentPos.x;
    float rightX = contentPos.x + cardW + 12.0f;
    float yPos = contentPos.y;

    static bool lootFilterCol = false;
    static bool rarityFilterCol = false;
    static bool visualCol = false;
    static bool sortCol = false;

    static bool lootAmmo = true;
    static bool lootConsumables = true;
    static bool lootAttachments = true;
    static bool lootArmor = true;
    static bool lootThrowables = true;
    static bool lootSpecial = true;

    static bool weaponAR = true;
    static bool weaponSMG = true;
    static bool weaponShotgun = true;
    static bool weaponSniper = true;
    static bool weaponPistol = true;
    static bool weaponMelee = true;

    static bool ammoLight = true;
    static bool ammoMedium = true;
    static bool ammoHeavy = true;
    static bool ammoShotgun = true;
    static bool ammoSniper = true;
    static bool ammoSpecial = true;

    static bool consumableHealthKits = true;
    static bool consumableBandages = true;
    static bool consumableEnergyDrinks = true;
    static bool consumablePainkillers = true;
    static bool consumableAdrenaline = true;

    static bool attachmentScopes = true;
    static bool attachmentMuzzles = true;
    static bool attachmentGrips = true;
    static bool attachmentMagazines = true;
    static bool attachmentStocks = true;

    static bool armorLv1 = true;
    static bool armorLv2 = true;
    static bool armorLv3 = true;
    static bool armorBackpacks = true;
    static bool armorHelmets = true;
    static bool armorVests = true;

    static bool throwableGrenades = true;
    static bool throwableSmoke = true;
    static bool throwableFlash = true;
    static bool throwableMolotov = true;

    static bool specialAirdrops = true;
    static bool specialFlares = true;
    static bool specialKeys = true;
    static bool specialCrafting = true;

    static bool rarityCommon = true;
    static bool rarityUncommon = true;
    static bool rarityRare = true;
    static bool rarityEpic = true;
    static bool rarityLegendary = true;

    static bool showItemName = true;
    static bool showItemDist = true;
    static bool showItemRarity = true;
    static bool itemGlow = true;
    static bool itemIcons = true;
    static float renderDist = 500.0f;

    static int sortByIdx = 0;
    static int sortOrderIdx = 0;

    static bool showWeapons = false;
    static bool showAmmo = false;
    static bool showConsumables = false;
    static bool showAttachments = false;
    static bool showArmor = false;
    static bool showThrowables = false;
    static bool showSpecial = false;

    const char* sortByOpts[] = {"Distance", "Rarity", "Type", "Name"};
    const char* sortOrderOpts[] = {"Ascending", "Descending"};
    char valBuf[128];

    ImGui::SetCursorScreenPos(ImVec2(leftX, yPos));
    ImGui::BeginChild("##loot_filter_card", ImVec2(cardW, 0.0f), false, ImGuiWindowFlags_NoScrollWithinParentChild);
    if (M_CardBegin("Loot Filters", &lootFilterCol, accent))
    {
        M_CyberHeader("LOOT FILTER", accent2, NULL);

        M_SectionDivider("Weapons Category", accent);
        M_ModernSwitch("Weapons (Any)", &t.ItemESP, accent);
        M_ExpandableSection("Weapon Types", &showWeapons, accent);
        if (showWeapons)
        {
            M_ModernSwitch("Assault Rifles", &weaponAR, accent);
            M_ModernSwitch("SMGs", &weaponSMG, accent);
            M_ModernSwitch("Shotguns", &weaponShotgun, accent);
            M_ModernSwitch("Snipers", &weaponSniper, accent);
            M_ModernSwitch("Pistols", &weaponPistol, accent);
            M_ModernSwitch("Melee", &weaponMelee, accent);
            M_GradientSlider("Weapon Range Weight", &renderDist, 0.0f, 1.0f, "%.2f", accent);
        }
        M_BooleanIndicator("Weapons Tracking", t.ItemESP, accent, ImColor(60, 60, 70));

        M_SectionDivider("Ammo Category", accent);
        M_ModernSwitch("Ammo", &lootAmmo, accent);
        M_ExpandableSection("Ammo Types", &showAmmo, accent);
        if (showAmmo)
        {
            M_ModernSwitch("Light Ammo", &ammoLight, accent);
            M_ModernSwitch("Medium Ammo", &ammoMedium, accent);
            M_ModernSwitch("Heavy Ammo", &ammoHeavy, accent);
            M_ModernSwitch("Shotgun Ammo", &ammoShotgun, accent);
            M_ModernSwitch("Sniper Ammo", &ammoSniper, accent);
            M_ModernSwitch("Special Ammo", &ammoSpecial, accent);
        }
        M_BooleanIndicator("Ammo Tracking", lootAmmo, accent, ImColor(60, 60, 70));

        M_SectionDivider("Consumables Category", accent);
        M_ModernSwitch("Consumables", &lootConsumables, accent);
        M_ExpandableSection("Consumable Types", &showConsumables, accent);
        if (showConsumables)
        {
            M_ModernSwitch("Health Kits", &consumableHealthKits, accent);
            M_ModernSwitch("Bandages", &consumableBandages, accent);
            M_ModernSwitch("Energy Drinks", &consumableEnergyDrinks, accent);
            M_ModernSwitch("Painkillers", &consumablePainkillers, accent);
            M_ModernSwitch("Adrenaline", &consumableAdrenaline, accent);
        }
        M_BooleanIndicator("Consumables Tracking", lootConsumables, accent, ImColor(60, 60, 70));

        M_SectionDivider("Attachments Category", accent);
        M_ModernSwitch("Attachments", &lootAttachments, accent);
        M_ExpandableSection("Attachment Types", &showAttachments, accent);
        if (showAttachments)
        {
            M_ModernSwitch("Scopes", &attachmentScopes, accent);
            M_ModernSwitch("Muzzles", &attachmentMuzzles, accent);
            M_ModernSwitch("Grips", &attachmentGrips, accent);
            M_ModernSwitch("Magazines", &attachmentMagazines, accent);
            M_ModernSwitch("Stocks", &attachmentStocks, accent);
        }
        M_BooleanIndicator("Attachments Tracking", lootAttachments, accent, ImColor(60, 60, 70));

        M_SectionDivider("Armor Category", accent);
        M_ModernSwitch("Armor", &lootArmor, accent);
        M_ExpandableSection("Armor Types", &showArmor, accent);
        if (showArmor)
        {
            M_ModernSwitch("Level 1 Armor", &armorLv1, accent);
            M_ModernSwitch("Level 2 Armor", &armorLv2, accent);
            M_ModernSwitch("Level 3 Armor", &armorLv3, accent);
            M_ModernSwitch("Backpacks", &armorBackpacks, accent);
            M_ModernSwitch("Helmets", &armorHelmets, accent);
            M_ModernSwitch("Vests", &armorVests, accent);
        }
        M_BooleanIndicator("Armor Tracking", lootArmor, accent, ImColor(60, 60, 70));

        M_SectionDivider("Throwables Category", accent);
        M_ModernSwitch("Throwables", &lootThrowables, accent);
        M_ExpandableSection("Throwable Types", &showThrowables, accent);
        if (showThrowables)
        {
            M_ModernSwitch("Grenades", &throwableGrenades, accent);
            M_ModernSwitch("Smoke", &throwableSmoke, accent);
            M_ModernSwitch("Flash", &throwableFlash, accent);
            M_ModernSwitch("Molotov", &throwableMolotov, accent);
        }
        M_BooleanIndicator("Throwables Tracking", lootThrowables, accent, ImColor(60, 60, 70));

        M_SectionDivider("Special Category", accent);
        M_ModernSwitch("Special", &lootSpecial, accent);
        M_ExpandableSection("Special Items", &showSpecial, accent);
        if (showSpecial)
        {
            M_ModernSwitch("Airdrops", &specialAirdrops, accent);
            M_ModernSwitch("Flares", &specialFlares, accent);
            M_ModernSwitch("Keys", &specialKeys, accent);
            M_ModernSwitch("Crafting Materials", &specialCrafting, accent);
        }
        M_BooleanIndicator("Special Tracking", lootSpecial, accent, ImColor(60, 60, 70));

        dl->AddRectFilled(
            ImVec2(leftX + 8, ImGui::GetCursorScreenPos().y),
            ImVec2(leftX + cardW - 8, ImGui::GetCursorScreenPos().y + 2),
            C(ImColor(255, 255, 255, 10)), 1.0f);
        ImGui::Dummy(ImVec2(0, 4));

        M_SectionDivider("Filter Status", accent);
        int catActive = (t.ItemESP ? 1 : 0) + (lootAmmo ? 1 : 0) + (lootConsumables ? 1 : 0) +
                        (lootAttachments ? 1 : 0) + (lootArmor ? 1 : 0) + (lootThrowables ? 1 : 0) +
                        (lootSpecial ? 1 : 0);
        snprintf(valBuf, sizeof(valBuf), "%d/7", catActive);
        M_StatCard("Active Filters", valBuf, NULL, catActive > 0, accent);
        M_InfoRow("Weapons Filter", t.ItemESP ? "Active" : "Disabled", t.ItemESP ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "W");
        M_InfoRow("Ammo Filter", lootAmmo ? "Active" : "Disabled", lootAmmo ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "A");
        M_InfoRow("Consumables Filter", lootConsumables ? "Active" : "Disabled", lootConsumables ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "C");
        M_InfoRow("Attachments Filter", lootAttachments ? "Active" : "Disabled", lootAttachments ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "T");
        M_InfoRow("Armor Filter", lootArmor ? "Active" : "Disabled", lootArmor ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "R");
        M_InfoRow("Throwables Filter", lootThrowables ? "Active" : "Disabled", lootThrowables ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "H");
        M_InfoRow("Special Filter", lootSpecial ? "Active" : "Disabled", lootSpecial ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "S");

        int subCount = 0;
        if (weaponAR) subCount++; if (weaponSMG) subCount++; if (weaponShotgun) subCount++; if (weaponSniper) subCount++; if (weaponPistol) subCount++; if (weaponMelee) subCount++;
        if (ammoLight) subCount++; if (ammoMedium) subCount++; if (ammoHeavy) subCount++; if (ammoShotgun) subCount++; if (ammoSniper) subCount++; if (ammoSpecial) subCount++;
        if (consumableHealthKits) subCount++; if (consumableBandages) subCount++; if (consumableEnergyDrinks) subCount++; if (consumablePainkillers) subCount++; if (consumableAdrenaline) subCount++;
        if (attachmentScopes) subCount++; if (attachmentMuzzles) subCount++; if (attachmentGrips) subCount++; if (attachmentMagazines) subCount++; if (attachmentStocks) subCount++;
        if (armorLv1) subCount++; if (armorLv2) subCount++; if (armorLv3) subCount++; if (armorBackpacks) subCount++; if (armorHelmets) subCount++; if (armorVests) subCount++;
        if (throwableGrenades) subCount++; if (throwableSmoke) subCount++; if (throwableFlash) subCount++; if (throwableMolotov) subCount++;
        if (specialAirdrops) subCount++; if (specialFlares) subCount++; if (specialKeys) subCount++; if (specialCrafting) subCount++;
        snprintf(valBuf, sizeof(valBuf), "%d/37", subCount);
        M_InfoRow("Sub-Filters Active", valBuf, subCount > 20 ? ImColor(0, 220, 100) : ImColor(200, 180, 0), "+");

        M_BooleanIndicator("Item ESP Master", t.ItemESP, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Ammo Filter State", lootAmmo, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Consumables State", lootConsumables, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Attachments State", lootAttachments, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Armor Filter State", lootArmor, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Throwables State", lootThrowables, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Special State", lootSpecial, accent, ImColor(60, 60, 70));

        dl->AddRectFilled(
            ImVec2(leftX + 8, ImGui::GetCursorScreenPos().y),
            ImVec2(leftX + cardW - 8, ImGui::GetCursorScreenPos().y + 2),
            C(ImColor(255, 255, 255, 10)), 1.0f);
        ImGui::Dummy(ImVec2(0, 4));

        M_Badge("FILTERS", accent, ImVec2(leftX + 8, ImGui::GetCursorScreenPos().y));
        ImGui::Dummy(ImVec2(0, 4));

        M_ActionButton("F", "Toggle All Filters", ImVec2(cardW - 20, 36), accent, NULL);
        M_ActionButton("R", "Reset All Sub-Filters", ImVec2(cardW - 20, 36), accent, NULL);
        M_IconButton("M", "Master Toggle", ImVec2(36, 36), accent, t.ItemESP, 0);

        int totalCat = 7;
        snprintf(valBuf, sizeof(valBuf), "%d/%d Categories", catActive, totalCat);
        M_StatCard("Category Overview", valBuf, NULL, catActive == totalCat, accent);
        snprintf(valBuf, sizeof(valBuf), "%d Items Tracked", subCount);
        M_StatCard("Sub-Item Count", valBuf, NULL, subCount > 20, accent);
        M_InfoRow("Total Categories", "", accent, "C");
        snprintf(valBuf, sizeof(valBuf), "%d Categories in Database", 7);
        M_InfoRow("", valBuf, accent, NULL);
        M_InfoRow("Sub-Item Types", "", accent, "S");
        snprintf(valBuf, sizeof(valBuf), "%d Sub-Item Filters", 37);
        M_InfoRow("", valBuf, accent, NULL);
    }
    M_CardEnd();
    ImGui::EndChild();
    float yL1 = ImGui::GetCursorScreenPos().y;

    ImGui::SetCursorScreenPos(ImVec2(rightX, yPos));
    ImGui::BeginChild("##loot_rarity_card", ImVec2(cardW, 0.0f), false, ImGuiWindowFlags_NoScrollWithinParentChild);
    if (M_CardBegin("Rarity Filters", &rarityFilterCol, ImColor(180, 100, 255)))
    {
        ImColor rarityAccent = ImColor(180, 100, 255);
        M_CyberHeader("RARITY FILTER", rarityAccent, NULL);

        M_SectionDivider("Rarity Levels", rarityAccent);
        M_ModernSwitch("Common (White)", &rarityCommon, rarityAccent);
        M_BooleanIndicator("Common", rarityCommon, rarityAccent, ImColor(60, 60, 70));
        M_ModernSwitch("Uncommon (Green)", &rarityUncommon, rarityAccent);
        M_BooleanIndicator("Uncommon", rarityUncommon, rarityAccent, ImColor(60, 60, 70));
        M_ModernSwitch("Rare (Blue)", &rarityRare, rarityAccent);
        M_BooleanIndicator("Rare", rarityRare, rarityAccent, ImColor(60, 60, 70));
        M_ModernSwitch("Epic (Purple)", &rarityEpic, rarityAccent);
        M_BooleanIndicator("Epic", rarityEpic, rarityAccent, ImColor(60, 60, 70));
        M_ModernSwitch("Legendary (Orange)", &rarityLegendary, rarityAccent);
        M_BooleanIndicator("Legendary", rarityLegendary, rarityAccent, ImColor(60, 60, 70));

        M_SectionDivider("Rarity Status", rarityAccent);
        int rarityActive = (rarityCommon ? 1 : 0) + (rarityUncommon ? 1 : 0) + (rarityRare ? 1 : 0) +
                           (rarityEpic ? 1 : 0) + (rarityLegendary ? 1 : 0);
        snprintf(valBuf, sizeof(valBuf), "%d/5", rarityActive);
        M_StatCard("Active Rarities", valBuf, NULL, rarityActive == 5, rarityAccent);
        M_InfoRow("Common Items", rarityCommon ? "Visible" : "Hidden", rarityCommon ? ImColor(200, 200, 200) : ImColor(200, 80, 80), "C");
        M_InfoRow("Uncommon Items", rarityUncommon ? "Visible" : "Hidden", rarityUncommon ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "U");
        M_InfoRow("Rare Items", rarityRare ? "Visible" : "Hidden", rarityRare ? ImColor(60, 120, 255) : ImColor(200, 80, 80), "R");
        M_InfoRow("Epic Items", rarityEpic ? "Visible" : "Hidden", rarityEpic ? ImColor(180, 80, 255) : ImColor(200, 80, 80), "E");
        M_InfoRow("Legendary Items", rarityLegendary ? "Visible" : "Hidden", rarityLegendary ? ImColor(255, 160, 50) : ImColor(200, 80, 80), "L");
        M_InfoRow("Color Profile", "Rarity-Based Tinting", rarityAccent, "!");

        dl->AddRectFilled(
            ImVec2(rightX + 8, ImGui::GetCursorScreenPos().y),
            ImVec2(rightX + cardW - 8, ImGui::GetCursorScreenPos().y + 2),
            C(ImColor(255, 255, 255, 10)), 1.0f);
        ImGui::Dummy(ImVec2(0, 4));

        M_Badge("RARITY", rarityAccent, ImVec2(rightX + 8, ImGui::GetCursorScreenPos().y));
        ImGui::Dummy(ImVec2(0, 4));

        M_ActionButton("R", "Enable All Rarities", ImVec2(cardW - 20, 36), rarityAccent, NULL);
        M_ActionButton("D", "Disable All Rarities", ImVec2(cardW - 20, 36), rarityAccent, NULL);
        M_IconButton("T", "Toggle Rarity Highlights", ImVec2(36, 36), rarityAccent, showItemRarity, 0);
        M_InfoRow("Rarity Count", "", rarityAccent, "#");
        snprintf(valBuf, sizeof(valBuf), "%d Rarity Levels Active", rarityActive);
        M_InfoRow("", valBuf, rarityAccent, NULL);
        M_InfoRow("Color Scheme", "Tier-Based Coloring", rarityAccent, "P");
        M_InfoRow("Rarity Mode", rarityActive == 5 ? "Full Spectrum" : "Selective", rarityAccent, "M");
        M_InfoRow("Item Database", "", rarityAccent, "D");
        snprintf(valBuf, sizeof(valBuf), "%d Items Categorized", 37);
        M_InfoRow("", valBuf, rarityAccent, NULL);
    }
    M_CardEnd();
    ImGui::EndChild();
    float yR1 = ImGui::GetCursorScreenPos().y;

    ImGui::SetCursorScreenPos(ImVec2(rightX, yR1 + 4.0f));
    ImGui::BeginChild("##loot_visual_card", ImVec2(cardW, 0.0f), false, ImGuiWindowFlags_NoScrollWithinParentChild);
    if (M_CardBegin("Visual Settings", &visualCol, ImColor(60, 200, 255)))
    {
        ImColor visualAccent = ImColor(60, 200, 255);
        M_CyberHeader("VISUAL SETTINGS", visualAccent, NULL);

        M_SectionDivider("Render Distance", visualAccent);
        M_GradientSlider("Max Render Distance", &renderDist, 50.0f, 500.0f, "%.0f m", visualAccent);
        M_InfoRow("Current Render Range", "", visualAccent, "D");
        snprintf(valBuf, sizeof(valBuf), "%.0f meters max", renderDist);
        M_InfoRow("", valBuf, visualAccent, NULL);

        M_SectionDivider("Display Options", visualAccent);
        M_ModernSwitch("Show Item Name", &showItemName, visualAccent);
        M_BooleanIndicator("Item Names", showItemName, visualAccent, ImColor(60, 60, 70));
        M_ModernSwitch("Show Item Distance", &showItemDist, visualAccent);
        M_BooleanIndicator("Item Distance", showItemDist, visualAccent, ImColor(60, 60, 70));
        M_ModernSwitch("Show Item Rarity", &showItemRarity, visualAccent);
        M_BooleanIndicator("Rarity Display", showItemRarity, visualAccent, ImColor(60, 60, 70));
        M_ModernSwitch("Glow Effect", &itemGlow, visualAccent);
        M_BooleanIndicator("Glow Active", itemGlow, visualAccent, ImColor(60, 60, 70));
        M_ModernSwitch("Item Icons", &itemIcons, visualAccent);
        M_BooleanIndicator("Icons Active", itemIcons, visualAccent, ImColor(60, 60, 70));

        M_SectionDivider("Visual Status", visualAccent);
        int visActive = (showItemName ? 1 : 0) + (showItemDist ? 1 : 0) + (showItemRarity ? 1 : 0) +
                        (itemGlow ? 1 : 0) + (itemIcons ? 1 : 0);
        snprintf(valBuf, sizeof(valBuf), "%d/5", visActive);
        M_StatCard("Active Visuals", valBuf, NULL, visActive > 2, visualAccent);
        M_InfoRow("Name Label", showItemName ? "Shown" : "Hidden", showItemName ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "N");
        M_InfoRow("Distance Label", showItemDist ? "Shown" : "Hidden", showItemDist ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "D");
        M_InfoRow("Rarity Label", showItemRarity ? "Shown" : "Hidden", showItemRarity ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "R");
        M_InfoRow("Glow Overlay", itemGlow ? "On" : "Off", itemGlow ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "G");
        M_InfoRow("Icon Display", itemIcons ? "On" : "Off", itemIcons ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "I");
        M_InfoRow("Render Distance", "", visualAccent, "M");
        snprintf(valBuf, sizeof(valBuf), "%.0f meters", renderDist);
        M_InfoRow("", valBuf, visualAccent, NULL);

        dl->AddRectFilled(
            ImVec2(rightX + 8, ImGui::GetCursorScreenPos().y),
            ImVec2(rightX + cardW - 8, ImGui::GetCursorScreenPos().y + 2),
            C(ImColor(255, 255, 255, 10)), 1.0f);
        ImGui::Dummy(ImVec2(0, 4));

        M_Badge("VISUAL", visualAccent, ImVec2(rightX + 8, ImGui::GetCursorScreenPos().y));
        ImGui::Dummy(ImVec2(0, 4));

        M_ActionButton("V", "Toggle All Visuals", ImVec2(cardW - 20, 36), visualAccent, NULL);
        M_IconButton("G", "Toggle Glow", ImVec2(36, 36), visualAccent, itemGlow, 0);
        M_IconButton("I", "Toggle Icons", ImVec2(36, 36), visualAccent, itemIcons, 0);
        M_InfoRow("Visual Mode", visActive > 2 ? "Enhanced" : "Minimal", visualAccent, "!");
        M_InfoRow("Label Settings", "", visualAccent, "L");
        int labelCount = (showItemName ? 1 : 0) + (showItemDist ? 1 : 0) + (showItemRarity ? 1 : 0);
        snprintf(valBuf, sizeof(valBuf), "%d/3 Labels Active", labelCount);
        M_InfoRow("", valBuf, visualAccent, NULL);
        M_InfoRow("Render Quality", renderDist > 300.0f ? "High" : (renderDist > 150.0f ? "Medium" : "Low"), visualAccent, "Q");
    }
    M_CardEnd();
    ImGui::EndChild();
    float yR2 = ImGui::GetCursorScreenPos().y;

    ImGui::SetCursorScreenPos(ImVec2(rightX, yR2 + 4.0f));
    ImGui::BeginChild("##loot_sort_card", ImVec2(cardW, 0.0f), false, ImGuiWindowFlags_NoScrollWithinParentChild);
    if (M_CardBegin("Sorting", &sortCol, ImColor(100, 255, 150)))
    {
        ImColor sortAccent = ImColor(100, 255, 150);
        M_CyberHeader("SORTING", sortAccent, NULL);

        M_SectionDivider("Sort Method", sortAccent);
        M_SegmentedToggle("Sort By", &sortByIdx, sortByOpts, 4, sortAccent);
        M_InfoRow("Current Sort Mode", "", sortAccent, "S");
        snprintf(valBuf, sizeof(valBuf), "Sorting by %s", sortByOpts[sortByIdx]);
        M_InfoRow("", valBuf, sortAccent, NULL);
        M_SectionDivider("Sort Direction", sortAccent);
        M_SegmentedToggle("Order", &sortOrderIdx, sortOrderOpts, 2, sortAccent);
        M_InfoRow("Current Order", "", sortAccent, "O");
        snprintf(valBuf, sizeof(valBuf), "%s Order", sortOrderOpts[sortOrderIdx]);
        M_InfoRow("", valBuf, sortAccent, NULL);

        M_SectionDivider("Sort Preview", sortAccent);
        M_InfoRow("Sort Key", sortByOpts[sortByIdx], sortAccent, "K");
        M_InfoRow("Direction", sortOrderOpts[sortOrderIdx], sortAccent, "D");
        M_InfoRow("Combined", "", sortAccent, "+");
        snprintf(valBuf, sizeof(valBuf), "%s / %s", sortByOpts[sortByIdx], sortOrderOpts[sortOrderIdx]);
        M_InfoRow("", valBuf, sortAccent, NULL);

        dl->AddRectFilled(
            ImVec2(rightX + 8, ImGui::GetCursorScreenPos().y),
            ImVec2(rightX + cardW - 8, ImGui::GetCursorScreenPos().y + 2),
            C(ImColor(255, 255, 255, 10)), 1.0f);
        ImGui::Dummy(ImVec2(0, 4));

        M_Badge("SORT", sortAccent, ImVec2(rightX + 8, ImGui::GetCursorScreenPos().y));
        ImGui::Dummy(ImVec2(0, 4));

        M_ActionButton("S", "Apply Sorting", ImVec2(cardW - 20, 36), sortAccent, NULL);
        M_IconButton("O", "Toggle Order", ImVec2(36, 36), sortAccent, sortOrderIdx == 1, 0);
        M_InfoRow("Sort Configuration", "", sortAccent, "C");
        snprintf(valBuf, sizeof(valBuf), "%s %s", sortByOpts[sortByIdx], sortOrderOpts[sortOrderIdx]);
        M_InfoRow("", valBuf, sortAccent, NULL);
        M_InfoRow("Sort Mode Index", "", sortAccent, "#");
        snprintf(valBuf, sizeof(valBuf), "Index %d of %d", sortByIdx, 3);
        M_InfoRow("", valBuf, sortAccent, NULL);
        M_InfoRow("Order Mode Index", "", sortAccent, "#");
        snprintf(valBuf, sizeof(valBuf), "Index %d of %d", sortOrderIdx, 1);
        M_InfoRow("", valBuf, sortAccent, NULL);
        M_InfoRow("Sorting Algorithm", "Quick Sort (Default)", sortAccent, "A");
        M_InfoRow("Stable Sort", "Enabled", sortAccent, "B");
        M_InfoRow("Item Count Reference", "", sortAccent, "R");
        snprintf(valBuf, sizeof(valBuf), "%d Items", 37);
        M_InfoRow("", valBuf, sortAccent, NULL);
    }
    M_CardEnd();
    ImGui::EndChild();
    float yR3 = ImGui::GetCursorScreenPos().y;

    float finalY = yL1;
    if (yR3 > finalY) finalY = yR3;
    ImGui::SetCursorScreenPos(ImVec2(contentPos.x, finalY + 8.0f));
}
