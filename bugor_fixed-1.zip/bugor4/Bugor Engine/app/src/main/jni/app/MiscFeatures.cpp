#include "MiscFeatures.h"
#include "Offsets.h"
#include <cmath>

MiscFeatures::MiscFeatures(MemoryIO* mem, GameOffsets* offsets, Config* cfg, Toggles* tog) {
    Mem = mem;
    Offsets = offsets;
    Cfg = cfg;
    Tog = tog;
}

void MiscFeatures::Update() {
    if (!Offsets->Initialized) return;
    
    if (Tog->GodMode) GodMode(true);
    if (Tog->InfiniteAmmo) InfiniteAmmo(true);
    if (Tog->NoRecoil) NoRecoil(true);
    if (Tog->NoSpread) NoSpread(true);
    if (Tog->RapidFire) RapidFire(true);
    if (Tog->OneHitKill) OneHitKill(true);
    if (Tog->NoClip) NoClip(true);
    if (Tog->NightVision) NightVision(true);
    if (Tog->ThermalVision) ThermalVision(true);
    if (Tog->Wireframe) Wireframe(true);
    if (Tog->Chams) Chams(true);
    if (Tog->XRay) XRay(true);
    if (Tog->NoFog) NoFog(true);
    if (Tog->DayTime) DayTime(true);
    if (Tog->CleanScreen) CleanScreen(true);
    if (Tog->InfiniteStamina) InfiniteStamina(true);
    if (Tog->InfiniteOxygen) InfiniteOxygen(true);
    if (Tog->NoFallDamage) NoFallDamage(true);
    if (Tog->NoHunger) NoHunger(true);
    if (Tog->NoThirst) NoThirst(true);
    if (Tog->MagicBullet) MagicBullet(true);
    if (Tog->ShowAllOnRadar) ShowAllOnRadar(true);
    if (Tog->AutoLoot) AutoLoot(true, Cfg->LootRadius);
    if (Tog->AutoPickup) AutoPickup(true);
    if (Tog->AutoHeal) AutoHeal(true, Cfg->HealPercent);
    if (Tog->AutoReload) AutoReload(true);
    if (Tog->AutoRespawn) AutoRespawn(true);
    if (Tog->AutoCraft) AutoCraft(true);
    if (Tog->AutoFarm) AutoFarm(true, Cfg->FarmRange);
    
    SetSpeed(Cfg->SpeedMultiplier);
    SetJumpHeight(Cfg->JumpHeight);
    SetGravity(Cfg->Gravity);
    SetTime(Cfg->TimeOfDay);
    SetWeather(Cfg->Weather);
    SetRadarRange(Cfg->RadarRange);
}

uintptr_t MiscFeatures::FindLocalPlayer() {
    if (!Offsets->Initialized) return 0;
    return Offsets->LocalPlayer;
}

uintptr_t MiscFeatures::FindWeaponManager() {
    uintptr_t player = FindLocalPlayer();
    if (!player) return 0;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return 0;
    uintptr_t pawn = Mem->ReadPtr64(controller + 0x2A0);
    if (!pawn) return 0;
    return Mem->ReadPtr64(pawn + Offsets->OffsetEntityWeapon);
}

uintptr_t MiscFeatures::FindMovementController() {
    uintptr_t player = FindLocalPlayer();
    if (!player) return 0;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return 0;
    uintptr_t pawn = Mem->ReadPtr64(controller + 0x2A0);
    if (!pawn) return 0;
    return Mem->ReadPtr64(pawn + 0x130);
}

uintptr_t MiscFeatures::FindInventory() {
    uintptr_t player = FindLocalPlayer();
    if (!player) return 0;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return 0;
    uintptr_t pawn = Mem->ReadPtr64(controller + 0x2A0);
    if (!pawn) return 0;
    return Mem->ReadPtr64(pawn + 0x1E0);
}

uintptr_t MiscFeatures::FindWeatherSystem() {
    if (!Offsets->Initialized) return 0;
    uintptr_t world = Offsets->UWorld;
    if (!world) return 0;
    return Mem->ReadPtr64(world + 0x98);
}

uintptr_t MiscFeatures::FindTimeSystem() {
    if (!Offsets->Initialized) return 0;
    uintptr_t world = Offsets->UWorld;
    if (!world) return 0;
    return Mem->ReadPtr64(world + 0xA0);
}

bool MiscFeatures::WriteValue(uintptr_t addr, uint32_t offset, float value) {
    if (!addr) return false;
    Mem->WriteFloat(addr + offset, value);
    return true;
}

bool MiscFeatures::WriteValue(uintptr_t addr, uint32_t offset, int value) {
    if (!addr) return false;
    Mem->WriteInt(addr + offset, value);
    return true;
}

bool MiscFeatures::WriteFlag(uintptr_t addr, uint32_t offset, bool value) {
    if (!addr) return false;
    uint8_t flag = value ? 1 : 0;
    Mem->Write(addr + offset, &flag, sizeof(uint8_t));
    return true;
}

void MiscFeatures::SetSpeed(float multiplier) {
    uintptr_t movement = FindMovementController();
    if (!movement) return;
    float walkSpeed = Cfg->WalkSpeed * multiplier;
    float runSpeed = Cfg->RunSpeed * multiplier;
    Mem->WriteFloat(movement + 0x24, walkSpeed);
    Mem->WriteFloat(movement + 0x28, runSpeed);
}

void MiscFeatures::SetJumpHeight(float height) {
    uintptr_t movement = FindMovementController();
    if (!movement) return;
    Mem->WriteFloat(movement + 0x2C, height * 100.0f);
}

void MiscFeatures::SetGravity(float gravity) {
    uintptr_t movement = FindMovementController();
    if (!movement) return;
    Mem->WriteFloat(movement + 0x30, gravity * -250.0f);
}

void MiscFeatures::SetSwimSpeed(float speed) {
    uintptr_t movement = FindMovementController();
    if (!movement) return;
    Mem->WriteFloat(movement + 0x34, speed);
}

void MiscFeatures::NoClip(bool enable) {
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    uintptr_t pawn = Mem->ReadPtr64(controller + 0x2A0);
    if (!pawn) return;
    uint8_t val = enable ? 0 : 1;
    Mem->Write(pawn + 0x2F8, &val, sizeof(uint8_t));
}

void MiscFeatures::GodMode(bool enable) {
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    uintptr_t pawn = Mem->ReadPtr64(controller + 0x2A0);
    if (!pawn) return;
    WriteFlag(pawn, Offsets->OffsetHealth + 0x4C, enable);
    if (enable) SetHealth(99999);
}

void MiscFeatures::InfiniteAmmo(bool enable) {
    uintptr_t weaponMgr = FindWeaponManager();
    if (!weaponMgr) return;
    for (int i = 0; i < 12; i++) {
        uintptr_t weapon = Mem->ReadPtr64(weaponMgr + 0x10 + i * sizeof(uintptr_t));
        if (!weapon) continue;
        if (enable) {
            Mem->WriteInt(weapon + Offsets->OffsetAmmo, 999);
            Mem->WriteInt(weapon + Offsets->OffsetMaxAmmo, 999);
        }
    }
}

void MiscFeatures::NoRecoil(bool enable) {
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    uintptr_t pawn = Mem->ReadPtr64(controller + 0x2A0);
    if (!pawn) return;
    uintptr_t weaponManager = FindWeaponManager();
    if (!weaponManager) return;
    uintptr_t currentWeapon = Mem->ReadPtr64(weaponManager + 0x08);
    if (!currentWeapon) return;
    if (enable) {
        Mem->WriteFloat(currentWeapon + Offsets->OffsetRecoil, 0.0f);
        Mem->WriteFloat(currentWeapon + Offsets->OffsetRecoil + 0x4, 0.0f);
    }
}

void MiscFeatures::NoSpread(bool enable) {
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    uintptr_t pawn = Mem->ReadPtr64(controller + 0x2A0);
    if (!pawn) return;
    uintptr_t weaponManager = FindWeaponManager();
    if (!weaponManager) return;
    uintptr_t currentWeapon = Mem->ReadPtr64(weaponManager + 0x08);
    if (!currentWeapon) return;
    if (enable) {
        Mem->WriteFloat(currentWeapon + Offsets->OffsetSpread, 0.0f);
        Mem->WriteFloat(currentWeapon + Offsets->OffsetSpread + 0x4, 0.0f);
    }
}

void MiscFeatures::RapidFire(bool enable) {
    uintptr_t weaponManager = FindWeaponManager();
    if (!weaponManager) return;
    uintptr_t currentWeapon = Mem->ReadPtr64(weaponManager + 0x08);
    if (!currentWeapon) return;
    if (enable) {
        Mem->WriteFloat(currentWeapon + Offsets->OffsetFireRate, 0.0f);
    }
}

void MiscFeatures::OneHitKill(bool enable) {
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    uintptr_t pawn = Mem->ReadPtr64(controller + 0x2A0);
    if (!pawn) return;
    uintptr_t weaponManager = FindWeaponManager();
    if (!weaponManager) return;
    uintptr_t currentWeapon = Mem->ReadPtr64(weaponManager + 0x08);
    if (!currentWeapon) return;
    if (enable) {
        Mem->WriteFloat(currentWeapon + 0x120, 99999.0f);
    }
}

void MiscFeatures::NightVision(bool enable) {
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    uintptr_t pawn = Mem->ReadPtr64(controller + 0x2A0);
    if (!pawn) return;
    WriteFlag(pawn, 0x7A0, enable);
}

void MiscFeatures::ThermalVision(bool enable) {
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    uintptr_t pawn = Mem->ReadPtr64(controller + 0x2A0);
    if (!pawn) return;
    WriteFlag(pawn, 0x7A4, enable);
}

void MiscFeatures::Wireframe(bool enable) {
    if (!Offsets->Initialized) return;
    uintptr_t renderDevice = Mem->ReadPtr64(Offsets->UnityBase + 0x2F8);
    if (!renderDevice) return;
    int val = enable ? 2 : 0;
    Mem->WriteInt(renderDevice + 0xC0, val);
}

void MiscFeatures::Chams(bool enable) {
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    uintptr_t pawn = Mem->ReadPtr64(controller + 0x2A0);
    if (!pawn) return;
    uintptr_t mesh = Mem->ReadPtr64(pawn + Offsets->OffsetEntityMesh);
    if (!mesh) return;
    WriteFlag(mesh + 0x330, 0x00, enable);
}

void MiscFeatures::XRay(bool enable) {
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    uintptr_t pawn = Mem->ReadPtr64(controller + 0x2A0);
    if (!pawn) return;
    uintptr_t mesh = Mem->ReadPtr64(pawn + Offsets->OffsetEntityMesh);
    if (!mesh) return;
    float val = enable ? 0.0f : 1.0f;
    Mem->WriteFloat(mesh + 0x1C0, val);
}

void MiscFeatures::SetTime(float hour) {
    uintptr_t timeSystem = FindTimeSystem();
    if (!timeSystem) return;
    Mem->WriteFloat(timeSystem + 0x20, hour);
    Mem->WriteFloat(timeSystem + 0x24, hour * 60.0f);
}

void MiscFeatures::SetWeather(int weather) {
    uintptr_t weatherSystem = FindWeatherSystem();
    if (!weatherSystem) return;
    if (weather < 0) weather = 0;
    if (weather > 5) weather = 5;
    Mem->WriteInt(weatherSystem + 0x18, weather);
}

void MiscFeatures::NoFog(bool enable) {
    uintptr_t weatherSystem = FindWeatherSystem();
    if (!weatherSystem) return;
    float val = enable ? 0.0f : 1.0f;
    Mem->WriteFloat(weatherSystem + 0x2C, val);
    Mem->WriteFloat(weatherSystem + 0x30, val);
}

void MiscFeatures::DayTime(bool enable) {
    uintptr_t timeSystem = FindTimeSystem();
    if (!timeSystem) return;
    if (enable) {
        Mem->WriteFloat(timeSystem + 0x20, 12.0f);
    }
    WriteFlag(timeSystem + 0x28, 0x00, enable);
}

void MiscFeatures::CleanScreen(bool enable) {
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    WriteFlag(controller + 0x3C0, 0x00, enable);
}

void MiscFeatures::SetHealth(int hp) {
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    uintptr_t pawn = Mem->ReadPtr64(controller + 0x2A0);
    if (!pawn) return;
    Mem->WriteFloat(pawn + Offsets->OffsetHealth, (float)hp);
    Mem->WriteFloat(pawn + Offsets->OffsetHealth + 0x4, (float)hp);
}

void MiscFeatures::SetShield(int shield) {
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    uintptr_t pawn = Mem->ReadPtr64(controller + 0x2A0);
    if (!pawn) return;
    Mem->WriteFloat(pawn + Offsets->OffsetShield, (float)shield);
}

void MiscFeatures::SetArmor(int armor) {
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    uintptr_t pawn = Mem->ReadPtr64(controller + 0x2A0);
    if (!pawn) return;
    Mem->WriteFloat(pawn + Offsets->OffsetArmor, (float)armor);
}

void MiscFeatures::SetMoney(int money) {
    uintptr_t inventory = FindInventory();
    if (!inventory) return;
    Mem->WriteInt(inventory + 0x60, money);
}

void MiscFeatures::TeleportTo(float x, float y, float z) {
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    uintptr_t pawn = Mem->ReadPtr64(controller + 0x2A0);
    if (!pawn) return;
    Mem->WriteFloat(pawn + Offsets->OffsetEntityPos, x);
    Mem->WriteFloat(pawn + Offsets->OffsetEntityPos + 0x4, y);
    Mem->WriteFloat(pawn + Offsets->OffsetEntityPos + 0x8, z);
}

void MiscFeatures::TeleportUp(float dist) {
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    uintptr_t pawn = Mem->ReadPtr64(controller + 0x2A0);
    if (!pawn) return;
    float x = Mem->ReadFloat(pawn + Offsets->OffsetEntityPos);
    float y = Mem->ReadFloat(pawn + Offsets->OffsetEntityPos + 0x4);
    float z = Mem->ReadFloat(pawn + Offsets->OffsetEntityPos + 0x8);
    Mem->WriteFloat(pawn + Offsets->OffsetEntityPos + 0x8, z + dist);
}

void MiscFeatures::TeleportForward(float dist) {
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    uintptr_t pawn = Mem->ReadPtr64(controller + 0x2A0);
    if (!pawn) return;
    float camYaw = Offsets->CameraYaw;
    float rad = camYaw * (3.14159265f / 180.0f);
    float dx = sinf(rad) * dist;
    float dz = cosf(rad) * dist;
    float x = Mem->ReadFloat(pawn + Offsets->OffsetEntityPos);
    float z = Mem->ReadFloat(pawn + Offsets->OffsetEntityPos + 0x8);
    Mem->WriteFloat(pawn + Offsets->OffsetEntityPos, x + dx);
    Mem->WriteFloat(pawn + Offsets->OffsetEntityPos + 0x8, z + dz);
}

void MiscFeatures::ShowAllOnRadar(bool enable) {
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    WriteFlag(controller + 0x3C8, 0x00, enable);
}

void MiscFeatures::SetRadarRange(float range) {
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    Mem->WriteFloat(controller + 0x3CC, range);
}

void MiscFeatures::AutoLoot(bool enable, int radius) {
    Tog->AutoLoot = enable;
    Cfg->LootRadius = radius;
}

void MiscFeatures::AutoPickup(bool enable) {
    Tog->AutoPickup = enable;
}

void MiscFeatures::AutoHeal(bool enable, float hpPercent) {
    Tog->AutoHeal = enable;
    Cfg->HealPercent = hpPercent;
    if (!enable) return;
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    uintptr_t pawn = Mem->ReadPtr64(controller + 0x2A0);
    if (!pawn) return;
    float hp = Mem->ReadFloat(pawn + Offsets->OffsetHealth);
    float maxHp = Mem->ReadFloat(pawn + Offsets->OffsetHealth + 0x4);
    if (maxHp <= 0.0f) maxHp = 100.0f;
    float threshold = maxHp * (hpPercent / 100.0f);
    if (hp < threshold) {
        SetHealth((int)maxHp);
    }
}

void MiscFeatures::AutoReload(bool enable) {
    Tog->AutoReload = enable;
    if (!enable) return;
    uintptr_t weaponManager = FindWeaponManager();
    if (!weaponManager) return;
    uintptr_t currentWeapon = Mem->ReadPtr64(weaponManager + 0x08);
    if (!currentWeapon) return;
    int ammo = Mem->ReadInt(currentWeapon + Offsets->OffsetAmmo);
    if (ammo <= 0) {
        Mem->WriteInt(currentWeapon + Offsets->OffsetAmmo, 999);
    }
}

void MiscFeatures::AutoRespawn(bool enable) {
    Tog->AutoRespawn = enable;
    if (!enable) return;
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    WriteFlag(controller + 0x3D0, 0x00, true);
}

void MiscFeatures::AutoCraft(bool enable) {
    Tog->AutoCraft = enable;
}

void MiscFeatures::AutoFarm(bool enable, int range) {
    Tog->AutoFarm = enable;
    Cfg->FarmRange = range;
}

void MiscFeatures::InfiniteStamina(bool enable) {
    uintptr_t movement = FindMovementController();
    if (!movement) return;
    if (enable) {
        Mem->WriteFloat(movement + 0x38, 100.0f);
        Mem->WriteFloat(movement + 0x3C, 100.0f);
    }
}

void MiscFeatures::InfiniteOxygen(bool enable) {
    uintptr_t movement = FindMovementController();
    if (!movement) return;
    if (enable) {
        Mem->WriteFloat(movement + 0x40, 100.0f);
    }
}

void MiscFeatures::NoFallDamage(bool enable) {
    uintptr_t movement = FindMovementController();
    if (!movement) return;
    WriteFlag(movement + 0x44, 0x00, enable);
}

void MiscFeatures::NoHunger(bool enable) {
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    uintptr_t pawn = Mem->ReadPtr64(controller + 0x2A0);
    if (!pawn) return;
    WriteFlag(pawn + 0x4B0, 0x00, enable);
    if (enable) {
        Mem->WriteFloat(pawn + 0x4B4, 100.0f);
    }
}

void MiscFeatures::NoThirst(bool enable) {
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    uintptr_t pawn = Mem->ReadPtr64(controller + 0x2A0);
    if (!pawn) return;
    WriteFlag(pawn + 0x4B8, 0x00, enable);
    if (enable) {
        Mem->WriteFloat(pawn + 0x4BC, 100.0f);
    }
}

void MiscFeatures::MagicBullet(bool enable) {
    uintptr_t weaponManager = FindWeaponManager();
    if (!weaponManager) return;
    uintptr_t currentWeapon = Mem->ReadPtr64(weaponManager + 0x08);
    if (!currentWeapon) return;
    WriteFlag(currentWeapon + 0x124, 0x00, enable);
}

void MiscFeatures::Airstrike(float x, float y, float z) {
    uintptr_t player = FindLocalPlayer();
    if (!player) return;
    uintptr_t controller = Mem->ReadPtr64(player + Offsets->OffsetPlayerController);
    if (!controller) return;
    uintptr_t pawn = Mem->ReadPtr64(controller + 0x2A0);
    if (!pawn) return;
    float px = Mem->ReadFloat(pawn + Offsets->OffsetEntityPos);
    float py = Mem->ReadFloat(pawn + Offsets->OffsetEntityPos + 0x4);
    float pz = Mem->ReadFloat(pawn + Offsets->OffsetEntityPos + 0x8);
    uintptr_t weatherSystem = FindWeatherSystem();
    if (!weatherSystem) return;
    Mem->WriteFloat(weatherSystem + 0x40, px + x);
    Mem->WriteFloat(weatherSystem + 0x44, py + y);
    Mem->WriteFloat(weatherSystem + 0x48, pz + z);
    Mem->WriteInt(weatherSystem + 0x4C, 1);
}

void MiscFeatures::SpawnItem(int itemID, int count) {
    uintptr_t inventory = FindInventory();
    if (!inventory) return;
    Mem->WriteInt(inventory + 0x64, itemID);
    Mem->WriteInt(inventory + 0x68, count);
    WriteFlag(inventory + 0x6C, 0x00, true);
}
