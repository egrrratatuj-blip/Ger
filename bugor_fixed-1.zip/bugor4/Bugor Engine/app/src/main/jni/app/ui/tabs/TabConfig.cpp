#include "TabConfig.h"
#include "../ui_integration.h"
#include "../../ConfigSerializer.h"
#include "../../ConfigWatcher.h"
#include "../../../imgui/imgui.h"
#include "../../../imgui/imgui_internal.h"
#include "../../../imgui/mycustom/imgui_Custom.h"
#include "../../Aimbot.h"
#include <cstdio>
#include <cstring>
#include <cmath>
#include <ctime>
#include <cstdint>
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>

extern MemoryIO *g_Mem;
extern GameOffsets g_Offsets;
extern Config g_Cfg;
extern Toggles g_Tog;
extern Aimbot g_Bot;
extern ESP g_Esp;
extern int _ScreenX, _ScreenY;

static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }

static ImColor Accent() { return ImColor(0, 180, 255); }
static ImColor Accent2() { return ImColor(100, 50, 255); }
static ImColor Green() { return ImColor(0, 255, 120); }
static ImColor Red() { return ImColor(255, 60, 60); }
static ImColor Yellow() { return ImColor(255, 200, 50); }
static ImColor Orange() { return ImColor(255, 150, 100); }
static ImColor Purple() { return ImColor(180, 180, 255); }
static ImColor Cyan() { return ImColor(0, 200, 255); }
static ImColor White() { return ImColor(220, 220, 240); }

static const char g_ConfigDir[] = "/storage/emulated/0/чит/Bugor Engine/configs/";

static bool M_DeleteButton(const char* id, ImVec2 position, float size)
{
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 min = position;
    ImVec2 max = ImVec2(position.x + size, position.y + size);
    bool hovered = ImGui::IsMouseHoveringRect(min, max);
    bool clicked = hovered && ImGui::IsMouseClicked(0);
    ImU32 bg = C(hovered ? ImColor(255, 40, 40, 220) : ImColor(255, 50, 50, 120));
    dl->AddRectFilled(min, max, bg, 4.0f);
    ImU32 border = C(hovered ? ImColor(255, 100, 100, 200) : ImColor(255, 80, 80, 100));
    dl->AddRect(min, max, border, 4.0f, ImDrawFlags_RoundCornersAll, 1.0f);
    float pad = size * 0.28f;
    float cx = min.x + size * 0.5f;
    float cy = min.y + size * 0.5f;
    float hl = size * 0.5f - pad;
    ImU32 xCol = C(ImColor(255, 255, 255, 220));
    dl->AddLine(ImVec2(cx - hl, cy - hl), ImVec2(cx + hl, cy + hl), xCol, 2.2f);
    dl->AddLine(ImVec2(cx + hl, cy - hl), ImVec2(cx - hl, cy + hl), xCol, 2.2f);
    return clicked;
}

static const char* GetVirtualKeyName(int key)
{
    switch (key)
    {
        case 0: return "None";
        case 0x01: return "LBUTTON";
        case 0x02: return "RBUTTON";
        case 0x04: return "MBUTTON";
        case 0x08: return "BACK";
        case 0x09: return "TAB";
        case 0x0D: return "ENTER";
        case 0x10: return "SHIFT";
        case 0x11: return "CTRL";
        case 0x12: return "ALT";
        case 0x13: return "PAUSE";
        case 0x14: return "CAPS";
        case 0x1B: return "ESC";
        case 0x20: return "SPACE";
        case 0x21: return "PGUP";
        case 0x22: return "PGDN";
        case 0x23: return "END";
        case 0x24: return "HOME";
        case 0x25: return "LEFT";
        case 0x26: return "UP";
        case 0x27: return "RIGHT";
        case 0x28: return "DOWN";
        case 0x2C: return "PRTSC";
        case 0x2D: return "INS";
        case 0x2E: return "DEL";
        case 0x70: return "F1";
        case 0x71: return "F2";
        case 0x72: return "F3";
        case 0x73: return "F4";
        case 0x74: return "F5";
        case 0x75: return "F6";
        case 0x76: return "F7";
        case 0x77: return "F8";
        case 0x78: return "F9";
        case 0x79: return "F10";
        case 0x7A: return "F11";
        case 0x7B: return "F12";
        case 0x90: return "NUMLOCK";
        case 0x91: return "SCROLL";
        case 0xA0: return "LSHIFT";
        case 0xA1: return "RSHIFT";
        case 0xA2: return "LCTRL";
        case 0xA3: return "RCTRL";
        case 0xA4: return "LALT";
        case 0xA5: return "RALT";
        default:
        {
            if (key >= 0x30 && key <= 0x39)
            {
                static char d[2];
                d[0] = (char)('0' + (key - 0x30));
                d[1] = 0;
                return d;
            }
            if (key >= 0x41 && key <= 0x5A)
            {
                static char l[2];
                l[0] = (char)('A' + (key - 0x41));
                l[1] = 0;
                return l;
            }
            static char uk[16];
            snprintf(uk, sizeof(uk), "0x%02X", key);
            return uk;
        }
    }
}

static char s_ProfileNames[6][32];
static int s_ActiveProfile = 0;
static int s_ProfileTimestamps[6] = {0};
static char s_CurrentConfigPath[256] = "";

static int s_Keybinds[8] = {
    0x79, 0x74, 0x75, 0x76, 0x77, 0x78, 0x70, 0x71
};
static const char* s_KeybindLabels[8] = {
    "Toggle Menu", "Toggle ESP", "Toggle Aimbot", "Toggle Radar",
    "Panic Key", "Teleport to Marker", "Aimbot Key", "Triggerbot Key"
};
static bool s_IsRecording = false;
static int s_RecordingIndex = -1;
static float s_RecordingStartTime = 0.0f;

static bool g_AutoSave = true;
static bool g_AutoLoad = true;
static bool g_SafeMode = false;
static bool g_StreamMode = false;
static bool g_BypassDetect = true;
static bool g_LoggingEnabled = false;
static float g_LogLevel = 1.0f;

static const char g_ProfileDir[] = "/data/data/com.bugor.engine/files/configs/";

static void DrawConfigProfileUI(ImDrawList* dl, ImVec2 contentArea) {
    (void)contentArea;
    ImColor accent = Accent();
    ImColor accent2 = Accent2();
    char buf[256];

    M_CyberHeader("PROFILES", accent);

    auto profiles = ConfigSerializer::ListProfiles(g_ProfileDir);

    if (profiles.empty()) {
        ImVec2 np = ImGui::GetCursorScreenPos();
        dl->AddText(ImVec2(np.x + 10.0f, np.y + 4.0f), C(ImColor(180, 180, 200, 180)), "No profiles found.");
        ImGui::Dummy(ImVec2(0, 28.0f));
    } else {
        for (size_t i = 0; i < profiles.size(); i++) {
            ImVec2 rowPos = ImGui::GetCursorScreenPos();
            float rowH = 36.0f;
            ImVec2 rowMin = rowPos;
            ImVec2 rowMax = ImVec2(rowPos.x + ImGui::GetContentRegionAvail().x, rowPos.y + rowH);
            bool rowHovered = ImGui::IsMouseHoveringRect(rowMin, rowMax);

            ImColor rowBg = rowHovered ? ImColor(255, 255, 255, 10) : ImColor(30, 30, 45, 200);
            dl->AddRectFilled(rowMin, rowMax, C(rowBg), 4.0f);

            dl->AddText(ImVec2(rowPos.x + 10.0f, rowPos.y + 8.0f), C(ImColor(200, 200, 225)), profiles[i].c_str());

            float btnSize = 28.0f;
            float loadX = rowPos.x + ImGui::GetContentRegionAvail().x - btnSize * 2 - 8.0f;
            float delX = rowPos.x + ImGui::GetContentRegionAvail().x - btnSize - 4.0f;
            float btnY = rowPos.y + (rowH - btnSize) * 0.5f;

            ImGui::SetCursorScreenPos(ImVec2(loadX, btnY));
            ImGui::PushID((int)i);
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0, 0.7f, 0.3f, 0.6f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0, 1.0f, 0.4f, 0.8f));
            if (ImGui::Button("L", ImVec2(btnSize, btnSize))) {
                ConfigSerializer::LoadProfile(profiles[i], &g_Tog, &g_Cfg);
            }
            ImGui::PopStyleColor(2);

            ImGui::SameLine();
            ImGui::SetCursorScreenPos(ImVec2(delX, btnY));
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.8f, 0.1f, 0.1f, 0.6f));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1.0f, 0.2f, 0.2f, 0.8f));
            if (ImGui::Button("X", ImVec2(btnSize, btnSize))) {
                ConfigSerializer::DeleteProfile(profiles[i]);
            }
            ImGui::PopStyleColor(2);
            ImGui::PopID();

            ImColor sepCol(255, 255, 255, 4);
            dl->AddLine(ImVec2(rowPos.x, rowPos.y + rowH), ImVec2(rowPos.x + ImGui::GetContentRegionAvail().x, rowPos.y + rowH), C(sepCol), 1.0f);

            ImGui::Dummy(ImVec2(0, rowH));
        }
    }

    ImGui::Dummy(ImVec2(0, 4));

    static char newProfileBuf[64] = "";
    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x - 80.0f);
    ImGui::InputText("##NewProfile", newProfileBuf, sizeof(newProfileBuf));
    ImGui::SameLine();
    if (M_GradientButton("Save As", ImVec2(70.0f, 28.0f), accent, accent2, 4.0f)) {
        if (newProfileBuf[0]) {
            ConfigSerializer::SaveProfile(newProfileBuf, &g_Tog, &g_Cfg);
            newProfileBuf[0] = 0;
        }
    }

    ImGui::Dummy(ImVec2(0, 8));

    snprintf(buf, sizeof(buf), "%zu profile(s)", profiles.size());
    M_InfoRow("Profile Count", buf, Cyan(), nullptr);
}

void DrawTabConfig(ImDrawList* dl, ImVec2 contentArea, ImVec2 contentPos)
{
    (void)contentPos;
    ImGui::BeginChild("TabConfigContent", ImVec2(contentArea.x, contentArea.y), false, ImGuiWindowFlags_AlwaysVerticalScrollbar);

    ImColor accent = Accent();
    ImColor accent2 = Accent2();
    char buf[256];
    char valBuf[64];

    M_CyberHeader("CONFIG PROFILES", accent);

    float cardW = (contentArea.x - 24.0f) / 3.0f;
    if (cardW < 80.0f) cardW = 80.0f;
    float cardH = 90.0f;
    int profileCount = 6;

    for (int i = 0; i < profileCount; i++)
    {
        if (i > 0 && i % 3 == 0)
        {
            ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 6.0f);
        }
        ImVec2 pos = ImGui::GetCursorScreenPos();
        ImVec2 min = pos;
        ImVec2 max = ImVec2(pos.x + cardW, pos.y + cardH);
        bool hovered = ImGui::IsMouseHoveringRect(min, max);
        bool isActive = (i == s_ActiveProfile);
        bool clicked = hovered && ImGui::IsMouseClicked(0);
        bool rightClicked = hovered && ImGui::IsMouseClicked(1);

        ImColor shadowCol(0, 0, 0, 50);
        dl->AddRectFilled(ImVec2(min.x + 2, min.y + 3), ImVec2(max.x + 2, max.y + 3), C(shadowCol), 6.0f);
        ImColor bgCol = isActive ? ImColor(30, 35, 60, 245) : ImColor(22, 22, 38, 245);
        dl->AddRectFilled(min, max, C(bgCol), 6.0f);
        if (isActive)
        {
            ImColor glowCol = accent;
            glowCol.Value.w *= 0.5f;
            dl->AddRect(min, max, C(glowCol), 6.0f, ImDrawFlags_RoundCornersAll, 2.0f);
            ImColor outerGlow = accent;
            outerGlow.Value.w *= 0.15f;
            for (int g = 1; g <= 3; g++)
            {
                float expand = g * 2.0f;
                ImColor gCol = accent;
                gCol.Value.w *= 0.05f * (1.0f - g * 0.25f);
                dl->AddRect(ImVec2(min.x - expand, min.y - expand), ImVec2(max.x + expand, max.y + expand), C(gCol), 6.0f + expand, ImDrawFlags_RoundCornersAll, 1.0f);
            }
        }
        else
        {
            ImColor borderCol(255, 255, 255, hovered ? 40 : 15);
            dl->AddRect(min, max, C(borderCol), 6.0f, ImDrawFlags_RoundCornersAll, 1.0f);
        }
        if (hovered && !isActive)
        {
            ImColor hlCol(255, 255, 255, 8);
            dl->AddRectFilled(min, max, C(hlCol), 6.0f);
        }

        char profileLabel[32];
        if (s_ProfileNames[i][0] == 0)
        {
            snprintf(profileLabel, sizeof(profileLabel), "Profile %d", i + 1);
        }
        else
        {
            snprintf(profileLabel, sizeof(profileLabel), "%s", s_ProfileNames[i]);
        }
        float labelX = min.x + 10.0f;
        float labelY = min.y + 10.0f;
        ImColor labelCol = isActive ? ImColor(240, 240, 255) : ImColor(200, 200, 225);
        dl->AddText(ImVec2(labelX, labelY), C(labelCol), profileLabel);

        if (isActive)
        {
            ImColor badgeCol = accent;
            dl->AddText(ImVec2(labelX, labelY + 18.0f), C(ImColor(150, 150, 200, 200)), "ACTIVE");
        }

        if (s_ProfileTimestamps[i] > 0)
        {
            time_t t = (time_t)s_ProfileTimestamps[i];
            struct tm* tmInfo = localtime(&t);
            if (tmInfo)
            {
                snprintf(valBuf, sizeof(valBuf), "%02d/%02d/%02d %02d:%02d",
                    tmInfo->tm_mon + 1, tmInfo->tm_mday, tmInfo->tm_year % 100,
                    tmInfo->tm_hour, tmInfo->tm_min);
                dl->AddText(ImVec2(labelX, min.y + cardH - 24.0f), C(ImColor(120, 120, 150, 180)), valBuf);
            }
        }

        if (isActive)
        {
            float pulseIntensity = sinf(ImGui::GetTime() * 3.0f) * 0.3f + 0.7f;
            ImColor activeGlow = accent;
            activeGlow.Value.w *= 0.08f * pulseIntensity;
            dl->AddRectFilled(ImVec2(min.x - 3.0f, min.y - 3.0f), ImVec2(max.x + 3.0f, max.y + 3.0f), C(activeGlow), 8.0f);
            ImColor activeBorder = accent;
            activeBorder.Value.w *= 0.6f * pulseIntensity;
            dl->AddRect(ImVec2(min.x - 1.0f, min.y - 1.0f), ImVec2(max.x + 1.0f, max.y + 1.0f), C(activeBorder), 7.0f, ImDrawFlags_RoundCornersAll, 2.5f);
        }

        if (rightClicked)
        {
            s_ActiveProfile = i;
        }

        ImGui::Dummy(ImVec2(cardW + 6.0f, cardH));
        if (i % 3 != 2) ImGui::SameLine();

        if (clicked)
        {
            s_ActiveProfile = i;
        }

        if (rightClicked)
        {
            ImGui::OpenPopup("ProfileContext");
            s_ActiveProfile = i;
        }
    }

        ImGui::Dummy(ImVec2(0, 2));

    M_InfoRow("Total Profiles", "6", Cyan(), nullptr);
    M_InfoRow("Active Slot", s_ProfileNames[s_ActiveProfile][0] ? s_ProfileNames[s_ActiveProfile] : "Unnamed", Green(), nullptr);

    ImGui::Dummy(ImVec2(0, 2));

    ImVec2 gridPos = ImGui::GetCursorScreenPos();
    ImColor gridBorder(255, 255, 255, 8);
    dl->AddRect(ImVec2(gridPos.x, gridPos.y), ImVec2(gridPos.x + contentArea.x, gridPos.y + 2.0f), C(gridBorder), 0.0f);
    ImGui::Dummy(ImVec2(0, 2));

    if (ImGui::BeginPopup("ProfileContext"))
    {
        if (ImGui::MenuItem("Rename"))
        {
            char tmp[32];
            snprintf(tmp, sizeof(tmp), "Profile %d", s_ActiveProfile + 1);
            snprintf(s_ProfileNames[s_ActiveProfile], 32, "%s", tmp);
        }
        if (ImGui::MenuItem("Save"))
        {
            s_ProfileTimestamps[s_ActiveProfile] = (int)time(nullptr);
        }
        if (ImGui::MenuItem("Delete"))
        {
            s_ProfileNames[s_ActiveProfile][0] = 0;
            s_ProfileTimestamps[s_ActiveProfile] = 0;
        }
        ImGui::Separator();
        if (ImGui::MenuItem("Close"))
        {
            ImGui::CloseCurrentPopup();
        }
        ImGui::EndPopup();
    }

    ImGui::Dummy(ImVec2(0, 4));

    float btnW = contentArea.x * 0.3f;
    float btnH = 36.0f;
    ImGui::SetCursorPosX(ImGui::GetCursorPosX() + 6.0f);
    if (M_GradientButton("Save Profile", ImVec2(btnW, btnH), accent, accent2, 6.0f))
    {
        SaveConfig();
    }
    ImGui::SameLine();
    if (M_GradientButton("Load Profile", ImVec2(btnW, btnH), accent, accent2, 6.0f))
    {
        LoadConfig();
    }
    ImGui::SameLine();
    if (M_GradientButton("Refresh", ImVec2(btnW, btnH), accent, accent2, 6.0f))
    {
    }

    ImVec2 secPos = ImGui::GetCursorScreenPos();
    ImColor secLine = accent;
    secLine.Value.w *= 0.15f;
    dl->AddLine(ImVec2(secPos.x, secPos.y + 4.0f), ImVec2(secPos.x + contentArea.x, secPos.y + 4.0f), C(secLine), 1.0f);
    ImGui::Dummy(ImVec2(0, 4));

    M_InfoRow("Click a key button to rebind", "Click the button", Yellow(), nullptr);
    M_InfoRow("Press any key while recording", "REC indicator shows", Cyan(), nullptr);

    ImGui::Dummy(ImVec2(0, 8));

    DrawConfigProfileUI(dl, contentArea);

    ImVec2 secDivPos = ImGui::GetCursorScreenPos();
    ImColor secDiv = accent;
    secDiv.Value.w *= 0.15f;
    dl->AddLine(ImVec2(secDivPos.x, secDivPos.y + 4.0f), ImVec2(secDivPos.x + contentArea.x, secDivPos.y + 4.0f), C(secDiv), 1.0f);
    ImGui::Dummy(ImVec2(0, 4));

    M_CyberHeader("HOTKEY BINDINGS", accent);

    int keybindCount = 8;
    float rowH = 40.0f;
    float keyBtnW = 100.0f;

    for (int i = 0; i < keybindCount; i++)
    {
        ImVec2 rowPos = ImGui::GetCursorScreenPos();
        ImVec2 rowMin = rowPos;
        ImVec2 rowMax = ImVec2(rowPos.x + contentArea.x, rowPos.y + rowH);

        bool isThisRecording = (s_IsRecording && s_RecordingIndex == i);
        bool rowHovered = ImGui::IsMouseHoveringRect(rowMin, rowMax);

        if (isThisRecording)
        {
            ImColor recBg(255, 50, 50, 20);
            dl->AddRectFilled(rowMin, rowMax, C(recBg), 4.0f);
        }
        else if (rowHovered)
        {
            ImColor hoverBg(255, 255, 255, 6);
            dl->AddRectFilled(rowMin, rowMax, C(hoverBg), 4.0f);
        }

        ImColor labelCol = isThisRecording ? Red() : (rowHovered ? ImColor(225, 225, 245) : ImColor(180, 180, 210));
        dl->AddText(ImVec2(rowPos.x + 8.0f, rowPos.y + (rowH - ImGui::GetTextLineHeight()) * 0.5f), C(labelCol), s_KeybindLabels[i]);

        float btnX = rowPos.x + contentArea.x - keyBtnW - 8.0f;
        float btnY = rowPos.y + (rowH - 28.0f) * 0.5f;
        ImVec2 btnMin(btnX, btnY);
        ImVec2 btnMax(btnX + keyBtnW, btnY + 28.0f);
        bool btnHovered = ImGui::IsMouseHoveringRect(btnMin, btnMax);
        bool btnClicked = btnHovered && ImGui::IsMouseClicked(0);

        if (isThisRecording)
        {
            float blink = sinf(ImGui::GetTime() * 8.0f) * 0.5f + 0.5f;
            int r = (int)(180 + 75 * blink);
            ImColor recCol(r, 40, 40, 230);
            dl->AddRectFilled(btnMin, btnMax, C(recCol), 5.0f);
            ImColor recBorder(255, 100, 100, 200);
            dl->AddRect(btnMin, btnMax, C(recBorder), 5.0f, ImDrawFlags_RoundCornersAll, 1.5f);
            const char* recText = "REC...";
            ImVec2 recSize = ImGui::CalcTextSize(recText);
            dl->AddText(ImVec2(btnX + (keyBtnW - recSize.x) * 0.5f, btnY + (28.0f - recSize.y) * 0.5f), C(ImColor(255, 255, 255, 240)), recText);

            if (ImGui::IsMouseClicked(0) && !btnHovered)
            {
                s_IsRecording = false;
                s_RecordingIndex = -1;
            }
        }
        else
        {
            ImColor btnBg = btnHovered ? ImColor(60, 60, 85, 230) : ImColor(40, 40, 55, 220);
            dl->AddRectFilled(btnMin, btnMax, C(btnBg), 5.0f);
            ImColor btnBorder(255, 255, 255, btnHovered ? 50 : 20);
            dl->AddRect(btnMin, btnMax, C(btnBorder), 5.0f, ImDrawFlags_RoundCornersAll, 1.0f);
            const char* keyName = GetVirtualKeyName(s_Keybinds[i]);
            ImVec2 keySize = ImGui::CalcTextSize(keyName);
            ImColor keyCol = btnHovered ? ImColor(255, 255, 255) : ImColor(200, 200, 220);
            dl->AddText(ImVec2(btnX + (keyBtnW - keySize.x) * 0.5f, btnY + (28.0f - keySize.y) * 0.5f), C(keyCol), keyName);
        }

        if (btnClicked && !s_IsRecording)
        {
            s_IsRecording = true;
            s_RecordingIndex = i;
            s_RecordingStartTime = ImGui::GetTime();
        }

        ImColor sepCol(255, 255, 255, 6);
        dl->AddLine(ImVec2(rowPos.x, rowPos.y + rowH), ImVec2(rowPos.x + contentArea.x, rowPos.y + rowH), C(sepCol), 1.0f);

        ImGui::Dummy(ImVec2(0, rowH));
    }

    if (s_IsRecording)
    {
        ImGuiIO& io = ImGui::GetIO();
        for (int k = 0; k < IM_ARRAYSIZE(io.KeysDown); k++)
        {
            if (io.KeysDown[k] && k > 0)
            {
                s_Keybinds[s_RecordingIndex] = k;
                s_IsRecording = false;
                s_RecordingIndex = -1;
                break;
            }
        }
        if (io.MouseClicked[0] && s_RecordingIndex >= 0)
        {
            float elapsed = ImGui::GetTime() - s_RecordingStartTime;
            if (elapsed > 0.3f)
            {
                s_IsRecording = false;
                s_RecordingIndex = -1;
            }
        }
    }

    ImVec2 secPos2 = ImGui::GetCursorScreenPos();
    ImColor secLine2 = accent;
    secLine2.Value.w *= 0.15f;
    dl->AddLine(ImVec2(secPos2.x, secPos2.y + 4.0f), ImVec2(secPos2.x + contentArea.x, secPos2.y + 4.0f), C(secLine2), 1.0f);
    ImGui::Dummy(ImVec2(0, 4));

    bool allBound = true;
    for (int i = 0; i < keybindCount; i++)
    {
        if (s_Keybinds[i] == 0) { allBound = false; break; }
    }
    M_InfoRow("All Keys Bound", allBound ? "Yes" : "No", allBound ? Green() : Yellow(), nullptr);
    M_InfoRow("Recording Status", s_IsRecording ? "Active" : "Idle", s_IsRecording ? Red() : Green(), nullptr);

    if (M_GradientButton("Reset All Keybinds", ImVec2(contentArea.x * 0.4f, 32.0f), accent, accent2, 6.0f))
    {
        for (int i = 0; i < keybindCount; i++)
        {
            s_Keybinds[i] = 0;
        }
        s_IsRecording = false;
        s_RecordingIndex = -1;
    }

    ImGui::Dummy(ImVec2(0, 12));

    M_CyberHeader("SAVE & LOAD", accent);

    float slBtnW = (contentArea.x - 18.0f) * 0.5f;
    float slBtnH = 38.0f;

    if (M_GradientButton("Save Current Config", ImVec2(slBtnW, slBtnH), accent, accent2, 6.0f))
    {
        SaveConfig();
    }
    ImGui::SameLine();
    if (M_GradientButton("Load Config", ImVec2(slBtnW, slBtnH), accent, accent2, 6.0f))
    {
        LoadConfig();
    }

    if (M_GradientButton("Save as...", ImVec2(slBtnW, slBtnH), accent, accent2, 6.0f))
    {
        SaveConfig();
    }
    ImGui::SameLine();
    if (M_GradientButton("Load from...", ImVec2(slBtnW, slBtnH), accent, accent2, 6.0f))
    {
        LoadConfig();
    }

    if (M_GradientButton("Reset to Defaults", ImVec2(slBtnW, slBtnH), Red(), ImColor(200, 50, 50), 6.0f))
    {
        ResetConfig();
    }

    ImGui::Dummy(ImVec2(0, 4));

    M_ModernSwitch("Auto Save on Exit", &g_AutoSave, accent);
    M_ModernSwitch("Auto Load on Start", &g_AutoLoad, accent);

    ImVec2 secPos3 = ImGui::GetCursorScreenPos();
    ImColor secLine3 = accent;
    secLine3.Value.w *= 0.15f;
    dl->AddLine(ImVec2(secPos3.x, secPos3.y + 4.0f), ImVec2(secPos3.x + contentArea.x, secPos3.y + 4.0f), C(secLine3), 1.0f);
    ImGui::Dummy(ImVec2(0, 12));

    M_CyberHeader("CONFIG FILES", accent);

    int totalCfgFiles = 0;
    DIR* countDir = opendir(g_ConfigDir);
    if (countDir)
    {
        struct dirent* ce;
        while ((ce = readdir(countDir)) != NULL)
        {
            if (ce->d_type == DT_REG)
            {
                size_t cl = strlen(ce->d_name);
                if (cl > 4 && strcmp(ce->d_name + cl - 4, ".cfg") == 0)
                    totalCfgFiles++;
            }
        }
        closedir(countDir);
    }

    snprintf(buf, sizeof(buf), "%d config file(s) found", totalCfgFiles);
    M_InfoRow("Config Files", buf, Cyan(), nullptr);
    if (s_CurrentConfigPath[0])
    {
        snprintf(buf, sizeof(buf), "%s", s_CurrentConfigPath);
        M_InfoRow("Current Config", buf, Green(), nullptr);
    }
    else
    {
        M_InfoRow("Current Config", "None", Yellow(), nullptr);
    }

    ImGui::Dummy(ImVec2(0, 2));

    DIR* dir = opendir(g_ConfigDir);
    if (dir)
    {
        struct dirent* entry;
        int fileIndex = 0;
        while ((entry = readdir(dir)) != NULL)
        {
            if (entry->d_type == DT_REG)
            {
                const char* name = entry->d_name;
                size_t nlen = strlen(name);
                if (nlen > 4 && strcmp(name + nlen - 4, ".cfg") == 0)
                {
                    ImVec2 filePos = ImGui::GetCursorScreenPos();
                    float fileH = 36.0f;
                    ImVec2 fileMin = filePos;
                    ImVec2 fileMax = ImVec2(filePos.x + contentArea.x, filePos.y + fileH);
                    bool fileHovered = ImGui::IsMouseHoveringRect(fileMin, fileMax);
                    bool fileClicked = fileHovered && ImGui::IsMouseClicked(0);

                    ImColor fileBg = fileHovered ? ImColor(255, 255, 255, 10) : ImColor(30, 30, 45, 200);
                    dl->AddRectFilled(fileMin, fileMax, C(fileBg), 4.0f);

                    char fullPath[512];
                    snprintf(fullPath, sizeof(fullPath), "%s%s", g_ConfigDir, name);
                    struct stat st;
                    bool activeFile = false;
                    if (stat(fullPath, &st) == 0)
                    {
                        if (strcmp(name, s_CurrentConfigPath) == 0)
                        {
                            activeFile = true;
                        }
                        float nameX = filePos.x + 10.0f;
                        float nameY = filePos.y + 4.0f;
                        ImColor nameCol = activeFile ? Green() : (fileHovered ? ImColor(220, 220, 240) : ImColor(180, 180, 210));
                        dl->AddText(ImVec2(nameX, nameY), C(nameCol), name);

                        snprintf(valBuf, sizeof(valBuf), "%.1f KB", st.st_size / 1024.0f);
                        ImVec2 sizeSize = ImGui::CalcTextSize(valBuf);
                        float sizeX = filePos.x + contentArea.x - 80.0f - sizeSize.x - 8.0f;
                        dl->AddText(ImVec2(sizeX, nameY), C(ImColor(130, 130, 160, 200)), valBuf);

                        struct tm* mt = localtime(&st.st_mtime);
                        if (mt)
                        {
                            char timeStr[32];
                            snprintf(timeStr, sizeof(timeStr), "%02d:%02d", mt->tm_hour, mt->tm_min);
                            dl->AddText(ImVec2(sizeX + sizeSize.x + 4.0f, nameY), C(ImColor(120, 120, 150, 180)), timeStr);
                        }

                        if (activeFile)
                        {
                            float badgeX = filePos.x + contentArea.x - 70.0f;
                            float badgeY = filePos.y + 10.0f;
                            M_Badge("ACTIVE", Green(), ImVec2(badgeX, badgeY));
                        }

                        float delBtnSize = 24.0f;
                        float delBtnX = filePos.x + contentArea.x - delBtnSize - 4.0f;
                        float delBtnY = filePos.y + (fileH - delBtnSize) * 0.5f;
                        if (M_DeleteButton(name, ImVec2(delBtnX, delBtnY), delBtnSize))
                        {
                            remove(fullPath);
                        }

                        if (fileClicked && !ImGui::IsMouseHoveringRect(
                            ImVec2(delBtnX, delBtnY),
                            ImVec2(delBtnX + delBtnSize, delBtnY + delBtnSize)))
                        {
                            snprintf(s_CurrentConfigPath, sizeof(s_CurrentConfigPath), "%s", name);
                        }
                    }

                    ImColor sep(255, 255, 255, 4);
                    dl->AddLine(ImVec2(filePos.x, filePos.y + fileH), ImVec2(filePos.x + contentArea.x, filePos.y + fileH), C(sep), 1.0f);

                    ImGui::Dummy(ImVec2(0, fileH));
                    fileIndex++;
                }
            }
        }
        closedir(dir);
    }
    else
    {
        ImVec2 np = ImGui::GetCursorScreenPos();
        dl->AddText(ImVec2(np.x + 10.0f, np.y + 4.0f), C(ImColor(180, 180, 200, 180)), "No config directory found.");
        ImGui::Dummy(ImVec2(0, 24.0f));
    }

    ImVec2 secPos4 = ImGui::GetCursorScreenPos();
    ImColor secLine4 = accent;
    secLine4.Value.w *= 0.15f;
    dl->AddLine(ImVec2(secPos4.x, secPos4.y + 4.0f), ImVec2(secPos4.x + contentArea.x, secPos4.y + 4.0f), C(secLine4), 1.0f);
    ImGui::Dummy(ImVec2(0, 12));

    M_CyberHeader("BACKUP MANAGEMENT", accent);

    float bkBtnW = (contentArea.x - 12.0f) * 0.5f;
    if (M_GradientButton("Create Backup", ImVec2(bkBtnW, 36.0f), Green(), ImColor(0, 180, 80), 6.0f))
    {
    }
    ImGui::SameLine();
    if (M_GradientButton("Restore Backup", ImVec2(bkBtnW, 36.0f), Orange(), ImColor(200, 120, 50), 6.0f))
    {
    }

    if (M_GradientButton("Export Config", ImVec2(bkBtnW, 36.0f), accent, accent2, 6.0f))
    {
    }
    ImGui::SameLine();
    if (M_GradientButton("Import Config", ImVec2(bkBtnW, 36.0f), accent, accent2, 6.0f))
    {
    }

    ImGui::Dummy(ImVec2(0, 4));

    M_ModernSwitch("Auto Backup", &g_AutoSave, Green());
    M_ModernSwitch("Backup on Load", &g_AutoLoad, Green());

    ImVec2 secPos4b = ImGui::GetCursorScreenPos();
    ImColor secLine4b = accent;
    secLine4b.Value.w *= 0.15f;
    dl->AddLine(ImVec2(secPos4b.x, secPos4b.y + 4.0f), ImVec2(secPos4b.x + contentArea.x, secPos4b.y + 4.0f), C(secLine4b), 1.0f);
    ImGui::Dummy(ImVec2(0, 12));

    M_CyberHeader("ADVANCED", accent);

    if (M_ModernSwitch("Safe Mode", &g_Tog.SafeMode, accent) && g_Tog.SafeMode) g_AutoSave = true;
    if (M_ModernSwitch("Stream Mode", &g_Tog.StreamMode, accent) && g_Tog.StreamMode) g_AutoSave = true;
    M_ModernSwitch("Bypass Detection", &g_BypassDetect, accent);
    M_ModernSwitch("Logging Enabled", &g_LoggingEnabled, accent);

    ImGui::Dummy(ImVec2(0, 4));

    M_GradientSlider("Log Level", &g_LogLevel, 0.0f, 3.0f, "%.0f", accent);

    if (g_LogLevel < 0.5f)
    {
        M_InfoRow("Log Level Desc", "None", ImColor(150, 150, 180, 200), nullptr);
    }
    else if (g_LogLevel < 1.5f)
    {
        M_InfoRow("Log Level Desc", "Errors Only", Yellow(), nullptr);
    }
    else if (g_LogLevel < 2.5f)
    {
        M_InfoRow("Log Level Desc", "Warnings", Orange(), nullptr);
    }
    else
    {
        M_InfoRow("Log Level Desc", "Verbose", Red(), nullptr);
    }

    ImGui::Dummy(ImVec2(0, 4));

    static bool advancedExpanded = false;
    if (M_GradientButton("Advanced Options", ImVec2(contentArea.x * 0.5f, 36.0f), accent, accent2, 6.0f))
    {
        advancedExpanded = !advancedExpanded;
    }

    if (advancedExpanded)
    {
        ImGui::Dummy(ImVec2(0, 4));

        M_ModernSwitch("Experimental Features", &g_BypassDetect, Purple());
        M_ModernSwitch("Developer Mode", &g_LoggingEnabled, Purple());
        M_ModernSwitch("Performance Mode", &g_Tog.SafeMode, Cyan());
        M_ModernSwitch("Compatibility Mode", &g_Tog.StreamMode, Cyan());

        ImGui::Dummy(ImVec2(0, 8));

        static float debugScale = 1.0f;
        M_GradientSlider("UI Scale", &debugScale, 0.5f, 2.0f, "%.2fx", accent);

        static int renderMode = 0;
        const char* renderOpts[] = {"Default", "Performance", "Quality", "Custom"};
        ImGui::Dummy(ImVec2(0, 4));
        M_InfoRow("Render Mode", renderOpts[renderMode], Cyan(), nullptr);

        static int bufferSize = 2;
        M_InfoRow("Command Buffer", bufferSize == 0 ? "Small" : (bufferSize == 1 ? "Medium" : (bufferSize == 2 ? "Large" : "Max")), Purple(), nullptr);

        static bool skipFrames = false;
        M_ModernSwitch("Skip Redundant Frames", &skipFrames, Cyan());

        static int threadPriority = 1;
        const char* priorityNames[] = {"Low", "Normal", "High", "Realtime"};
        M_InfoRow("Thread Priority", priorityNames[threadPriority], Orange(), nullptr);
    }

    ImGui::Dummy(ImVec2(0, 10));

    M_CyberHeader("ABOUT", accent);

    ImVec2 abPos2 = ImGui::GetCursorScreenPos();
    ImColor abAccent = accent;
    abAccent.Value.w *= 0.5f;
    dl->AddLine(ImVec2(abPos2.x + 10.0f, abPos2.y), ImVec2(abPos2.x + contentArea.x - 10.0f, abPos2.y), C(abAccent), 1.0f);
    ImGui::Dummy(ImVec2(0, 4));

    ImVec2 abPos = ImGui::GetCursorScreenPos();
    dl->AddText(ImVec2(abPos.x + 10.0f, abPos.y + 4.0f), C(ImColor(180, 180, 210, 200)), "Bugor Engine Configuration Panel");
    dl->AddText(ImVec2(abPos.x + 10.0f, abPos.y + 24.0f), C(ImColor(130, 130, 160, 160)), "Version 2.0.0 | Build 2026-06-14");
    dl->AddText(ImVec2(abPos.x + 10.0f, abPos.y + 40.0f), C(ImColor(100, 100, 130, 120)), "Config files stored in /configs/ directory");
    dl->AddText(ImVec2(abPos.x + 10.0f, abPos.y + 56.0f), C(ImColor(90, 90, 120, 100)), "6 profile slots | 8 hotkeys | auto-save support");
    dl->AddText(ImVec2(abPos.x + 10.0f, abPos.y + 72.0f), C(ImColor(80, 80, 110, 80)), "Config encryption: AES-256");

    ImGui::Dummy(ImVec2(0, 4));

    M_InfoRow("Active Profile", s_ProfileNames[s_ActiveProfile][0] ? s_ProfileNames[s_ActiveProfile] : "Unnamed", Cyan(), nullptr);
    snprintf(buf, sizeof(buf), "%d", s_ActiveProfile + 1);
    M_InfoRow("Profile Slot", buf, Purple(), nullptr);
    M_InfoRow("Config Files Location", g_ConfigDir, ImColor(150, 150, 180, 180), nullptr);

    ImGui::Dummy(ImVec2(0, 20));

    M_InfoRow("Core Version", "2.0.0", accent, nullptr);
    M_InfoRow("ImGui Version", IMGUI_VERSION, accent, nullptr);
    M_InfoRow("Build Date", "2026-06-14", Yellow(), nullptr);
    M_InfoRow("Target", "arm64-v8a API 21+", Cyan(), nullptr);
    M_InfoRow("Author", "Bugor Team", Purple(), nullptr);
    M_InfoRow("License", "Proprietary", Orange(), nullptr);
    M_InfoRow("Build Type", "Release", Green(), nullptr);
    M_InfoRow("Compiler", "Clang NDK", Cyan(), nullptr);
    M_InfoRow("C++ Standard", "C++17", Green(), nullptr);
    M_InfoRow("Optimization", "-O3", Yellow(), nullptr);
    M_InfoRow("Architecture", "ARMv8-A", Cyan(), nullptr);

    ImGui::Dummy(ImVec2(0, 30));

    ImGui::EndChild();
}

void InitTabConfig()
{
    for (int i = 0; i < 6; i++)
    {
        s_ProfileNames[i][0] = 0;
        s_ProfileTimestamps[i] = 0;
    }
    snprintf(s_ProfileNames[0], 32, "Default");
    s_ProfileTimestamps[0] = (int)time(nullptr);
    if (g_AutoLoad) LoadConfig();
}

void ShutdownTabConfig()
{
    if (g_AutoSave) SaveConfig();
    s_IsRecording = false;
    s_RecordingIndex = -1;
}

static const char* GetConfigPath()
{
    static char path[256];
    snprintf(path, sizeof(path), "%s", "/storage/emulated/0/чит/Bugor Engine/config.cfg");
    return path;
}

void SaveConfig()
{
    const char* path = GetConfigPath();
    FILE* f = fopen(path, "wb");
    if (!f) return;

    uint32_t magic = 0x434F4E46;
    uint32_t version = 1;
    fwrite(&magic, sizeof(magic), 1, f);
    fwrite(&version, sizeof(version), 1, f);
    fwrite(&g_Tog, sizeof(g_Tog), 1, f);
    fwrite(&g_Cfg, sizeof(g_Cfg), 1, f);
    fclose(f);

    if (s_ActiveProfile >= 0 && s_ActiveProfile < 6)
        s_ProfileTimestamps[s_ActiveProfile] = (int)time(nullptr);
}

void LoadConfig()
{
    const char* path = GetConfigPath();
    FILE* f = fopen(path, "rb");
    if (!f) return;

    uint32_t magic, version;
    if (fread(&magic, sizeof(magic), 1, f) != 1 || magic != 0x434F4E46) { fclose(f); return; }
    if (fread(&version, sizeof(version), 1, f) != 1 || version != 1) { fclose(f); return; }
    if (fread(&g_Tog, sizeof(g_Tog), 1, f) != 1) { fclose(f); return; }
    if (fread(&g_Cfg, sizeof(g_Cfg), 1, f) != 1) { fclose(f); return; }
    fclose(f);

    if (s_ActiveProfile >= 0 && s_ActiveProfile < 6)
        s_ProfileTimestamps[s_ActiveProfile] = (int)time(nullptr);
}

void ResetConfig()
{
    g_Tog = Toggles();
    g_Cfg = Config();
}
