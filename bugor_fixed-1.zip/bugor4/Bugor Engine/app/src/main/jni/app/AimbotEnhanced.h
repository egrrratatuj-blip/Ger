#pragma once
#include "Config.h"
#include "MemoryIO.h"
#include "GameOffsets.h"
#include "ESP.h"
#include <vector>
#include <array>
#include <string>
#include <cmath>
#include <algorithm>
#include <functional>
#include <atomic>
#include <mutex>
#include <chrono>
#include <random>
#include <map>
#include <set>
#include <deque>
#include <queue>
#include <optional>

enum class AimbotMode {
    Normal = 0,
    Silent = 1,
    PSilent = 2,
    Legit = 3,
    Assisted = 4,
    Auto = 5
};

enum class HitboxSelection {
    Head = 0,
    Neck = 1,
    Chest = 2,
    Stomach = 3,
    Pelvis = 4,
    Legs = 5,
    Feet = 6,
    Best = 7,
    Random = 8,
    AutoAim = 9
};

enum class AimPriority {
    Distance = 0,
    FOV = 1,
    Health = 2,
    Crosshair = 3,
    Visibility = 4,
    Velocity = 5,
    Angle = 6,
    Random = 7,
    Smart = 8,
    Threat = 9
};

enum class TriggerMode {
    Disabled = 0,
    Hold = 1,
    Toggle = 2,
    Auto = 3,
    OnScope = 4,
    OnTarget = 5
};

enum class RCSMode {
    Disabled = 0,
    Standalone = 1,
    AimbotIntegrated = 2,
    Hybrid = 3,
    Adaptive = 4,
    WeaponSpecific = 5
};

enum class VisibilityCheck {
    None = 0,
    Raycast = 1,
    TraceLine = 2,
    Engine = 3,
    Distance = 4,
    Hybrid = 5
};

struct AimbotEnhancedTarget {
    int index;
    float distance;
    float fovDistance;
    float pitch;
    float yaw;
    float angle;
    D3DVector position;
    D3DVector headPosition;
    D3DVector velocity;
    D3DVector aimPoint;
    bool isVisible;
    bool isValid;
    bool isBot;
    uintptr_t address;
    int health;
    int maxHealth;
    int teamID;
    int priority;
    float lastSeenTime;
    float confidence;
    float latency;
    HitboxSelection hitbox;
    D3DVector bonePositions[128];
    int boneCount;
    char playerName[64];
    char weaponName[32];
    bool isScoping;
    bool isReloading;
    bool isShooting;
    bool isMoving;
    float movementSpeed;
    float aimPitch;
    float aimYaw;
    uint64_t playerId;
    int weaponTier;
};

struct HumanizedAimSettings {
    float smoothness;
    float prediction;
    float reactionTime;
    float errorMargin;
    float maxCorrection;
    float minMovement;
    float maxMovement;
    float noiseAmount;
    float noiseFrequency;
    bool humanizeCurve;
    bool addRandomDelay;
    bool simulateAimPunch;
    bool simulateWeaponSway;
    bool simulateBreathing;
    bool simulateFatigue;
    bool simulateFlickering;
    float targetSwitchDelay;
    float lockOnDelay;
    float unlockDelay;
    float fovReduction;
    float smoothIncrease;
    float smoothDecrease;
    int minShotsBeforeSwitch;
    int maxShotsBeforeSwitch;
};

struct RecoilControlSettings {
    RCSMode mode;
    float verticalScale;
    float horizontalScale;
    float verticalOffset;
    float horizontalOffset;
    float smoothness;
    float prediction;
    int startAfterShots;
    bool compensateSpray;
    bool adaptiveCompensation;
    bool weaponSpecific;
    float verticalRecoilPattern[30];
    float horizontalRecoilPattern[30];
    int patternLength;
    float patternScale;
    bool randomizeCompensation;
    float randomizationAmount;
    float recoverySpeed;
    bool autoConfigure;
    std::map<std::string, float> weaponMultipliers;
};

struct TriggerbotSettings {
    TriggerMode mode;
    int delayMin;
    int delayMax;
    float fovLimit;
    float rangeLimit;
    bool requireVisible;
    bool friendlyFire;
    bool onlyOnScope;
    bool autoScope;
    bool shootThroughWalls;
    int burstCount;
    int burstDelay;
    float hitboxPriority;
    bool checkWeapon;
    bool checkAmmo;
    bool recoilCompensation;
    std::vector<std::string> whitelistedWeapons;
    std::vector<std::string> blacklistedWeapons;
    bool movementCheck;
    bool holdToActivate;
    int activationKey;
    std::chrono::milliseconds minInterval;
};

struct AimbotStatistics {
    int totalShots;
    int hits;
    int misses;
    int headshots;
    int kills;
    int targetSwitches;
    float accuracy;
    float averageTimeToKill;
    float longestShot;
    float closestShot;
    std::chrono::steady_clock::time_point startTime;
    std::chrono::steady_clock::time_point lastTargetSwitch;
    std::map<std::string, int> weaponStats;
    std::map<int, int> hitboxStats;
    std::deque<float> recentAccuracies;
    std::deque<float> recentDistances;
};

class AimbotEnhanced {
public:
    AimbotEnhanced(MemoryIO *mem, GameOffsets *offsets, Config *cfg, Toggles *tog);
    ~AimbotEnhanced();

    void update();
    void aim();
    void render(ImDrawList *draw);
    void reset();

    void findTarget();
    void acquireTarget();
    void releaseTarget();
    void switchTarget();
    void lockTarget(int index);

    void aimAtTarget();
    void silentAim();
    void pSilentAim();
    void legitAim();
    void assistedAim();
    void autoAim();

    void applySilentAim(float pitch, float yaw);
    void applySilentAimSilent(float pitch, float yaw);
    void applyLegitAim(float targetPitch, float targetYaw);
    void applyHumanizedMovement(float targetPitch, float targetYaw);
    void applyRecoilControl();

    float calculatePitch(D3DVector from, D3DVector to);
    float calculateYaw(D3DVector from, D3DVector to);
    float calculateDistance(D3DVector a, D3DVector b);
    float calculateFOV(float pitch, float yaw, float targetPitch, float targetYaw);
    float calculateSmoothFactor(float distance, float fov);

    D3DVector getPredictedPosition(AimbotEnhancedTarget &target, float bulletSpeed, float gravity);
    D3DVector getAimPoint(AimbotEnhancedTarget &target, HitboxSelection hitbox);
    D3DVector getHitboxPosition(AimbotEnhancedTarget &target, HitboxSelection hitbox);
    D3DVector getBonePosition(EnhancedPlayerData &player, int boneID);

    HitboxSelection selectHitbox(AimbotEnhancedTarget &target);
    AimPriority selectPriority(AimbotEnhancedTarget &target);

    bool isTargetValid(const AimbotEnhancedTarget &target);
    bool isTargetVisible(const AimbotEnhancedTarget &target);
    bool isTargetInFOV(const AimbotEnhancedTarget &target);
    bool isTargetInRange(const AimbotEnhancedTarget &target);
    bool isLineOfSightClear(D3DVector from, D3DVector to);
    bool isWeaponReady();
    bool isTargetOnScreen(AimbotEnhancedTarget &target);
    bool checkIsLocked() const;

    void triggerbot();
    void autoShoot();
    void autoFire();
    void triggerOnTarget();
    void delayedShot(int delay);

    void checkVisibility();
    void updateTargets();
    void sortTargets();
    void filterTargets();
    void prioritizeTargets();

    void updateHitbox();
    void updateRCS();
    void updatePrediction();
    void updateSmoothing();

    void setMode(AimbotMode mode);
    void setHitbox(HitboxSelection hitbox);
    void setPriority(AimPriority priority);
    void setFOV(float fov);
    void setRange(float range);
    void setSmoothness(float smooth);
    void setPrediction(float pred);

    AimbotMode getMode() const;
    HitboxSelection getHitbox() const;
    AimPriority getPriority() const;
    float getFOV() const;
    float getRange() const;
    float getSmoothness() const;
    float getPrediction() const;

    AimbotEnhancedTarget getCurrentTarget() const;
    AimbotEnhancedTarget getBestTarget() const;
    std::vector<AimbotEnhancedTarget> getTargets() const;
    AimbotEnhancedTarget getTarget(int index) const;
    int getTargetCount() const;

    AimbotStatistics getStatistics() const;
    void resetStatistics();
    void updateStatistics(bool hit, bool headshot);

    HumanizedAimSettings getHumanizedSettings() const;
    void setHumanizedSettings(const HumanizedAimSettings &settings);

    TriggerbotSettings getTriggerbotSettings() const;
    void setTriggerbotSettings(const TriggerbotSettings &settings);

    RecoilControlSettings getRCS() const;
    void setRCS(const RecoilControlSettings &settings);

    void setResolverEnabled(bool enable);
    bool isResolverEnabled() const;

    void setMultitargetEnabled(bool enable);
    bool isMultitargetEnabled() const;
    void cycleTarget();
    int getCurrentTargetIndex() const;

    void drawAimbotFOV(ImDrawList *draw);
    void drawTargetInfo(ImDrawList *draw, AimbotEnhancedTarget &target);
    void drawTargetLine(ImDrawList *draw, AimbotEnhancedTarget &target);
    void drawHitbox(ImDrawList *draw, AimbotEnhancedTarget &target);
    void drawStatistics(ImDrawList *draw);

    bool worldToScreen(D3DVector world, float *x, float *y);
    bool isVisible(D3DVector from, D3DVector to, uintptr_t targetEntity);

    void setPlayerData(EnhancedPlayerData *data, int count);

private:
    MemoryIO *mem;
    GameOffsets *offsets;
    Config *cfg;
    Toggles *tog;

    AimbotMode currentMode;
    HitboxSelection currentHitbox;
    AimPriority currentPriority;

    AimbotEnhancedTarget currentTarget;
    AimbotEnhancedTarget bestTarget;
    std::vector<AimbotEnhancedTarget> targets;

    AimbotStatistics stats;
    HumanizedAimSettings humanizedSettings;
    TriggerbotSettings triggerbotSettings;
    RecoilControlSettings rcsSettings;

    float fov;
    float range;
    float smoothness;
    float prediction;
    float bulletSpeed;
    float gravity;

    float lastPitch;
    float lastYaw;
    float currentPitch;
    float currentYaw;
    float smoothPitch;
    float smoothYaw;

    std::atomic<bool> isLocked;
    bool resolverEnabled;
    bool multitargetEnabled;
    int currentTargetIndex;
    int localPlayerID;
    float spreadLimit;

    int shotsFired;
    int consecutiveHits;
    int consecutiveMisses;

    std::chrono::steady_clock::time_point lastShot;
    std::chrono::steady_clock::time_point lastTargetChange;
    std::chrono::steady_clock::time_point aimStartTime;
    std::atomic<bool> delayedShotPending;
    std::chrono::steady_clock::time_point delayedShotFireTime;

    float recoilPitch;
    float recoilYaw;
    int rcsShotsFired;
    std::array<float, 30> currentRecoilPattern;
    int currentPatternIndex;

    std::mutex aimMutex;
    std::atomic<bool> updating;
    std::atomic<bool> aiming;

    EnhancedPlayerData *playerData;
    int playerCount;
    int localPlayerIndex;

    std::random_device rd;
    std::mt19937_64 rng;

    float screenWidth;
    float screenHeight;
    float screenCenterX;
    float screenCenterY;

    std::chrono::steady_clock::time_point lastUpdate;
    std::chrono::steady_clock::time_point lastAim;
    float deltaTime;

    void checkDelayedShot();
    void updateLocalPlayer();
    void updateTargetPosition(AimbotEnhancedTarget &target);
    void updateTargetVisibility(AimbotEnhancedTarget &target);
    void updateTargetPriority(AimbotEnhancedTarget &target);

    D3DVector getCameraPosition();
    D3DVector getCameraRotation();
    float getCameraFOV();
    void setCameraRotation(float pitch, float yaw);

    void resolvePlayerAnimation(AimbotEnhancedTarget &target);
    void onTargetAcquired(AimbotEnhancedTarget &target);
    void onTargetReleased();
    void onShot();

    bool canShoot();
    bool hasAmmo();
    int getAmmoCount();
    int getMaxAmmo();
    float getFireRate();

    float applySmoothing(float current, float target, float smoothFactor);
    float applyCurve(float value, float curveFactor);
    float applyDeadzone(float value, float deadzone);
    float applyRandomization(float value, float amount);
    D3DVector applySpread(D3DVector aimPoint, float spread);

    void updateDeltaTime();
    void updateScreenDimensions();

    bool isKeyPressed(int key) const;
    bool isButtonPressed(int button) const;
};

#define AIMBOT_EPSILON 0.001f
#define AIMBOT_PI 3.14159265358979323846f
#define AIMBOT_DEG2RAD(x) ((x) * AIMBOT_PI / 180.0f)
#define AIMBOT_RAD2DEG(x) ((x) * 180.0f / AIMBOT_PI)
#define AIMBOT_CLAMP(val, min, max) (std::max(min, std::min(max, val)))
#define AIMBOT_NORMALIZE_YAW(yaw) (fmodf(yaw + 180.0f, 360.0f) - 180.0f)
#define AIMBOT_NORMALIZE_PITCH(pitch) (fmodf(pitch + 90.0f, 180.0f) - 90.0f)
