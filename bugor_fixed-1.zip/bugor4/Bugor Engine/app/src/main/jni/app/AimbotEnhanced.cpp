#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "AimbotEnhanced.h"
#include "MathUtils.h"
#include "imgui.h"
#include "imgui_internal.h"
#include <thread>
#include <chrono>
#include <cstdio>
#include <cstring>

AimbotEnhanced::AimbotEnhanced(MemoryIO *m, GameOffsets *o, Config *c, Toggles *t)
    : mem(m), offsets(o), cfg(c), tog(t),
      currentMode(AimbotMode::Legit), currentHitbox(HitboxSelection::Head),
      currentPriority(AimPriority::FOV),
      fov(350.0f), range(500.0f), smoothness(5.0f), prediction(1.0f),
      bulletSpeed(800.0f), gravity(9.81f),
      lastPitch(0), lastYaw(0), currentPitch(0), currentYaw(0),
      smoothPitch(0), smoothYaw(0),
      resolverEnabled(false), multitargetEnabled(false),
      currentTargetIndex(-1), localPlayerID(0), spreadLimit(5.0f),
      shotsFired(0), consecutiveHits(0), consecutiveMisses(0),
      recoilPitch(0), recoilYaw(0), rcsShotsFired(0), currentPatternIndex(0),
      playerData(nullptr), playerCount(0), localPlayerIndex(-1),
      rng(std::random_device{}()),
      screenWidth(0), screenHeight(0), screenCenterX(0), screenCenterY(0),
      deltaTime(0.016f) {
    isLocked.store(false);
    updating.store(false);
    aiming.store(false);
    delayedShotPending.store(false);
    lastShot = std::chrono::steady_clock::now();
    lastTargetChange = std::chrono::steady_clock::now();
    aimStartTime = std::chrono::steady_clock::now();
    lastUpdate = std::chrono::steady_clock::now();
    lastAim = std::chrono::steady_clock::now();
    memset(&currentRecoilPattern, 0, sizeof(currentRecoilPattern));
    humanizedSettings.smoothness = 5.0f;
    humanizedSettings.prediction = 1.0f;
    humanizedSettings.reactionTime = 0.15f;
    humanizedSettings.errorMargin = 0.5f;
    humanizedSettings.maxCorrection = 5.0f;
    humanizedSettings.minMovement = 0.1f;
    humanizedSettings.maxMovement = 1.0f;
    humanizedSettings.noiseAmount = 0.3f;
    humanizedSettings.humanizeCurve = true;
    humanizedSettings.addRandomDelay = true;
    humanizedSettings.simulateBreathing = true;
    humanizedSettings.simulateWeaponSway = true;
    humanizedSettings.targetSwitchDelay = 0.3f;
    humanizedSettings.lockOnDelay = 0.1f;
    humanizedSettings.minShotsBeforeSwitch = 3;
    humanizedSettings.maxShotsBeforeSwitch = 8;
    rcsSettings.mode = RCSMode::Hybrid;
    rcsSettings.verticalScale = 0.6f;
    rcsSettings.horizontalScale = 0.4f;
    rcsSettings.smoothness = 3.0f;
    rcsSettings.startAfterShots = 2;
    rcsSettings.patternLength = 30;
    rcsSettings.adaptiveCompensation = true;
    triggerbotSettings.mode = TriggerMode::Disabled;
    triggerbotSettings.delayMin = 50;
    triggerbotSettings.delayMax = 150;
    triggerbotSettings.fovLimit = 5.0f;
    triggerbotSettings.rangeLimit = 300.0f;
    triggerbotSettings.requireVisible = true;
    triggerbotSettings.burstCount = 1;
    triggerbotSettings.minInterval = std::chrono::milliseconds(100);
    stats.startTime = std::chrono::steady_clock::now();
}

AimbotEnhanced::~AimbotEnhanced() {
    reset();
}

void AimbotEnhanced::update() {
    if (updating.exchange(true)) return;
    updateDeltaTime();
    updateLocalPlayer();
    updateTargets();
    filterTargets();
    sortTargets();
    prioritizeTargets();
    checkDelayedShot();
    if (tog->Aimbot && !targets.empty()) {
        findTarget();
        triggerbot();
        switch (currentMode) {
            case AimbotMode::Silent: silentAim(); break;
            case AimbotMode::PSilent: pSilentAim(); break;
            case AimbotMode::Legit: legitAim(); break;
            case AimbotMode::Assisted: assistedAim(); break;
            case AimbotMode::Auto: autoAim(); break;
            default: aimAtTarget(); break;
        }
        if (tog->AimbotAutoFire) autoFire();
    }
    lastUpdate = std::chrono::steady_clock::now();
    updating = false;
}

void AimbotEnhanced::aim() {
    if (!tog->Aimbot || bestTarget.index < 0) return;
    switch (currentMode) {
        case AimbotMode::Silent: silentAim(); break;
        case AimbotMode::PSilent: pSilentAim(); break;
        case AimbotMode::Legit: legitAim(); break;
        default: aimAtTarget(); break;
    }
}

void AimbotEnhanced::render(ImDrawList *draw) {
    if (!draw) return;
    screenWidth = ImGui::GetIO().DisplaySize.x;
    screenHeight = ImGui::GetIO().DisplaySize.y;
    screenCenterX = screenWidth / 2.0f;
    screenCenterY = screenHeight / 2.0f;
    if (tog->AimbotDrawFOV) drawAimbotFOV(draw);
    if (tog->AimbotDrawTarget && currentTarget.index >= 0) drawTargetInfo(draw, currentTarget);
    if (tog->AimbotTargetLine && currentTarget.index >= 0) drawTargetLine(draw, currentTarget);
    if (tog->ShowInfo) drawStatistics(draw);
}

void AimbotEnhanced::reset() {
    std::lock_guard<std::mutex> lock(aimMutex);
    currentTargetIndex = -1;
    isLocked = false;
    memset(&currentTarget, 0, sizeof(currentTarget));
    memset(&bestTarget, 0, sizeof(bestTarget));
    targets.clear();
    shotsFired = 0;
    consecutiveHits = 0;
    consecutiveMisses = 0;
    recoilPitch = 0;
    recoilYaw = 0;
    rcsShotsFired = 0;
    smoothPitch = 0;
    smoothYaw = 0;
    localPlayerID = 0;
}

void AimbotEnhanced::findTarget() {
    if (fov <= 0) {
        if (isLocked) releaseTarget();
        return;
    }
    if (isLocked && currentTarget.index >= 0) {
        bool stillValid = false;
        for (auto &t : targets) {
            if (t.index == currentTarget.index && t.isValid && t.health > 0) {
                stillValid = true;
                break;
            }
        }
        if (!stillValid) {
            releaseTarget();
        }
    }
    bestTarget = AimbotEnhancedTarget{};
    bestTarget.fovDistance = fov;
    bestTarget.distance = range;
    for (auto &target : targets) {
        if (!isTargetValid(target)) continue;
        if (!isTargetInRange(target)) continue;
        if (!isTargetInFOV(target)) continue;
        float currentFOV = calculateFOV(currentPitch, currentYaw, target.pitch, target.yaw);
        float currentDist = target.distance;
        bool better = false;
        switch (currentPriority) {
            case AimPriority::Distance: better = currentDist < bestTarget.distance; break;
            case AimPriority::FOV: better = currentFOV < bestTarget.fovDistance; break;
            case AimPriority::Health: better = target.health < bestTarget.health; break;
            case AimPriority::Crosshair: better = currentFOV < bestTarget.fovDistance * 0.5f; break;
            case AimPriority::Visibility: better = target.isVisible && !bestTarget.isVisible; break;
            case AimPriority::Velocity:
                better = target.movementSpeed < bestTarget.movementSpeed;
                break;
            case AimPriority::Smart:
                better = (currentFOV < bestTarget.fovDistance * 1.5f) &&
                         (target.distance < bestTarget.distance * 1.2f);
                break;
            case AimPriority::Threat: better = target.weaponTier > bestTarget.weaponTier; break;
            default: better = currentFOV < bestTarget.fovDistance; break;
        }
        if (better || bestTarget.index < 0) {
            bestTarget = target;
            bestTarget.fovDistance = currentFOV;
        }
    }
    if (bestTarget.index >= 0) {
        if (bestTarget.index != currentTargetIndex) {
            onTargetReleased();
        }
        currentTarget = bestTarget;
        currentTargetIndex = bestTarget.index;
        smoothPitch = currentPitch;
        smoothYaw = currentYaw;
        aimStartTime = std::chrono::steady_clock::now();
        if (!isLocked) {
            isLocked = true;
            onTargetAcquired(currentTarget);
        }
    } else {
        if (isLocked) {
            releaseTarget();
        }
    }
}

void AimbotEnhanced::acquireTarget() {
    if (bestTarget.index >= 0) {
        currentTarget = bestTarget;
        currentTargetIndex = bestTarget.index;
        isLocked = true;
        onTargetAcquired(currentTarget);
    }
}

void AimbotEnhanced::releaseTarget() {
    isLocked = false;
    currentTargetIndex = -1;
    onTargetReleased();
}

void AimbotEnhanced::switchTarget() {
    if (!multitargetEnabled) return;
    cycleTarget();
}

void AimbotEnhanced::lockTarget(int index) {
    if (index < 0 || index >= (int)targets.size()) return;
    currentTarget = targets[index];
    currentTargetIndex = index;
    isLocked = true;
    onTargetAcquired(currentTarget);
}

void AimbotEnhanced::aimAtTarget() {
    if (!isLocked || currentTarget.index < 0) return;
    if (!isTargetValid(currentTarget)) { releaseTarget(); return; }
    float targetPitch = calculatePitch(offsets->CameraPos, currentTarget.aimPoint);
    float targetYaw = calculateYaw(offsets->CameraPos, currentTarget.aimPoint);
    float pitchDiff = AIMBOT_NORMALIZE_PITCH(targetPitch - currentPitch);
    float yawDiff = AIMBOT_NORMALIZE_YAW(targetYaw - currentYaw);
    if (fabs(pitchDiff) > spreadLimit) {
        pitchDiff = (pitchDiff > 0 ? 1 : -1) * spreadLimit;
    }
    if (fabs(yawDiff) > spreadLimit) {
        yawDiff = (yawDiff > 0 ? 1 : -1) * spreadLimit;
    }
    targetPitch = currentPitch + pitchDiff;
    targetYaw = currentYaw + yawDiff;
    smoothPitch = applySmoothing(smoothPitch, targetPitch, smoothness);
    smoothYaw = applySmoothing(smoothYaw, targetYaw, smoothness);
    setCameraRotation(smoothPitch, smoothYaw);
}

void AimbotEnhanced::silentAim() {
    if (!isLocked || currentTarget.index < 0) return;
    float pitch = calculatePitch(offsets->CameraPos, currentTarget.aimPoint);
    float yaw = calculateYaw(offsets->CameraPos, currentTarget.aimPoint);
    applySilentAim(pitch, yaw);
}

void AimbotEnhanced::pSilentAim() {
    if (!isLocked || currentTarget.index < 0) return;
    D3DVector predicted = getPredictedPosition(currentTarget, bulletSpeed, gravity);
    float pitch = calculatePitch(offsets->CameraPos, predicted);
    float yaw = calculateYaw(offsets->CameraPos, predicted);
    applySilentAimSilent(pitch, yaw);
}

void AimbotEnhanced::legitAim() {
    if (!isLocked || currentTarget.index < 0) return;
    if (!isTargetValid(currentTarget)) { releaseTarget(); return; }
    if (humanizedSettings.addRandomDelay) {
        float delay = humanizedSettings.reactionTime +
                      (static_cast<float>(rng() % 100) / 100.0f) * 0.1f;
        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now() - aimStartTime).count() / 1000.0f;
        if (elapsed < delay) return;
    }
    D3DVector predicted = getPredictedPosition(currentTarget, bulletSpeed, gravity);
    float targetPitch = calculatePitch(offsets->CameraPos, predicted);
    float targetYaw = calculateYaw(offsets->CameraPos, predicted);
    float pitchDiff = AIMBOT_NORMALIZE_PITCH(targetPitch - currentPitch);
    float yawDiff = AIMBOT_NORMALIZE_YAW(targetYaw - currentYaw);
    if (fabs(pitchDiff) > spreadLimit) {
        pitchDiff = (pitchDiff > 0 ? 1 : -1) * spreadLimit;
    }
    if (fabs(yawDiff) > spreadLimit) {
        yawDiff = (yawDiff > 0 ? 1 : -1) * spreadLimit;
    }
    targetPitch = currentPitch + pitchDiff;
    targetYaw = currentYaw + yawDiff;
    applyHumanizedMovement(targetPitch, targetYaw);
    setCameraRotation(currentPitch, currentYaw);
    updateRCS();
}

void AimbotEnhanced::assistedAim() {
    if (!isLocked || currentTarget.index < 0) return;
    float targetPitch = calculatePitch(offsets->CameraPos, currentTarget.aimPoint);
    float targetYaw = calculateYaw(offsets->CameraPos, currentTarget.aimPoint);
    float fovDist = calculateFOV(currentPitch, currentYaw, targetPitch, targetYaw);
    if (fovDist > humanizedSettings.maxCorrection) return;
    float pitchDiff = AIMBOT_NORMALIZE_PITCH(targetPitch - currentPitch);
    float yawDiff = AIMBOT_NORMALIZE_YAW(targetYaw - currentYaw);
    if (fabs(pitchDiff) > spreadLimit) {
        pitchDiff = (pitchDiff > 0 ? 1 : -1) * spreadLimit;
    }
    if (fabs(yawDiff) > spreadLimit) {
        yawDiff = (yawDiff > 0 ? 1 : -1) * spreadLimit;
    }
    targetPitch = currentPitch + pitchDiff;
    targetYaw = currentYaw + yawDiff;
    float correction = 1.0f - (fovDist / humanizedSettings.maxCorrection);
    targetPitch = currentPitch + (targetPitch - currentPitch) * correction;
    targetYaw = currentYaw + (targetYaw - currentYaw) * correction;
    applyHumanizedMovement(targetPitch, targetYaw);
    setCameraRotation(currentPitch, currentYaw);
}

void AimbotEnhanced::autoAim() {
    aimAtTarget();
    autoFire();
}

void AimbotEnhanced::applySilentAim(float pitch, float yaw) {
    if (!offsets || !offsets->LocalPlayer) return;
    // Читаем MouseLook: PlayerManager+0x70 → mlPtr → +0x60 (Vector2 yaw/pitch)
    uintptr_t mlPtr = mem->ReadPtr64(offsets->LocalPlayer + 0x70);
    if (!mlPtr) return;
    // Сохраняем оригинальные углы для восстановления
    float origYaw   = mem->ReadFloat(mlPtr + 0x60);
    float origPitch = mem->ReadFloat(mlPtr + 0x64);
    // Пишем углы на 1 кадр
    mem->WriteFloat(mlPtr + 0x60, yaw);
    mem->WriteFloat(mlPtr + 0x64, pitch);
    // Восстанавливаем через ~16мс (1 кадр при 60fps)
    std::thread([mlPtr, origYaw, origPitch, this]() {
        std::this_thread::sleep_for(std::chrono::milliseconds(16));
        mem->WriteFloat(mlPtr + 0x60, origYaw);
        mem->WriteFloat(mlPtr + 0x64, origPitch);
    }).detach();
}

void AimbotEnhanced::applySilentAimSilent(float pitch, float yaw) {
    if (!offsets || !offsets->LocalPlayer) return;
    // P-Silent: патчим направление снаряда через скорость projectile
    // Читаем адрес активного оружия
    uintptr_t weaponAddr = 0;
    if (localPlayerIndex >= 0 && playerData) {
        weaponAddr = playerData[localPlayerIndex].WeaponAddr;
    }
    if (!weaponAddr) return;
    uintptr_t projectileAddr = mem->ReadPtr64(weaponAddr + 0x50);
    if (!projectileAddr) return;
    // Считаем направление вектора
    float sp = sinf(pitch * 0.017453f), cp = cosf(pitch * 0.017453f);
    float sy = sinf(yaw   * 0.017453f), cy = cosf(yaw   * 0.017453f);
    float bulletSpeed = this->bulletSpeed > 0 ? this->bulletSpeed : 300.0f;
    float velX = cp * sy * bulletSpeed;
    float velY = sp * bulletSpeed;
    float velZ = cp * cy * bulletSpeed;
    // Пишем скорость снаряда
    mem->WriteFloat(projectileAddr + 0x28, velX);
    mem->WriteFloat(projectileAddr + 0x2C, velY);
    mem->WriteFloat(projectileAddr + 0x30, velZ);
}

void AimbotEnhanced::applyLegitAim(float targetPitch, float targetYaw) {
    smoothPitch = applySmoothing(smoothPitch, targetPitch, smoothness);
    smoothYaw = applySmoothing(smoothYaw, targetYaw, smoothness);
    smoothPitch = applyCurve(smoothPitch, 0.3f);
    smoothYaw = applyCurve(smoothYaw, 0.3f);
    smoothPitch = applyDeadzone(smoothPitch, 0.1f);
    smoothYaw = applyDeadzone(smoothYaw, 0.1f);
    if (humanizedSettings.simulateBreathing) {
        float breath = sinf(std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count() / 1000.0f * 0.2f) * 0.05f;
        smoothPitch += breath;
        smoothYaw += breath * 0.5f;
    }
    if (humanizedSettings.simulateWeaponSway) {
        float sway = sinf(std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count() / 1000.0f * 0.5f) * 0.03f;
        smoothPitch += sway;
        smoothYaw += sway * 0.7f;
    }
    currentPitch = smoothPitch;
    currentYaw = smoothYaw;
}

void AimbotEnhanced::applyHumanizedMovement(float targetPitch, float targetYaw) {
    float pitchDiff = AIMBOT_NORMALIZE_PITCH(targetPitch - currentPitch);
    float yawDiff = AIMBOT_NORMALIZE_YAW(targetYaw - currentYaw);
    float maxMove = humanizedSettings.maxMovement * (1.0f + 0.5f * sinf(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count() / 1000.0f));
    pitchDiff = AIMBOT_CLAMP(pitchDiff, -maxMove, maxMove);
    yawDiff = AIMBOT_CLAMP(yawDiff, -maxMove, maxMove);
    if (humanizedSettings.noiseAmount > 0) {
        float noise = sinf(std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count() / 100.0f *
            humanizedSettings.noiseFrequency) * humanizedSettings.noiseAmount;
        pitchDiff += noise * 0.1f;
        yawDiff += noise * 0.05f;
    }
    currentPitch += pitchDiff;
    currentYaw += yawDiff;
    currentPitch = AIMBOT_NORMALIZE_PITCH(currentPitch);
    currentYaw = AIMBOT_NORMALIZE_YAW(currentYaw);
}

void AimbotEnhanced::applyRecoilControl() {
    if (rcsSettings.mode == RCSMode::Disabled) return;
    if (shotsFired < rcsSettings.startAfterShots) return;
    float verticalControl = rcsSettings.verticalScale;
    float horizontalControl = rcsSettings.horizontalScale;
    if (rcsSettings.adaptiveCompensation) {
        float fireRate = getFireRate();
        if (fireRate > 0) {
            verticalControl *= (600.0f / fireRate) * 0.5f;
        }
    }
    if (rcsSettings.randomizeCompensation) {
        float randVal = (static_cast<float>(rng() % 100) / 100.0f - 0.5f) * 2.0f;
        verticalControl *= 1.0f + randVal * rcsSettings.randomizationAmount;
        horizontalControl *= 1.0f + randVal * rcsSettings.randomizationAmount * 0.5f;
    }
    float pitchAdjust = -recoilPitch * verticalControl;
    float yawAdjust = -recoilYaw * horizontalControl;
    pitchAdjust = applySmoothing(0, pitchAdjust, rcsSettings.smoothness);
    yawAdjust = applySmoothing(0, yawAdjust, rcsSettings.smoothness);
    currentPitch += pitchAdjust;
    currentYaw += yawAdjust;
    currentPitch = AIMBOT_NORMALIZE_PITCH(currentPitch);
    currentYaw = AIMBOT_NORMALIZE_YAW(currentYaw);
    setCameraRotation(currentPitch, currentYaw);
}

float AimbotEnhanced::calculatePitch(D3DVector from, D3DVector to) {
    float dx = to.X - from.X;
    float dy = to.Y - from.Y;
    float dz = to.Z - from.Z;
    float dist = sqrtf(dx * dx + dz * dz);
    if (dist < 0.001f || !std::isfinite(dist)) return currentPitch;
    float pitch = AIMBOT_RAD2DEG(-atan2f(dy, dist));
    if (!std::isfinite(pitch)) return currentPitch;
    return pitch;
}

float AimbotEnhanced::calculateYaw(D3DVector from, D3DVector to) {
    float dx = to.X - from.X;
    float dz = to.Z - from.Z;
    if (fabsf(dx) < 0.001f && fabsf(dz) < 0.001f) return currentYaw;
    float yaw = AIMBOT_RAD2DEG(atan2f(dx, dz));
    if (!std::isfinite(yaw)) return currentYaw;
    return yaw;
}

float AimbotEnhanced::calculateDistance(D3DVector a, D3DVector b) {
    float dx = a.X - b.X;
    float dy = a.Y - b.Y;
    float dz = a.Z - b.Z;
    return sqrtf(dx * dx + dy * dy + dz * dz);
}

float AimbotEnhanced::calculateFOV(float pitch, float yaw, float targetPitch, float targetYaw) {
    float dp = AIMBOT_NORMALIZE_PITCH(pitch - targetPitch);
    float dy = AIMBOT_NORMALIZE_YAW(yaw - targetYaw);
    return sqrtf(dp * dp + dy * dy);
}

float AimbotEnhanced::calculateSmoothFactor(float distance, float fov) {
    float distFactor = std::clamp(distance / range, 0.3f, 1.0f);
    float fovFactor = std::clamp(fov / this->fov, 0.3f, 1.0f);
    return (distFactor + fovFactor) / 2.0f * smoothness;
}

D3DVector AimbotEnhanced::getPredictedPosition(AimbotEnhancedTarget &target, float bulletSpeed, float gravity) {
    D3DVector pos = target.aimPoint;
    if (bulletSpeed <= 0 || !cfg->AimbotPrediction || !tog->AimbotPrediction) return pos;
    float dist = calculateDistance(offsets->CameraPos, pos);
    float travelTime = dist / bulletSpeed;
    pos.X += target.velocity.X * travelTime * prediction;
    pos.Y += target.velocity.Y * travelTime * prediction + 0.5f * gravity * travelTime * travelTime;
    pos.Z += target.velocity.Z * travelTime * prediction;
    return pos;
}

D3DVector AimbotEnhanced::getAimPoint(AimbotEnhancedTarget &target, HitboxSelection hitbox) {
    return getHitboxPosition(target, hitbox);
}

D3DVector AimbotEnhanced::getHitboxPosition(AimbotEnhancedTarget &target, HitboxSelection hitbox) {
    switch (hitbox) {
        case HitboxSelection::Head: return target.headPosition;
        case HitboxSelection::Neck: return target.bonePositions[1];
        case HitboxSelection::Chest: return target.bonePositions[2];
        case HitboxSelection::Stomach: return target.bonePositions[3];
        case HitboxSelection::Pelvis: return target.bonePositions[4];
        case HitboxSelection::Legs: return target.bonePositions[5];
        case HitboxSelection::Feet: return target.bonePositions[6];
        case HitboxSelection::Best:
            return target.isVisible ? target.headPosition : target.bonePositions[2];
        case HitboxSelection::Random: {
            int maxBone = std::min(7, target.boneCount);
            if (maxBone <= 0) return target.headPosition;
            return target.bonePositions[rng() % maxBone];
        }
        default: return target.headPosition;
    }
}

D3DVector AimbotEnhanced::getBonePosition(EnhancedPlayerData &player, int boneID) {
    if (boneID < 0 || boneID >= player.boneCount) return player.Position;
    return player.bonePositions[boneID];
}

HitboxSelection AimbotEnhanced::selectHitbox(AimbotEnhancedTarget &target) {
    if (currentHitbox == HitboxSelection::AutoAim) {
        if (target.distance < 50.0f) return HitboxSelection::Head;
        if (target.distance < 150.0f) return HitboxSelection::Neck;
        if (target.distance < 300.0f) return HitboxSelection::Chest;
        return HitboxSelection::Stomach;
    }
    return currentHitbox;
}

AimPriority AimbotEnhanced::selectPriority(AimbotEnhancedTarget &target) {
    return currentPriority;
}

bool AimbotEnhanced::isTargetValid(const AimbotEnhancedTarget &target) {
    if (target.index < 0) return false;
    if (!target.isValid) return false;
    if (target.health <= 0) return false;
    if (target.teamID == -1) return false;
    if (tog->FilterSelf && target.index == localPlayerIndex) return false;
    if (tog->FilterTeam && target.teamID == 0) return false;
    if (tog->FilterEnemy && target.teamID != 0) return false;
    if (tog->FilterVisible && !target.isVisible) return false;
    if (tog->AimbotVisibleCheck && !target.isVisible) return false;
    if (tog->FilterDistance && target.distance > cfg->AimbotMaxDistance) return false;
    return true;
}

bool AimbotEnhanced::isTargetVisible(const AimbotEnhancedTarget &target) {
    return target.isVisible;
}

bool AimbotEnhanced::isTargetInFOV(const AimbotEnhancedTarget &target) {
    float fovDist = calculateFOV(currentPitch, currentYaw, target.pitch, target.yaw);
    return fovDist <= fov;
}

bool AimbotEnhanced::isTargetInRange(const AimbotEnhancedTarget &target) {
    return target.distance <= range;
}

bool AimbotEnhanced::isLineOfSightClear(D3DVector from, D3DVector to) {
    return true;
}

bool AimbotEnhanced::isWeaponReady() {
    auto now = std::chrono::steady_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - lastShot).count();
    return elapsed >= (1000.0f / getFireRate());
}

bool AimbotEnhanced::isTargetOnScreen(AimbotEnhancedTarget &target) {
    float x, y;
    return worldToScreen(target.aimPoint, &x, &y);
}

bool AimbotEnhanced::isLocked() const {
    return isLocked;
}

void AimbotEnhanced::triggerbot() {
    if (triggerbotSettings.mode == TriggerMode::Disabled) return;
    if (!isLocked || currentTarget.index < 0) return;
    if (triggerbotSettings.requireVisible && !currentTarget.isVisible) return;
    float fovDist = calculateFOV(currentPitch, currentYaw, currentTarget.pitch, currentTarget.yaw);
    if (fovDist > triggerbotSettings.fovLimit) return;
    if (currentTarget.distance > triggerbotSettings.rangeLimit) return;
    if (triggerbotSettings.holdToActivate && !isKeyPressed(triggerbotSettings.activationKey)) return;
    if (!isWeaponReady()) return;
    auto now = std::chrono::steady_clock::now();
    if (now - lastShot < triggerbotSettings.minInterval) return;
    int delay = triggerbotSettings.delayMin;
    if (triggerbotSettings.delayMax > triggerbotSettings.delayMin) {
        delay += rng() % (triggerbotSettings.delayMax - triggerbotSettings.delayMin);
    }
    delayedShot(delay);
}

void AimbotEnhanced::autoShoot() {
    if (!isLocked || currentTarget.index < 0) return;
    if (!isWeaponReady()) return;
    if (tog->FilterVisible && !currentTarget.isVisible) return;
    if (tog->AimbotVisibleCheck && !currentTarget.isVisible) return;
    if (!canShoot()) return;
    if (currentTarget.health <= 0) return;
    onShot();
}

void AimbotEnhanced::autoFire() {
    autoShoot();
}

void AimbotEnhanced::triggerOnTarget() {
    triggerbot();
}

void AimbotEnhanced::delayedShot(int delay) {
    if (delay <= 0) {
        onShot();
        return;
    }
    if (delayedShotPending.exchange(true)) return;
    delayedShotFireTime = std::chrono::steady_clock::now() + std::chrono::milliseconds(delay);
}

void AimbotEnhanced::checkDelayedShot() {
    if (!delayedShotPending) return;
    if (std::chrono::steady_clock::now() < delayedShotFireTime) return;
    delayedShotPending = false;
    if (isLocked) onShot();
}

void AimbotEnhanced::checkVisibility() {
    for (auto &target : targets) {
        updateTargetVisibility(target);
    }
}

void AimbotEnhanced::updateTargets() {
    targets.clear();
    if (!playerData || playerCount <= 0) return;
    for (int i = 0; i < playerCount; ++i) {
        if (i == localPlayerIndex) continue;
        EnhancedPlayerData &player = playerData[i];
        if (!player.IsAlive) continue;
        AimbotEnhancedTarget target;
        target.index = i;
        target.address = player.Address;
        target.position = player.Position;
        target.headPosition = player.Head;
        target.distance = calculateDistance(offsets->CameraPos, player.Position);
        target.health = (int)player.Health;
        target.maxHealth = (int)player.MaxHealth;
        target.teamID = player.TeamID;
        target.isVisible = player.IsVisible;
        target.isBot = player.IsBot;
        target.isValid = true;
        target.velocity = player.Velocity;
        memcpy(target.playerName, player.PlayerName, 64);
        memcpy(target.weaponName, player.WeaponName, 32);
        target.pitch = calculatePitch(offsets->CameraPos, target.headPosition);
        target.yaw = calculateYaw(offsets->CameraPos, target.headPosition);
        target.aimPoint = getHitboxPosition(target, currentHitbox);
        target.hitbox = currentHitbox;
        memcpy(target.bonePositions, player.bonePositions, sizeof(D3DVector) * std::min(player.boneCount, 128));
        target.boneCount = player.boneCount;
        target.aimPitch = player.aimPitch;
        target.aimYaw = player.aimYaw;
        target.isScoping = player.isScoping;
        target.isReloading = player.isReloading;
        target.isShooting = player.isShooting;
        target.isMoving = player.isRunning;
        target.movementSpeed = sqrtf(player.velocity.X * player.velocity.X +
                                     player.velocity.Y * player.velocity.Y +
                                     player.velocity.Z * player.velocity.Z);
        target.playerId = player.playerId;
        target.lastSeenTime = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count() / 1000.0f;
        int tier = 1;
        if (strstr(target.weaponName, "Sniper") || strstr(target.weaponName, "RPG") || strstr(target.weaponName, "Launcher")) tier = 5;
        else if (strstr(target.weaponName, "Shotgun") || strstr(target.weaponName, "LMG")) tier = 4;
        else if (strstr(target.weaponName, "Assault") || strstr(target.weaponName, "SMG") || strstr(target.weaponName, "Carbine")) tier = 3;
        else if (strstr(target.weaponName, "Pistol") || strstr(target.weaponName, "Revolver")) tier = 2;
        target.weaponTier = tier;
        targets.push_back(target);
    }
}

void AimbotEnhanced::sortTargets() {
    std::sort(targets.begin(), targets.end(), [this](const AimbotEnhancedTarget &a, const AimbotEnhancedTarget &b) {
        float fovA = calculateFOV(currentPitch, currentYaw, a.pitch, a.yaw);
        float fovB = calculateFOV(currentPitch, currentYaw, b.pitch, b.yaw);
        if (fabs(fovA - fovB) > 1.0f) return fovA < fovB;
        return a.distance < b.distance;
    });
}

void AimbotEnhanced::filterTargets() {
    targets.erase(std::remove_if(targets.begin(), targets.end(),
        [this](const AimbotEnhancedTarget &t) { return !isTargetValid(t); }), targets.end());
}

void AimbotEnhanced::prioritizeTargets() {
    for (auto &target : targets) {
        updateTargetPriority(target);
    }
}

void AimbotEnhanced::updateHitbox() {
    if (currentTarget.index >= 0) {
        currentTarget.aimPoint = getHitboxPosition(currentTarget, currentHitbox);
    }
}

void AimbotEnhanced::updateRCS() {
    applyRecoilControl();
}

void AimbotEnhanced::updatePrediction() {
    if (currentTarget.index >= 0) {
        currentTarget.aimPoint = getPredictedPosition(currentTarget, bulletSpeed, gravity);
    }
}

void AimbotEnhanced::updateSmoothing() {
    smoothness = cfg->AimbotSmoothValue;
}

void AimbotEnhanced::setMode(AimbotMode mode) { currentMode = mode; }
void AimbotEnhanced::setHitbox(HitboxSelection hitbox) { currentHitbox = hitbox; }
void AimbotEnhanced::setPriority(AimPriority priority) { currentPriority = priority; }
void AimbotEnhanced::setFOV(float f) { fov = f; }
void AimbotEnhanced::setRange(float r) { range = r; }
void AimbotEnhanced::setSmoothness(float s) { smoothness = s; }
void AimbotEnhanced::setPrediction(float p) { prediction = p; }

AimbotMode AimbotEnhanced::getMode() const { return currentMode; }
HitboxSelection AimbotEnhanced::getHitbox() const { return currentHitbox; }
AimPriority AimbotEnhanced::getPriority() const { return currentPriority; }
float AimbotEnhanced::getFOV() const { return fov; }
float AimbotEnhanced::getRange() const { return range; }
float AimbotEnhanced::getSmoothness() const { return smoothness; }
float AimbotEnhanced::getPrediction() const { return prediction; }

AimbotEnhancedTarget AimbotEnhanced::getCurrentTarget() const { return currentTarget; }
AimbotEnhancedTarget AimbotEnhanced::getBestTarget() const { return bestTarget; }
std::vector<AimbotEnhancedTarget> AimbotEnhanced::getTargets() const { return targets; }
AimbotEnhancedTarget AimbotEnhanced::getTarget(int index) const {
    if (index < 0 || index >= (int)targets.size()) return {};
    return targets[index];
}
int AimbotEnhanced::getTargetCount() const { return targets.size(); }

AimbotStatistics AimbotEnhanced::getStatistics() const { return stats; }

void AimbotEnhanced::resetStatistics() {
    stats = AimbotStatistics{};
    stats.startTime = std::chrono::steady_clock::now();
}

void AimbotEnhanced::updateStatistics(bool hit, bool headshot) {
    stats.totalShots++;
    if (hit) {
        stats.hits++;
        consecutiveHits++;
        consecutiveMisses = 0;
        if (headshot) stats.headshots++;
    } else {
        stats.misses++;
        consecutiveMisses++;
        consecutiveHits = 0;
    }
    if (stats.totalShots > 0) {
        stats.accuracy = (float)stats.hits / stats.totalShots * 100.0f;
    }
    stats.recentAccuracies.push_back(stats.accuracy);
    if (stats.recentAccuracies.size() > 100) stats.recentAccuracies.pop_front();
    stats.recentDistances.push_back(currentTarget.distance);
    if (stats.recentDistances.size() > 100) stats.recentDistances.pop_front();
    if (headshot) stats.hitboxStats[(int)HitboxSelection::Head]++;
    else if (currentHitbox == HitboxSelection::Chest) stats.hitboxStats[(int)HitboxSelection::Chest]++;
}

HumanizedAimSettings AimbotEnhanced::getHumanizedSettings() const { return humanizedSettings; }
void AimbotEnhanced::setHumanizedSettings(const HumanizedAimSettings &settings) { humanizedSettings = settings; }

TriggerbotSettings AimbotEnhanced::getTriggerbotSettings() const { return triggerbotSettings; }
void AimbotEnhanced::setTriggerbotSettings(const TriggerbotSettings &settings) { triggerbotSettings = settings; }

RecoilControlSettings AimbotEnhanced::getRCS() const { return rcsSettings; }
void AimbotEnhanced::setRCS(const RecoilControlSettings &settings) { rcsSettings = settings; }

void AimbotEnhanced::setResolverEnabled(bool enable) { resolverEnabled = enable; }
bool AimbotEnhanced::isResolverEnabled() const { return resolverEnabled; }

void AimbotEnhanced::setMultitargetEnabled(bool enable) { multitargetEnabled = enable; }
bool AimbotEnhanced::isMultitargetEnabled() const { return multitargetEnabled; }

void AimbotEnhanced::cycleTarget() {
    if (targets.empty()) return;
    currentTargetIndex = (currentTargetIndex + 1) % targets.size();
    currentTarget = targets[currentTargetIndex];
}

int AimbotEnhanced::getCurrentTargetIndex() const { return currentTargetIndex; }

void AimbotEnhanced::drawAimbotFOV(ImDrawList *draw) {
    draw->AddCircle(ImVec2(screenCenterX, screenCenterY), fov, cfg->AimbotFOVColor, 64, 1.0f);
}

void AimbotEnhanced::drawTargetInfo(ImDrawList *draw, AimbotEnhancedTarget &target) {
    float sx, sy;
    if (!worldToScreen(target.aimPoint, &sx, &sy)) return;
    draw->AddCircleFilled(ImVec2(sx, sy), 5.0f, cfg->AimbotTargetColor, 12);
    draw->AddCircle(ImVec2(sx, sy), 10.0f, cfg->AimbotTargetColor, 16, 2.0f);
    char info[128];
    snprintf(info, sizeof(info), "%s [%.0fm]", target.playerName, target.distance);
    draw->AddText(ImVec2(sx + 15, sy - 20), ImColor(255, 255, 255), info);
    snprintf(info, sizeof(info), "HP: %d/%d | FOV: %.1f", target.health, target.maxHealth, target.fovDistance);
    draw->AddText(ImVec2(sx + 15, sy - 5), ImColor(200, 200, 200), info);
}

void AimbotEnhanced::drawTargetLine(ImDrawList *draw, AimbotEnhancedTarget &target) {
    float sx, sy;
    if (!worldToScreen(target.aimPoint, &sx, &sy)) return;
    draw->AddLine(ImVec2(screenCenterX, screenCenterY), ImVec2(sx, sy), cfg->AimLineColor, 1.5f);
}

void AimbotEnhanced::drawHitbox(ImDrawList *draw, AimbotEnhancedTarget &target) {
}

void AimbotEnhanced::drawStatistics(ImDrawList *draw) {
    char buffer[128];
    int y = 90;
    snprintf(buffer, sizeof(buffer), "Aimbot: %s", isLocked ? "LOCKED" : "IDLE");
    draw->AddText(ImVec2(20, y), isLocked ? ImColor(0, 255, 0) : ImColor(255, 255, 255), buffer); y += 18;
    snprintf(buffer, sizeof(buffer), "Target: %s", currentTarget.playerName);
    draw->AddText(ImVec2(20, y), ImColor(255, 255, 255), buffer); y += 18;
    snprintf(buffer, sizeof(buffer), "Dist: %.0fm | FOV: %.1f", currentTarget.distance, currentTarget.fovDistance);
    draw->AddText(ImVec2(20, y), ImColor(200, 200, 200), buffer); y += 18;
    snprintf(buffer, sizeof(buffer), "Acc: %.1f%% | Hits: %d | Misses: %d",
             stats.accuracy, stats.hits, stats.misses);
    draw->AddText(ImVec2(20, y), ImColor(0, 255, 200), buffer); y += 18;
    snprintf(buffer, sizeof(buffer), "HS: %d | Shots: %d", stats.headshots, stats.totalShots);
    draw->AddText(ImVec2(20, y), ImColor(255, 200, 0), buffer);
}

bool AimbotEnhanced::worldToScreen(D3DVector world, float *x, float *y) {
    if (!x || !y) return false;
    if (!offsets || !offsets->Initialized) return false;
    float *matrix = offsets->ViewMatrix;
    if (!matrix) return false;
    return ::WorldToScreen(world, x, y, matrix, screenWidth, screenHeight);
}

bool AimbotEnhanced::isVisible(D3DVector from, D3DVector to, uintptr_t targetEntity) {
    return true;
}

void AimbotEnhanced::setPlayerData(EnhancedPlayerData *data, int count) {
    playerData = data;
    playerCount = count;
}

void AimbotEnhanced::updateLocalPlayer() {
    if (!offsets || !offsets->Initialized) return;
    uintptr_t cameraAddr = offsets->CameraAddr;
    if (!cameraAddr) {
        if (offsets->UWorld) cameraAddr = offsets->UWorld + 0x310;
    }
    if (cameraAddr && mem) {
        currentPitch = mem->ReadFloat(cameraAddr);
        currentYaw = mem->ReadFloat(cameraAddr + 0x4);
    } else {
        currentPitch = 0;
        currentYaw = 0;
    }
}

void AimbotEnhanced::updateTargetPosition(AimbotEnhancedTarget &target) {
    target.position = playerData[target.index].Position;
    target.headPosition = playerData[target.index].Head;
    target.aimPoint = getHitboxPosition(target, currentHitbox);
    target.distance = calculateDistance(offsets->CameraPos, target.position);
}

void AimbotEnhanced::updateTargetVisibility(AimbotEnhancedTarget &target) {
    target.isVisible = isTargetVisible(target);
}

void AimbotEnhanced::updateTargetPriority(AimbotEnhancedTarget &target) {
    target.priority = static_cast<int>(currentPriority);
}

D3DVector AimbotEnhanced::getCameraPosition() {
    return offsets->CameraPos;
}

D3DVector AimbotEnhanced::getCameraRotation() {
    return D3DVector(currentPitch, currentYaw, 0);
}

float AimbotEnhanced::getCameraFOV() {
    return offsets->CameraFOV > 0 ? offsets->CameraFOV : 90.0f;
}

void AimbotEnhanced::setCameraRotation(float pitch, float yaw) {
    lastPitch = currentPitch;
    lastYaw = currentYaw;
    currentPitch = AIMBOT_NORMALIZE_PITCH(pitch);
    currentYaw = AIMBOT_NORMALIZE_YAW(yaw);
    if (mem && offsets) {
        uintptr_t cameraAddr = offsets->CameraAddr;
        if (!cameraAddr && offsets->UWorld) cameraAddr = offsets->UWorld + 0x310;
        if (cameraAddr) {
            mem->WriteFloat(cameraAddr, currentPitch);
            mem->WriteFloat(cameraAddr + 0x4, currentYaw);
        }
    }
}

void AimbotEnhanced::resolvePlayerAnimation(AimbotEnhancedTarget &target) {
    if (!resolverEnabled) return;
}

void AimbotEnhanced::onTargetAcquired(AimbotEnhancedTarget &target) {
    lastTargetChange = std::chrono::steady_clock::now();
    stats.targetSwitches++;
}

void AimbotEnhanced::onTargetReleased() {
    isLocked = false;
    delayedShotPending = false;
}

void AimbotEnhanced::onShot() {
    shotsFired++;
    lastShot = std::chrono::steady_clock::now();
    if (mem && offsets && offsets->ForceAttackAddr) {
        mem->WriteInt(offsets->ForceAttackAddr, 1);
    }
    if (rcsSettings.mode != RCSMode::Disabled) {
        rcsShotsFired++;
        int plen = std::min(rcsSettings.patternLength, 30);
        if (plen > 0) {
            recoilPitch += rcsSettings.verticalRecoilPattern[currentPatternIndex % plen];
            recoilYaw += rcsSettings.horizontalRecoilPattern[currentPatternIndex % plen];
            currentPatternIndex = (currentPatternIndex + 1) % plen;
        }
    }
}

bool AimbotEnhanced::canShoot() {
    return hasAmmo() && isWeaponReady();
}

bool AimbotEnhanced::hasAmmo() {
    return getAmmoCount() > 0;
}

int AimbotEnhanced::getAmmoCount() {
    if (mem && offsets && offsets->Initialized && offsets->OffsetAmmo) {
        uintptr_t localAddr = 0;
        if (localPlayerIndex >= 0 && playerData) {
            localAddr = playerData[localPlayerIndex].Address + offsets->OffsetAmmo;
        }
        if (localAddr) {
            int ammo = mem->ReadInt(localAddr);
            if (ammo >= 0) return ammo;
        }
    }
    return 30;
}

int AimbotEnhanced::getMaxAmmo() {
    return 30;
}

float AimbotEnhanced::getFireRate() {
    return 600.0f;
}

float AimbotEnhanced::applySmoothing(float current, float target, float smoothFactor) {
    if (smoothFactor <= 0.01f) return target;
    float factor = std::clamp(1.0f / (smoothFactor * 10.0f), 0.01f, 1.0f);
    return current + (target - current) * factor;
}

float AimbotEnhanced::applyCurve(float value, float curveFactor) {
    return value * (1.0f + curveFactor * (value * value - 1.0f));
}

float AimbotEnhanced::applyDeadzone(float value, float deadzone) {
    if (fabs(value) < deadzone) return 0;
    return value;
}

float AimbotEnhanced::applyRandomization(float value, float amount) {
    return value + (static_cast<float>(rng() % 1000) / 1000.0f - 0.5f) * 2.0f * amount;
}

D3DVector AimbotEnhanced::applySpread(D3DVector aimPoint, float spread) {
    float theta = (static_cast<float>(rng() % 1000) / 1000.0f) * 2.0f * AIMBOT_PI;
    float r = (static_cast<float>(rng() % 1000) / 1000.0f) * spread;
    aimPoint.X += r * cosf(theta);
    aimPoint.Y += r * sinf(theta);
    return aimPoint;
}

void AimbotEnhanced::updateDeltaTime() {
    auto now = std::chrono::steady_clock::now();
    deltaTime = std::chrono::duration_cast<std::chrono::milliseconds>(now - lastUpdate).count() / 1000.0f;
}

void AimbotEnhanced::updateScreenDimensions() {
    screenWidth = ImGui::GetIO().DisplaySize.x;
    screenHeight = ImGui::GetIO().DisplaySize.y;
    screenCenterX = screenWidth / 2.0f;
    screenCenterY = screenHeight / 2.0f;
}

bool AimbotEnhanced::isKeyPressed(int key) const {
    return key > 0;
}

bool AimbotEnhanced::isButtonPressed(int button) const {
    return button > 0;
}
