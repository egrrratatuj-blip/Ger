#include "LoggingSystem.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <sys/syscall.h>

namespace BugorLogging {

LoggingSystem::LoggingSystem()
    : logPath("/data/data/com.bugor.engine/files/logs/"),
      pattern("[%H:%M:%S] [%l] %v"),
      globalLevel(LogLevel::Trace),
      initialized(false), async(false), autoFlushEnabled(false),
      remoteEnabled(false), encryptionEnabled(false), crashHandlerEnabled(false),
      compressionEnabled(false),
      logCount(0), errorCount(0), warningCount(0),
      asyncQueueSize(8192), flushInterval(1000), autoFlushInterval(5000),
      backtraceSize(64), maxQueueSize(65536), maxLogAge(72),
      autoFlushThread(nullptr), asyncWorkerThread(nullptr) {
    spdLogger = spdlog::basic_logger_st("bugor", logPath + "engine.log");
    spdlog::set_pattern("[%H:%M:%S] [%^%l%$] %v");
}

LoggingSystem::~LoggingSystem() {
    shutdown();
}

bool LoggingSystem::initialize(const std::string &configPath) {
    if (initialized) return true;
    if (!configPath.empty()) {
        loadConfiguration(configPath);
    }
    if (!std::filesystem::exists(logPath)) {
        std::filesystem::create_directories(logPath);
    }
    if (sinks.empty()) {
        LogSinkConfig consoleConfig;
        consoleConfig.type = LogSinkType::Console;
        consoleConfig.name = "default_console";
        consoleConfig.level = LogLevel::Trace;
        consoleConfig.pattern = pattern;
        auto consoleSink = std::make_shared<ConsoleSink>();
        if (consoleSink->initialize(consoleConfig)) {
            sinks.push_back(consoleSink);
        }
        LogSinkConfig fileConfig;
        fileConfig.type = LogSinkType::RotatingFile;
        fileConfig.name = "default_file";
        fileConfig.path = logPath + "engine.log";
        fileConfig.level = LogLevel::Debug;
        fileConfig.maxFileSize = 10485760;
        fileConfig.maxFiles = 5;
        fileConfig.pattern = pattern;
        auto fileSink = std::make_shared<RotatingFileSink>();
        if (fileSink->initialize(fileConfig)) {
            sinks.push_back(fileSink);
        }
    }
    initialized = true;
    return true;
}

void LoggingSystem::shutdown() {
    stopAutoFlush();
    flushAll();
    initialized = false;
    std::unique_lock<std::shared_mutex> lock(sinkMutex);
    for (auto &sink : sinks) {
        sink->shutdown();
    }
    sinks.clear();
    spdlog::drop_all();
}

void LoggingSystem::log(LogLevel level, const std::string &message) {
    log(level, "default", message);
}

void LoggingSystem::log(LogLevel level, const std::string &logger, const std::string &message) {
    log(level, logger, "", 0, "", message);
}

void LoggingSystem::log(LogLevel level, const std::string &logger, const std::string &file, int line, const std::string &function, const std::string &message) {
    if (!initialized || !shouldLog(logger, level)) return;
    auto entry = createEntry(level, logger, file, line, function, message);
    logCount++;
    if (level == LogLevel::Error || level == LogLevel::Critical) errorCount++;
    if (level == LogLevel::Warn) warningCount++;
    if (async) {
        std::lock_guard<std::mutex> lock(queueMutex);
        if (asyncQueue.size() < maxQueueSize) {
            asyncQueue.push(entry);
            queueCV.notify_one();
        }
    } else {
        dispatchToSinks(entry);
    }
    switch (level) {
        case LogLevel::Trace: spdlog->trace(message); break;
        case LogLevel::Debug: spdlog->debug(message); break;
        case LogLevel::Info: spdlog->info(message); break;
        case LogLevel::Warn: spdlog->warn(message); break;
        case LogLevel::Error: spdlog->error(message); break;
        case LogLevel::Critical: spdlog->critical(message); break;
        case LogLevel::Fatal: spdlog->critical(message); break;
        default: break;
    }
}

void LoggingSystem::log(const LogEntry &entry) {
    if (!initialized || !shouldLog(entry.logger, entry.level)) return;
    logCount++;
    dispatchToSinks(entry);
}

void LoggingSystem::trace(const std::string &message) { log(LogLevel::Trace, message); }
void LoggingSystem::debug(const std::string &message) { log(LogLevel::Debug, message); }
void LoggingSystem::info(const std::string &message) { log(LogLevel::Info, message); }
void LoggingSystem::warn(const std::string &message) { log(LogLevel::Warn, message); }
void LoggingSystem::error(const std::string &message) { log(LogLevel::Error, message); }
void LoggingSystem::critical(const std::string &message) { log(LogLevel::Critical, message); }
void LoggingSystem::fatal(const std::string &message) { log(LogLevel::Fatal, message); }

void LoggingSystem::flush() {
    std::shared_lock<std::shared_mutex> lock(sinkMutex);
    for (auto &sink : sinks) {
        sink->flush();
    }
}

void LoggingSystem::flushAll() {
    std::unique_lock<std::shared_mutex> lock(sinkMutex);
    for (auto &sink : sinks) {
        sink->flush();
    }
    if (!asyncQueue.empty()) {
        std::lock_guard<std::mutex> qLock(queueMutex);
        while (!asyncQueue.empty()) {
            auto entry = asyncQueue.front();
            asyncQueue.pop();
            for (auto &sink : sinks) {
                sink->write(entry);
            }
        }
    }
}

void LoggingSystem::setLevel(LogLevel level) { globalLevel = level; }
LogLevel LoggingSystem::getLevel() const { return globalLevel; }

void LoggingSystem::setPattern(const std::string &p) { pattern = p; }
std::string LoggingSystem::getPattern() const { return pattern; }

void LoggingSystem::addSink(std::shared_ptr<LogSink> sink) {
    std::unique_lock<std::shared_mutex> lock(sinkMutex);
    sinks.push_back(sink);
}

void LoggingSystem::removeSink(const std::string &name) {
    std::unique_lock<std::shared_mutex> lock(sinkMutex);
    sinks.erase(std::remove_if(sinks.begin(), sinks.end(),
        [&](auto &s) { return s->getName() == name; }), sinks.end());
}

void LoggingSystem::removeAllSinks() {
    std::unique_lock<std::shared_mutex> lock(sinkMutex);
    sinks.clear();
}

std::vector<std::shared_ptr<LogSink>> LoggingSystem::getSinks() const {
    std::shared_lock<std::shared_mutex> lock(sinkMutex);
    return sinks;
}

void LoggingSystem::setAsync(bool enable) {
    async = enable;
    if (enable && !asyncWorkerThread) {
        asyncWorkerThread = new std::thread(&LoggingSystem::processAsyncQueue, this);
    }
}

bool LoggingSystem::isAsync() const { return async; }
void LoggingSystem::setAsyncQueueSize(uint32_t size) { asyncQueueSize = size; }
void LoggingSystem::setFlushInterval(uint32_t ms) { flushInterval = ms; }

void LoggingSystem::enableBacktrace(bool enable) {}
void LoggingSystem::setBacktraceSize(uint32_t size) { backtraceSize = size; }
void LoggingSystem::dumpBacktrace() {}
void LoggingSystem::enableCrashHandler(bool enable) { crashHandlerEnabled = enable; }
void LoggingSystem::enableEncryption(bool enable) { encryptionEnabled = enable; }

void LoggingSystem::setEncryptionKey(const std::vector<uint8_t> &key) {
    encryptionKey = key;
    encryptionEnabled = !key.empty();
}

bool LoggingSystem::loadConfiguration(const std::string &configPath) {
    return true;
}

bool LoggingSystem::saveConfiguration(const std::string &configPath) {
    return true;
}

void LoggingSystem::registerLogger(const std::string &name, const LoggerConfig &config) {
    std::unique_lock<std::shared_mutex> lock(loggerMutex);
    loggers[name] = config;
}

void LoggingSystem::unregisterLogger(const std::string &name) {
    std::unique_lock<std::shared_mutex> lock(loggerMutex);
    loggers.erase(name);
}

bool LoggingSystem::hasLogger(const std::string &name) const {
    std::shared_lock<std::shared_mutex> lock(loggerMutex);
    return loggers.find(name) != loggers.end();
}

std::vector<std::string> LoggingSystem::getLoggerNames() const {
    std::shared_lock<std::shared_mutex> lock(loggerMutex);
    std::vector<std::string> names;
    for (auto &[name, _] : loggers) names.push_back(name);
    return names;
}

void LoggingSystem::setLoggerLevel(const std::string &logger, LogLevel level) {
    std::unique_lock<std::shared_mutex> lock(loggerMutex);
    auto it = loggers.find(logger);
    if (it != loggers.end()) it->second.level = level;
}

LogLevel LoggingSystem::getLoggerLevel(const std::string &logger) const {
    std::shared_lock<std::shared_mutex> lock(loggerMutex);
    auto it = loggers.find(logger);
    return it != loggers.end() ? it->second.level : globalLevel;
}

void LoggingSystem::setCategoryLevel(const std::string &category, LogLevel level) {
    categoryLevels[category] = level;
}

void LoggingSystem::enableCategory(const std::string &category) {
    if (std::find(enabledCategories.begin(), enabledCategories.end(), category) == enabledCategories.end()) {
        enabledCategories.push_back(category);
    }
}

void LoggingSystem::disableCategory(const std::string &category) {
    if (std::find(disabledCategories.begin(), disabledCategories.end(), category) == disabledCategories.end()) {
        disabledCategories.push_back(category);
    }
}

bool LoggingSystem::isCategoryEnabled(const std::string &category) const {
    if (!disabledCategories.empty()) {
        if (std::find(disabledCategories.begin(), disabledCategories.end(), category) != disabledCategories.end()) return false;
    }
    if (!enabledCategories.empty()) {
        return std::find(enabledCategories.begin(), enabledCategories.end(), category) != enabledCategories.end();
    }
    return true;
}

void LoggingSystem::startAutoFlush(uint32_t intervalMs) {
    if (autoFlushEnabled) return;
    autoFlushInterval = intervalMs;
    autoFlushEnabled = true;
    autoFlushThread = new std::thread(&LoggingSystem::autoFlushLoop, this);
}

void LoggingSystem::stopAutoFlush() {
    autoFlushEnabled = false;
    if (autoFlushThread && autoFlushThread->joinable()) {
        autoFlushThread->join();
        delete autoFlushThread;
        autoFlushThread = nullptr;
    }
}

bool LoggingSystem::isAutoFlushEnabled() const { return autoFlushEnabled; }

uint64_t LoggingSystem::getLogCount() const { return logCount; }
uint64_t LoggingSystem::getErrorCount() const { return errorCount; }
uint64_t LoggingSystem::getWarningCount() const { return warningCount; }

void LoggingSystem::resetCounters() {
    logCount = 0;
    errorCount = 0;
    warningCount = 0;
}

void LoggingSystem::clearLogFile(const std::string &path) {
    std::ofstream file(path, std::ios::trunc);
}

void LoggingSystem::clearAllLogFiles() {
    if (!std::filesystem::exists(logPath)) return;
    for (auto &entry : std::filesystem::directory_iterator(logPath)) {
        if (entry.path().extension() == ".log") {
            std::filesystem::remove(entry.path());
        }
    }
}

void LoggingSystem::setLogPath(const std::string &path) { logPath = path; }
std::string LoggingSystem::getLogPath() const { return logPath; }

void LoggingSystem::addRemoteEndpoint(const std::string &host, uint16_t port, const std::string &token) {
    LogSinkConfig config;
    config.type = LogSinkType::Remote;
    config.name = "remote_" + host + "_" + std::to_string(port);
    config.host = host;
    config.port = port;
    config.level = LogLevel::Warn;
    config.options["token"] = token;
    auto sink = std::make_shared<RemoteSink>();
    if (sink->initialize(config)) {
        addSink(sink);
    }
}

void LoggingSystem::removeRemoteEndpoint(const std::string &host, uint16_t port) {
    std::string name = "remote_" + host + "_" + std::to_string(port);
    removeSink(name);
}

void LoggingSystem::setRemoteEnabled(bool enable) { remoteEnabled = enable; }
bool LoggingSystem::isRemoteEnabled() const { return remoteEnabled; }

size_t LoggingSystem::getQueueSize() const { return asyncQueue.size(); }
size_t LoggingSystem::getMaxQueueSize() const { return maxQueueSize; }
void LoggingSystem::setMaxQueueSize(size_t size) { maxQueueSize = size; }
void LoggingSystem::setMaxLogAge(uint32_t hours) { maxLogAge = hours; }
void LoggingSystem::enableCompression(bool enable) { compressionEnabled = enable; }

void LoggingSystem::processAsyncQueue() {
    while (initialized || !asyncQueue.empty()) {
        std::unique_lock<std::mutex> lock(queueMutex);
        queueCV.wait_for(lock, std::chrono::milliseconds(100), [this]() { return !asyncQueue.empty() || !initialized; });
        while (!asyncQueue.empty()) {
            auto entry = asyncQueue.front();
            asyncQueue.pop();
            lock.unlock();
            dispatchToSinks(entry);
            lock.lock();
        }
    }
}

void LoggingSystem::autoFlushLoop() {
    while (autoFlushEnabled) {
        std::this_thread::sleep_for(std::chrono::milliseconds(autoFlushInterval));
        flush();
    }
}

LogEntry LoggingSystem::createEntry(LogLevel level, const std::string &logger, const std::string &file, int line, const std::string &function, const std::string &message) {
    LogEntry entry;
    entry.logger = logger;
    entry.message = message;
    entry.level = level;
    entry.file = file;
    entry.function = function;
    entry.line = line;
    entry.timestamp = std::chrono::system_clock::now();
    entry.timestamp_ms = std::chrono::duration_cast<std::chrono::milliseconds>(entry.timestamp.time_since_epoch()).count();
    entry.processId = getpid();
    entry.threadId = syscall(SYS_gettid);
    entry.encrypted = encryptionEnabled;
    entry.compressed = compressionEnabled;
    entry.formatted = formatMessage(entry);
    char threadName[16];
    if (prctl(PR_GET_NAME, threadName) == 0) {
        entry.thread = threadName;
    }
    return entry;
}

void LoggingSystem::dispatchToSinks(const LogEntry &entry) {
    std::shared_lock<std::shared_mutex> lock(sinkMutex);
    for (auto &sink : sinks) {
        if (static_cast<int>(entry.level) >= static_cast<int>(sink->getLevel())) {
            sink->write(entry);
        }
    }
}

bool LoggingSystem::shouldLog(const std::string &logger, LogLevel level) const {
    auto it = loggers.find(logger);
    LogLevel loggerLevel = (it != loggers.end()) ? it->second.level : globalLevel;
    if (static_cast<int>(level) < static_cast<int>(loggerLevel)) return false;
    return true;
}

std::string LoggingSystem::formatMessage(const LogEntry &entry) const {
    return LogFormatter::format(entry, pattern);
}

std::string LogFormatter::format(const LogEntry &entry, const std::string &pattern) {
    std::string result = pattern;
    size_t pos;
    pos = result.find("%v"); if (pos != std::string::npos) result.replace(pos, 2, entry.message);
    pos = result.find("%l"); if (pos != std::string::npos) result.replace(pos, 2, formatLevel(entry.level));
    pos = result.find("%n"); if (pos != std::string::npos) result.replace(pos, 2, entry.logger);
    pos = result.find("%t"); if (pos != std::string::npos) result.replace(pos, 2, entry.thread);
    pos = result.find("%@"); if (pos != std::string::npos) result.replace(pos, 2, formatLocation(entry.file, entry.line, entry.function));
    pos = result.find("%T"); if (pos != std::string::npos) result.replace(pos, 2, std::to_string(entry.threadId));
    pos = result.find("%P"); if (pos != std::string::npos) result.replace(pos, 2, std::to_string(entry.processId));
    pos = result.find("%H"); if (pos != std::string::npos) result.replace(pos, 2, formatTimestamp(entry.timestamp, "%H:%M:%S"));
    pos = result.find("%d"); if (pos != std::string::npos) result.replace(pos, 2, formatTimestamp(entry.timestamp, "%Y-%m-%d"));
    pos = result.find("%D"); if (pos != std::string::npos) result.replace(pos, 2, formatTimestamp(entry.timestamp, "%Y-%m-%d %H:%M:%S"));
    return result;
}

std::string LogFormatter::defaultPattern() { return "[%H:%M:%S] [%l] %v"; }
std::string LogFormatter::detailedPattern() { return "[%D] [%l] [%n] [%t] %@: %v"; }
std::string LogFormatter::compactPattern() { return "%l: %v"; }
std::string LogFormatter::jsonPattern() { return "{\"time\":\"%D\",\"level\":\"%l\",\"logger\":\"%n\",\"message\":\"%v\"}"; }
std::string LogFormatter::encryptedPattern() { return "[ENCRYPTED] %v"; }

std::string LogFormatter::formatTimestamp(const std::chrono::system_clock::time_point &tp, const std::string &format) {
    auto t = std::chrono::system_clock::to_time_t(tp);
    std::tm tm;
    localtime_r(&t, &tm);
    std::ostringstream ss;
    ss << std::put_time(&tm, format.c_str());
    return ss.str();
}

std::string LogFormatter::formatLevel(LogLevel level) {
    switch (level) {
        case LogLevel::Trace: return "TRACE";
        case LogLevel::Debug: return "DEBUG";
        case LogLevel::Info: return "INFO";
        case LogLevel::Warn: return "WARN";
        case LogLevel::Error: return "ERROR";
        case LogLevel::Critical: return "CRITICAL";
        case LogLevel::Fatal: return "FATAL";
        default: return "UNKNOWN";
    }
}

std::string LogFormatter::formatThread() {
    char name[16];
    if (prctl(PR_GET_NAME, name) == 0) return name;
    return std::to_string(syscall(SYS_gettid));
}

std::string LogFormatter::formatLocation(const std::string &file, int line, const std::string &function) {
    std::string result;
    if (!file.empty()) {
        size_t pos = file.rfind('/');
        result += (pos != std::string::npos) ? file.substr(pos + 1) : file;
    }
    if (line > 0) result += ":" + std::to_string(line);
    if (!function.empty()) result += " (" + function + ")";
    return result;
}

std::vector<uint8_t> LogFormatter::encryptFormat(const LogEntry &entry, const std::vector<uint8_t> &key) { return {}; }
LogEntry LogFormatter::parseFromString(const std::string &formatted) { return {}; }
std::string LogFormatter::colorize(const std::string &text, LogLevel level) { return text; }
std::string LogFormatter::stripColor(const std::string &text) { return text; }

ConsoleSink::ConsoleSink() : initialized(false), output(nullptr) {}
ConsoleSink::~ConsoleSink() { shutdown(); }

bool ConsoleSink::initialize(const LogSinkConfig &cfg) {
    config = cfg;
    output = stdout;
    initialized = true;
    return true;
}

void ConsoleSink::shutdown() {
    initialized = false;
    output = nullptr;
}

void ConsoleSink::write(const LogEntry &entry) {
    if (!initialized) return;
    std::lock_guard<std::mutex> lock(writeMutex);
    std::string formatted = LogFormatter::format(entry, config.pattern);
    formatted += "\n";
    writeToConsole(formatted, entry.level);
}

void ConsoleSink::flush() {
    if (output) fflush(output);
}

bool ConsoleSink::isInitialized() const { return initialized; }
LogSinkType ConsoleSink::getType() const { return LogSinkType::Console; }
std::string ConsoleSink::getName() const { return config.name; }
void ConsoleSink::setLevel(LogLevel level) { config.level = level; }
LogLevel ConsoleSink::getLevel() const { return config.level; }

void ConsoleSink::writeToConsole(const std::string &formatted, LogLevel level) {
    if (!output) return;
    fprintf(output, "%s", formatted.c_str());
}

FileSink::FileSink() : initialized(false), currentSize(0) {}
FileSink::~FileSink() { shutdown(); }

bool FileSink::initialize(const LogSinkConfig &cfg) {
    config = cfg;
    if (config.path.empty()) return false;
    currentPath = config.path;
    if (!openFile(currentPath)) return false;
    initialized = true;
    return true;
}

void FileSink::shutdown() {
    initialized = false;
    closeFile();
}

void FileSink::write(const LogEntry &entry) {
    if (!initialized) return;
    std::lock_guard<std::mutex> lock(fileMutex);
    std::string formatted = LogFormatter::format(entry, config.pattern);
    formatted += "\n";
    fileStream << formatted;
    currentSize += formatted.size();
    if (config.maxFileSize > 0 && currentSize >= config.maxFileSize) {
        rotateFile();
    }
}

void FileSink::flush() {
    if (fileStream.is_open()) fileStream.flush();
}

bool FileSink::isInitialized() const { return initialized; }
LogSinkType FileSink::getType() const { return LogSinkType::File; }
std::string FileSink::getName() const { return config.name; }
void FileSink::setLevel(LogLevel level) { config.level = level; }
LogLevel FileSink::getLevel() const { return config.level; }

void FileSink::rotateFile() {
    closeFile();
    std::string backupPath = currentPath + ".1";
    std::filesystem::rename(currentPath, backupPath);
    openFile(currentPath);
    currentSize = 0;
}

std::string FileSink::generateFileName() {
    auto now = std::chrono::system_clock::now();
    auto t = std::chrono::system_clock::to_time_t(now);
    std::tm tm;
    localtime_r(&t, &tm);
    std::ostringstream ss;
    ss << config.path << "." << std::put_time(&tm, "%Y%m%d_%H%M%S");
    return ss.str();
}

bool FileSink::openFile(const std::string &path) {
    fileStream.open(path, std::ios::app);
    if (!fileStream.is_open()) return false;
    currentSize = getFileSize(path);
    return true;
}

void FileSink::closeFile() {
    if (fileStream.is_open()) {
        fileStream.flush();
        fileStream.close();
    }
}

size_t FileSink::getFileSize(const std::string &path) {
    struct stat st;
    if (stat(path.c_str(), &st) == 0) return st.st_size;
    return 0;
}

RotatingFileSink::RotatingFileSink() : initialized(false), currentSize(0), currentFileIndex(0) {}
RotatingFileSink::~RotatingFileSink() { shutdown(); }

bool RotatingFileSink::initialize(const LogSinkConfig &cfg) {
    config = cfg;
    if (config.path.empty()) return false;
    basePath = config.path;
    for (int i = config.maxFiles - 1; i >= 0; --i) {
        std::string path = getRotationPath(i);
        if (std::filesystem::exists(path)) {
            currentFileIndex = i + 1;
            break;
        }
    }
    if (currentFileIndex >= (int)config.maxFiles) currentFileIndex = 0;
    std::string path = getRotationPath(currentFileIndex);
    if (!openFile(path)) return false;
    initialized = true;
    return true;
}

void RotatingFileSink::shutdown() {
    initialized = false;
    if (fileStream.is_open()) {
        fileStream.flush();
        fileStream.close();
    }
}

void RotatingFileSink::write(const LogEntry &entry) {
    if (!initialized) return;
    std::lock_guard<std::mutex> lock(fileMutex);
    std::string formatted = LogFormatter::format(entry, config.pattern);
    formatted += "\n";
    fileStream << formatted;
    currentSize += formatted.size();
    if (config.maxFileSize > 0 && currentSize >= config.maxFileSize) {
        rotateFiles();
    }
}

void RotatingFileSink::flush() {
    if (fileStream.is_open()) fileStream.flush();
}

bool RotatingFileSink::isInitialized() const { return initialized; }
LogSinkType RotatingFileSink::getType() const { return LogSinkType::RotatingFile; }
std::string RotatingFileSink::getName() const { return config.name; }
void RotatingFileSink::setLevel(LogLevel level) { config.level = level; }
LogLevel RotatingFileSink::getLevel() const { return config.level; }

void RotatingFileSink::rotateFiles() {
    if (fileStream.is_open()) {
        fileStream.flush();
        fileStream.close();
    }
    cleanupOldFiles();
    currentFileIndex = (currentFileIndex + 1) % config.maxFiles;
    std::string path = getRotationPath(currentFileIndex);
    openFile(path);
    currentSize = 0;
}

std::string RotatingFileSink::getRotationPath(int index) {
    return basePath + "." + std::to_string(index);
}

void RotatingFileSink::cleanupOldFiles() {
    for (int i = 0; i < (int)config.maxFiles; ++i) {
        std::string path = getRotationPath(i);
        if (std::filesystem::exists(path) && i == currentFileIndex) {
            std::string backup = path + ".old";
            std::filesystem::rename(path, backup);
        }
    }
}

void RotatingFileSink::removeFile(const std::string &path) {
    std::error_code ec;
    std::filesystem::remove(path, ec);
}

bool RotatingFileSink::openFile(const std::string &path) {
    fileStream.open(path, std::ios::app);
    return fileStream.is_open();
}

NetworkSink::NetworkSink() : initialized(false), sock(-1) {}
NetworkSink::~NetworkSink() { shutdown(); }

bool NetworkSink::initialize(const LogSinkConfig &cfg) {
    config = cfg;
    initialized = true;
    return connect();
}

void NetworkSink::shutdown() {
    initialized = false;
    disconnect();
}

void NetworkSink::write(const LogEntry &entry) {
    if (!initialized) return;
    std::lock_guard<std::mutex> lock(networkMutex);
    std::string formatted = LogFormatter::format(entry, config.pattern) + "\n";
    std::vector<uint8_t> data(formatted.begin(), formatted.end());
    sendData(data);
}

void NetworkSink::flush() {}

bool NetworkSink::isInitialized() const { return initialized; }
LogSinkType NetworkSink::getType() const { return LogSinkType::Network; }
std::string NetworkSink::getName() const { return config.name; }
void NetworkSink::setLevel(LogLevel level) { config.level = level; }
LogLevel NetworkSink::getLevel() const { return config.level; }

bool NetworkSink::connect() {
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) return false;
    struct hostent *server = gethostbyname(config.host.c_str());
    if (!server) { close(sock); return false; }
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(config.port);
    memcpy(&addr.sin_addr.s_addr, server->h_addr, server->h_length);
    if (::connect(sock, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        close(sock);
        return false;
    }
    return true;
}

void NetworkSink::disconnect() {
    if (sock >= 0) {
        close(sock);
        sock = -1;
    }
}

bool NetworkSink::sendData(const std::vector<uint8_t> &data) {
    if (sock < 0) {
        if (!connect()) return false;
    }
    int sent = send(sock, data.data(), data.size(), 0);
    if (sent < 0) {
        disconnect();
        return false;
    }
    return true;
}

RemoteSink::RemoteSink() : initialized(false), running(false), senderThread(nullptr) {}
RemoteSink::~RemoteSink() { shutdown(); }

bool RemoteSink::initialize(const LogSinkConfig &cfg) {
    config = cfg;
    apiEndpoint = "http://" + config.host + ":" + std::to_string(config.port) + "/api/logs";
    authToken = config.options["token"];
    initialized = true;
    running = true;
    senderThread = new std::thread(&RemoteSink::senderLoop, this);
    return true;
}

void RemoteSink::shutdown() {
    initialized = false;
    running = false;
    if (senderThread && senderThread->joinable()) {
        senderThread->join();
        delete senderThread;
        senderThread = nullptr;
    }
}

void RemoteSink::write(const LogEntry &entry) {
    if (!initialized) return;
    std::lock_guard<std::mutex> lock(remoteMutex);
    if (pendingEntries.size() < 10000) {
        pendingEntries.push(entry);
    }
}

void RemoteSink::flush() {
    while (!pendingEntries.empty()) {
        auto entry = pendingEntries.front();
        sendToServer(entry);
        pendingEntries.pop();
    }
}

bool RemoteSink::isInitialized() const { return initialized; }
LogSinkType RemoteSink::getType() const { return LogSinkType::Remote; }
std::string RemoteSink::getName() const { return config.name; }
void RemoteSink::setLevel(LogLevel level) { config.level = level; }
LogLevel RemoteSink::getLevel() const { return config.level; }

void RemoteSink::senderLoop() {
    while (running) {
        if (!pendingEntries.empty()) {
            std::lock_guard<std::mutex> lock(remoteMutex);
            auto entry = pendingEntries.front();
            pendingEntries.pop();
            sendToServer(entry);
        } else {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
    }
}

bool RemoteSink::sendToServer(const LogEntry &entry) {
    return true;
}

bool RemoteSink::authenticate() {
    return true;
}

std::string RemoteSink::buildPayload(const LogEntry &entry) {
    return entry.formatted;
}

EncryptedSink::EncryptedSink() : initialized(false) {}
EncryptedSink::~EncryptedSink() { shutdown(); }

bool EncryptedSink::initialize(const LogSinkConfig &cfg) {
    config = cfg;
    if (!config.encryptionKey.empty()) {
        encryptionKey.assign(config.encryptionKey.begin(), config.encryptionKey.end());
    }
    initialized = true;
    return true;
}

void EncryptedSink::shutdown() {
    initialized = false;
    if (innerSink) innerSink->shutdown();
}

void EncryptedSink::write(const LogEntry &entry) {
    if (!initialized) return;
    LogEntry encrypted = entry;
    encrypted.encrypted = true;
    encrypted.message = "[ENCRYPTED]";
    if (innerSink) {
        innerSink->write(encrypted);
    }
}

void EncryptedSink::flush() {
    if (innerSink) innerSink->flush();
}

bool EncryptedSink::isInitialized() const { return initialized; }
LogSinkType EncryptedSink::getType() const { return LogSinkType::Encrypted; }
std::string EncryptedSink::getName() const { return config.name; }
void EncryptedSink::setLevel(LogLevel level) { config.level = level; }
LogLevel EncryptedSink::getLevel() const { return config.level; }
std::vector<uint8_t> EncryptedSink::encryptData(const std::vector<uint8_t> &data) { return data; }
std::vector<uint8_t> EncryptedSink::decryptData(const std::vector<uint8_t> &data) { return data; }

CallbackSink::CallbackSink() : initialized(false) {}
CallbackSink::~CallbackSink() { shutdown(); }

bool CallbackSink::initialize(const LogSinkConfig &cfg) {
    config = cfg;
    initialized = true;
    return true;
}

void CallbackSink::shutdown() {
    initialized = false;
    callback = nullptr;
}

void CallbackSink::write(const LogEntry &entry) {
    if (!initialized || !callback) return;
    std::lock_guard<std::mutex> lock(callbackMutex);
    callback(entry);
}

void CallbackSink::flush() {}

bool CallbackSink::isInitialized() const { return initialized; }
LogSinkType CallbackSink::getType() const { return LogSinkType::Callback; }
std::string CallbackSink::getName() const { return config.name; }
void CallbackSink::setLevel(LogLevel level) { config.level = level; }
LogLevel CallbackSink::getLevel() const { return config.level; }
void CallbackSink::setCallback(std::function<void(const LogEntry&)> cb) { callback = cb; }

}
