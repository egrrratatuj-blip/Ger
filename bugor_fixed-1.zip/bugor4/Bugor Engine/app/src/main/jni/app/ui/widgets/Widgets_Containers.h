#pragma once
#include "../../../../imgui/imgui.h"

void M_CyberHeader(const char* title, ImColor accent = ImColor(0, 180, 255), const char* subtitle = nullptr);
bool M_CardBegin(const char* id, bool* collapsed = nullptr, ImColor accent = ImColor(0, 180, 255));
void M_CardEnd();
bool M_CardContainer(const char* title, bool* collapsed = nullptr, ImColor accent = ImColor(0, 180, 255), const char* badge = nullptr);
bool M_ExpandableSection(const char* title, bool* expanded, ImColor accent = ImColor(0, 180, 255));
void M_SectionDivider(const char* label, ImColor accent = ImColor(0, 180, 255));
void M_InfoRow(const char* label, const char* value, ImColor valueColor = ImColor(255, 255, 255), const char* icon = nullptr);
void M_StatCard(const char* label, const char* value, const char* trend, bool trendUp, ImColor accent = ImColor(0, 180, 255));
void M_GlassTooltip(const char* text, ImVec2 position, ImColor accent = ImColor(0, 180, 255));
void M_Badge(const char* text, ImColor color, ImVec2 position = ImVec2(0, 0));
