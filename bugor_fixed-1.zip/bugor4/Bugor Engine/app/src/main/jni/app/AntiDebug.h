#pragma once
#include <cstdint>
#include <cstddef>

namespace AntiDebug {

enum ProtectionLevel {
    LOW = 0,
    MEDIUM = 1,
    HIGH = 2,
    PARANOID = 3
};

bool IsBeingDebugged();
void ProtectProcess();
void CrashIfDebugged();

void ObfuscateMemory(void* ptr, size_t size);

void StartMonitoring(int level);
void StopMonitoring();

}
