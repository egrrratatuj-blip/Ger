#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "TabESP.h"
#include "../ui_integration.h"
#include "../widgets/Widgets_Switches.h"
#include "../widgets/Widgets_Buttons.h"
#include "../widgets/Widgets_Containers.h"
#include "../widgets/Widgets_Sliders.h"

static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }

static float ClampF(float v, float mn, float mx) { return v < mn ? mn : (v > mx ? mx : v); }

void DrawTabESP(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize)
{
    (void)contentSize;
    Config& c = g_Cfg;
    Toggles& t = g_Tog;
    ImColor accent = c.AccentColor;
    ImColor accent2 = c.AccentColor2;
    float cardW = (contentSize.x - 12.0f) * 0.5f;
    float leftX = contentPos.x;
    float rightX = contentPos.x + cardW + 12.0f;
    float yPos = contentPos.y;
    float fullW = contentSize.x;

    static bool espCol = false;
    static bool infoCol = false;
    static bool hbCol = false;
    static bool skCol = false;
    static bool itemCol = false;
    static bool filterCol = false;
    static bool effectsCol = false;

    static int boxStyleIdx = 0;
    static int barStyleIdx = 0;
    static int skeletonStyleIdx = 0;
    static int filterModeIdx = 0;
    static int snaplineStyleIdx = 0;
    static int boxColorThemeIdx = 0;
    static int lineColorThemeIdx = 0;
    static int nameColorThemeIdx = 0;
    static int distanceColorThemeIdx = 0;
    static int effectPriorityIdx = 0;

    static float healthyHue = 0.30f;
    static float lowHpHue = 0.00f;
    static float snaplineHue = 0.55f;
    static float boxColorHue = 0.58f;
    static float glowIntensity = 0.50f;
    static float chamBrightness = 0.70f;
    static float textOutlineSize = 1.0f;
    static float barBgAlpha = 0.30f;
    static float skeletonThickness = 1.5f;
    static float itemTextSize = 14.0f;
    static float espAlpha = 1.0f;
    static float fillAlpha = 0.30f;
    static float nameOffset = 0.0f;
    static float healthOffset = 0.0f;
    static float distanceOffset = 0.0f;
    static float weaponOffset = 0.0f;
    static float boxRoundness = 0.0f;
    static float espRenderDist = 400.0f;

    static bool showAdvBox = false;
    static bool showAdvHealth = false;
    static bool showAdvSkeleton = false;
    static bool showAdvFilter = false;
    static bool showAdvItem = false;
    static bool showAdvEffects = false;
    static bool showAdvInfo = false;
    static bool showAdvSnapline = false;
    static bool showAdvColors = false;
    static bool showAdvBoxDetail = false;
    static bool showAdvLineDetail = false;
    static bool showAdvItemDetail = false;

    const char* boxStyleOpts[] = { "2D", "Corner", "Filled" };
    const char* barStyleOpts[] = { "Solid", "Gradient", "Outline" };
    const char* skeletonOpts[] = { "Full", "Upper", "Lower" };
    const char* filterOpts[] = { "All", "Enemy", "Team" };
    const char* snaplineStyleOpts[] = { "Line", "Dashed", "Dotted" };
    const char* colorThemeOpts[] = { "Default", "Neon", "Pastel", "Dark", "Custom" };
    const char* priorityOpts[] = { "Low", "Medium", "High", "Critical" };
    char valBuf[128];
    char valBuf2[128];

    ImGui::SetCursorScreenPos(ImVec2(leftX, yPos));
    ImGui::BeginChild("##esp_player_card", ImVec2(cardW, 0.0f), false, ImGuiWindowFlags_NoScrollWithinParentChild);
    if (M_CardBegin("Player ESP", &espCol, accent))
    {
        M_CyberHeader("PLAYER VISUALS", accent2, NULL);

        M_SectionDivider("Master Toggle", accent);
        M_ToggleRow("E", "ESP Enabled", "Master switch for all ESP", &t.PlayerESP, accent);
        if (!t.PlayerESP)
        {
            M_InfoRow("Status", "DISABLED", ImColor(255, 80, 80), "!");
            dl->AddRectFilled(
                ImVec2(leftX + 10, ImGui::GetCursorScreenPos().y),
                ImVec2(leftX + cardW - 10, ImGui::GetCursorScreenPos().y + 24),
                C(ImColor(255, 50, 50, 30)), 4.0f);
            dl->AddRect(
                ImVec2(leftX + 10, ImGui::GetCursorScreenPos().y),
                ImVec2(leftX + cardW - 10, ImGui::GetCursorScreenPos().y + 24),
                C(ImColor(255, 50, 50, 60)), 4.0f, 0, 1.0f);
            ImGui::Dummy(ImVec2(0, 28));
        }

        M_SectionDivider("Box Rendering", accent);
        M_ModernSwitch("Box", &t.Box, accent);
        M_ModernSwitch("Corner Box", &t.CornerBox, accent);
        M_ModernSwitch("Filled Box", &t.BoxFilled, accent);
        M_SegmentedToggle("Box Style", &boxStyleIdx, boxStyleOpts, 3, accent);
        M_GradientSlider("Box Thickness", &c.BoxWidth, 0.5f, 5.0f, "%.1f px", accent);
        M_ColorSlider("Box Color", &boxColorHue, ImColor(200, 200, 255), ImColor(0, 180, 255), accent);
        M_ModernSwitch("Box Outline Glow", &t.Box, accent);
        M_ClassicToggle("Classic Box Style", &t.Box, accent);
        M_FancyCheckbox("Fancy Box Style", &t.BoxFilled, accent);

        M_ExpandableSection("Advanced Box", &showAdvBox, accent);
        if (showAdvBox)
        {
            M_ModernSwitch("Box Outline", &t.Box, accent);
            M_ModernSwitch("Box Glow", &t.BoxFilled, accent);
            M_ModernSwitch("Rainbow Box", &t.Box, accent);
            M_ModernSwitch("Pulsing Box", &t.BoxFilled, accent);
            M_ModernSwitch("Animated Border", &t.Box, accent);
            M_ModernSwitch("Health-Based Color", &t.Box, accent);
            M_ModernSwitch("Distance Fade", &t.Box, accent);
            M_GradientSlider("Outline Width", &c.BoxWidth, 0.5f, 3.0f, "%.1f", accent);
            M_GradientSlider("Box Roundness", &boxRoundness, 0.0f, 8.0f, "%.1f", accent);
            M_ColorSlider("Outline Color", &boxColorHue, ImColor(255, 255, 255), ImColor(100, 100, 255), accent);
            M_GradientSlider("Fill Opacity", &fillAlpha, 0.0f, 1.0f, "%.2f", accent);
            M_GradientSlider("ESP Alpha", &espAlpha, 0.0f, 1.0f, "%.2f", accent);
            M_InfoRow("Sub-Options", "Extended", accent, "+");
            M_Switch3D("3D Box Style", &t.Box, accent);
            M_RadioSelector("Radio Box On", t.Box, accent);
            M_RadioSelector("Radio Box Off", !t.Box, accent);
        }

        M_ExpandableSection("Box Detail Config", &showAdvBoxDetail, accent);
        if (showAdvBoxDetail)
        {
            M_ModernSwitch("Show Team Colors", &t.Box, accent);
            M_ModernSwitch("Show Enemy Colors", &t.Box, accent);
            M_ModernSwitch("Show Distance Color", &t.Box, accent);
            M_ModernSwitch("Show Health Color", &t.Box, accent);
            M_ModernSwitch("Show Weapon Color", &t.Box, accent);
            M_ModernSwitch("Color Gradient Mode", &t.BoxFilled, accent);
            M_GradientSlider("Team Color Blend", &boxColorHue, 0.0f, 1.0f, "%.2f", accent);
            M_GradientSlider("Enemy Color Blend", &snaplineHue, 0.0f, 1.0f, "%.2f", accent);
            M_ColorSlider("Team Box Color", &boxColorHue, ImColor(0, 150, 255), ImColor(0, 200, 100), accent);
            M_ColorSlider("Enemy Box Color", &snaplineHue, ImColor(255, 0, 0), ImColor(255, 100, 0), accent);
        }

        M_SectionDivider("Snapline Settings", accent);
        M_ModernSwitch("Snaplines", &t.Snaplines, accent);
        M_ModernSwitch("Snaplines (Bottom)", &t.LineFromBottom, accent);
        M_SegmentedToggle("Snapline Style", &snaplineStyleIdx, snaplineStyleOpts, 3, accent);
        M_GradientSlider("Max Distance", &c.ESPMaxDistance, 50.0f, 2000.0f, "%.0f m", accent);

        M_ExpandableSection("Advanced Snaplines", &showAdvSnapline, accent);
        if (showAdvSnapline)
        {
            M_ModernSwitch("Snapline Glow", &t.Snaplines, accent);
            M_ModernSwitch("Snapline Gradient", &t.Snaplines, accent);
            M_ModernSwitch("Snapline From Center", &t.LineFromBottom, accent);
            M_ModernSwitch("Snapline From Top", &t.Snaplines, accent);
            M_ModernSwitch("Snapline From Crosshair", &t.Snaplines, accent);
            M_ModernSwitch("Snapline Color By Distance", &t.Snaplines, accent);
            M_GradientSlider("Snapline Thickness", &c.LineWidth, 0.5f, 4.0f, "%.1f", accent);
            M_ColorSlider("Snapline Hue", &snaplineHue, ImColor(100, 100, 255), ImColor(255, 100, 100), accent);
        }

        M_SectionDivider("Color Themes", accent);
        M_DropdownSelect("Box Color Theme", &boxColorThemeIdx, colorThemeOpts, 5, accent);
        M_DropdownSelect("Line Color Theme", &lineColorThemeIdx, colorThemeOpts, 5, accent);

        M_SectionDivider("Status Overview", accent);
        M_InfoRow("Box Mode", "", accent, "B");
        const char* boxModeStr = t.Box ? (t.CornerBox ? "Corner" : (t.BoxFilled ? "Filled" : "Standard")) : "Off";
        snprintf(valBuf, sizeof(valBuf), "%s", boxModeStr);
        M_InfoRow("", valBuf, accent, NULL);
        M_InfoRow("Thickness", "", accent, "T");
        snprintf(valBuf, sizeof(valBuf), "%.1f px", c.BoxWidth);
        M_InfoRow("", valBuf, accent, NULL);
        M_InfoRow("Render Distance", "", accent, "R");
        snprintf(valBuf, sizeof(valBuf), "%.0f m", c.ESPMaxDistance);
        M_InfoRow("", valBuf, accent, NULL);
        M_InfoRow("Fill Alpha", "", accent, "F");
        snprintf(valBuf, sizeof(valBuf), "%.0f%%", fillAlpha * 100.0f);
        M_InfoRow("", valBuf, accent, NULL);
        M_InfoRow("Box Roundness", "", accent, "O");
        snprintf(valBuf, sizeof(valBuf), "%.1f px", boxRoundness);
        M_InfoRow("", valBuf, accent, NULL);
        M_InfoRow("Snaplines", t.Snaplines ? "On" : "Off", t.Snaplines ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "S");
        M_InfoRow("Bottom Line", t.LineFromBottom ? "On" : "Off", t.LineFromBottom ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "B");

        M_BooleanIndicator("Box Enabled", t.Box, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Snaplines Active", t.Snaplines, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Filled Box Active", t.BoxFilled, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Corner Box Active", t.CornerBox, accent, ImColor(60, 60, 70));

        dl->AddRectFilled(
            ImVec2(leftX + 8, ImGui::GetCursorScreenPos().y),
            ImVec2(leftX + cardW - 8, ImGui::GetCursorScreenPos().y + 2),
            C(ImColor(255, 255, 255, 10)), 1.0f);
        ImGui::Dummy(ImVec2(0, 4));

        M_Badge("ESP", accent, ImVec2(leftX + 8, ImGui::GetCursorScreenPos().y));
        ImGui::Dummy(ImVec2(0, 4));

        M_ActionButton("B", "Toggle Boxes", ImVec2(cardW - 20, 36), accent, NULL);
        M_ActionButton("L", "Toggle Lines", ImVec2(cardW - 20, 36), accent, NULL);

        int boxCount = (t.Box ? 1 : 0) + (t.CornerBox ? 1 : 0) + (t.BoxFilled ? 1 : 0);
        snprintf(valBuf, sizeof(valBuf), "%d/3", boxCount);
        M_StatCard("Box Modes", valBuf, NULL, false, accent);

        M_IconButton("B", "Toggle Box", ImVec2(36, 36), accent, t.Box, 0);
        M_IconButton("S", "Toggle Snapline", ImVec2(36, 36), accent, t.Snaplines, 0);
    }
    M_CardEnd();
    ImGui::EndChild();
    float yL1 = ImGui::GetCursorScreenPos().y;

    ImGui::SetCursorScreenPos(ImVec2(rightX, yPos));
    ImGui::BeginChild("##esp_info_card", ImVec2(cardW, 0.0f), false, ImGuiWindowFlags_NoScrollWithinParentChild);
    if (M_CardBegin("Player Info", &infoCol, accent))
    {
        M_CyberHeader("PLAYER INFO", accent2, NULL);

        M_SectionDivider("Label Display", accent);
        M_ModernSwitch("Name", &t.Name, accent);
        M_ModernSwitch("Distance", &t.Distance, accent);
        M_ModernSwitch("Health Text", &t.Health, accent);
        M_ClassicToggle("Classic Name Label", &t.Name, accent);
        M_FancyCheckbox("Fancy Distance", &t.Distance, accent);

        M_SectionDivider("Equipment Info", accent);
        M_ModernSwitch("Weapon", &t.Weapon, accent);
        M_ModernSwitch("Armor", &t.Armor, accent);
        M_ModernSwitch("Shield", &t.Shield, accent);
        M_ModernSwitch("Faction", &t.Faction, accent);
        M_Switch3D("3D Equipment Icons", &t.Weapon, accent);

        M_ExpandableSection("Equipment Detail", &showAdvInfo, accent);
        if (showAdvInfo)
        {
            M_ModernSwitch("Show Weapon Tier", &t.Weapon, accent);
            M_ModernSwitch("Show Weapon Ammo", &t.Weapon, accent);
            M_ModernSwitch("Show Weapon Attachments", &t.Weapon, accent);
            M_ModernSwitch("Show Armor Tier", &t.Armor, accent);
            M_ModernSwitch("Show Shield HP", &t.Shield, accent);
            M_ModernSwitch("Show Faction Icon", &t.Faction, accent);
            M_ModernSwitch("Show Faction Name", &t.Faction, accent);
            M_ModernSwitch("Show Gear Score", &t.Armor, accent);
            M_ModernSwitch("Show Backpack Info", &t.Armor, accent);
            M_GradientSlider("Equipment Text Size", &itemTextSize, 10.0f, 24.0f, "%.0f", accent);
            M_ColorSlider("Equipment Color", &boxColorHue, ImColor(200, 200, 255), ImColor(0, 255, 200), accent);
        }

        M_SectionDivider("Text Configuration", accent);
        M_GradientSlider("Text Size", &c.TextSize, 12.0f, 32.0f, "%.0f pt", accent);
        M_DropdownSelect("Name Color Theme", &nameColorThemeIdx, colorThemeOpts, 5, accent);
        M_DropdownSelect("Distance Color Theme", &distanceColorThemeIdx, colorThemeOpts, 5, accent);

        M_ExpandableSection("Advanced Info", &showAdvColors, accent);
        if (showAdvColors)
        {
            M_ModernSwitch("Show Distance Units", &t.Distance, accent);
            M_ModernSwitch("Show Health Percentage", &t.Health, accent);
            M_ModernSwitch("Show Weapon Icon", &t.Weapon, accent);
            M_ModernSwitch("Show Ammo Count", &t.Weapon, accent);
            M_ModernSwitch("Show Player Level", &t.Name, accent);
            M_ModernSwitch("Show Clan Tag", &t.Name, accent);
            M_ModernSwitch("Show Platform Icon", &t.Faction, accent);
            M_ModernSwitch("Show Ping", &t.Distance, accent);
            M_ModernSwitch("Show Bot Tag", &t.Name, accent);
            M_ModernSwitch("Show Rank Badge", &t.Name, accent);
            M_GradientSlider("Label Offset", &textOutlineSize, 0.0f, 5.0f, "%.1f", accent);
            M_GradientSlider("Label Spacing", &textOutlineSize, 0.0f, 10.0f, "%.1f", accent);
            M_GradientSlider("Name Y Offset", &nameOffset, -20.0f, 20.0f, "%.1f", accent);
            M_GradientSlider("Health Y Offset", &healthOffset, -20.0f, 20.0f, "%.1f", accent);
            M_GradientSlider("Distance Y Offset", &distanceOffset, -20.0f, 20.0f, "%.1f", accent);
            M_GradientSlider("Weapon Y Offset", &weaponOffset, -20.0f, 20.0f, "%.1f", accent);
            M_ColorSlider("Text Color", &boxColorHue, ImColor(255, 255, 255), ImColor(0, 200, 255), accent);
            M_ColorSlider("Distance Color", &snaplineHue, ImColor(255, 255, 100), ImColor(0, 255, 200), accent);
            M_ColorSlider("Health Text Color", &healthyHue, ImColor(0, 255, 0), ImColor(255, 0, 0), accent);
            M_ColorSlider("Weapon Color", &snaplineHue, ImColor(200, 200, 255), ImColor(255, 200, 0), accent);
            M_KnobDial("Label Brightness", &chamBrightness, 0.0f, 1.0f, "%.2f", accent);
            M_RadioSelector("Left Align", t.Name, accent);
            M_RadioSelector("Center Align", !t.Name, accent);
            M_RadioSelector("Right Align", !t.Name, accent);
        }

        M_SectionDivider("Current Settings", accent);
        M_InfoRow("Name Display", t.Name ? "Visible" : "Hidden", t.Name ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "N");
        M_InfoRow("Distance Display", t.Distance ? "Visible" : "Hidden", t.Distance ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "D");
        M_InfoRow("Health Display", t.Health ? "Visible" : "Hidden", t.Health ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "H");
        M_InfoRow("Weapon Display", t.Weapon ? "Visible" : "Hidden", t.Weapon ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "W");
        M_InfoRow("Armor Display", t.Armor ? "Visible" : "Hidden", t.Armor ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "A");
        M_InfoRow("Shield Display", t.Shield ? "Visible" : "Hidden", t.Shield ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "S");
        M_InfoRow("Faction Display", t.Faction ? "Visible" : "Hidden", t.Faction ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "F");
        M_InfoRow("Text Size", "", accent, "S");
        snprintf(valBuf, sizeof(valBuf), "%.0f pt", c.TextSize);
        M_InfoRow("", valBuf, accent, NULL);
        M_InfoRow("Name Theme", colorThemeOpts[nameColorThemeIdx], accent, "T");
        M_InfoRow("Distance Theme", colorThemeOpts[distanceColorThemeIdx], accent, "T");

        M_BooleanIndicator("Name Active", t.Name, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Weapon Active", t.Weapon, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Armor Active", t.Armor, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Shield Active", t.Shield, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Faction Active", t.Faction, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Distance Active", t.Distance, accent, ImColor(60, 60, 70));

        dl->AddRectFilled(
            ImVec2(rightX + 8, ImGui::GetCursorScreenPos().y),
            ImVec2(rightX + cardW - 8, ImGui::GetCursorScreenPos().y + 2),
            C(ImColor(255, 255, 255, 10)), 1.0f);
        ImGui::Dummy(ImVec2(0, 4));

        int infoCount = (t.Name ? 1 : 0) + (t.Distance ? 1 : 0) + (t.Health ? 1 : 0) +
                        (t.Weapon ? 1 : 0) + (t.Armor ? 1 : 0) + (t.Shield ? 1 : 0) +
                        (t.Faction ? 1 : 0);
        snprintf(valBuf, sizeof(valBuf), "%d/7", infoCount);
        M_StatCard("Active Labels", valBuf, NULL, false, accent);

        M_ActionButton("R", "Reset Info Defaults", ImVec2(cardW - 20, 36), accent, NULL);
        M_IconButton("I", "Info Overview", ImVec2(36, 36), accent, false, 0);
    }
    M_CardEnd();
    ImGui::EndChild();
    float yR1 = ImGui::GetCursorScreenPos().y;

    yPos = (yL1 > yR1 ? yL1 : yR1) + 4.0f;

    ImGui::SetCursorScreenPos(ImVec2(leftX, yPos));
    ImGui::BeginChild("##esp_health_card", ImVec2(cardW, 0.0f), false, ImGuiWindowFlags_NoScrollWithinParentChild);
    if (M_CardBegin("Health Bar", &hbCol, accent))
    {
        M_CyberHeader("HEALTH BAR", accent2, NULL);

        M_SectionDivider("Toggle", accent);
        M_ModernSwitch("Health Bar", &t.HealthBar, accent);
        M_Switch3D("3D Health Bar", &t.HealthBar, accent);

        M_SectionDivider("Dimensions", accent);
        M_IntSlider("Bar Width", (int*)&c.HealthBarWidth, 2, 10, "%d px", accent);
        M_KnobDial("Bar Size", &c.HealthBarWidth, 2.0f, 10.0f, "%.0f", accent);

        M_SectionDivider("Color Configuration", accent);
        M_ColorSlider("Healthy Color", &healthyHue, ImColor(255, 255, 0), ImColor(0, 255, 0), accent);
        M_ColorSlider("Low HP Color", &lowHpHue, ImColor(255, 0, 0), ImColor(255, 165, 0), accent);

        M_SectionDivider("Visual Style", accent);
        M_SegmentedToggle("Bar Style", &barStyleIdx, barStyleOpts, 3, accent);

        M_ExpandableSection("Advanced Health Bar", &showAdvHealth, accent);
        if (showAdvHealth)
        {
            M_ModernSwitch("Show Background", &t.HealthBar, accent);
            M_GradientSlider("Background Opacity", &barBgAlpha, 0.0f, 1.0f, "%.2f", accent);
            M_ModernSwitch("Show Border", &t.HealthBar, accent);
            M_ModernSwitch("Show Percentage", &t.Health, accent);
            M_ModernSwitch("Animated Bar", &t.HealthBar, accent);
            M_ModernSwitch("Health Color Gradient", &t.HealthBar, accent);
            M_ModernSwitch("Show Damage Flash", &t.HealthBar, accent);
            M_ModernSwitch("Show Shield Bar", &t.Shield, accent);
            M_ModernSwitch("Show Armor Bar", &t.Armor, accent);
            M_ModernSwitch("Show Health Icon", &t.HealthBar, accent);
            M_ModernSwitch("Show Background Glow", &t.HealthBar, accent);
            M_IntSlider("Bar Height", (int*)&c.HealthBarWidth, 2, 8, "%d px", accent);
            M_ColorSlider("Bar Border Color", &boxColorHue, ImColor(255, 255, 255), ImColor(100, 100, 100), accent);
            M_ColorSlider("Bar Background", &snaplineHue, ImColor(60, 60, 60), ImColor(30, 30, 30), accent);
            M_ColorSlider("Bar Glow Color", &healthyHue, ImColor(0, 255, 0), ImColor(255, 200, 0), accent);
            M_GradientSlider("Glow Spread", &glowIntensity, 0.0f, 10.0f, "%.1f", accent);
            M_ClassicToggle("Classic Bar", &t.HealthBar, accent);
            M_FancyCheckbox("Fancy Bar", &t.HealthBar, accent);
        }

        M_SectionDivider("Status", accent);
        M_InfoRow("Health Bar State", t.HealthBar ? "Enabled" : "Disabled", t.HealthBar ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "H");
        M_InfoRow("Bar Width", "", accent, "W");
        snprintf(valBuf, sizeof(valBuf), "%d px", (int)c.HealthBarWidth);
        M_InfoRow("", valBuf, accent, NULL);
        M_InfoRow("Bar Style", barStyleOpts[barStyleIdx], accent, "S");
        M_InfoRow("Healthy Hue", "", accent, "G");
        snprintf(valBuf, sizeof(valBuf), "%.0f%%", healthyHue * 100.0f);
        M_InfoRow("", valBuf, accent, NULL);
        M_InfoRow("Low HP Hue", "", accent, "R");
        snprintf(valBuf, sizeof(valBuf), "%.0f%%", lowHpHue * 100.0f);
        M_InfoRow("", valBuf, accent, NULL);
        M_InfoRow("Background Alpha", "", accent, "A");
        snprintf(valBuf, sizeof(valBuf), "%.0f%%", barBgAlpha * 100.0f);
        M_InfoRow("", valBuf, accent, NULL);

        M_BooleanIndicator("Health Bar Active", t.HealthBar, accent, ImColor(60, 60, 70));

        dl->AddRectFilled(
            ImVec2(leftX + 8, ImGui::GetCursorScreenPos().y),
            ImVec2(leftX + cardW - 8, ImGui::GetCursorScreenPos().y + 2),
            C(ImColor(255, 255, 255, 10)), 1.0f);
        ImGui::Dummy(ImVec2(0, 4));

        ImColor healthyCol = ImColor(0, 255, 0, 200);
        ImColor lowCol = ImColor(255, 0, 0, 200);
        M_Badge("HP", healthyCol, ImVec2(leftX + 8, ImGui::GetCursorScreenPos().y));
        ImGui::Dummy(ImVec2(0, 4));

        M_ButtonGroup("Bar Group", &barStyleIdx, barStyleOpts, 3, accent);
        M_GlassTooltip("Health bar width and color settings", ImVec2(leftX + 20, ImGui::GetCursorScreenPos().y), accent);
        M_RadioSelector("Solid Style", barStyleIdx == 0, accent);
        M_RadioSelector("Gradient Style", barStyleIdx == 1, accent);
        M_RadioSelector("Outline Style", barStyleIdx == 2, accent);
        M_InfoRow("Bar Preview", barStyleOpts[barStyleIdx], accent, "*");
        M_InfoRow("Bar Color Mode", "", accent, "C");
        snprintf(valBuf, sizeof(valBuf), "HP: %.0f%% | Low: %.0f%%", healthyHue * 100.0f, lowHpHue * 100.0f);
        M_InfoRow("", valBuf, accent, NULL);
    }
    M_CardEnd();
    ImGui::EndChild();
    float yL2 = ImGui::GetCursorScreenPos().y;

    ImGui::SetCursorScreenPos(ImVec2(rightX, yPos));
    ImGui::BeginChild("##esp_skeleton_card", ImVec2(cardW, 0.0f), false, ImGuiWindowFlags_NoScrollWithinParentChild);
    if (M_CardBegin("Skeleton & Lines", &skCol, accent))
    {
        M_CyberHeader("SKELETON & LINES", accent2, NULL);

        M_SectionDivider("Skeleton Rendering", accent);
        M_ModernSwitch("Skeleton", &t.Skeleton, accent);
        M_SegmentedToggle("Skeleton Style", &skeletonStyleIdx, skeletonOpts, 3, accent);
        M_GradientSlider("Bone Thickness", &skeletonThickness, 0.5f, 3.0f, "%.1f px", accent);
        M_Switch3D("3D Skeleton", &t.Skeleton, accent);

        M_ExpandableSection("Advanced Skeleton", &showAdvSkeleton, accent);
        if (showAdvSkeleton)
        {
            M_ModernSwitch("Show Joints", &t.Skeleton, accent);
            M_ModernSwitch("Show Bones", &t.Skeleton, accent);
            M_ModernSwitch("Glow Effect", &t.Skeleton, accent);
            M_ModernSwitch("Show Head Circle", &t.Skeleton, accent);
            M_ModernSwitch("Show Spine Line", &t.Skeleton, accent);
            M_ModernSwitch("Show Limb Lines", &t.Skeleton, accent);
            M_ModernSwitch("Show Hand Bones", &t.Skeleton, accent);
            M_ModernSwitch("Show Foot Bones", &t.Skeleton, accent);
            M_ModernSwitch("Show Chest Bone", &t.Skeleton, accent);
            M_ModernSwitch("Color by Health", &t.Skeleton, accent);
            M_ModernSwitch("Color by Team", &t.Skeleton, accent);
            M_ModernSwitch("Dynamic Thickness", &t.Skeleton, accent);
            M_ColorSlider("Bone Color", &snaplineHue, ImColor(100, 200, 255), ImColor(255, 150, 100), accent);
            M_ColorSlider("Joint Color", &snaplineHue, ImColor(255, 255, 255), ImColor(0, 200, 255), accent);
            M_GradientSlider("Glow Radius", &skeletonThickness, 0.0f, 5.0f, "%.1f", accent);
            M_GradientSlider("Joint Size", &skeletonThickness, 1.0f, 6.0f, "%.1f", accent);
            M_ClassicToggle("Classic Skeleton", &t.Skeleton, accent);
        }

        M_SectionDivider("Snapline", accent);
        M_ModernSwitch("Snapline", &t.Snaplines, accent);
        M_ColorSlider("Snapline Color", &snaplineHue, ImColor(100, 100, 255), ImColor(255, 100, 100), accent);
        M_GradientSlider("Line Width", &c.LineWidth, 0.5f, 3.0f, "%.1f px", accent);

        M_SectionDivider("Aim Assistance", accent);
        M_ModernSwitch("Aim Line", &t.AimLine, accent);
        M_GradientSlider("Aim Line Width", &c.LineWidth, 0.5f, 3.0f, "%.1f", accent);
        M_ColorSlider("Aim Line Color", &snaplineHue, ImColor(0, 255, 100), ImColor(255, 50, 50), accent);

        M_ExpandableSection("Line Detail", &showAdvLineDetail, accent);
        if (showAdvLineDetail)
        {
            M_ModernSwitch("Line Glow", &t.Snaplines, accent);
            M_ModernSwitch("Line Gradient", &t.Snaplines, accent);
            M_ModernSwitch("Line Animation", &t.Snaplines, accent);
            M_ModernSwitch("Line Dashed Effect", &t.Snaplines, accent);
            M_ModernSwitch("Line Color By Distance", &t.Snaplines, accent);
            M_ModernSwitch("Line From Multiple Origins", &t.LineFromBottom, accent);
            M_GradientSlider("Line Glow Width", &c.LineWidth, 0.0f, 5.0f, "%.1f", accent);
            M_ColorSlider("Line Glow Color", &snaplineHue, ImColor(100, 100, 255), ImColor(255, 100, 255), accent);
        }

        M_SectionDivider("Status", accent);
        M_InfoRow("Skeleton State", t.Skeleton ? "Rendering" : "Off", t.Skeleton ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "K");
        M_InfoRow("Snapline State", t.Snaplines ? "Rendering" : "Off", t.Snaplines ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "L");
        M_InfoRow("Aim Line State", t.AimLine ? "Rendering" : "Off", t.AimLine ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "A");
        M_InfoRow("Line Width", "", accent, "W");
        snprintf(valBuf, sizeof(valBuf), "%.1f px", c.LineWidth);
        M_InfoRow("", valBuf, accent, NULL);
        M_InfoRow("Bone Thickness", "", accent, "B");
        snprintf(valBuf, sizeof(valBuf), "%.1f px", skeletonThickness);
        M_InfoRow("", valBuf, accent, NULL);
        M_InfoRow("Skeleton Style", skeletonOpts[skeletonStyleIdx], accent, "S");

        M_BooleanIndicator("Skeleton Active", t.Skeleton, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Aim Line Active", t.AimLine, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Snapline Active", t.Snaplines, accent, ImColor(60, 60, 70));

        dl->AddRectFilled(
            ImVec2(rightX + 8, ImGui::GetCursorScreenPos().y),
            ImVec2(rightX + cardW - 8, ImGui::GetCursorScreenPos().y + 2),
            C(ImColor(255, 255, 255, 10)), 1.0f);
        ImGui::Dummy(ImVec2(0, 4));

        int skActive = (t.Skeleton ? 1 : 0) + (t.Snaplines ? 1 : 0) + (t.AimLine ? 1 : 0);
        snprintf(valBuf, sizeof(valBuf), "%d/3", skActive);
        M_StatCard("Active Lines", valBuf, NULL, false, accent);

        M_ActionButton("S", "Toggle Skeleton", ImVec2(cardW - 20, 36), accent, NULL);
        M_IconButton("K", "Skeleton On/Off", ImVec2(36, 36), accent, t.Skeleton, 0);
        M_RadioSelector("Full Body", skeletonStyleIdx == 0, accent);
        M_RadioSelector("Upper Body", skeletonStyleIdx == 1, accent);
        M_RadioSelector("Lower Body", skeletonStyleIdx == 2, accent);
        M_InfoRow("Style Preview", skeletonOpts[skeletonStyleIdx], accent, "*");
        M_InfoRow("Bone Count", "", accent, "B");
        snprintf(valBuf, sizeof(valBuf), "%s Mode", skeletonOpts[skeletonStyleIdx]);
        M_InfoRow("", valBuf, accent, NULL);
    }
    M_CardEnd();
    ImGui::EndChild();
    float yR2 = ImGui::GetCursorScreenPos().y;

    yPos = (yL2 > yR2 ? yL2 : yR2) + 4.0f;

    ImGui::SetCursorScreenPos(ImVec2(leftX, yPos));
    ImGui::BeginChild("##esp_item_card", ImVec2(cardW, 0.0f), false, ImGuiWindowFlags_NoScrollWithinParentChild);
    if (M_CardBegin("Item ESP", &itemCol, accent))
    {
        M_CyberHeader("ITEM ESP", accent2, NULL);

        M_SectionDivider("World Pickups", accent);
        M_ModernSwitch("Items", &t.ItemESP, accent);
        M_ModernSwitch("Supplies", &t.SupplyESP, accent);
        M_ModernSwitch("Collectibles", &t.CollectibleESP, accent);
        M_ClassicToggle("Classic Item Label", &t.ItemESP, accent);
        M_FancyCheckbox("Fancy Item Icon", &t.ItemESP, accent);

        M_SectionDivider("Entities", accent);
        M_ModernSwitch("Vehicles", &t.VehicleESP, accent);
        M_ModernSwitch("Traps", &t.TrapESP, accent);
        M_ModernSwitch("NPCs", &t.NpcESP, accent);
        M_Switch3D("3D NPC Labels", &t.NpcESP, accent);

        M_ExpandableSection("Advanced Items", &showAdvItem, accent);
        if (showAdvItem)
        {
            M_ModernSwitch("Show Item Names", &t.ItemESP, accent);
            M_ModernSwitch("Show Item Distance", &t.ItemESP, accent);
            M_ModernSwitch("Show Rarity Colors", &t.ItemESP, accent);
            M_ModernSwitch("Show Ammo Count", &t.ItemESP, accent);
            M_ModernSwitch("Show Item Count", &t.ItemESP, accent);
            M_ModernSwitch("Show Loot Tier", &t.ItemESP, accent);
            M_ModernSwitch("Filter by Rarity", &t.ItemESP, accent);
            M_ModernSwitch("Show Only Weapons", &t.ItemESP, accent);
            M_ModernSwitch("Show Only Ammo", &t.SupplyESP, accent);
            M_ModernSwitch("Show Only Meds", &t.SupplyESP, accent);
            M_ModernSwitch("Show Only Armor", &t.ItemESP, accent);
            M_ModernSwitch("Show Attachments", &t.ItemESP, accent);
            M_ModernSwitch("Show Consumables", &t.ItemESP, accent);
            M_ModernSwitch("Show Keycards", &t.CollectibleESP, accent);
            M_GradientSlider("Item Text Size", &itemTextSize, 10.0f, 24.0f, "%.0f", accent);
            M_ColorSlider("Item Color", &boxColorHue, ImColor(255, 255, 100), ImColor(0, 255, 200), accent);
            M_ColorSlider("Rarity Color", &snaplineHue, ImColor(255, 200, 0), ImColor(200, 0, 255), accent);
            M_ColorSlider("Rare Item Color", &healthyHue, ImColor(255, 200, 0), ImColor(255, 50, 200), accent);
            M_ColorSlider("Legendary Color", &lowHpHue, ImColor(255, 100, 0), ImColor(200, 0, 255), accent);
        }

        M_SectionDivider("Range", accent);
        M_GradientSlider("Max Distance", &c.ESPMaxDistance, 50.0f, 2000.0f, "%.0f m", accent);
        M_RangeSlider("Distance Range", &espRenderDist, &c.ESPMaxRender, 50.0f, 2000.0f, "%.0f", accent);

        M_SectionDivider("Status", accent);
        M_InfoRow("Items", t.ItemESP ? "On" : "Off", t.ItemESP ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "I");
        M_InfoRow("Supplies", t.SupplyESP ? "On" : "Off", t.SupplyESP ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "S");
        M_InfoRow("Collectibles", t.CollectibleESP ? "On" : "Off", t.CollectibleESP ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "C");
        M_InfoRow("Vehicles", t.VehicleESP ? "On" : "Off", t.VehicleESP ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "V");
        M_InfoRow("Traps", t.TrapESP ? "On" : "Off", t.TrapESP ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "T");
        M_InfoRow("NPCs", t.NpcESP ? "On" : "Off", t.NpcESP ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "N");
        M_InfoRow("Max Render Range", "", accent, "R");
        snprintf(valBuf, sizeof(valBuf), "%.0f m", c.ESPMaxDistance);
        M_InfoRow("", valBuf, accent, NULL);
        M_InfoRow("Item Text Size", "", accent, "Z");
        snprintf(valBuf, sizeof(valBuf), "%.0f pt", itemTextSize);
        M_InfoRow("", valBuf, accent, NULL);

        M_BooleanIndicator("Item ESP Active", t.ItemESP, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Vehicle ESP", t.VehicleESP, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("NPC ESP", t.NpcESP, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Trap ESP", t.TrapESP, accent, ImColor(60, 60, 70));

        dl->AddRectFilled(
            ImVec2(leftX + 8, ImGui::GetCursorScreenPos().y),
            ImVec2(leftX + cardW - 8, ImGui::GetCursorScreenPos().y + 2),
            C(ImColor(255, 255, 255, 10)), 1.0f);
        ImGui::Dummy(ImVec2(0, 4));

        int itemCount = (t.ItemESP ? 1 : 0) + (t.SupplyESP ? 1 : 0) + (t.CollectibleESP ? 1 : 0) +
                        (t.VehicleESP ? 1 : 0) + (t.TrapESP ? 1 : 0) + (t.NpcESP ? 1 : 0);
        snprintf(valBuf, sizeof(valBuf), "%d/6", itemCount);
        M_Badge("Items", accent, ImVec2(leftX + 8, ImGui::GetCursorScreenPos().y));
        ImGui::Dummy(ImVec2(0, 4));

        M_StatCard("Item Categories", valBuf, NULL, false, accent);
        M_InfoRow("Weapons", t.ItemESP ? "Tracked" : "Ignored", t.ItemESP ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "W");
        M_InfoRow("Supplies", t.SupplyESP ? "Tracked" : "Ignored", t.SupplyESP ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "S");
        M_InfoRow("Vehicles", t.VehicleESP ? "Tracked" : "Ignored", t.VehicleESP ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "V");
        M_InfoRow("Traps", t.TrapESP ? "Tracked" : "Ignored", t.TrapESP ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "T");
    }
    M_CardEnd();
    ImGui::EndChild();
    float yL3 = ImGui::GetCursorScreenPos().y;

    ImGui::SetCursorScreenPos(ImVec2(rightX, yPos));
    ImGui::BeginChild("##esp_filter_card", ImVec2(cardW, 0.0f), false, ImGuiWindowFlags_NoScrollWithinParentChild);
    if (M_CardBegin("Filters", &filterCol, accent))
    {
        M_CyberHeader("FILTERS", accent2, NULL);

        M_SectionDivider("Entity Visibility", accent);
        M_ModernSwitch("Show Enemies", &t.FilterEnemy, accent);
        M_ModernSwitch("Show Teammates", &t.FilterTeam, accent);
        M_ModernSwitch("Show Self", &t.FilterSelf, accent);
        M_ClassicToggle("Classic Filters", &t.FilterEnemy, accent);
        M_Switch3D("3D Filter Mode", &t.FilterEnemy, accent);

        M_SectionDivider("Culling Options", accent);
        M_ModernSwitch("Visible Only", &t.FilterVisible, accent);
        M_ModernSwitch("Filter by Distance", &t.FilterDistance, accent);
        M_SegmentedToggle("Filter Mode", &filterModeIdx, filterOpts, 3, accent);
        M_GradientSlider("Max Distance", &c.ESPMaxDistance, 50.0f, 2000.0f, "%.0f m", accent);

        M_ExpandableSection("Advanced Filters", &showAdvFilter, accent);
        if (showAdvFilter)
        {
            M_ModernSwitch("Filter by Team ID", &t.FilterTeam, accent);
            M_ModernSwitch("Filter by Health %", &t.FilterDistance, accent);
            M_ModernSwitch("Filter by Weapon Type", &t.FilterEnemy, accent);
            M_ModernSwitch("Ignore Bots", &t.FilterTeam, accent);
            M_ModernSwitch("Ignore Downed", &t.FilterTeam, accent);
            M_ModernSwitch("Ignore Spectators", &t.FilterTeam, accent);
            M_ModernSwitch("Show Only Prioritized", &t.FilterEnemy, accent);
            M_ModernSwitch("Filter by Armor", &t.FilterEnemy, accent);
            M_ModernSwitch("Filter by Rank", &t.FilterEnemy, accent);
            M_ModernSwitch("Filter by Platform", &t.FilterTeam, accent);
            M_ModernSwitch("Filter by Skin", &t.FilterEnemy, accent);
            M_ModernSwitch("Filter by Level Range", &t.FilterEnemy, accent);
            M_ModernSwitch("Filter by Distance Range", &t.FilterDistance, accent);
            M_GradientSlider("Min Health Filter", &glowIntensity, 0.0f, 100.0f, "%.0f%%", accent);
            M_GradientSlider("Max Distance Filter", &c.ESPMaxDistance, 50.0f, 2000.0f, "%.0f m", accent);
            M_GradientSlider("Min Level Filter", &chamBrightness, 0.0f, 100.0f, "%.0f", accent);
            M_GradientSlider("Max Level Filter", &glowIntensity, 0.0f, 100.0f, "%.0f", accent);
        }

        M_SectionDivider("Priority", accent);
        M_DropdownSelect("Filter Priority", &effectPriorityIdx, priorityOpts, 4, accent);

        M_SectionDivider("Status", accent);
        M_InfoRow("Enemy Visibility", t.FilterEnemy ? "Shown" : "Hidden", t.FilterEnemy ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "E");
        M_InfoRow("Team Visibility", t.FilterTeam ? "Shown" : "Hidden", t.FilterTeam ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "T");
        M_InfoRow("Self Visibility", t.FilterSelf ? "Shown" : "Hidden", t.FilterSelf ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "S");
        M_InfoRow("Visible Check", t.FilterVisible ? "On" : "Off", t.FilterVisible ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "V");
        M_InfoRow("Distance Filter", t.FilterDistance ? "On" : "Off", t.FilterDistance ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "D");
        M_InfoRow("Filter Mode", filterOpts[filterModeIdx], accent, "M");
        M_InfoRow("Priority", priorityOpts[effectPriorityIdx], accent, "P");
        M_InfoRow("Max Distance", "", accent, "R");
        snprintf(valBuf, sizeof(valBuf), "%.0f m", c.ESPMaxDistance);
        M_InfoRow("", valBuf, accent, NULL);

        M_BooleanIndicator("Enemy Filter", t.FilterEnemy, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Team Filter", t.FilterTeam, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Self Filter", t.FilterSelf, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Visible Filter", t.FilterVisible, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Distance Filter", t.FilterDistance, accent, ImColor(60, 60, 70));

        dl->AddRectFilled(
            ImVec2(rightX + 8, ImGui::GetCursorScreenPos().y),
            ImVec2(rightX + cardW - 8, ImGui::GetCursorScreenPos().y + 2),
            C(ImColor(255, 255, 255, 10)), 1.0f);
        ImGui::Dummy(ImVec2(0, 4));

        int filterActive = (t.FilterEnemy ? 1 : 0) + (t.FilterTeam ? 1 : 0) + (t.FilterSelf ? 1 : 0);
        snprintf(valBuf, sizeof(valBuf), "%d/3", filterActive);
        M_StatCard("Active Filters", valBuf, NULL, false, accent);

        M_ActionButton("F", "Reset Filters", ImVec2(cardW - 20, 36), accent, NULL);
        M_IconButton("V", "Toggle Visibility", ImVec2(36, 36), accent, t.FilterVisible, 0);
        M_RadioSelector("Show All", filterModeIdx == 0, accent);
        M_RadioSelector("Enemy Only", filterModeIdx == 1, accent);
        M_RadioSelector("Team Only", filterModeIdx == 2, accent);
        M_InfoRow("Mode Preview", filterOpts[filterModeIdx], accent, "*");
        M_InfoRow("Culling Mode", t.FilterVisible ? "Active" : "Inactive", t.FilterVisible ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "C");
        M_InfoRow("Range Check", t.FilterDistance ? "Active" : "Inactive", t.FilterDistance ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "R");
    }
    M_CardEnd();
    ImGui::EndChild();
    float yR3 = ImGui::GetCursorScreenPos().y;

    yPos = (yL3 > yR3 ? yL3 : yR3) + 4.0f;

    ImGui::SetCursorScreenPos(ImVec2(leftX, yPos));
    ImGui::BeginChild("##esp_effects_card", ImVec2(fullW, 0.0f), false, ImGuiWindowFlags_NoScrollWithinParentChild);
    if (M_CardBegin("Effects", &effectsCol, accent))
    {
        M_CyberHeader("EFFECTS", accent2, NULL);

        M_SectionDivider("Chams Configuration", accent);
        M_ModernSwitch("Chams", &t.Chams, accent);
        M_GradientSlider("Cham Brightness", &chamBrightness, 0.0f, 1.0f, "%.2f", accent);
        M_ClassicToggle("Classic Chams", &t.Chams, accent);
        M_Switch3D("3D Chams", &t.Chams, accent);

        M_SectionDivider("Glow Configuration", accent);
        M_ModernSwitch("Glow", &t.Glow, accent);
        M_GradientSlider("Glow Intensity", &glowIntensity, 0.0f, 1.0f, "%.2f", accent);

        M_SectionDivider("Exploit Overrides", accent);
        M_ModernSwitch("Wallhack (Chams)", &t.Wallhack, accent);
        M_ModernSwitch("No Fog", &t.NoFog, accent);
        M_FancyCheckbox("Fancy Wallhack", &t.Wallhack, accent);

        M_ExpandableSection("Advanced Effects", &showAdvEffects, accent);
        if (showAdvEffects)
        {
            M_ModernSwitch("Show Through Walls", &t.Wallhack, accent);
            M_ModernSwitch("Wireframe Mode", &t.Chams, accent);
            M_ModernSwitch("Flat Shading", &t.Chams, accent);
            M_ModernSwitch("Ignore Teams", &t.FilterTeam, accent);
            M_ModernSwitch("Always Visible", &t.FilterVisible, accent);
            M_ModernSwitch("XRay Vision", &t.Wallhack, accent);
            M_ModernSwitch("Thermal Vision", &t.Chams, accent);
            M_ModernSwitch("Night Vision", &t.Glow, accent);
            M_ModernSwitch("Outline Mode", &t.Chams, accent);
            M_ModernSwitch("Glow Through Walls", &t.Glow, accent);
            M_ModernSwitch("Edge Glow", &t.Glow, accent);
            M_ModernSwitch("Pulse Effect", &t.Glow, accent);
            M_GradientSlider("Cham Opacity", &chamBrightness, 0.0f, 1.0f, "%.2f", accent);
            M_ColorSlider("Cham Color", &boxColorHue, ImColor(0, 180, 255), ImColor(255, 100, 100), accent);
            M_ColorSlider("Glow Color", &snaplineHue, ImColor(0, 255, 200), ImColor(255, 50, 50), accent);
            M_GradientSlider("Glow Radius", &glowIntensity, 0.0f, 2.0f, "%.1f", accent);
            M_GradientSlider("Wallhack Opacity", &chamBrightness, 0.0f, 1.0f, "%.2f", accent);
            M_GradientSlider("Glow Speed", &glowIntensity, 0.0f, 5.0f, "%.1f", accent);
            M_ColorSlider("Wallhack Color", &boxColorHue, ImColor(0, 255, 100), ImColor(255, 50, 0), accent);
            M_KnobDial("Effect Intensity", &glowIntensity, 0.0f, 1.0f, "%.2f", accent);
        }

        M_SectionDivider("Effect Status", accent);
        M_InfoRow("Chams", t.Chams ? "Enabled" : "Disabled", t.Chams ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "C");
        M_InfoRow("Glow", t.Glow ? "Enabled" : "Disabled", t.Glow ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "G");
        M_InfoRow("Wallhack", t.Wallhack ? "Enabled" : "Disabled", t.Wallhack ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "W");
        M_InfoRow("No Fog", t.NoFog ? "Enabled" : "Disabled", t.NoFog ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "F");
        M_InfoRow("Cham Brightness", "", accent, "B");
        snprintf(valBuf, sizeof(valBuf), "%.0f%%", chamBrightness * 100.0f);
        M_InfoRow("", valBuf, accent, NULL);
        M_InfoRow("Glow Intensity", "", accent, "I");
        snprintf(valBuf, sizeof(valBuf), "%.0f%%", glowIntensity * 100.0f);
        M_InfoRow("", valBuf, accent, NULL);
        M_InfoRow("Max Render Distance", "", accent, "D");
        snprintf(valBuf, sizeof(valBuf), "%.0f m", c.ESPMaxRender);
        M_InfoRow("", valBuf, accent, NULL);

        M_BooleanIndicator("Chams Active", t.Chams, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Glow Active", t.Glow, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("Wallhack Active", t.Wallhack, accent, ImColor(60, 60, 70));
        M_BooleanIndicator("No Fog Active", t.NoFog, accent, ImColor(60, 60, 70));

        dl->AddRectFilled(
            ImVec2(leftX + 8, ImGui::GetCursorScreenPos().y),
            ImVec2(leftX + fullW - 8, ImGui::GetCursorScreenPos().y + 2),
            C(ImColor(255, 255, 255, 10)), 1.0f);
        ImGui::Dummy(ImVec2(0, 4));

        int effectsOn = (t.Chams ? 1 : 0) + (t.Glow ? 1 : 0) + (t.Wallhack ? 1 : 0) + (t.NoFog ? 1 : 0);
        snprintf(valBuf, sizeof(valBuf), "%d/4 Effects Active", effectsOn);
        M_InfoRow("Summary", valBuf, effectsOn > 0 ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "!");

        M_Badge("FX", accent, ImVec2(leftX + 8, ImGui::GetCursorScreenPos().y));
        ImGui::Dummy(ImVec2(0, 4));

        M_StatCard("Chams", t.Chams ? "ON" : "OFF", NULL, t.Chams, accent);
        M_StatCard("Glow", t.Glow ? "ON" : "OFF", NULL, t.Glow, accent);
        M_StatCard("Wallhack", t.Wallhack ? "ON" : "OFF", NULL, t.Wallhack, accent);
        M_StatCard("No Fog", t.NoFog ? "ON" : "OFF", NULL, t.NoFog, accent);

        M_InfoRow("All Effects", effectsOn == 4 ? "All Active" : "Partial", effectsOn == 4 ? ImColor(0, 220, 100) : ImColor(200, 180, 0), "*");

        M_GradientButton("Reset All Effects", ImVec2(fullW - 20, 40), accent, accent2, 4.0f);
        M_GradientButton("Enable All", ImVec2(fullW - 20, 40), ImColor(0, 200, 100), ImColor(0, 100, 50), 4.0f);
        M_GradientButton("Disable All", ImVec2(fullW - 20, 40), ImColor(200, 50, 50), ImColor(100, 0, 0), 4.0f);

        M_SectionDivider("Quick Actions", accent);
        M_MenuButton("Effects Menu", showAdvEffects, accent);
        M_SplitButton("Apply Preset", ImVec2(fullW - 20, 40), accent);

        M_ButtonGroup("Effect Group", &barStyleIdx, barStyleOpts, 3, accent);
        M_CyberButton("Reset to Defaults", ImVec2(fullW - 20, 40), accent);
        M_InfoRow("Precision", "", accent, "P");
        snprintf(valBuf, sizeof(valBuf), "%.3f ms", chamBrightness * glowIntensity);
        M_InfoRow("", valBuf, accent, NULL);
        M_InfoRow("Effect Render State", effectsOn > 0 ? "Rendering" : "Idle", effectsOn > 0 ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "S");
        M_InfoRow("Performance Mode", "", accent, "P");
        snprintf(valBuf, sizeof(valBuf), "%s", effectsOn > 2 ? "High" : (effectsOn > 0 ? "Medium" : "Low"));
        M_InfoRow("", valBuf, accent, NULL);
    }
    M_CardEnd();
    ImGui::EndChild();
    float yLast = ImGui::GetCursorScreenPos().y;

    yPos = yLast + 4.0f;

    ImGui::SetCursorScreenPos(ImVec2(leftX, yPos));
    ImGui::BeginChild("##esp_global_card", ImVec2(fullW, 0.0f), false, ImGuiWindowFlags_NoScrollWithinParentChild);
    ImGui::Dummy(ImVec2(0, 4));
    M_CyberHeader("GLOBAL ESP OVERVIEW", accent2, NULL);
    ImGui::Dummy(ImVec2(0, 4));
    M_SectionDivider("Active Systems", accent);
    snprintf(valBuf, sizeof(valBuf), "Player ESP: %s", t.PlayerESP ? "ON" : "OFF");
    M_InfoRow("Player ESP", t.PlayerESP ? "Active" : "Disabled", t.PlayerESP ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "P");
    snprintf(valBuf2, sizeof(valBuf2), "Item ESP: %s", t.ItemESP ? "ON" : "OFF");
    M_InfoRow("Item ESP", t.ItemESP ? "Active" : "Disabled", t.ItemESP ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "I");
    snprintf(valBuf2, sizeof(valBuf2), "Chams: %s", t.Chams ? "ON" : "OFF");
    M_InfoRow("Chams", t.Chams ? "Active" : "Disabled", t.Chams ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "C");
    snprintf(valBuf2, sizeof(valBuf2), "Glow: %s", t.Glow ? "ON" : "OFF");
    M_InfoRow("Glow", t.Glow ? "Active" : "Disabled", t.Glow ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "G");
    snprintf(valBuf2, sizeof(valBuf2), "Wallhack: %s", t.Wallhack ? "ON" : "OFF");
    M_InfoRow("Wallhack", t.Wallhack ? "Active" : "Disabled", t.Wallhack ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "W");
    snprintf(valBuf2, sizeof(valBuf2), "No Fog: %s", t.NoFog ? "ON" : "OFF");
    M_InfoRow("No Fog", t.NoFog ? "Active" : "Disabled", t.NoFog ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "F");

    M_SectionDivider("Render Configuration", accent);
    M_InfoRow("Box Thickness", "", accent, "B");
    snprintf(valBuf, sizeof(valBuf), "%.1f px", c.BoxWidth);
    M_InfoRow("", valBuf, accent, NULL);
    M_InfoRow("Line Width", "", accent, "L");
    snprintf(valBuf, sizeof(valBuf), "%.1f px", c.LineWidth);
    M_InfoRow("", valBuf, accent, NULL);
    M_InfoRow("Text Size", "", accent, "T");
    snprintf(valBuf, sizeof(valBuf), "%.0f pt", c.TextSize);
    M_InfoRow("", valBuf, accent, NULL);
    M_InfoRow("Health Bar Width", "", accent, "H");
    snprintf(valBuf, sizeof(valBuf), "%d px", (int)c.HealthBarWidth);
    M_InfoRow("", valBuf, accent, NULL);
    M_InfoRow("Max ESP Distance", "", accent, "D");
    snprintf(valBuf, sizeof(valBuf), "%.0f m", c.ESPMaxDistance);
    M_InfoRow("", valBuf, accent, NULL);
    M_InfoRow("Max Render Distance", "", accent, "R");
    snprintf(valBuf, sizeof(valBuf), "%.0f m", c.ESPMaxRender);
    M_InfoRow("", valBuf, accent, NULL);

    M_SectionDivider("Filter Configuration", accent);
    M_InfoRow("Show Enemies", t.FilterEnemy ? "Yes" : "No", t.FilterEnemy ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "E");
    M_InfoRow("Show Teammates", t.FilterTeam ? "Yes" : "No", t.FilterTeam ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "T");
    M_InfoRow("Show Self", t.FilterSelf ? "Yes" : "No", t.FilterSelf ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "S");
    M_InfoRow("Visible Only", t.FilterVisible ? "Yes" : "No", t.FilterVisible ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "V");
    M_InfoRow("Distance Filter", t.FilterDistance ? "Yes" : "No", t.FilterDistance ? ImColor(0, 220, 100) : ImColor(200, 80, 80), "D");

    M_SectionDivider("Global Controls", accent);
    M_ActionButton("E", "Toggle All ESP", ImVec2(fullW - 20, 40), accent, NULL);
    if (M_GradientButton("Save ESP Config", ImVec2(fullW - 20, 40), accent, accent2, 4.0f))
    {
    }
    if (M_GradientButton("Load ESP Config", ImVec2(fullW - 20, 40), accent2, accent, 4.0f))
    {
    }
    M_Badge("CFG", accent, ImVec2(leftX + 8, ImGui::GetCursorScreenPos().y));
    ImGui::Dummy(ImVec2(0, 4));
    M_SectionDivider("Summary Statistics", accent);
    int totalActive = (t.PlayerESP ? 1 : 0) + (t.Box ? 1 : 0) + (t.CornerBox ? 1 : 0) + (t.BoxFilled ? 1 : 0) +
                      (t.Snaplines ? 1 : 0) + (t.LineFromBottom ? 1 : 0) + (t.Name ? 1 : 0) +
                      (t.Distance ? 1 : 0) + (t.Health ? 1 : 0) + (t.HealthBar ? 1 : 0) +
                      (t.Weapon ? 1 : 0) + (t.Armor ? 1 : 0) + (t.Shield ? 1 : 0) + (t.Faction ? 1 : 0) +
                      (t.Skeleton ? 1 : 0) + (t.AimLine ? 1 : 0) + (t.ItemESP ? 1 : 0) +
                      (t.VehicleESP ? 1 : 0) + (t.SupplyESP ? 1 : 0) + (t.TrapESP ? 1 : 0) +
                      (t.CollectibleESP ? 1 : 0) + (t.NpcESP ? 1 : 0) + (t.Chams ? 1 : 0) +
                      (t.Glow ? 1 : 0) + (t.Wallhack ? 1 : 0) + (t.NoFog ? 1 : 0);
    int totalPossible = 26;
    snprintf(valBuf, sizeof(valBuf), "%d/%d", totalActive, totalPossible);
    M_StatCard("Toggles Active", valBuf, NULL, totalActive > totalPossible / 2, accent);
    snprintf(valBuf, sizeof(valBuf), "%.1f%%", (float)totalActive / (float)totalPossible * 100.0f);
    M_StatCard("ESP Utilization", valBuf, NULL, totalActive > totalPossible / 2, accent);
    M_InfoRow("Total Active Toggles", "", accent, "#");
    snprintf(valBuf, sizeof(valBuf), "%d of %d", totalActive, totalPossible);
    M_InfoRow("", valBuf, accent, NULL);
    M_InfoRow("Box Config", "", accent, "B");
    snprintf(valBuf, sizeof(valBuf), "%.1fpx %s", c.BoxWidth, t.Box ? "On" : "Off");
    M_InfoRow("", valBuf, accent, NULL);
    M_InfoRow("Snapline Config", "", accent, "L");
    snprintf(valBuf, sizeof(valBuf), "%.1fpx %s", c.LineWidth, t.Snaplines ? "On" : "Off");
    M_InfoRow("", valBuf, accent, NULL);
    M_InfoRow("Text Config", "", accent, "T");
    snprintf(valBuf, sizeof(valBuf), "%.0fpt %s", c.TextSize, t.Name ? "Show" : "Hide");
    M_InfoRow("", valBuf, accent, NULL);
    M_InfoRow("Health Config", "", accent, "H");
    snprintf(valBuf, sizeof(valBuf), "%dpx %s", (int)c.HealthBarWidth, t.HealthBar ? "On" : "Off");
    M_InfoRow("", valBuf, accent, NULL);
    M_InfoRow("ESP Version", "1.0.0", accent, "V");
    M_InfoRow("Render Mode", "Custom Widgets", accent, "M");
    ImGui::Dummy(ImVec2(0, 8));
    ImGui::EndChild();
    float yGlobal = ImGui::GetCursorScreenPos().y;

    float finalY = yGlobal + 8.0f;
    ImGui::SetCursorScreenPos(ImVec2(contentPos.x, finalY));
}
