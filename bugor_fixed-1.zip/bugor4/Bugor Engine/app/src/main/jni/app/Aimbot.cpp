#include "Aimbot.h"
#include <cmath>

static const float M_PI_F = 3.14159265358979323846f;

Aimbot::Aimbot(MemoryIO* mem, GameOffsets* offsets, Config* cfg, Toggles* tog) {
    Mem = mem;
    Offsets = offsets;
    Cfg = cfg;
    Tog = tog;
    IsLocked.store(false);
    LocalPlayerIndex.store(-1);
    CurrentPitch = 0.0f;
    CurrentYaw = 0.0f;
    LastPitch = 0.0f;
    LastYaw = 0.0f;
    CameraPos = D3DVector();
    memset(&BestTarget, 0, sizeof(AimbotTarget));
    BestTarget.Index = -1;
}

void Aimbot::Update() {
    if (!Offsets->Initialized || !Tog->Aimbot) {
        ReleaseTarget();
        return;
    }
    UpdateCameraAngles();
    Offsets->UpdateEntityList();
    FindTarget();
    if (BestTarget.Index >= 0) AimAtTarget();
    if (Tog->AimbotAutoFire) AutoFire();
    if (Tog->TriggerbotEnabled) Triggerbot();
}

void Aimbot::FindTarget() {
    int bestIndex = -1;
    float bestFOV = Cfg->AimbotRange;
    float cx = abs_ScreenX / 2.0f;
    float cy = abs_ScreenY / 2.0f;
    for (int i = 0; i < Offsets->EntityCount; i++) {
        PlayerData p;
        if (!Offsets->ReadEntityData(i, &p)) continue;
        if (p.PlayerID == LocalPlayerIndex.load()) continue;
        if (Tog->FilterEnemy && p.TeamID == 0) continue;
        if (!p.IsAlive) continue;
        if (Tog->AimbotVisibleCheck && !p.IsVisible) continue;
        float dist = Vec3Distance(CameraPos, p.Position);
        if (dist > Cfg->AimbotMaxDistance) continue;
        float sx, sy;
        if (!WorldToScreen2(Offsets->ViewMatrix, p.Position, &sx, &sy)) continue;
        float fov = sqrtf(powf(sx - cx, 2.0f) + powf(sy - cy, 2.0f));
        if (fov < bestFOV) {
            bestFOV = fov;
            bestIndex = i;
        }
    }
    if (bestIndex >= 0) {
        PlayerData p;
        Offsets->ReadEntityData(bestIndex, &p);
        BestTarget.Index = bestIndex;
        BestTarget.Distance = Vec3Distance(CameraPos, p.Position);
        BestTarget.Position = p.Position;
        BestTarget.Head = p.Head;
        BestTarget.Health = p.Health;
        BestTarget.IsVisible = p.IsVisible;
        BestTarget.TeamID = p.TeamID;
        BestTarget.Address = p.Address;
        BestTarget.BoneAddress = p.BoneAddress;
        BestTarget.FOV = bestFOV;
        IsLocked.store(true);
    } else {
        ReleaseTarget();
    }
}

void Aimbot::AimAtTarget() {
    if (!IsLocked.load() || BestTarget.Index < 0) return;
    float pitch, yaw;
    D3DVector aimPos = BestTarget.Position;
    if (Cfg->SelectedAimbotBone == 0) aimPos = BestTarget.Head;
    if (Tog->AimbotPrediction) {
        D3DVector vel = {0, 0, 0};
        if (BestTarget.Address && Offsets->OffsetVelocity) {
            vel.X = Mem->ReadFloat(BestTarget.Address + Offsets->OffsetVelocity);
            vel.Y = Mem->ReadFloat(BestTarget.Address + Offsets->OffsetVelocity + 4);
            vel.Z = Mem->ReadFloat(BestTarget.Address + Offsets->OffsetVelocity + 8);
        } else {
            vel = {10.0f, 10.0f, 10.0f};
        }
        PredictTarget(aimPos, vel, Cfg->AimbotPredictionValue);
    }
    D3DVector delta;
    delta.X = aimPos.X - CameraPos.X;
    delta.Y = aimPos.Y - CameraPos.Y;
    delta.Z = aimPos.Z - CameraPos.Z;
    float dist = Vec3Length(delta);
    if (dist < 0.01f) return;
    pitch = -atan2f(delta.Y, sqrtf(delta.X * delta.X + delta.Z * delta.Z)) * 180.0f / M_PI_F;
    yaw = atan2f(delta.X, delta.Z) * 180.0f / M_PI_F;
    NormalizeAngles(pitch, yaw);
    if (Tog->AimbotSmooth && Cfg->AimbotSmoothValue > 0.01f) {
        SmoothAim(pitch, yaw, Cfg->AimbotSmoothValue);
    }
    SetCameraAngles(pitch, yaw);
}

void Aimbot::ReleaseTarget() {
    IsLocked.store(false);
    memset(&BestTarget, 0, sizeof(AimbotTarget));
    BestTarget.Index = -1;
}

void Aimbot::PredictTarget(D3DVector& pos, D3DVector vel, float time) {
    pos.X += vel.X * time;
    pos.Y += vel.Y * time;
    pos.Z += vel.Z * time;
}

void Aimbot::SmoothAim(float& pitch, float& yaw, float smoothFactor) {
    float diffPitch = pitch - CurrentPitch;
    float diffYaw = yaw - CurrentYaw;
    NormalizeAngles(diffPitch, diffYaw);
    diffPitch /= smoothFactor;
    diffYaw /= smoothFactor;
    float maxDelta = Cfg->AimbotMaxDelta;
    diffPitch = fmaxf(-maxDelta, fminf(maxDelta, diffPitch));
    diffYaw = fmaxf(-maxDelta, fminf(maxDelta, diffYaw));
    pitch = CurrentPitch + diffPitch;
    yaw = CurrentYaw + diffYaw;
    NormalizeAngles(pitch, yaw);
}

void Aimbot::SetCameraAngles(float pitch, float yaw) {
    float clampedPitch = fmaxf(-89.0f, fminf(89.0f, pitch));
    uintptr_t mlPtr = Mem->ReadPtr64(Offsets->LocalPlayer + Offsets->OffsetCameraManager);
    if (mlPtr) {
        Mem->WriteFloat(mlPtr + 0x60, yaw);
        Mem->WriteFloat(mlPtr + 0x64, clampedPitch);
    }
    CurrentPitch = pitch;
    CurrentYaw = yaw;
}

void Aimbot::Triggerbot() {
    if (IsLocked.load() && BestTarget.Index >= 0) {
        float sx, sy;
        if (WorldToScreen2(Offsets->ViewMatrix, BestTarget.Head, &sx, &sy)) {
            float dist = sqrtf(powf(sx - abs_ScreenX / 2.0f, 2.0f) + powf(sy - abs_ScreenY / 2.0f, 2.0f));
            if (dist < 20.0f) {
                if (Offsets->ForceAttackAddr) {
                    Mem->WriteInt(Offsets->ForceAttackAddr, 1);
                }
            }
        }
    }
}

bool Aimbot::WorldToScreen2(float* matrix, D3DVector world, float* sx, float* sy) {
    return ::WorldToScreen(world, sx, sy, matrix, (float)abs_ScreenX, (float)abs_ScreenY);
}

bool Aimbot::IsValidTarget(AimbotTarget& t) {
    if (t.Index < 0) return false;
    if (t.Health <= 0.0f) return false;
    if (t.Distance > Cfg->AimbotMaxDistance) return false;
    if (Tog->AimbotVisibleCheck && !t.IsVisible) return false;
    return true;
}

void Aimbot::AutoFire() {
    if (!Offsets->Initialized || !IsLocked.load() || BestTarget.Index < 0) return;
    if (Offsets->ForceAttackAddr) {
        Mem->WriteInt(Offsets->ForceAttackAddr, 1);
    }
}

void Aimbot::UpdateCameraAngles() {
    uintptr_t mlPtr = Mem->ReadPtr64(Offsets->LocalPlayer + Offsets->OffsetCameraManager);
    if (mlPtr) {
        LastPitch = CurrentPitch;
        LastYaw = CurrentYaw;
        CurrentPitch = Mem->ReadFloat(mlPtr + 0x64);
        CurrentYaw = Mem->ReadFloat(mlPtr + 0x60);
    }
    CameraPos = Offsets->CameraPos;
}

void Aimbot::NormalizeAngles(float& pitch, float& yaw) {
    if (pitch > 89.0f) pitch = 89.0f;
    if (pitch < -89.0f) pitch = -89.0f;
    if (yaw > 180.0f) yaw -= 360.0f;
    if (yaw < -180.0f) yaw += 360.0f;
}

float Aimbot::GetAngularFOV(float pitch, float yaw, AimbotTarget& t) {
    float dp = pitch - CurrentPitch;
    float dy = yaw - CurrentYaw;
    NormalizeAngles(dp, dy);
    return sqrtf(dp * dp + dy * dy);
}
