#include "AntiCheatSystem.h"
#include <unistd.h>
#include <fcntl.h>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <signal.h>
#include <dlfcn.h>
#include <thread>
#include <atomic>
#include <chrono>
#include <sys/stat.h>

namespace AntiCheatSystem {

static std::thread g_monitorThread;
static std::atomic<bool> g_monitorRunning(false);

bool DetectOtherCheats() {
    const char* signatures[] = {
        "gameguardian", "il2cppdumper", "frida-agent",
        "libsubstrate", "libxposed", "frida",
        "cheatengine", nullptr
    };
    FILE* fp = fopen("/proc/self/maps", "r");
    if (!fp) return false;
    char line[1024];
    while (fgets(line, sizeof(line), fp)) {
        for (int i = 0; signatures[i]; i++) {
            if (strstr(line, signatures[i])) {
                fclose(fp);
                return true;
            }
        }
    }
    fclose(fp);
    return false;
}

bool DetectHooks() {
    void* openPtr = dlsym(RTLD_DEFAULT, "open");
    void* readPtr = dlsym(RTLD_DEFAULT, "read");
    void* mmapPtr = dlsym(RTLD_DEFAULT, "mmap");

    void* funcs[] = {openPtr, readPtr, mmapPtr};

    int memFd = open("/proc/self/mem", O_RDONLY);
    if (memFd < 0) return false;

    for (int i = 0; i < 3; i++) {
        if (!funcs[i]) continue;
        uint32_t bytes;
        if (pread(memFd, &bytes, 4, (off_t)funcs[i]) == 4) {
            if (bytes == 0x58000050) { close(memFd); return true; }
            if ((bytes & 0xFC000000) == 0x14000000) { close(memFd); return true; }
            if (bytes == 0xE51FF004) { close(memFd); return true; }
            if ((bytes & 0xFF) == 0xE9) { close(memFd); return true; }
        }
    }

    close(memFd);
    return false;
}

bool IsEmulator() {
    FILE* fp = fopen("/proc/cpuinfo", "r");
    if (fp) {
        char line[256];
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, "goldfish") || strstr(line, "ranchu")) {
                fclose(fp);
                return true;
            }
        }
        fclose(fp);
    }

    fp = fopen("/system/build.prop", "r");
    if (fp) {
        char line[512];
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, "ro.kernel.qemu") && strstr(line, "=1")) {
                fclose(fp);
                return true;
            }
            if (strstr(line, "ro.product.board") &&
                (strstr(line, "goldfish") || strstr(line, "ranchu"))) {
                fclose(fp);
                return true;
            }
        }
        fclose(fp);
    }

    struct stat st;
    if (stat("/dev/qemu_pipe", &st) == 0) return true;
    if (stat("/dev/qemu_trace", &st) == 0) return true;

    fp = popen("getprop ro.build.fingerprint 2>/dev/null", "r");
    if (fp) {
        char buf[256];
        if (fgets(buf, sizeof(buf), fp)) {
            if (strstr(buf, "generic") || strstr(buf, "sdk")) {
                pclose(fp);
                return true;
            }
        }
        pclose(fp);
    }

    return false;
}

void StartMonitoring() {
    if (g_monitorRunning.load()) return;
    g_monitorRunning.store(true);
    g_monitorThread = std::thread([]() {
        while (g_monitorRunning.load()) {
            if (DetectOtherCheats() || DetectHooks() || IsEmulator()) {
                raise(SIGKILL);
                _exit(1);
            }
            std::this_thread::sleep_for(std::chrono::seconds(5));
        }
    });
}

void StopMonitoring() {
    g_monitorRunning.store(false);
    if (g_monitorThread.joinable()) {
        g_monitorThread.join();
    }
}

}
