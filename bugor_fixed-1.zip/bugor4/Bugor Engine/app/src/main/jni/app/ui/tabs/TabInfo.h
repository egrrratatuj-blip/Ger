#pragma once
#include "imgui/imgui.h"

void DrawTabInfo(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize);
void InitTabInfo();
void ShutdownTabInfo();
