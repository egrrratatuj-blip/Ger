#pragma once
#include "../../../../imgui/imgui.h"

void M_ProgressRing(ImDrawList* dl, const char* label, float value, float maxValue, ImVec2 center, float radius, ImColor accent = ImColor(0, 180, 255), float thickness = 8.0f);
void M_SparkLine(ImDrawList* dl, const char* label, float* data, int dataCount, ImVec2 pos, float width, float height, ImColor lineColor = ImColor(0, 180, 255), ImColor fillColor = ImColor(0, 180, 255, 60));
void M_MiniBarGraph(ImDrawList* dl, const char* label, float* data, int dataCount, ImVec2 pos, float width, float height, ImColor* colors = nullptr);
void M_BadgeCounter(ImDrawList* dl, ImVec2 pos, int count, ImColor color = ImColor(255, 80, 80));
int M_RadialMenu(const char* label, ImVec2 center, float radius, const char** items, int count, int selected, ImColor accent = ImColor(0, 180, 255), float startAngle = 0.0f);
void M_MatrixDisplay(ImDrawList* dl, const char* label, float* matrix, int rows, int cols, ImVec2 pos, float cellWidth, float cellHeight);
void M_HeatmapGrid(ImDrawList* dl, const char* label, float* data, int rows, int cols, ImVec2 pos, float cellW, float cellH, float minVal = 0.0f, float maxVal = 1.0f);
void M_GaugeBar(ImDrawList* dl, const char* label, float value, float maxValue, ImVec2 pos, float width, float height, ImColor accent = ImColor(0, 180, 255), bool showLabel = true);
