#pragma once
#include <imgui.h>

void DrawTabTheme(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize);
void InitTabTheme();
void ShutdownTabTheme();
