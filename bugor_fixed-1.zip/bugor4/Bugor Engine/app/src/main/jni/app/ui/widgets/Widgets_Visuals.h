#pragma once
#include "../../../../imgui/imgui.h"

void M_DrawVisualBackground(ImDrawList* dl, ImVec2 pos, ImVec2 size, ImColor accent = ImColor(0, 180, 255));
void M_DrawGlowEffect(ImDrawList* dl, ImVec2 pos, ImVec2 size, float intensity = 1.0f, ImColor color = ImColor(0, 180, 255));
void M_DrawScanline(ImDrawList* dl, ImVec2 pos, ImVec2 size, float time = 0.0f);
void M_DrawGridOverlay(ImDrawList* dl, ImVec2 pos, ImVec2 size, float alpha = 0.1f);
void M_DrawVignette(ImDrawList* dl, ImVec2 pos, ImVec2 size, float intensity = 0.5f);
