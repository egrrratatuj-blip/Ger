#include "ConfigSerializer.h"
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <cctype>
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>
#include <errno.h>

static const char* PROFILE_DIR = "/data/data/com.bugor.engine/files/configs/";

static uint32_t crc32_table[256];
static bool crc32_initialized = false;

static void InitCRC32() {
    if (crc32_initialized) return;
    for (uint32_t i = 0; i < 256; i++) {
        uint32_t crc = i;
        for (int j = 0; j < 8; j++) {
            if (crc & 1) crc = (crc >> 1) ^ 0xEDB88320;
            else crc >>= 1;
        }
        crc32_table[i] = crc;
    }
    crc32_initialized = true;
}

static uint32_t CalcCRC32(const void* data, size_t len) {
    InitCRC32();
    uint32_t crc = 0xFFFFFFFF;
    const uint8_t* bytes = (const uint8_t*)data;
    for (size_t i = 0; i < len; i++) {
        crc = crc32_table[(crc ^ bytes[i]) & 0xFF] ^ (crc >> 8);
    }
    return crc ^ 0xFFFFFFFF;
}

struct ToggleField {
    const char* name;
    bool Toggles::*ptr;
};

struct ConfigFloatField {
    const char* name;
    float Config::*ptr;
};

struct ConfigIntField {
    const char* name;
    int Config::*ptr;
};

struct ConfigColorField {
    const char* name;
    ImColor Config::*ptr;
};

static const ToggleField g_ToggleFields[] = {
    {"Rendering", &Toggles::Rendering},
    {"Box", &Toggles::Box},
    {"BoxFilled", &Toggles::BoxFilled},
    {"CornerBox", &Toggles::CornerBox},
    {"Line", &Toggles::Line},
    {"LineFromBottom", &Toggles::LineFromBottom},
    {"Distance", &Toggles::Distance},
    {"Name", &Toggles::Name},
    {"Health", &Toggles::Health},
    {"HealthBar", &Toggles::HealthBar},
    {"Armor", &Toggles::Armor},
    {"Shield", &Toggles::Shield},
    {"Weapon", &Toggles::Weapon},
    {"Faction", &Toggles::Faction},
    {"Snaplines", &Toggles::Snaplines},
    {"Skeleton", &Toggles::Skeleton},
    {"AimLine", &Toggles::AimLine},
    {"Aimbot", &Toggles::Aimbot},
    {"AimbotCircle", &Toggles::AimbotCircle},
    {"AimbotAutoFire", &Toggles::AimbotAutoFire},
    {"AimbotVisibleCheck", &Toggles::AimbotVisibleCheck},
    {"AimbotPrediction", &Toggles::AimbotPrediction},
    {"AimbotSmooth", &Toggles::AimbotSmooth},
    {"AimbotTargetLine", &Toggles::AimbotTargetLine},
    {"AimbotDrawFOV", &Toggles::AimbotDrawFOV},
    {"AimbotDrawTarget", &Toggles::AimbotDrawTarget},
    {"AimbotOn", &Toggles::AimbotOn},
    {"ItemESP", &Toggles::ItemESP},
    {"VehicleESP", &Toggles::VehicleESP},
    {"SupplyESP", &Toggles::SupplyESP},
    {"TrapESP", &Toggles::TrapESP},
    {"CollectibleESP", &Toggles::CollectibleESP},
    {"NpcESP", &Toggles::NpcESP},
    {"PlayerESP", &Toggles::PlayerESP},
    {"Chams", &Toggles::Chams},
    {"Glow", &Toggles::Glow},
    {"NoFog", &Toggles::NoFog},
    {"NoRecoil", &Toggles::NoRecoil},
    {"NoSpread", &Toggles::NoSpread},
    {"Wallhack", &Toggles::Wallhack},
    {"SpeedHack", &Toggles::SpeedHack},
    {"FlyHack", &Toggles::FlyHack},
    {"Teleport", &Toggles::Teleport},
    {"GodMode", &Toggles::GodMode},
    {"UnlimitedAmmo", &Toggles::UnlimitedAmmo},
    {"NoClip", &Toggles::NoClip},
    {"FilterTeam", &Toggles::FilterTeam},
    {"FilterSelf", &Toggles::FilterSelf},
    {"FilterEnemy", &Toggles::FilterEnemy},
    {"FilterVisible", &Toggles::FilterVisible},
    {"FilterDistance", &Toggles::FilterDistance},
    {"ShowCrosshair", &Toggles::ShowCrosshair},
    {"ShowRadar", &Toggles::ShowRadar},
    {"ShowCompass", &Toggles::ShowCompass},
    {"ShowInfo", &Toggles::ShowInfo},
    {"ShowFPS", &Toggles::ShowFPS},
    {"ShowWatermark", &Toggles::ShowWatermark},
    {"SafeMode", &Toggles::SafeMode},
    {"StreamMode", &Toggles::StreamMode},
    {"AimbotAutoScope", &Toggles::AimbotAutoScope},
    {"AimbotAutoWallbang", &Toggles::AimbotAutoWallbang},
    {"TriggerbotEnabled", &Toggles::TriggerbotEnabled},
    {"TriggerbotFriendlyFire", &Toggles::TriggerbotFriendlyFire},
    {"RCSRandomization", &Toggles::RCSRandomization},
    {"IgnoreDowned", &Toggles::IgnoreDowned},
    {"TargetSwitchDelay", &Toggles::TargetSwitchDelay},
    {"RadarRotate", &Toggles::RadarRotate},
    {"RadarNames", &Toggles::RadarNames},
    {"RadarDistance", &Toggles::RadarDistance},
    {"RadarSnaplines", &Toggles::RadarSnaplines},
    {"RadarScan", &Toggles::RadarScan},
    {"LootWeapons", &Toggles::LootWeapons},
    {"LootAmmo", &Toggles::LootAmmo},
    {"LootConsumables", &Toggles::LootConsumables},
    {"LootAttachments", &Toggles::LootAttachments},
    {"LootArmor", &Toggles::LootArmor},
    {"LootThrowables", &Toggles::LootThrowables},
    {"LootSpecial", &Toggles::LootSpecial},
    {"RarityCommon", &Toggles::RarityCommon},
    {"RarityUncommon", &Toggles::RarityUncommon},
    {"RarityRare", &Toggles::RarityRare},
    {"RarityEpic", &Toggles::RarityEpic},
    {"RarityLegendary", &Toggles::RarityLegendary},
    {"ItemName", &Toggles::ItemName},
    {"ItemDistance", &Toggles::ItemDistance},
    {"ItemRarity", &Toggles::ItemRarity},
    {"ItemGlow", &Toggles::ItemGlow},
    {"ItemIcons", &Toggles::ItemIcons},
    {"RadarShowEnemy", &Toggles::RadarShowEnemy},
    {"RadarShowTeam", &Toggles::RadarShowTeam},
    {"LootESP", &Toggles::LootESP},
    {"LootSortAscending", &Toggles::LootSortAscending},
    {"LootSortBy", &Toggles::LootSortBy},
    {"AutoSprint", &Toggles::AutoSprint},
    {"BunnyHop", &Toggles::BunnyHop},
    {"NoFallDamage", &Toggles::NoFallDamage},
    {"InfiniteStamina", &Toggles::InfiniteStamina},
    {"NoBreath", &Toggles::NoBreath},
    {"Invisible", &Toggles::Invisible},
    {"InstantADS", &Toggles::InstantADS},
    {"RapidFire", &Toggles::RapidFire},
    {"ShowPlayerCount", &Toggles::ShowPlayerCount},
    {"ShowServerInfo", &Toggles::ShowServerInfo},
    {"Triggerbot", &Toggles::Triggerbot},
    {"AutoLoot", &Toggles::AutoLoot},
    {"AutoPickup", &Toggles::AutoPickup},
    {"AutoHeal", &Toggles::AutoHeal},
    {"NoSmoke", &Toggles::NoSmoke},
    {"NoFlash", &Toggles::NoFlash},
    {"NightMode", &Toggles::NightMode},
    {"DayTime", &Toggles::DayTime},
    {"AntiScreenshot", &Toggles::AntiScreenshot},
    {"StreamProof", &Toggles::StreamProof},
    {"Animations", &Toggles::Animations},
    {"Particles", &Toggles::Particles},
};
static const int g_ToggleCount = sizeof(g_ToggleFields) / sizeof(g_ToggleFields[0]);

static const ConfigFloatField g_ConfigFloatFields[] = {
    {"AimbotRange", &Config::AimbotRange},
    {"AimbotSmoothValue", &Config::AimbotSmoothValue},
    {"AimbotMaxDistance", &Config::AimbotMaxDistance},
    {"AimbotPredictionValue", &Config::AimbotPredictionValue},
    {"ESPMaxDistance", &Config::ESPMaxDistance},
    {"ESPMaxRender", &Config::ESPMaxRender},
    {"BoxWidth", &Config::BoxWidth},
    {"LineWidth", &Config::LineWidth},
    {"TextSize", &Config::TextSize},
    {"CrosshairSize", &Config::CrosshairSize},
    {"CrosshairThickness", &Config::CrosshairThickness},
    {"RadarRange", &Config::RadarRange},
    {"RadarScale", &Config::RadarScale},
    {"RadarOpacity", &Config::RadarOpacity},
    {"RadarDotSize", &Config::RadarDotSize},
    {"HealthBarWidth", &Config::HealthBarWidth},
    {"FOV", &Config::FOV},
    {"LootMaxDistance", &Config::LootMaxDistance},
    {"UIScale", &Config::UIScale},
    {"AimbotFOVHue", &Config::AimbotFOVHue},
    {"AimbotTargetLineWidth", &Config::AimbotTargetLineWidth},
    {"AimbotFireRate", &Config::AimbotFireRate},
    {"TriggerDelay", &Config::TriggerDelay},
    {"RCSVerticalValue", &Config::RCSVerticalValue},
    {"RCSHorizontalValue", &Config::RCSHorizontalValue},
    {"SwitchDelayValue", &Config::SwitchDelayValue},
    {"MaxTargetsValue", &Config::MaxTargetsValue},
    {"SpeedMultiplier", &Config::SpeedMultiplier},
    {"FlySpeed", &Config::FlySpeed},
    {"FireRateMult", &Config::FireRateMult},
    {"AutoHealHP", &Config::AutoHealHP},
    {"WorldBrightness", &Config::WorldBrightness},
};
static const int g_ConfigFloatCount = sizeof(g_ConfigFloatFields) / sizeof(g_ConfigFloatFields[0]);

static const ConfigIntField g_ConfigIntFields[] = {
    {"SelectedAimbotBone", &Config::SelectedAimbotBone},
    {"SelectedAimbotPriority", &Config::SelectedAimbotPriority},
    {"SelectedTarget", &Config::SelectedTarget},
    {"SelectedColorTheme", &Config::SelectedColorTheme},
    {"Theme", &Config::Theme},
    {"SelectedAimbotMode", &Config::SelectedAimbotMode},
    {"TriggerMode", &Config::TriggerMode},
    {"RCSMode", &Config::RCSMode},
    {"SelectedCrosshair", &Config::SelectedCrosshair},
    {"CrosshairStyle", &Config::CrosshairStyle},
    {"LootSortBy", &Config::LootSortBy},
    {"RadarShowEnemy", &Config::RadarShowEnemy},
    {"RadarShowTeam", &Config::RadarShowTeam},
};
static const int g_ConfigIntCount = sizeof(g_ConfigIntFields) / sizeof(g_ConfigIntFields[0]);

static const ConfigColorField g_ConfigColorFields[] = {
    {"ESPBoxColor", &Config::ESPBoxColor},
    {"ESPWallColor", &Config::ESPWallColor},
    {"ESPVisibleColor", &Config::ESPVisibleColor},
    {"ESPEnemyColor", &Config::ESPEnemyColor},
    {"ESPTeamColor", &Config::ESPTeamColor},
    {"ESPLineColor", &Config::ESPLineColor},
    {"ESPNameColor", &Config::ESPNameColor},
    {"ESPDistanceColor", &Config::ESPDistanceColor},
    {"AimbotFOVColor", &Config::AimbotFOVColor},
    {"AimbotTargetColor", &Config::AimbotTargetColor},
    {"AimLineColor", &Config::AimLineColor},
    {"CrosshairColor", &Config::CrosshairColor},
    {"CrosshairColorPick", &Config::CrosshairColorPick},
    {"WatermarkColor", &Config::WatermarkColor},
    {"BackgroundColor", &Config::BackgroundColor},
    {"AccentColor", &Config::AccentColor},
    {"AccentColor2", &Config::AccentColor2},
};
static const int g_ConfigColorCount = sizeof(g_ConfigColorFields) / sizeof(g_ConfigColorFields[0]);

static int TotalConfigEntries() {
    return g_ConfigFloatCount + g_ConfigIntCount + g_ConfigColorCount * 4;
}

bool ConfigSerializer::SaveBinary(const std::string& path, Toggles* tog, Config* cfg) {
    FILE* f = fopen(path.c_str(), "wb");
    if (!f) return false;

    uint32_t magic = MAGIC;
    uint32_t version = VERSION;
    uint32_t toggle_count = g_ToggleCount;
    uint32_t config_count = TotalConfigEntries();

    fwrite(&magic, sizeof(magic), 1, f);
    fwrite(&version, sizeof(version), 1, f);
    fwrite(&toggle_count, sizeof(toggle_count), 1, f);
    fwrite(&config_count, sizeof(config_count), 1, f);

    uint32_t data_start = ftell(f);

    for (int i = 0; i < g_ToggleCount; i++) {
        uint8_t name_len = (uint8_t)strlen(g_ToggleFields[i].name);
        uint8_t val = tog->*(g_ToggleFields[i].ptr) ? 1 : 0;
        fwrite(&name_len, 1, 1, f);
        fwrite(g_ToggleFields[i].name, 1, name_len, f);
        fwrite(&val, 1, 1, f);
    }

    for (int i = 0; i < g_ConfigFloatCount; i++) {
        uint8_t name_len = (uint8_t)strlen(g_ConfigFloatFields[i].name);
        uint8_t type = 0;
        float val = cfg->*(g_ConfigFloatFields[i].ptr);
        fwrite(&name_len, 1, 1, f);
        fwrite(g_ConfigFloatFields[i].name, 1, name_len, f);
        fwrite(&type, 1, 1, f);
        fwrite(&val, sizeof(val), 1, f);
    }

    for (int i = 0; i < g_ConfigIntCount; i++) {
        uint8_t name_len = (uint8_t)strlen(g_ConfigIntFields[i].name);
        uint8_t type = 1;
        int32_t val = cfg->*(g_ConfigIntFields[i].ptr);
        fwrite(&name_len, 1, 1, f);
        fwrite(g_ConfigIntFields[i].name, 1, name_len, f);
        fwrite(&type, 1, 1, f);
        fwrite(&val, sizeof(val), 1, f);
    }

    for (int i = 0; i < g_ConfigColorCount; i++) {
        ImColor col = cfg->*(g_ConfigColorFields[i].ptr);
        float vals[4] = {col.Value.x, col.Value.y, col.Value.z, col.Value.w};
        for (int c = 0; c < 4; c++) {
            uint8_t name_buf[64];
            int nlen = snprintf((char*)name_buf, sizeof(name_buf), "%s_%c", g_ConfigColorFields[i].name, "RGBA"[c]);
            uint8_t name_len = (uint8_t)nlen;
            uint8_t type = 0;
            fwrite(&name_len, 1, 1, f);
            fwrite(name_buf, 1, name_len, f);
            fwrite(&type, 1, 1, f);
            fwrite(&vals[c], sizeof(float), 1, f);
        }
    }

    uint32_t data_end = ftell(f);
    uint32_t data_size = data_end - data_start;

    fseek(f, data_start, SEEK_SET);
    uint8_t* data_buf = new uint8_t[data_size];
    fread(data_buf, 1, data_size, f);
    uint32_t crc = CalcCRC32(data_buf, data_size);
    delete[] data_buf;

    fseek(f, 0, SEEK_END);
    fwrite(&crc, sizeof(crc), 1, f);

    fclose(f);
    return true;
}

bool ConfigSerializer::LoadBinary(const std::string& path, Toggles* tog, Config* cfg) {
    FILE* f = fopen(path.c_str(), "rb");
    if (!f) return false;

    uint32_t magic, version, toggle_count, config_count;
    if (fread(&magic, sizeof(magic), 1, f) != 1 || magic != MAGIC) { fclose(f); return false; }
    if (fread(&version, sizeof(version), 1, f) != 1) { fclose(f); return false; }
    if (fread(&toggle_count, sizeof(toggle_count), 1, f) != 1) { fclose(f); return false; }
    if (fread(&config_count, sizeof(config_count), 1, f) != 1) { fclose(f); return false; }

    uint32_t data_start = ftell(f);

    fseek(f, 0, SEEK_END);
    uint32_t file_size = ftell(f);
    uint32_t data_size = file_size - data_start - 4;

    fseek(f, data_start, SEEK_SET);
    uint8_t* data_buf = new uint8_t[data_size];
    if (fread(data_buf, 1, data_size, f) != data_size) {
        delete[] data_buf; fclose(f); return false;
    }

    fread(&magic, sizeof(magic), 1, f); // read CRC (stored in magic var for reuse)
    uint32_t stored_crc = magic;
    uint32_t calc_crc = CalcCRC32(data_buf, data_size);
    if (stored_crc != calc_crc) {
        delete[] data_buf; fclose(f); return false;
    }

    fseek(f, data_start, SEEK_SET);

    uint32_t toggles_read = 0;
    uint32_t configs_read = 0;

    while (toggles_read < toggle_count && ftell(f) < (long)(data_start + data_size)) {
        uint8_t name_len;
        if (fread(&name_len, 1, 1, f) != 1) break;
        char name[256];
        if (fread(name, 1, name_len, f) != name_len) break;
        name[name_len] = 0;
        uint8_t val;
        if (fread(&val, 1, 1, f) != 1) break;

        for (int i = 0; i < g_ToggleCount; i++) {
            if (strcmp(name, g_ToggleFields[i].name) == 0) {
                tog->*(g_ToggleFields[i].ptr) = (val != 0);
                break;
            }
        }
        toggles_read++;
    }

    while (configs_read < config_count && ftell(f) < (long)(data_start + data_size)) {
        uint8_t name_len;
        if (fread(&name_len, 1, 1, f) != 1) break;
        char name[256];
        if (fread(name, 1, name_len, f) != name_len) break;
        name[name_len] = 0;
        uint8_t type;
        if (fread(&type, 1, 1, f) != 1) break;

        if (type == 0) {
            float val;
            if (fread(&val, sizeof(val), 1, f) != 1) break;

            bool matched = false;
            for (int i = 0; i < g_ConfigFloatCount; i++) {
                if (strcmp(name, g_ConfigFloatFields[i].name) == 0) {
                    cfg->*(g_ConfigFloatFields[i].ptr) = val;
                    matched = true; break;
                }
            }
            if (!matched) {
                for (int i = 0; i < g_ConfigColorCount; i++) {
                    const char* cn = g_ConfigColorFields[i].name;
                    size_t cn_len = strlen(cn);
                    if (strncmp(name, cn, cn_len) == 0 && name[cn_len] == '_' && name[cn_len+1] && name[cn_len+2] == 0) {
                        char component = name[cn_len + 1];
                        float* vals[4] = {
                            &(cfg->*(g_ConfigColorFields[i].ptr)).Value.x,
                            &(cfg->*(g_ConfigColorFields[i].ptr)).Value.y,
                            &(cfg->*(g_ConfigColorFields[i].ptr)).Value.z,
                            &(cfg->*(g_ConfigColorFields[i].ptr)).Value.w
                        };
                        int comp_idx = (component == 'R') ? 0 : (component == 'G') ? 1 : (component == 'B') ? 2 : 3;
                        *(vals[comp_idx]) = val;
                        break;
                    }
                }
            }
        } else if (type == 1) {
            int32_t val;
            if (fread(&val, sizeof(val), 1, f) != 1) break;
            for (int i = 0; i < g_ConfigIntCount; i++) {
                if (strcmp(name, g_ConfigIntFields[i].name) == 0) {
                    cfg->*(g_ConfigIntFields[i].ptr) = val;
                    break;
                }
            }
        }
        configs_read++;
    }

    delete[] data_buf;
    fclose(f);
    return true;
}

bool ConfigSerializer::ValidateBinary(const std::string& path) {
    FILE* f = fopen(path.c_str(), "rb");
    if (!f) return false;

    uint32_t magic, version;
    if (fread(&magic, sizeof(magic), 1, f) != 1 || magic != MAGIC) { fclose(f); return false; }
    if (fread(&version, sizeof(version), 1, f) != 1) { fclose(f); return false; }

    fseek(f, 0, SEEK_END);
    long file_size = ftell(f);
    if (file_size < 20) { fclose(f); return false; }

    uint32_t data_start = 16;
    uint32_t data_size = file_size - data_start - 4;

    fseek(f, data_start, SEEK_SET);
    uint8_t* buf = new uint8_t[data_size];
    if (fread(buf, 1, data_size, f) != data_size) {
        delete[] buf; fclose(f); return false;
    }

    uint32_t stored_crc;
    fread(&stored_crc, sizeof(stored_crc), 1, f);
    uint32_t calc_crc = CalcCRC32(buf, data_size);
    delete[] buf;
    fclose(f);

    return stored_crc == calc_crc;
}

struct JsonValue {
    enum Type { JSON_NULL, JSON_BOOL, JSON_NUMBER, JSON_STRING, JSON_ARRAY, JSON_OBJECT };
    Type type;
    bool bool_val;
    double num_val;
    std::string str_val;
    std::vector<JsonValue> arr_val;
    std::map<std::string, JsonValue> obj_val;

    JsonValue() : type(JSON_NULL), bool_val(false), num_val(0) {}
};

static std::string JsonEscape(const std::string& s) {
    std::string out;
    out.reserve(s.size() + 2);
    for (size_t i = 0; i < s.size(); i++) {
        char c = s[i];
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\b': out += "\\b"; break;
            case '\f': out += "\\f"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if ((unsigned char)c < 0x20) {
                    char buf[8];
                    snprintf(buf, sizeof(buf), "\\u%04x", (unsigned char)c);
                    out += buf;
                } else {
                    out += c;
                }
        }
    }
    return out;
}

static std::string JsonUnescape(const std::string& s) {
    std::string out;
    out.reserve(s.size());
    for (size_t i = 0; i < s.size(); i++) {
        if (s[i] == '\\' && i + 1 < s.size()) {
            char c = s[i + 1];
            switch (c) {
                case '"': out += '"'; i++; break;
                case '\\': out += '\\'; i++; break;
                case '/': out += '/'; i++; break;
                case 'b': out += '\b'; i++; break;
                case 'f': out += '\f'; i++; break;
                case 'n': out += '\n'; i++; break;
                case 'r': out += '\r'; i++; break;
                case 't': out += '\t'; i++; break;
                case 'u': {
                    if (i + 5 < s.size()) {
                        char hex[5] = {s[i+2], s[i+3], s[i+4], s[i+5], 0};
                        unsigned int cp = (unsigned int)strtol(hex, nullptr, 16);
                        if (cp < 0x80) out += (char)cp;
                        else if (cp < 0x800) { out += (char)(0xC0 | (cp >> 6)); out += (char)(0x80 | (cp & 0x3F)); }
                        else { out += (char)(0xE0 | (cp >> 12)); out += (char)(0x80 | ((cp >> 6) & 0x3F)); out += (char)(0x80 | (cp & 0x3F)); }
                        i += 5;
                    }
                    break;
                }
                default: out += c; break;
            }
        } else {
            out += s[i];
        }
    }
    return out;
}

class JsonParser {
    const std::string& input;
    size_t pos;
public:
    JsonParser(const std::string& s) : input(s), pos(0) {}

    void SkipWS() {
        while (pos < input.size() && (input[pos] == ' ' || input[pos] == '\t' || input[pos] == '\n' || input[pos] == '\r'))
            pos++;
    }

    char Peek() {
        SkipWS();
        return pos < input.size() ? input[pos] : 0;
    }

    char Next() {
        SkipWS();
        return pos < input.size() ? input[pos++] : 0;
    }

    bool Expect(char c) {
        SkipWS();
        if (pos < input.size() && input[pos] == c) { pos++; return true; }
        return false;
    }

    std::string ParseString() {
        SkipWS();
        if (pos >= input.size() || input[pos] != '"') return "";
        pos++;
        std::string s;
        while (pos < input.size() && input[pos] != '"') {
            if (input[pos] == '\\' && pos + 1 < input.size()) {
                s += '\\';
                s += input[pos + 1];
                pos += 2;
            } else {
                s += input[pos++];
            }
        }
        if (pos < input.size()) pos++;
        return JsonUnescape(s);
    }

    JsonValue ParseValue() {
        JsonValue v;
        char c = Peek();
        if (c == '"') {
            v.type = JsonValue::JSON_STRING;
            v.str_val = ParseString();
        } else if (c == '{') {
            v.type = JsonValue::JSON_OBJECT;
            Next();
            if (Expect('}')) return v;
            while (true) {
                std::string key = ParseString();
                Expect(':');
                v.obj_val[key] = ParseValue();
                if (!Expect(',')) break;
            }
            Expect('}');
        } else if (c == '[') {
            v.type = JsonValue::JSON_ARRAY;
            Next();
            if (Expect(']')) return v;
            while (true) {
                v.arr_val.push_back(ParseValue());
                if (!Expect(',')) break;
            }
            Expect(']');
        } else if (c == 't' || c == 'f') {
            v.type = JsonValue::JSON_BOOL;
            if (pos + 4 <= input.size() && input.substr(pos, 4) == "true") {
                v.bool_val = true; pos += 4;
            } else if (pos + 5 <= input.size() && input.substr(pos, 5) == "false") {
                v.bool_val = false; pos += 5;
            }
        } else if (c == 'n') {
            v.type = JsonValue::JSON_NULL;
            if (pos + 4 <= input.size() && input.substr(pos, 4) == "null") {
                pos += 4;
            }
        } else {
            v.type = JsonValue::JSON_NUMBER;
            size_t start = pos;
            if (pos < input.size() && input[pos] == '-') pos++;
            while (pos < input.size() && (isdigit(input[pos]) || input[pos] == '.' || input[pos] == 'e' || input[pos] == 'E' || input[pos] == '+' || input[pos] == '-')) {
                if ((input[pos] == '+' || input[pos] == '-') && pos > start && input[pos-1] != 'e' && input[pos-1] != 'E') break;
                pos++;
            }
            std::string num = input.substr(start, pos - start);
            if (num.find('.') != std::string::npos || num.find('e') != std::string::npos || num.find('E') != std::string::npos) {
                v.num_val = strtof(num.c_str(), nullptr);
            } else {
                v.num_val = (double)strtol(num.c_str(), nullptr, 10);
            }
        }
        return v;
    }

    JsonValue Parse() {
        return ParseValue();
    }
};

static std::string JsonIndent(int depth) {
    return std::string(depth * 2, ' ');
}

static void JsonSerializeValue(const JsonValue& v, std::string& out, int depth) {
    switch (v.type) {
        case JsonValue::JSON_NULL: out += "null"; break;
        case JsonValue::JSON_BOOL: out += v.bool_val ? "true" : "false"; break;
        case JsonValue::JSON_NUMBER: {
            char buf[64];
            if (v.num_val == (double)(int)v.num_val && fabs(v.num_val) < 1e9)
                snprintf(buf, sizeof(buf), "%d", (int)v.num_val);
            else
                snprintf(buf, sizeof(buf), "%.10g", v.num_val);
            out += buf;
            break;
        }
        case JsonValue::JSON_STRING:
            out += "\"" + JsonEscape(v.str_val) + "\"";
            break;
        case JsonValue::JSON_ARRAY: {
            out += "[";
            if (!v.arr_val.empty()) {
                out += "\n";
                for (size_t i = 0; i < v.arr_val.size(); i++) {
                    out += JsonIndent(depth + 1);
                    JsonSerializeValue(v.arr_val[i], out, depth + 1);
                    if (i + 1 < v.arr_val.size()) out += ",";
                    out += "\n";
                }
                out += JsonIndent(depth);
            }
            out += "]";
            break;
        }
        case JsonValue::JSON_OBJECT: {
            out += "{";
            if (!v.obj_val.empty()) {
                out += "\n";
                bool first = true;
                for (auto& kv : v.obj_val) {
                    if (!first) out += ",\n";
                    first = false;
                    out += JsonIndent(depth + 1);
                    out += "\"" + JsonEscape(kv.first) + "\": ";
                    JsonSerializeValue(kv.second, out, depth + 1);
                }
                out += "\n" + JsonIndent(depth);
            }
            out += "}";
            break;
        }
    }
}

static std::string JsonSerialize(const JsonValue& v) {
    std::string out;
    JsonSerializeValue(v, out, 0);
    out += "\n";
    return out;
}

bool ConfigSerializer::SaveJSON(const std::string& path, Toggles* tog, Config* cfg) {
    JsonValue root;
    root.type = JsonValue::JSON_OBJECT;

    JsonValue toggles_obj;
    toggles_obj.type = JsonValue::JSON_OBJECT;
    for (int i = 0; i < g_ToggleCount; i++) {
        JsonValue v;
        v.type = JsonValue::JSON_BOOL;
        v.bool_val = tog->*(g_ToggleFields[i].ptr);
        toggles_obj.obj_val[g_ToggleFields[i].name] = v;
    }
    root.obj_val["toggles"] = toggles_obj;

    JsonValue config_obj;
    config_obj.type = JsonValue::JSON_OBJECT;

    for (int i = 0; i < g_ConfigFloatCount; i++) {
        JsonValue v;
        v.type = JsonValue::JSON_NUMBER;
        v.num_val = cfg->*(g_ConfigFloatFields[i].ptr);
        config_obj.obj_val[g_ConfigFloatFields[i].name] = v;
    }

    for (int i = 0; i < g_ConfigIntCount; i++) {
        JsonValue v;
        v.type = JsonValue::JSON_NUMBER;
        v.num_val = cfg->*(g_ConfigIntFields[i].ptr);
        config_obj.obj_val[g_ConfigIntFields[i].name] = v;
    }

    for (int i = 0; i < g_ConfigColorCount; i++) {
        ImColor col = cfg->*(g_ConfigColorFields[i].ptr);
        JsonValue col_obj;
        col_obj.type = JsonValue::JSON_OBJECT;
        const char* comps[] = {"R", "G", "B", "A"};
        float vals[4] = {col.Value.x, col.Value.y, col.Value.z, col.Value.w};
        for (int c = 0; c < 4; c++) {
            JsonValue cv;
            cv.type = JsonValue::JSON_NUMBER;
            cv.num_val = vals[c];
            col_obj.obj_val[comps[c]] = cv;
        }
        config_obj.obj_val[g_ConfigColorFields[i].name] = col_obj;
    }

    root.obj_val["config"] = config_obj;

    std::string json = JsonSerialize(root);
    FILE* f = fopen(path.c_str(), "w");
    if (!f) return false;
    fwrite(json.c_str(), 1, json.size(), f);
    fclose(f);
    return true;
}

bool ConfigSerializer::LoadJSON(const std::string& path, Toggles* tog, Config* cfg) {
    FILE* f = fopen(path.c_str(), "rb");
    if (!f) return false;

    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);

    std::string content;
    content.resize(size);
    if (fread(&content[0], 1, size, f) != (size_t)size) {
        fclose(f); return false;
    }
    fclose(f);

    JsonParser parser(content);
    JsonValue root = parser.Parse();
    if (root.type != JsonValue::JSON_OBJECT) return false;

    auto toggles_it = root.obj_val.find("toggles");
    if (toggles_it != root.obj_val.end() && toggles_it->second.type == JsonValue::JSON_OBJECT) {
        for (auto& kv : toggles_it->second.obj_val) {
            if (kv.second.type != JsonValue::JSON_BOOL) continue;
            for (int i = 0; i < g_ToggleCount; i++) {
                if (kv.first == g_ToggleFields[i].name) {
                    tog->*(g_ToggleFields[i].ptr) = kv.second.bool_val;
                    break;
                }
            }
        }
    }

    auto config_it = root.obj_val.find("config");
    if (config_it != root.obj_val.end() && config_it->second.type == JsonValue::JSON_OBJECT) {
        for (auto& kv : config_it->second.obj_val) {
            if (kv.second.type == JsonValue::JSON_NUMBER) {
                double val = kv.second.num_val;
                bool matched = false;
                for (int i = 0; i < g_ConfigFloatCount; i++) {
                    if (kv.first == g_ConfigFloatFields[i].name) {
                        cfg->*(g_ConfigFloatFields[i].ptr) = (float)val;
                        matched = true; break;
                    }
                }
                if (!matched) {
                    for (int i = 0; i < g_ConfigIntCount; i++) {
                        if (kv.first == g_ConfigIntFields[i].name) {
                            cfg->*(g_ConfigIntFields[i].ptr) = (int)val;
                            break;
                        }
                    }
                }
            } else if (kv.second.type == JsonValue::JSON_OBJECT && kv.second.obj_val.size() == 4) {
                for (int i = 0; i < g_ConfigColorCount; i++) {
                    if (kv.first == g_ConfigColorFields[i].name) {
                        auto& col_obj = kv.second.obj_val;
                        auto rit = col_obj.find("R");
                        auto git = col_obj.find("G");
                        auto bit = col_obj.find("B");
                        auto ait = col_obj.find("A");
                        if (rit != col_obj.end() && git != col_obj.end() && bit != col_obj.end() && ait != col_obj.end()) {
                            ImColor col;
                            col.Value.x = (float)rit->second.num_val;
                            col.Value.y = (float)git->second.num_val;
                            col.Value.z = (float)bit->second.num_val;
                            col.Value.w = (float)ait->second.num_val;
                            cfg->*(g_ConfigColorFields[i].ptr) = col;
                        }
                        break;
                    }
                }
            }
        }
    }

    return true;
}

std::vector<std::string> ConfigSerializer::ListProfiles(const std::string& directory) {
    std::vector<std::string> profiles;
    DIR* dir = opendir(directory.c_str());
    if (!dir) {
        mkdir(directory.c_str(), 0777);
        return profiles;
    }
    struct dirent* entry;
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_REG) {
            const char* name = entry->d_name;
            size_t len = strlen(name);
            if (len > 4 && strcmp(name + len - 4, ".bgr") == 0) {
                std::string p(name, len - 4);
                profiles.push_back(p);
            }
        }
    }
    closedir(dir);
    return profiles;
}

bool ConfigSerializer::SaveProfile(const std::string& name, Toggles* tog, Config* cfg) {
    std::string dir = PROFILE_DIR;
    mkdir(dir.c_str(), 0777);
    std::string path = dir + name + ".bgr";
    return SaveBinary(path, tog, cfg);
}

bool ConfigSerializer::LoadProfile(const std::string& name, Toggles* tog, Config* cfg) {
    std::string path = std::string(PROFILE_DIR) + name + ".bgr";
    return LoadBinary(path, tog, cfg);
}

bool ConfigSerializer::DeleteProfile(const std::string& name) {
    std::string path = std::string(PROFILE_DIR) + name + ".bgr";
    return unlink(path.c_str()) == 0;
}
