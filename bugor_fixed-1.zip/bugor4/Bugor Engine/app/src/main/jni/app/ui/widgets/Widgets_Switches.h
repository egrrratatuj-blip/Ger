#pragma once
#include "../../../../imgui/imgui.h"

bool M_ModernSwitch(const char* label, bool* value, ImColor accent = ImColor(0, 180, 255));
bool M_ClassicToggle(const char* label, bool* value, ImColor accent = ImColor(0, 180, 255));
bool M_FancyCheckbox(const char* label, bool* value, ImColor accent = ImColor(0, 180, 255));
bool M_RadioSelector(const char* label, bool active, ImColor accent = ImColor(0, 180, 255));
int M_SegmentedToggle(const char* label, int* activeIndex, const char** options, int optionCount, ImColor accent = ImColor(0, 180, 255));
bool M_Switch3D(const char* label, bool* value, ImColor accent = ImColor(0, 180, 255));
void M_BooleanIndicator(const char* label, bool value, ImColor activeColor = ImColor(0, 255, 0), ImColor inactiveColor = ImColor(80, 80, 100));
bool M_ToggleRow(const char* icon, const char* label, const char* subtitle, bool* value, ImColor accent = ImColor(0, 180, 255));
