#pragma once
#include "Config.h"

class ConfigSystem {
public:
    ConfigSystem();
    bool SaveToFile(const char* path);
    bool LoadFromFile(const char* path);
    void ResetToDefaults();
    Toggles& GetToggles();
    Config& GetConfig();
private:
    Toggles toggles;
    Config config;
};
