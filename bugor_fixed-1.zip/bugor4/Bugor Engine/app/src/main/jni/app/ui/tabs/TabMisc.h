#pragma once
#include <imgui.h>

void DrawTabMisc(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize);
void InitTabMisc();
void ShutdownTabMisc();
