#pragma once
#include <imgui.h>

void DrawTabPlayers(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize);
void InitTabPlayers();
void ShutdownTabPlayers();
