#pragma once
#include "../../../imgui/imgui.h"
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846f
#endif

namespace Easing {
    float Linear(float t);
    float InQuad(float t);
    float OutQuad(float t);
    float InOutQuad(float t);
    float InCubic(float t);
    float OutCubic(float t);
    float InOutCubic(float t);
    float InQuart(float t);
    float OutQuart(float t);
    float InOutQuart(float t);
    float InQuint(float t);
    float OutQuint(float t);
    float InOutQuint(float t);
    float InSine(float t);
    float OutSine(float t);
    float InOutSine(float t);
    float InExpo(float t);
    float OutExpo(float t);
    float InOutExpo(float t);
    float InCirc(float t);
    float OutCirc(float t);
    float InOutCirc(float t);
    float InElastic(float t);
    float OutElastic(float t);
    float InOutElastic(float t);
    float InBack(float t, float overshoot = 1.70158f);
    float OutBack(float t, float overshoot = 1.70158f);
    float InOutBack(float t, float overshoot = 1.70158f);
    float InBounce(float t);
    float OutBounce(float t);
    float InOutBounce(float t);
    float OutElasticBounce(float t);
    float SoftSpot(float t);
    float Pulse(float t);
    float Lerp(float a, float b, float t);
    float LerpEased(float a, float b, float t, float (*easingFunc)(float));
    ImVec2 LerpVec2(ImVec2 a, ImVec2 b, float t, float (*easingFunc)(float));
    ImColor LerpColor(ImColor a, ImColor b, float t, float (*easingFunc)(float));
}

float ApplyEasing(float t, int easingType);
const char* GetEasingName(int easingType);
