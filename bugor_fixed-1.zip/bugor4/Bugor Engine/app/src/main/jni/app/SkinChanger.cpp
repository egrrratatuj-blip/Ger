#include "SkinChanger.h"
#include <cstring>

static const uintptr_t SKIN_OFFSET_ID = 0x2C0;
static const uintptr_t SKIN_OFFSET_WEAR = 0x2C4;
static const uintptr_t SKIN_OFFSET_SEED = 0x2C8;
static const uintptr_t WEAPON_SLOT_OFFSETS[] = {0x5E0, 0x5E8, 0x5F0, 0x5F8, 0x600, 0x608, 0x610, 0x618};
static const int WEAPON_SLOT_COUNT = 8;

SkinChanger::SkinChanger(MemoryIO* mem, GameOffsets* offsets, Config* cfg, Toggles* tog) {
    Mem = mem;
    Offsets = offsets;
    Cfg = cfg;
    Tog = tog;
    selectedSkin = 0;
}

uintptr_t SkinChanger::FindWeaponSlot(int slot) {
    if (!Offsets->Initialized || slot < 0 || slot >= WEAPON_SLOT_COUNT) return 0;
    GamesOffsetTable* gt = &Offsets->GamesTable[Offsets->CurrentGameID];
    if (Offsets->CurrentGameID < 0) return 0;
    uintptr_t uworld = Offsets->UWorld;
    if (!uworld) return 0;
    uintptr_t gameInstance = Mem->ReadPtr64(uworld + gt->OffsetGameInstance);
    if (!gameInstance) return 0;
    uintptr_t localPlayer = Mem->ReadPtr64(gameInstance + gt->OffsetLocalPlayer);
    if (!localPlayer) return 0;
    uintptr_t playerController = Mem->ReadPtr64(localPlayer + gt->OffsetPlayerController);
    if (!playerController) return 0;
    uintptr_t pawn = Mem->ReadPtr64(playerController + 0x2F8);
    if (!pawn) return 0;
    uintptr_t weaponManager = Mem->ReadPtr64(pawn + gt->OffsetEntityWeapon);
    if (!weaponManager) return 0;
    uintptr_t weaponSlot = Mem->ReadPtr64(weaponManager + WEAPON_SLOT_OFFSETS[slot]);
    return weaponSlot;
}

uintptr_t SkinChanger::FindCharacterMesh() {
    if (!Offsets->Initialized) return 0;
    GamesOffsetTable* gt = &Offsets->GamesTable[Offsets->CurrentGameID];
    if (Offsets->CurrentGameID < 0) return 0;
    uintptr_t uworld = Offsets->UWorld;
    if (!uworld) return 0;
    uintptr_t gameInstance = Mem->ReadPtr64(uworld + gt->OffsetGameInstance);
    if (!gameInstance) return 0;
    uintptr_t localPlayer = Mem->ReadPtr64(gameInstance + gt->OffsetLocalPlayer);
    if (!localPlayer) return 0;
    uintptr_t playerController = Mem->ReadPtr64(localPlayer + gt->OffsetPlayerController);
    if (!playerController) return 0;
    uintptr_t pawn = Mem->ReadPtr64(playerController + 0x2F8);
    if (!pawn) return 0;
    uintptr_t mesh = Mem->ReadPtr64(pawn + gt->OffsetEntityBone);
    return mesh;
}

bool SkinChanger::WriteSkinID(uintptr_t addr, int skinID) {
    if (!addr) return false;
    Mem->WriteInt(addr + SKIN_OFFSET_ID, skinID);
    return true;
}

bool SkinChanger::WriteSkinWear(uintptr_t addr, float wear) {
    if (!addr) return false;
    Mem->WriteFloat(addr + SKIN_OFFSET_WEAR, wear);
    return true;
}

bool SkinChanger::WriteSkinSeed(uintptr_t addr, int seed) {
    if (!addr) return false;
    Mem->WriteInt(addr + SKIN_OFFSET_SEED, seed);
    return true;
}

void SkinChanger::RefreshSkinList() {
    skins.clear();
    skins.push_back({0, "Default", "weapon", 0, 0, 0, 0.0f, 0, false});
    skins.push_back({1, "Dragon Lore", "weapon", 0, 4, 0, 0.05f, 12345, false});
    skins.push_back({2, "Fire Serpent", "weapon", 0, 4, 0, 0.1f, 67890, false});
    skins.push_back({3, "Asiimov", "weapon", 0, 3, 0, 0.3f, 11111, false});
    skins.push_back({4, "Neon Rider", "weapon", 0, 3, 0, 0.0f, 22222, false});
    skins.push_back({5, "Fade", "weapon", 0, 3, 0, 0.0f, 33333, false});
    skins.push_back({6, "Kill Confirmed", "weapon", 0, 4, 0, 0.2f, 44444, false});
    skins.push_back({7, "Medusa", "weapon", 0, 4, 0, 0.0f, 55555, false});
    skins.push_back({8, "Howl", "weapon", 0, 4, 0, 0.0f, 66666, false});
    skins.push_back({9, "Knight", "weapon", 0, 3, 0, 0.15f, 77777, false});
    skins.push_back({10, "Default", "character", 0, 0, 0, 0.0f, 0, false});
    skins.push_back({11, "Gold", "character", 0, 4, 0, 0.0f, 0, false});
    skins.push_back({12, "Diamond", "character", 0, 4, 0, 0.0f, 0, false});
    skins.push_back({13, "Stealth", "character", 0, 2, 0, 0.0f, 0, false});
    skins.push_back({14, "Tactical", "character", 0, 3, 0, 0.3f, 0, false});
    skins.push_back({15, "Ghost", "character", 0, 4, 0, 0.0f, 0, false});
    skins.push_back({16, "Default", "backpack", 0, 0, 0, 0.0f, 0, false});
    skins.push_back({17, "Digital", "backpack", 0, 2, 0, 0.2f, 0, false});
    skins.push_back({18, "Flame", "backpack", 0, 3, 0, 0.1f, 0, false});
    skins.push_back({19, "Void", "backpack", 0, 4, 0, 0.0f, 0, false});
}

void SkinChanger::ApplySkin(int index) {
    if (index < 0 || index >= (int)skins.size()) return;
    SkinEntry& s = skins[index];
    if (s.Category == "weapon") {
        for (int i = 0; i < WEAPON_SLOT_COUNT; i++) {
            uintptr_t addr = FindWeaponSlot(i);
            if (addr) {
                WriteSkinID(addr, s.SkinID);
                WriteSkinWear(addr, s.Wear);
                WriteSkinSeed(addr, s.Seed);
            }
        }
        s.Applied = true;
    } else if (s.Category == "character") {
        uintptr_t mesh = FindCharacterMesh();
        if (mesh) {
            WriteSkinID(mesh, s.SkinID);
            WriteSkinWear(mesh, s.Wear);
            WriteSkinSeed(mesh, s.Seed);
            s.Applied = true;
        }
    } else if (s.Category == "backpack") {
        uintptr_t mesh = FindCharacterMesh();
        if (mesh) {
            uintptr_t backpack = Mem->ReadPtr64(mesh + 0x4B0);
            if (backpack) {
                WriteSkinID(backpack, s.SkinID);
                WriteSkinWear(backpack, s.Wear);
                WriteSkinSeed(backpack, s.Seed);
                s.Applied = true;
            }
        }
    }
}

void SkinChanger::ApplyAllSkins() {
    RefreshSkinList();
    for (int i = 0; i < (int)skins.size(); i++) {
        if (skins[i].SkinID > 0) {
            if (skins[i].Category == "weapon") {
                uintptr_t addr = FindWeaponSlot(i);
                if (addr) {
                    WriteSkinID(addr, skins[i].SkinID);
                    WriteSkinWear(addr, skins[i].Wear);
                    WriteSkinSeed(addr, skins[i].Seed);
                    skins[i].Applied = true;
                }
            } else if (skins[i].Category == "character") {
                uintptr_t mesh = FindCharacterMesh();
                if (mesh) {
                    WriteSkinID(mesh, skins[i].SkinID);
                    WriteSkinWear(mesh, skins[i].Wear);
                    WriteSkinSeed(mesh, skins[i].Seed);
                    skins[i].Applied = true;
                }
            } else if (skins[i].Category == "backpack") {
                uintptr_t mesh = FindCharacterMesh();
                if (mesh) {
                    uintptr_t backpack = Mem->ReadPtr64(mesh + 0x4B0);
                    if (backpack) {
                        WriteSkinID(backpack, skins[i].SkinID);
                        WriteSkinWear(backpack, skins[i].Wear);
                        WriteSkinSeed(backpack, skins[i].Seed);
                        skins[i].Applied = true;
                    }
                }
            }
        }
    }
}

void SkinChanger::ResetSkins() {
    for (int i = 0; i < (int)skins.size(); i++) {
        if (skins[i].Applied) {
            if (skins[i].Category == "weapon") {
                for (int s = 0; s < WEAPON_SLOT_COUNT; s++) {
                    uintptr_t addr = FindWeaponSlot(s);
                    if (addr) {
                        WriteSkinID(addr, 0);
                        WriteSkinWear(addr, 0.0f);
                        WriteSkinSeed(addr, 0);
                    }
                }
            } else if (skins[i].Category == "character") {
                uintptr_t mesh = FindCharacterMesh();
                if (mesh) {
                    WriteSkinID(mesh, 0);
                    WriteSkinWear(mesh, 0.0f);
                    WriteSkinSeed(mesh, 0);
                }
            } else if (skins[i].Category == "backpack") {
                uintptr_t mesh = FindCharacterMesh();
                if (mesh) {
                    uintptr_t backpack = Mem->ReadPtr64(mesh + 0x4B0);
                    if (backpack) {
                        WriteSkinID(backpack, 0);
                        WriteSkinWear(backpack, 0.0f);
                        WriteSkinSeed(backpack, 0);
                    }
                }
            }
            skins[i].Applied = false;
        }
    }
}

void SkinChanger::Update() {
    if (!Offsets->Initialized) return;
    for (int i = 0; i < (int)skins.size(); i++) {
        if (!skins[i].Applied) continue;
        if (skins[i].Category == "weapon") {
            uintptr_t addr = FindWeaponSlot(i);
            if (addr) {
                int currentID = Mem->ReadInt(addr + SKIN_OFFSET_ID);
                if (currentID != skins[i].SkinID) {
                    WriteSkinID(addr, skins[i].SkinID);
                    WriteSkinWear(addr, skins[i].Wear);
                    WriteSkinSeed(addr, skins[i].Seed);
                }
            }
        } else if (skins[i].Category == "character") {
            uintptr_t mesh = FindCharacterMesh();
            if (mesh) {
                int currentID = Mem->ReadInt(mesh + SKIN_OFFSET_ID);
                if (currentID != skins[i].SkinID) {
                    WriteSkinID(mesh, skins[i].SkinID);
                    WriteSkinWear(mesh, skins[i].Wear);
                    WriteSkinSeed(mesh, skins[i].Seed);
                }
            }
        } else if (skins[i].Category == "backpack") {
            uintptr_t mesh = FindCharacterMesh();
            if (mesh) {
                uintptr_t backpack = Mem->ReadPtr64(mesh + 0x4B0);
                if (backpack) {
                    int currentID = Mem->ReadInt(backpack + SKIN_OFFSET_ID);
                    if (currentID != skins[i].SkinID) {
                        WriteSkinID(backpack, skins[i].SkinID);
                        WriteSkinWear(backpack, skins[i].Wear);
                        WriteSkinSeed(backpack, skins[i].Seed);
                    }
                }
            }
        }
    }
}
