#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "../../../imgui/imgui.h"
#include "../../../imgui/imgui_internal.h"
#include <stdlib.h>
#include <string.h>
static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }
static float R(float min, float max) { return min + (float)rand() / (float)RAND_MAX * (max - min); }
static float Lerp(float a, float b, float t) { return a + (b - a) * t; }

struct Particle {
    ImVec2 pos, vel, accel;
    float life, maxLife;
    float size, startSize, endSize;
    ImColor color, startColor, endColor;
    float rotation, rotSpeed;
    int shape;
    bool active;
};

class ParticleSystem {
    static const int MAX_PARTICLES = 200;
    Particle particles[MAX_PARTICLES];
    int emitCount;
    float emitTimer;
    float emitRate;
    ImVec2 emitterPos;
    ImVec2 emitterSize;
public:
    ParticleSystem() {
        for (int i = 0; i < MAX_PARTICLES; i++) particles[i].active = false;
        emitCount = 0;
        emitTimer = 0.0f;
        emitRate = 60.0f;
        emitterPos = ImVec2(0, 0);
        emitterSize = ImVec2(100, 100);
    }

    void SetEmitter(ImVec2 pos, ImVec2 size) {
        emitterPos = pos;
        emitterSize = size;
    }

    void SetRate(float rate) {
        emitRate = ImMax(rate, 1.0f);
    }

    void Emit(int count, ImColor color, float minSpeed, float maxSpeed, float minSize, float maxSize, float lifetime) {
        for (int e = 0; e < count; e++) {
            int idx = -1;
            for (int i = 0; i < MAX_PARTICLES; i++) {
                if (!particles[i].active) { idx = i; break; }
            }
            if (idx < 0) break;
            Particle& p = particles[idx];
            float angle = R(0, IM_PI * 2.0f);
            float speed = R(minSpeed, maxSpeed);
            p.pos = ImVec2(
                emitterPos.x + R(0, emitterSize.x),
                emitterPos.y + R(0, emitterSize.y)
            );
            p.vel = ImVec2(cosf(angle) * speed, sinf(angle) * speed);
            p.accel = ImVec2(R(-10.0f, 10.0f), 50.0f);
            p.life = lifetime;
            p.maxLife = lifetime;
            float sz = R(minSize, maxSize);
            p.size = sz;
            p.startSize = sz;
            p.endSize = sz * 0.2f;
            p.startColor = color;
            ImColor endCol = color;
            endCol.Value.w = 0.0f;
            p.endColor = endCol;
            p.color = color;
            p.rotation = R(0, IM_PI * 2.0f);
            p.rotSpeed = R(-2.0f, 2.0f);
            p.shape = rand() % 4;
            p.active = true;
        }
    }

    void Update(float dt) {
        for (int i = 0; i < MAX_PARTICLES; i++) {
            if (!particles[i].active) continue;
            Particle& p = particles[i];
            p.vel.x += p.accel.x * dt;
            p.vel.y += p.accel.y * dt;
            p.pos.x += p.vel.x * dt;
            p.pos.y += p.vel.y * dt;
            p.life -= dt;
            if (p.life <= 0.0f) {
                p.active = false;
                continue;
            }
            float t = 1.0f - p.life / p.maxLife;
            t = ImClamp(t, 0.0f, 1.0f);
            p.size = Lerp(p.startSize, p.endSize, t);
            float r = Lerp(p.startColor.Value.x, p.endColor.Value.x, t);
            float g = Lerp(p.startColor.Value.y, p.endColor.Value.y, t);
            float b = Lerp(p.startColor.Value.z, p.endColor.Value.z, t);
            float a = p.startColor.Value.w * (1.0f - t);
            p.color = ImColor(r, g, b, a);
            p.rotation += p.rotSpeed * dt;
        }
        emitTimer += dt;
        while (emitTimer >= 1.0f / emitRate && emitCount < MAX_PARTICLES * 2) {
            emitTimer -= 1.0f / emitRate;
        }
    }

    void Render(ImDrawList* dl) {
        for (int i = 0; i < MAX_PARTICLES; i++) {
            if (!particles[i].active) continue;
            Particle& p = particles[i];
            ImU32 col = C(p.color);
            float s = p.size;
            ImVec2 pos = p.pos;
            float rot = p.rotation;
            float fadeGlow = p.life / p.maxLife;
            if (fadeGlow < 0.2f) {
                float glowAlpha = (1.0f - fadeGlow * 5.0f) * p.color.Value.w * 0.4f;
                if (glowAlpha > 0.0f) {
                    ImColor glowCol = p.color;
                    glowCol.Value.w = glowAlpha;
                    dl->AddCircleFilled(pos, s * 2.5f, C(glowCol), 16);
                }
            }
            if (p.shape == 0) {
                dl->AddCircleFilled(pos, s, col, 24);
            } else if (p.shape == 1) {
                dl->AddRectFilled(
                    ImVec2(pos.x - s, pos.y - s),
                    ImVec2(pos.x + s, pos.y + s),
                    col
                );
            } else if (p.shape == 2) {
                ImVec2 t0 = ImVec2(
                    pos.x + cosf(rot) * s * 1.5f,
                    pos.y + sinf(rot) * s * 1.5f
                );
                ImVec2 t1 = ImVec2(
                    pos.x + cosf(rot + IM_PI * 2.0f / 3.0f) * s,
                    pos.y + sinf(rot + IM_PI * 2.0f / 3.0f) * s
                );
                ImVec2 t2 = ImVec2(
                    pos.x + cosf(rot + IM_PI * 4.0f / 3.0f) * s,
                    pos.y + sinf(rot + IM_PI * 4.0f / 3.0f) * s
                );
                dl->AddTriangleFilled(t0, t1, t2, col);
            } else if (p.shape == 3) {
                for (int j = 0; j < 5; j++) {
                    float a1 = rot + (float)j * IM_PI * 2.0f / 5.0f - IM_PI / 2.0f;
                    float a2 = rot + (float)(j + 1) * IM_PI * 2.0f / 5.0f - IM_PI / 2.0f;
                    float aInner1 = rot + (float)j * IM_PI * 2.0f / 5.0f + IM_PI / 10.0f - IM_PI / 2.0f;
                    float aInner2 = rot + (float)(j + 1) * IM_PI * 2.0f / 5.0f + IM_PI / 10.0f - IM_PI / 2.0f;
                    ImVec2 outer1 = ImVec2(pos.x + cosf(a1) * s, pos.y + sinf(a1) * s);
                    ImVec2 outer2 = ImVec2(pos.x + cosf(a2) * s, pos.y + sinf(a2) * s);
                    ImVec2 inner = ImVec2(
                        pos.x + cosf(aInner1) * s * 0.4f,
                        pos.y + sinf(aInner1) * s * 0.4f
                    );
                    dl->AddTriangleFilled(outer1, inner, outer2, col);
                }
            }
        }
    }

    void Clear() {
        for (int i = 0; i < MAX_PARTICLES; i++) particles[i].active = false;
        emitCount = 0;
        emitTimer = 0.0f;
    }
};

class SparkSystem {
    Particle particles[80];
public:
    SparkSystem() {
        for (int i = 0; i < 80; i++) particles[i].active = false;
    }

    void Emit(int count, ImVec2 pos, ImColor color) {
        for (int e = 0; e < count; e++) {
            int idx = -1;
            for (int i = 0; i < 80; i++) {
                if (!particles[i].active) { idx = i; break; }
            }
            if (idx < 0) break;
            Particle& p = particles[idx];
            float angle = R(0, IM_PI * 2.0f);
            float speed = R(150.0f, 500.0f);
            p.pos = ImVec2(pos.x + R(-2, 2), pos.y + R(-2, 2));
            p.vel = ImVec2(cosf(angle) * speed, sinf(angle) * speed);
            p.accel = ImVec2(0, 0);
            p.life = R(0.1f, 0.4f);
            p.maxLife = p.life;
            p.size = R(1.0f, 3.0f);
            p.startSize = p.size;
            p.endSize = 0.0f;
            p.startColor = color;
            ImColor ec = color;
            ec.Value.w = 0.0f;
            p.endColor = ec;
            p.color = color;
            p.rotation = 0;
            p.rotSpeed = 0;
            p.shape = 0;
            p.active = true;
        }
    }

    void Update(float dt) {
        for (int i = 0; i < 80; i++) {
            if (!particles[i].active) continue;
            Particle& p = particles[i];
            p.pos.x += p.vel.x * dt;
            p.pos.y += p.vel.y * dt;
            p.life -= dt;
            if (p.life <= 0.0f) { p.active = false; continue; }
            float t = 1.0f - p.life / p.maxLife;
            p.size = Lerp(p.startSize, p.endSize, t);
            float a = p.startColor.Value.w * (1.0f - t);
            p.color = p.startColor;
            p.color.Value.w = a;
        }
    }

    void Render(ImDrawList* dl) {
        for (int i = 0; i < 80; i++) {
            if (!particles[i].active) continue;
            Particle& p = particles[i];
            ImU32 col = C(p.color);
            float s = p.size;
            if (s < 0.5f) {
                dl->AddCircleFilled(p.pos, 1.0f, col, 8);
            } else {
                dl->AddCircleFilled(p.pos, s, col, 12);
                if (p.color.Value.w > 0.3f) {
                    ImColor glow = p.color;
                    glow.Value.w *= 0.3f;
                    dl->AddCircleFilled(p.pos, s * 3.0f, C(glow), 8);
                }
            }
        }
    }

    void Clear() {
        for (int i = 0; i < 80; i++) particles[i].active = false;
    }
};

class ConfettiSystem {
    Particle particles[120];
public:
    ConfettiSystem() {
        for (int i = 0; i < 120; i++) particles[i].active = false;
    }

    void Emit(int count, ImVec2 pos, ImVec2 area) {
        static ImColor colors[] = {
            ImColor(255, 50, 50), ImColor(50, 255, 50),
            ImColor(50, 50, 255), ImColor(255, 255, 50),
            ImColor(255, 50, 255), ImColor(50, 255, 255),
            ImColor(255, 128, 0), ImColor(128, 0, 255)
        };
        for (int e = 0; e < count; e++) {
            int idx = -1;
            for (int i = 0; i < 120; i++) {
                if (!particles[i].active) { idx = i; break; }
            }
            if (idx < 0) break;
            Particle& p = particles[idx];
            float angle = R(-IM_PI * 0.3f, IM_PI * 0.3f) - IM_PI / 2.0f;
            float speed = R(20.0f, 80.0f);
            p.pos = ImVec2(pos.x + R(0, area.x), pos.y + R(0, area.y));
            p.vel = ImVec2(cosf(angle) * speed + R(-10, 10), sinf(angle) * speed);
            p.accel = ImVec2(R(-5.0f, 5.0f), 40.0f);
            p.life = R(2.0f, 4.0f);
            p.maxLife = p.life;
            p.size = R(3.0f, 8.0f);
            p.startSize = p.size;
            p.endSize = p.size * 0.5f;
            ImColor c = colors[rand() % 8];
            p.startColor = c;
            ImColor ec = c;
            ec.Value.w = 0.0f;
            p.endColor = ec;
            p.color = c;
            p.rotation = R(0, IM_PI * 2.0f);
            p.rotSpeed = R(-3.0f, 3.0f);
            p.shape = 1;
            p.active = true;
        }
    }

    void Update(float dt) {
        for (int i = 0; i < 120; i++) {
            if (!particles[i].active) continue;
            Particle& p = particles[i];
            p.vel.x += p.accel.x * dt;
            p.vel.y += p.accel.y * dt;
            p.pos.x += p.vel.x * dt;
            p.pos.y += p.vel.y * dt;
            p.rotation += p.rotSpeed * dt;
            p.life -= dt;
            if (p.life <= 0.0f) { p.active = false; continue; }
            float t = 1.0f - p.life / p.maxLife;
            p.size = Lerp(p.startSize, p.endSize, t);
            float a = p.startColor.Value.w * (1.0f - t);
            p.color = p.startColor;
            p.color.Value.w = a;
        }
    }

    void Render(ImDrawList* dl) {
        for (int i = 0; i < 120; i++) {
            if (!particles[i].active) continue;
            Particle& p = particles[i];
            ImU32 col = C(p.color);
            float hs = p.size * 0.5f;
            float c = cosf(p.rotation), s = sinf(p.rotation);
            ImVec2 corners[4] = {
                ImVec2(p.pos.x + (-hs * c - -hs * s), p.pos.y + (-hs * s + -hs * c)),
                ImVec2(p.pos.x + ( hs * c - -hs * s), p.pos.y + ( hs * s + -hs * c)),
                ImVec2(p.pos.x + ( hs * c -  hs * s), p.pos.y + ( hs * s +  hs * c)),
                ImVec2(p.pos.x + (-hs * c -  hs * s), p.pos.y + (-hs * s +  hs * c))
            };
            dl->AddQuadFilled(corners[0], corners[1], corners[2], corners[3], col);
        }
    }

    void Clear() {
        for (int i = 0; i < 120; i++) particles[i].active = false;
    }
};

class TextParticleSystem {
    static const int MAX_GLYPHS = 64;
    struct GlyphParticle {
        bool active;
        ImVec2 basePos, pos, vel;
        float life, maxLife;
        float size;
        ImColor color;
        char ch;
    };
    GlyphParticle glyphs[MAX_GLYPHS];
public:
    TextParticleSystem() {
        for (int i = 0; i < MAX_GLYPHS; i++) glyphs[i].active = false;
    }

    void EmitText(ImVec2 pos, const char* text, ImColor color) {
        int len = 0;
        while (text[len] && len < 16) len++;
        if (len == 0) return;
        int total = len * 3;
        int count = 0;
        for (int i = 0; i < total && count < MAX_GLYPHS; i++) {
            int idx = -1;
            for (int j = 0; j < MAX_GLYPHS; j++) {
                if (!glyphs[j].active) { idx = j; break; }
            }
            if (idx < 0) break;
            GlyphParticle& g = glyphs[idx];
            int charIdx = i / 3;
            float offsetX = (float)(i % 3) * 8.0f - 8.0f;
            float offsetY = (float)(charIdx) * -12.0f;
            g.basePos = ImVec2(pos.x + offsetX, pos.y + offsetY);
            g.pos = g.basePos;
            g.vel = ImVec2(R(-30.0f, 30.0f), R(-80.0f, -20.0f));
            g.life = R(1.0f, 2.0f);
            g.maxLife = g.life;
            g.size = R(10.0f, 14.0f);
            g.color = color;
            g.ch = text[charIdx];
            g.active = true;
            count++;
        }
    }

    void Update(float dt) {
        for (int i = 0; i < MAX_GLYPHS; i++) {
            if (!glyphs[i].active) continue;
            GlyphParticle& g = glyphs[i];
            g.vel.y += 60.0f * dt;
            g.pos.x += g.vel.x * dt;
            g.pos.y += g.vel.y * dt;
            g.life -= dt;
            if (g.life <= 0.0f) {
                g.active = false;
                continue;
            }
            float t = 1.0f - g.life / g.maxLife;
            float a = g.color.Value.w * (1.0f - t);
            g.color.Value.w = ImClamp(a, 0.0f, 1.0f);
            g.size = 14.0f * (1.0f - t * 0.5f);
        }
    }

    void Render(ImDrawList* dl) {
        for (int i = 0; i < MAX_GLYPHS; i++) {
            if (!glyphs[i].active) continue;
            GlyphParticle& g = glyphs[i];
            char str[2] = { g.ch, 0 };
            ImU32 col = C(g.color);
            dl->AddText(ImGui::GetFont(), g.size, g.pos, col, str);
        }
    }

    void Clear() {
        for (int i = 0; i < MAX_GLYPHS; i++) glyphs[i].active = false;
    }
};

class TrailSystem {
    static const int MAX_TRAIL = 100;
    struct TrailPoint {
        ImVec2 pos;
        float life;
        float maxLife;
        float size;
        ImColor color;
    };
    TrailPoint points[MAX_TRAIL];
    int head;
public:
    TrailSystem() {
        for (int i = 0; i < MAX_TRAIL; i++) {
            points[i].life = 0;
            points[i].maxLife = 0.5f;
            points[i].size = 4.0f;
        }
        head = 0;
    }

    void AddPoint(ImVec2 pos, ImColor color) {
        TrailPoint& tp = points[head];
        tp.pos = pos;
        tp.life = 0.5f;
        tp.maxLife = 0.5f;
        tp.size = R(2.0f, 5.0f);
        tp.color = color;
        head = (head + 1) % MAX_TRAIL;
    }

    void AddPoint(ImVec2 pos) {
        AddPoint(pos, ImColor(255, 255, 255, 200));
    }

    void Update(float dt) {
        for (int i = 0; i < MAX_TRAIL; i++) {
            if (points[i].life <= 0) continue;
            points[i].life -= dt;
            if (points[i].life < 0) points[i].life = 0;
        }
    }

    void Render(ImDrawList* dl) {
        int count = 0;
        ImVec2 prevPos;
        bool hasPrev = false;
        ImColor prevCol;
        float prevSize = 0;
        for (int pass = 0; pass < 2; pass++) {
            for (int i = 0; i < MAX_TRAIL; i++) {
                int idx = pass == 0 ? (head - 1 - i + MAX_TRAIL * 2) % MAX_TRAIL : i;
                if (points[idx].life <= 0) continue;
                float t = 1.0f - points[idx].life / points[idx].maxLife;
                float a = points[idx].color.Value.w * (1.0f - t);
                ImColor c = points[idx].color;
                c.Value.w = ImClamp(a, 0.0f, 1.0f);
                float sz = points[idx].size * (1.0f - t * 0.7f);
                if (pass == 0) {
                    if (sz > 1.0f) {
                        ImColor glowCol = c;
                        glowCol.Value.w *= 0.3f;
                        dl->AddCircleFilled(points[idx].pos, sz * 3.0f, C(glowCol), 12);
                    }
                } else {
                    if (hasPrev) {
                        dl->AddLine(prevPos, points[idx].pos, C(c), (sz + prevSize) * 0.5f);
                    }
                    prevPos = points[idx].pos;
                    prevCol = c;
                    prevSize = sz;
                    hasPrev = true;
                }
            }
        }
    }

    void Clear() {
        for (int i = 0; i < MAX_TRAIL; i++) points[i].life = 0;
        head = 0;
    }
};

class SnowSystem {
    static const int MAX_FLAKES = 150;
    struct Flake {
        ImVec2 pos;
        float speed;
        float drift;
        float size;
        float wobble;
        float alpha;
        bool active;
    };
    Flake flakes[MAX_FLAKES];
    ImVec2 area;
public:
    SnowSystem() {
        for (int i = 0; i < MAX_FLAKES; i++) flakes[i].active = false;
        area = ImVec2(400, 300);
    }

    void SetArea(ImVec2 a) { area = a; }

    void Update(float dt) {
        int activeCount = 0;
        for (int i = 0; i < MAX_FLAKES; i++) if (flakes[i].active) activeCount++;
        int target = 60;
        if (activeCount < target) {
            for (int i = 0; i < MAX_FLAKES && activeCount < target; i++) {
                if (!flakes[i].active) {
                    flakes[i].pos = ImVec2(R(0, area.x), R(-20, 0));
                    flakes[i].speed = R(30.0f, 80.0f);
                    flakes[i].drift = R(-15.0f, 15.0f);
                    flakes[i].size = R(1.5f, 4.0f);
                    flakes[i].wobble = R(0, IM_PI * 2.0f);
                    flakes[i].alpha = R(0.3f, 0.8f);
                    flakes[i].active = true;
                    activeCount++;
                }
            }
        }
        for (int i = 0; i < MAX_FLAKES; i++) {
            if (!flakes[i].active) continue;
            Flake& f = flakes[i];
            f.wobble += dt * 2.0f;
            f.pos.x += f.drift * dt + sinf(f.wobble) * 10.0f * dt;
            f.pos.y += f.speed * dt;
            if (f.pos.y > area.y + 20) f.active = false;
        }
    }

    void Render(ImDrawList* dl) {
        for (int i = 0; i < MAX_FLAKES; i++) {
            if (!flakes[i].active) continue;
            Flake& f = flakes[i];
            ImColor col = ImColor(255, 255, 255, (int)(f.alpha * 255));
            dl->AddCircleFilled(f.pos, f.size, C(col), 8);
            if (f.size > 2.5f) {
                ImColor glow = ImColor(255, 255, 255, (int)(f.alpha * 60));
                dl->AddCircleFilled(f.pos, f.size * 2.5f, C(glow), 8);
            }
        }
    }

    void Clear() {
        for (int i = 0; i < MAX_FLAKES; i++) flakes[i].active = false;
    }
};

class RainSystem {
    static const int MAX_DROPS = 100;
    struct Drop {
        ImVec2 pos;
        float speed;
        float length;
        float alpha;
        bool active;
    };
    Drop drops[MAX_DROPS];
    ImVec2 area;
public:
    RainSystem() {
        for (int i = 0; i < MAX_DROPS; i++) drops[i].active = false;
        area = ImVec2(400, 300);
    }

    void SetArea(ImVec2 a) { area = a; }

    void Update(float dt) {
        int activeCount = 0;
        for (int i = 0; i < MAX_DROPS; i++) if (drops[i].active) activeCount++;
        int target = 40;
        if (activeCount < target) {
            for (int i = 0; i < MAX_DROPS && activeCount < target; i++) {
                if (!drops[i].active) {
                    drops[i].pos = ImVec2(R(0, area.x), R(-30, 0));
                    drops[i].speed = R(400.0f, 800.0f);
                    drops[i].length = R(8.0f, 20.0f);
                    drops[i].alpha = R(0.2f, 0.5f);
                    drops[i].active = true;
                    activeCount++;
                }
            }
        }
        for (int i = 0; i < MAX_DROPS; i++) {
            if (!drops[i].active) continue;
            Drop& d = drops[i];
            d.pos.x += R(-5.0f, 5.0f) * dt;
            d.pos.y += d.speed * dt;
            if (d.pos.y > area.y + 20) d.active = false;
        }
    }

    void Render(ImDrawList* dl) {
        for (int i = 0; i < MAX_DROPS; i++) {
            if (!drops[i].active) continue;
            Drop& d = drops[i];
            ImColor col = ImColor(180, 200, 255, (int)(d.alpha * 255));
            dl->AddLine(
                d.pos,
                ImVec2(d.pos.x, d.pos.y - d.length),
                C(col), 1.0f
            );
        }
    }

    void Clear() {
        for (int i = 0; i < MAX_DROPS; i++) drops[i].active = false;
    }
};

class FireworkSystem {
    static const int MAX_ROCKETS = 5;
    static const int MAX_BURST = 100;
    struct Rocket {
        ImVec2 pos, vel;
        float life;
        bool active;
        ImColor color;
    };
    struct BurstParticle {
        ImVec2 pos, vel;
        float life, maxLife;
        float size;
        ImColor color;
        bool active;
    };
    Rocket rockets[MAX_ROCKETS];
    BurstParticle bursts[MAX_BURST];
    float timer;
public:
    FireworkSystem() {
        for (int i = 0; i < MAX_ROCKETS; i++) rockets[i].active = false;
        for (int i = 0; i < MAX_BURST; i++) bursts[i].active = false;
        timer = 0;
    }

    void LaunchRocket(ImVec2 start, ImVec2 target, ImColor color) {
        for (int i = 0; i < MAX_ROCKETS; i++) {
            if (!rockets[i].active) {
                rockets[i].pos = start;
                float dx = target.x - start.x;
                float dy = target.y - start.y;
                float dist = ImSqrt(dx * dx + dy * dy);
                if (dist < 1) dist = 1;
                rockets[i].vel = ImVec2(dx / dist * 300.0f, dy / dist * 300.0f);
                rockets[i].life = dist / 300.0f;
                rockets[i].color = color;
                rockets[i].active = true;
                return;
            }
        }
    }

    void Explode(ImVec2 pos, ImColor color) {
        for (int i = 0; i < MAX_BURST; i++) {
            if (!bursts[i].active) {
                float angle = R(0, IM_PI * 2.0f);
                float speed = R(50.0f, 200.0f);
                bursts[i].pos = pos;
                bursts[i].vel = ImVec2(cosf(angle) * speed, sinf(angle) * speed);
                bursts[i].life = R(0.5f, 1.5f);
                bursts[i].maxLife = bursts[i].life;
                bursts[i].size = R(2.0f, 5.0f);
                ImColor c = color;
                c.Value.x += R(-0.2f, 0.2f);
                c.Value.y += R(-0.2f, 0.2f);
                c.Value.z += R(-0.2f, 0.2f);
                bursts[i].color = c;
                bursts[i].active = true;
            }
        }
    }

    void Update(float dt) {
        timer += dt;
        if (timer > 1.5f) {
            timer = 0;
            ImColor colors[] = {ImColor(255,50,50), ImColor(50,255,50), ImColor(50,50,255), ImColor(255,255,50)};
            LaunchRocket(
                ImVec2(R(50, 350), 300),
                ImVec2(R(80, 320), R(50, 150)),
                colors[rand() % 4]
            );
        }
        for (int i = 0; i < MAX_ROCKETS; i++) {
            if (!rockets[i].active) continue;
            Rocket& r = rockets[i];
            r.pos.x += r.vel.x * dt;
            r.pos.y += r.vel.y * dt;
            r.life -= dt;
            if (r.life <= 0.3f) {
                if (r.life + dt > 0.3f) Explode(r.pos, r.color);
            }
            if (r.life <= 0) r.active = false;
        }
        for (int i = 0; i < MAX_BURST; i++) {
            if (!bursts[i].active) continue;
            BurstParticle& b = bursts[i];
            b.vel.y += 30.0f * dt;
            b.pos.x += b.vel.x * dt;
            b.pos.y += b.vel.y * dt;
            b.life -= dt;
            if (b.life <= 0) { b.active = false; continue; }
            float t = 1.0f - b.life / b.maxLife;
            b.size = 5.0f * (1.0f - t * 0.8f);
            b.color.Value.w = (1.0f - t);
        }
    }

    void Render(ImDrawList* dl) {
        for (int i = 0; i < MAX_ROCKETS; i++) {
            if (!rockets[i].active) continue;
            Rocket& r = rockets[i];
            dl->AddCircleFilled(r.pos, 2.0f, C(r.color), 8);
            ImColor trail = r.color;
            trail.Value.w = 0.3f;
            dl->AddCircleFilled(r.pos, 4.0f, C(trail), 8);
        }
        for (int i = 0; i < MAX_BURST; i++) {
            if (!bursts[i].active) continue;
            BurstParticle& b = bursts[i];
            ImU32 col = C(b.color);
            dl->AddCircleFilled(b.pos, b.size, col, 12);
            if (b.color.Value.w > 0.3f) {
                ImColor glow = b.color;
                glow.Value.w *= 0.3f;
                dl->AddCircleFilled(b.pos, b.size * 2.5f, C(glow), 12);
            }
        }
    }

    void Clear() {
        for (int i = 0; i < MAX_ROCKETS; i++) rockets[i].active = false;
        for (int i = 0; i < MAX_BURST; i++) bursts[i].active = false;
    }
};

static ParticleSystem gParticleSys;
static SparkSystem gSparkSys;
static ConfettiSystem gConfettiSys;
static TextParticleSystem gTextSys;
static TrailSystem gTrailSys;
static SnowSystem gSnowSys;
static RainSystem gRainSys;
static FireworkSystem gFireworkSys;

void EmitConfetti(ImDrawList* dl, ImVec2 pos, int count, ImColor color) {
    static ParticleSystem confetti;
    confetti.SetEmitter(ImVec2(pos.x - 10, pos.y - 10), ImVec2(20, 20));
    confetti.Emit(count, color, 50.0f, 150.0f, 3.0f, 8.0f, 2.0f);
    confetti.Update(ImGui::GetIO().DeltaTime);
    confetti.Render(dl);
}

void EmitExplosion(ImDrawList* dl, ImVec2 pos, int count, ImColor color) {
    static ParticleSystem explosion;
    explosion.SetEmitter(ImVec2(pos.x - 2, pos.y - 2), ImVec2(4, 4));
    explosion.Emit(count, color, 100.0f, 300.0f, 2.0f, 6.0f, 0.8f);
    explosion.Update(ImGui::GetIO().DeltaTime);
    explosion.Render(dl);
}

void EmitFloatingText(ImDrawList* dl, ImVec2 pos, const char* text, ImColor color) {
    static TextParticleSystem ftp;
    ftp.EmitText(pos, text, color);
    ftp.Update(ImGui::GetIO().DeltaTime);
    ftp.Render(dl);
}

void EmitSparkBurst(ImDrawList* dl, ImVec2 pos, int count, ImColor color) {
    static SparkSystem ss;
    ss.Emit(count, pos, color);
    ss.Update(ImGui::GetIO().DeltaTime);
    ss.Render(dl);
}

void EmitSnow(ImDrawList* dl, ImVec2 area) {
    gSnowSys.SetArea(area);
    gSnowSys.Update(ImGui::GetIO().DeltaTime);
    gSnowSys.Render(dl);
}

void EmitRain(ImDrawList* dl, ImVec2 area) {
    gRainSys.SetArea(area);
    gRainSys.Update(ImGui::GetIO().DeltaTime);
    gRainSys.Render(dl);
}

void UpdateFireworks(ImDrawList* dl) {
    gFireworkSys.Update(ImGui::GetIO().DeltaTime);
    gFireworkSys.Render(dl);
}

void UpdateTrail(ImVec2 pos) {
    gTrailSys.AddPoint(pos);
    gTrailSys.Update(ImGui::GetIO().DeltaTime);
}

void RenderTrail(ImDrawList* dl) {
    gTrailSys.Render(dl);
}

void RenderParticles(ImDrawList* dl) {
    gParticleSys.Update(ImGui::GetIO().DeltaTime);
    gParticleSys.Render(dl);
}

void EmitParticles(int count, ImColor color, ImVec2 pos, ImVec2 size, float minSpeed, float maxSpeed, float minSize, float maxSize, float lifetime) {
    gParticleSys.SetEmitter(pos, size);
    gParticleSys.Emit(count, color, minSpeed, maxSpeed, minSize, maxSize, lifetime);
}

void RenderConfettiSystem(ImDrawList* dl) {
    gConfettiSys.Update(ImGui::GetIO().DeltaTime);
    gConfettiSys.Render(dl);
}

void EmitConfettiSystem(ImVec2 pos, ImVec2 area) {
    gConfettiSys.Emit(5, pos, area);
}

void RenderTextParticles(ImDrawList* dl) {
    gTextSys.Update(ImGui::GetIO().DeltaTime);
    gTextSys.Render(dl);
}

void EmitTextParticles(ImVec2 pos, const char* text, ImColor color) {
    gTextSys.EmitText(pos, text, color);
}

void RenderSparks(ImDrawList* dl) {
    gSparkSys.Update(ImGui::GetIO().DeltaTime);
    gSparkSys.Render(dl);
}

void ClearAllParticleSystems() {
    gParticleSys.Clear();
    gSparkSys.Clear();
    gConfettiSys.Clear();
    gTextSys.Clear();
    gTrailSys.Clear();
    gSnowSys.Clear();
    gRainSys.Clear();
    gFireworkSys.Clear();
}
