#pragma once
#include "Config.h"
#include "GameOffsets.h"
#include "MemoryIO.h"
#include "MathUtils.h"
#include <atomic>

struct AimbotTarget {
    int Index;
    float Distance;
    float FOV;
    D3DVector Position;
    D3DVector Head;
    float Health;
    bool IsVisible;
    int TeamID;
    uintptr_t Address;
    uintptr_t BoneAddress;
};

class Aimbot {
public:
    MemoryIO* Mem;
    GameOffsets* Offsets;
    Config* Cfg;
    Toggles* Tog;
    std::atomic<bool> IsLocked;
    AimbotTarget BestTarget;
    D3DVector CameraPos;
    float CurrentPitch, CurrentYaw;
    float LastPitch, LastYaw;
    std::atomic<int> LocalPlayerIndex;

    Aimbot(MemoryIO* mem, GameOffsets* offsets, Config* cfg, Toggles* tog);

    void Update();
    void FindTarget();
    void AimAtTarget();
    void ReleaseTarget();
    void PredictTarget(D3DVector& pos, D3DVector vel, float time);
    void SmoothAim(float& pitch, float& yaw, float smoothFactor);
    void Triggerbot();

    bool WorldToScreen2(float* matrix, D3DVector world, float* sx, float* sy);
    bool IsValidTarget(AimbotTarget& t);
    void AutoFire();
    void UpdateCameraAngles();
    void SetCameraAngles(float pitch, float yaw);
    void NormalizeAngles(float& pitch, float& yaw);
    float GetAngularFOV(float pitch, float yaw, AimbotTarget& t);
};

extern Aimbot g_Bot;
