#pragma once
#include <imgui.h>

inline ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }

ImColor hsvToRgb(float h, float s, float v);
ImColor lerpCol(const ImColor& a, const ImColor& b, float t);
float clampF(float v, float lo, float hi);
void drawCardGlow(ImDrawList* dl, ImVec2 pos, float w, float h, ImColor accent, float intensity);
void drawSectionBar(ImDrawList* dl, ImVec2 pos, float w, ImColor accent);
void drawActivePulse(ImDrawList* dl, ImVec2 pos, float w, ImColor accent, float phase, float height);
