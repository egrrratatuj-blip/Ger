#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "../../../imgui/imgui.h"
#include "../../../imgui/imgui_internal.h"
#include <stdlib.h>
#include <math.h>
static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }
static float R(float min, float max) { return min + (float)rand() / (float)RAND_MAX * (max - min); }
static float Lerp(float a, float b, float t) { return a + (b - a) * t; }

ImColor SampleGradient(const ImColor* stops, int numStops, float t) {
    if (numStops <= 0) return ImColor(0, 0, 0, 0);
    if (numStops == 1) return stops[0];
    t = ImClamp(t, 0.0f, 1.0f);
    float seg = 1.0f / (float)(numStops - 1);
    int idx = (int)(t / seg);
    if (idx >= numStops - 1) return stops[numStops - 1];
    float localT = (t - (float)idx * seg) / seg;
    const ImColor& a = stops[idx];
    const ImColor& b = stops[idx + 1];
    return ImColor(
        Lerp(a.Value.x, b.Value.x, localT),
        Lerp(a.Value.y, b.Value.y, localT),
        Lerp(a.Value.z, b.Value.z, localT),
        Lerp(a.Value.w, b.Value.w, localT)
    );
}

void DrawGradientRect(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor topLeft, ImColor topRight, ImColor bottomLeft, ImColor bottomRight, float rounding) {
    if (rounding > 0.5f) {
        int steps = 16;
        float h = p2.y - p1.y;
        for (int i = 0; i < steps; i++) {
            float t0 = (float)i / (float)steps;
            float t1 = (float)(i + 1) / (float)steps;
            float y0 = p1.y + h * t0;
            float y1 = p1.y + h * t1;
            ImColor c0 = ImColor(
                Lerp(topLeft.Value.x, bottomLeft.Value.x, t0),
                Lerp(topLeft.Value.y, bottomLeft.Value.y, t0),
                Lerp(topLeft.Value.z, bottomLeft.Value.z, t0),
                Lerp(topLeft.Value.w, bottomLeft.Value.w, t0)
            );
            ImColor c1 = ImColor(
                Lerp(topRight.Value.x, bottomRight.Value.x, t0),
                Lerp(topRight.Value.y, bottomRight.Value.y, t0),
                Lerp(topRight.Value.z, bottomRight.Value.z, t0),
                Lerp(topRight.Value.w, bottomRight.Value.w, t0)
            );
            ImVec2 rp1 = ImVec2(p1.x, y0);
            ImVec2 rp2 = ImVec2(p2.x, y1);
            dl->AddRectFilledMultiColor(rp1, rp2, C(c0), C(c1), C(c1), C(c0));
        }
    } else {
        dl->AddRectFilledMultiColor(p1, p2, C(topLeft), C(topRight), C(bottomRight), C(bottomLeft));
    }
}

void DrawGradientLine(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor colA, ImColor colB, float thickness) {
    ImVec2 dir = ImVec2(p2.x - p1.x, p2.y - p1.y);
    float len = ImSqrt(dir.x * dir.x + dir.y * dir.y);
    if (len < 1.0f) return;
    dir.x /= len; dir.y /= len;
    ImVec2 perp = ImVec2(-dir.y, dir.x);
    int steps = 8;
    for (int i = 0; i < steps; i++) {
        float t0 = (float)i / (float)steps;
        float t1 = (float)(i + 1) / (float)steps;
        ImVec2 segP1 = ImVec2(p1.x + dir.x * t0 * len, p1.y + dir.y * t0 * len);
        ImVec2 segP2 = ImVec2(p1.x + dir.x * t1 * len, p1.y + dir.y * t1 * len);
        ImColor c = ImColor(
            Lerp(colA.Value.x, colB.Value.x, t0),
            Lerp(colA.Value.y, colB.Value.y, t0),
            Lerp(colA.Value.z, colB.Value.z, t0),
            Lerp(colA.Value.w, colB.Value.w, t0)
        );
        ImVec2 sp1 = ImVec2(segP1.x - perp.x * thickness * 0.5f, segP1.y - perp.y * thickness * 0.5f);
        ImVec2 sp2 = ImVec2(segP2.x - perp.x * thickness * 0.5f, segP2.y - perp.y * thickness * 0.5f);
        ImVec2 sp3 = ImVec2(segP2.x + perp.x * thickness * 0.5f, segP2.y + perp.y * thickness * 0.5f);
        ImVec2 sp4 = ImVec2(segP1.x + perp.x * thickness * 0.5f, segP1.y + perp.y * thickness * 0.5f);
        dl->AddQuadFilled(sp1, sp2, sp3, sp4, C(c));
    }
}

void DrawGradientCircle(ImDrawList* dl, ImVec2 center, float radius, ImColor inner, ImColor outer, int segments) {
    int rings = 8;
    float ringStep = radius / (float)rings;
    for (int r = 0; r < rings; r++) {
        float rt0 = (float)r / (float)rings;
        float rt1 = (float)(r + 1) / (float)rings;
        float rr0 = ringStep * (float)r;
        float rr1 = ringStep * (float)(r + 1);
        ImColor c = ImColor(
            Lerp(inner.Value.x, outer.Value.x, rt0),
            Lerp(inner.Value.y, outer.Value.y, rt0),
            Lerp(inner.Value.z, outer.Value.z, rt0),
            Lerp(inner.Value.w, outer.Value.w, rt0)
        );
        for (int i = 0; i < segments; i++) {
            float a0 = (float)i * IM_PI * 2.0f / (float)segments;
            float a1 = (float)(i + 1) * IM_PI * 2.0f / (float)segments;
            ImVec2 p0 = ImVec2(center.x + cosf(a0) * rr0, center.y + sinf(a0) * rr0);
            ImVec2 p1 = ImVec2(center.x + cosf(a1) * rr0, center.y + sinf(a1) * rr0);
            ImVec2 p2 = ImVec2(center.x + cosf(a1) * rr1, center.y + sinf(a1) * rr1);
            ImVec2 p3 = ImVec2(center.x + cosf(a0) * rr1, center.y + sinf(a0) * rr1);
            dl->AddQuadFilled(p0, p1, p2, p3, C(c));
        }
    }
}

void DrawGradientBorder(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor colA, ImColor colB, float radius, float thickness, float rounding) {
    int steps = 16;
    float offset = thickness * 0.5f;
    ImVec2 outerP1 = ImVec2(p1.x - offset, p1.y - offset);
    ImVec2 outerP2 = ImVec2(p2.x + offset, p2.y + offset);
    ImVec2 innerP1 = ImVec2(p1.x + offset, p1.y + offset);
    ImVec2 innerP2 = ImVec2(p2.x - offset, p2.y - offset);
    for (int i = 0; i < steps; i++) {
        float t0 = (float)i / (float)steps;
        float t1 = (float)(i + 1) / (float)steps;
        float y0 = outerP1.y + (outerP2.y - outerP1.y) * t0;
        float y1 = outerP1.y + (outerP2.y - outerP1.y) * t1;
        ImColor c0 = ImColor(
            Lerp(colA.Value.x, colB.Value.x, t0),
            Lerp(colA.Value.y, colB.Value.y, t0),
            Lerp(colA.Value.z, colB.Value.z, t0),
            Lerp(colA.Value.w, colB.Value.w, t0)
        );
        ImVec2 rp1 = ImVec2(outerP1.x, y0);
        ImVec2 rp2 = ImVec2(outerP2.x, y0);
        ImVec2 rp3 = ImVec2(outerP2.x, y1);
        ImVec2 rp4 = ImVec2(outerP1.x, y1);
        dl->AddQuadFilled(rp1, rp2, rp3, rp4, C(c0));
        ImVec2 ip1 = ImVec2(innerP1.x, y0);
        ImVec2 ip2 = ImVec2(innerP2.x, y0);
        ImVec2 ip3 = ImVec2(innerP2.x, y1);
        ImVec2 ip4 = ImVec2(innerP1.x, y1);
        dl->AddQuadFilled(ip1, ip2, ip3, ip4, C(ImColor(0,0,0,255)));
    }
}

void FillWithNoise(ImDrawList* dl, ImVec2 p1, ImVec2 p2, float alpha, float scale) {
    float x = p1.x;
    while (x < p2.x) {
        float y = p1.y;
        while (y < p2.y) {
            if ((rand() % 100) < 10) {
                float val = (float)rand() / (float)RAND_MAX;
                ImColor col = ImColor(val, val, val, alpha);
                dl->AddRectFilled(
                    ImVec2(x, y),
                    ImVec2(x + scale, y + scale),
                    C(col)
                );
            }
            y += scale;
        }
        x += scale;
    }
}

void DrawVignette(ImDrawList* dl, ImVec2 screenSize, float intensity) {
    ImVec2 center = ImVec2(screenSize.x * 0.5f, screenSize.y * 0.5f);
    float maxDist = ImSqrt(center.x * center.x + center.y * center.y);
    int steps = 12;
    for (int i = 0; i < steps; i++) {
        float t0 = (float)i / (float)steps;
        float t1 = (float)(i + 1) / (float)steps;
        float r0 = maxDist * t0;
        float r1 = maxDist * t1;
        float alpha0 = t0 * t0 * intensity;
        float alpha1 = t1 * t1 * intensity;
        ImColor c0 = ImColor(0, 0, 0, ImClamp(alpha0, 0.0f, 1.0f));
        ImColor c1 = ImColor(0, 0, 0, ImClamp(alpha1, 0.0f, 1.0f));
        int seg = 32;
        for (int j = 0; j < seg; j++) {
            float a0 = (float)j * IM_PI * 2.0f / (float)seg;
            float a1 = (float)(j + 1) * IM_PI * 2.0f / (float)seg;
            ImVec2 p0 = ImVec2(center.x + cosf(a0) * r0, center.y + sinf(a0) * r0);
            ImVec2 p1v = ImVec2(center.x + cosf(a1) * r0, center.y + sinf(a1) * r0);
            ImVec2 p2v = ImVec2(center.x + cosf(a1) * r1, center.y + sinf(a1) * r1);
            ImVec2 p3v = ImVec2(center.x + cosf(a0) * r1, center.y + sinf(a0) * r1);
            dl->AddQuadFilled(p0, p3v, p2v, p1v, C(c0));
        }
    }
}

void DrawLensFlares(ImDrawList* dl, ImVec2 center, ImColor color, int count) {
    float time = ImGui::GetTime();
    for (int i = 0; i < count; i++) {
        float angle = time * 0.5f + (float)i * IM_PI * 2.0f / (float)count;
        float dist = 30.0f + (float)i * 25.0f;
        ImVec2 flarePos = ImVec2(
            center.x + cosf(angle) * dist,
            center.y + sinf(angle) * dist
        );
        float size = 15.0f - (float)i * 2.0f;
        float a = color.Value.w * (1.0f - (float)i / (float)count * 0.7f);
        ImColor c = color;
        c.Value.w = a;
        dl->AddCircleFilled(flarePos, size, C(c), 16);
        for (int j = 0; j < 3; j++) {
            float a2 = angle + IM_PI + (float)(j - 1) * 0.3f;
            float d2 = dist + 8.0f + (float)j * 6.0f;
            ImVec2 ghostPos = ImVec2(
                center.x + cosf(a2) * d2,
                center.y + sinf(a2) * d2
            );
            float gs = size * 0.3f;
            float ga = a * 0.3f;
            ImColor gc = color;
            gc.Value.w = ga;
            dl->AddCircleFilled(ghostPos, gs, C(gc), 12);
        }
        dl->AddLine(
            center,
            ImVec2(
                center.x + cosf(angle) * dist * 1.5f,
                center.y + sinf(angle) * dist * 1.5f
            ),
            C(ImColor(255, 255, 255, (int)(a * 40.0f))),
            1.0f
        );
    }
}

void DrawGradientRectH(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor left, ImColor right, float rounding) {
    int steps = 20;
    float w = p2.x - p1.x;
    for (int i = 0; i < steps; i++) {
        float t0 = (float)i / (float)steps;
        float t1 = (float)(i + 1) / (float)steps;
        float x0 = p1.x + w * t0;
        float x1 = p1.x + w * t1;
        ImColor c = ImColor(
            Lerp(left.Value.x, right.Value.x, t0),
            Lerp(left.Value.y, right.Value.y, t0),
            Lerp(left.Value.z, right.Value.z, t0),
            Lerp(left.Value.w, right.Value.w, t0)
        );
        dl->AddRectFilled(ImVec2(x0, p1.y), ImVec2(x1, p2.y), C(c), rounding);
    }
}

void DrawGradientRectV(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor top, ImColor bottom, float rounding) {
    int steps = 20;
    float h = p2.y - p1.y;
    for (int i = 0; i < steps; i++) {
        float t0 = (float)i / (float)steps;
        float t1 = (float)(i + 1) / (float)steps;
        float y0 = p1.y + h * t0;
        float y1 = p1.y + h * t1;
        ImColor c = ImColor(
            Lerp(top.Value.x, bottom.Value.x, t0),
            Lerp(top.Value.y, bottom.Value.y, t0),
            Lerp(top.Value.z, bottom.Value.z, t0),
            Lerp(top.Value.w, bottom.Value.w, t0)
        );
        dl->AddRectFilled(ImVec2(p1.x, y0), ImVec2(p2.x, y1), C(c), rounding);
    }
}

void DrawGradientAngle(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImColor colA, ImColor colB, float angleDeg, float rounding) {
    float rad = angleDeg * IM_PI / 180.0f;
    ImVec2 center = ImVec2((p1.x + p2.x) * 0.5f, (p1.y + p2.y) * 0.5f);
    int steps = 24;
    float halfW = (p2.x - p1.x) * 0.5f;
    float halfH = (p2.y - p1.y) * 0.5f;
    for (int i = 0; i < steps; i++) {
        float t0 = (float)i / (float)steps;
        float t1 = (float)(i + 1) / (float)steps;
        float proj0 = (t0 - 0.5f) * 2.0f * ImSqrt(halfW * halfW + halfH * halfH);
        float proj1 = (t1 - 0.5f) * 2.0f * ImSqrt(halfW * halfW + halfH * halfH);
        ImVec2 dir = ImVec2(cosf(rad), sinf(rad));
        ImVec2 perp = ImVec2(-dir.y, dir.x);
        ImVec2 lp0 = ImVec2(center.x + dir.x * proj0, center.y + dir.y * proj0);
        ImVec2 lp1 = ImVec2(center.x + dir.x * proj1, center.y + dir.y * proj1);
        ImVec2 c0 = ImColor(
            Lerp(colA.Value.x, colB.Value.x, t0),
            Lerp(colA.Value.y, colB.Value.y, t0),
            Lerp(colA.Value.z, colB.Value.z, t0),
            Lerp(colA.Value.w, colB.Value.w, t0)
        );
        float maxExt = ImSqrt(halfW * halfW + halfH * halfH);
        ImVec2 corners[4] = {
            ImVec2(lp0.x - perp.x * maxExt, lp0.y - perp.y * maxExt),
            ImVec2(lp1.x - perp.x * maxExt, lp1.y - perp.y * maxExt),
            ImVec2(lp1.x + perp.x * maxExt, lp1.y + perp.y * maxExt),
            ImVec2(lp0.x + perp.x * maxExt, lp0.y + perp.y * maxExt)
        };
        dl->AddQuadFilled(corners[0], corners[1], corners[2], corners[3], C(c0));
    }
}

void DrawGradientMultiStop(ImDrawList* dl, ImVec2 p1, ImVec2 p2, const ImColor* stops, int numStops, bool horizontal, float rounding) {
    int steps = (numStops - 1) * 8;
    for (int i = 0; i < steps; i++) {
        float t0 = (float)i / (float)steps;
        float t1 = (float)(i + 1) / (float)steps;
        ImColor c0 = SampleGradient(stops, numStops, t0);
        ImColor c1 = SampleGradient(stops, numStops, t1);
        if (horizontal) {
            float x0 = p1.x + (p2.x - p1.x) * t0;
            float x1 = p1.x + (p2.x - p1.x) * t1;
            dl->AddRectFilled(ImVec2(x0, p1.y), ImVec2(x1, p2.y), C(c0), rounding);
        } else {
            float y0 = p1.y + (p2.y - p1.y) * t0;
            float y1 = p1.y + (p2.y - p1.y) * t1;
            dl->AddRectFilled(ImVec2(p1.x, y0), ImVec2(p2.x, y1), C(c0), rounding);
        }
    }
}

void DrawCheckerboard(ImDrawList* dl, ImVec2 p1, ImVec2 p2, float tileSize, ImColor colA, ImColor colB) {
    float x = p1.x;
    int row = 0;
    while (x < p2.x) {
        float y = p1.y;
        int col = 0;
        while (y < p2.y) {
            ImColor c = ((row + col) % 2 == 0) ? colA : colB;
            dl->AddRectFilled(
                ImVec2(x, y),
                ImVec2(ImMin(x + tileSize, p2.x), ImMin(y + tileSize, p2.y)),
                C(c)
            );
            y += tileSize;
            col++;
        }
        x += tileSize;
        row++;
    }
}

void DrawRadialBurst(ImDrawList* dl, ImVec2 center, float radius, ImColor inner, ImColor outer, int spikes) {
    for (int i = 0; i < spikes; i++) {
        float a0 = (float)i * IM_PI * 2.0f / (float)spikes;
        float a1 = (float)(i + 1) * IM_PI * 2.0f / (float)spikes;
        float aMid = (a0 + a1) * 0.5f;
        float r0 = radius * 0.1f;
        float r1 = radius;
        ImVec2 tip = ImVec2(center.x + cosf(aMid) * radius, center.y + sinf(aMid) * radius);
        ImVec2 b0 = ImVec2(center.x + cosf(a0) * r0, center.y + sinf(a0) * r0);
        ImVec2 b1 = ImVec2(center.x + cosf(a1) * r0, center.y + sinf(a1) * r0);
        ImVec2 e0 = ImVec2(center.x + cosf(a0) * r1, center.y + sinf(a0) * r1);
        ImVec2 e1 = ImVec2(center.x + cosf(a1) * r1, center.y + sinf(a1) * r1);
        ImColor c = ImColor(
            Lerp(inner.Value.x, outer.Value.x, (float)i / (float)spikes),
            Lerp(inner.Value.y, outer.Value.y, (float)i / (float)spikes),
            Lerp(inner.Value.z, outer.Value.z, (float)i / (float)spikes),
            Lerp(inner.Value.w, outer.Value.w, (float)i / (float)spikes)
        );
        dl->AddTriangleFilled(b0, e0, tip, C(c));
        dl->AddTriangleFilled(b1, tip, e1, C(c));
    }
}

void DrawSunburst(ImDrawList* dl, ImVec2 center, float innerRadius, float outerRadius, ImColor inner, ImColor outer, int rays) {
    for (int i = 0; i < rays; i++) {
        float a0 = (float)i * IM_PI * 2.0f / (float)rays;
        float a1 = (float)(i + 1) * IM_PI * 2.0f / (float)rays;
        float aMid = (a0 + a1) * 0.5f;
        float t = (float)i / (float)rays;
        ImColor c = ImColor(
            Lerp(inner.Value.x, outer.Value.x, t),
            Lerp(inner.Value.y, outer.Value.y, t),
            Lerp(inner.Value.z, outer.Value.z, t),
            Lerp(inner.Value.w, outer.Value.w, t)
        );
        ImVec2 pInner0 = ImVec2(center.x + cosf(a0) * innerRadius, center.y + sinf(a0) * innerRadius);
        ImVec2 pInner1 = ImVec2(center.x + cosf(a1) * innerRadius, center.y + sinf(a1) * innerRadius);
        ImVec2 pOuter = ImVec2(center.x + cosf(aMid) * outerRadius, center.y + sinf(aMid) * outerRadius);
        dl->AddTriangleFilled(pInner0, pInner1, pOuter, C(c));
    }
}
