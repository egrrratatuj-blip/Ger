#pragma once
#include "Config.h"
#include "MemoryIO.h"
#include "GameOffsets.h"
#include "Aimbot.h"
#include "MathUtils.h"
#include <vector>
#include <mutex>
#include <imgui.h>

static const BoneJoint g_SkeletonJoints[] = {
    {0,1},{1,2},{2,3},{3,4},{2,5},{5,6},{6,7},
    {2,8},{8,9},{9,10},{0,11},{11,12},{12,13},{0,14},{14,15},{15,16}
};
static const int g_SkeletonJointCount = sizeof(g_SkeletonJoints)/sizeof(g_SkeletonJoints[0]);

class ESP {
public:
    MemoryIO *Mem;
    GameOffsets *Offsets;
    Config *Cfg;
    Toggles *Tog;
    Aimbot *Bot;
    std::vector<PlayerData> Players;
    int PlayerCount;
    uint32_t lastToggleHash;
    std::mutex playersMutex;

    ESP(MemoryIO *mem, GameOffsets *offsets, Config *cfg, Toggles *tog, Aimbot *bot);
    void UpdatePlayers();
    void Render(ImDrawList *draw);

private:
    bool WorldToScreen(D3DVector world, float *screenX, float *screenY);
    void DrawPlayerBox(ImDrawList *draw, PlayerData &p, float sx, float sy);
    void DrawSkeleton(ImDrawList *draw, uintptr_t boneAddr);
    void DrawCrosshair(ImDrawList *draw);
    void DrawWatermark(ImDrawList *draw);
    void DrawAimbotFOV(ImDrawList *draw);
    void DrawAimbotTarget(ImDrawList *draw);
    void DrawRadar(ImDrawList *draw);
    void DrawHealthBar(ImDrawList *draw, float x, float y, float w, float h, float health, float maxHealth);
    ImColor GetPlayerColor(const PlayerData &p);
};
