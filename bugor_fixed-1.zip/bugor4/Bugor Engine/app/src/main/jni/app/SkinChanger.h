#pragma once
#include "Config.h"
#include "GameOffsets.h"
#include "MemoryIO.h"
#include <string>
#include <vector>
#include <map>

struct SkinEntry {
    int ID;
    std::string Name;
    std::string Category;
    uintptr_t Address;
    int SkinID;
    int Quality;
    float Wear;
    int Seed;
    bool Applied;
};

class SkinChanger {
    MemoryIO* Mem;
    GameOffsets* Offsets;
    Toggles* Tog;
    Config* Cfg;

    std::vector<SkinEntry> skins;
    int selectedSkin;

    uintptr_t FindWeaponSlot(int slot);
    uintptr_t FindCharacterMesh();
    bool WriteSkinID(uintptr_t addr, int skinID);
    bool WriteSkinWear(uintptr_t addr, float wear);
    bool WriteSkinSeed(uintptr_t addr, int seed);

public:
    SkinChanger(MemoryIO* mem, GameOffsets* offsets, Config* cfg, Toggles* tog);

    void Update();
    void ApplySkin(int index);
    void ApplyAllSkins();
    void ResetSkins();
    void RefreshSkinList();

    std::vector<SkinEntry>& GetSkins() { return skins; }
    int GetSelectedSkin() { return selectedSkin; }
    void SetSelectedSkin(int idx) { if (idx >= 0 && idx < (int)skins.size()) selectedSkin = idx; }
};

extern SkinChanger g_Skin;
