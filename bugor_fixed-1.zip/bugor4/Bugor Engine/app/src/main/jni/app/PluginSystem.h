#pragma once
#include <string>
#include <vector>
#include <map>
#include <memory>
#include <functional>
#include <atomic>
#include <mutex>
#include <shared_mutex>
#include <thread>
#include <chrono>
#include <cstdint>
#include <dlfcn.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <filesystem>

namespace BugorPlugins {

struct PluginInfo {
    std::string name;
    std::string version;
    std::string author;
    std::string description;
    std::string path;
    std::string entryPoint;
    uint32_t apiVersion;
    uint32_t pluginId;
    uint64_t loadTime;
    uint64_t initTime;
    bool isSystem;
    bool isSandboxed;
    bool hasUI;
    bool hasConfig;
    bool hasHooks;
    bool hasNetwork;
    std::vector<std::string> dependencies;
    std::vector<std::string> permissions;
    std::map<std::string, std::string> metadata;
};

struct PluginStats {
    uint64_t memoryUsage;
    uint64_t cpuTime;
    uint64_t callsExecuted;
    uint64_t errors;
    float uptime;
    float averageLatency;
    size_t hookCount;
    size_t threadCount;
    size_t handleCount;
};

class PluginAPI {
public:
    virtual ~PluginAPI() = default;
    virtual bool onLoad() = 0;
    virtual bool onUnload() = 0;
    virtual bool onEnable() = 0;
    virtual bool onDisable() = 0;
    virtual void onUpdate(float deltaTime) = 0;
    virtual void onRender() = 0;
    virtual void onConfigLoad(const std::string &config) = 0;
    virtual std::string onConfigSave() = 0;
    virtual void onEvent(const std::string &event, void *data) = 0;
    virtual void onKeyEvent(int key, bool down) = 0;
    virtual void onMouseEvent(int button, bool down, float x, float y) = 0;
    virtual void onTouchEvent(int id, int action, float x, float y) = 0;
    virtual void onPacket(const uint8_t *data, size_t size, bool outgoing) = 0;
    virtual void onTargetFound(void *target) = 0;
    virtual void onTargetLost() = 0;
    virtual void onShot() = 0;
    virtual void onDamage(float damage, uintptr_t source) = 0;
    virtual void onKill(uintptr_t target) = 0;
    virtual void onDeath(uintptr_t killer) = 0;
    virtual void onGameStart() = 0;
    virtual void onGameEnd() = 0;
    virtual void onMapChange(const std::string &map) = 0;
    virtual void onTeamChange(int newTeam) = 0;
    virtual void onWeaponSwitch(const std::string &weapon) = 0;
    virtual void onRespawn() = 0;
    virtual void onLevelUp(int level) = 0;
    virtual void onAchievement(const std::string &achievement) = 0;
    virtual void onError(const std::string &error) = 0;
    virtual void* getFunction(const std::string &name) = 0;
    virtual bool registerHook(const std::string &name, void *hookFunc, void **original) = 0;
    virtual bool unregisterHook(const std::string &name) = 0;
    virtual bool sendMessage(const std::string &target, const std::string &message) = 0;
    virtual std::string receiveMessage() = 0;
    virtual bool hasPermission(const std::string &permission) = 0;
    virtual std::string getDataPath() = 0;
    virtual std::string getConfigPath() = 0;
    virtual void log(const std::string &message, int level) = 0;
    virtual uint64_t getTime() = 0;
};

using PluginCreateFunc = PluginAPI* (*)();
using PluginDestroyFunc = void (*)(PluginAPI*);

struct PluginHandle {
    void *handle;
    PluginAPI *api;
    PluginCreateFunc createFunc;
    PluginDestroyFunc destroyFunc;
    PluginInfo info;
    PluginStats stats;
    bool loaded;
    bool enabled;
    bool sandboxed;
    std::chrono::steady_clock::time_point loadTime;
};

class PluginManager {
public:
    PluginManager();
    ~PluginManager();
    bool initialize();
    void shutdown();
    bool loadPlugin(const std::string &path);
    bool unloadPlugin(const std::string &name);
    bool unloadPlugin(uint32_t pluginId);
    bool enablePlugin(const std::string &name);
    bool disablePlugin(const std::string &name);
    bool reloadPlugin(const std::string &name);
    bool reloadAllPlugins();
    bool isLoaded(const std::string &name) const;
    bool isEnabled(const std::string &name) const;
    PluginAPI* getPluginAPI(const std::string &name);
    PluginAPI* getPluginAPI(uint32_t pluginId);
    PluginInfo getPluginInfo(const std::string &name) const;
    PluginStats getPluginStats(const std::string &name) const;
    std::vector<PluginInfo> getAllPlugins() const;
    std::vector<PluginInfo> getEnabledPlugins() const;
    std::vector<PluginInfo> getLoadedPlugins() const;
    std::vector<std::string> getPluginNames() const;
    uint32_t getPluginCount() const;
    bool hasPlugin(const std::string &name) const;
    void setPluginDirectory(const std::string &path);
    std::string getPluginDirectory() const;
    void scanForPlugins();
    void updateAll(float deltaTime);
    void renderAll();
    void broadcastEvent(const std::string &event, void *data);
    void broadcastKeyEvent(int key, bool down);
    void broadcastMouseEvent(int button, bool down, float x, float y);
    void broadcastTouchEvent(int id, int action, float x, float y);
    void broadcastPacket(const uint8_t *data, size_t size, bool outgoing);
    void broadcastTargetFound(void *target);
    void broadcastTargetLost();
    void broadcastShot();
    void broadcastDamage(float damage, uintptr_t source);
    void broadcastKill(uintptr_t target);
    void broadcastDeath(uintptr_t killer);
    void broadcastGameStart();
    void broadcastGameEnd();
    void broadcastMapChange(const std::string &map);
    void broadcastWeaponSwitch(const std::string &weapon);
    void setPluginEnabled(const std::string &name, bool enable);
    void setPluginAutoload(const std::string &name, bool autoload);
    bool isPluginAutoload(const std::string &name) const;
    void savePluginConfig();
    void loadPluginConfig();
    std::map<std::string, bool> getPluginStates() const;
    void setPluginStates(const std::map<std::string, bool> &states);
    void addPluginPath(const std::string &path);
    void removePluginPath(const std::string &path);
    std::vector<std::string> getPluginPaths() const;
    void setMaxPlugins(uint32_t max);
    uint32_t getMaxPlugins() const;
    void enableSandboxing(bool enable);
    bool isSandboxingEnabled() const;
    void setPluginTimeout(uint32_t ms);
    uint32_t getPluginTimeout() const;
    void setMemoryLimit(size_t limit);
    size_t getMemoryLimit() const;

private:
    std::vector<std::unique_ptr<PluginHandle>> plugins;
    std::map<std::string, uint32_t> pluginIndex;
    std::vector<std::string> pluginPaths;
    std::string pluginDirectory;
    std::map<std::string, bool> pluginAutoload;
    std::atomic<bool> initialized;
    std::atomic<bool> running;
    uint32_t nextPluginId;
    uint32_t maxPlugins;
    bool sandboxingEnabled;
    uint32_t pluginTimeout;
    size_t memoryLimit;
    mutable std::shared_mutex pluginsMutex;
    std::thread *monitorThread;
    std::mutex monitorMutex;
    std::condition_variable monitorCV;
    PluginHandle* findPlugin(const std::string &name);
    PluginHandle* findPluginById(uint32_t id);
    bool validatePlugin(void *handle);
    bool checkDependencies(const PluginInfo &info);
    bool verifyPluginSignature(const std::string &path);
    void* loadSymbol(void *handle, const char *symbol);
    void monitorLoop();
    void cleanupPlugin(PluginHandle *plugin);
    void terminatePlugin(PluginHandle *plugin);
    bool sandboxPlugin(PluginHandle *plugin);
    void unsandboxPlugin(PluginHandle *plugin);
    std::string resolvePluginPath(const std::string &name);
    bool checkPluginPermissions(const PluginInfo &info);
    void collectPluginStats(PluginHandle *plugin);
    void savePluginState();
    void loadPluginState();
    void autoLoadPlugins();
};

class PluginSandbox {
public:
    PluginSandbox();
    ~PluginSandbox();
    bool createSandbox(PluginHandle *plugin);
    void destroySandbox(PluginHandle *plugin);
    bool isSandboxed(PluginHandle *plugin) const;
    bool restrictSyscalls(PluginHandle *plugin);
    bool restrictMemory(PluginHandle *plugin, size_t limit);
    bool restrictFileAccess(PluginHandle *plugin, const std::vector<std::string> &allowedPaths);
    bool restrictNetwork(PluginHandle *plugin);
    bool setCPULimit(PluginHandle *plugin, float limit);
    bool setTimeLimit(PluginHandle *plugin, uint32_t ms);
    bool monitorPlugin(PluginHandle *plugin);
    bool killPlugin(PluginHandle *plugin);
    void enableSeccomp();
    void disableSeccomp();
    void enableNamespace();
    void disableNamespace();
    void setAllowedCalls(const std::vector<int> &calls);
    std::vector<int> getAllowedCalls() const;

private:
    std::map<uintptr_t, bool> sandboxedPlugins;
    std::vector<int> allowedSyscalls;
    bool seccompEnabled;
    bool namespaceEnabled;
    std::mutex sandboxMutex;
    bool applySeccompFilter();
    bool createNamespace();
    bool setupChroot(const std::string &path);
    bool limitResources(const PluginHandle *plugin);
    void trackSyscalls(const PluginHandle *plugin);
};

class InterPluginCommunicator {
public:
    InterPluginCommunicator();
    ~InterPluginCommunicator();
    bool initialize();
    void shutdown();
    bool sendMessage(const std::string &from, const std::string &to, const std::string &message);
    bool sendMessage(const std::string &from, const std::string &to, const std::vector<uint8_t> &data);
    bool broadcastMessage(const std::string &from, const std::string &message);
    bool broadcastMessage(const std::string &from, const std::vector<uint8_t> &data);
    std::string waitForMessage(const std::string &plugin, uint32_t timeoutMs = 5000);
    bool hasMessage(const std::string &plugin) const;
    void clearMessages(const std::string &plugin);
    void registerHandler(const std::string &plugin, std::function<void(const std::string&, const std::string&)> handler);
    void unregisterHandler(const std::string &plugin);
    struct Message {
        std::string from;
        std::string to;
        std::vector<uint8_t> data;
        std::string text;
        uint64_t timestamp;
    };

private:
    std::map<std::string, std::queue<Message>> messageQueues;
    std::map<std::string, std::function<void(const std::string&, const std::string&)>> handlers;
    mutable std::mutex commMutex;
    std::condition_variable commCV;
    bool initialized;
    void processMessage(const Message &msg);
};

class HotReloader {
public:
    HotReloader();
    ~HotReloader();
    void start(PluginManager *manager);
    void stop();
    void setWatchDirectory(const std::string &path);
    void setPollInterval(uint32_t ms);
    void watchFile(const std::string &path);
    void unwatchFile(const std::string &path);
    bool isWatching() const;
    std::vector<std::string> getChangedFiles() const;
    void clearChanges();

private:
    PluginManager *pluginManager;
    std::vector<std::string> watchPaths;
    std::map<std::string, std::filesystem::file_time_type> fileTimestamps;
    std::atomic<bool> running;
    std::thread *watcherThread;
    uint32_t pollInterval;
    std::string watchDirectory;
    std::mutex watchMutex;
    void watchLoop();
    bool hasFileChanged(const std::string &path);
    void reloadChangedPlugins();
};

}
