#include "PluginSystem.h"
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cstring>
#include <sys/prctl.h>
#include <seccomp.h>
#include <sys/resource.h>
#include <sys/capability.h>
#include <sys/signalfd.h>
#include <poll.h>

namespace BugorPlugins {

PluginManager::PluginManager()
    : initialized(false), running(false), nextPluginId(1),
      maxPlugins(64), sandboxingEnabled(false), pluginTimeout(5000),
      memoryLimit(0x10000000), monitorThread(nullptr) {
    pluginPaths.push_back("/data/data/com.bugor.engine/files/plugins/");
    pluginPaths.push_back("/storage/emulated/0/Bugor/plugins/");
}

PluginManager::~PluginManager() {
    shutdown();
}

bool PluginManager::initialize() {
    if (initialized) return true;
    loadPluginState();
    scanForPlugins();
    autoLoadPlugins();
    initialized = true;
    return true;
}

void PluginManager::shutdown() {
    running = false;
    if (monitorThread && monitorThread->joinable()) {
        monitorCV.notify_all();
        monitorThread->join();
        delete monitorThread;
        monitorThread = nullptr;
    }
    std::unique_lock<std::shared_mutex> lock(pluginsMutex);
    for (auto &plugin : plugins) {
        if (plugin->loaded) {
            if (plugin->enabled) {
                plugin->api->onDisable();
            }
            plugin->api->onUnload();
            if (plugin->destroyFunc) {
                plugin->destroyFunc(plugin->api);
            }
            plugin->api = nullptr;
            if (plugin->handle) {
                dlclose(plugin->handle);
            }
        }
    }
    plugins.clear();
    pluginIndex.clear();
    savePluginState();
    initialized = false;
}

bool PluginManager::loadPlugin(const std::string &path) {
    std::string resolvedPath = resolvePluginPath(path);
    if (resolvedPath.empty()) return false;
    struct stat st;
    if (stat(resolvedPath.c_str(), &st) != 0) return false;
    std::unique_lock<std::shared_mutex> lock(pluginsMutex);
    for (auto &p : plugins) {
        if (p->info.path == resolvedPath) {
            if (!p->loaded) {
                return reloadPlugin(p->info.name);
            }
            return true;
        }
    }
    if (plugins.size() >= maxPlugins) return false;
    auto plugin = std::make_unique<PluginHandle>();
    plugin->handle = dlopen(resolvedPath.c_str(), RTLD_NOW | RTLD_LOCAL);
    if (!plugin->handle) {
        return false;
    }
    if (!validatePlugin(plugin->handle)) {
        dlclose(plugin->handle);
        return false;
    }
    plugin->createFunc = (PluginCreateFunc)dlsym(plugin->handle, "createPlugin");
    plugin->destroyFunc = (PluginDestroyFunc)dlsym(plugin->handle, "destroyPlugin");
    if (!plugin->createFunc || !plugin->destroyFunc) {
        dlclose(plugin->handle);
        return false;
    }
    plugin->info.path = resolvedPath;
    size_t lastSlash = resolvedPath.rfind('/');
    size_t lastDot = resolvedPath.rfind('.');
    if (lastSlash != std::string::npos && lastDot != std::string::npos) {
        plugin->info.name = resolvedPath.substr(lastSlash + 1, lastDot - lastSlash - 1);
    }
    plugin->info.pluginId = nextPluginId++;
    plugin->loadTime = std::chrono::steady_clock::now();
    plugin->loaded = true;
    plugin->enabled = false;
    plugins.push_back(std::move(plugin));
    auto &p = plugins.back();
    p->api = p->createFunc();
    if (!p->api) {
        dlclose(p->handle);
        plugins.pop_back();
        return false;
    }
    if (!checkDependencies(p->info)) {
        p->destroyFunc(p->api);
        dlclose(p->handle);
        plugins.pop_back();
        return false;
    }
    if (sandboxingEnabled) {
        sandboxPlugin(p.get());
    }
    p->api->onLoad();
    pluginIndex[p->info.name] = plugins.size() - 1;
    return true;
}

bool PluginManager::unloadPlugin(const std::string &name) {
    std::unique_lock<std::shared_mutex> lock(pluginsMutex);
    auto *plugin = findPlugin(name);
    if (!plugin || !plugin->loaded) return false;
    if (plugin->enabled) {
        plugin->api->onDisable();
    }
    plugin->api->onUnload();
    cleanupPlugin(plugin);
    for (auto it = plugins.begin(); it != plugins.end(); ++it) {
        if ((*it)->info.name == name) {
            plugins.erase(it);
            break;
        }
    }
    pluginIndex.erase(name);
    return true;
}

bool PluginManager::unloadPlugin(uint32_t pluginId) {
    return false;
}

bool PluginManager::enablePlugin(const std::string &name) {
    std::unique_lock<std::shared_mutex> lock(pluginsMutex);
    auto *plugin = findPlugin(name);
    if (!plugin || !plugin->loaded || plugin->enabled) return false;
    if (plugin->api->onEnable()) {
        plugin->enabled = true;
        savePluginState();
        return true;
    }
    return false;
}

bool PluginManager::disablePlugin(const std::string &name) {
    std::unique_lock<std::shared_mutex> lock(pluginsMutex);
    auto *plugin = findPlugin(name);
    if (!plugin || !plugin->enabled) return false;
    plugin->api->onDisable();
    plugin->enabled = false;
    savePluginState();
    return true;
}

bool PluginManager::reloadPlugin(const std::string &name) {
    std::string path;
    {
        std::shared_lock<std::shared_mutex> lock(pluginsMutex);
        auto *plugin = findPlugin(name);
        if (!plugin) return false;
        path = plugin->info.path;
    }
    unloadPlugin(name);
    return loadPlugin(path);
}

bool PluginManager::reloadAllPlugins() {
    std::vector<std::string> names;
    {
        std::shared_lock<std::shared_mutex> lock(pluginsMutex);
        for (auto &p : plugins) {
            names.push_back(p->info.name);
        }
    }
    bool allSuccess = true;
    for (auto &name : names) {
        if (!reloadPlugin(name)) allSuccess = false;
    }
    return allSuccess;
}

bool PluginManager::isLoaded(const std::string &name) const {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    auto *plugin = findPlugin(name);
    return plugin && plugin->loaded;
}

bool PluginManager::isEnabled(const std::string &name) const {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    auto *plugin = findPlugin(name);
    return plugin && plugin->enabled;
}

PluginAPI* PluginManager::getPluginAPI(const std::string &name) {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    auto *plugin = findPlugin(name);
    return plugin ? plugin->api : nullptr;
}

PluginAPI* PluginManager::getPluginAPI(uint32_t pluginId) {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    auto *plugin = findPluginById(pluginId);
    return plugin ? plugin->api : nullptr;
}

PluginInfo PluginManager::getPluginInfo(const std::string &name) const {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    auto *plugin = findPlugin(name);
    return plugin ? plugin->info : PluginInfo{};
}

PluginStats PluginManager::getPluginStats(const std::string &name) const {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    auto *plugin = findPlugin(name);
    return plugin ? plugin->stats : PluginStats{};
}

std::vector<PluginInfo> PluginManager::getAllPlugins() const {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    std::vector<PluginInfo> infos;
    infos.reserve(plugins.size());
    for (auto &p : plugins) {
        infos.push_back(p->info);
    }
    return infos;
}

std::vector<PluginInfo> PluginManager::getEnabledPlugins() const {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    std::vector<PluginInfo> infos;
    for (auto &p : plugins) {
        if (p->enabled) infos.push_back(p->info);
    }
    return infos;
}

std::vector<PluginInfo> PluginManager::getLoadedPlugins() const {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    std::vector<PluginInfo> infos;
    for (auto &p : plugins) {
        if (p->loaded) infos.push_back(p->info);
    }
    return infos;
}

std::vector<std::string> PluginManager::getPluginNames() const {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    std::vector<std::string> names;
    names.reserve(plugins.size());
    for (auto &p : plugins) {
        names.push_back(p->info.name);
    }
    return names;
}

uint32_t PluginManager::getPluginCount() const {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    return plugins.size();
}

bool PluginManager::hasPlugin(const std::string &name) const {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    return findPlugin(name) != nullptr;
}

void PluginManager::setPluginDirectory(const std::string &path) {
    pluginDirectory = path;
}

std::string PluginManager::getPluginDirectory() const {
    return pluginDirectory;
}

void PluginManager::scanForPlugins() {
    std::set<std::string> existing;
    {
        std::shared_lock<std::shared_mutex> lock(pluginsMutex);
        for (auto &p : plugins) {
            existing.insert(p->info.name);
        }
    }
    for (auto &dir : pluginPaths) {
        DIR *dp = opendir(dir.c_str());
        if (!dp) continue;
        struct dirent *entry;
        while ((entry = readdir(dp)) != NULL) {
            std::string name = entry->d_name;
            if (name.size() < 3) continue;
            if (name.rfind(".so") != name.size() - 3) continue;
            if (existing.find(name) != existing.end()) continue;
            std::string fullPath = dir + "/" + name;
            loadPlugin(fullPath);
        }
        closedir(dp);
    }
}

void PluginManager::updateAll(float deltaTime) {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    for (auto &plugin : plugins) {
        if (plugin->enabled && plugin->loaded) {
            auto start = std::chrono::steady_clock::now();
            plugin->api->onUpdate(deltaTime);
            auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::steady_clock::now() - start).count();
            plugin->stats.cpuTime += elapsed;
            plugin->stats.callsExecuted++;
        }
    }
}

void PluginManager::renderAll() {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    for (auto &plugin : plugins) {
        if (plugin->enabled && plugin->loaded) {
            plugin->api->onRender();
        }
    }
}

void PluginManager::broadcastEvent(const std::string &event, void *data) {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    for (auto &plugin : plugins) {
        if (plugin->enabled) {
            plugin->api->onEvent(event, data);
        }
    }
}

void PluginManager::broadcastKeyEvent(int key, bool down) {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    for (auto &plugin : plugins) {
        if (plugin->enabled) plugin->api->onKeyEvent(key, down);
    }
}

void PluginManager::broadcastMouseEvent(int button, bool down, float x, float y) {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    for (auto &plugin : plugins) {
        if (plugin->enabled) plugin->api->onMouseEvent(button, down, x, y);
    }
}

void PluginManager::broadcastTouchEvent(int id, int action, float x, float y) {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    for (auto &plugin : plugins) {
        if (plugin->enabled) plugin->api->onTouchEvent(id, action, x, y);
    }
}

void PluginManager::broadcastPacket(const uint8_t *data, size_t size, bool outgoing) {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    for (auto &plugin : plugins) {
        if (plugin->enabled) plugin->api->onPacket(data, size, outgoing);
    }
}

void PluginManager::broadcastTargetFound(void *target) {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    for (auto &plugin : plugins) {
        if (plugin->enabled) plugin->api->onTargetFound(target);
    }
}

void PluginManager::broadcastTargetLost() {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    for (auto &plugin : plugins) {
        if (plugin->enabled) plugin->api->onTargetLost();
    }
}

void PluginManager::broadcastShot() {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    for (auto &plugin : plugins) {
        if (plugin->enabled) plugin->api->onShot();
    }
}

void PluginManager::broadcastDamage(float damage, uintptr_t source) {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    for (auto &plugin : plugins) {
        if (plugin->enabled) plugin->api->onDamage(damage, source);
    }
}

void PluginManager::broadcastKill(uintptr_t target) {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    for (auto &plugin : plugins) {
        if (plugin->enabled) plugin->api->onKill(target);
    }
}

void PluginManager::broadcastDeath(uintptr_t killer) {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    for (auto &plugin : plugins) {
        if (plugin->enabled) plugin->api->onDeath(killer);
    }
}

void PluginManager::broadcastGameStart() {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    for (auto &plugin : plugins) {
        if (plugin->enabled) plugin->api->onGameStart();
    }
}

void PluginManager::broadcastGameEnd() {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    for (auto &plugin : plugins) {
        if (plugin->enabled) plugin->api->onGameEnd();
    }
}

void PluginManager::broadcastMapChange(const std::string &map) {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    for (auto &plugin : plugins) {
        if (plugin->enabled) plugin->api->onMapChange(map);
    }
}

void PluginManager::broadcastWeaponSwitch(const std::string &weapon) {
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    for (auto &plugin : plugins) {
        if (plugin->enabled) plugin->api->onWeaponSwitch(weapon);
    }
}

void PluginManager::setPluginEnabled(const std::string &name, bool enable) {
    if (enable) enablePlugin(name);
    else disablePlugin(name);
}

void PluginManager::setPluginAutoload(const std::string &name, bool autoload) {
    pluginAutoload[name] = autoload;
}

bool PluginManager::isPluginAutoload(const std::string &name) const {
    auto it = pluginAutoload.find(name);
    return it != pluginAutoload.end() && it->second;
}

void PluginManager::savePluginConfig() {}
void PluginManager::loadPluginConfig() {}

std::map<std::string, bool> PluginManager::getPluginStates() const {
    std::map<std::string, bool> states;
    std::shared_lock<std::shared_mutex> lock(pluginsMutex);
    for (auto &p : plugins) {
        states[p->info.name] = p->enabled;
    }
    return states;
}

void PluginManager::setPluginStates(const std::map<std::string, bool> &states) {
    for (auto &[name, enabled] : states) {
        setPluginEnabled(name, enabled);
    }
}

void PluginManager::addPluginPath(const std::string &path) {
    if (std::find(pluginPaths.begin(), pluginPaths.end(), path) == pluginPaths.end()) {
        pluginPaths.push_back(path);
    }
}

void PluginManager::removePluginPath(const std::string &path) {
    pluginPaths.erase(std::remove(pluginPaths.begin(), pluginPaths.end(), path), pluginPaths.end());
}

std::vector<std::string> PluginManager::getPluginPaths() const { return pluginPaths; }
void PluginManager::setMaxPlugins(uint32_t max) { maxPlugins = max; }
uint32_t PluginManager::getMaxPlugins() const { return maxPlugins; }
void PluginManager::enableSandboxing(bool enable) { sandboxingEnabled = enable; }
bool PluginManager::isSandboxingEnabled() const { return sandboxingEnabled; }
void PluginManager::setPluginTimeout(uint32_t ms) { pluginTimeout = ms; }
uint32_t PluginManager::getPluginTimeout() const { return pluginTimeout; }
void PluginManager::setMemoryLimit(size_t limit) { memoryLimit = limit; }
size_t PluginManager::getMemoryLimit() const { return memoryLimit; }

PluginHandle* PluginManager::findPlugin(const std::string &name) {
    auto it = pluginIndex.find(name);
    if (it != pluginIndex.end() && it->second < plugins.size()) {
        return plugins[it->second].get();
    }
    for (auto &p : plugins) {
        if (p->info.name == name) return p.get();
    }
    return nullptr;
}

PluginHandle* PluginManager::findPluginById(uint32_t id) {
    for (auto &p : plugins) {
        if (p->info.pluginId == id) return p.get();
    }
    return nullptr;
}

const PluginHandle* PluginManager::findPlugin(const std::string &name) const {
    for (auto &p : plugins) {
        if (p->info.name == name) return p.get();
    }
    return nullptr;
}

bool PluginManager::validatePlugin(void *handle) {
    return true;
}

bool PluginManager::checkDependencies(const PluginInfo &info) {
    for (auto &dep : info.dependencies) {
        if (!isLoaded(dep)) return false;
    }
    return true;
}

bool PluginManager::verifyPluginSignature(const std::string &path) {
    return true;
}

void* PluginManager::loadSymbol(void *handle, const char *symbol) {
    return dlsym(handle, symbol);
}

void PluginManager::monitorLoop() {
    while (running) {
        std::unique_lock<std::mutex> lock(monitorMutex);
        monitorCV.wait_for(lock, std::chrono::seconds(5));
        if (!running) break;
        collectPluginStats(nullptr);
    }
}

void PluginManager::cleanupPlugin(PluginHandle *plugin) {
    if (plugin->sandboxed) {
        unsandboxPlugin(plugin);
    }
    if (plugin->destroyFunc && plugin->api) {
        plugin->destroyFunc(plugin->api);
    }
    if (plugin->handle) {
        dlclose(plugin->handle);
    }
    plugin->api = nullptr;
    plugin->handle = nullptr;
    plugin->loaded = false;
    plugin->enabled = false;
}

void PluginManager::terminatePlugin(PluginHandle *plugin) {
    cleanupPlugin(plugin);
}

bool PluginManager::sandboxPlugin(PluginHandle *plugin) {
    plugin->sandboxed = true;
    return true;
}

void PluginManager::unsandboxPlugin(PluginHandle *plugin) {
    plugin->sandboxed = false;
}

std::string PluginManager::resolvePluginPath(const std::string &name) {
    struct stat st;
    if (stat(name.c_str(), &st) == 0) return name;
    for (auto &dir : pluginPaths) {
        std::string path = dir + "/" + name;
        if (stat(path.c_str(), &st) == 0) return path;
        if (name.find(".so") == std::string::npos) {
            path = dir + "/" + name + ".so";
            if (stat(path.c_str(), &st) == 0) return path;
        }
    }
    if (!pluginDirectory.empty()) {
        std::string path = pluginDirectory + "/" + name;
        if (stat(path.c_str(), &st) == 0) return path;
        if (name.find(".so") == std::string::npos) {
            path = pluginDirectory + "/" + name + ".so";
            if (stat(path.c_str(), &st) == 0) return path;
        }
    }
    return "";
}

bool PluginManager::checkPluginPermissions(const PluginInfo &info) {
    return true;
}

void PluginManager::collectPluginStats(PluginHandle *plugin) {
    if (plugin) {
        struct rusage usage;
        getrusage(RUSAGE_THREAD, &usage);
        plugin->stats.memoryUsage = usage.ru_maxrss;
        plugin->stats.cpuTime = usage.ru_utime.tv_sec * 1000000ULL + usage.ru_utime.tv_usec;
    }
}

void PluginManager::savePluginState() {
    auto states = getPluginStates();
    std::ofstream file(pluginDirectory + "/plugins.json");
    if (!file.is_open()) return;
    file << "{";
    bool first = true;
    for (auto &[name, enabled] : states) {
        if (!first) file << ",";
        file << "\"" << name << "\":" << (enabled ? "true" : "false");
        first = false;
    }
    for (auto &[name, autoload] : pluginAutoload) {
        if (states.find(name) != states.end()) continue;
        file << ",\"" << name << "\":" << (autoload ? "true" : "false");
    }
    file << "}";
}

void PluginManager::loadPluginState() {
    std::ifstream file(pluginDirectory + "/plugins.json");
    if (!file.is_open()) return;
    std::stringstream buffer;
    buffer << file.rdbuf();
    std::string content = buffer.str();
    std::string key;
    bool readingKey = false;
    bool readingValue = false;
    for (char c : content) {
        if (c == '"') {
            if (!readingKey && !readingValue) {
                readingKey = true;
                key.clear();
            } else if (readingKey) {
                readingKey = false;
                readingValue = true;
            }
        } else if (c == ':' && readingValue) {
            readingValue = false;
        } else if (c == 't' || c == 'f') {
            bool value = (c == 't');
            if (!key.empty()) {
                pluginAutoload[key] = value;
            }
            key.clear();
        } else if (readingKey) {
            key += c;
        }
    }
}

void PluginManager::autoLoadPlugins() {
    std::unique_lock<std::shared_mutex> lock(pluginsMutex);
    for (auto &[name, autoload] : pluginAutoload) {
        if (autoload) {
            auto *plugin = findPlugin(name);
            if (plugin && plugin->loaded && !plugin->enabled) {
                if (plugin->api->onEnable()) {
                    plugin->enabled = true;
                }
            }
        }
    }
}

PluginSandbox::PluginSandbox() : seccompEnabled(false), namespaceEnabled(false) {}
PluginSandbox::~PluginSandbox() {}

bool PluginSandbox::createSandbox(PluginHandle *plugin) {
    if (!plugin) return false;
    if (seccompEnabled && !applySeccompFilter()) return false;
    if (namespaceEnabled && !createNamespace()) return false;
    sandboxedPlugins[reinterpret_cast<uintptr_t>(plugin)] = true;
    plugin->sandboxed = true;
    return true;
}

void PluginSandbox::destroySandbox(PluginHandle *plugin) {
    if (plugin) {
        sandboxedPlugins.erase(reinterpret_cast<uintptr_t>(plugin));
        plugin->sandboxed = false;
    }
}

bool PluginSandbox::isSandboxed(PluginHandle *plugin) const {
    auto it = sandboxedPlugins.find(reinterpret_cast<uintptr_t>(plugin));
    return it != sandboxedPlugins.end();
}

bool PluginSandbox::restrictSyscalls(PluginHandle *plugin) {
    return seccompEnabled && applySeccompFilter();
}

bool PluginSandbox::restrictMemory(PluginHandle *plugin, size_t limit) {
    struct rlimit rlim;
    rlim.rlim_cur = limit;
    rlim.rlim_max = limit;
    return setrlimit(RLIMIT_AS, &rlim) == 0;
}

bool PluginSandbox::restrictFileAccess(PluginHandle *plugin, const std::vector<std::string> &allowedPaths) {
    return true;
}

bool PluginSandbox::restrictNetwork(PluginHandle *plugin) {
    return true;
}

bool PluginSandbox::setCPULimit(PluginHandle *plugin, float limit) {
    struct rlimit rlim;
    rlim.rlim_cur = (rlim_t)(limit * 1000000);
    rlim.rlim_max = (rlim_t)(limit * 1000000);
    return setrlimit(RLIMIT_CPU, &rlim) == 0;
}

bool PluginSandbox::setTimeLimit(PluginHandle *plugin, uint32_t ms) {
    return setCPULimit(plugin, ms / 1000.0f);
}

bool PluginSandbox::monitorPlugin(PluginHandle *plugin) {
    return true;
}

bool PluginSandbox::killPlugin(PluginHandle *plugin) {
    if (plugin) {
        plugin->loaded = false;
        plugin->enabled = false;
        return true;
    }
    return false;
}

void PluginSandbox::enableSeccomp() { seccompEnabled = true; }
void PluginSandbox::disableSeccomp() { seccompEnabled = false; }
void PluginSandbox::enableNamespace() { namespaceEnabled = true; }
void PluginSandbox::disableNamespace() { namespaceEnabled = false; }
void PluginSandbox::setAllowedCalls(const std::vector<int> &calls) { allowedSyscalls = calls; }
std::vector<int> PluginSandbox::getAllowedCalls() const { return allowedSyscalls; }

bool PluginSandbox::applySeccompFilter() {
    scmp_filter_ctx ctx = seccomp_init(SCMP_ACT_KILL);
    if (!ctx) return false;
    seccomp_release(ctx);
    return true;
}

bool PluginSandbox::createNamespace() {
    return unshare(CLONE_NEWNS | CLONE_NEWPID | CLONE_NEWNET) == 0;
}

bool PluginSandbox::setupChroot(const std::string &path) {
    return chroot(path.c_str()) == 0;
}

bool PluginSandbox::limitResources(const PluginHandle *plugin) {
    return true;
}

void PluginSandbox::trackSyscalls(const PluginHandle *plugin) {}

InterPluginCommunicator::InterPluginCommunicator() : initialized(false) {}
InterPluginCommunicator::~InterPluginCommunicator() { shutdown(); }

bool InterPluginCommunicator::initialize() {
    initialized = true;
    return true;
}

void InterPluginCommunicator::shutdown() {
    initialized = false;
    std::lock_guard<std::mutex> lock(commMutex);
    messageQueues.clear();
    handlers.clear();
}

bool InterPluginCommunicator::sendMessage(const std::string &from, const std::string &to, const std::string &message) {
    std::lock_guard<std::mutex> lock(commMutex);
    Message msg;
    msg.from = from;
    msg.to = to;
    msg.text = message;
    msg.timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    messageQueues[to].push(msg);
    commCV.notify_all();
    return true;
}

bool InterPluginCommunicator::sendMessage(const std::string &from, const std::string &to, const std::vector<uint8_t> &data) {
    std::lock_guard<std::mutex> lock(commMutex);
    Message msg;
    msg.from = from;
    msg.to = to;
    msg.data = data;
    msg.timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    messageQueues[to].push(msg);
    commCV.notify_all();
    return true;
}

bool InterPluginCommunicator::broadcastMessage(const std::string &from, const std::string &message) {
    std::lock_guard<std::mutex> lock(commMutex);
    for (auto &[target, _] : messageQueues) {
        if (target != from) {
            Message msg;
            msg.from = from;
            msg.to = target;
            msg.text = message;
            msg.timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::system_clock::now().time_since_epoch()).count();
            messageQueues[target].push(msg);
        }
    }
    commCV.notify_all();
    return true;
}

bool InterPluginCommunicator::broadcastMessage(const std::string &from, const std::vector<uint8_t> &data) {
    return true;
}

std::string InterPluginCommunicator::waitForMessage(const std::string &plugin, uint32_t timeoutMs) {
    std::unique_lock<std::mutex> lock(commMutex);
    if (messageQueues[plugin].empty()) {
        commCV.wait_for(lock, std::chrono::milliseconds(timeoutMs));
    }
    if (messageQueues[plugin].empty()) return "";
    Message msg = messageQueues[plugin].front();
    messageQueues[plugin].pop();
    return msg.text;
}

bool InterPluginCommunicator::hasMessage(const std::string &plugin) const {
    std::lock_guard<std::mutex> lock(commMutex);
    auto it = messageQueues.find(plugin);
    return it != messageQueues.end() && !it->second.empty();
}

void InterPluginCommunicator::clearMessages(const std::string &plugin) {
    std::lock_guard<std::mutex> lock(commMutex);
    messageQueues[plugin] = std::queue<Message>();
}

void InterPluginCommunicator::registerHandler(const std::string &plugin, std::function<void(const std::string&, const std::string&)> handler) {
    std::lock_guard<std::mutex> lock(commMutex);
    handlers[plugin] = handler;
}

void InterPluginCommunicator::unregisterHandler(const std::string &plugin) {
    std::lock_guard<std::mutex> lock(commMutex);
    handlers.erase(plugin);
}

void InterPluginCommunicator::processMessage(const Message &msg) {
    auto it = handlers.find(msg.to);
    if (it != handlers.end()) {
        it->second(msg.from, msg.text);
    }
}

HotReloader::HotReloader()
    : pluginManager(nullptr), running(false), watcherThread(nullptr),
      pollInterval(2000) {}

HotReloader::~HotReloader() { stop(); }

void HotReloader::start(PluginManager *manager) {
    if (running) return;
    pluginManager = manager;
    running = true;
    watcherThread = new std::thread(&HotReloader::watchLoop, this);
}

void HotReloader::stop() {
    running = false;
    if (watcherThread && watcherThread->joinable()) {
        watcherThread->join();
        delete watcherThread;
        watcherThread = nullptr;
    }
    clearChanges();
}

void HotReloader::setWatchDirectory(const std::string &path) {
    std::lock_guard<std::mutex> lock(watchMutex);
    watchDirectory = path;
}

void HotReloader::setPollInterval(uint32_t ms) {
    pollInterval = ms;
}

void HotReloader::watchFile(const std::string &path) {
    std::lock_guard<std::mutex> lock(watchMutex);
    if (std::find(watchPaths.begin(), watchPaths.end(), path) == watchPaths.end()) {
        watchPaths.push_back(path);
        std::error_code ec;
        fileTimestamps[path] = std::filesystem::last_write_time(path, ec);
    }
}

void HotReloader::unwatchFile(const std::string &path) {
    std::lock_guard<std::mutex> lock(watchMutex);
    watchPaths.erase(std::remove(watchPaths.begin(), watchPaths.end(), path), watchPaths.end());
    fileTimestamps.erase(path);
}

bool HotReloader::isWatching() const {
    return running;
}

std::vector<std::string> HotReloader::getChangedFiles() const {
    std::lock_guard<std::mutex> lock(watchMutex);
    std::vector<std::string> changed;
    for (auto &path : watchPaths) {
        if (hasFileChanged(path)) changed.push_back(path);
    }
    return changed;
}

void HotReloader::clearChanges() {
    std::lock_guard<std::mutex> lock(watchMutex);
    fileTimestamps.clear();
    for (auto &path : watchPaths) {
        std::error_code ec;
        fileTimestamps[path] = std::filesystem::last_write_time(path, ec);
    }
}

void HotReloader::watchLoop() {
    while (running) {
        std::this_thread::sleep_for(std::chrono::milliseconds(pollInterval));
        if (!running) break;
        reloadChangedPlugins();
    }
}

bool HotReloader::hasFileChanged(const std::string &path) {
    std::error_code ec;
    auto current = std::filesystem::last_write_time(path, ec);
    if (ec) return false;
    auto it = fileTimestamps.find(path);
    if (it == fileTimestamps.end()) return true;
    return current != it->second;
}

void HotReloader::reloadChangedPlugins() {
    if (!pluginManager) return;
    std::lock_guard<std::mutex> lock(watchMutex);
    for (auto &path : watchPaths) {
        if (hasFileChanged(path)) {
            size_t lastSlash = path.rfind('/');
            size_t lastDot = path.rfind('.');
            std::string name;
            if (lastSlash != std::string::npos && lastDot != std::string::npos) {
                name = path.substr(lastSlash + 1, lastDot - lastSlash - 1);
            }
            if (!name.empty()) {
                pluginManager->reloadPlugin(name);
                std::error_code ec;
                fileTimestamps[path] = std::filesystem::last_write_time(path, ec);
            }
        }
    }
}

}
