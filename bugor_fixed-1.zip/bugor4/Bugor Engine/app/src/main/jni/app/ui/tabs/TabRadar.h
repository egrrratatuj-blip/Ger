#pragma once
#include <imgui.h>

void DrawTabRadar(ImDrawList* dl, ImVec2 contentPos, ImVec2 contentSize);
void InitTabRadar();
void ShutdownTabRadar();
void DrawRadarOverlay();
