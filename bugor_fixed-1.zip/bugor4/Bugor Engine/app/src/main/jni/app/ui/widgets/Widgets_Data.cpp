#ifndef IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#define IMGUI_IMPL_OPENGL3_LOADER_CUSTOM
#include <GLES3/gl3.h>
#endif
#include "../../../imgui/imgui.h"
#include "../../../imgui/imgui_internal.h"
#include "../../../imgui/mycustom/imgui_Custom.h"
#include <math.h>
#include <string.h>
#include <map>
#include <stdlib.h>

static ImU32 C(const ImColor& c) { return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w)); }

void M_ProgressRing(ImDrawList* dl, const char* label, float value, float maxValue, ImVec2 center, float radius, ImColor accent, float thickness)
{
    static std::map<const char*, struct { float current; float prevTarget; float pulse; float rotation; }> s_anim;
    auto& s = s_anim[label];
    float target = (maxValue > 0.0f) ? ImClamp(value / maxValue, 0.0f, 1.0f) : 0.0f;
    if (fabsf(target - s.prevTarget) > 0.001f)
    {
        s.prevTarget = target;
        s.pulse = 1.4f;
    }
    s.current += (target - s.current) * ImClamp(ImGui::GetIO().DeltaTime * 7.0f, 0.0f, 1.0f);
    s.pulse += (1.0f - s.pulse) * ImClamp(ImGui::GetIO().DeltaTime * 5.0f, 0.0f, 1.0f);
    s.rotation += ImGui::GetIO().DeltaTime * 15.0f;
    float t = s.current;
    ImColor c;
    float greenPhase = 0.5f;
    float yellowPhase = 0.8f;
    if (t < greenPhase)
    {
        float f = t / greenPhase;
        c.Value.x = 0.1f + f * 0.9f;
        c.Value.y = 0.9f + f * 0.1f;
        c.Value.z = 0.1f;
    }
    else if (t < yellowPhase)
    {
        float f = (t - greenPhase) / (yellowPhase - greenPhase);
        c.Value.x = 1.0f;
        c.Value.y = 1.0f - f * 0.6f;
        c.Value.z = 0.1f + f * 0.4f;
    }
    else
    {
        float f = (t - yellowPhase) / (1.0f - yellowPhase);
        c.Value.x = 1.0f;
        c.Value.y = 0.4f - f * 0.3f;
        c.Value.z = 0.5f - f * 0.4f;
    }
    c.Value.w = 1.0f;
    ImU32 col = C(c);
    ImU32 bgCol = C(ImColor(45, 45, 55));
    ImU32 trackBg = C(ImColor(35, 35, 45));
    float startAngle = -IM_PI * 0.5f;
    float endAngle = startAngle + t * IM_PI * 2.0f;
    int segments = (int)(24.0f + t * 48.0f);
    if (segments < 12) segments = 12;
    if (segments > 96) segments = 96;
    dl->AddCircle(center, radius, trackBg, segments, thickness + 2.0f);
    dl->AddCircle(center, radius, bgCol, segments, 2.0f);
    if (t > 0.003f)
    {
        float pulseW = thickness * s.pulse;
        dl->AddArc(center, radius, col, startAngle, endAngle, segments, pulseW);
        if (t > 0.1f)
        {
            ImColor glowCol = c;
            glowCol.Value.w = 0.12f * s.pulse;
            dl->AddArc(center, radius + 4.0f, C(glowCol), startAngle, endAngle, segments, 4.0f);
            dl->AddArc(center, radius - 4.0f, C(glowCol), startAngle, endAngle, segments, 2.0f);
        }
        if (t > 0.95f)
        {
            float spin = s.rotation * IM_PI / 180.0f;
            ImColor spCol = c;
            spCol.Value.w = 0.5f;
            dl->AddArc(center, radius + 6.0f, C(spCol), spin, spin + IM_PI * 0.5f, 8, 2.0f);
        }
    }
    char pct[16];
    snprintf(pct, sizeof(pct), "%.0f%%", t * 100.0f);
    ImVec2 ts = ImGui::CalcTextSize(pct);
    float pctScale = 0.7f + s.pulse * 0.3f;
    dl->AddText(ImGui::GetFont(), 18.0f * pctScale, ImVec2(center.x - ts.x * 0.5f * pctScale, center.y - ts.y * 0.5f * pctScale), col, pct);
    ImVec2 labelSize = ImGui::CalcTextSize(label);
    dl->AddText(ImGui::GetFont(), 10.0f, ImVec2(center.x - labelSize.x * 0.5f, center.y + radius * 0.6f + 2.0f), C(ImColor(120,120,135)), label);
    char valStr[32];
    snprintf(valStr, sizeof(valStr), "%.1f/%.1f", ImMin(value, maxValue), maxValue);
    ImVec2 vs = ImGui::CalcTextSize(valStr);
    dl->AddText(ImGui::GetFont(), 9.0f, ImVec2(center.x - vs.x * 0.5f, center.y + radius * 0.6f + 14.0f), C(ImColor(90,90,105)), valStr);
    if (t > 0.98f)
    {
        float sweep = fmodf(ImGui::GetTime() * 2.0f, 1.0f);
        float sa = startAngle + sweep * IM_PI * 2.0f;
        float sa2 = sa + IM_PI * 0.15f;
        ImColor tailCol = c;
        tailCol.Value.w = 0.3f;
        dl->AddArc(center, radius + 3.0f, C(tailCol), sa, sa2, 8, 3.0f);
    }
}

void M_SparkLine(ImDrawList* dl, const char* label, float* data, int dataCount, ImVec2 pos, float width, float height, ImColor lineColor, ImColor fillColor)
{
    if (!data || dataCount < 2) return;
    float minV = data[0], maxV = data[0];
    for (int i = 1; i < dataCount; ++i)
    {
        if (data[i] < minV) minV = data[i];
        if (data[i] > maxV) maxV = data[i];
    }
    float range = maxV - minV;
    if (range < 0.0001f) range = 1.0f;
    float pad = height * 0.06f;
    ImVector<ImVec2> pts;
    pts.reserve(dataCount);
    float stepX = (dataCount > 1) ? width / (float)(dataCount - 1) : 0.0f;
    for (int i = 0; i < dataCount; ++i)
    {
        float x = pos.x + i * stepX;
        float y = pos.y + height - pad - ((data[i] - minV) / range) * (height - pad * 2.0f);
        pts.push_back(ImVec2(x, y));
    }
    ImU32 lineC = C(lineColor);
    ImU32 fillC = C(ImColor(fillColor.Value.x, fillColor.Value.y, fillColor.Value.z, fillColor.Value.w * 0.5f));
    ImU32 fillC2 = C(ImColor(fillColor.Value.x, fillColor.Value.y, fillColor.Value.z, 0.0f));
    if (dataCount >= 3)
    {
        ImVector<ImVec2> smoothPts;
        smoothPts.reserve(dataCount * 4);
        for (int i = 0; i < dataCount - 1; ++i)
        {
            ImVec2 p0 = pts[i];
            ImVec2 p1 = pts[i + 1];
            ImVec2 cp0, cp1;
            if (i == 0)
            {
                cp0 = ImVec2(p0.x + (p1.x - p0.x) * 0.3f, p0.y);
                cp1 = ImVec2(p1.x - (p1.x - p0.x) * 0.3f, p1.y);
            }
            else if (i == dataCount - 2)
            {
                cp0 = ImVec2(p0.x + (p1.x - p0.x) * 0.3f, p0.y);
                cp1 = ImVec2(p1.x - (p1.x - p0.x) * 0.3f, p1.y);
            }
            else
            {
                cp0 = ImVec2(p0.x + (p1.x - p0.x) * 0.4f, p0.y);
                cp1 = ImVec2(p1.x - (p1.x - p0.x) * 0.4f, p1.y);
            }
            for (int s = 0; s < 10; ++s)
            {
                float f = (float)s / 10.0f;
                float u = 1.0f - f;
                float x = u * u * u * p0.x + 3.0f * u * u * f * cp0.x + 3.0f * u * f * f * cp1.x + f * f * f * p1.x;
                float y = u * u * u * p0.y + 3.0f * u * u * f * cp0.y + 3.0f * u * f * f * cp1.y + f * f * f * p1.y;
                smoothPts.push_back(ImVec2(x, y));
            }
        }
        smoothPts.push_back(pts[dataCount - 1]);
        if (smoothPts.Size > 1)
        {
            ImVector<ImVec2> fillPts;
            fillPts.reserve(smoothPts.Size + 2);
            fillPts.push_back(ImVec2(smoothPts[0].x, pos.y + height));
            for (int i = 0; i < smoothPts.Size; ++i)
                fillPts.push_back(smoothPts[i]);
            fillPts.push_back(ImVec2(smoothPts[smoothPts.Size - 1].x, pos.y + height));
            dl->AddConvexPolyFilled(fillPts.Data, fillPts.Size, fillC);
            dl->AddPolyline(smoothPts.Data, smoothPts.Size, lineC, false, 2.0f);
        }
    }
    else
    {
        ImVector<ImVec2> fillPts;
        fillPts.push_back(ImVec2(pts[0].x, pos.y + height));
        for (int i = 0; i < pts.Size; ++i)
            fillPts.push_back(pts[i]);
        fillPts.push_back(ImVec2(pts[pts.Size - 1].x, pos.y + height));
        dl->AddConvexPolyFilled(fillPts.Data, fillPts.Size, fillC);
        dl->AddPolyline(pts.Data, pts.Size, lineC, false, 2.0f);
    }
    dl->AddLine(ImVec2(pos.x, pos.y + height), ImVec2(pos.x + width, pos.y + height), C(ImColor(50,50,60)));
    char lastVal[32];
    snprintf(lastVal, sizeof(lastVal), "%.1f", data[dataCount - 1]);
    ImVec2 lv = ImGui::CalcTextSize(lastVal);
    ImVec2 lvPos = ImVec2(pos.x + width - lv.x - 2.0f, pos.y - 2.0f);
    dl->AddRectFilled(ImVec2(lvPos.x - 2.0f, lvPos.y - 1.0f), ImVec2(lvPos.x + lv.x + 2.0f, lvPos.y + lv.y + 1.0f), C(ImColor(0,0,0,120)), 2.0f);
    dl->AddText(ImGui::GetFont(), 10.0f, lvPos, lineC, lastVal);
    float avg = 0.0f;
    for (int i = 0; i < dataCount; ++i) avg += data[i];
    avg /= (float)dataCount;
    char avgStr[32];
    snprintf(avgStr, sizeof(avgStr), "avg %.1f", avg);
    ImVec2 avs = ImGui::CalcTextSize(avgStr);
    dl->AddText(ImGui::GetFont(), 9.0f, ImVec2(pos.x + 2.0f, pos.y - avs.y - 2.0f), C(ImColor(90,90,105)), avgStr);
    char rangeStr[32];
    snprintf(rangeStr, sizeof(rangeStr), "%.1f-%.1f", minV, maxV);
    ImVec2 rs = ImGui::CalcTextSize(rangeStr);
    dl->AddText(ImGui::GetFont(), 8.0f, ImVec2(pos.x + 2.0f, pos.y + height + 2.0f), C(ImColor(70,70,85)), rangeStr);
}

void M_MiniBarGraph(ImDrawList* dl, const char* label, float* data, int dataCount, ImVec2 pos, float width, float height, ImColor* colors)
{
    if (dataCount < 1) return;
    float maxV = data[0];
    for (int i = 1; i < dataCount; ++i)
        if (data[i] > maxV) maxV = data[i];
    if (maxV < 0.001f) maxV = 1.0f;
    float availableW = width;
    float spacing = 4.0f;
    float totalSpacing = spacing * (dataCount - 1);
    float barW = (availableW - totalSpacing) / (float)dataCount;
    if (barW < 2.5f)
    {
        barW = 2.5f;
        spacing = (availableW - barW * dataCount) / (float)(dataCount - 1);
        if (spacing < 1.0f) { spacing = 1.0f; barW = (availableW - spacing * (dataCount - 1)) / (float)dataCount; if (barW < 1.0f) barW = 1.0f; }
    }
    dl->AddRectFilled(pos, ImVec2(pos.x + width, pos.y + height), C(ImColor(22,22,30)));
    dl->AddRect(pos, ImVec2(pos.x + width, pos.y + height), C(ImColor(45,45,55)));
    int gridLines = 4;
    for (int g = 1; g < gridLines; ++g)
    {
        float gy = pos.y + height * (float)g / (float)gridLines;
        dl->AddLine(ImVec2(pos.x + 1.0f, gy), ImVec2(pos.x + width - 1.0f, gy), C(ImColor(38,38,48)));
        char gv[8];
        snprintf(gv, sizeof(gv), "%.0f", maxV * (1.0f - (float)g / (float)gridLines));
        ImVec2 gvs = ImGui::CalcTextSize(gv);
        dl->AddText(ImGui::GetFont(), 8.0f, ImVec2(pos.x + width - gvs.x - 2.0f, gy - gvs.y * 0.5f), C(ImColor(60,60,75)), gv);
    }
    ImVec2 mouse = ImGui::GetIO().MousePos;
    int hoverIdx = -1;
    for (int i = 0; i < dataCount; ++i)
    {
        float barH = (data[i] / maxV) * height;
        if (barH < 1.0f && data[i] > 0.0f) barH = 1.0f;
        float x0 = pos.x + i * (barW + spacing);
        float y0 = pos.y + height - barH;
        ImVec2 b0 = ImVec2(x0, y0);
        ImVec2 b1 = ImVec2(x0 + barW, pos.y + height);
        bool hovered = (mouse.x >= b0.x && mouse.x <= b1.x && mouse.y >= b0.y && mouse.y <= b1.y);
        if (hovered) hoverIdx = i;
        ImU32 col;
        if (colors)
        {
            ImColor base = colors[i % dataCount];
            if (hovered) { base.Value.x = ImMin(base.Value.x * 1.3f, 1.0f); base.Value.y = ImMin(base.Value.y * 1.3f, 1.0f); base.Value.z = ImMin(base.Value.z * 1.3f, 1.0f); }
            col = C(base);
        }
        else
        {
            ImColor base = ImColor(60 + (i * 20) % 120, 120 + (i * 30) % 100, 200);
            if (hovered) { base = ImColor(80 + (i * 20) % 120, 160 + (i * 30) % 100, 255); }
            col = C(base);
        }
        dl->AddRectFilled(b0, b1, col, 2.0f);
        if (hovered)
        {
            dl->AddRect(b0, b1, C(ImColor(255,255,255,50)), 2.0f);
            char val[32];
            snprintf(val, sizeof(val), "%.2f", data[i]);
            ImVec2 vs = ImGui::CalcTextSize(val);
            float lblX = b0.x + barW * 0.5f - vs.x * 0.5f;
            float lblY = b0.y - vs.y - 4.0f;
            dl->AddRectFilled(ImVec2(lblX - 2.0f, lblY - 1.0f), ImVec2(lblX + vs.x + 2.0f, lblY + vs.y + 1.0f), C(ImColor(0,0,0,150)), 2.0f);
            dl->AddText(ImGui::GetFont(), 10.0f, ImVec2(lblX, lblY), C(ImColor(255,255,255)), val);
        }
    }
    if (hoverIdx >= 0)
    {
        char idxStr[16];
        snprintf(idxStr, sizeof(idxStr), "idx:%d", hoverIdx);
        ImVec2 is = ImGui::CalcTextSize(idxStr);
        dl->AddText(ImGui::GetFont(), 8.0f, ImVec2(pos.x + 2.0f, pos.y + height + 2.0f), C(ImColor(80,80,95)), idxStr);
    }
    else
    {
        ImVec2 ls = ImGui::CalcTextSize(label);
        dl->AddText(ImGui::GetFont(), 9.0f, ImVec2(pos.x + width * 0.5f - ls.x * 0.5f, pos.y + height + 2.0f), C(ImColor(110,110,125)), label);
    }
}

void M_BadgeCounter(ImDrawList* dl, ImVec2 pos, int count, ImColor color)
{
    static std::map<float, std::map<float, struct { int prev; float scale; float time; float targetScale; }>> s_anim;
    auto& a = s_anim[pos.x][pos.y];
    if (a.prev != count)
    {
        a.prev = count;
        a.targetScale = 1.5f;
        a.time = 0.0f;
    }
    a.time += ImGui::GetIO().DeltaTime;
    a.scale += (a.targetScale - a.scale) * ImClamp(ImGui::GetIO().DeltaTime * 12.0f, 0.0f, 1.0f);
    if (a.scale > 1.5f) a.scale = 1.5f;
    if (fabsf(a.scale - 1.0f) < 0.02f && a.targetScale > 1.0f)
    {
        a.targetScale = 0.85f;
    }
    else if (a.scale < 0.9f && a.targetScale < 1.0f)
    {
        a.targetScale = 1.05f;
    }
    else if (fabsf(a.scale - 1.05f) < 0.02f && a.targetScale > 1.0f && a.targetScale < 1.5f)
    {
        a.targetScale = 1.0f;
    }
    if (a.targetScale > 1.0f && a.scale >= a.targetScale * 0.95f)
    {
        a.targetScale = 0.85f;
    }
    char txt[8];
    if (count > 99) snprintf(txt, sizeof(txt), "99+");
    else snprintf(txt, sizeof(txt), "%d", count);
    ImVec2 textSize = ImGui::CalcTextSize(txt);
    float baseR = ImMax(textSize.x, textSize.y) * 0.5f + 8.0f;
    float r = baseR * a.scale;
    ImU32 bg = C(color);
    dl->AddCircleFilled(pos, r, bg, 48);
    ImColor borderCol = ImColor(255,255,255,50);
    dl->AddCircle(pos, r, C(borderCol), 48, 1.5f);
    if (a.scale > 1.05f)
    {
        ImColor glow = color;
        glow.Value.w = (a.scale - 1.0f) * 0.5f;
        dl->AddCircle(pos, r + 4.0f, C(glow), 48, 3.0f);
        ImColor glow2 = color;
        glow2.Value.w = (a.scale - 1.0f) * 0.2f;
        dl->AddCircle(pos, r + 8.0f, C(glow2), 48, 2.0f);
    }
    ImColor txtCol(255, 255, 255, 255);
    dl->AddText(ImGui::GetFont(), 12.0f * a.scale, ImVec2(pos.x - textSize.x * 0.5f * a.scale, pos.y - textSize.y * 0.5f * a.scale), C(txtCol), txt);
}

int M_RadialMenu(const char* label, ImVec2 center, float radius, const char** items, int count, int selected, ImColor accent, float startAngle)
{
    static std::map<const char*, struct { int hovered; float animHover; float selectAnim; float pulse; int prevSelected; }> s_state;
    auto& st = s_state[label];
    ImDrawList* dl = ImGui::GetOverlayDrawList();
    ImGuiIO& io = ImGui::GetIO();
    ImVec2 mouse = io.MousePos;
    int result = -1;
    float angleStep = (IM_PI * 2.0f) / (float)count;
    float angleOff = angleStep * 0.5f;
    float bgR = radius + 35.0f;
    st.hovered = -1;
    float dx = mouse.x - center.x;
    float dy = mouse.y - center.y;
    float distFromCenter = sqrtf(dx * dx + dy * dy);
    if (distFromCenter > 10.0f && distFromCenter < bgR)
    {
        float mouseAngle = atan2f(dy, dx);
        if (mouseAngle < 0.0f) mouseAngle += IM_PI * 2.0f;
        float relAngle = mouseAngle - startAngle;
        if (relAngle < 0.0f) relAngle += IM_PI * 2.0f;
        int idx = (int)(relAngle / angleStep);
        if (idx >= 0 && idx < count) st.hovered = idx;
    }
    float targetHover = (st.hovered >= 0) ? 1.0f : 0.0f;
    st.animHover += (targetHover - st.animHover) * ImClamp(io.DeltaTime * 14.0f, 0.0f, 1.0f);
    st.selectAnim += ((selected >= 0 ? 1.0f : 0.0f) - st.selectAnim) * ImClamp(io.DeltaTime * 6.0f, 0.0f, 1.0f);
    st.pulse = sinf(io.Time * 2.0f) * 0.1f + 0.9f;
    dl->AddCircleFilled(center, bgR, C(ImColor(18,18,26,220)), 64);
    dl->AddCircle(center, bgR, C(ImColor(50,50,65)), 64, 1.5f);
    for (int i = 0; i < count; ++i)
    {
        float a0 = startAngle + i * angleStep - angleOff;
        float a1 = startAngle + i * angleStep + angleOff;
        bool hovered = (i == st.hovered);
        bool sel = (i == selected);
        ImColor bg;
        float alpha = 0.25f;
        if (sel) { bg = accent; bg.Value.w = 0.45f; alpha = 0.45f; }
        else if (hovered && st.animHover > 0.1f) { bg = ImColor(70,70,90); bg.Value.w = 0.5f * st.animHover; alpha = 0.5f * st.animHover; }
        else { bg = ImColor(35,35,48); bg.Value.w = 0.2f; }
        dl->AddArcFilled(center, radius, C(bg), a0, a1, 32);
        if (sel && st.selectAnim > 0.1f)
        {
            ImColor selPulse = accent;
            selPulse.Value.w = 0.2f * st.selectAnim * st.pulse;
            dl->AddArc(center, radius + 5.0f, C(selPulse), a0, a1, 32, 4.0f);
        }
        if (hovered && st.animHover > 0.1f)
            dl->AddArc(center, radius, C(accent), a0, a1, 32, 5.0f * st.animHover);
    }
    dl->AddCircle(center, radius, C(ImColor(45,45,58)), 64, 2.0f);
    dl->AddCircleFilled(center, 10.0f, C(ImColor(45,45,58)), 32);
    dl->AddCircle(center, 10.0f, C(ImColor(70,70,85)), 32, 1.5f);
    for (int i = 0; i < count; ++i)
    {
        float a = startAngle + i * angleStep;
        ImVec2 itemPos = ImVec2(center.x + cosf(a) * radius, center.y + sinf(a) * radius);
        ImVec2 textPos = ImVec2(center.x + cosf(a) * (radius + 36.0f), center.y + sinf(a) * (radius + 36.0f));
        bool hovered = (i == st.hovered);
        bool sel = (i == selected);
        float dotR = sel ? 20.0f : (hovered ? 16.0f : 14.0f);
        ImU32 dotCol;
        if (sel) dotCol = C(accent);
        else if (hovered) dotCol = C(ImColor(80,80,100));
        else dotCol = C(ImColor(55,55,70));
        dl->AddCircleFilled(itemPos, dotR, dotCol, 32);
        dl->AddCircle(itemPos, dotR, C(ImColor(100,100,120,60)), 32, sel ? 2.5f : 1.5f);
        char idx[4];
        snprintf(idx, sizeof(idx), "%d", i + 1);
        ImVec2 is = ImGui::CalcTextSize(idx);
        dl->AddText(ImGui::GetFont(), sel ? 13.0f : 11.0f, ImVec2(itemPos.x - is.x * 0.5f, itemPos.y - is.y * 0.5f), C(ImColor(255,255,255)), idx);
        ImU32 txtCol = C(hovered ? accent : ImColor(170,170,185));
        dl->AddText(ImGui::GetFont(), 11.0f, ImVec2(textPos.x - ImGui::CalcTextSize(items[i]).x * 0.5f, textPos.y - 5.5f), txtCol, items[i]);
        float dist = sqrtf((mouse.x - itemPos.x) * (mouse.x - itemPos.x) + (mouse.y - itemPos.y) * (mouse.y - itemPos.y));
        if ((dist < dotR && io.MouseClicked[0]) || (st.hovered == i && io.MouseClicked[0] && distFromCenter > radius * 0.5f))
            result = i;
    }
    char title[128];
    snprintf(title, sizeof(title), "##radial_%s", label);
    ImGui::SetCursorScreenPos(ImVec2(center.x - bgR, center.y - bgR));
    ImGui::InvisibleButton(title, ImVec2(bgR * 2.0f, bgR * 2.0f));
    if (ImGui::IsMouseClicked(1) || ImGui::IsKeyPressed(ImGuiKey_Escape) || (io.MouseClicked[0] && st.hovered < 0 && sqrtf((mouse.x-center.x)*(mouse.x-center.x)+(mouse.y-center.y)*(mouse.y-center.y)) > bgR))
        result = -2;
    return result;
}

void M_MatrixDisplay(ImDrawList* dl, const char* label, float* matrix, int rows, int cols, ImVec2 pos, float cellWidth, float cellHeight)
{
    float totalW = cols * cellWidth;
    float totalH = rows * cellHeight;
    dl->AddRectFilled(pos, ImVec2(pos.x + totalW, pos.y + totalH), C(ImColor(18,18,26)), 4.0f);
    dl->AddRect(pos, ImVec2(pos.x + totalW, pos.y + totalH), C(ImColor(45,45,55)), 4.0f);
    for (int r = 0; r < rows; ++r)
    {
        for (int c = 0; c < cols; ++c)
        {
            ImVec2 p0 = ImVec2(pos.x + c * cellWidth, pos.y + r * cellHeight);
            ImVec2 p1 = ImVec2(p0.x + cellWidth, p0.y + cellHeight);
            bool isFirstRow = (r == 0);
            bool isFirstCol = (c == 0);
            ImU32 borderCol = C(ImColor(55,55,68));
            if (isFirstRow || isFirstCol) borderCol = C(ImColor(70,70,88));
            dl->AddRect(p0, p1, borderCol);
            if (isFirstCol && isFirstRow)
                dl->AddRectFilled(p0, p1, C(ImColor(30,30,42)));
            float val = matrix[r * cols + c];
            char fmt[32];
            if (fabsf(val) < 0.0001f)
                snprintf(fmt, sizeof(fmt), "0");
            else if (fabsf(val) < 0.01f)
                snprintf(fmt, sizeof(fmt), "%.4f", val);
            else if (fabsf(val) < 1.0f)
                snprintf(fmt, sizeof(fmt), "%.3f", val);
            else if (fabsf(val) < 100.0f)
                snprintf(fmt, sizeof(fmt), "%.2f", val);
            else
                snprintf(fmt, sizeof(fmt), "%.1f", val);
            ImVec2 ts = ImGui::CalcTextSize(fmt);
            ImU32 txtCol;
            if (fabsf(val) < 0.0001f)
                txtCol = C(ImColor(70,70,85));
            else if (val < 0.0f && fabsf(val) > 0.0001f)
                txtCol = C(ImColor(255,110,110));
            else if (val > 0.0f && fabsf(val) > 0.0001f)
                txtCol = C(ImColor(200,210,220));
            else
                txtCol = C(ImColor(150,150,160));
            if (isFirstCol || isFirstRow)
                txtCol = C(ImColor(180,190,210));
            float xOff = p0.x + cellWidth * 0.5f - ts.x * 0.5f;
            float yOff = p0.y + cellHeight * 0.5f - ts.y * 0.5f;
            dl->AddText(ImGui::GetFont(), 11.0f, ImVec2(xOff, yOff), txtCol, fmt);
        }
    }
    ImVec2 ls = ImGui::CalcTextSize(label);
    dl->AddText(ImGui::GetFont(), 10.0f, ImVec2(pos.x + totalW * 0.5f - ls.x * 0.5f, pos.y - ls.y - 5.0f), C(ImColor(120,120,135)), label);
    char dimStr[32];
    snprintf(dimStr, sizeof(dimStr), "%dx%d", rows, cols);
    ImVec2 ds = ImGui::CalcTextSize(dimStr);
    dl->AddText(ImGui::GetFont(), 8.0f, ImVec2(pos.x + totalW + 4.0f, pos.y + totalH * 0.5f - ds.y * 0.5f), C(ImColor(70,70,85)), dimStr);
    float detVal = 0.0f;
    if (rows == 2 && cols == 2) detVal = matrix[0] * matrix[3] - matrix[1] * matrix[2];
    if (rows == 3 && cols == 3)
    {
        detVal = matrix[0] * (matrix[4] * matrix[8] - matrix[5] * matrix[7])
               - matrix[1] * (matrix[3] * matrix[8] - matrix[5] * matrix[6])
               + matrix[2] * (matrix[3] * matrix[7] - matrix[4] * matrix[6]);
    }
    if (rows == 2 || rows == 3)
    {
        char detStr[32];
        snprintf(detStr, sizeof(detStr), "det=%.2f", detVal);
        ImVec2 dts = ImGui::CalcTextSize(detStr);
        dl->AddText(ImGui::GetFont(), 9.0f, ImVec2(pos.x + totalW * 0.5f - dts.x * 0.5f, pos.y + totalH + 3.0f), C(detVal < 0.01f && detVal > -0.01f ? ImColor(120,120,135) : ImColor(200,200,215)), detStr);
    }
}

void M_HeatmapGrid(ImDrawList* dl, const char* label, float* data, int rows, int cols, ImVec2 pos, float cellW, float cellH, float minVal, float maxVal)
{
    float range = maxVal - minVal;
    if (range < 0.0001f) range = 1.0f;
    for (int r = 0; r < rows; ++r)
    {
        for (int c = 0; c < cols; ++c)
        {
            float val = data[r * cols + c];
            float norm = (val - minVal) / range;
            float rCol, gCol, bCol;
            if (norm < 0.5f)
            {
                float f = norm / 0.5f;
                rCol = 0.05f + f * 0.9f;
                gCol = 0.05f + f * 0.9f;
                bCol = 0.3f + f * 0.7f;
            }
            else
            {
                float f = (norm - 0.5f) / 0.5f;
                rCol = 0.95f + f * 0.05f;
                gCol = 0.95f - f * 0.7f;
                bCol = 1.0f - f * 0.8f;
            }
            ImColor cellCol(rCol, gCol, bCol);
            ImVec2 p0 = ImVec2(pos.x + c * cellW, pos.y + r * cellH);
            ImVec2 p1 = ImVec2(p0.x + cellW, p0.y + cellH);
            dl->AddRectFilled(p0, p1, C(cellCol));
            dl->AddRect(p0, p1, C(ImColor(40,40,50)));
        }
    }
    ImVec2 ls = ImGui::CalcTextSize(label);
    dl->AddText(ImGui::GetFont(), 9.0f, ImVec2(pos.x + cols * cellW * 0.5f - ls.x * 0.5f, pos.y - ls.y - 2.0f), C(ImColor(120,120,135)), label);
}

void M_GaugeBar(ImDrawList* dl, const char* label, float value, float maxValue, ImVec2 pos, float width, float height, ImColor accent, bool showLabel)
{
    float fill = (maxValue > 0) ? ImClamp(value / maxValue, 0.0f, 1.0f) : 0.0f;
    ImVec2 p1 = ImVec2(pos.x + width, pos.y + height);
    dl->AddRectFilled(pos, p1, C(ImColor(35,35,45)), height * 0.5f);
    if (fill > 0.01f)
    {
        ImVec2 f1 = ImVec2(pos.x + fill * width, pos.y + height);
        dl->AddRectFilled(pos, f1, C(accent), height * 0.5f);
    }
    dl->AddRect(pos, p1, C(ImColor(55,55,68)), height * 0.5f);
    if (showLabel)
    {
        char buf[32];
        snprintf(buf, sizeof(buf), "%s: %.1f/%.1f", label, value, maxValue);
        ImVec2 ts = ImGui::CalcTextSize(buf);
        dl->AddText(ImGui::GetFont(), 11.0f, ImVec2(pos.x + 6.0f, pos.y + (height - ts.y) * 0.5f), C(ImColor(200,200,215)), buf);
    }
}
