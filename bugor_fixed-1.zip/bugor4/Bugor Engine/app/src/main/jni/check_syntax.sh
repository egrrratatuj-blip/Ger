#!/system/bin/sh
MKDIR="$(dirname "$0")"
cd "$MKDIR" || exit 1
MKFILE="Android.mk"
if [ ! -f "$MKFILE" ]; then
  echo "ERROR: $MKFILE not found"
  exit 1
fi
FILES=$(grep -E '\.cpp' "$MKFILE" | grep -v 'LOCAL_' | sed 's/^[[:space:]]*//; s/[[:space:]]*\\$//')
MISSING=0
COUNT=0
for f in $FILES; do
  COUNT=$((COUNT + 1))
  if [ ! -f "$f" ]; then
    echo "MISSING: $f"
    MISSING=$((MISSING + 1))
  fi
done
echo "---"
echo "Total files checked: $COUNT"
echo "Missing files: $MISSING"
if [ "$MISSING" -gt 0 ]; then
  echo "SOME FILES ARE MISSING"
  exit 1
else
  echo "ALL FILES EXIST"
  exit 0
fi
