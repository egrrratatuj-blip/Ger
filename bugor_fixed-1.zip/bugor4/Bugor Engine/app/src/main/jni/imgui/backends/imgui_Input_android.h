#pragma once
#include "imgui.h"

#ifndef IM_DOWN
    #define IM_DOWN 0
#endif
#ifndef IM_MOVE
    #define IM_MOVE 2
#endif 
#ifndef IM_UP
    #define IM_UP 1
#endif

typedef struct {
    int Action;
    float x;
    float y;
    int VSCOLL;
    int HSCROLL;
    int ToolType;
    int ButtonState;
    float AXIS_VSCROLL;
    float AXIS_HSCROLL;
} MyInputEvent;

struct ImGuInput_LinuxEvent {
    int Action_type;
    int fingerIndex;
    ImVec2 pos;
    float pressure;
};

#define MAX_TOUCH_POINTS 10

struct TouchPoint {
    int id;
    bool active;
    ImVec2 pos;
    ImVec2 lastPos;
    float pressure;
    double downTime;
};

IMGUI_IMPL_API int32_t ImGui_ImplAndroid_HandleInputEvent(MyInputEvent input_event);
IMGUI_IMPL_API int32_t ImGui_ImplLinux_HandleInputEvent(ImGuInput_LinuxEvent event);
IMGUI_IMPL_API const TouchPoint* ImGui_GetTouchPoints(int* count);
IMGUI_IMPL_API void ImGui_TouchReset();
