#include "imgui_Custom.h"
#include <cmath>

static ImU32 ColorToU32(const ImColor &c) {
    return ImGui::ColorConvertFloat4ToU32(ImVec4(c.Value.x, c.Value.y, c.Value.z, c.Value.w));
}

static ImU32 ColorToU32(const ImVec4 &c) {
    return ImGui::ColorConvertFloat4ToU32(c);
}

static float easeOutQuad(float t) {
    return t * (2.0f - t);
}

static float easeOutBack(float t) {
    float c1 = 1.70158f;
    float c3 = c1 + 1.0f;
    return 1.0f + c3 * powf(t - 1.0f, 3.0f) + c1 * powf(t - 1.0f, 2.0f);
}

static float easeInOutQuad(float t) {
    return t < 0.5f ? 2.0f * t * t : 1.0f - powf(-2.0f * t + 2.0f, 2.0f) * 0.5f;
}

struct SwitchAnimData {
    ImGuiID id;
    AnimFloat circlePos;
    AnimFloat glowAlpha;
    AnimFloat hoverScale;
    float lastFrameTime;
};

static ImVector<SwitchAnimData> s_SwitchAnims;

static SwitchAnimData* FindOrCreateSwitchAnim(ImGuiID id) {
    for (int i = 0; i < s_SwitchAnims.Size; i++) {
        if (s_SwitchAnims[i].id == id) return &s_SwitchAnims[i];
    }
    SwitchAnimData d;
    d.id = id;
    d.circlePos = AnimFloat(0.0f, 9.0f);
    d.glowAlpha = AnimFloat(0.0f, 7.0f);
    d.hoverScale = AnimFloat(1.0f, 12.0f);
    d.lastFrameTime = 0;
    s_SwitchAnims.push_back(d);
    return &s_SwitchAnims[s_SwitchAnims.Size - 1];
}

bool ImGui::M_SwitchCircle(const char *id, bool *v, const ImVec2 &size) {
    if (size.y > size.x) return false;
    ImGuiWindow *win = GetCurrentWindow();
    if (win->SkipItems) return false;
    ImGuiContext &g = *GImGui;
    const ImGuiStyle &style = g.Style;
    const ImGuiID uid = win->GetID(id);
    ImVec2 pos = win->DC.CursorPos;
    const ImVec2 labelSize = CalcTextSize(id, NULL, true);
    const float spacing = 8.0f;
    const float totalWidth = size.x + labelSize.x + spacing;
    const ImRect totalBb(pos, ImVec2(pos.x + totalWidth, pos.y + size.y));
    ItemSize(totalBb, style.FramePadding.y);
    if (!ItemAdd(totalBb, uid)) return false;
    bool hovered, held;
    bool pressed = ButtonBehavior(totalBb, uid, &hovered, &held);
    if (pressed) { *v = !(*v); MarkItemEdited(uid); }

    SwitchAnimData *anim = FindOrCreateSwitchAnim(uid);
    float dt = ImGui::GetIO().DeltaTime;
    anim->circlePos.SetTarget(*v ? 1.0f : 0.0f);
    anim->glowAlpha.SetTarget(*v ? 1.0f : 0.0f);
    anim->hoverScale.SetTarget((hovered || held) ? 1.08f : 1.0f);
    anim->circlePos.Update(dt);
    anim->glowAlpha.Update(dt);
    anim->hoverScale.Update(dt);

    float t = anim->circlePos.Get();
    float easedT = easeOutQuad(t);

    float trackHeight = size.y * 0.5f;
    float trackY = pos.y + (size.y - trackHeight) * 0.5f;
    float trackRadius = trackHeight * 0.5f;
    float circleRadius = (size.y - 8.0f) * 0.5f * anim->hoverScale.Get();
    float circleInset = 4.0f;
    float trackLeft = pos.x + circleRadius + circleInset;
    float trackRight = pos.x + size.x - circleRadius - circleInset;
    float circleX = ImLerp(trackLeft, trackRight, easedT);
    float circleY = pos.y + size.y * 0.5f;

    ImColor trackOff(55, 55, 75, 180);
    ImColor trackOnA(0, 200, 255, 80);
    ImColor trackOnB(100, 50, 255, 80);
    ImColor circleOffCol(140, 140, 160, 255);
    ImColor circleOnCol(220, 220, 255, 255);
    ImColor glowCol(0, 200, 255, (int)(60.0f * anim->glowAlpha.Get()));

    ImU32 trackCol = ColorToU32(ImLerp(trackOff, trackOnA, easedT));
    float glowRadius = circleRadius * 2.0f;
    float alpha = anim->glowAlpha.Get() * 0.3f;
    if (alpha > 0.01f) {
        win->DrawList->AddCircleFilled(ImVec2(circleX, circleY), glowRadius,
            ColorToU32(ImVec4(0, 0.8f, 1, alpha)), 0);
    }

    win->DrawList->AddRectFilled(
        ImVec2(pos.x, trackY),
        ImVec2(pos.x + size.x, trackY + trackHeight),
        trackCol, trackRadius);

    if (t > 0.01f) {
        ImVec2 gradStart = ImVec2(pos.x, trackY);
        ImVec2 gradEnd = ImVec2(pos.x + size.x * t, trackY + trackHeight);
        ImU32 colA = ColorToU32(ImVec4(0, 0.7f, 1, 0.3f * t));
        ImU32 colB = ColorToU32(ImVec4(0.4f, 0.2f, 1, 0.2f * t));
        win->DrawList->AddRectFilledMultiColor(gradStart, gradEnd, colA, colB, colB, colA);
    }

    ImU32 shadowCol = ColorToU32(ImVec4(0, 0, 0, 0.25f));
    win->DrawList->AddCircleFilled(ImVec2(circleX + 1.5f, circleY + 1.5f),
        circleRadius + 1, shadowCol, 32);

    ImColor circleColor = ImLerp(circleOffCol, circleOnCol, easedT);
    win->DrawList->AddCircleFilled(ImVec2(circleX, circleY),
        circleRadius, ColorToU32(circleColor), 32);

    ImU32 borderCol = ColorToU32(ImVec4(1, 1, 1, 0.15f + 0.2f * easedT));
    win->DrawList->AddCircle(ImVec2(circleX, circleY),
        circleRadius, borderCol, 32, 1.0f);

    if (labelSize.x > 0) {
        float textY = pos.y + (size.y - labelSize.y) * 0.5f;
        ImColor textCol = ImLerp(ImColor(180, 180, 200), ImColor(220, 220, 255), easedT);
        RenderText(ImVec2(pos.x + size.x + spacing, textY), id);
    }
    return pressed;
}

bool ImGui::M_Tab(const char *label, bool active, const ImVec2 &size) {
    ImVec4 col = active ? ImVec4(0, 0.7f, 1, 1) : ImVec4(0.12f, 0.12f, 0.2f, 1);
    PushStyleColor(ImGuiCol_Button, col);
    PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0, 0.5f, 0.8f, 1));
    PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0, 0.8f, 1, 1));
    bool ret = Button(label, size);
    PopStyleColor(3);
    return ret;
}

bool ImGui::M_ColoredButton(const char *label, const ImVec4 &col, const ImVec2 &size) {
    PushStyleColor(ImGuiCol_Button, col);
    PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(col.x + 0.1f, col.y + 0.1f, col.z + 0.1f, 1));
    PushStyleColor(ImGuiCol_ButtonActive, ImVec4(col.x + 0.2f, col.y + 0.2f, col.z + 0.2f, 1));
    bool ret = Button(label, size);
    PopStyleColor(3);
    return ret;
}

void ImGui::M_ProgressBar(float val, const ImVec2 &size, const char *suffix, const ImVec4 &col) {
    PushStyleColor(ImGuiCol_PlotHistogram, col);
    ProgressBar(val, size, suffix);
    PopStyleColor();
}

struct CheckboxAnimData {
    ImGuiID id;
    AnimFloat checkScale;
    AnimFloat bgAnim;
    float lastFrameTime;
};

static ImVector<CheckboxAnimData> s_CheckAnims;

static CheckboxAnimData* FindOrCreateCheckAnim(ImGuiID id) {
    for (int i = 0; i < s_CheckAnims.Size; i++) {
        if (s_CheckAnims[i].id == id) return &s_CheckAnims[i];
    }
    CheckboxAnimData d;
    d.id = id;
    d.checkScale = AnimFloat(0.0f, 10.0f);
    d.bgAnim = AnimFloat(0.0f, 8.0f);
    s_CheckAnims.push_back(d);
    return &s_CheckAnims[s_CheckAnims.Size - 1];
}

bool ImGui::M_AnimatedCheckbox(const char *label, bool *v) {
    ImGuiWindow *win = GetCurrentWindow();
    if (win->SkipItems) return false;
    ImGuiContext &g = *GImGui;
    const ImGuiStyle &style = g.Style;
    const ImGuiID uid = win->GetID(label);
    ImVec2 pos = win->DC.CursorPos;
    const ImVec2 labelSize = CalcTextSize(label, NULL, true);
    float cbSize = 20.0f;
    float totalWidth = cbSize + style.ItemInnerSpacing.x + labelSize.x;
    const ImRect totalBb(pos, ImVec2(pos.x + totalWidth, pos.y + ImMax(cbSize, labelSize.y)));
    ItemSize(totalBb, style.FramePadding.y);
    if (!ItemAdd(totalBb, uid)) return false;
    bool hovered, held;
    bool pressed = ButtonBehavior(totalBb, uid, &hovered, &held);
    if (pressed) {
        *v = !(*v);
        MarkItemEdited(uid);
    }

    CheckboxAnimData *anim = FindOrCreateCheckAnim(uid);
    float dt = ImGui::GetIO().DeltaTime;
    anim->bgAnim.SetTarget(*v ? 1.0f : 0.0f);
    anim->checkScale.SetTarget(*v ? 1.0f : 0.0f);
    if (pressed) {
        anim->checkScale.Set(0.3f);
        anim->checkScale.SetTarget(*v ? 1.0f : 0.0f);
    }
    anim->bgAnim.Update(dt);
    anim->checkScale.Update(dt);

    ImVec2 cbPos(pos.x, pos.y + (totalBb.GetHeight() - cbSize) * 0.5f);
    float t = anim->bgAnim.Get();
    ImColor bgCol = ImLerp(ImColor(40, 40, 55, 200), ImColor(0, 180, 255, 200), t);
    ImColor borderCol = ImLerp(ImColor(70, 70, 90), ImColor(0, 220, 255), t);

    win->DrawList->AddRectFilled(cbPos, ImVec2(cbPos.x + cbSize, cbPos.y + cbSize),
        ColorToU32(bgCol), 4.0f);
    win->DrawList->AddRect(cbPos, ImVec2(cbPos.x + cbSize, cbPos.y + cbSize),
        ColorToU32(borderCol), 4.0f, 0, 1.5f);

    float checkScale = anim->checkScale.Get();
    if (checkScale > 0.01f) {
        ImVec2 center(cbPos.x + cbSize * 0.5f, cbPos.y + cbSize * 0.5f);
        float s = checkScale * 0.35f;
        float halfW = cbSize * s;
        ImVec2 p1(center.x - halfW * 0.6f, center.y);
        ImVec2 p2(center.x - halfW * 0.15f, center.y + halfW * 0.7f);
        ImVec2 p3(center.x + halfW * 0.8f, center.y - halfW * 0.5f);
        float thickness = 2.0f * ImMin(1.0f, checkScale * 2.0f);
        ImU32 checkCol = ColorToU32(ImVec4(1, 1, 1, checkScale));
        win->DrawList->AddLine(p1, p2, checkCol, thickness);
        win->DrawList->AddLine(p2, p3, checkCol, thickness);
    }

    if (labelSize.x > 0) {
        float textY = pos.y + (totalBb.GetHeight() - labelSize.y) * 0.5f;
        ImColor textCol = ImLerp(ImColor(180, 180, 200), ImColor(255, 255, 255), t);
        RenderText(ImVec2(pos.x + cbSize + style.ItemInnerSpacing.x, textY), label);
    }
    return pressed;
}

bool ImGui::M_Checkbox(const char *label, bool *v) {
    return Checkbox(label, v);
}

void ImGui::M_Separator(const ImVec4 &col) {
    ImGuiWindow *win = GetCurrentWindow();
    if (win->SkipItems) return;
    ImVec2 pos = win->DC.CursorPos;
    float width = GetContentRegionAvail().x;
    win->DrawList->AddLine(ImVec2(pos.x, pos.y + 1), ImVec2(pos.x + width, pos.y + 1),
        col, 1);
    SetCursorPosY(pos.y + 6);
}

void ImGui::M_Header(const char *label) {
    ImGui::TextColored(ImVec4(0, 0.7f, 1, 1), label);
    ImGui::Separator();
}

bool ImGui::M_SliderFloat(const char *label, float *v, float min, float max, const char *fmt) {
    PushItemWidth(GetContentRegionAvail().x * 0.6f);
    bool ret = SliderFloat(label, v, min, max, fmt);
    PopItemWidth();
    return ret;
}

struct ButtonAnimData {
    ImGuiID id;
    AnimFloat scale;
    AnimFloat opacity;
    AnimFloat glowAlpha;
};

static ImVector<ButtonAnimData> s_ButtonAnims;

static ButtonAnimData* FindOrCreateButtonAnim(ImGuiID id) {
    for (int i = 0; i < s_ButtonAnims.Size; i++) {
        if (s_ButtonAnims[i].id == id) return &s_ButtonAnims[i];
    }
    ButtonAnimData d;
    d.id = id;
    d.scale = AnimFloat(1.0f, 12.0f);
    d.opacity = AnimFloat(1.0f, 10.0f);
    d.glowAlpha = AnimFloat(0.0f, 8.0f);
    s_ButtonAnims.push_back(d);
    return &s_ButtonAnims[s_ButtonAnims.Size - 1];
}

bool ImGui::M_GradientButton(const char *label, const ImVec2 &size_arg, ImColor color1, ImColor color2) {
    ImGuiWindow *win = GetCurrentWindow();
    if (win->SkipItems) return false;
    ImGuiContext &g = *GImGui;
    const ImGuiStyle &style = g.Style;
    const ImGuiID uid = win->GetID(label);
    ImVec2 pos = win->DC.CursorPos;
    ImVec2 size = CalcItemSize(size_arg, CalcItemWidth(), style.FramePadding.y * 2.0f + 20.0f);
    const ImRect bb(pos, ImVec2(pos.x + size.x, pos.y + size.y));
    ItemSize(size, style.FramePadding.y);
    if (!ItemAdd(bb, uid)) return false;
    bool hovered, held;
    bool pressed = ButtonBehavior(bb, uid, &hovered, &held);

    ButtonAnimData *anim = FindOrCreateButtonAnim(uid);
    float dt = ImGui::GetIO().DeltaTime;
    anim->scale.SetTarget(held ? 0.95f : (hovered ? 1.03f : 1.0f));
    anim->opacity.SetTarget(held ? 0.85f : 1.0f);
    anim->glowAlpha.SetTarget(hovered ? 1.0f : 0.0f);
    anim->scale.Update(dt);
    anim->opacity.Update(dt);
    anim->glowAlpha.Update(dt);

    ImVec2 center = bb.GetCenter();
    float s = anim->scale.Get();
    ImVec2 scaledPos = ImLerp(center, bb.Min, s);
    ImVec2 scaledSize = size * s;

    float glow = anim->glowAlpha.Get() * 8.0f;
    if (glow > 0.5f) {
        ImU32 glowCol = ColorToU32(ImVec4(color1.Value.x, color1.Value.y, color1.Value.z, glow * 0.15f));
        ImVec2 gp1(scaledPos.x - glow, scaledPos.y - glow);
        ImVec2 gp2(scaledPos.x + scaledSize.x + glow, scaledPos.y + scaledSize.y + glow);
        win->DrawList->AddRectFilled(gp1, gp2, glowCol, 6.0f + glow * 0.3f);
    }

    ImU32 colA = ColorToU32(ImVec4(color1.Value.x, color1.Value.y, color1.Value.z, anim->opacity.Get()));
    ImU32 colB = ColorToU32(ImVec4(color2.Value.x, color2.Value.y, color2.Value.z, anim->opacity.Get()));
    win->DrawList->AddRectFilledMultiColor(
        scaledPos,
        ImVec2(scaledPos.x + scaledSize.x, scaledPos.y + scaledSize.y),
        colA, colB, colB, colA, 6.0f);

    ImU32 borderCol = ColorToU32(ImVec4(1, 1, 1, 0.1f + 0.15f * hovered));
    win->DrawList->AddRect(scaledPos,
        ImVec2(scaledPos.x + scaledSize.x, scaledPos.y + scaledSize.y),
        borderCol, 6.0f, 0, 1.0f);

    ImVec2 textSize = CalcTextSize(label, NULL, true);
    float textX = center.x - textSize.x * 0.5f;
    float textY = scaledPos.y + (scaledSize.y - textSize.y) * 0.5f;
    ImColor textCol = ImLerp(ImColor(200, 200, 220), ImColor(255, 255, 255), hovered ? 1.0f : 0.5f);
    RenderText(ImVec2(textX, textY), label);

    return pressed;
}

void ImGui::M_GlowRect(ImVec2 p1, ImVec2 p2, ImColor col, float radius, float glowSize, int steps) {
    ImGuiWindow *win = GetCurrentWindow();
    if (win->SkipItems) return;
    for (int i = steps; i > 0; i--) {
        float t = (float)i / (float)steps;
        float expand = glowSize * t;
        float alpha = col.Value.w * t * 0.15f;
        ImU32 c = ColorToU32(ImVec4(col.Value.x, col.Value.y, col.Value.z, alpha));
        win->DrawList->AddRect(
            ImVec2(p1.x - expand, p1.y - expand),
            ImVec2(p2.x + expand, p2.y + expand),
            c, radius + expand * 0.3f, 0, 1.0f + t * 1.0f);
    }
}

void ImGui::M_TextShadow(const char *text, ImVec2 pos, ImColor col, float shadowOffset) {
    ImGuiWindow *win = GetCurrentWindow();
    if (win->SkipItems) return;
    ImU32 shadowCol = ColorToU32(ImVec4(0, 0, 0, col.Value.w * 0.5f));
    win->DrawList->AddText(ImVec2(pos.x + shadowOffset, pos.y + shadowOffset), shadowCol, text);
    win->DrawList->AddText(pos, ColorToU32(col), text);
}

void ImGui::M_CyberHeader(const char *label, ImColor accent) {
    ImGuiWindow *win = GetCurrentWindow();
    if (win->SkipItems) return;
    ImVec2 pos = win->DC.CursorPos;
    float width = GetContentRegionAvail().x;
    ImVec2 textSize = CalcTextSize(label, NULL, true);
    win->DrawList->AddText(ImVec2(pos.x, pos.y), ColorToU32(accent), label);
    float lineY = pos.y + textSize.y + 4.0f;
    win->DrawList->AddRectFilled(ImVec2(pos.x, lineY), ImVec2(pos.x + textSize.x + 8.0f, lineY + 2.0f),
        ColorToU32(accent), 1.0f);
    SetCursorPosY(lineY + 8.0f);
}

struct CollapseAnimData {
    ImGuiID id;
    AnimFloat arrowRotation;
    float lastFrameTime;
};

static ImVector<CollapseAnimData> s_CollapseAnims;

static CollapseAnimData* FindOrCreateCollapseAnim(ImGuiID id) {
    for (int i = 0; i < s_CollapseAnims.Size; i++) {
        if (s_CollapseAnims[i].id == id) return &s_CollapseAnims[i];
    }
    CollapseAnimData d;
    d.id = id;
    d.arrowRotation = AnimFloat(0.0f, 10.0f);
    s_CollapseAnims.push_back(d);
    return &s_CollapseAnims[s_CollapseAnims.Size - 1];
}

bool ImGui::M_AnimatedCollapsingHeader(const char *label, ImColor accent, bool *open) {
    ImGuiWindow *win = GetCurrentWindow();
    if (win->SkipItems) return false;
    ImGuiContext &g = *GImGui;
    const ImGuiID uid = win->GetID(label);
    ImVec2 pos = win->DC.CursorPos;
    float width = GetContentRegionAvail().x;
    ImVec2 textSize = CalcTextSize(label, NULL, true);
    float headerHeight = textSize.y + 12.0f;
    const ImRect bb(pos, ImVec2(pos.x + width, pos.y + headerHeight));
    ItemSize(bb);
    if (!ItemAdd(bb, uid)) return false;
    bool hovered, held;
    bool pressed = ButtonBehavior(bb, uid, &hovered, &held);

    if (pressed && open) { *open = !(*open); MarkItemEdited(uid); }

    CollapseAnimData *anim = FindOrCreateCollapseAnim(uid);
    float dt = ImGui::GetIO().DeltaTime;
    if (open) anim->arrowRotation.SetTarget(*open ? 1.0f : 0.0f);
    anim->arrowRotation.Update(dt);
    float rotT = easeInOutQuad(anim->arrowRotation.Get());

    ImU32 bgCol = ColorToU32(ImVec4(0.08f, 0.08f, 0.12f, hovered ? 0.6f : 0.4f));
    win->DrawList->AddRectFilled(pos, ImVec2(pos.x + width, pos.y + headerHeight), bgCol, 4.0f);

    ImU32 accentCol = ColorToU32(accent);
    win->DrawList->AddRectFilled(ImVec2(pos.x, pos.y + headerHeight - 1),
        ImVec2(pos.x + width, pos.y + headerHeight),
        ColorToU32(ImVec4(accent.Value.x, accent.Value.y, accent.Value.z, 0.2f)), 0);

    float arrowSize = 8.0f;
    float arrowX = pos.x + 12.0f;
    float arrowY = pos.y + headerHeight * 0.5f;
    float angle = rotT * IM_PI * 0.5f;
    float cosA = cosf(angle);
    float sinA = sinf(angle);
    ImVec2 arrowP1(arrowX - arrowSize * 0.7f, arrowY - arrowSize * 0.5f);
    ImVec2 arrowP2(arrowX, arrowY + arrowSize * 0.5f);
    ImVec2 arrowP3(arrowX + arrowSize * 0.7f, arrowY - arrowSize * 0.5f);
    ImVec2 c(arrowX, arrowY);
    auto rot = [&](ImVec2 p) -> ImVec2 {
        float dx = p.x - c.x, dy = p.y - c.y;
        return ImVec2(c.x + dx * cosA - dy * sinA, c.y + dx * sinA + dy * cosA);
    };
    win->DrawList->AddTriangleFilled(rot(arrowP1), rot(arrowP2), rot(arrowP3), accentCol);

    float textX = pos.x + 26.0f;
    float textY = pos.y + (headerHeight - textSize.y) * 0.5f;
    win->DrawList->AddText(ImVec2(textX, textY), ColorToU32(ImColor(200, 200, 220)), label);

    SetCursorPosY(pos.y + headerHeight + 4.0f);
    return pressed;
}
