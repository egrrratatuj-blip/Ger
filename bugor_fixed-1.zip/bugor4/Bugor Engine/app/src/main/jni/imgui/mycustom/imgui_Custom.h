#pragma once
#include "imgui.h"
#include "imgui_internal.h"

namespace ImGui {

struct AnimFloat {
    float current;
    float target;
    float speed;
    AnimFloat() : current(0), target(0), speed(8.0f) {}
    AnimFloat(float v, float s = 8.0f) : current(v), target(v), speed(s) {}
    void Update(float dt = ImGui::GetIO().DeltaTime) {
        if (fabsf(current - target) > 0.001f)
            current += (target - current) * ImClamp(speed * dt, 0.0f, 1.0f);
        else { current = target; }
    }
    void SetTarget(float t) { target = t; }
    void Set(float v) { current = target = v; }
    bool IsDone() const { return fabsf(current - target) < 0.001f; }
    float Get() const { return current; }
};

struct AnimColor {
    ImColor current;
    ImColor target;
    float speed;
    AnimColor() : current(0,0,0,0), target(0,0,0,0), speed(6.0f) {}
    AnimColor(ImColor c, float s = 6.0f) : current(c), target(c), speed(s) {}
    void Update(float dt = ImGui::GetIO().DeltaTime) {
        float t = ImClamp(speed * dt, 0.0f, 1.0f);
        current.Value.x += (target.Value.x - current.Value.x) * t;
        current.Value.y += (target.Value.y - current.Value.y) * t;
        current.Value.z += (target.Value.z - current.Value.z) * t;
        current.Value.w += (target.Value.w - current.Value.w) * t;
    }
    void SetTarget(ImColor c) { target = c; }
    void Set(ImColor c) { current = target = c; }
    bool IsDone() const {
        return fabsf(current.Value.x - target.Value.x) < 0.001f &&
               fabsf(current.Value.y - target.Value.y) < 0.001f &&
               fabsf(current.Value.z - target.Value.z) < 0.001f;
    }
    ImColor Get() const { return current; }
    ImVec4 GetVec4() const {
        return ImVec4(current.Value.x, current.Value.y, current.Value.z, current.Value.w);
    }
};

IMGUI_API bool M_SwitchCircle(const char *id, bool *v, const ImVec2 &size = ImVec2(90, 36));
IMGUI_API bool M_Tab(const char *label, bool active, const ImVec2 &size);
IMGUI_API bool M_ColoredButton(const char *label, const ImVec4 &col, const ImVec2 &size);
IMGUI_API void M_ProgressBar(float val, const ImVec2 &size, const char *suffix, const ImVec4 &col);
IMGUI_API bool M_AnimatedCheckbox(const char *label, bool *v);
IMGUI_API bool M_Checkbox(const char *label, bool *v);
IMGUI_API void M_Separator(const ImVec4 &col);
IMGUI_API void M_Header(const char *label);
IMGUI_API bool M_SliderFloat(const char *label, float *v, float min, float max, const char *fmt);
IMGUI_API bool M_GradientButton(const char *label, const ImVec2 &size, ImColor color1, ImColor color2);
IMGUI_API void M_GlowRect(ImVec2 p1, ImVec2 p2, ImColor col, float radius, float glowSize, int steps = 6);
IMGUI_API void M_TextShadow(const char *text, ImVec2 pos, ImColor col, float shadowOffset = 1.0f);
IMGUI_API void M_CyberHeader(const char *label, ImColor accent);
IMGUI_API bool M_AnimatedCollapsingHeader(const char *label, ImColor accent, bool *open);

}
