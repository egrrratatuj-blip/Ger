#include "imgui.h"
#include "imgui_Input_android.h"
#include <time.h>
#include <android/native_window.h>
#include <android/input.h>
#include <android/keycodes.h>
#include <string.h>

static TouchPoint g_TouchPoints[MAX_TOUCH_POINTS];
static double g_CurrentTime = 0.0;

static void UpdateTime() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    g_CurrentTime = (double)ts.tv_sec + (double)ts.tv_nsec / 1000000000.0;
}

int32_t ImGui_ImplAndroid_HandleInputEvent(MyInputEvent input_event)
{
    ImGuiIO& io = ImGui::GetIO();
    int32_t event_action = input_event.Action;
    event_action &= AMOTION_EVENT_ACTION_MASK;
    switch (event_action)
    {
    case AMOTION_EVENT_ACTION_DOWN:
    case AMOTION_EVENT_ACTION_UP:
        if((input_event.ToolType == AMOTION_EVENT_TOOL_TYPE_FINGER)
        || (input_event.ToolType == AMOTION_EVENT_TOOL_TYPE_UNKNOWN))
        {
            io.MouseDown[0] = (event_action == AMOTION_EVENT_ACTION_DOWN) ? true : false;
            io.MousePos = ImVec2(input_event.x, input_event.y);
        }
        break;
    case AMOTION_EVENT_ACTION_BUTTON_PRESS:
    case AMOTION_EVENT_ACTION_BUTTON_RELEASE:
        {
            int32_t button_state = input_event.ButtonState;
            io.MouseDown[0] = (button_state & AMOTION_EVENT_BUTTON_PRIMARY) ? true : false;
            io.MouseDown[1] = (button_state & AMOTION_EVENT_BUTTON_SECONDARY) ? true : false;
            io.MouseDown[2] = (button_state & AMOTION_EVENT_BUTTON_TERTIARY) ? true : false;
        }
        break;
    case AMOTION_EVENT_ACTION_HOVER_MOVE:
    case AMOTION_EVENT_ACTION_MOVE:
        io.MousePos = ImVec2(input_event.x, input_event.y);
        break;
    case AMOTION_EVENT_ACTION_SCROLL:
        io.MouseWheel = input_event.AXIS_VSCROLL;
        io.MouseWheelH = input_event.AXIS_HSCROLL;
        break;
    default:
        break;
    }
    return 1;
}

int32_t ImGui_ImplLinux_HandleInputEvent(ImGuInput_LinuxEvent event) {
    ImGuiIO& io = ImGui::GetIO();
    int id = event.fingerIndex;
    if (id < 0 || id >= MAX_TOUCH_POINTS)
        id = 0;

    UpdateTime();
    g_TouchPoints[id].id = id;

    switch (event.Action_type) {
    case IM_DOWN: {
        g_TouchPoints[id].active = true;
        g_TouchPoints[id].pos = event.pos;
        g_TouchPoints[id].lastPos = event.pos;
        g_TouchPoints[id].pressure = event.pressure;
        g_TouchPoints[id].downTime = g_CurrentTime;
        if (id == 0) {
            io.MouseDown[0] = true;
            io.MousePos = event.pos;
        }
        break;
    }
    case IM_UP: {
        g_TouchPoints[id].lastPos = g_TouchPoints[id].pos;
        g_TouchPoints[id].active = false;
        if (id == 0) {
            io.MouseDown[0] = false;
        }
        break;
    }
    case IM_MOVE: {
        g_TouchPoints[id].lastPos = g_TouchPoints[id].pos;
        g_TouchPoints[id].pos = event.pos;
        g_TouchPoints[id].pressure = event.pressure;
        if (id == 0) {
            io.MousePos = event.pos;
        }
        break;
    }
    default:
        break;
    }
    return 0;
}

const TouchPoint* ImGui_GetTouchPoints(int* count) {
    int activeCount = 0;
    for (int i = 0; i < MAX_TOUCH_POINTS; i++) {
        if (g_TouchPoints[i].active)
            activeCount++;
    }
    if (count)
        *count = activeCount;
    return g_TouchPoints;
}

void ImGui_TouchReset() {
    memset(g_TouchPoints, 0, sizeof(g_TouchPoints));
}
