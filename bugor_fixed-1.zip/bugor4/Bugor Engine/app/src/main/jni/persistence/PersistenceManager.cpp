#include "PersistenceManager.h"
#include <fstream>
#include <map>
#include <cstdio>
#include <cerrno>
#include <cinttypes>
#include <sys/stat.h>

PersistenceManager::PersistenceManager()
    : initialized(false)
    , transactionActive(false)
    , encrypted(false)
    , compressed(false)
    , cacheEnabled(true)
    , backend(StorageBackend::JSON)
    , sqlite(nullptr)
    , leveldb(nullptr)
    , blockCache(nullptr)
    , cacheHits(0)
    , cacheMisses(0)
    , backupThread(nullptr)
    , compactThread(nullptr)
    , syncThread(nullptr)
    , threadsRunning(false)
{
    memset(&stats, 0, sizeof(stats));
}

PersistenceManager::~PersistenceManager()
{
    shutdown();
}

bool PersistenceManager::initialize(const StorageConfig &config)
{
    if (initialized) return true;
    this->config = config;
    if (!config.base_path.empty()) createDirectory(config.base_path);
    if (!config.db_path.empty()) createDirectory(config.db_path.substr(0, config.db_path.rfind('/')));
    if (!config.cache_path.empty()) createDirectory(config.cache_path);
    if (!config.backup_path.empty()) createDirectory(config.backup_path);
    if (!config.temp_path.empty()) createDirectory(config.temp_path);
    threadsRunning = true;
    backupThread = new std::thread(&PersistenceManager::backupLoop, this);
    compactThread = new std::thread(&PersistenceManager::compactLoop, this);
    syncThread = new std::thread(&PersistenceManager::syncLoop, this);
    initialized = true;
    return true;
}

void PersistenceManager::shutdown()
{
    if (!initialized) return;
    threadsRunning = false;
    flush();
    if (backupThread) { backupThread->join(); delete backupThread; backupThread = nullptr; }
    if (compactThread) { compactThread->join(); delete compactThread; compactThread = nullptr; }
    if (syncThread) { syncThread->join(); delete syncThread; syncThread = nullptr; }
    if (sqlite) closeSQLite();
    if (leveldb) closeLevelDB();
    if (blockCache) delete blockCache;
    clearCacheInternal();
    initialized = false;
}

bool PersistenceManager::isInitialized() const
{
    return initialized;
}

bool PersistenceManager::open()
{
    if (!initialized) return false;
    if (config.db_path.empty()) return false;
    if (config.db_path.find(".db") != std::string::npos || config.db_path.find(".sqlite") != std::string::npos) {
        backend = StorageBackend::SQLite;
        return initSQLite(config.db_path);
    }
    backend = StorageBackend::JSON;
    return true;
}

bool PersistenceManager::close()
{
    if (sqlite) return closeSQLite();
    if (leveldb) return closeLevelDB();
    return true;
}

bool PersistenceManager::reopen()
{
    if (!close()) return false;
    return open();
}

bool PersistenceManager::store(const std::string &key, const std::string &value)
{
    if (!initialized) return false;
    std::lock_guard<std::mutex> lock(storageMutex);
    std::string final_value = value;
    if (encrypted) final_value = encryptString(final_value);
    if (compressed) final_value = compressString(final_value);
    if (sqlite) {
        std::string sql = "INSERT OR REPLACE INTO kv_store (key, value) VALUES ('" + key + "', '" + final_value + "')";
        if (!executeSQL(sql)) return false;
    } else if (leveldb) {
        leveldb::Status status = leveldb->Put(leveldb::WriteOptions(), key, final_value);
        if (!status.ok()) return false;
    }
    memoryCache[key] = final_value;
    cacheAccessTimes[key] = static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count());
    ++stats.write_count;
    if (changeCallback) changeCallback(key, value);
    return true;
}

bool PersistenceManager::store(const std::string &key, const std::vector<uint8_t> &value)
{
    return store(key, std::string(value.begin(), value.end()));
}

bool PersistenceManager::store(const std::string &key, int32_t value)
{
    return store(key, std::to_string(value));
}

bool PersistenceManager::store(const std::string &key, int64_t value)
{
    return store(key, std::to_string(value));
}

bool PersistenceManager::store(const std::string &key, float value)
{
    return store(key, std::to_string(value));
}

bool PersistenceManager::store(const std::string &key, double value)
{
    return store(key, std::to_string(value));
}

bool PersistenceManager::store(const std::string &key, bool value)
{
    return store(key, value ? "true" : "false");
}

bool PersistenceManager::storeBatch(const std::map<std::string, std::string> &entries)
{
    beginTransaction();
    bool all_ok = true;
    for (const auto &kv : entries) {
        if (!store(kv.first, kv.second)) all_ok = false;
    }
    if (all_ok) commitTransaction();
    else rollbackTransaction();
    return all_ok;
}

std::string PersistenceManager::getString(const std::string &key, const std::string &default_val)
{
    if (!initialized) return default_val;
    std::lock_guard<std::mutex> lock(storageMutex);
    std::string value;
    if (cacheEnabled) {
        value = getFromCache(key);
        if (!value.empty()) { ++cacheHits; return decryptString(decompressString(value)); }
    }
    ++cacheMisses;
    if (sqlite) {
        auto results = querySQL("SELECT value FROM kv_store WHERE key='" + key + "'");
        if (!results.empty()) value = results[0]["value"];
    } else if (leveldb) {
        std::string val;
        leveldb::Status status = leveldb->Get(leveldb::ReadOptions(), key, &val);
        if (status.ok()) value = val;
    } else {
        auto it = memoryCache.find(key);
        if (it != memoryCache.end()) value = it->second;
    }
    if (value.empty()) return default_val;
    if (compressed) value = decompressString(value);
    if (encrypted) value = decryptString(value);
    if (cacheEnabled) addToCache(key, value);
    ++stats.read_count;
    return value;
}

std::vector<uint8_t> PersistenceManager::getBytes(const std::string &key)
{
    std::string s = getString(key);
    return std::vector<uint8_t>(s.begin(), s.end());
}

int32_t PersistenceManager::getInt32(const std::string &key, int32_t default_val)
{
    std::string s = getString(key);
    return s.empty() ? default_val : static_cast<int32_t>(std::stol(s));
}

int64_t PersistenceManager::getInt64(const std::string &key, int64_t default_val)
{
    std::string s = getString(key);
    return s.empty() ? default_val : std::stoll(s);
}

float PersistenceManager::getFloat(const std::string &key, float default_val)
{
    std::string s = getString(key);
    return s.empty() ? default_val : std::stof(s);
}

double PersistenceManager::getDouble(const std::string &key, double default_val)
{
    std::string s = getString(key);
    return s.empty() ? default_val : std::stod(s);
}

bool PersistenceManager::getBool(const std::string &key, bool default_val)
{
    std::string s = getString(key);
    if (s.empty()) return default_val;
    return s == "true" || s == "1";
}

std::map<std::string, std::string> PersistenceManager::getBatch(const std::vector<std::string> &keys)
{
    std::map<std::string, std::string> result;
    for (const auto &k : keys) {
        std::string v = getString(k);
        if (!v.empty()) result[k] = v;
    }
    return result;
}

bool PersistenceManager::remove(const std::string &key)
{
    if (!initialized) return false;
    std::lock_guard<std::mutex> lock(storageMutex);
    if (sqlite) {
        if (!executeSQL("DELETE FROM kv_store WHERE key='" + key + "'")) return false;
    } else if (leveldb) {
        leveldb::Status status = leveldb->Delete(leveldb::WriteOptions(), key);
        if (!status.ok()) return false;
    }
    memoryCache.erase(key);
    invalidateCache(key);
    ++stats.delete_count;
    if (deleteCallback) deleteCallback(key);
    return true;
}

bool PersistenceManager::removeBatch(const std::vector<std::string> &keys)
{
    bool all_ok = true;
    for (const auto &k : keys) { if (!remove(k)) all_ok = false; }
    return all_ok;
}

bool PersistenceManager::removeByPrefix(const std::string &prefix)
{
    auto keys = getKeysByPrefix(prefix);
    return removeBatch(keys);
}

bool PersistenceManager::removeByPattern(const std::string &pattern)
{
    auto keys = getKeysByPattern(pattern);
    return removeBatch(keys);
}

bool PersistenceManager::clear()
{
    if (!initialized) return false;
    std::lock_guard<std::mutex> lock(storageMutex);
    if (sqlite) {
        if (!executeSQL("DELETE FROM kv_store")) return false;
    } else if (leveldb) {
        auto it = leveldb->NewIterator(leveldb::ReadOptions());
        for (it->SeekToFirst(); it->Valid(); it->Next()) {
            leveldb->Delete(leveldb::WriteOptions(), it->key());
        }
        delete it;
    }
    memoryCache.clear();
    clearCacheInternal();
    stats.total_entries = 0;
    return true;
}

bool PersistenceManager::hasKey(const std::string &key) const
{
    if (memoryCache.find(key) != memoryCache.end()) return true;
    if (sqlite) {
        auto results = const_cast<PersistenceManager*>(this)->querySQL("SELECT COUNT(*) as c FROM kv_store WHERE key='" + key + "'");
        if (!results.empty() && results[0]["c"] != "0") return true;
    }
    return false;
}

uint64_t PersistenceManager::getEntryCount() const
{
    return stats.total_entries;
}

std::vector<std::string> PersistenceManager::getKeys() const
{
    std::vector<std::string> keys;
    if (sqlite) {
        auto results = const_cast<PersistenceManager*>(this)->querySQL("SELECT key FROM kv_store");
        for (const auto &row : results) keys.push_back(row.at("key"));
    } else {
        for (const auto &kv : memoryCache) keys.push_back(kv.first);
    }
    return keys;
}

std::vector<std::string> PersistenceManager::getKeysByPrefix(const std::string &prefix) const
{
    std::vector<std::string> keys;
    for (const auto &kv : memoryCache) {
        if (kv.first.find(prefix) == 0) keys.push_back(kv.first);
    }
    return keys;
}

std::vector<std::string> PersistenceManager::getKeysByPattern(const std::string &pattern) const
{
    std::vector<std::string> keys;
    for (const auto &kv : memoryCache) {
        if (kv.first.find(pattern) != std::string::npos) keys.push_back(kv.first);
    }
    return keys;
}

std::vector<std::pair<std::string, std::string>> PersistenceManager::getAllEntries() const
{
    std::vector<std::pair<std::string, std::string>> entries;
    for (const auto &kv : memoryCache) entries.emplace_back(kv.first, kv.second);
    return entries;
}

std::vector<std::pair<std::string, std::string>> PersistenceManager::getEntriesByPrefix(const std::string &prefix) const
{
    std::vector<std::pair<std::string, std::string>> entries;
    for (const auto &kv : memoryCache) {
        if (kv.first.find(prefix) == 0) entries.emplace_back(kv.first, kv.second);
    }
    return entries;
}

bool PersistenceManager::beginTransaction()
{
    if (transactionActive) return false;
    transactionActive = true;
    if (sqlite) return executeSQL("BEGIN TRANSACTION");
    return true;
}

bool PersistenceManager::commitTransaction()
{
    if (!transactionActive) return false;
    transactionActive = false;
    if (sqlite) return executeSQL("COMMIT");
    return true;
}

bool PersistenceManager::rollbackTransaction()
{
    if (!transactionActive) return false;
    transactionActive = false;
    if (sqlite) return executeSQL("ROLLBACK");
    return true;
}

bool PersistenceManager::isTransactionActive() const
{
    return transactionActive;
}

bool PersistenceManager::compact()
{
    if (sqlite) return executeSQL("VACUUM");
    return false;
}

bool PersistenceManager::compactRange(const std::string &start, const std::string &end)
{
    (void)start;
    (void)end;
    return compact();
}

bool PersistenceManager::optimize()
{
    return compact();
}

bool PersistenceManager::analyze()
{
    if (sqlite) return executeSQL("ANALYZE");
    return true;
}

bool PersistenceManager::createBackup(const std::string &path)
{
    std::string backup_path = path.empty() ? (config.backup_path + "/backup_" + std::to_string(time(nullptr)) + ".db") : path;
    if (sqlite) {
        std::string sql = "VACUUM INTO '" + backup_path + "'";
        return executeSQL(sql);
    }
    std::ofstream out(backup_path);
    if (!out.is_open()) return false;
    for (const auto &kv : memoryCache) out << kv.first << "=" << kv.second << "\n";
    ++stats.backup_count;
    return out.good();
}

bool PersistenceManager::restoreBackup(const std::string &path)
{
    std::ifstream in(path);
    if (!in.is_open()) return false;
    clear();
    std::string line;
    while (std::getline(in, line)) {
        size_t eq = line.find('=');
        if (eq != std::string::npos) store(line.substr(0, eq), line.substr(eq + 1));
    }
    return true;
}

bool PersistenceManager::deleteBackup(const std::string &path)
{
    return std::remove(path.c_str()) == 0;
}

std::vector<std::string> PersistenceManager::listBackups() const
{
    std::vector<std::string> backups;
    DIR *d = opendir(config.backup_path.c_str());
    if (!d) return backups;
    struct dirent *entry;
    while ((entry = readdir(d)) != nullptr) {
        std::string name = entry->d_name;
        if (name.find("backup_") == 0) backups.push_back(config.backup_path + "/" + name);
    }
    closedir(d);
    return backups;
}

bool PersistenceManager::checkIntegrity()
{
    if (sqlite) {
        auto results = querySQL("PRAGMA integrity_check");
        return !results.empty() && results[0].begin()->second == "ok";
    }
    return true;
}

bool PersistenceManager::repair()
{
    return checkIntegrity();
}

bool PersistenceManager::vacuum()
{
    if (sqlite) return executeSQL("VACUUM");
    return false;
}

bool PersistenceManager::encrypt(const std::string &key)
{
    (void)key;
    encrypted = true;
    return true;
}

bool PersistenceManager::decrypt(const std::string &key)
{
    (void)key;
    encrypted = false;
    return true;
}

bool PersistenceManager::isEncrypted() const
{
    return encrypted;
}

bool PersistenceManager::compress()
{
    compressed = true;
    return true;
}

bool PersistenceManager::decompress()
{
    compressed = false;
    return true;
}

bool PersistenceManager::isCompressed() const
{
    return compressed;
}

bool PersistenceManager::importData(const std::string &path, const std::string &format)
{
    if (format == "csv") return importFromCSV(path);
    if (format == "json") {
        std::ifstream in(path);
        if (!in.is_open()) return false;
        std::stringstream ss;
        ss << in.rdbuf();
        auto entries = deserializeFromJSON(ss.str());
        return storeBatch(entries);
    }
    return false;
}

bool PersistenceManager::exportData(const std::string &path, const std::string &format)
{
    if (format == "csv") return exportToCSV(path);
    if (format == "json") {
        std::ofstream out(path);
        if (!out.is_open()) return false;
        out << serializeToJSON(getAllEntries());
        return out.good();
    }
    return false;
}

bool PersistenceManager::importFromCSV(const std::string &path)
{
    std::ifstream in(path);
    if (!in.is_open()) return false;
    std::string line;
    while (std::getline(in, line)) {
        size_t comma = line.find(',');
        if (comma != std::string::npos) store(line.substr(0, comma), line.substr(comma + 1));
    }
    return true;
}

bool PersistenceManager::exportToCSV(const std::string &path)
{
    std::ofstream out(path);
    if (!out.is_open()) return false;
    for (const auto &kv : getAllEntries()) out << kv.first << "," << kv.second << "\n";
    return out.good();
}

bool PersistenceManager::importFromSQL(const std::string &path)
{
    std::ifstream in(path);
    if (!in.is_open()) return false;
    std::string sql((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    return executeSQL(sql);
}

bool PersistenceManager::exportToSQL(const std::string &path)
{
    std::ofstream out(path);
    if (!out.is_open()) return false;
    out << "CREATE TABLE IF NOT EXISTS kv_store (key TEXT PRIMARY KEY, value TEXT);\n";
    for (const auto &kv : getAllEntries()) {
        out << "INSERT INTO kv_store VALUES ('" << kv.first << "', '" << kv.second << "');\n";
    }
    return out.good();
}

bool PersistenceManager::migrateSchema(uint32_t from_version, uint32_t to_version)
{
    (void)from_version;
    (void)to_version;
    return true;
}

uint32_t PersistenceManager::getSchemaVersion() const
{
    return 1;
}

bool PersistenceManager::setSchemaVersion(uint32_t version)
{
    return store("__schema_version", std::to_string(version));
}

StorageStats PersistenceManager::getStats() const
{
    return stats;
}

StorageConfig PersistenceManager::getConfig() const
{
    return config;
}

bool PersistenceManager::setConfig(const StorageConfig &config)
{
    this->config = config;
    return true;
}

bool PersistenceManager::setCacheEnabled(bool enable)
{
    cacheEnabled = enable;
    if (!enable) clearCache();
    return true;
}

bool PersistenceManager::isCacheEnabled() const
{
    return cacheEnabled;
}

bool PersistenceManager::clearCache()
{
    std::lock_guard<std::mutex> lock(cacheMutex);
    memoryCache.clear();
    return true;
}

uint64_t PersistenceManager::getCacheSize() const
{
    uint64_t size = 0;
    for (const auto &kv : memoryCache) size += kv.first.size() + kv.second.size();
    return size;
}

bool PersistenceManager::setEncryptionEnabled(bool enable)
{
    encrypted = enable;
    return true;
}

bool PersistenceManager::isEncryptionEnabled() const
{
    return encrypted;
}

void PersistenceManager::setEncryptionKey(const std::string &key)
{
    config.encryption_key = key;
}

bool PersistenceManager::setCompressionEnabled(bool enable)
{
    compressed = enable;
    return true;
}

bool PersistenceManager::isCompressionEnabled() const
{
    return compressed;
}

void PersistenceManager::setCompressionLevel(int level)
{
    config.compression_level = level;
}

void PersistenceManager::flush()
{
    sync();
}

void PersistenceManager::sync()
{
    if (sqlite) executeSQL("PRAGMA wal_checkpoint(TRUNCATE)");
}

void PersistenceManager::onError(std::function<void(const std::string&)> callback)
{
    errorCallback = callback;
}

void PersistenceManager::onChange(std::function<void(const std::string&, const std::string&)> callback)
{
    changeCallback = callback;
}

void PersistenceManager::onDelete(std::function<void(const std::string&)> callback)
{
    deleteCallback = callback;
}

std::string PersistenceManager::getVersion() const
{
    return "1.0.0";
}

std::string PersistenceManager::getBackendName() const
{
    switch (backend) {
        case StorageBackend::SQLite: return "SQLite";
        case StorageBackend::LevelDB: return "LevelDB";
        case StorageBackend::JSON: return "JSON";
        default: return "Unknown";
    }
}

StorageBackend PersistenceManager::getBackend() const
{
    return backend;
}

bool PersistenceManager::initSQLite(const std::string &path)
{
    if (sqlite) closeSQLite();
    if (sqlite3_open(path.c_str(), &sqlite) != SQLITE_OK) return false;
    if (config.use_wal) executeSQL("PRAGMA journal_mode=WAL");
    if (config.foreign_keys) executeSQL("PRAGMA foreign_keys=ON");
    if (config.sync_mode) executeSQL("PRAGMA synchronous=FULL");
    std::string sql = "CREATE TABLE IF NOT EXISTS kv_store (key TEXT PRIMARY KEY, value TEXT)";
    return executeSQL(sql);
}

bool PersistenceManager::initLevelDB(const std::string &path)
{
    leveldb::Options options;
    options.create_if_missing = true;
    if (blockCache) delete blockCache;
    blockCache = leveldb::NewLRUCache(config.cache_size > 0 ? config.cache_size : 8 * 1024 * 1024);
    options.block_cache = blockCache;
    if (config.bloom_filter_bits > 0) options.filter_policy = leveldb::NewBloomFilterPolicy(config.bloom_filter_bits);
    leveldb::Status status = leveldb::DB::Open(options, path, &leveldb);
    return status.ok();
}

bool PersistenceManager::closeSQLite()
{
    if (!sqlite) return false;
    sqlite3_close(sqlite);
    sqlite = nullptr;
    return true;
}

bool PersistenceManager::closeLevelDB()
{
    if (!leveldb) return false;
    delete leveldb;
    leveldb = nullptr;
    return true;
}

bool PersistenceManager::executeSQL(const std::string &sql)
{
    if (!sqlite) return false;
    char *err = nullptr;
    if (sqlite3_exec(sqlite, sql.c_str(), nullptr, nullptr, &err) != SQLITE_OK) {
        if (errorCallback && err) errorCallback(err);
        sqlite3_free(err);
        return false;
    }
    return true;
}

std::vector<std::map<std::string, std::string>> PersistenceManager::querySQL(const std::string &sql)
{
    std::vector<std::map<std::string, std::string>> results;
    if (!sqlite) return results;
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(sqlite, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) return results;
    int cols = sqlite3_column_count(stmt);
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        std::map<std::string, std::string> row;
        for (int i = 0; i < cols; ++i) {
            const char *name = sqlite3_column_name(stmt, i);
            const char *val = reinterpret_cast<const char*>(sqlite3_column_text(stmt, i));
            row[name ? name : ""] = val ? val : "";
        }
        results.push_back(row);
    }
    sqlite3_finalize(stmt);
    return results;
}

std::string PersistenceManager::encryptString(const std::string &data)
{
    std::string result = data;
    if (!config.encryption_key.empty()) {
        for (size_t i = 0; i < result.size(); ++i) {
            result[i] ^= config.encryption_key[i % config.encryption_key.size()];
        }
    }
    return result;
}

std::string PersistenceManager::decryptString(const std::string &data)
{
    return encryptString(data);
}

std::vector<uint8_t> PersistenceManager::encryptBytes(const std::vector<uint8_t> &data)
{
    std::vector<uint8_t> result = data;
    for (size_t i = 0; i < result.size(); ++i) result[i] ^= 0xAA;
    return result;
}

std::vector<uint8_t> PersistenceManager::decryptBytes(const std::vector<uint8_t> &data)
{
    return encryptBytes(data);
}

std::string PersistenceManager::compressString(const std::string &data)
{
    return data;
}

std::string PersistenceManager::decompressString(const std::string &data)
{
    return data;
}

std::vector<uint8_t> PersistenceManager::compressBytes(const std::vector<uint8_t> &data)
{
    return data;
}

std::vector<uint8_t> PersistenceManager::decompressBytes(const std::vector<uint8_t> &data)
{
    return data;
}

std::string PersistenceManager::serializeToJSON(const std::map<std::string, std::string> &entries) const
{
    std::ostringstream oss;
    oss << "{";
    bool first = true;
    for (const auto &kv : entries) {
        if (!first) oss << ",";
        first = false;
        oss << "\"" << kv.first << "\":\"" << kv.second << "\"";
    }
    oss << "}";
    return oss.str();
}

std::map<std::string, std::string> PersistenceManager::deserializeFromJSON(const std::string &json) const
{
    std::map<std::string, std::string> entries;
    size_t pos = 0;
    while (true) {
        size_t kstart = json.find('"', pos);
        if (kstart == std::string::npos) break;
        size_t kend = json.find('"', kstart + 1);
        if (kend == std::string::npos) break;
        std::string key = json.substr(kstart + 1, kend - kstart - 1);
        size_t vstart = json.find('"', kend + 1);
        if (vstart == std::string::npos) break;
        size_t vend = json.find('"', vstart + 1);
        if (vend == std::string::npos) break;
        std::string value = json.substr(vstart + 1, vend - vstart - 1);
        entries[key] = value;
        pos = vend + 1;
    }
    return entries;
}

std::string PersistenceManager::toHex(const std::vector<uint8_t> &data) const
{
    std::ostringstream oss;
    for (auto b : data) oss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(b);
    return oss.str();
}

std::vector<uint8_t> PersistenceManager::fromHex(const std::string &hex) const
{
    std::vector<uint8_t> data;
    for (size_t i = 0; i < hex.size(); i += 2) {
        uint8_t byte = 0;
        for (int j = 0; j < 2 && i + j < hex.size(); ++j) {
            char c = hex[i + j];
            byte <<= 4;
            if (c >= '0' && c <= '9') byte |= (c - '0');
            else if (c >= 'a' && c <= 'f') byte |= (10 + c - 'a');
            else if (c >= 'A' && c <= 'F') byte |= (10 + c - 'A');
        }
        data.push_back(byte);
    }
    return data;
}

bool PersistenceManager::createDirectory(const std::string &path)
{
    struct stat st;
    if (stat(path.c_str(), &st) == 0 && S_ISDIR(st.st_mode)) return true;
    size_t pos = 0;
    while ((pos = path.find('/', pos + 1)) != std::string::npos) {
        std::string sub = path.substr(0, pos);
        mkdir(sub.c_str(), 0755);
    }
    mkdir(path.c_str(), 0755);
    return stat(path.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
}

bool PersistenceManager::fileExists(const std::string &path) const
{
    struct stat st;
    return stat(path.c_str(), &st) == 0;
}

uint64_t PersistenceManager::getFileSize(const std::string &path) const
{
    struct stat st;
    if (stat(path.c_str(), &st) != 0) return 0;
    return static_cast<uint64_t>(st.st_size);
}

void PersistenceManager::addToCache(const std::string &key, const std::string &value)
{
    std::lock_guard<std::mutex> lock(cacheMutex);
    memoryCache[key] = value;
    if (memoryCache.size() > 1000) evictCache();
}

std::string PersistenceManager::getFromCache(const std::string &key)
{
    std::lock_guard<std::mutex> lock(cacheMutex);
    auto it = memoryCache.find(key);
    return it != memoryCache.end() ? it->second : "";
}

void PersistenceManager::evictCache()
{
    while (memoryCache.size() > 100) {
        auto oldest = memoryCache.begin();
        for (auto it = memoryCache.begin(); it != memoryCache.end(); ++it) {
            if (cacheAccessTimes[it->first] < cacheAccessTimes[oldest->first]) oldest = it;
        }
        memoryCache.erase(oldest);
    }
}

void PersistenceManager::invalidateCache(const std::string &key)
{
    memoryCache.erase(key);
}

void PersistenceManager::clearCacheInternal()
{
    memoryCache.clear();
    cacheAccessTimes.clear();
}

void PersistenceManager::runIntegrityCheck()
{
    checkIntegrity();
    stats.last_integrity_check = static_cast<uint64_t>(time(nullptr));
}

void PersistenceManager::runAutoCompact()
{
    if (config.auto_compact) compact();
    stats.last_compact_time = static_cast<uint64_t>(time(nullptr));
}

void PersistenceManager::runAutoBackup()
{
    if (config.auto_backup) createBackup();
    stats.last_backup_time = static_cast<uint64_t>(time(nullptr));
}

void PersistenceManager::backupLoop()
{
    while (threadsRunning) {
        std::this_thread::sleep_for(std::chrono::seconds(config.backup_interval > 0 ? config.backup_interval : 3600));
        if (config.auto_backup) runAutoBackup();
    }
}

void PersistenceManager::compactLoop()
{
    while (threadsRunning) {
        std::this_thread::sleep_for(std::chrono::seconds(config.compaction_interval > 0 ? config.compaction_interval : 86400));
        if (config.auto_compact) runAutoCompact();
    }
}

void PersistenceManager::syncLoop()
{
    while (threadsRunning) {
        std::this_thread::sleep_for(std::chrono::seconds(config.sync_interval > 0 ? config.sync_interval : 60));
        sync();
    }
}

void PersistenceManager::updateStats()
{
    stats.total_entries = static_cast<uint64_t>(memoryCache.size());
    stats.cache_size = static_cast<uint64_t>(memoryCache.size() * 128);
    stats.cache_hit_ratio = (stats.cache_hits + stats.cache_misses) > 0
        ? static_cast<double>(stats.cache_hits) / (stats.cache_hits + stats.cache_misses) * 100.0 : 0.0;
}
