#ifndef BUGOR_PERSISTENCE_MANAGER_H
#define BUGOR_PERSISTENCE_MANAGER_H

#include <string>
#include <vector>
#include <map>
#include <functional>
#include <memory>
#include <mutex>
#include <atomic>
#include <thread>
#include <chrono>
#include <queue>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <set>
#include <cstdint>
#include <cstring>
#include <sqlite3.h>
#include <leveldb/db.h>
#include <leveldb/cache.h>
#include <leveldb/write_batch.h>
#include <google/protobuf/message.h>
#include <zlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <filesystem>

struct StorageConfig {
    std::string base_path;
    std::string db_path;
    std::string cache_path;
    std::string backup_path;
    std::string temp_path;
    std::string encryption_key;
    size_t max_db_size;
    size_t max_cache_size;
    size_t page_size;
    size_t cache_size;
    uint32_t wal_size;
    uint32_t sync_interval;
    uint32_t backup_interval;
    uint32_t max_backups;
    uint32_t compaction_interval;
    uint32_t write_ahead_log_size;
    uint32_t bloom_filter_bits;
    uint32_t block_size;
    uint32_t block_restart_interval;
    int compression_level;
    bool encrypt_data;
    bool compress_data;
    bool use_wal;
    bool use_mmap;
    bool use_shared_cache;
    bool auto_compact;
    bool auto_backup;
    bool incremental_backup;
    bool integrity_check;
    bool journal_mode;
    bool foreign_keys;
    bool sync_mode;
    bool temp_store;
    bool memory_mapped_io;
};

struct StorageStats {
    uint64_t total_entries;
    uint64_t total_size;
    uint64_t data_size;
    uint64_t index_size;
    uint64_t cache_size;
    uint64_t wal_size;
    uint64_t backup_count;
    uint64_t backup_total_size;
    uint32_t open_connections;
    uint32_t active_transactions;
    uint32_t cache_hits;
    uint32_t cache_misses;
    uint32_t read_count;
    uint32_t write_count;
    uint32_t delete_count;
    uint32_t errors;
    uint64_t last_compact_time;
    uint64_t last_backup_time;
    uint64_t last_integrity_check;
    double avg_read_time_ms;
    double avg_write_time_ms;
    double cache_hit_ratio;
    double fragmentation_ratio;
    double storage_usage_ratio;
};

enum class StorageBackend {
    SQLite,
    LevelDB,
    RocksDB,
    Protobuf,
    JSON,
    XML,
    Binary,
    Custom
};

enum class SerializationFormat {
    Protobuf,
    JSON,
    XML,
    Binary,
    MessagePack,
    BSON,
    CBOR,
    Custom
};

class PersistenceManager {
public:
    PersistenceManager();
    ~PersistenceManager();

    bool initialize(const StorageConfig &config);
    void shutdown();
    bool isInitialized() const;

    bool open();
    bool close();
    bool reopen();

    bool store(const std::string &key, const std::string &value);
    bool store(const std::string &key, const std::vector<uint8_t> &value);
    bool store(const std::string &key, int32_t value);
    bool store(const std::string &key, int64_t value);
    bool store(const std::string &key, float value);
    bool store(const std::string &key, double value);
    bool store(const std::string &key, bool value);
    bool storeBatch(const std::map<std::string, std::string> &entries);

    std::string getString(const std::string &key, const std::string &default_val = "");
    std::vector<uint8_t> getBytes(const std::string &key);
    int32_t getInt32(const std::string &key, int32_t default_val = 0);
    int64_t getInt64(const std::string &key, int64_t default_val = 0);
    float getFloat(const std::string &key, float default_val = 0.0f);
    double getDouble(const std::string &key, double default_val = 0.0);
    bool getBool(const std::string &key, bool default_val = false);
    std::map<std::string, std::string> getBatch(const std::vector<std::string> &keys);

    bool remove(const std::string &key);
    bool removeBatch(const std::vector<std::string> &keys);
    bool removeByPrefix(const std::string &prefix);
    bool removeByPattern(const std::string &pattern);
    bool clear();

    bool hasKey(const std::string &key) const;
    uint64_t getEntryCount() const;
    std::vector<std::string> getKeys() const;
    std::vector<std::string> getKeysByPrefix(const std::string &prefix) const;
    std::vector<std::string> getKeysByPattern(const std::string &pattern) const;

    std::vector<std::pair<std::string, std::string>> getAllEntries() const;
    std::vector<std::pair<std::string, std::string>> getEntriesByPrefix(const std::string &prefix) const;

    bool beginTransaction();
    bool commitTransaction();
    bool rollbackTransaction();
    bool isTransactionActive() const;

    bool compact();
    bool compactRange(const std::string &start, const std::string &end);
    bool optimize();
    bool analyze();

    bool createBackup(const std::string &path = "");
    bool restoreBackup(const std::string &path);
    bool deleteBackup(const std::string &path);
    std::vector<std::string> listBackups() const;

    bool checkIntegrity();
    bool repair();
    bool vacuum();

    bool encrypt(const std::string &key);
    bool decrypt(const std::string &key);
    bool isEncrypted() const;

    bool compress();
    bool decompress();
    bool isCompressed() const;

    bool importData(const std::string &path, const std::string &format = "json");
    bool exportData(const std::string &path, const std::string &format = "json");
    bool importFromCSV(const std::string &path);
    bool exportToCSV(const std::string &path);
    bool importFromSQL(const std::string &path);
    bool exportToSQL(const std::string &path);

    bool migrateSchema(uint32_t from_version, uint32_t to_version);
    uint32_t getSchemaVersion() const;
    bool setSchemaVersion(uint32_t version);

    StorageStats getStats() const;
    StorageConfig getConfig() const;
    bool setConfig(const StorageConfig &config);

    bool setCacheEnabled(bool enable);
    bool isCacheEnabled() const;
    bool clearCache();
    uint64_t getCacheSize() const;

    bool setEncryptionEnabled(bool enable);
    bool isEncryptionEnabled() const;
    void setEncryptionKey(const std::string &key);

    bool setCompressionEnabled(bool enable);
    bool isCompressionEnabled() const;
    void setCompressionLevel(int level);

    void flush();
    void sync();

    void onError(std::function<void(const std::string&)> callback);
    void onChange(std::function<void(const std::string&, const std::string&)> callback);
    void onDelete(std::function<void(const std::string&)> callback);

    std::string getVersion() const;
    std::string getBackendName() const;
    StorageBackend getBackend() const;

private:
    bool initialized;
    bool transactionActive;
    bool encrypted;
    bool compressed;
    bool cacheEnabled;

    StorageConfig config;
    StorageStats stats;
    StorageBackend backend;

    sqlite3 *sqlite;
    leveldb::DB *leveldb;
    leveldb::Cache *blockCache;

    std::mutex storageMutex;
    std::mutex transactionMutex;
    std::mutex backupMutex;
    std::mutex cacheMutex;

    std::map<std::string, std::string> memoryCache;
    std::map<std::string, uint64_t> cacheAccessTimes;
    uint64_t cacheHits;
    uint64_t cacheMisses;

    std::function<void(const std::string&)> errorCallback;
    std::function<void(const std::string&, const std::string&)> changeCallback;
    std::function<void(const std::string&)> deleteCallback;

    std::thread *backupThread;
    std::thread *compactThread;
    std::thread *syncThread;
    std::atomic<bool> threadsRunning;

    bool initSQLite(const std::string &path);
    bool initLevelDB(const std::string &path);
    bool closeSQLite();
    bool closeLevelDB();

    bool executeSQL(const std::string &sql);
    std::vector<std::map<std::string, std::string>> querySQL(const std::string &sql);

    std::string encryptString(const std::string &data);
    std::string decryptString(const std::string &data);
    std::vector<uint8_t> encryptBytes(const std::vector<uint8_t> &data);
    std::vector<uint8_t> decryptBytes(const std::vector<uint8_t> &data);

    std::string compressString(const std::string &data);
    std::string decompressString(const std::string &data);
    std::vector<uint8_t> compressBytes(const std::vector<uint8_t> &data);
    std::vector<uint8_t> decompressBytes(const std::vector<uint8_t> &data);

    std::string serializeToJSON(const std::map<std::string, std::string> &entries) const;
    std::map<std::string, std::string> deserializeFromJSON(const std::string &json) const;

    std::string toHex(const std::vector<uint8_t> &data) const;
    std::vector<uint8_t> fromHex(const std::string &hex) const;

    bool createDirectory(const std::string &path);
    bool fileExists(const std::string &path) const;
    uint64_t getFileSize(const std::string &path) const;

    void addToCache(const std::string &key, const std::string &value);
    std::string getFromCache(const std::string &key);
    void evictCache();
    void invalidateCache(const std::string &key);
    void clearCacheInternal();

    void runIntegrityCheck();
    void runAutoCompact();
    void runAutoBackup();
    void backupLoop();
    void compactLoop();
    void syncLoop();
    void updateStats();
};

#endif
