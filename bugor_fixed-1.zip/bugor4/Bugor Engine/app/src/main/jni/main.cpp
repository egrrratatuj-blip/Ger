#include <jni.h>
#include <android/log.h>
#include <string>
#include <atomic>
#include <thread>
#include <mutex>
#include "app/Config.h"
#include "app/AntiDebug.h"
#include "app/Obfuscator.h"
#include "BugorBridge.h"

#define LOG_TAG "BugorEngine"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static int g_PID = 0;
static std::string g_UUID;
static std::string g_Key;
static std::atomic<bool> g_EngineRunning{true};
static std::thread g_GuiThread;

extern "C" {

void RequestEngineShutdown() {
    g_EngineRunning.store(false);
    if (g_GuiThread.joinable()) {
        g_GuiThread.join();
    }
}

bool IsEngineRunning() {
    return g_EngineRunning.load();
}

JNICALL void SurfaceCreated(JNIEnv *env, jclass cla, jobject surface) {
    if (window_sv) ANativeWindow_release(window_sv);
    window_sv = ANativeWindow_fromSurface(env, surface);
    AntiDebug::ProtectProcess();
    {
        std::lock_guard<std::mutex> lock(g_EngineStateMutex);
        if (g_GuiThread.joinable()) {
            g_EngineRunning.store(false);
            g_GuiThread.join();
        }
        g_EngineRunning.store(true);
    }
    g_GuiThread = std::thread([]() {
        while (g_EngineRunning.load()) {
            if (!g_Initialized.load()) {
                initGui();
            }
            if (g_Initialized.load()) {
                ImGuiMainMenuWind();
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(16));
        }
    });
}

JNICALL void TouchEvent(JNIEnv *env, jclass clazz, jint action, jint pointerId, jfloat x, jfloat y, jfloat pressure) {
    ImGuInput_LinuxEvent ev;
    ev.Action_type = action;
    ev.fingerIndex = pointerId;
    ev.pos.x = x;
    ev.pos.y = y;
    ev.pressure = pressure;
    ImGui_ImplLinux_HandleInputEvent(ev);
}

JNICALL jstring OnStart(JNIEnv *env, jclass clazz, jint width, jint height) {
    _ScreenX = width;
    _ScreenY = height;
    glViewport(0, 0, width, height);
    return env->NewStringUTF("BugorEngine");
}

JNICALL jfloatArray GetWinSize(JNIEnv *env, jclass clazz) {
    jfloatArray ret = env->NewFloatArray(4);
    if (ret == nullptr) return nullptr;
    float data[4] = {0, 0, 0, 0};
    if (Window) {
        data[0] = Window->Pos.x;
        data[1] = Window->Pos.y;
        data[2] = Window->Size.x;
        data[3] = Window->Size.y;
    }
    env->SetFloatArrayRegion(ret, 0, 4, data);
    return ret;
}

JNICALL void SetUUID(JNIEnv *env, jclass, jstring uuid_j) {
    const char *uuid = env->GetStringUTFChars(uuid_j, nullptr);
    if (uuid) {
        g_UUID = uuid;
        env->ReleaseStringUTFChars(uuid_j, uuid);
    }
}

JNICALL void SetKey(JNIEnv *env, jclass, jstring key_j) {
    const char *key = env->GetStringUTFChars(key_j, nullptr);
    if (key) {
        g_Key = key;
        env->ReleaseStringUTFChars(key_j, key);
    }
}

JNICALL void SetPID(JNIEnv *env, jclass, jint pid) {
    g_PID = (int)pid;
}

JNICALL jboolean Bugor_Initialize(JNIEnv *env, jclass clazz, jstring configPath_j) {
    const char *configPath = env->GetStringUTFChars(configPath_j, nullptr);
    bool result = BugorNativeInitialize(configPath);
    env->ReleaseStringUTFChars(configPath_j, configPath);
    return result ? JNI_TRUE : JNI_FALSE;
}

JNICALL jboolean Bugor_Shutdown(JNIEnv *env, jclass clazz) {
    return BugorNativeShutdown() ? JNI_TRUE : JNI_FALSE;
}

JNICALL jboolean Bugor_IsInitialized(JNIEnv *env, jclass clazz) {
    return BugorNativeIsInitialized() ? JNI_TRUE : JNI_FALSE;
}

JNICALL jstring Bugor_GetVersion(JNIEnv *env, jclass clazz) {
    return env->NewStringUTF(BugorNativeGetVersion().c_str());
}

JNICALL jboolean Bugor_ExecuteScript(JNIEnv *env, jclass clazz, jstring script_j) {
    const char *script = env->GetStringUTFChars(script_j, nullptr);
    bool result = BugorNativeExecuteScript(script);
    env->ReleaseStringUTFChars(script_j, script);
    return result ? JNI_TRUE : JNI_FALSE;
}

JNICALL jstring Bugor_ExecuteCommand(JNIEnv *env, jclass clazz, jstring command_j) {
    const char *command = env->GetStringUTFChars(command_j, nullptr);
    std::string result = BugorNativeExecuteCommand(command);
    env->ReleaseStringUTFChars(command_j, command);
    return env->NewStringUTF(result.c_str());
}

JNICALL jlong Bugor_ReadLong(JNIEnv *env, jclass clazz, jlong address) {
    return (jlong)BugorNativeReadLong((uintptr_t)address);
}

JNICALL jint Bugor_ReadInt(JNIEnv *env, jclass clazz, jlong address) {
    return (jint)BugorNativeReadInt((uintptr_t)address);
}

JNICALL jfloat Bugor_ReadFloat(JNIEnv *env, jclass clazz, jlong address) {
    return (jfloat)BugorNativeReadFloat((uintptr_t)address);
}

JNICALL jdouble Bugor_ReadDouble(JNIEnv *env, jclass clazz, jlong address) {
    return (jdouble)BugorNativeReadDouble((uintptr_t)address);
}

JNICALL jboolean Bugor_WriteLong(JNIEnv *env, jclass clazz, jlong address, jlong value) {
    return BugorNativeWriteLong((uintptr_t)address, (uintptr_t)value) ? JNI_TRUE : JNI_FALSE;
}

JNICALL jboolean Bugor_WriteInt(JNIEnv *env, jclass clazz, jlong address, jint value) {
    return BugorNativeWriteInt((uintptr_t)address, (int)value) ? JNI_TRUE : JNI_FALSE;
}

JNICALL jboolean Bugor_WriteFloat(JNIEnv *env, jclass clazz, jlong address, jfloat value) {
    return BugorNativeWriteFloat((uintptr_t)address, (float)value) ? JNI_TRUE : JNI_FALSE;
}

JNICALL jboolean Bugor_WriteDouble(JNIEnv *env, jclass clazz, jlong address, jdouble value) {
    return BugorNativeWriteDouble((uintptr_t)address, (double)value) ? JNI_TRUE : JNI_FALSE;
}

JNICALL jstring Bugor_SearchMemory(JNIEnv *env, jclass clazz, jint valueType, jlong value, jint valueSize, jlong regionStart, jlong regionEnd) {
    std::string result = BugorNativeSearchMemory((int)valueType, (uintptr_t)value, (int)valueSize, (uintptr_t)regionStart, (uintptr_t)regionEnd);
    return env->NewStringUTF(result.c_str());
}

JNICALL jboolean Bugor_PatchMemory(JNIEnv *env, jclass clazz, jlong address, jbyteArray patchData) {
    if (patchData == nullptr) return JNI_FALSE;
    jsize len = env->GetArrayLength(patchData);
    jbyte *data = env->GetByteArrayElements(patchData, nullptr);
    if (data == nullptr) return JNI_FALSE;
    bool result = BugorNativePatchMemory((uintptr_t)address, (const uint8_t*)data, (size_t)len);
    env->ReleaseByteArrayElements(patchData, data, JNI_ABORT);
    return result ? JNI_TRUE : JNI_FALSE;
}

JNICALL jlong Bugor_GetModuleBase(JNIEnv *env, jclass clazz, jstring moduleName_j) {
    const char *moduleName = env->GetStringUTFChars(moduleName_j, nullptr);
    uintptr_t result = BugorNativeGetModuleBase(moduleName);
    env->ReleaseStringUTFChars(moduleName_j, moduleName);
    return (jlong)result;
}

JNICALL jstring Bugor_DumpMemory(JNIEnv *env, jclass clazz, jlong address, jint size) {
    return env->NewStringUTF(BugorNativeDumpMemory((uintptr_t)address, (int)size).c_str());
}

JNICALL jint Bugor_InstallHook(JNIEnv *env, jclass clazz, jlong targetAddress, jlong hookFunction) {
    return (jint)BugorNativeInstallHook((uintptr_t)targetAddress, (void*)hookFunction);
}

JNICALL jboolean Bugor_UninstallHook(JNIEnv *env, jclass clazz, jint hookId) {
    return BugorNativeUninstallHook((int)hookId) ? JNI_TRUE : JNI_FALSE;
}

JNICALL jboolean Bugor_FreezeValue(JNIEnv *env, jclass clazz, jlong address, jlong value, jint valueType) {
    return BugorNativeFreezeValue((uintptr_t)address, (uintptr_t)value, (int)valueType) ? JNI_TRUE : JNI_FALSE;
}

JNICALL jboolean Bugor_UnfreezeValue(JNIEnv *env, jclass clazz, jlong address) {
    return BugorNativeUnfreezeValue((uintptr_t)address) ? JNI_TRUE : JNI_FALSE;
}

JNICALL jboolean Bugor_UnfreezeAll(JNIEnv *env, jclass clazz) {
    return BugorNativeUnfreezeAll() ? JNI_TRUE : JNI_FALSE;
}

JNICALL jboolean Bugor_ProtectMemory(JNIEnv *env, jclass clazz, jlong address, jlong size, jint protection) {
    return BugorNativeProtectMemory((uintptr_t)address, (size_t)size, (int)protection) ? JNI_TRUE : JNI_FALSE;
}

JNICALL jlong Bugor_AllocateMemory(JNIEnv *env, jclass clazz, jlong size, jint protection) {
    return (jlong)BugorNativeAllocateMemory((size_t)size, (int)protection);
}

JNICALL jboolean Bugor_FreeMemory(JNIEnv *env, jclass clazz, jlong address) {
    return BugorNativeFreeMemory((uintptr_t)address) ? JNI_TRUE : JNI_FALSE;
}

JNICALL jstring Bugor_GetRegions(JNIEnv *env, jclass clazz) {
    return env->NewStringUTF(BugorNativeGetRegions().c_str());
}

JNICALL jboolean Bugor_LoadScriptFile(JNIEnv *env, jclass clazz, jstring path_j) {
    const char *path = env->GetStringUTFChars(path_j, nullptr);
    bool result = BugorNativeLoadScriptFile(path);
    env->ReleaseStringUTFChars(path_j, path);
    return result ? JNI_TRUE : JNI_FALSE;
}

JNICALL jboolean Bugor_LoadScript(JNIEnv *env, jclass clazz, jstring name_j, jstring source_j) {
    const char *name = env->GetStringUTFChars(name_j, nullptr);
    const char *source = env->GetStringUTFChars(source_j, nullptr);
    bool result = BugorNativeLoadScript(name, source);
    env->ReleaseStringUTFChars(name_j, name);
    env->ReleaseStringUTFChars(source_j, source);
    return result ? JNI_TRUE : JNI_FALSE;
}

JNICALL jboolean Bugor_ConnectRemote(JNIEnv *env, jclass clazz, jstring host_j, jint port, jstring apiKey_j) {
    const char *host = env->GetStringUTFChars(host_j, nullptr);
    const char *apiKey = env->GetStringUTFChars(apiKey_j, nullptr);
    bool result = BugorNativeConnectRemote(host, (int)port, apiKey);
    env->ReleaseStringUTFChars(host_j, host);
    env->ReleaseStringUTFChars(apiKey_j, apiKey);
    return result ? JNI_TRUE : JNI_FALSE;
}

JNICALL jboolean Bugor_DisconnectRemote(JNIEnv *env, jclass clazz) {
    return BugorNativeDisconnectRemote() ? JNI_TRUE : JNI_FALSE;
}

JNICALL jstring Bugor_SendRemoteCommand(JNIEnv *env, jclass clazz, jstring command_j, jstring args_j) {
    const char *command = env->GetStringUTFChars(command_j, nullptr);
    const char *args = env->GetStringUTFChars(args_j, nullptr);
    std::string result = BugorNativeSendRemoteCommand(command, args);
    env->ReleaseStringUTFChars(command_j, command);
    env->ReleaseStringUTFChars(args_j, args);
    return env->NewStringUTF(result.c_str());
}

JNICALL jstring Bugor_Encrypt(JNIEnv *env, jclass clazz, jstring data_j, jstring key_j) {
    const char *data = env->GetStringUTFChars(data_j, nullptr);
    const char *key = env->GetStringUTFChars(key_j, nullptr);
    std::string result = BugorNativeEncrypt(data, key);
    env->ReleaseStringUTFChars(data_j, data);
    env->ReleaseStringUTFChars(key_j, key);
    return env->NewStringUTF(result.c_str());
}

JNICALL jstring Bugor_Decrypt(JNIEnv *env, jclass clazz, jstring data_j, jstring key_j) {
    const char *data = env->GetStringUTFChars(data_j, nullptr);
    const char *key = env->GetStringUTFChars(key_j, nullptr);
    std::string result = BugorNativeDecrypt(data, key);
    env->ReleaseStringUTFChars(data_j, data);
    env->ReleaseStringUTFChars(key_j, key);
    return env->NewStringUTF(result.c_str());
}

JNICALL jstring Bugor_Hash(JNIEnv *env, jclass clazz, jstring data_j) {
    const char *data = env->GetStringUTFChars(data_j, nullptr);
    std::string result = BugorNativeHash(data);
    env->ReleaseStringUTFChars(data_j, data);
    return env->NewStringUTF(result.c_str());
}

JNICALL jstring Bugor_GetMetrics(JNIEnv *env, jclass clazz) {
    return env->NewStringUTF(BugorNativeGetMetrics().c_str());
}

JNICALL void Bugor_SetLogLevel(JNIEnv *env, jclass clazz, jint level) {
    BugorNativeSetLogLevel((int)level);
}

JNICALL void Bugor_Log(JNIEnv *env, jclass clazz, jint level, jstring message_j) {
    const char *message = env->GetStringUTFChars(message_j, nullptr);
    BugorNativeLog((int)level, message);
    env->ReleaseStringUTFChars(message_j, message);
}

JNICALL jboolean Bugor_AttachDebugger(JNIEnv *env, jclass clazz, jint pid) {
    return BugorNativeAttachDebugger((int)pid) ? JNI_TRUE : JNI_FALSE;
}

JNICALL jboolean Bugor_DetachDebugger(JNIEnv *env, jclass clazz) {
    return BugorNativeDetachDebugger() ? JNI_TRUE : JNI_FALSE;
}

JNICALL jboolean Bugor_SetBreakpoint(JNIEnv *env, jclass clazz, jlong address) {
    return BugorNativeSetBreakpoint((uintptr_t)address) ? JNI_TRUE : JNI_FALSE;
}

JNICALL jboolean Bugor_StoreValue(JNIEnv *env, jclass clazz, jstring key_j, jstring value_j) {
    const char *key = env->GetStringUTFChars(key_j, nullptr);
    const char *value = env->GetStringUTFChars(value_j, nullptr);
    bool result = BugorNativeStoreValue(key, value);
    env->ReleaseStringUTFChars(key_j, key);
    env->ReleaseStringUTFChars(value_j, value);
    return result ? JNI_TRUE : JNI_FALSE;
}

JNICALL jstring Bugor_LoadValue(JNIEnv *env, jclass clazz, jstring key_j) {
    const char *key = env->GetStringUTFChars(key_j, nullptr);
    std::string result = BugorNativeLoadValue(key);
    env->ReleaseStringUTFChars(key_j, key);
    return env->NewStringUTF(result.c_str());
}

JNICALL jboolean Bugor_DeleteValue(JNIEnv *env, jclass clazz, jstring key_j) {
    const char *key = env->GetStringUTFChars(key_j, nullptr);
    bool result = BugorNativeDeleteValue(key);
    env->ReleaseStringUTFChars(key_j, key);
    return result ? JNI_TRUE : JNI_FALSE;
}

JNICALL jstring Bugor_GetHealthStatus(JNIEnv *env, jclass clazz) {
    return env->NewStringUTF(BugorNativeGetHealthStatus().c_str());
}

JNICALL jlong Bugor_GetEnginePointer(JNIEnv *env, jclass clazz) {
    return (jlong)(uintptr_t)BugorNativeGetEnginePointer();
}

JNICALL jint Bugor_GetState(JNIEnv *env, jclass clazz) {
    return (jint)BugorNativeGetState();
}

JNICALL jboolean Bugor_Pause(JNIEnv *env, jclass clazz) {
    return BugorNativePause() ? JNI_TRUE : JNI_FALSE;
}

JNICALL jboolean Bugor_Resume(JNIEnv *env, jclass clazz) {
    return BugorNativeResume() ? JNI_TRUE : JNI_FALSE;
}

JNICALL jboolean Bugor_Restart(JNIEnv *env, jclass clazz) {
    return BugorNativeRestart() ? JNI_TRUE : JNI_FALSE;
}

JNICALL jstring Bugor_GetBuildInfo(JNIEnv *env, jclass clazz) {
    return env->NewStringUTF(BugorNativeGetBuildInfo().c_str());
}

JNICALL jboolean Bugor_RegisterFunction(JNIEnv *env, jclass clazz, jstring name_j, jlong funcPtr) {
    const char *name = env->GetStringUTFChars(name_j, nullptr);
    bool result = BugorNativeRegisterFunction(name, (void*)funcPtr);
    env->ReleaseStringUTFChars(name_j, name);
    return result ? JNI_TRUE : JNI_FALSE;
}

JNICALL jboolean Bugor_StartServer(JNIEnv *env, jclass clazz, jint port) {
    return BugorNativeStartServer((int)port) ? JNI_TRUE : JNI_FALSE;
}

JNICALL void Bugor_StartServerV(JNIEnv *env, jclass clazz) {
    BugorNativeStartServer(0);
}

JNICALL jboolean Bugor_StopServer(JNIEnv *env, jclass clazz) {
    return BugorNativeStopServer() ? JNI_TRUE : JNI_FALSE;
}

JNICALL void Bugor_StopServerV(JNIEnv *env, jclass clazz) {
    BugorNativeStopServer();
}

JNICALL void Bugor_RegisterFunctionV(JNIEnv *env, jclass clazz, jstring name_j, jlong funcPtr) {
    const char *name = env->GetStringUTFChars(name_j, nullptr);
    BugorNativeRegisterFunction(name, (void*)funcPtr);
    env->ReleaseStringUTFChars(name_j, name);
}

}

static JNINativeMethod methods[] = {
    {"start", "(II)Ljava/lang/String;", (void *)OnStart},
    {"setSurface", "(Landroid/view/Surface;)V", (void *)SurfaceCreated},
    {"setPid", "(I)V", (void *)SetPID},
    {"setUUid", "(Ljava/lang/String;)V", (void *)SetUUID},
    {"setKey", "(Ljava/lang/String;)V", (void *)SetKey},
    {"MotionEventClick", "(IIFFF)V", (void *)TouchEvent},
    {"GetImGuiwinsize", "()[F", (void *)GetWinSize},
    {"initialize", "(Ljava/lang/String;)Z", (void *)Bugor_Initialize},
    {"shutdown", "()Z", (void *)Bugor_Shutdown},
    {"isInitialized", "()Z", (void *)Bugor_IsInitialized},
    {"getVersion", "()Ljava/lang/String;", (void *)Bugor_GetVersion},
    {"executeScript", "(Ljava/lang/String;)Z", (void *)Bugor_ExecuteScript},
    {"executeCommand", "(Ljava/lang/String;)Ljava/lang/String;", (void *)Bugor_ExecuteCommand},
    {"readLong", "(J)J", (void *)Bugor_ReadLong},
    {"readInt", "(J)I", (void *)Bugor_ReadInt},
    {"readFloat", "(J)F", (void *)Bugor_ReadFloat},
    {"readDouble", "(J)D", (void *)Bugor_ReadDouble},
    {"writeLong", "(JJ)Z", (void *)Bugor_WriteLong},
    {"writeInt", "(JI)Z", (void *)Bugor_WriteInt},
    {"writeFloat", "(JF)Z", (void *)Bugor_WriteFloat},
    {"writeDouble", "(JD)Z", (void *)Bugor_WriteDouble},
    {"searchMemory", "(IJIJJ)Ljava/lang/String;", (void *)Bugor_SearchMemory},
    {"patchMemory", "(J[B)Z", (void *)Bugor_PatchMemory},
    {"getModuleBase", "(Ljava/lang/String;)J", (void *)Bugor_GetModuleBase},
    {"dumpMemory", "(JI)Ljava/lang/String;", (void *)Bugor_DumpMemory},
    {"installHook", "(JJ)I", (void *)Bugor_InstallHook},
    {"uninstallHook", "(I)Z", (void *)Bugor_UninstallHook},
    {"freezeValue", "(JJI)Z", (void *)Bugor_FreezeValue},
    {"unfreezeValue", "(J)Z", (void *)Bugor_UnfreezeValue},
    {"unfreezeAll", "()Z", (void *)Bugor_UnfreezeAll},
    {"protectMemory", "(JJI)Z", (void *)Bugor_ProtectMemory},
    {"allocateMemory", "(JI)J", (void *)Bugor_AllocateMemory},
    {"freeMemory", "(J)Z", (void *)Bugor_FreeMemory},
    {"getRegions", "()Ljava/lang/String;", (void *)Bugor_GetRegions},
    {"loadScriptFile", "(Ljava/lang/String;)Z", (void *)Bugor_LoadScriptFile},
    {"loadScript", "(Ljava/lang/String;Ljava/lang/String;)Z", (void *)Bugor_LoadScript},
    {"connectRemote", "(Ljava/lang/String;ILjava/lang/String;)Z", (void *)Bugor_ConnectRemote},
    {"disconnectRemote", "()Z", (void *)Bugor_DisconnectRemote},
    {"sendRemoteCommand", "(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;", (void *)Bugor_SendRemoteCommand},
    {"encrypt", "(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;", (void *)Bugor_Encrypt},
    {"decrypt", "(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;", (void *)Bugor_Decrypt},
    {"hash", "(Ljava/lang/String;)Ljava/lang/String;", (void *)Bugor_Hash},
    {"getMetrics", "()Ljava/lang/String;", (void *)Bugor_GetMetrics},
    {"setLogLevel", "(I)V", (void *)Bugor_SetLogLevel},
    {"log", "(ILjava/lang/String;)V", (void *)Bugor_Log},
    {"attachDebugger", "(I)Z", (void *)Bugor_AttachDebugger},
    {"detachDebugger", "()Z", (void *)Bugor_DetachDebugger},
    {"setBreakpoint", "(J)Z", (void *)Bugor_SetBreakpoint},
    {"storeValue", "(Ljava/lang/String;Ljava/lang/String;)Z", (void *)Bugor_StoreValue},
    {"loadValue", "(Ljava/lang/String;)Ljava/lang/String;", (void *)Bugor_LoadValue},
    {"deleteValue", "(Ljava/lang/String;)Z", (void *)Bugor_DeleteValue},
    {"getHealthStatus", "()Ljava/lang/String;", (void *)Bugor_GetHealthStatus},
    {"getEnginePointer", "()J", (void *)Bugor_GetEnginePointer},
    {"getState", "()I", (void *)Bugor_GetState},
    {"pause", "()Z", (void *)Bugor_Pause},
    {"resume", "()Z", (void *)Bugor_Resume},
    {"restart", "()Z", (void *)Bugor_Restart},
    {"getBuildInfo", "()Ljava/lang/String;", (void *)Bugor_GetBuildInfo},
    {"registerFunction", "(Ljava/lang/String;J)Z", (void *)Bugor_RegisterFunction},
    {"startServer", "(I)Z", (void *)Bugor_StartServer},
    {"stopServer", "()Z", (void *)Bugor_StopServer},
    {"nativeRegisterFunction", "(Ljava/lang/String;J)V", (void *)Bugor_RegisterFunctionV},
    {"nativeStartServer", "()V", (void *)Bugor_StartServerV},
    {"nativeStopServer", "()V", (void *)Bugor_StopServerV},
};

extern "C" jboolean NativeRoot_Init(JNIEnv*, jclass) { return JNI_FALSE; }
extern "C" jboolean NativeRoot_Available(JNIEnv*, jclass) { return JNI_FALSE; }
extern "C" jint NativeRoot_Exec(JNIEnv*, jclass, jstring) { return -1; }
extern "C" jstring NativeRoot_ExecOutput(JNIEnv* env, jclass, jstring) { return env->NewStringUTF(""); }
extern "C" jint NativeRoot_GetPid(JNIEnv*, jclass, jstring) { return -1; }
extern "C" jlong NativeRoot_GetModuleBase(JNIEnv*, jclass, jint, jstring) { return 0; }
extern "C" jobjectArray NativeRoot_ListModules(JNIEnv* env, jclass, jint) {
    return env->NewObjectArray(0, env->FindClass("java/lang/String"), nullptr);
}
extern "C" jboolean NativeRoot_WriteMemory(JNIEnv*, jclass, jint, jlong, jbyteArray) { return JNI_FALSE; }
extern "C" jbyteArray NativeRoot_ReadMemory(JNIEnv* env, jclass, jint, jlong, jint) { return env->NewByteArray(0); }
extern "C" jboolean NativeRoot_Mount(JNIEnv*, jclass, jstring, jstring) { return JNI_FALSE; }
extern "C" jboolean NativeRoot_SetSELinux(JNIEnv*, jclass, jstring, jstring) { return JNI_FALSE; }

static JNINativeMethod rootMethods[] = {
    {"nativeRootInit", "()Z", (void *)NativeRoot_Init},
    {"nativeRootAvailable", "()Z", (void *)NativeRoot_Available},
    {"nativeRootExec", "(Ljava/lang/String;)I", (void *)NativeRoot_Exec},
    {"nativeRootExecOutput", "(Ljava/lang/String;)Ljava/lang/String;", (void *)NativeRoot_ExecOutput},
    {"nativeRootGetPid", "(Ljava/lang/String;)I", (void *)NativeRoot_GetPid},
    {"nativeRootGetModuleBase", "(ILjava/lang/String;)J", (void *)NativeRoot_GetModuleBase},
    {"nativeRootListModules", "(I)[Ljava/lang/String;", (void *)NativeRoot_ListModules},
    {"nativeRootWriteMemory", "(IJ[B)Z", (void *)NativeRoot_WriteMemory},
    {"nativeRootReadMemory", "(IJI)[B", (void *)NativeRoot_ReadMemory},
    {"nativeRootMount", "(Ljava/lang/String;Ljava/lang/String;)Z", (void *)NativeRoot_Mount},
    {"nativeRootSetSELinux", "(Ljava/lang/String;Ljava/lang/String;)Z", (void *)NativeRoot_SetSELinux},
};

extern "C" int jniRegisterNativeMethods(JNIEnv *env, const char *className, JNINativeMethod *methods, int count) {
    jclass clazz = env->FindClass(className);
    if (!clazz) return JNI_FALSE;
    int result = env->RegisterNatives(clazz, methods, count) >= 0 ? JNI_TRUE : JNI_FALSE;
    env->DeleteLocalRef(clazz);
    return result;
}

extern "C" int registerNativeMethods(JNIEnv *env) {
    int r1 = jniRegisterNativeMethods(env, "com/bugor/engine/SuperJNI", methods, sizeof(methods) / sizeof(methods[0]));
    int r2 = jniRegisterNativeMethods(env, "com/bugor/engine/SuperJNI", rootMethods, sizeof(rootMethods) / sizeof(rootMethods[0]));
    return r1 && r2;
}

extern "C" jint JNI_OnLoad(JavaVM *vm, void *) {
    JNIEnv *env;
    if (vm->GetEnv((void **)&env, JNI_VERSION_1_6) != JNI_OK) return -1;
    if (!registerNativeMethods(env)) return -1;
    AntiDebug::CrashIfDebugged();
    return JNI_VERSION_1_6;
}

extern "C" void JNI_OnUnload(JavaVM *vm, void *) {
    JNIEnv *env;
    vm->GetEnv((void **)&env, JNI_VERSION_1_6);
    if (env) {
        jclass clazz = env->FindClass("com/bugor/engine/SuperJNI");
        if (clazz) env->DeleteLocalRef(clazz);
    }
    RequestEngineShutdown();
    shutdownGui();
    ImGui::DestroyContext();
    cleanupEngine();
}
