#ifndef BUGOR_MEMORY_MANAGER_H
#define BUGOR_MEMORY_MANAGER_H

#include <string>
#include <vector>
#include <map>
#include <unordered_map>
#include <functional>
#include <memory>
#include <mutex>
#include <atomic>
#include <cstring>
#include <cstdint>
#include <algorithm>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <thread>
#include <chrono>
#include <regex>
#include <set>

#include <sys/mman.h>
#include <sys/ptrace.h>
#include <sys/wait.h>
#include <sys/uio.h>
#include <sys/user.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>
#include <dlfcn.h>
#include <elf.h>
#include <link.h>

struct MemoryRegion {
    uintptr_t start;
    uintptr_t end;
    uintptr_t offset;
    uint32_t size;
    uint8_t protection;
    uint8_t flags;
    uint32_t inode;
    std::string path;
    std::string name;
    bool readable;
    bool writable;
    bool executable;
    bool shared;
    bool private_;
    bool is_anonymous;
    bool is_heap;
    bool is_stack;
    bool is_jit;
    bool is_ashmem;
    bool is_bss;
    bool is_data;
    bool is_text;
    bool is_java_heap;
    bool is_art;
    bool is_oat;
    bool is_dex;
    bool is_so;
    bool is_vdso;
    bool is_vvar;
    bool is_vsyscall;
    bool is_guard;
    bool is_file_backed;
    std::vector<uint8_t> data;
};

struct MemorySearchPattern {
    std::vector<uint8_t> bytes;
    std::vector<uint8_t> mask;
    std::string hex_string;
    std::string string_value;
    int value_type;
    int value_size;
    uint64_t value;
    uint64_t value_end;
    int alignment;
    int offset;
    bool use_regex;
    bool case_sensitive;
    bool use_mask;
    bool use_wildcards;
    bool use_pattern;
    bool use_bytes;
    bool use_string;
    bool use_value;
    bool use_range;
    bool fuzzy;
    bool signed_type;
    bool big_endian;
    std::regex regex_pattern;
    std::function<bool(const uint8_t*, size_t)> custom_matcher;
};

struct MemorySearchResult {
    uintptr_t address;
    uintptr_t offset;
    uint32_t size;
    uint32_t protection;
    std::string module;
    std::string region_name;
    std::vector<uint8_t> data;
    uint64_t current_value;
    uint64_t previous_value;
    bool value_changed;
    double similarity;
    int match_count;
    std::vector<uintptr_t> related_addresses;
};

struct MemoryFilter {
    int filter_type;
    int operation;
    int value_type;
    int value_size;
    uint64_t value;
    uint64_t previous_value;
    uint64_t min_value;
    uint64_t max_value;
    double min_float;
    double max_float;
    std::string string_value;
    bool case_sensitive;
    bool use_previous;
    bool use_range;
    bool fuzzy;
    bool signed_type;
    bool inverted;
    bool use_regex;
    std::regex regex_filter;
};

struct MemoryWriteOperation {
    uintptr_t address;
    uint32_t size;
    std::vector<uint8_t> data;
    uint64_t value;
    int value_type;
    bool preserve_protection;
    bool make_permanent;
    bool freeze_value;
    bool lock_region;
    bool async_write;
    int original_protection;
    std::vector<uint8_t> original_data;
};

struct MemoryMapConfig {
    uintptr_t base_address;
    uint32_t size;
    uint32_t protection;
    int flags;
    int fd;
    off_t offset;
    bool fixed;
    bool anonymous;
    bool shared;
    bool private_;
    bool populate;
    bool huge_pages;
    bool no_reserve;
    bool grow_down;
    bool deny_write;
    bool executable;
    bool writable;
    bool readable;
    bool jit;
    std::string name;
    std::string file_path;
};

struct MemoryPatch {
    uintptr_t address;
    uintptr_t original_address;
    uint32_t size;
    std::vector<uint8_t> original_bytes;
    std::vector<uint8_t> patch_bytes;
    std::string name;
    std::string module;
    bool applied;
    bool permanent;
    bool frozen;
    bool locked;
    int original_protection;
    std::chrono::system_clock::time_point applied_at;
};

struct AllocationInfo {
    uintptr_t address;
    uint32_t size;
    uint32_t protection;
    int flags;
    std::string tag;
    std::chrono::system_clock::time_point allocated_at;
    bool from_pool;
    bool is_native;
    bool is_java;
    bool is_external;
};

struct MemoryPool {
    uintptr_t base;
    uint32_t size;
    uint32_t used;
    uint32_t free;
    uint32_t block_size;
    uint32_t alignment;
    bool managed;
    bool growable;
    bool thread_safe;
    uint32_t allocation_count;
    uint32_t deallocation_count;
    std::vector<uint8_t> bitmap;
    std::vector<AllocationInfo> allocations;
    std::mutex poolMutex;
};

struct AllocationStats {
    uint64_t total_allocated;
    uint64_t total_freed;
    uint32_t current_allocations;
    uint32_t peak_allocations;
    uint64_t total_size;
    uint64_t peak_size;
    uint64_t current_size;
    uint32_t failed_allocations;
    uint32_t pool_hits;
    uint32_t pool_misses;
    uint64_t avg_allocation_size;
    uint64_t max_allocation_size;
    std::map<std::string, uint32_t> allocation_by_tag;
    std::map<uint32_t, uint32_t> allocation_by_size;
};

class MemoryManager {
public:
    MemoryManager();
    ~MemoryManager();

    bool initialize();
    void shutdown();
    bool isInitialized() const;

    bool readMemory(uintptr_t address, void *buffer, size_t size);
    bool writeMemory(uintptr_t address, const void *data, size_t size);
    bool writeMemory(uintptr_t address, uint64_t value, int value_type);
    bool writeMemoryProtected(uintptr_t address, const void *data, size_t size);
    bool writeMemorySafe(uintptr_t address, const void *data, size_t size);
    bool writeMemoryAtomic(uintptr_t address, const void *data, size_t size);
    bool writeMemoryAsync(uintptr_t address, const void *data, size_t size);

    std::vector<uint8_t> readBytes(uintptr_t address, size_t size);
    uint8_t readByte(uintptr_t address);
    uint16_t readShort(uintptr_t address);
    uint32_t readInt(uintptr_t address);
    uint64_t readLong(uintptr_t address);
    float readFloat(uintptr_t address);
    double readDouble(uintptr_t address);
    std::string readString(uintptr_t address, size_t max_length);
    std::string readUTF16String(uintptr_t address, size_t max_length);
    std::string readASCIIString(uintptr_t address, size_t max_length);

    bool writeByte(uintptr_t address, uint8_t value);
    bool writeShort(uintptr_t address, uint16_t value);
    bool writeInt(uintptr_t address, uint32_t value);
    bool writeLong(uintptr_t address, uint64_t value);
    bool writeFloat(uintptr_t address, float value);
    bool writeDouble(uintptr_t address, double value);
    bool writeString(uintptr_t address, const std::string &value);
    bool writeBytes(uintptr_t address, const std::vector<uint8_t> &data);

    bool patchMemory(uintptr_t address, const std::vector<uint8_t> &data);
    bool patchMemory(uintptr_t address, const std::string &hex_string);
    bool applyPatch(const MemoryPatch &patch);
    bool applyPatches(const std::vector<MemoryPatch> &patches);
    bool removePatch(const MemoryPatch &patch);
    bool removeAllPatches();
    bool restorePatch(const MemoryPatch &patch);
    bool restoreAllPatches();
    bool isPatched(uintptr_t address) const;
    std::vector<MemoryPatch> getActivePatches() const;
    uint32_t getPatchCount() const;

    MemoryPatch createPatch(uintptr_t address, const std::vector<uint8_t> &patch_bytes);
    MemoryPatch createPatch(const std::string &module, uintptr_t offset, const std::vector<uint8_t> &patch_bytes);
    MemoryPatch createPatch(const std::string &module, const std::string &pattern, const std::vector<uint8_t> &patch_bytes);

    bool freezeValue(uintptr_t address, uint64_t value, int value_type);
    bool freezeValue(uintptr_t address, const std::vector<uint8_t> &data);
    bool unfreezeValue(uintptr_t address);
    bool isFrozen(uintptr_t address) const;
    bool unfreezeAll();
    std::vector<uintptr_t> getFrozenAddresses() const;

    bool lockMemory(uintptr_t address, size_t size);
    bool unlockMemory(uintptr_t address);
    bool isLocked(uintptr_t address) const;
    bool lockAllMemory();
    bool unlockAllMemory();

    uintptr_t allocateMemory(size_t size, uint32_t protection = 0);
    uintptr_t allocateMemory(uintptr_t address, size_t size, uint32_t protection = 0);
    uintptr_t allocateNearbyMemory(uintptr_t near, size_t size, uint32_t protection = 0);
    bool freeMemory(uintptr_t address);
    bool freeMemory(uintptr_t address, size_t size);
    bool protectMemory(uintptr_t address, size_t size, int protection);
    int getMemoryProtection(uintptr_t address) const;

    bool makeExecutable(uintptr_t address, size_t size);
    bool makeWritable(uintptr_t address, size_t size);
    bool makeReadable(uintptr_t address, size_t size);
    bool makeReadWrite(uintptr_t address, size_t size);
    bool makeReadExecute(uintptr_t address, size_t size);
    bool makeReadWriteExecute(uintptr_t address, size_t size);

    MemoryPool *createMemoryPool(size_t size, uint32_t block_size = 0, uint32_t alignment = 16);
    bool destroyMemoryPool(MemoryPool *pool);
    bool destroyAllPools();
    uintptr_t poolAllocate(MemoryPool *pool, size_t size, const std::string &tag = "");
    bool poolDeallocate(MemoryPool *pool, uintptr_t address);
    AllocationStats getPoolStatistics(MemoryPool *pool) const;
    std::vector<MemoryPool*> getPools() const;

    std::vector<MemoryRegion> enumerateRegions();
    std::vector<MemoryRegion> enumerateRegions(uintptr_t start, uintptr_t end);
    std::vector<MemoryRegion> enumerateRegions(const std::string &path_filter);
    std::vector<MemoryRegion> enumerateExecutableRegions();
    std::vector<MemoryRegion> enumerateWritableRegions();
    std::vector<MemoryRegion> enumerateReadableRegions();
    std::vector<MemoryRegion> enumerateHeapRegions();
    std::vector<MemoryRegion> enumerateStackRegions();
    std::vector<MemoryRegion> enumerateAnonymousRegions();
    std::vector<MemoryRegion> enumerateFileBackedRegions();
    std::vector<MemoryRegion> enumerateJITRegions();
    std::vector<MemoryRegion> enumerateDEXRegions();
    std::vector<MemoryRegion> enumerateSOFilesRegions();
    std::vector<MemoryRegion> enumerateNativeHeapRegions();
    std::vector<MemoryRegion> enumerateJavaHeapRegions();

    MemoryRegion getRegion(uintptr_t address) const;
    MemoryRegion getRegion(const std::string &name) const;
    bool isRegionReadable(uintptr_t address) const;
    bool isRegionWritable(uintptr_t address) const;
    bool isRegionExecutable(uintptr_t address) const;

    std::vector<MemorySearchResult> search(const MemorySearchPattern &pattern);
    std::vector<MemorySearchResult> search(const MemorySearchPattern &pattern, const std::vector<MemoryRegion> &regions);
    std::vector<MemorySearchResult> search(const MemorySearchPattern &pattern, uintptr_t start, uintptr_t end);
    std::vector<MemorySearchResult> searchValue(uint64_t value, int value_type, int value_size);
    std::vector<MemorySearchResult> searchValueRange(uint64_t min_val, uint64_t max_val, int value_type, int value_size);
    std::vector<MemorySearchResult> searchString(const std::string &str, bool case_sensitive = false);
    std::vector<MemorySearchResult> searchBytes(const std::vector<uint8_t> &bytes, const std::vector<uint8_t> &mask = {});
    std::vector<MemorySearchResult> searchHex(const std::string &hex);
    std::vector<MemorySearchResult> searchPattern(const std::string &pattern, bool use_regex = false);
    std::vector<MemorySearchResult> searchNearby(uintptr_t address, uint32_t radius, const MemorySearchPattern &pattern);

    std::vector<MemorySearchResult> searchNext(const MemorySearchPattern &pattern, const std::vector<MemorySearchResult> &previous);
    std::vector<MemorySearchResult> filterResults(const std::vector<MemorySearchResult> &results, const MemoryFilter &filter);
    std::vector<MemorySearchResult> filterChanged(const std::vector<MemorySearchResult> &results);
    std::vector<MemorySearchResult> filterUnchanged(const std::vector<MemorySearchResult> &results);
    std::vector<MemorySearchResult> filterIncreased(const std::vector<MemorySearchResult> &results);
    std::vector<MemorySearchResult> filterDecreased(const std::vector<MemorySearchResult> &results);
    std::vector<MemorySearchResult> filterByValue(const std::vector<MemorySearchResult> &results, uint64_t value, int operation);
    std::vector<MemorySearchResult> filterByRange(const std::vector<MemorySearchResult> &results, uint64_t min_val, uint64_t max_val);
    std::vector<MemorySearchResult> filterByString(const std::vector<MemorySearchResult> &results, const std::string &str);

    bool groupResults(const std::vector<MemorySearchResult> &results, std::map<std::string, std::vector<MemorySearchResult>> &groups);
    bool sortResults(std::vector<MemorySearchResult> &results, const std::string &sort_by, bool ascending = true);

    bool isAddressValid(uintptr_t address) const;
    bool isAddressMapped(uintptr_t address) const;
    bool isAddressReadable(uintptr_t address) const;
    bool isAddressWritable(uintptr_t address) const;
    bool isAddressExecutable(uintptr_t address) const;

    uintptr_t getBaseAddress(const std::string &module) const;
    uintptr_t getModuleSize(const std::string &module) const;
    uintptr_t getAbsoluteAddress(const std::string &module, uintptr_t offset) const;
    uintptr_t findPatternInModule(const std::string &module, const std::string &pattern);
    uintptr_t findPattern(const std::vector<uint8_t> &pattern, const std::vector<uint8_t> &mask, const std::vector<MemoryRegion> &regions);
    uintptr_t findPattern(const std::string &hex_pattern, uintptr_t start, uintptr_t end);

    bool dumpMemory(const std::string &path, uintptr_t address, size_t size);
    bool dumpModule(const std::string &module_name, const std::string &output_path);
    bool dumpRegion(const MemoryRegion &region, const std::string &output_path);
    bool dumpAllExecutable(const std::string &output_dir);
    bool dumpHeap(const std::string &output_path);

    std::string dumpHex(uintptr_t address, size_t size);
    std::string dumpASCII(uintptr_t address, size_t max_length);
    std::string dumpStructure(uintptr_t address, const std::string &structure_def);

    void setSearchAlignment(uint32_t alignment);
    uint32_t getSearchAlignment() const;
    void setSearchLimit(uint32_t limit);
    uint32_t getSearchLimit() const;
    void setSearchTimeout(uint32_t timeout_ms);
    uint32_t getSearchTimeout() const;
    void setIOTimeout(uint32_t timeout_ms);
    uint32_t getIOTimeout() const;

    uint64_t getPageSize() const;
    uint64_t getAllocationGranularity() const;
    uint64_t getTotalPhysicalMemory() const;
    uint64_t getAvailableMemory() const;
    uint64_t getProcessMemoryUsage() const;

    AllocationStats getAllocationStatistics() const;
    void resetAllocationStatistics();
    uint32_t getAllocationCount() const;
    uint64_t getTotalAllocationSize() const;

    bool isProcessSuspended() const;
    bool suspendProcess();
    bool resumeProcess();
    bool isProcessAttached() const;
    bool attachProcess(pid_t pid);
    bool detachProcess();

    bool waitForModule(const std::string &module_name, uint32_t timeout_ms = 10000);
    uintptr_t getModuleBase(const std::string &module_name) const;
    std::vector<std::pair<std::string, uintptr_t>> getLoadedModules() const;

    bool setWatchpoint(uintptr_t address, size_t size);
    bool removeWatchpoint(uintptr_t address);
    bool removeAllWatchpoints();
    bool hasWatchpoint(uintptr_t address) const;

    bool setBreakpoint(uintptr_t address);
    bool removeBreakpoint(uintptr_t address);
    bool removeAllBreakpoints();
    bool hasBreakpoint(uintptr_t address) const;

    void onMemoryChange(std::function<void(uintptr_t, size_t, const std::vector<uint8_t>&)> callback);
    void onRegionChange(std::function<void(const MemoryRegion&, bool created)> callback);
    void onAllocation(std::function<void(uintptr_t, size_t)> callback);
    void onDeallocation(std::function<void(uintptr_t)> callback);

    std::string getVersion() const;
    std::string getArchitecture() const;
    bool isARM64() const;
    bool isARM32() const;
    bool isX86() const;
    bool isX64() const;

    bool saveState(const std::string &path);
    bool loadState(const std::string &path);
    bool exportSearchResults(const std::string &path, const std::vector<MemorySearchResult> &results);
    std::vector<MemorySearchResult> importSearchResults(const std::string &path);

private:
    bool initialized;
    bool processAttached;
    pid_t targetPid;
    uint32_t searchAlignment;
    uint32_t searchLimit;
    uint32_t searchTimeout;
    uint32_t m_IOTimeoutMs;
    uint32_t pageSize;

    std::mutex memoryMutex;
    std::mutex patchMutex;
    std::mutex freezeMutex;
    std::mutex poolMutex;
    std::mutex searchMutex;

    std::vector<MemoryPatch> patches;
    std::map<uintptr_t, MemoryWriteOperation> frozenValues;
    std::map<uintptr_t, bool> lockedRegions;
    std::map<uintptr_t, MemoryPool> pools;
    std::map<uintptr_t, uintptr_t> breakpoints;
    std::map<uintptr_t, size_t> watchpoints;
    std::vector<MemoryRegion> cachedRegions;
    uint64_t lastRegionRefresh;

    AllocationStats allocStats;
    uint32_t pageSize_;
    uint64_t allocGranularity;

    std::function<void(uintptr_t, size_t, const std::vector<uint8_t>&)> memoryChangeCallback;
    std::function<void(const MemoryRegion&, bool)> regionChangeCallback;
    std::function<void(uintptr_t, size_t)> allocCallback;
    std::function<void(uintptr_t)> deallocCallback;

    bool readMaps();
    bool readMaps(pid_t pid);
    MemoryRegion parseMapsLine(const std::string &line);
    bool parseProtection(const std::string &prot_str, uint8_t &prot, uint8_t &flags);
    void refreshRegions();
    bool refreshIfNeeded();
    bool isRegionCached(uintptr_t address) const;
    std::vector<uintptr_t> findAddresses(const MemorySearchPattern &pattern, const MemoryRegion &region);
    bool matchPattern(const uint8_t *data, size_t size, const MemorySearchPattern &pattern);
    bool matchValue(const uint8_t *data, size_t size, const MemorySearchPattern &pattern);
    bool matchString(const uint8_t *data, size_t size, const MemorySearchPattern &pattern);
    bool matchRegex(const uint8_t *data, size_t size, const MemorySearchPattern &pattern);
    bool matchCustom(const uint8_t *data, size_t size, const MemorySearchPattern &pattern);
    uint64_t readValue(const uint8_t *data, int value_type, int size, bool big_endian);
    void writeValue(uint8_t *data, uint64_t value, int value_type, int size, bool big_endian);
    bool writeMemoryInternal(uintptr_t address, const void *data, size_t size);
    bool readMemoryInternal(uintptr_t address, void *buffer, size_t size);
    bool writeMemoryWithPTrace(uintptr_t address, const void *data, size_t size);
    bool readMemoryWithPTrace(uintptr_t address, void *buffer, size_t size);
    bool createMemoryRegion(uintptr_t address, size_t size, int protection);
    void applyFrozenValues();
    uintptr_t findFreeRegion(size_t size, uintptr_t near = 0);
    bool isRegionOverlapping(const MemoryRegion &region) const;
};

#endif
