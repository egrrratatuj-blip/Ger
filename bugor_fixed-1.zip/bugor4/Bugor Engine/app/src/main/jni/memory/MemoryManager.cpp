#include "MemoryManager.h"
#include <sys/mman.h>
#include <sys/time.h>
#include <signal.h>
#include <vector>
#include <algorithm>
#include <cstdio>
#include <cerrno>
#include <cinttypes>

static void MMTimeoutHandler(int) {}

MemoryManager::MemoryManager()
    : initialized(false)
    , processAttached(false)
    , targetPid(0)
    , searchAlignment(1)
    , searchLimit(10000)
    , searchTimeout(5000)
    , m_IOTimeoutMs(5000)
    , pageSize(0)
    , pageSize_(0)
    , allocGranularity(0)
    , lastRegionRefresh(0)
{
    pageSize_ = static_cast<uint32_t>(sysconf(_SC_PAGESIZE));
    allocGranularity = static_cast<uint64_t>(sysconf(_SC_PAGE_SIZE));
    allocStats.total_allocated = 0;
    allocStats.total_freed = 0;
    allocStats.current_allocations = 0;
    allocStats.peak_allocations = 0;
    allocStats.total_size = 0;
    allocStats.peak_size = 0;
    allocStats.current_size = 0;
    allocStats.failed_allocations = 0;
    allocStats.pool_hits = 0;
    allocStats.pool_misses = 0;
    allocStats.avg_allocation_size = 0;
    allocStats.max_allocation_size = 0;
}

MemoryManager::~MemoryManager()
{
    shutdown();
}

bool MemoryManager::initialize()
{
    std::lock_guard<std::mutex> lock(memoryMutex);
    if (initialized) return true;
    pageSize_ = static_cast<uint32_t>(sysconf(_SC_PAGESIZE));
    allocGranularity = static_cast<uint64_t>(sysconf(_SC_PAGE_SIZE));
    refreshRegions();
    initialized = true;
    return true;
}

void MemoryManager::shutdown()
{
    std::lock_guard<std::mutex> lock(memoryMutex);
    if (!initialized) return;
    removeAllPatches();
    unfreezeAll();
    unlockAllMemory();
    destroyAllPools();
    removeAllBreakpoints();
    removeAllWatchpoints();
    if (processAttached) detachProcess();
    initialized = false;
}

bool MemoryManager::isInitialized() const
{
    return initialized;
}

bool MemoryManager::readMemory(uintptr_t address, void *buffer, size_t size)
{
    if (!initialized || !buffer || size == 0) return false;
    if (!isAddressValid(address)) return false;
    return readMemoryInternal(address, buffer, size);
}

bool MemoryManager::writeMemory(uintptr_t address, const void *data, size_t size)
{
    if (!initialized || !data || size == 0) return false;
    if (!isAddressWritable(address)) return false;
    return writeMemoryInternal(address, data, size);
}

bool MemoryManager::writeMemory(uintptr_t address, uint64_t value, int value_type)
{
    std::vector<uint8_t> buf(8);
    writeValue(buf.data(), value, value_type, static_cast<int>(buf.size()), false);
    return writeMemory(address, buf.data(), buf.size());
}

bool MemoryManager::writeMemoryProtected(uintptr_t address, const void *data, size_t size)
{
    if (!initialized || !data || size == 0) return false;
    int old_prot = getMemoryProtection(address);
    if (old_prot == -1) return false;
    uintptr_t page_start = address & ~(pageSize_ - 1);
    size_t region_size = ((address + size - page_start + pageSize_ - 1) / pageSize_) * pageSize_;
    if (mprotect(reinterpret_cast<void*>(page_start), region_size, PROT_READ | PROT_WRITE) != 0) return false;
    bool result = writeMemoryInternal(address, data, size);
    mprotect(reinterpret_cast<void*>(page_start), region_size, old_prot);
    return result;
}

bool MemoryManager::writeMemorySafe(uintptr_t address, const void *data, size_t size)
{
    if (!initialized || !data || size == 0) return false;
    if (!isAddressValid(address)) return false;
    std::vector<uint8_t> verify(size);
    if (!writeMemoryInternal(address, data, size)) return false;
    if (!readMemoryInternal(address, verify.data(), size)) return false;
    return memcmp(data, verify.data(), size) == 0;
}

bool MemoryManager::writeMemoryAtomic(uintptr_t address, const void *data, size_t size)
{
    if (!initialized || !data || size == 0) return false;
    std::lock_guard<std::mutex> lock(memoryMutex);
    std::vector<uint8_t> backup(size);
    readMemoryInternal(address, backup.data(), size);
    if (!writeMemoryInternal(address, data, size)) return false;
    std::vector<uint8_t> verify(size);
    readMemoryInternal(address, verify.data(), size);
    if (memcmp(data, verify.data(), size) != 0) {
        writeMemoryInternal(address, backup.data(), size);
        return false;
    }
    if (memoryChangeCallback) {
        memoryChangeCallback(address, size, std::vector<uint8_t>(static_cast<const uint8_t*>(data), static_cast<const uint8_t*>(data) + size));
    }
    return true;
}

bool MemoryManager::writeMemoryAsync(uintptr_t address, const void *data, size_t size)
{
    return writeMemoryProtected(address, data, size);
}

std::vector<uint8_t> MemoryManager::readBytes(uintptr_t address, size_t size)
{
    std::vector<uint8_t> result(size);
    if (!readMemory(address, result.data(), size)) result.clear();
    return result;
}

uint8_t MemoryManager::readByte(uintptr_t address)
{
    uint8_t val = 0;
    readMemory(address, &val, sizeof(val));
    return val;
}

uint16_t MemoryManager::readShort(uintptr_t address)
{
    uint16_t val = 0;
    readMemory(address, &val, sizeof(val));
    return val;
}

uint32_t MemoryManager::readInt(uintptr_t address)
{
    uint32_t val = 0;
    readMemory(address, &val, sizeof(val));
    return val;
}

uint64_t MemoryManager::readLong(uintptr_t address)
{
    uint64_t val = 0;
    readMemory(address, &val, sizeof(val));
    return val;
}

float MemoryManager::readFloat(uintptr_t address)
{
    float val = 0.0f;
    readMemory(address, &val, sizeof(val));
    return val;
}

double MemoryManager::readDouble(uintptr_t address)
{
    double val = 0.0;
    readMemory(address, &val, sizeof(val));
    return val;
}

std::string MemoryManager::readString(uintptr_t address, size_t max_length)
{
    std::string result;
    result.reserve(max_length);
    for (size_t i = 0; i < max_length; ++i) {
        char c = static_cast<char>(readByte(address + i));
        if (c == '\0') break;
        result.push_back(c);
    }
    return result;
}

std::string MemoryManager::readUTF16String(uintptr_t address, size_t max_length)
{
    std::string result;
    result.reserve(max_length);
    for (size_t i = 0; i < max_length; i += 2) {
        uint16_t c = readShort(address + i);
        if (c == 0) break;
        if (c <= 0x7F) {
            result.push_back(static_cast<char>(c));
        } else if (c <= 0x7FF) {
            result.push_back(static_cast<char>(0xC0 | (c >> 6)));
            result.push_back(static_cast<char>(0x80 | (c & 0x3F)));
        } else {
            result.push_back(static_cast<char>(0xE0 | (c >> 12)));
            result.push_back(static_cast<char>(0x80 | ((c >> 6) & 0x3F)));
            result.push_back(static_cast<char>(0x80 | (c & 0x3F)));
        }
    }
    return result;
}

std::string MemoryManager::readASCIIString(uintptr_t address, size_t max_length)
{
    return readString(address, max_length);
}

bool MemoryManager::writeByte(uintptr_t address, uint8_t value)
{
    return writeMemory(address, &value, sizeof(value));
}

bool MemoryManager::writeShort(uintptr_t address, uint16_t value)
{
    return writeMemory(address, &value, sizeof(value));
}

bool MemoryManager::writeInt(uintptr_t address, uint32_t value)
{
    return writeMemory(address, &value, sizeof(value));
}

bool MemoryManager::writeLong(uintptr_t address, uint64_t value)
{
    return writeMemory(address, &value, sizeof(value));
}

bool MemoryManager::writeFloat(uintptr_t address, float value)
{
    return writeMemory(address, &value, sizeof(value));
}

bool MemoryManager::writeDouble(uintptr_t address, double value)
{
    return writeMemory(address, &value, sizeof(value));
}

bool MemoryManager::writeString(uintptr_t address, const std::string &value)
{
    return writeMemory(address, value.c_str(), value.size() + 1);
}

bool MemoryManager::writeBytes(uintptr_t address, const std::vector<uint8_t> &data)
{
    return writeMemory(address, data.data(), data.size());
}

bool MemoryManager::patchMemory(uintptr_t address, const std::vector<uint8_t> &data)
{
    return writeMemoryProtected(address, data.data(), data.size());
}

bool MemoryManager::patchMemory(uintptr_t address, const std::string &hex_string)
{
    std::vector<uint8_t> bytes;
    bytes.reserve(hex_string.size() / 2);
    for (size_t i = 0; i < hex_string.size(); i += 2) {
        uint8_t byte = 0;
        for (int j = 0; j < 2; ++j) {
            char c = hex_string[i + j];
            byte <<= 4;
            if (c >= '0' && c <= '9') byte |= static_cast<uint8_t>(c - '0');
            else if (c >= 'a' && c <= 'f') byte |= static_cast<uint8_t>(10 + c - 'a');
            else if (c >= 'A' && c <= 'F') byte |= static_cast<uint8_t>(10 + c - 'A');
        }
        bytes.push_back(byte);
    }
    return writeMemoryProtected(address, bytes.data(), bytes.size());
}

bool MemoryManager::applyPatch(const MemoryPatch &patch)
{
    std::lock_guard<std::mutex> lock(patchMutex);
    if (patch.applied) return true;
    uintptr_t addr = patch.address;
    const std::vector<uint8_t> &data = patch.patch_bytes;
    if (!writeMemoryProtected(addr, data.data(), data.size())) return false;
    MemoryPatch &p = const_cast<MemoryPatch&>(patch);
    p.applied = true;
    p.applied_at = std::chrono::system_clock::now();
    patches.push_back(patch);
    return true;
}

bool MemoryManager::applyPatches(const std::vector<MemoryPatch> &patches)
{
    bool all_ok = true;
    for (const auto &p : patches) {
        if (!applyPatch(p)) all_ok = false;
    }
    return all_ok;
}

bool MemoryManager::removePatch(const MemoryPatch &patch)
{
    std::lock_guard<std::mutex> lock(patchMutex);
    auto it = std::find_if(patches.begin(), patches.end(),
        [&patch](const MemoryPatch &p) { return p.address == patch.address; });
    if (it == patches.end()) return false;
    writeMemoryProtected(it->address, it->original_bytes.data(), it->original_bytes.size());
    patches.erase(it);
    return true;
}

bool MemoryManager::removeAllPatches()
{
    std::lock_guard<std::mutex> lock(patchMutex);
    for (auto &p : patches) {
        writeMemoryProtected(p.address, p.original_bytes.data(), p.original_bytes.size());
    }
    patches.clear();
    return true;
}

bool MemoryManager::restorePatch(const MemoryPatch &patch)
{
    return removePatch(patch);
}

bool MemoryManager::restoreAllPatches()
{
    return removeAllPatches();
}

bool MemoryManager::isPatched(uintptr_t address) const
{
    std::lock_guard<std::mutex> lock(patchMutex);
    return std::any_of(patches.begin(), patches.end(),
        [address](const MemoryPatch &p) { return p.address == address && p.applied; });
}

std::vector<MemoryPatch> MemoryManager::getActivePatches() const
{
    std::lock_guard<std::mutex> lock(patchMutex);
    return patches;
}

uint32_t MemoryManager::getPatchCount() const
{
    std::lock_guard<std::mutex> lock(patchMutex);
    return static_cast<uint32_t>(patches.size());
}

MemoryPatch MemoryManager::createPatch(uintptr_t address, const std::vector<uint8_t> &patch_bytes)
{
    MemoryPatch patch;
    patch.address = address;
    patch.patch_bytes = patch_bytes;
    patch.size = static_cast<uint32_t>(patch_bytes.size());
    patch.original_bytes.resize(patch_bytes.size());
    readMemory(address, patch.original_bytes.data(), patch_bytes.size());
    patch.original_address = address;
    patch.applied = false;
    patch.permanent = false;
    patch.frozen = false;
    patch.locked = false;
    return patch;
}

MemoryPatch MemoryManager::createPatch(const std::string &module, uintptr_t offset, const std::vector<uint8_t> &patch_bytes)
{
    uintptr_t base = getModuleBase(module);
    if (base == 0) return MemoryPatch();
    return createPatch(base + offset, patch_bytes);
}

MemoryPatch MemoryManager::createPatch(const std::string &module, const std::string &pattern, const std::vector<uint8_t> &patch_bytes)
{
    uintptr_t addr = findPatternInModule(module, pattern);
    if (addr == 0) return MemoryPatch();
    return createPatch(addr, patch_bytes);
}

bool MemoryManager::freezeValue(uintptr_t address, uint64_t value, int value_type)
{
    std::lock_guard<std::mutex> lock(freezeMutex);
    MemoryWriteOperation op;
    op.address = address;
    op.value = value;
    op.value_type = value_type;
    op.size = static_cast<uint32_t>((value_type == 0) ? 4 : (value_type == 1) ? 8 : 1);
    op.freeze_value = true;
    op.original_data.resize(op.size);
    readMemory(address, op.original_data.data(), op.size);
    frozenValues[address] = op;
    return writeMemory(address, value, value_type);
}

bool MemoryManager::freezeValue(uintptr_t address, const std::vector<uint8_t> &data)
{
    std::lock_guard<std::mutex> lock(freezeMutex);
    MemoryWriteOperation op;
    op.address = address;
    op.data = data;
    op.size = static_cast<uint32_t>(data.size());
    op.freeze_value = true;
    op.original_data.resize(data.size());
    readMemory(address, op.original_data.data(), data.size());
    frozenValues[address] = op;
    return writeMemory(address, data.data(), data.size());
}

bool MemoryManager::unfreezeValue(uintptr_t address)
{
    std::lock_guard<std::mutex> lock(freezeMutex);
    auto it = frozenValues.find(address);
    if (it == frozenValues.end()) return false;
    bool ok = writeMemory(address, it->second.original_data.data(), it->second.original_data.size());
    frozenValues.erase(it);
    return ok;
}

bool MemoryManager::isFrozen(uintptr_t address) const
{
    std::lock_guard<std::mutex> lock(freezeMutex);
    return frozenValues.find(address) != frozenValues.end();
}

bool MemoryManager::unfreezeAll()
{
    std::lock_guard<std::mutex> lock(freezeMutex);
    bool all_ok = true;
    for (auto &kv : frozenValues) {
        if (!writeMemory(kv.first, kv.second.original_data.data(), kv.second.original_data.size())) {
            all_ok = false;
        }
    }
    frozenValues.clear();
    return all_ok;
}

std::vector<uintptr_t> MemoryManager::getFrozenAddresses() const
{
    std::lock_guard<std::mutex> lock(freezeMutex);
    std::vector<uintptr_t> addrs;
    addrs.reserve(frozenValues.size());
    for (const auto &kv : frozenValues) addrs.push_back(kv.first);
    return addrs;
}

bool MemoryManager::lockMemory(uintptr_t address, size_t size)
{
    std::lock_guard<std::mutex> lock(memoryMutex);
    if (mlock(reinterpret_cast<void*>(address), size) != 0) return false;
    lockedRegions[address] = true;
    return true;
}

bool MemoryManager::unlockMemory(uintptr_t address)
{
    std::lock_guard<std::mutex> lock(memoryMutex);
    auto it = lockedRegions.find(address);
    if (it == lockedRegions.end()) return false;
    if (munlock(reinterpret_cast<void*>(address), pageSize_) != 0) return false;
    lockedRegions.erase(it);
    return true;
}

bool MemoryManager::isLocked(uintptr_t address) const
{
    std::lock_guard<std::mutex> lock(memoryMutex);
    return lockedRegions.find(address) != lockedRegions.end();
}

bool MemoryManager::lockAllMemory()
{
    std::lock_guard<std::mutex> lock(memoryMutex);
    auto regions = enumerateRegions();
    bool all_ok = true;
    for (const auto &r : regions) {
        if (!r.is_anonymous) continue;
        if (mlock(reinterpret_cast<void*>(r.start), r.size) != 0) all_ok = false;
        else lockedRegions[r.start] = true;
    }
    return all_ok;
}

bool MemoryManager::unlockAllMemory()
{
    std::lock_guard<std::mutex> lock(memoryMutex);
    bool all_ok = true;
    for (auto &kv : lockedRegions) {
        if (munlock(reinterpret_cast<void*>(kv.first), pageSize_) != 0) all_ok = false;
    }
    lockedRegions.clear();
    return all_ok;
}

uintptr_t MemoryManager::allocateMemory(size_t size, uint32_t protection)
{
    if (protection == 0) protection = PROT_READ | PROT_WRITE;
    void *addr = mmap(nullptr, size, static_cast<int>(protection), MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (addr == MAP_FAILED) return 0;
    uintptr_t result = reinterpret_cast<uintptr_t>(addr);
    std::lock_guard<std::mutex> lock(memoryMutex);
    ++allocStats.current_allocations;
    allocStats.total_allocated += size;
    allocStats.total_size += size;
    allocStats.current_size += size;
    if (allocStats.current_allocations > allocStats.peak_allocations) allocStats.peak_allocations = allocStats.current_allocations;
    if (size > allocStats.max_allocation_size) allocStats.max_allocation_size = size;
    return result;
}

uintptr_t MemoryManager::allocateMemory(uintptr_t address, size_t size, uint32_t protection)
{
    if (protection == 0) protection = PROT_READ | PROT_WRITE;
    void *addr = mmap(reinterpret_cast<void*>(address), size, static_cast<int>(protection), MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    if (addr == MAP_FAILED) return 0;
    return reinterpret_cast<uintptr_t>(addr);
}

uintptr_t MemoryManager::allocateNearbyMemory(uintptr_t near, size_t size, uint32_t protection)
{
    uintptr_t region = findFreeRegion(size, near);
    if (region == 0) return 0;
    return allocateMemory(region, size, protection);
}

bool MemoryManager::freeMemory(uintptr_t address)
{
    if (address == 0) return false;
    void *addr = reinterpret_cast<void*>(address);
    size_t size = pageSize_;
    for (const auto &r : cachedRegions) {
        if (r.start == address) { size = r.size; break; }
    }
    int ret = munmap(addr, size);
    if (ret == 0) {
        std::lock_guard<std::mutex> lock(memoryMutex);
        ++allocStats.current_allocations;
        allocStats.total_freed += size;
        allocStats.current_size -= size;
    }
    return ret == 0;
}

bool MemoryManager::freeMemory(uintptr_t address, size_t size)
{
    if (address == 0 || size == 0) return false;
    int ret = munmap(reinterpret_cast<void*>(address), size);
    if (ret == 0) {
        std::lock_guard<std::mutex> lock(memoryMutex);
        ++allocStats.current_allocations;
        allocStats.total_freed += size;
        allocStats.current_size -= size;
    }
    return ret == 0;
}

bool MemoryManager::protectMemory(uintptr_t address, size_t size, int protection)
{
    uintptr_t page_start = address & ~(pageSize_ - 1);
    size_t region_size = ((address - page_start + size + pageSize_ - 1) / pageSize_) * pageSize_;
    return mprotect(reinterpret_cast<void*>(page_start), region_size, protection) == 0;
}

int MemoryManager::getMemoryProtection(uintptr_t address) const
{
    for (const auto &r : cachedRegions) {
        if (address >= r.start && address < r.end) return r.protection;
    }
    return -1;
}

bool MemoryManager::makeExecutable(uintptr_t address, size_t size)
{
    return protectMemory(address, size, PROT_READ | PROT_EXEC);
}

bool MemoryManager::makeWritable(uintptr_t address, size_t size)
{
    return protectMemory(address, size, PROT_READ | PROT_WRITE);
}

bool MemoryManager::makeReadable(uintptr_t address, size_t size)
{
    return protectMemory(address, size, PROT_READ);
}

bool MemoryManager::makeReadWrite(uintptr_t address, size_t size)
{
    return protectMemory(address, size, PROT_READ | PROT_WRITE);
}

bool MemoryManager::makeReadExecute(uintptr_t address, size_t size)
{
    return protectMemory(address, size, PROT_READ | PROT_EXEC);
}

bool MemoryManager::makeReadWriteExecute(uintptr_t address, size_t size)
{
    return protectMemory(address, size, PROT_READ | PROT_WRITE | PROT_EXEC);
}

MemoryPool *MemoryManager::createMemoryPool(size_t size, uint32_t block_size, uint32_t alignment)
{
    if (block_size == 0) block_size = static_cast<uint32_t>(pageSize_);
    if (alignment == 0) alignment = 16;
    uintptr_t base = allocateMemory(size, PROT_READ | PROT_WRITE);
    if (base == 0) return nullptr;
    auto pool = std::make_unique<MemoryPool>();
    pool->base = base;
    pool->size = static_cast<uint32_t>(size);
    pool->used = 0;
    pool->free = static_cast<uint32_t>(size);
    pool->block_size = block_size;
    pool->alignment = alignment;
    pool->managed = true;
    pool->growable = false;
    pool->thread_safe = true;
    pool->allocation_count = 0;
    pool->deallocation_count = 0;
    size_t bitmap_size = (size + block_size - 1) / block_size;
    pool->bitmap.resize(bitmap_size, 0);
    MemoryPool *raw = pool.get();
    std::lock_guard<std::mutex> lock(poolMutex);
    pools[base] = std::move(*pool);
    return raw;
}

bool MemoryManager::destroyMemoryPool(MemoryPool *pool)
{
    if (!pool) return false;
    std::lock_guard<std::mutex> lock(poolMutex);
    auto it = pools.find(pool->base);
    if (it == pools.end()) return false;
    freeMemory(pool->base, pool->size);
    pools.erase(it);
    return true;
}

bool MemoryManager::destroyAllPools()
{
    std::lock_guard<std::mutex> lock(poolMutex);
    bool all_ok = true;
    for (auto &kv : pools) {
        if (!freeMemory(kv.first, kv.second.size)) all_ok = false;
    }
    pools.clear();
    return all_ok;
}

uintptr_t MemoryManager::poolAllocate(MemoryPool *pool, size_t size, const std::string &tag)
{
    if (!pool || size == 0) return 0;
    std::lock_guard<std::mutex> lock(pool->poolMutex);
    size_t aligned = (size + pool->alignment - 1) & ~(pool->alignment - 1);
    if (aligned > pool->free) return 0;
    uint32_t blocks_needed = static_cast<uint32_t>((aligned + pool->block_size - 1) / pool->block_size);
    uint32_t total_blocks = static_cast<uint32_t>(pool->bitmap.size());
    uint32_t start_block = total_blocks;
    for (uint32_t i = 0; i <= total_blocks - blocks_needed; ++i) {
        bool free_run = true;
        for (uint32_t j = 0; j < blocks_needed; ++j) {
            if (pool->bitmap[i + j] != 0) { free_run = false; break; }
        }
        if (free_run) { start_block = i; break; }
    }
    if (start_block >= total_blocks) return 0;
    for (uint32_t j = 0; j < blocks_needed; ++j) pool->bitmap[start_block + j] = 1;
    uintptr_t addr = pool->base + start_block * pool->block_size;
    pool->used += static_cast<uint32_t>(aligned);
    pool->free -= static_cast<uint32_t>(aligned);
    ++pool->allocation_count;
    AllocationInfo info;
    info.address = addr;
    info.size = static_cast<uint32_t>(aligned);
    info.tag = tag;
    info.allocated_at = std::chrono::system_clock::now();
    info.from_pool = true;
    pool->allocations.push_back(info);
    if (allocCallback) allocCallback(addr, aligned);
    return addr;
}

bool MemoryManager::poolDeallocate(MemoryPool *pool, uintptr_t address)
{
    if (!pool || address < pool->base) return false;
    std::lock_guard<std::mutex> lock(pool->poolMutex);
    uint32_t block_index = static_cast<uint32_t>((address - pool->base) / pool->block_size);
    if (block_index >= pool->bitmap.size() || pool->bitmap[block_index] == 0) return false;
    pool->bitmap[block_index] = 0;
    pool->used -= pool->block_size;
    pool->free += pool->block_size;
    ++pool->deallocation_count;
    auto it = std::find_if(pool->allocations.begin(), pool->allocations.end(),
        [address](const AllocationInfo &a) { return a.address == address; });
    if (it != pool->allocations.end()) pool->allocations.erase(it);
    if (deallocCallback) deallocCallback(address);
    return true;
}

AllocatorStats MemoryManager::getPoolStatistics(MemoryPool *pool) const
{
    AllocatorStats stats;
    if (!pool) return stats;
    stats.total_allocated = pool->allocation_count;
    stats.total_freed = pool->deallocation_count;
    stats.current_size = pool->used;
    stats.peak_size = pool->size;
    return stats;
}

std::vector<MemoryPool*> MemoryManager::getPools() const
{
    std::lock_guard<std::mutex> lock(poolMutex);
    std::vector<MemoryPool*> result;
    for (auto &kv : pools) result.push_back(const_cast<MemoryPool*>(&kv.second));
    return result;
}

std::vector<MemoryRegion> MemoryManager::enumerateRegions()
{
    refreshIfNeeded();
    return cachedRegions;
}

std::vector<MemoryRegion> MemoryManager::enumerateRegions(uintptr_t start, uintptr_t end)
{
    refreshIfNeeded();
    std::vector<MemoryRegion> result;
    for (const auto &r : cachedRegions) {
        if (r.start >= start && r.end <= end) result.push_back(r);
    }
    return result;
}

std::vector<MemoryRegion> MemoryManager::enumerateRegions(const std::string &path_filter)
{
    refreshIfNeeded();
    std::vector<MemoryRegion> result;
    for (const auto &r : cachedRegions) {
        if (r.path.find(path_filter) != std::string::npos) result.push_back(r);
    }
    return result;
}

std::vector<MemoryRegion> MemoryManager::enumerateExecutableRegions()
{
    refreshIfNeeded();
    std::vector<MemoryRegion> result;
    for (const auto &r : cachedRegions) {
        if (r.executable) result.push_back(r);
    }
    return result;
}

std::vector<MemoryRegion> MemoryManager::enumerateWritableRegions()
{
    refreshIfNeeded();
    std::vector<MemoryRegion> result;
    for (const auto &r : cachedRegions) {
        if (r.writable) result.push_back(r);
    }
    return result;
}

std::vector<MemoryRegion> MemoryManager::enumerateReadableRegions()
{
    refreshIfNeeded();
    std::vector<MemoryRegion> result;
    for (const auto &r : cachedRegions) {
        if (r.readable) result.push_back(r);
    }
    return result;
}

std::vector<MemoryRegion> MemoryManager::enumerateHeapRegions()
{
    refreshIfNeeded();
    std::vector<MemoryRegion> result;
    for (const auto &r : cachedRegions) {
        if (r.is_heap) result.push_back(r);
    }
    return result;
}

std::vector<MemoryRegion> MemoryManager::enumerateStackRegions()
{
    refreshIfNeeded();
    std::vector<MemoryRegion> result;
    for (const auto &r : cachedRegions) {
        if (r.is_stack) result.push_back(r);
    }
    return result;
}

std::vector<MemoryRegion> MemoryManager::enumerateAnonymousRegions()
{
    refreshIfNeeded();
    std::vector<MemoryRegion> result;
    for (const auto &r : cachedRegions) {
        if (r.is_anonymous) result.push_back(r);
    }
    return result;
}

std::vector<MemoryRegion> MemoryManager::enumerateFileBackedRegions()
{
    refreshIfNeeded();
    std::vector<MemoryRegion> result;
    for (const auto &r : cachedRegions) {
        if (r.is_file_backed) result.push_back(r);
    }
    return result;
}

std::vector<MemoryRegion> MemoryManager::enumerateJITRegions()
{
    refreshIfNeeded();
    std::vector<MemoryRegion> result;
    for (const auto &r : cachedRegions) {
        if (r.is_jit) result.push_back(r);
    }
    return result;
}

std::vector<MemoryRegion> MemoryManager::enumerateDEXRegions()
{
    refreshIfNeeded();
    std::vector<MemoryRegion> result;
    for (const auto &r : cachedRegions) {
        if (r.is_dex) result.push_back(r);
    }
    return result;
}

std::vector<MemoryRegion> MemoryManager::enumerateSOFilesRegions()
{
    refreshIfNeeded();
    std::vector<MemoryRegion> result;
    for (const auto &r : cachedRegions) {
        if (r.is_so) result.push_back(r);
    }
    return result;
}

std::vector<MemoryRegion> MemoryManager::enumerateNativeHeapRegions()
{
    return enumerateHeapRegions();
}

std::vector<MemoryRegion> MemoryManager::enumerateJavaHeapRegions()
{
    refreshIfNeeded();
    std::vector<MemoryRegion> result;
    for (const auto &r : cachedRegions) {
        if (r.is_java_heap) result.push_back(r);
    }
    return result;
}

MemoryRegion MemoryManager::getRegion(uintptr_t address) const
{
    for (const auto &r : cachedRegions) {
        if (address >= r.start && address < r.end) return r;
    }
    return MemoryRegion();
}

MemoryRegion MemoryManager::getRegion(const std::string &name) const
{
    for (const auto &r : cachedRegions) {
        if (r.name == name || r.path.find(name) != std::string::npos) return r;
    }
    return MemoryRegion();
}

bool MemoryManager::isRegionReadable(uintptr_t address) const
{
    auto r = getRegion(address);
    return r.readable;
}

bool MemoryManager::isRegionWritable(uintptr_t address) const
{
    auto r = getRegion(address);
    return r.writable;
}

bool MemoryManager::isRegionExecutable(uintptr_t address) const
{
    auto r = getRegion(address);
    return r.executable;
}

bool MemoryManager::readMaps()
{
    return readMaps(getpid());
}

bool MemoryManager::readMaps(pid_t pid)
{
    cachedRegions.clear();
    std::string path = "/proc/" + std::to_string(pid) + "/maps";
    std::ifstream maps_file(path);
    if (!maps_file.is_open()) return false;
    std::string line;
    while (std::getline(maps_file, line)) {
        cachedRegions.push_back(parseMapsLine(line));
    }
    lastRegionRefresh = static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count());
    return true;
}

MemoryRegion MemoryManager::parseMapsLine(const std::string &line)
{
    MemoryRegion region;
    memset(&region, 0, sizeof(region));
    std::istringstream iss(line);
    std::string addr_range, perms, offset_hex, dev, inode_str, path_name;
    iss >> addr_range >> perms >> offset_hex >> dev >> inode_str;
    std::getline(iss, path_name);
    if (!path_name.empty() && path_name[0] == ' ') path_name.erase(0, 1);
    size_t dash = addr_range.find('-');
    if (dash != std::string::npos) {
        region.start = std::stoull(addr_range.substr(0, dash), nullptr, 16);
        region.end = std::stoull(addr_range.substr(dash + 1), nullptr, 16);
    }
    region.size = static_cast<uint32_t>(region.end - region.start);
    region.offset = std::stoull(offset_hex, nullptr, 16);
    region.inode = static_cast<uint32_t>(std::stoul(inode_str));
    region.path = path_name;
    size_t last_slash = path_name.rfind('/');
    region.name = (last_slash != std::string::npos) ? path_name.substr(last_slash + 1) : path_name;
    region.readable = perms.size() > 0 && perms[0] == 'r';
    region.writable = perms.size() > 1 && perms[1] == 'w';
    region.executable = perms.size() > 2 && perms[2] == 'x';
    region.shared = perms.size() > 3 && perms[3] == 's';
    region.private_ = perms.size() > 3 && perms[3] == 'p';
    region.is_anonymous = path_name.empty() || path_name == "[anon]";
    region.is_heap = path_name.find("[heap]") != std::string::npos;
    region.is_stack = path_name.find("[stack") != std::string::npos;
    region.is_so = path_name.find(".so") != std::string::npos;
    region.is_jit = path_name.find("[JIT]") != std::string::npos || path_name.find("jit") != std::string::npos;
    region.is_vdso = path_name.find("[vdso]") != std::string::npos;
    region.is_vvar = path_name.find("[vvar]") != std::string::npos;
    region.is_vsyscall = path_name.find("[vsyscall]") != std::string::npos;
    region.is_file_backed = !region.is_anonymous && !path_name.empty();
    region.protection = 0;
    if (region.readable) region.protection |= PROT_READ;
    if (region.writable) region.protection |= PROT_WRITE;
    if (region.executable) region.protection |= PROT_EXEC;
    return region;
}

bool MemoryManager::parseProtection(const std::string &prot_str, uint8_t &prot, uint8_t &flags)
{
    prot = 0;
    flags = 0;
    if (prot_str.size() < 4) return false;
    if (prot_str[0] == 'r') prot |= PROT_READ;
    if (prot_str[1] == 'w') prot |= PROT_WRITE;
    if (prot_str[2] == 'x') prot |= PROT_EXEC;
    if (prot_str[3] == 's') flags = 1;
    else if (prot_str[3] == 'p') flags = 2;
    return true;
}

void MemoryManager::refreshRegions()
{
    readMaps();
}

bool MemoryManager::refreshIfNeeded()
{
    uint64_t now = static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count());
    if (now - lastRegionRefresh > 1000) {
        readMaps();
        return true;
    }
    return false;
}

bool MemoryManager::isRegionCached(uintptr_t address) const
{
    for (const auto &r : cachedRegions) {
        if (address >= r.start && address < r.end) return true;
    }
    return false;
}

std::vector<uintptr_t> MemoryManager::findAddresses(const MemorySearchPattern &pattern, const MemoryRegion &region)
{
    std::vector<uintptr_t> results;
    size_t size = region.size;
    if (size == 0 || size > 1024 * 1024 * 1024) return results;
    std::vector<uint8_t> data(size);
    if (!readMemoryInternal(region.start, data.data(), size)) return results;
    size_t step = std::max(1, pattern.alignment);
    size_t pattern_size = pattern.bytes.size();
    for (size_t i = 0; i + pattern_size <= size; i += step) {
        if (matchPattern(data.data() + i, size - i, pattern)) {
            results.push_back(region.start + i);
        }
    }
    return results;
}

bool MemoryManager::matchPattern(const uint8_t *data, size_t size, const MemorySearchPattern &pattern)
{
    if (pattern.custom_matcher) return pattern.custom_matcher(data, size);
    if (pattern.use_regex) return matchRegex(data, size, pattern);
    if (pattern.use_string) return matchString(data, size, pattern);
    if (pattern.use_value) return matchValue(data, size, pattern);
    if (pattern.use_bytes || pattern.use_pattern) {
        size_t ps = pattern.bytes.size();
        if (ps > size) return false;
        if (pattern.use_mask) {
            for (size_t i = 0; i < ps; ++i) {
                if ((pattern.mask.size() > i && pattern.mask[i] == 0)) continue;
                if (data[i] != pattern.bytes[i]) return false;
            }
        } else {
            if (memcmp(data, pattern.bytes.data(), ps) != 0) return false;
        }
        return true;
    }
    return false;
}

bool MemoryManager::matchValue(const uint8_t *data, size_t size, const MemorySearchPattern &pattern)
{
    if (size < static_cast<size_t>(pattern.value_size)) return false;
    uint64_t val = readValue(data, pattern.value_type, pattern.value_size, pattern.big_endian);
    if (pattern.use_range) return val >= pattern.value && val <= pattern.value_end;
    if (pattern.fuzzy) {
        uint64_t diff = (val > pattern.value) ? (val - pattern.value) : (pattern.value - val);
        return diff <= 1;
    }
    return val == pattern.value;
}

bool MemoryManager::matchString(const uint8_t *data, size_t size, const MemorySearchPattern &pattern)
{
    const std::string &needle = pattern.string_value;
    if (needle.size() > size) return false;
    if (pattern.case_sensitive) {
        return memcmp(data, needle.c_str(), needle.size()) == 0;
    }
    for (size_t i = 0; i < needle.size(); ++i) {
        if (std::tolower(static_cast<unsigned char>(data[i])) != std::tolower(static_cast<unsigned char>(needle[i]))) return false;
    }
    return true;
}

bool MemoryManager::matchRegex(const uint8_t *data, size_t size, const MemorySearchPattern &pattern)
{
    std::string s(reinterpret_cast<const char*>(data), std::min(size, size_t(1024)));
    return std::regex_search(s, pattern.regex_pattern);
}

bool MemoryManager::matchCustom(const uint8_t *data, size_t size, const MemorySearchPattern &pattern)
{
    if (pattern.custom_matcher) return pattern.custom_matcher(data, size);
    return false;
}

uint64_t MemoryManager::readValue(const uint8_t *data, int value_type, int size, bool big_endian)
{
    if (size <= 0 || size > 8) return 0;
    uint64_t val = 0;
    if (big_endian) {
        for (int i = 0; i < size; ++i) val = (val << 8) | data[i];
    } else {
        for (int i = size - 1; i >= 0; --i) val = (val << 8) | data[i];
    }
    return val;
}

void MemoryManager::writeValue(uint8_t *data, uint64_t value, int value_type, int size, bool big_endian)
{
    if (size <= 0 || size > 8) return;
    if (big_endian) {
        for (int i = size - 1; i >= 0; --i) { data[i] = value & 0xFF; value >>= 8; }
    } else {
        for (int i = 0; i < size; ++i) { data[i] = value & 0xFF; value >>= 8; }
    }
}

static bool ReadWithTimeout(int fd, void *buf, size_t size, off_t off, uint32_t timeout_ms) {
    if (timeout_ms == 0) {
        ssize_t n = pread64(fd, buf, size, off);
        return n == static_cast<ssize_t>(size);
    }
    struct sigaction sa, old;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = MMTimeoutHandler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sigaction(SIGALRM, &sa, &old);
    struct itimerval it;
    it.it_value.tv_sec = timeout_ms / 1000;
    it.it_value.tv_usec = (timeout_ms % 1000) * 1000;
    it.it_interval.tv_sec = 0;
    it.it_interval.tv_usec = 0;
    setitimer(ITIMER_REAL, &it, NULL);
    ssize_t n = pread64(fd, buf, size, off);
    struct itimerval zero;
    memset(&zero, 0, sizeof(zero));
    setitimer(ITIMER_REAL, &zero, NULL);
    sigaction(SIGALRM, &old, NULL);
    return n == static_cast<ssize_t>(size);
}

static bool WriteWithTimeout(int fd, const void *data, size_t size, off_t off, uint32_t timeout_ms) {
    if (timeout_ms == 0) {
        ssize_t w = pwrite64(fd, data, size, off);
        return w == static_cast<ssize_t>(size);
    }
    struct sigaction sa, old;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = MMTimeoutHandler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    sigaction(SIGALRM, &sa, &old);
    struct itimerval it;
    it.it_value.tv_sec = timeout_ms / 1000;
    it.it_value.tv_usec = (timeout_ms % 1000) * 1000;
    it.it_interval.tv_sec = 0;
    it.it_interval.tv_usec = 0;
    setitimer(ITIMER_REAL, &it, NULL);
    ssize_t w = pwrite64(fd, data, size, off);
    struct itimerval zero;
    memset(&zero, 0, sizeof(zero));
    setitimer(ITIMER_REAL, &zero, NULL);
    sigaction(SIGALRM, &old, NULL);
    return w == static_cast<ssize_t>(size);
}

bool MemoryManager::writeMemoryInternal(uintptr_t address, const void *data, size_t size)
{
    if (processAttached && targetPid > 0) return writeMemoryWithPTrace(address, data, size);
    int fd = open("/proc/self/mem", O_RDWR);
    if (fd < 0) return false;
    bool ok;
    if (!isAddressWritable(address)) {
        int prot = getMemoryProtection(address);
        if (prot < 0) { close(fd); return false; }
        uintptr_t page_start = address & ~(pageSize_ - 1);
        size_t region_size = ((address - page_start + size + pageSize_ - 1) / pageSize_) * pageSize_;
        if (mprotect(reinterpret_cast<void*>(page_start), region_size, prot | PROT_WRITE) != 0) { close(fd); return false; }
        ok = WriteWithTimeout(fd, data, size, address, m_IOTimeoutMs);
        mprotect(reinterpret_cast<void*>(page_start), region_size, prot);
    } else {
        ok = WriteWithTimeout(fd, data, size, address, m_IOTimeoutMs);
    }
    close(fd);
    return ok;
}

bool MemoryManager::readMemoryInternal(uintptr_t address, void *buffer, size_t size)
{
    if (processAttached && targetPid > 0) return readMemoryWithPTrace(address, buffer, size);
    int fd = open("/proc/self/mem", O_RDONLY);
    if (fd < 0) return false;
    bool ok = ReadWithTimeout(fd, buffer, size, address, m_IOTimeoutMs);
    close(fd);
    return ok;
}

bool MemoryManager::writeMemoryWithPTrace(uintptr_t address, const void *data, size_t size)
{
    if (!processAttached || targetPid == 0) return false;
    if (kill(targetPid, 0) != 0) return false;
    size_t words = (size + sizeof(long) - 1) / sizeof(long);
    const unsigned char *src = static_cast<const unsigned char*>(data);
    for (size_t i = 0; i < words; ++i) {
        unsigned long word = 0;
        memcpy(&word, src + i * sizeof(long), std::min(sizeof(long), size - i * sizeof(long)));
        if (m_IOTimeoutMs > 0) {
            struct sigaction sa, old;
            memset(&sa, 0, sizeof(sa));
            sa.sa_handler = MMTimeoutHandler;
            sigemptyset(&sa.sa_mask);
            sa.sa_flags = 0;
            sigaction(SIGALRM, &sa, &old);
            struct itimerval it;
            it.it_value.tv_sec = m_IOTimeoutMs / 1000;
            it.it_value.tv_usec = (m_IOTimeoutMs % 1000) * 1000;
            it.it_interval.tv_sec = 0;
            it.it_interval.tv_usec = 0;
            setitimer(ITIMER_REAL, &it, NULL);
            int ret = ptrace(PTRACE_POKEDATA, targetPid, reinterpret_cast<void*>(address + i * sizeof(long)), reinterpret_cast<void*>(word));
            struct itimerval zero;
            memset(&zero, 0, sizeof(zero));
            setitimer(ITIMER_REAL, &zero, NULL);
            sigaction(SIGALRM, &old, NULL);
            if (ret != 0) return false;
        } else {
            if (ptrace(PTRACE_POKEDATA, targetPid, reinterpret_cast<void*>(address + i * sizeof(long)), reinterpret_cast<void*>(word)) != 0) return false;
        }
    }
    return true;
}

bool MemoryManager::readMemoryWithPTrace(uintptr_t address, void *buffer, size_t size)
{
    if (!processAttached || targetPid == 0) return false;
    if (kill(targetPid, 0) != 0) return false;
    size_t words = (size + sizeof(long) - 1) / sizeof(long);
    unsigned char *dst = static_cast<unsigned char*>(buffer);
    for (size_t i = 0; i < words; ++i) {
        errno = 0;
        if (m_IOTimeoutMs > 0) {
            struct sigaction sa, old;
            memset(&sa, 0, sizeof(sa));
            sa.sa_handler = MMTimeoutHandler;
            sigemptyset(&sa.sa_mask);
            sa.sa_flags = 0;
            sigaction(SIGALRM, &sa, &old);
            struct itimerval it;
            it.it_value.tv_sec = m_IOTimeoutMs / 1000;
            it.it_value.tv_usec = (m_IOTimeoutMs % 1000) * 1000;
            it.it_interval.tv_sec = 0;
            it.it_interval.tv_usec = 0;
            setitimer(ITIMER_REAL, &it, NULL);
            long word = ptrace(PTRACE_PEEKDATA, targetPid, reinterpret_cast<void*>(address + i * sizeof(long)), nullptr);
            struct itimerval zero;
            memset(&zero, 0, sizeof(zero));
            setitimer(ITIMER_REAL, &zero, NULL);
            sigaction(SIGALRM, &old, NULL);
            if (word == -1 && errno != 0) return false;
            memcpy(dst + i * sizeof(long), &word, std::min(sizeof(long), size - i * sizeof(long)));
        } else {
            long word = ptrace(PTRACE_PEEKDATA, targetPid, reinterpret_cast<void*>(address + i * sizeof(long)), nullptr);
            if (word == -1 && errno != 0) return false;
            memcpy(dst + i * sizeof(long), &word, std::min(sizeof(long), size - i * sizeof(long)));
        }
    }
    return true;
}

bool MemoryManager::createMemoryRegion(uintptr_t address, size_t size, int protection)
{
    void *addr = mmap(reinterpret_cast<void*>(address), size, protection, MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    if (addr == MAP_FAILED) return false;
    refreshRegions();
    return true;
}

void MemoryManager::applyFrozenValues()
{
    for (auto &kv : frozenValues) {
        writeMemory(kv.first, kv.second.data.data(), kv.second.data.size());
    }
}

uintptr_t MemoryManager::findFreeRegion(size_t size, uintptr_t near)
{
    uintptr_t search_start = (near != 0) ? near : 0x100000000;
    uintptr_t region_start = search_start;
    const size_t gap = pageSize_ * 4;
    while (true) {
        bool overlap = false;
        for (const auto &r : cachedRegions) {
            uintptr_t r_start = r.start;
            uintptr_t r_end = r.end;
            uintptr_t new_end = region_start + size;
            if ((region_start >= r_start && region_start < r_end) ||
                (new_end > r_start && new_end <= r_end) ||
                (region_start <= r_start && new_end >= r_end)) {
                overlap = true;
                region_start = r_end + gap;
                break;
            }
        }
        if (!overlap) break;
        if (region_start > 0x7FFFFFFFFFFFFFFFUL) return 0;
    }
    return region_start;
}

bool MemoryManager::isRegionOverlapping(const MemoryRegion &region) const
{
    for (const auto &r : cachedRegions) {
        if (region.start < r.end && region.end > r.start) return true;
    }
    return false;
}

std::vector<MemorySearchResult> MemoryManager::search(const MemorySearchPattern &pattern)
{
    refreshIfNeeded();
    return search(pattern, cachedRegions);
}

std::vector<MemorySearchResult> MemoryManager::search(const MemorySearchPattern &pattern, const std::vector<MemoryRegion> &regions)
{
    std::vector<MemorySearchResult> results;
    uint64_t start_time = static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count());
    for (const auto &region : regions) {
        if (!region.readable || region.is_stack) continue;
        if (results.size() >= searchLimit) break;
        uint64_t now = static_cast<uint64_t>(
            std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::steady_clock::now().time_since_epoch()).count());
        if (now - start_time >= searchTimeout) break;
        auto addrs = findAddresses(pattern, region);
        for (auto addr : addrs) {
            if (results.size() >= searchLimit) break;
            MemorySearchResult res;
            res.address = addr;
            res.offset = addr - region.start;
            res.size = region.size;
            res.protection = region.protection;
            res.module = region.path;
            res.region_name = region.name;
            res.current_value = readValue(nullptr, 0, 0, false);
            res.previous_value = 0;
            res.value_changed = false;
            res.match_count = 1;
            results.push_back(res);
        }
    }
    return results;
}

std::vector<MemorySearchResult> MemoryManager::search(const MemorySearchPattern &pattern, uintptr_t start, uintptr_t end)
{
    auto regions = enumerateRegions(start, end);
    return search(pattern, regions);
}

std::vector<MemorySearchResult> MemoryManager::searchValue(uint64_t value, int value_type, int value_size)
{
    MemorySearchPattern pattern;
    pattern.value = value;
    pattern.value_type = value_type;
    pattern.value_size = value_size;
    pattern.use_value = true;
    return search(pattern);
}

std::vector<MemorySearchResult> MemoryManager::searchValueRange(uint64_t min_val, uint64_t max_val, int value_type, int value_size)
{
    MemorySearchPattern pattern;
    pattern.value = min_val;
    pattern.value_end = max_val;
    pattern.value_type = value_type;
    pattern.value_size = value_size;
    pattern.use_value = true;
    pattern.use_range = true;
    return search(pattern);
}

std::vector<MemorySearchResult> MemoryManager::searchString(const std::string &str, bool case_sensitive)
{
    MemorySearchPattern pattern;
    pattern.string_value = str;
    pattern.use_string = true;
    pattern.case_sensitive = case_sensitive;
    return search(pattern);
}

std::vector<MemorySearchResult> MemoryManager::searchBytes(const std::vector<uint8_t> &bytes, const std::vector<uint8_t> &mask)
{
    MemorySearchPattern pattern;
    pattern.bytes = bytes;
    pattern.mask = mask;
    pattern.use_bytes = true;
    pattern.use_mask = !mask.empty();
    return search(pattern);
}

std::vector<MemorySearchResult> MemoryManager::searchHex(const std::string &hex)
{
    MemorySearchPattern pattern;
    pattern.hex_string = hex;
    pattern.use_pattern = true;
    pattern.bytes.clear();
    std::string h = hex;
    h.erase(std::remove_if(h.begin(), h.end(), ::isspace), h.end());
    for (size_t i = 0; i < h.size(); i += 2) {
        uint8_t byte = 0;
        for (int j = 0; j < 2 && i + j < h.size(); ++j) {
            char c = h[i + j];
            byte <<= 4;
            if (c >= '0' && c <= '9') byte |= (c - '0');
            else if (c >= 'a' && c <= 'f') byte |= (10 + c - 'a');
            else if (c >= 'A' && c <= 'F') byte |= (10 + c - 'A');
        }
        pattern.bytes.push_back(byte);
    }
    return search(pattern);
}

std::vector<MemorySearchResult> MemoryManager::searchPattern(const std::string &pattern, bool use_regex)
{
    MemorySearchPattern sp;
    sp.use_regex = use_regex;
    if (use_regex) {
        sp.regex_pattern = std::regex(pattern);
    } else {
        sp.string_value = pattern;
        sp.use_string = true;
    }
    return search(sp);
}

std::vector<MemorySearchResult> MemoryManager::searchNearby(uintptr_t address, uint32_t radius, const MemorySearchPattern &pattern)
{
    uintptr_t start = (address > radius) ? address - radius : 0;
    uintptr_t end = address + radius;
    return search(pattern, start, end);
}

std::vector<MemorySearchResult> MemoryManager::searchNext(const MemorySearchPattern &pattern, const std::vector<MemorySearchResult> &previous)
{
    std::vector<MemorySearchResult> results;
    for (const auto &prev : previous) {
        std::vector<uint8_t> data(prev.size);
        if (readMemory(prev.address, data.data(), prev.size)) {
            if (matchPattern(data.data(), prev.size, pattern)) {
                results.push_back(prev);
            }
        }
    }
    return results;
}

std::vector<MemorySearchResult> MemoryManager::filterResults(const std::vector<MemorySearchResult> &results, const MemoryFilter &filter)
{
    std::vector<MemorySearchResult> filtered;
    for (const auto &res : results) {
        std::vector<uint8_t> data(res.size > 0 ? res.size : 8);
        if (!readMemory(res.address, data.data(), data.size())) continue;
        uint64_t val = readValue(data.data(), filter.value_type, filter.value_size, false);
        bool match = false;
        switch (filter.operation) {
            case 0: match = (val == filter.value); break;
            case 1: match = (val != filter.value); break;
            case 2: match = (val > filter.value); break;
            case 3: match = (val >= filter.value); break;
            case 4: match = (val < filter.value); break;
            case 5: match = (val <= filter.value); break;
            case 6: match = (val >= filter.min_value && val <= filter.max_value); break;
            default: match = true; break;
        }
        if (filter.inverted) match = !match;
        if (match) filtered.push_back(res);
    }
    return filtered;
}

std::vector<MemorySearchResult> MemoryManager::filterChanged(const std::vector<MemorySearchResult> &results)
{
    std::vector<MemorySearchResult> filtered;
    for (const auto &res : results) {
        std::vector<uint8_t> data(res.size > 0 ? res.size : 8);
        if (readMemory(res.address, data.data(), data.size())) {
            uint64_t now_val = readValue(data.data(), 0, static_cast<int>(data.size()), false);
            if (now_val != res.current_value) {
                MemorySearchResult r = res;
                r.previous_value = res.current_value;
                r.current_value = now_val;
                r.value_changed = true;
                filtered.push_back(r);
            }
        }
    }
    return filtered;
}

std::vector<MemorySearchResult> MemoryManager::filterUnchanged(const std::vector<MemorySearchResult> &results)
{
    std::vector<MemorySearchResult> filtered;
    for (const auto &res : results) {
        std::vector<uint8_t> data(res.size > 0 ? res.size : 8);
        if (readMemory(res.address, data.data(), data.size())) {
            uint64_t now_val = readValue(data.data(), 0, static_cast<int>(data.size()), false);
            if (now_val == res.current_value) filtered.push_back(res);
        }
    }
    return filtered;
}

std::vector<MemorySearchResult> MemoryManager::filterIncreased(const std::vector<MemorySearchResult> &results)
{
    std::vector<MemorySearchResult> filtered;
    for (const auto &res : results) {
        std::vector<uint8_t> data(res.size > 0 ? res.size : 8);
        if (readMemory(res.address, data.data(), data.size())) {
            uint64_t now_val = readValue(data.data(), 0, static_cast<int>(data.size()), false);
            if (now_val > res.current_value) filtered.push_back(res);
        }
    }
    return filtered;
}

std::vector<MemorySearchResult> MemoryManager::filterDecreased(const std::vector<MemorySearchResult> &results)
{
    std::vector<MemorySearchResult> filtered;
    for (const auto &res : results) {
        std::vector<uint8_t> data(res.size > 0 ? res.size : 8);
        if (readMemory(res.address, data.data(), data.size())) {
            uint64_t now_val = readValue(data.data(), 0, static_cast<int>(data.size()), false);
            if (now_val < res.current_value) filtered.push_back(res);
        }
    }
    return filtered;
}

std::vector<MemorySearchResult> MemoryManager::filterByValue(const std::vector<MemorySearchResult> &results, uint64_t value, int operation)
{
    MemoryFilter filter;
    filter.value = value;
    filter.operation = operation;
    return filterResults(results, filter);
}

std::vector<MemorySearchResult> MemoryManager::filterByRange(const std::vector<MemorySearchResult> &results, uint64_t min_val, uint64_t max_val)
{
    MemoryFilter filter;
    filter.min_value = min_val;
    filter.max_value = max_val;
    filter.use_range = true;
    filter.operation = 6;
    return filterResults(results, filter);
}

std::vector<MemorySearchResult> MemoryManager::filterByString(const std::vector<MemorySearchResult> &results, const std::string &str)
{
    std::vector<MemorySearchResult> filtered;
    for (const auto &res : results) {
        std::string s = readString(res.address, str.size() + 32);
        if (s.find(str) != std::string::npos) filtered.push_back(res);
    }
    return filtered;
}

bool MemoryManager::groupResults(const std::vector<MemorySearchResult> &results, std::map<std::string, std::vector<MemorySearchResult>> &groups)
{
    groups.clear();
    for (const auto &res : results) {
        groups[res.module].push_back(res);
    }
    return !groups.empty();
}

bool MemoryManager::sortResults(std::vector<MemorySearchResult> &results, const std::string &sort_by, bool ascending)
{
    auto cmp = [&sort_by, ascending](const MemorySearchResult &a, const MemorySearchResult &b) -> bool {
        int dir = ascending ? 1 : -1;
        if (sort_by == "address") return (a.address < b.address) * dir > 0;
        if (sort_by == "offset") return (a.offset < b.offset) * dir > 0;
        if (sort_by == "size") return (a.size < b.size) * dir > 0;
        if (sort_by == "value") return (a.current_value < b.current_value) * dir > 0;
        return (a.address < b.address) * dir > 0;
    };
    std::sort(results.begin(), results.end(), cmp);
    return true;
}

bool MemoryManager::isAddressValid(uintptr_t address) const
{
    if (address == 0) return false;
    for (const auto &r : cachedRegions) {
        if (address >= r.start && address < r.end) return true;
    }
    return false;
}

bool MemoryManager::isAddressMapped(uintptr_t address) const
{
    return isAddressValid(address);
}

bool MemoryManager::isAddressReadable(uintptr_t address) const
{
    auto r = getRegion(address);
    return r.readable;
}

bool MemoryManager::isAddressWritable(uintptr_t address) const
{
    auto r = getRegion(address);
    return r.writable;
}

bool MemoryManager::isAddressExecutable(uintptr_t address) const
{
    auto r = getRegion(address);
    return r.executable;
}

uintptr_t MemoryManager::getBaseAddress(const std::string &module) const
{
    for (const auto &r : cachedRegions) {
        if (r.path.find(module) != std::string::npos && r.offset == 0 && r.executable) return r.start;
    }
    return 0;
}

uintptr_t MemoryManager::getModuleSize(const std::string &module) const
{
    uintptr_t base = 0;
    uintptr_t max_end = 0;
    for (const auto &r : cachedRegions) {
        if (r.path.find(module) != std::string::npos) {
            if (base == 0 || r.start < base) base = r.start;
            if (r.end > max_end) max_end = r.end;
        }
    }
    if (base == 0) return 0;
    return max_end - base;
}

uintptr_t MemoryManager::getAbsoluteAddress(const std::string &module, uintptr_t offset) const
{
    uintptr_t base = getBaseAddress(module);
    if (base == 0) return 0;
    return base + offset;
}

uintptr_t MemoryManager::findPatternInModule(const std::string &module, const std::string &pattern)
{
    auto regions = enumerateRegions(module);
    auto reg = enumerateRegions();
    MemorySearchPattern sp;
    sp.hex_string = pattern;
    sp.use_pattern = true;
    sp.bytes.clear();
    std::string h = pattern;
    h.erase(std::remove_if(h.begin(), h.end(), ::isspace), h.end());
    for (size_t i = 0; i < h.size(); i += 2) {
        if (h[i] == '?' || (i + 1 < h.size() && h[i + 1] == '?')) {
            sp.bytes.push_back(0);
            sp.mask.push_back(0);
            if (h[i] == '?') { if (i + 1 < h.size() && h[i+1] != '?') sp.bytes.push_back(0); }
            continue;
        }
        uint8_t byte = 0;
        for (int j = 0; j < 2 && i + j < h.size(); ++j) {
            char c = h[i + j];
            byte <<= 4;
            if (c >= '0' && c <= '9') byte |= (c - '0');
            else if (c >= 'a' && c <= 'f') byte |= (10 + c - 'a');
            else if (c >= 'A' && c <= 'F') byte |= (10 + c - 'A');
        }
        sp.bytes.push_back(byte);
        sp.mask.push_back(0xFF);
    }
    sp.use_mask = true;
    auto results = search(sp, reg);
    if (results.empty()) return 0;
    return results[0].address;
}

uintptr_t MemoryManager::findPattern(const std::vector<uint8_t> &pattern, const std::vector<uint8_t> &mask, const std::vector<MemoryRegion> &regions)
{
    MemorySearchPattern sp;
    sp.bytes = pattern;
    sp.mask = mask;
    sp.use_bytes = true;
    sp.use_mask = !mask.empty();
    auto results = search(sp, regions);
    if (results.empty()) return 0;
    return results[0].address;
}

uintptr_t MemoryManager::findPattern(const std::string &hex_pattern, uintptr_t start, uintptr_t end)
{
    auto results = searchHex(hex_pattern);
    for (const auto &r : results) {
        if (r.address >= start && r.address <= end) return r.address;
    }
    return 0;
}

bool MemoryManager::dumpMemory(const std::string &path, uintptr_t address, size_t size)
{
    std::ofstream out(path, std::ios::binary);
    if (!out.is_open()) return false;
    std::vector<uint8_t> data(size);
    if (!readMemory(address, data.data(), size)) return false;
    out.write(reinterpret_cast<const char*>(data.data()), size);
    return out.good();
}

bool MemoryManager::dumpModule(const std::string &module_name, const std::string &output_path)
{
    uintptr_t base = getBaseAddress(module_name);
    if (base == 0) return false;
    size_t size = static_cast<size_t>(getModuleSize(module_name));
    if (size == 0) return false;
    return dumpMemory(output_path, base, size);
}

bool MemoryManager::dumpRegion(const MemoryRegion &region, const std::string &output_path)
{
    return dumpMemory(output_path, region.start, region.size);
}

bool MemoryManager::dumpAllExecutable(const std::string &output_dir)
{
    auto regions = enumerateExecutableRegions();
    bool all_ok = true;
    int idx = 0;
    for (const auto &r : regions) {
        std::string path = output_dir + "/region_" + std::to_string(idx++) + ".bin";
        if (!dumpRegion(r, path)) all_ok = false;
    }
    return all_ok;
}

bool MemoryManager::dumpHeap(const std::string &output_path)
{
    auto regions = enumerateHeapRegions();
    if (regions.empty()) return false;
    std::ofstream out(output_path, std::ios::binary);
    if (!out.is_open()) return false;
    for (const auto &r : regions) {
        std::vector<uint8_t> data(r.size);
        if (readMemory(r.start, data.data(), r.size)) {
            out.write(reinterpret_cast<const char*>(data.data()), r.size);
        }
    }
    return out.good();
}

std::string MemoryManager::dumpHex(uintptr_t address, size_t size)
{
    std::ostringstream oss;
    std::vector<uint8_t> data(size);
    if (!readMemory(address, data.data(), size)) return "";
    for (size_t i = 0; i < size; ++i) {
        if (i % 16 == 0) oss << std::hex << std::setw(8) << std::setfill('0') << (address + i) << ": ";
        oss << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(data[i]) << " ";
        if (i % 16 == 15 || i == size - 1) {
            oss << " ";
            size_t line_start = (i / 16) * 16;
            for (size_t j = line_start; j <= i; ++j) {
                char c = static_cast<char>(data[j]);
                oss << (std::isprint(static_cast<unsigned char>(c)) ? c : '.');
            }
            oss << "\n";
        }
    }
    return oss.str();
}

std::string MemoryManager::dumpASCII(uintptr_t address, size_t max_length)
{
    return readString(address, max_length);
}

std::string MemoryManager::dumpStructure(uintptr_t address, const std::string &structure_def)
{
    std::ostringstream oss;
    oss << "Structure dump at 0x" << std::hex << address << ":\n";
    std::istringstream iss(structure_def);
    std::string field;
    while (iss >> field) {
        size_t colon = field.find(':');
        if (colon == std::string::npos) continue;
        std::string name = field.substr(0, colon);
        std::string type = field.substr(colon + 1);
        uintptr_t field_addr = address;
        if (type == "uint8") {
            field_addr = address + std::stoul(name, nullptr, 16);
            oss << "  +0x" << name << " (uint8): " << static_cast<int>(readByte(field_addr)) << "\n";
        } else if (type == "uint16") {
            field_addr = address + std::stoul(name, nullptr, 16);
            oss << "  +0x" << name << " (uint16): " << readShort(field_addr) << "\n";
        } else if (type == "uint32") {
            field_addr = address + std::stoul(name, nullptr, 16);
            oss << "  +0x" << name << " (uint32): " << readInt(field_addr) << "\n";
        } else if (type == "uint64") {
            field_addr = address + std::stoul(name, nullptr, 16);
            oss << "  +0x" << name << " (uint64): " << readLong(field_addr) << "\n";
        }
    }
    return oss.str();
}

void MemoryManager::setSearchAlignment(uint32_t alignment)
{
    searchAlignment = alignment;
}

uint32_t MemoryManager::getSearchAlignment() const
{
    return searchAlignment;
}

void MemoryManager::setSearchLimit(uint32_t limit)
{
    searchLimit = limit;
}

uint32_t MemoryManager::getSearchLimit() const
{
    return searchLimit;
}

void MemoryManager::setSearchTimeout(uint32_t timeout_ms)
{
    searchTimeout = timeout_ms;
}

uint32_t MemoryManager::getSearchTimeout() const
{
    return searchTimeout;
}

void MemoryManager::setIOTimeout(uint32_t timeout_ms)
{
    m_IOTimeoutMs = timeout_ms;
}

uint32_t MemoryManager::getIOTimeout() const
{
    return m_IOTimeoutMs;
}

uint64_t MemoryManager::getPageSize() const
{
    return pageSize_;
}

uint64_t MemoryManager::getAllocationGranularity() const
{
    return allocGranularity;
}

uint64_t MemoryManager::getTotalPhysicalMemory() const
{
    long pages = sysconf(_SC_PHYS_PAGES);
    long page_size = sysconf(_SC_PAGESIZE);
    return static_cast<uint64_t>(pages) * static_cast<uint64_t>(page_size);
}

uint64_t MemoryManager::getAvailableMemory() const
{
    long pages = sysconf(_SC_AVPHYS_PAGES);
    long page_size = sysconf(_SC_PAGESIZE);
    return static_cast<uint64_t>(pages) * static_cast<uint64_t>(page_size);
}

uint64_t MemoryManager::getProcessMemoryUsage() const
{
    std::ifstream statm("/proc/self/statm");
    if (!statm.is_open()) return 0;
    unsigned long rss = 0;
    statm >> rss;
    return rss * pageSize_;
}

AllocatorStats MemoryManager::getAllocationStatistics() const
{
    return allocStats;
}

void MemoryManager::resetAllocationStatistics()
{
    memset(&allocStats, 0, sizeof(allocStats));
}

uint32_t MemoryManager::getAllocationCount() const
{
    return allocStats.current_allocations;
}

uint64_t MemoryManager::getTotalAllocationSize() const
{
    return allocStats.total_size;
}

bool MemoryManager::isProcessSuspended() const
{
    return false;
}

bool MemoryManager::suspendProcess()
{
    if (!processAttached || targetPid == 0) return false;
    return ptrace(PTRACE_INTERRUPT, targetPid, nullptr, nullptr) == 0;
}

bool MemoryManager::resumeProcess()
{
    if (!processAttached || targetPid == 0) return false;
    return ptrace(PTRACE_CONT, targetPid, nullptr, nullptr) == 0;
}

bool MemoryManager::isProcessAttached() const
{
    return processAttached;
}

bool MemoryManager::attachProcess(pid_t pid)
{
    if (processAttached) return false;
    if (ptrace(PTRACE_ATTACH, pid, nullptr, nullptr) != 0) return false;
    int status;
    waitpid(pid, &status, 0);
    targetPid = pid;
    processAttached = true;
    readMaps(pid);
    return true;
}

bool MemoryManager::detachProcess()
{
    if (!processAttached) return false;
    ptrace(PTRACE_DETACH, targetPid, nullptr, nullptr);
    targetPid = 0;
    processAttached = false;
    return true;
}

bool MemoryManager::waitForModule(const std::string &module_name, uint32_t timeout_ms)
{
    uint64_t start = static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count());
    while (true) {
        uint64_t now = static_cast<uint64_t>(
            std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::steady_clock::now().time_since_epoch()).count());
        if (now - start > timeout_ms) return false;
        refreshRegions();
        if (getBaseAddress(module_name) != 0) return true;
        usleep(10000);
    }
}

uintptr_t MemoryManager::getModuleBase(const std::string &module_name) const
{
    return getBaseAddress(module_name);
}

std::vector<std::pair<std::string, uintptr_t>> MemoryManager::getLoadedModules() const
{
    std::vector<std::pair<std::string, uintptr_t>> modules;
    std::set<std::string> seen;
    for (const auto &r : cachedRegions) {
        if (!r.path.empty() && r.offset == 0) {
            std::string name = r.path;
            if (seen.find(name) == seen.end()) {
                seen.insert(name);
                modules.emplace_back(name, r.start);
            }
        }
    }
    return modules;
}

bool MemoryManager::setWatchpoint(uintptr_t address, size_t size)
{
    std::lock_guard<std::mutex> lock(memoryMutex);
    watchpoints[address] = size;
    return true;
}

bool MemoryManager::removeWatchpoint(uintptr_t address)
{
    std::lock_guard<std::mutex> lock(memoryMutex);
    return watchpoints.erase(address) > 0;
}

bool MemoryManager::removeAllWatchpoints()
{
    std::lock_guard<std::mutex> lock(memoryMutex);
    watchpoints.clear();
    return true;
}

bool MemoryManager::hasWatchpoint(uintptr_t address) const
{
    std::lock_guard<std::mutex> lock(memoryMutex);
    return watchpoints.find(address) != watchpoints.end();
}

bool MemoryManager::setBreakpoint(uintptr_t address)
{
    std::lock_guard<std::mutex> lock(memoryMutex);
    if (breakpoints.find(address) != breakpoints.end()) return true;
    uint8_t original_byte = readByte(address);
    uint8_t bkpt = 0x00;
#if defined(__aarch64__)
    bkpt = 0x00;
#elif defined(__arm__)
    bkpt = 0x70;
#else
    bkpt = 0xCC;
#endif
    if (!writeByte(address, bkpt)) return false;
    breakpoints[address] = original_byte;
    return true;
}

bool MemoryManager::removeBreakpoint(uintptr_t address)
{
    std::lock_guard<std::mutex> lock(memoryMutex);
    auto it = breakpoints.find(address);
    if (it == breakpoints.end()) return false;
    uint8_t original_byte = static_cast<uint8_t>(it->second);
    writeByte(address, original_byte);
    breakpoints.erase(it);
    return true;
}

bool MemoryManager::removeAllBreakpoints()
{
    std::lock_guard<std::mutex> lock(memoryMutex);
    bool all_ok = true;
    for (auto &kv : breakpoints) {
        if (!writeByte(kv.first, static_cast<uint8_t>(kv.second))) all_ok = false;
    }
    breakpoints.clear();
    return all_ok;
}

bool MemoryManager::hasBreakpoint(uintptr_t address) const
{
    std::lock_guard<std::mutex> lock(memoryMutex);
    return breakpoints.find(address) != breakpoints.end();
}

void MemoryManager::onMemoryChange(std::function<void(uintptr_t, size_t, const std::vector<uint8_t>&)> callback)
{
    memoryChangeCallback = callback;
}

void MemoryManager::onRegionChange(std::function<void(const MemoryRegion&, bool)> callback)
{
    regionChangeCallback = callback;
}

void MemoryManager::onAllocation(std::function<void(uintptr_t, size_t)> callback)
{
    allocCallback = callback;
}

void MemoryManager::onDeallocation(std::function<void(uintptr_t)> callback)
{
    deallocCallback = callback;
}

std::string MemoryManager::getVersion() const
{
    return "1.0.0";
}

std::string MemoryManager::getArchitecture() const
{
#if defined(__aarch64__)
    return "ARM64";
#elif defined(__arm__)
    return "ARM32";
#elif defined(__x86_64__)
    return "x64";
#elif defined(__i386__)
    return "x86";
#else
    return "Unknown";
#endif
}

bool MemoryManager::isARM64() const
{
#if defined(__aarch64__)
    return true;
#else
    return false;
#endif
}

bool MemoryManager::isARM32() const
{
#if defined(__arm__)
    return true;
#else
    return false;
#endif
}

bool MemoryManager::isX86() const
{
#if defined(__i386__)
    return true;
#else
    return false;
#endif
}

bool MemoryManager::isX64() const
{
#if defined(__x86_64__)
    return true;
#else
    return false;
#endif
}

bool MemoryManager::saveState(const std::string &path)
{
    std::ofstream out(path, std::ios::binary);
    if (!out.is_open()) return false;
    out.write("MMGR", 4);
    uint32_t count = static_cast<uint32_t>(patches.size());
    out.write(reinterpret_cast<const char*>(&count), sizeof(count));
    for (const auto &p : patches) {
        out.write(reinterpret_cast<const char*>(&p.address), sizeof(p.address));
        uint32_t sz = static_cast<uint32_t>(p.original_bytes.size());
        out.write(reinterpret_cast<const char*>(&sz), sizeof(sz));
        out.write(reinterpret_cast<const char*>(p.original_bytes.data()), sz);
        sz = static_cast<uint32_t>(p.patch_bytes.size());
        out.write(reinterpret_cast<const char*>(&sz), sizeof(sz));
        out.write(reinterpret_cast<const char*>(p.patch_bytes.data()), sz);
    }
    return out.good();
}

bool MemoryManager::loadState(const std::string &path)
{
    std::ifstream in(path, std::ios::binary);
    if (!in.is_open()) return false;
    char magic[4];
    in.read(magic, 4);
    if (memcmp(magic, "MMGR", 4) != 0) return false;
    uint32_t count = 0;
    in.read(reinterpret_cast<char*>(&count), sizeof(count));
    for (uint32_t i = 0; i < count; ++i) {
        MemoryPatch p;
        in.read(reinterpret_cast<char*>(&p.address), sizeof(p.address));
        uint32_t sz = 0;
        in.read(reinterpret_cast<char*>(&sz), sizeof(sz));
        p.original_bytes.resize(sz);
        in.read(reinterpret_cast<char*>(p.original_bytes.data()), sz);
        in.read(reinterpret_cast<char*>(&sz), sizeof(sz));
        p.patch_bytes.resize(sz);
        in.read(reinterpret_cast<char*>(p.patch_bytes.data()), sz);
        patches.push_back(p);
    }
    return in.good();
}

bool MemoryManager::exportSearchResults(const std::string &path, const std::vector<MemorySearchResult> &results)
{
    std::ofstream out(path);
    if (!out.is_open()) return false;
    out << "Address,Offset,Size,Protection,Module,Value\n";
    for (const auto &r : results) {
        out << std::hex << "0x" << r.address << ","
            << "0x" << r.offset << ","
            << std::dec << r.size << ","
            << static_cast<int>(r.protection) << ","
            << r.module << ","
            << r.current_value << "\n";
    }
    return out.good();
}

std::vector<MemorySearchResult> MemoryManager::importSearchResults(const std::string &path)
{
    std::vector<MemorySearchResult> results;
    std::ifstream in(path);
    if (!in.is_open()) return results;
    std::string line;
    std::getline(in, line);
    while (std::getline(in, line)) {
        std::istringstream iss(line);
        std::string token;
        MemorySearchResult res;
        if (std::getline(iss, token, ',')) res.address = std::stoull(token, nullptr, 16);
        if (std::getline(iss, token, ',')) res.offset = std::stoull(token, nullptr, 16);
        if (std::getline(iss, token, ',')) res.size = static_cast<uint32_t>(std::stoul(token));
        if (std::getline(iss, token, ',')) res.protection = static_cast<uint32_t>(std::stoul(token));
        if (std::getline(iss, token, ',')) res.module = token;
        if (std::getline(iss, token, ',')) res.current_value = std::stoull(token);
        results.push_back(res);
    }
    return results;
}
