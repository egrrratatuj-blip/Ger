#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <unistd.h>
#include <sys/types.h>
#include <dirent.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/mount.h>
#include <sys/wait.h>
#include <mutex>

#define LOG_TAG "BugorNativeRoot"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

#define CHECK_JNI_EXCEPTION(env, ret) do { \
    if ((env)->ExceptionCheck()) { \
        (env)->ExceptionDescribe(); \
        (env)->ExceptionClear(); \
        return (ret); \
    } \
} while(0)

namespace NativeRoot {

struct CachedEnv {
    JNIEnv *env;
    jobject rootShellObj;
    jclass rootShellClass;
    jmethodID methodInitialize;
    jmethodID methodIsRootAvailable;
    jmethodID methodExecSync;
    jmethodID methodExecSyncWithOutput;
    jmethodID methodGetPidByName;
    jmethodID methodGetModuleBase;
    jmethodID methodListModules;
    jmethodID methodReadMemory;
    jmethodID methodWriteMemory;
    jmethodID methodMountFile;
    jmethodID methodSetSELinuxContext;
    jmethodID methodCopyFileAsRoot;
    bool ready;
};

static std::mutex g_cacheMutex;
static CachedEnv g_cache = {};
static bool g_initialized = false;

static bool EnsureJavaBindings(JNIEnv *env) {
    std::lock_guard<std::mutex> lock(g_cacheMutex);
    if (g_cache.ready && g_cache.env == env) return true;
    jclass clazz = env->FindClass("com/bugor/engine/RootShell");
    if (!clazz) {
        LOGE("RootShell class not found");
        return false;
    }
    jmethodID getInstance = env->GetStaticMethodID(clazz, "getInstance", "(Landroid/content/Context;)Lcom/bugor/engine/RootShell;");
    if (!getInstance) {
        LOGE("RootShell.getInstance not found");
        env->DeleteLocalRef(clazz);
        return false;
    }
    jclass activityClass = env->FindClass("com/bugor/engine/MainActivity");
    if (!activityClass) {
        activityClass = env->FindClass("android/app/ActivityThread");
    }
    jobject context = nullptr;
    if (activityClass) {
        jmethodID currentApplication = env->GetStaticMethodID(activityClass, "getInstance", "()Landroid/app/ActivityThread;");
        if (!currentApplication) {
            jmethodID appMethod = env->GetStaticMethodID(activityClass, "getApplication", "()Landroid/app/Application;");
            if (appMethod) {
                context = env->CallStaticObjectMethod(activityClass, appMethod);
            }
        }
        env->DeleteLocalRef(activityClass);
    }
    if (!context) {
        jclass ctxCls = env->FindClass("android/app/ActivityThread");
        if (ctxCls) {
            jmethodID currentApp = env->GetStaticMethodID(ctxCls, "currentApplication", "()Landroid/app/Application;");
            if (currentApp) {
                context = env->CallStaticObjectMethod(ctxCls, currentApp);
            }
            env->DeleteLocalRef(ctxCls);
        }
    }
    if (!context) {
        LOGE("Application context not available");
        env->DeleteLocalRef(clazz);
        return false;
    }
    jobject instance = env->CallStaticObjectMethod(clazz, getInstance, context);
    env->DeleteLocalRef(context);
    if (!instance) {
        LOGE("RootShell.getInstance returned null");
        env->DeleteLocalRef(clazz);
        return false;
    }
    g_cache.rootShellClass = (jclass)env->NewGlobalRef(clazz);
    g_cache.rootShellObj = env->NewGlobalRef(instance);
    env->DeleteLocalRef(clazz);
    env->DeleteLocalRef(instance);
    g_cache.methodInitialize = env->GetMethodID(g_cache.rootShellClass, "initialize", "()Z");
    g_cache.methodIsRootAvailable = env->GetMethodID(g_cache.rootShellClass, "isRootAvailable", "()Z");
    g_cache.methodExecSync = env->GetMethodID(g_cache.rootShellClass, "execSync", "(Ljava/lang/String;)I");
    g_cache.methodExecSyncWithOutput = env->GetMethodID(g_cache.rootShellClass, "execSyncWithOutput", "(Ljava/lang/String;)Ljava/lang/String;");
    g_cache.methodGetPidByName = env->GetMethodID(g_cache.rootShellClass, "getPidByName", "(Ljava/lang/String;)I");
    g_cache.methodGetModuleBase = env->GetMethodID(g_cache.rootShellClass, "getModuleBase", "(JLjava/lang/String;)J");
    g_cache.methodListModules = env->GetMethodID(g_cache.rootShellClass, "listModules", "(J)[Ljava/lang/String;");
    g_cache.methodReadMemory = env->GetMethodID(g_cache.rootShellClass, "readMemory", "(JJI)Ljava/lang/String;");
    g_cache.methodWriteMemory = env->GetMethodID(g_cache.rootShellClass, "writeMemoryString", "(JJLjava/lang/String;)Z");
    g_cache.methodMountFile = env->GetMethodID(g_cache.rootShellClass, "mountFile", "(Ljava/lang/String;Ljava/lang/String;)Z");
    g_cache.methodSetSELinuxContext = env->GetMethodID(g_cache.rootShellClass, "setSELinuxContext", "(Ljava/lang/String;Ljava/lang/String;)Z");
    g_cache.methodCopyFileAsRoot = env->GetMethodID(g_cache.rootShellClass, "copyFileAsRoot", "(Ljava/lang/String;Ljava/lang/String;)Z");
    g_cache.env = env;
    g_cache.ready = true;
    g_initialized = false;
    return true;
}

static int FindPidByScanning(const char *processName) {
    if (!processName) return -1;
    DIR *dir = opendir("/proc");
    if (!dir) return -1;
    struct dirent *entry;
    int pid = -1;
    size_t nameLen = strlen(processName);
    char cmdlinePath[64];
    char cmdline[512];
    while ((entry = readdir(dir)) != NULL) {
        int id = atoi(entry->d_name);
        if (id <= 0) continue;
        snprintf(cmdlinePath, sizeof(cmdlinePath), "/proc/%d/cmdline", id);
        FILE *fp = fopen(cmdlinePath, "r");
        if (!fp) continue;
        size_t n = fread(cmdline, 1, sizeof(cmdline) - 1, fp);
        fclose(fp);
        if (n == 0) continue;
        cmdline[n] = 0;
        if (n >= nameLen && strncmp(processName, cmdline, nameLen) == 0) {
            pid = id;
            break;
        }
    }
    closedir(dir);
    return pid;
}

static int FindPidInCmdline(const char *processName) {
    if (!processName) return -1;
    DIR *dir = opendir("/proc");
    if (!dir) return -1;
    struct dirent *entry;
    int pid = -1;
    size_t nameLen = strlen(processName);
    char statusPath[64];
    char line[512];
    while ((entry = readdir(dir)) != NULL) {
        int id = atoi(entry->d_name);
        if (id <= 0) continue;
        snprintf(statusPath, sizeof(statusPath), "/proc/%d/comm", id);
        FILE *fp = fopen(statusPath, "r");
        if (!fp) continue;
        if (!fgets(line, sizeof(line), fp)) {
            fclose(fp);
            continue;
        }
        fclose(fp);
        size_t len = strlen(line);
        while (len > 0 && (line[len - 1] == '\n' || line[len - 1] == '\r')) {
            line[--len] = 0;
        }
        if (strcmp(line, processName) == 0) {
            pid = id;
            break;
        }
    }
    closedir(dir);
    return pid;
}

static bool CheckSuExists() {
    struct stat st;
    if (stat("/system/xbin/su", &st) == 0) return true;
    if (stat("/system/bin/su", &st) == 0) return true;
    if (stat("/sbin/su", &st) == 0) return true;
    if (stat("/vendor/bin/su", &st) == 0) return true;
    return false;
}

}

extern "C" {

JNIEXPORT jboolean JNICALL NativeRoot_Init(JNIEnv *env, jclass clazz) {
    if (!NativeRoot::EnsureJavaBindings(env)) {
        return JNI_FALSE;
    }
    if (NativeRoot::g_cache.methodInitialize) {
        jboolean ok = env->CallBooleanMethod(NativeRoot::g_cache.rootShellObj, NativeRoot::g_cache.methodInitialize);
        CHECK_JNI_EXCEPTION(env, JNI_FALSE);
        if (ok == JNI_TRUE) {
            NativeRoot::g_initialized = true;
        }
        return ok;
    }
    return JNI_FALSE;
}

JNIEXPORT jboolean JNICALL NativeRoot_Available(JNIEnv *env, jclass clazz) {
    if (!NativeRoot::EnsureJavaBindings(env)) {
        return NativeRoot::CheckSuExists() ? JNI_TRUE : JNI_FALSE;
    }
    if (NativeRoot::g_cache.methodIsRootAvailable) {
        jboolean res = env->CallBooleanMethod(NativeRoot::g_cache.rootShellObj, NativeRoot::g_cache.methodIsRootAvailable);
        CHECK_JNI_EXCEPTION(env, JNI_FALSE);
        return res;
    }
    return JNI_FALSE;
}

JNIEXPORT jint JNICALL NativeRoot_Exec(JNIEnv *env, jclass clazz, jstring command_j) {
    if (!command_j) return -1;
    const char *cmd = env->GetStringUTFChars(command_j, nullptr);
    if (!cmd) return -1;
    int result = -1;
    if (NativeRoot::EnsureJavaBindings(env) && NativeRoot::g_cache.methodExecSync) {
        jstring jcmd = env->NewStringUTF(cmd);
        if (jcmd) {
            result = (int)env->CallIntMethod(NativeRoot::g_cache.rootShellObj, NativeRoot::g_cache.methodExecSync, jcmd);
            CHECK_JNI_EXCEPTION(env, -1);
            env->DeleteLocalRef(jcmd);
        }
    }
    env->ReleaseStringUTFChars(command_j, cmd);
    return result;
}

JNIEXPORT jstring JNICALL NativeRoot_ExecOutput(JNIEnv *env, jclass clazz, jstring command_j) {
    if (!command_j) return env->NewStringUTF("");
    const char *cmd = env->GetStringUTFChars(command_j, nullptr);
    if (!cmd) return env->NewStringUTF("");
    jstring result = env->NewStringUTF("");
    if (NativeRoot::EnsureJavaBindings(env) && NativeRoot::g_cache.methodExecSyncWithOutput) {
        jstring jcmd = env->NewStringUTF(cmd);
        if (jcmd) {
            jstring out = (jstring)env->CallObjectMethod(NativeRoot::g_cache.rootShellObj, NativeRoot::g_cache.methodExecSyncWithOutput, jcmd);
            CHECK_JNI_EXCEPTION(env, env->NewStringUTF(""));
            env->DeleteLocalRef(jcmd);
            if (out) {
                result = out;
            }
        }
    }
    env->ReleaseStringUTFChars(command_j, cmd);
    return result;
}

JNIEXPORT jint JNICALL NativeRoot_GetPid(JNIEnv *env, jclass clazz, jstring processName_j) {
    if (!processName_j) return -1;
    const char *name = env->GetStringUTFChars(processName_j, nullptr);
    if (!name) return -1;
    int pid = -1;
    if (NativeRoot::EnsureJavaBindings(env) && NativeRoot::g_cache.methodGetPidByName) {
        pid = (int)env->CallIntMethod(NativeRoot::g_cache.rootShellObj, NativeRoot::g_cache.methodGetPidByName, processName_j);
        CHECK_JNI_EXCEPTION(env, -1);
    }
    if (pid <= 0) {
        pid = NativeRoot::FindPidByScanning(name);
    }
    if (pid <= 0) {
        pid = NativeRoot::FindPidInCmdline(name);
    }
    env->ReleaseStringUTFChars(processName_j, name);
    return pid;
}

JNIEXPORT jlong JNICALL NativeRoot_GetModuleBase(JNIEnv *env, jclass clazz, jint pid, jstring moduleName_j) {
    if (!moduleName_j || pid <= 0) return 0;
    const char *name = env->GetStringUTFChars(moduleName_j, nullptr);
    if (!name) return 0;
    jlong result = 0;
    bool triedJava = false;
    if (NativeRoot::EnsureJavaBindings(env) && NativeRoot::g_cache.methodGetModuleBase) {
        triedJava = true;
        result = env->CallLongMethod(NativeRoot::g_cache.rootShellObj, NativeRoot::g_cache.methodGetModuleBase, (jlong)pid, moduleName_j);
        CHECK_JNI_EXCEPTION(env, 0);
    }
    if (!triedJava || result == 0) {
        char mapsPath[64];
        snprintf(mapsPath, sizeof(mapsPath), "/proc/%d/maps", (int)pid);
        FILE *fp = fopen(mapsPath, "r");
        if (fp) {
            char line[1024];
            while (fgets(line, sizeof(line), fp)) {
                const char *found = strstr(line, name);
                if (!found) continue;
                const char *end = found + strlen(name);
                char c = *end;
                if (c != 0 && c != '\n' && c != ' ' && c != '\t') continue;
                unsigned long start = 0, stop = 0;
                if (sscanf(line, "%lx-%lx", &start, &stop) == 2) {
                    result = (jlong)start;
                    break;
                }
            }
            fclose(fp);
        }
    }
    env->ReleaseStringUTFChars(moduleName_j, name);
    return result;
}

JNIEXPORT jobjectArray JNICALL NativeRoot_ListModules(JNIEnv *env, jclass clazz, jint pid) {
    std::vector<std::string> modules;
    if (pid <= 0) {
        return env->NewObjectArray(0, env->FindClass("java/lang/String"), nullptr);
    }
    bool gotFromJava = false;
    if (NativeRoot::EnsureJavaBindings(env) && NativeRoot::g_cache.methodListModules) {
        jobjectArray arr = (jobjectArray)env->CallObjectMethod(NativeRoot::g_cache.rootShellObj, NativeRoot::g_cache.methodListModules, (jlong)pid);
        CHECK_JNI_EXCEPTION(env, env->NewObjectArray(0, env->FindClass("java/lang/String"), nullptr));
        if (arr) {
            jsize len = env->GetArrayLength(arr);
            for (jsize i = 0; i < len; i++) {
                jstring s = (jstring)env->GetObjectArrayElement(arr, i);
                if (s) {
                    const char *cstr = env->GetStringUTFChars(s, nullptr);
                    if (cstr) {
                        modules.push_back(cstr);
                        env->ReleaseStringUTFChars(s, cstr);
                    }
                    env->DeleteLocalRef(s);
                }
            }
            env->DeleteLocalRef(arr);
            gotFromJava = true;
        }
    }
    if (!gotFromJava) {
        char mapsPath[64];
        snprintf(mapsPath, sizeof(mapsPath), "/proc/%d/maps", (int)pid);
        FILE *fp = fopen(mapsPath, "r");
        if (fp) {
            char line[1024];
            char lastPath[512];
            lastPath[0] = 0;
            while (fgets(line, sizeof(line), fp)) {
                const char *path = strrchr(line, '/');
                if (!path) continue;
                path++;
                size_t len = 0;
                while (path[len] && path[len] != '\n' && path[len] != ' ' && path[len] != '\t') len++;
                if (len == 0) continue;
                char name[512];
                memcpy(name, path, len);
                name[len] = 0;
                if (strcmp(name, lastPath) == 0) continue;
                strncpy(lastPath, name, sizeof(lastPath) - 1);
                lastPath[sizeof(lastPath) - 1] = 0;
                modules.push_back(name);
            }
            fclose(fp);
        }
    }
    jclass stringClass = env->FindClass("java/lang/String");
    jobjectArray arr = env->NewObjectArray((jsize)modules.size(), stringClass, nullptr);
    for (size_t i = 0; i < modules.size(); i++) {
        env->SetObjectArrayElement(arr, (jsize)i, env->NewStringUTF(modules[i].c_str()));
    }
    return arr;
}

JNIEXPORT jboolean JNICALL NativeRoot_WriteMemory(JNIEnv *env, jclass clazz, jint pid, jlong address, jbyteArray data) {
    if (!data || pid <= 0) return JNI_FALSE;
    jsize len = env->GetArrayLength(data);
    if (len <= 0) return JNI_FALSE;
    jbyte *bytes = env->GetByteArrayElements(data, nullptr);
    if (!bytes) return JNI_FALSE;
    bool ok = false;
    if (NativeRoot::EnsureJavaBindings(env) && NativeRoot::g_cache.methodWriteMemory) {
        static const char hex[] = "0123456789ABCDEF";
        char *encoded = (char*)malloc((size_t)len * 2 + 1);
        if (encoded) {
            for (jsize i = 0; i < len; i++) {
                unsigned char b = (unsigned char)bytes[i];
                encoded[i * 2] = hex[(b >> 4) & 0xF];
                encoded[i * 2 + 1] = hex[b & 0xF];
            }
            encoded[len * 2] = 0;
            jstring jstr = env->NewStringUTF(encoded);
            if (jstr) {
                jboolean res = env->CallBooleanMethod(NativeRoot::g_cache.rootShellObj, NativeRoot::g_cache.methodWriteMemory, (jlong)pid, address, jstr);
                CHECK_JNI_EXCEPTION(env, JNI_FALSE);
                env->DeleteLocalRef(jstr);
                ok = (res == JNI_TRUE);
            }
            free(encoded);
        }
    }
    if (!ok) {
        char memPath[64];
        snprintf(memPath, sizeof(memPath), "/proc/%d/mem", (int)pid);
        int fd = open(memPath, O_WRONLY);
        if (fd >= 0) {
            ssize_t written = pwrite64(fd, bytes, (size_t)len, (off64_t)address);
            ok = (written == (ssize_t)len);
            close(fd);
        }
    }
    env->ReleaseByteArrayElements(data, bytes, JNI_ABORT);
    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jbyteArray JNICALL NativeRoot_ReadMemory(JNIEnv *env, jclass clazz, jint pid, jlong address, jint size) {
    if (pid <= 0 || size <= 0) {
        return env->NewByteArray(0);
    }
    jbyteArray result = nullptr;
    jbyte *buffer = (jbyte*)malloc((size_t)size);
    if (!buffer) {
        return env->NewByteArray(0);
    }
    bool ok = false;
    char memPath[64];
    snprintf(memPath, sizeof(memPath), "/proc/%d/mem", (int)pid);
    int fd = open(memPath, O_RDONLY);
    if (fd >= 0) {
        ssize_t rd = pread64(fd, buffer, (size_t)size, (off64_t)address);
        ok = (rd == (ssize_t)size);
        close(fd);
    }
    if (!ok && NativeRoot::EnsureJavaBindings(env) && NativeRoot::g_cache.methodReadMemory) {
        jstring b64 = (jstring)env->CallObjectMethod(NativeRoot::g_cache.rootShellObj, NativeRoot::g_cache.methodReadMemory, (jlong)pid, address, (jint)size);
        CHECK_JNI_EXCEPTION(env, env->NewByteArray(0));
        if (b64) {
            const char *str = env->GetStringUTFChars(b64, nullptr);
            if (str) {
                static const int8_t decodeTable[256] = {
                    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
                    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,
                    -1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,62,-1,-1,-1,63,
                    52,53,54,55,56,57,58,59,60,61,-1,-1,-1,-1,-1,-1,
                    -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,
                    15,16,17,18,19,20,21,22,23,24,25,-1,-1,-1,-1,-1,
                    -1,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,
                    41,42,43,44,45,46,47,48,49,50,51,-1,-1,-1,-1,-1
                };
                size_t slen = strlen(str);
                size_t outLen = 0;
                int val = 0, valb = -8;
                for (size_t i = 0; i < slen; i++) {
                    unsigned char ch = (unsigned char)str[i];
                    if (ch == '=') break;
                    int8_t d = decodeTable[ch];
                    if (d < 0) continue;
                    val = (val << 6) | d;
                    valb += 6;
                    if (valb >= 0) {
                        if (outLen < (size_t)size) {
                            buffer[outLen++] = (jbyte)((val >> valb) & 0xFF);
                        }
                        valb -= 8;
                    }
                }
                ok = true;
            }
            env->ReleaseStringUTFChars(b64, str);
        }
        env->DeleteLocalRef(b64);
    }
    if (ok) {
        result = env->NewByteArray(size);
        env->SetByteArrayRegion(result, 0, size, buffer);
    } else {
        result = env->NewByteArray(0);
    }
    free(buffer);
    return result;
}

JNIEXPORT jboolean JNICALL NativeRoot_Mount(JNIEnv *env, jclass clazz, jstring source_j, jstring target_j) {
    if (!source_j || !target_j) return JNI_FALSE;
    const char *src = env->GetStringUTFChars(source_j, nullptr);
    const char *tgt = env->GetStringUTFChars(target_j, nullptr);
    if (!src || !tgt) {
        if (src) env->ReleaseStringUTFChars(source_j, src);
        if (tgt) env->ReleaseStringUTFChars(target_j, tgt);
        return JNI_FALSE;
    }
    bool ok = false;
    if (NativeRoot::EnsureJavaBindings(env) && NativeRoot::g_cache.methodMountFile) {
        jboolean res = env->CallBooleanMethod(NativeRoot::g_cache.rootShellObj, NativeRoot::g_cache.methodMountFile, source_j, target_j);
        CHECK_JNI_EXCEPTION(env, JNI_FALSE);
        ok = (res == JNI_TRUE);
    }
    if (!ok) {
        ok = (mount(src, tgt, nullptr, MS_BIND, nullptr) == 0);
    }
    env->ReleaseStringUTFChars(source_j, src);
    env->ReleaseStringUTFChars(target_j, tgt);
    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL NativeRoot_SetSELinux(JNIEnv *env, jclass clazz, jstring path_j, jstring context_j) {
    if (!path_j || !context_j) return JNI_FALSE;
    bool ok = false;
    if (NativeRoot::EnsureJavaBindings(env) && NativeRoot::g_cache.methodSetSELinuxContext) {
        jboolean res = env->CallBooleanMethod(NativeRoot::g_cache.rootShellObj, NativeRoot::g_cache.methodSetSELinuxContext, path_j, context_j);
        CHECK_JNI_EXCEPTION(env, JNI_FALSE);
        ok = (res == JNI_TRUE);
    }
    return ok ? JNI_TRUE : JNI_FALSE;
}

}
