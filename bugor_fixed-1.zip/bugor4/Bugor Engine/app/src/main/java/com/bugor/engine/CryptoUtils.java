package com.bugor.engine;

import android.util.Base64;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class CryptoUtils {
    private static final String AES_CBC_PADDING = "AES/CBC/PKCS5Padding";
    private static final String AES_GCM_NO_PADDING = "AES/GCM/NoPadding";
    private static final String RSA_ECB_PADDING = "RSA/ECB/PKCS1Padding";
    private static final String HMAC_SHA256 = "HmacSHA256";
    private static final String HMAC_SHA512 = "HmacSHA512";
    private static final String SHA_256 = "SHA-256";
    private static final String SHA_512 = "SHA-512";
    private static final String PBKDF2_HMAC_SHA256 = "PBKDF2WithHmacSHA256";
    private static final String RSA = "RSA";
    private static final String AES = "AES";
    private static final int GCM_IV_LENGTH = 12;
    private static final int GCM_TAG_LENGTH = 128;
    private static final int AES_KEY_SIZE = 256;
    private static final int PBKDF2_ITERATIONS = 100000;
    private static final int PBKDF2_KEY_LENGTH = 256;
    private static final String CHARSET = "UTF-8";
    private static final int BUFFER_SIZE = 8192;
    private static SecureRandom secureRandom = new SecureRandom();

    public static byte[] aesCbcEncrypt(byte[] data, byte[] key, byte[] iv) {
        try {
            SecretKeySpec keySpec = new SecretKeySpec(key, AES);
            IvParameterSpec ivSpec = new IvParameterSpec(iv);
            Cipher cipher = Cipher.getInstance(AES_CBC_PADDING);
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);
            return cipher.doFinal(data);
        } catch (Exception e) {
            return data;
        }
    }

    public static byte[] aesCbcDecrypt(byte[] encrypted, byte[] key, byte[] iv) {
        try {
            SecretKeySpec keySpec = new SecretKeySpec(key, AES);
            IvParameterSpec ivSpec = new IvParameterSpec(iv);
            Cipher cipher = Cipher.getInstance(AES_CBC_PADDING);
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
            return cipher.doFinal(encrypted);
        } catch (Exception e) {
            return encrypted;
        }
    }

    public static byte[] aesGcmEncrypt(byte[] data, byte[] key) {
        try {
            byte[] iv = new byte[GCM_IV_LENGTH];
            secureRandom.nextBytes(iv);
            GCMParameterSpec spec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
            SecretKeySpec keySpec = new SecretKeySpec(key, AES);
            Cipher cipher = Cipher.getInstance(AES_GCM_NO_PADDING);
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, spec);
            byte[] encrypted = cipher.doFinal(data);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            baos.write(iv);
            baos.write(encrypted);
            return baos.toByteArray();
        } catch (Exception e) {
            return data;
        }
    }

    public static byte[] aesGcmDecrypt(byte[] data, byte[] key) {
        try {
            if (data.length < GCM_IV_LENGTH + GCM_TAG_LENGTH / 8) return data;
            byte[] iv = new byte[GCM_IV_LENGTH];
            System.arraycopy(data, 0, iv, 0, GCM_IV_LENGTH);
            byte[] encrypted = new byte[data.length - GCM_IV_LENGTH];
            System.arraycopy(data, GCM_IV_LENGTH, encrypted, 0, encrypted.length);
            GCMParameterSpec spec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
            SecretKeySpec keySpec = new SecretKeySpec(key, AES);
            Cipher cipher = Cipher.getInstance(AES_GCM_NO_PADDING);
            cipher.init(Cipher.DECRYPT_MODE, keySpec, spec);
            return cipher.doFinal(encrypted);
        } catch (Exception e) {
            return data;
        }
    }

    public static byte[] rsaEncrypt(byte[] data, PublicKey publicKey) {
        try {
            Cipher cipher = Cipher.getInstance(RSA_ECB_PADDING);
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);
            return cipher.doFinal(data);
        } catch (Exception e) {
            return data;
        }
    }

    public static byte[] rsaDecrypt(byte[] encrypted, PrivateKey privateKey) {
        try {
            Cipher cipher = Cipher.getInstance(RSA_ECB_PADDING);
            cipher.init(Cipher.DECRYPT_MODE, privateKey);
            return cipher.doFinal(encrypted);
        } catch (Exception e) {
            return encrypted;
        }
    }

    public static byte[] rsaSign(byte[] data, PrivateKey privateKey) {
        try {
            Signature sig = Signature.getInstance("SHA256withRSA");
            sig.initSign(privateKey);
            sig.update(data);
            return sig.sign();
        } catch (Exception e) {
            return new byte[0];
        }
    }

    public static boolean rsaVerify(byte[] data, byte[] signature, PublicKey publicKey) {
        try {
            Signature sig = Signature.getInstance("SHA256withRSA");
            sig.initVerify(publicKey);
            sig.update(data);
            return sig.verify(signature);
        } catch (Exception e) {
            return false;
        }
    }

    public static KeyPair generateRsaKeyPair(int keySize) {
        try {
            KeyPairGenerator kpg = KeyPairGenerator.getInstance(RSA);
            kpg.initialize(keySize, secureRandom);
            return kpg.generateKeyPair();
        } catch (Exception e) {
            return null;
        }
    }

    public static PublicKey getPublicKeyFromBytes(byte[] encoded) {
        try {
            X509EncodedKeySpec spec = new X509EncodedKeySpec(encoded);
            KeyFactory kf = KeyFactory.getInstance(RSA);
            return kf.generatePublic(spec);
        } catch (Exception e) {
            return null;
        }
    }

    public static PrivateKey getPrivateKeyFromBytes(byte[] encoded) {
        try {
            PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(encoded);
            KeyFactory kf = KeyFactory.getInstance(RSA);
            return kf.generatePrivate(spec);
        } catch (Exception e) {
            return null;
        }
    }

    public static byte[] sha256(byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance(SHA_256);
            return md.digest(data);
        } catch (Exception e) {
            return data;
        }
    }

    public static String sha256Hex(String data) {
        try {
            MessageDigest md = MessageDigest.getInstance(SHA_256);
            byte[] hash = md.digest(data.getBytes(CHARSET));
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) hex.append(String.format("%02x", b & 0xFF));
            return hex.toString();
        } catch (Exception e) {
            return "";
        }
    }

    public static byte[] sha512(byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance(SHA_512);
            return md.digest(data);
        } catch (Exception e) {
            return data;
        }
    }

    public static String sha512Hex(String data) {
        try {
            MessageDigest md = MessageDigest.getInstance(SHA_512);
            byte[] hash = md.digest(data.getBytes(CHARSET));
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) hex.append(String.format("%02x", b & 0xFF));
            return hex.toString();
        } catch (Exception e) {
            return "";
        }
    }

    public static byte[] hmacSha256(byte[] data, byte[] key) {
        try {
            Mac mac = Mac.getInstance(HMAC_SHA256);
            SecretKeySpec keySpec = new SecretKeySpec(key, HMAC_SHA256);
            mac.init(keySpec);
            return mac.doFinal(data);
        } catch (Exception e) {
            return new byte[0];
        }
    }

    public static String hmacSha256Hex(String data, String key) {
        try {
            Mac mac = Mac.getInstance(HMAC_SHA256);
            SecretKeySpec keySpec = new SecretKeySpec(
                key.getBytes(CHARSET), HMAC_SHA256);
            mac.init(keySpec);
            byte[] hash = mac.doFinal(data.getBytes(CHARSET));
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) hex.append(String.format("%02x", b & 0xFF));
            return hex.toString();
        } catch (Exception e) {
            return "";
        }
    }

    public static byte[] hmacSha512(byte[] data, byte[] key) {
        try {
            Mac mac = Mac.getInstance(HMAC_SHA512);
            SecretKeySpec keySpec = new SecretKeySpec(key, HMAC_SHA512);
            mac.init(keySpec);
            return mac.doFinal(data);
        } catch (Exception e) {
            return new byte[0];
        }
    }

    public static String base64Encode(byte[] data) {
        return Base64.encodeToString(data, Base64.NO_WRAP);
    }

    public static String base64EncodeUrlSafe(byte[] data) {
        return Base64.encodeToString(data, Base64.URL_SAFE | Base64.NO_WRAP);
    }

    public static byte[] base64Decode(String encoded) {
        return Base64.decode(encoded, Base64.DEFAULT);
    }

    public static byte[] base64DecodeUrlSafe(String encoded) {
        return Base64.decode(encoded, Base64.URL_SAFE);
    }

    public static byte[] generateSecureRandom(int length) {
        byte[] random = new byte[length];
        secureRandom.nextBytes(random);
        return random;
    }

    public static int generateSecureInt() {
        return secureRandom.nextInt();
    }

    public static long generateSecureLong() {
        return secureRandom.nextLong();
    }

    public static String generateSecureHexString(int length) {
        byte[] random = new byte[(length + 1) / 2];
        secureRandom.nextBytes(random);
        StringBuilder hex = new StringBuilder();
        for (byte b : random) hex.append(String.format("%02x", b & 0xFF));
        return hex.substring(0, length);
    }

    public static byte[] deriveKeyPbkdf2(String password, byte[] salt) {
        try {
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt,
                PBKDF2_ITERATIONS, PBKDF2_KEY_LENGTH);
            SecretKeyFactory skf = SecretKeyFactory.getInstance(PBKDF2_HMAC_SHA256);
            SecretKey key = skf.generateSecret(spec);
            return key.getEncoded();
        } catch (Exception e) {
            return sha256((password + byteArrayToHex(salt)).getBytes());
        }
    }

    public static byte[] deriveKeyPbkdf2(String password, byte[] salt,
                                          int iterations, int keyLength) {
        try {
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt,
                iterations, keyLength);
            SecretKeyFactory skf = SecretKeyFactory.getInstance(PBKDF2_HMAC_SHA256);
            SecretKey key = skf.generateSecret(spec);
            return key.getEncoded();
        } catch (Exception e) {
            return sha256((password + byteArrayToHex(salt)).getBytes());
        }
    }

    public static byte[] generateSalt(int length) {
        return generateSecureRandom(length);
    }

    public static SecretKey generateAesKey() {
        try {
            KeyGenerator kg = KeyGenerator.getInstance(AES);
            kg.init(AES_KEY_SIZE, secureRandom);
            return kg.generateKey();
        } catch (Exception e) {
            return new SecretKeySpec(generateSecureRandom(32), AES);
        }
    }

    public static byte[] generateIv(int length) {
        return generateSecureRandom(length);
    }

    public static boolean constantTimeEquals(byte[] a, byte[] b) {
        if (a == null && b == null) return true;
        if (a == null || b == null) return false;
        if (a.length != b.length) return false;
        int result = 0;
        for (int i = 0; i < a.length; i++) {
            result |= a[i] ^ b[i];
        }
        return result == 0;
    }

    public static boolean constantTimeEquals(String a, String b) {
        if (a == null && b == null) return true;
        if (a == null || b == null) return false;
        return constantTimeEquals(a.getBytes(), b.getBytes());
    }

    public static byte[] xorObfuscate(byte[] data, byte[] key) {
        byte[] result = new byte[data.length];
        for (int i = 0; i < data.length; i++) {
            result[i] = (byte) (data[i] ^ key[i % key.length]);
        }
        return result;
    }

    public static byte[] xorObfuscate(byte[] data, String key) {
        return xorObfuscate(data, key.getBytes());
    }

    public static String xorObfuscateString(String data, String key) {
        byte[] result = xorObfuscate(data.getBytes(), key.getBytes());
        return Base64.encodeToString(result, Base64.NO_WRAP);
    }

    public static String xorDeobfuscateString(String data, String key) {
        byte[] decoded = Base64.decode(data, Base64.NO_WRAP);
        byte[] result = xorObfuscate(decoded, key.getBytes());
        return new String(result);
    }

    public static void encryptFile(File input, File output, byte[] key, byte[] iv) {
        try {
            Cipher cipher = Cipher.getInstance(AES_CBC_PADDING);
            SecretKeySpec keySpec = new SecretKeySpec(key, AES);
            IvParameterSpec ivSpec = new IvParameterSpec(iv);
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);
            FileInputStream fis = new FileInputStream(input);
            FileOutputStream fos = new FileOutputStream(output);
            CipherOutputStream cos = new CipherOutputStream(fos, cipher);
            byte[] buffer = new byte[BUFFER_SIZE];
            int read;
            while ((read = fis.read(buffer)) != -1) {
                cos.write(buffer, 0, read);
            }
            cos.close();
            fis.close();
        } catch (Exception e) {
        }
    }

    public static void decryptFile(File input, File output, byte[] key, byte[] iv) {
        try {
            Cipher cipher = Cipher.getInstance(AES_CBC_PADDING);
            SecretKeySpec keySpec = new SecretKeySpec(key, AES);
            IvParameterSpec ivSpec = new IvParameterSpec(iv);
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
            FileInputStream fis = new FileInputStream(input);
            FileOutputStream fos = new FileOutputStream(output);
            CipherInputStream cis = new CipherInputStream(fis, cipher);
            byte[] buffer = new byte[BUFFER_SIZE];
            int read;
            while ((read = cis.read(buffer)) != -1) {
                fos.write(buffer, 0, read);
            }
            cis.close();
            fos.close();
        } catch (Exception e) {
        }
    }

    public static byte[] encryptWithHmac(byte[] data, byte[] encKey, byte[] hmacKey) {
        try {
            byte[] iv = generateIv(16);
            byte[] encrypted = aesCbcEncrypt(data, encKey, iv);
            byte[] payload = new byte[iv.length + encrypted.length];
            System.arraycopy(iv, 0, payload, 0, iv.length);
            System.arraycopy(encrypted, 0, payload, iv.length, encrypted.length);
            byte[] hmac = hmacSha256(payload, hmacKey);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            baos.write(payload);
            baos.write(hmac);
            return baos.toByteArray();
        } catch (Exception e) {
            return data;
        }
    }

    public static byte[] decryptWithHmac(byte[] data, byte[] encKey, byte[] hmacKey) {
        try {
            if (data.length < 16 + 32) return data;
            int payloadLen = data.length - 32;
            byte[] payload = new byte[payloadLen];
            byte[] hmac = new byte[32];
            System.arraycopy(data, 0, payload, 0, payloadLen);
            System.arraycopy(data, payloadLen, hmac, 0, 32);
            byte[] computed = hmacSha256(payload, hmacKey);
            if (!constantTimeEquals(hmac, computed)) return data;
            byte[] iv = new byte[16];
            byte[] encrypted = new byte[payloadLen - 16];
            System.arraycopy(payload, 0, iv, 0, 16);
            System.arraycopy(payload, 16, encrypted, 0, encrypted.length);
            return aesCbcDecrypt(encrypted, encKey, iv);
        } catch (Exception e) {
            return data;
        }
    }

    public static String byteArrayToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) sb.append(String.format("%02x", b & 0xFF));
        return sb.toString();
    }

    public static byte[] hexToByteArray(String hex) {
        int len = hex.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                + Character.digit(hex.charAt(i + 1), 16));
        }
        return data;
    }

    public static String encryptString(String plaintext, String key) {
        try {
            byte[] keyBytes = sha256(key.getBytes(CHARSET));
            byte[] iv = generateIv(16);
            byte[] encrypted = aesCbcEncrypt(plaintext.getBytes(CHARSET), keyBytes, iv);
            byte[] combined = new byte[iv.length + encrypted.length];
            System.arraycopy(iv, 0, combined, 0, iv.length);
            System.arraycopy(encrypted, 0, combined, iv.length, encrypted.length);
            return base64Encode(combined);
        } catch (Exception e) {
            return "";
        }
    }

    public static String decryptString(String encryptedData, String key) {
        try {
            byte[] keyBytes = sha256(key.getBytes(CHARSET));
            byte[] combined = base64Decode(encryptedData);
            byte[] iv = new byte[16];
            byte[] encrypted = new byte[combined.length - 16];
            System.arraycopy(combined, 0, iv, 0, 16);
            System.arraycopy(combined, 16, encrypted, 0, encrypted.length);
            byte[] decrypted = aesCbcDecrypt(encrypted, keyBytes, iv);
            return new String(decrypted, CHARSET);
        } catch (Exception e) {
            return "";
        }
    }

    public static byte[] rc4Encrypt(byte[] data, byte[] key) {
        int[] s = new int[256];
        byte[] result = new byte[data.length];
        for (int i = 0; i < 256; i++) s[i] = i;
        int j = 0;
        for (int i = 0; i < 256; i++) {
            j = (j + s[i] + (key[i % key.length] & 0xFF)) % 256;
            int temp = s[i];
            s[i] = s[j];
            s[j] = temp;
        }
        int i = 0;
        j = 0;
        for (int k = 0; k < data.length; k++) {
            i = (i + 1) % 256;
            j = (j + s[i]) % 256;
            int temp = s[i];
            s[i] = s[j];
            s[j] = temp;
            result[k] = (byte) (data[k] ^ s[(s[i] + s[j]) % 256]);
        }
        return result;
    }

    public static String rc4EncryptString(String data, String key) {
        try {
            byte[] result = rc4Encrypt(data.getBytes(CHARSET), key.getBytes(CHARSET));
            return byteArrayToHex(result);
        } catch (Exception e) {
            return "";
        }
    }

    public static String rc4DecryptString(String data, String key) {
        try {
            byte[] result = rc4Encrypt(hexToByteArray(data), key.getBytes(CHARSET));
            return new String(result, CHARSET);
        } catch (Exception e) {
            return "";
        }
    }

    public static String md5(String data) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] hash = md.digest(data.getBytes(CHARSET));
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) hex.append(String.format("%02x", b & 0xFF));
            return hex.toString();
        } catch (Exception e) {
            return "";
        }
    }

    public static byte[] combineKeyAndIv(byte[] key, byte[] iv) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            baos.write(key);
            baos.write(iv);
        } catch (IOException e) {
        }
        return sha256(baos.toByteArray());
    }

    public static byte[] incrementIv(byte[] iv) {
        byte[] result = Arrays.copyOf(iv, iv.length);
        for (int i = result.length - 1; i >= 0; i--) {
            result[i]++;
            if (result[i] != 0) break;
        }
        return result;
    }

    public static String fingerprintKey(byte[] key) {
        return sha256Hex(base64Encode(key));
    }

    public static boolean isKeyValid(byte[] key, int expectedLength) {
        return key != null && key.length == expectedLength;
    }

    public static byte[] padPKCS7(byte[] data, int blockSize) {
        int padding = blockSize - (data.length % blockSize);
        byte[] padded = new byte[data.length + padding];
        System.arraycopy(data, 0, padded, 0, data.length);
        for (int i = data.length; i < padded.length; i++) {
            padded[i] = (byte) padding;
        }
        return padded;
    }

    public static byte[] unpadPKCS7(byte[] data) {
        int padding = data[data.length - 1] & 0xFF;
        if (padding > data.length) return data;
        return Arrays.copyOf(data, data.length - padding);
    }

    public static byte[] encryptChaCha20(byte[] data, byte[] key, byte[] nonce) {
        try {
            int[] state = new int[16];
            state[0] = 0x61707865;
            state[1] = 0x3320646e;
            state[2] = 0x79622d32;
            state[3] = 0x6b206574;
            for (int i = 0; i < 8; i++) {
                state[4 + i] = bytesToInt(key, i * 4);
            }
            state[12] = 0;
            state[13] = 0;
            state[14] = bytesToInt(nonce, 0);
            state[15] = bytesToInt(nonce, 4);
            byte[] output = new byte[data.length];
            for (int i = 0; i < data.length; i += 64) {
                int[] block = chachaBlock(state);
                for (int j = 0; j < 64 && i + j < data.length; j++) {
                    output[i + j] = (byte) (data[i + j] ^ ((block[j / 4] >> ((j % 4) * 8)) & 0xFF));
                }
                state[12]++;
            }
            return output;
        } catch (Exception e) {
            return data;
        }
    }

    private static int[] chachaBlock(int[] state) {
        int[] x = Arrays.copyOf(state, 16);
        for (int i = 0; i < 10; i++) {
            quarterRound(x, 0, 4, 8, 12);
            quarterRound(x, 1, 5, 9, 13);
            quarterRound(x, 2, 6, 10, 14);
            quarterRound(x, 3, 7, 11, 15);
            quarterRound(x, 0, 5, 10, 15);
            quarterRound(x, 1, 6, 11, 12);
            quarterRound(x, 2, 7, 8, 13);
            quarterRound(x, 3, 4, 9, 14);
        }
        int[] result = new int[16];
        for (int i = 0; i < 16; i++) {
            result[i] = x[i] + state[i];
        }
        return result;
    }

    private static void quarterRound(int[] x, int a, int b, int c, int d) {
        x[a] += x[b]; x[d] ^= x[a]; x[d] = Integer.rotateLeft(x[d], 16);
        x[c] += x[d]; x[b] ^= x[c]; x[b] = Integer.rotateLeft(x[b], 12);
        x[a] += x[b]; x[d] ^= x[a]; x[d] = Integer.rotateLeft(x[d], 8);
        x[c] += x[d]; x[b] ^= x[c]; x[b] = Integer.rotateLeft(x[b], 7);
    }

    private static int bytesToInt(byte[] bytes, int offset) {
        return (bytes[offset] & 0xFF) | ((bytes[offset + 1] & 0xFF) << 8) |
            ((bytes[offset + 2] & 0xFF) << 16) | ((bytes[offset + 3] & 0xFF) << 24);
    }
}
