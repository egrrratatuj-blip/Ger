package com.bugor.engine;

import android.content.Context;
import android.graphics.SurfaceTexture;
import android.util.Log;
import android.view.Surface;
import android.view.TextureView;

import com.bugor.engine.IPCCond.IPCService;

public class TV extends TextureView implements TextureView.SurfaceTextureListener {
    public TV(Context context) {
        super(context);
        setOpaque(true);
        setSurfaceTextureListener(this);
    }

    public void onSurfaceTextureAvailable(SurfaceTexture surface, int width, int height) {
        if (MainActivity.useRoot) {
            try {
                IPCService.GetIPC().start(width, height);
                IPCService.GetIPC().setSurface(new Surface(surface));
            } catch (android.os.RemoteException e) {
                Log.e("TV", "IPC error: " + e.getMessage());
            }
        } else {
            SuperJNI.start(width, height);
            SuperJNI.setSurface(new Surface(surface));
        }
    }

    public void onSurfaceTextureSizeChanged(SurfaceTexture surface, int width, int height) {}
    public boolean onSurfaceTextureDestroyed(SurfaceTexture surface) { return false; }
    public void onSurfaceTextureUpdated(SurfaceTexture surface) {}
}
