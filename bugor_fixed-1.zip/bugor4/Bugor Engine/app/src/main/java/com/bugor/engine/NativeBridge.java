package com.bugor.engine;

import android.view.Surface;

public class NativeBridge {
    public static native void onSurfaceCreated(Surface surface);
    public static native void onSurfaceDestroyed();
    public static native void initEngine();
    public static native void shutdownEngine();
}
