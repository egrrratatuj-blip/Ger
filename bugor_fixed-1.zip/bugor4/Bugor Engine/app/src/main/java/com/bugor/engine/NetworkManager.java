package com.bugor.engine;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.util.Pair;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.Proxy;
import java.net.Socket;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

public class NetworkManager {
    private static volatile NetworkManager instance;
    private Context context;
    private ExecutorService executor = Executors.newFixedThreadPool(8);
    private ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(4);
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private Map<String, String> headers = new ConcurrentHashMap<>();
    private Map<String, String> defaultHeaders = new ConcurrentHashMap<>();
    private Map<String, List<NetworkCallback>> pendingCallbacks = new ConcurrentHashMap<>();
    private Map<String, WebSocketConnection> webSockets = new ConcurrentHashMap<>();
    private ConnectionPool connectionPool = new ConnectionPool();
    private RateLimiter rateLimiter = new RateLimiter(100, TimeUnit.SECONDS);
    private RetryPolicy retryPolicy = new RetryPolicy(3, 1000, 2.0);
    private AtomicLong totalBytesSent = new AtomicLong(0);
    private AtomicLong totalBytesReceived = new AtomicLong(0);
    private AtomicInteger activeRequests = new AtomicInteger(0);
    private AtomicBoolean isInitialized = new AtomicBoolean(false);
    private String baseUrl = "";
    private String apiKey = "";
    private boolean useProxy = false;
    private String proxyHost = "";
    private int proxyPort = 8080;
    private Proxy.Type proxyType = Proxy.Type.HTTP;
    private String proxyUsername = "";
    private String proxyPassword = "";
    private boolean certificatePinning = true;
    private List<String> pinnedCertHashes = new CopyOnWriteArrayList<>();
    private String encryptKey = "";
    private String encryptIv = "";
    private String hmacKey = "";
    private static final int DEFAULT_TIMEOUT = 30000;
    private static final int MAX_RETRIES = 5;
    private static final int MAX_CONNECTIONS = 20;
    private static final long KEEP_ALIVE_DURATION = 300000L;
    private static final String PREFS_CONFIG = "network_config";
    private static final String CLOUD_CONFIG_URL = "https://config.bugor-engine.com/config.json";

    public interface NetworkCallback {
        void onSuccess(int statusCode, byte[] data, Map<String, String> responseHeaders);
        void onError(int statusCode, String error);
        void onProgress(long bytesWritten, long totalBytes);
    }

    public interface WebSocketListener {
        void onOpen();
        void onMessage(String text);
        void onMessage(byte[] data);
        void onClosing(int code, String reason);
        void onClosed(int code, String reason);
        void onFailure(Throwable t);
    }

    public interface UploadCallback {
        void onProgress(long uploaded, long total);
        void onComplete(String response);
        void onError(String error);
    }

    public interface DownloadCallback {
        void onProgress(long downloaded, long total);
        void onComplete(File file);
        void onError(String error);
    }

    public interface ConfigCallback {
        void onConfigLoaded(Map<String, Object> config);
        void onConfigError(String error);
    }

    public static class NetworkResponse {
        public int statusCode;
        public byte[] data;
        public Map<String, String> headers;
        public long duration;
        public boolean isCached;
        public String url;
    }

    public static class NetworkException extends Exception {
        public int statusCode;
        public NetworkException(int code, String message) {
            super(message);
            this.statusCode = code;
        }
        public NetworkException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    private static class ConnectionPool {
        private Map<String, List<Socket>> pool = new ConcurrentHashMap<>();
        private AtomicInteger totalConnections = new AtomicInteger(0);

        public synchronized Socket getConnection(String host, int port) {
            String key = host + ":" + port;
            List<Socket> sockets = pool.get(key);
            if (sockets != null && !sockets.isEmpty()) {
                Socket s = sockets.remove(sockets.size() - 1);
                if (!s.isClosed() && s.isConnected()) {
                    totalConnections.decrementAndGet();
                    return s;
                }
            }
            return null;
        }

        public synchronized void returnConnection(String host, int port, Socket socket) {
            if (totalConnections.get() >= MAX_CONNECTIONS) {
                try { socket.close(); } catch (IOException e) {}
                return;
            }
            String key = host + ":" + port;
            List<Socket> sockets = pool.computeIfAbsent(key, k -> new ArrayList<>());
            sockets.add(socket);
            totalConnections.incrementAndGet();
        }

        public void closeAll() {
            for (List<Socket> sockets : pool.values()) {
                for (Socket s : sockets) {
                    try { s.close(); } catch (IOException e) {}
                }
            }
            pool.clear();
            totalConnections.set(0);
        }
    }

    private static class RateLimiter {
        private int maxRequests;
        private long timeWindow;
        private Map<Long, AtomicInteger> requestBuckets = new ConcurrentHashMap<>();

        public RateLimiter(int maxRequests, TimeUnit timeUnit) {
            this.maxRequests = maxRequests;
            this.timeWindow = timeUnit.toMillis(1);
        }

        public synchronized boolean tryAcquire() {
            long bucketKey = System.currentTimeMillis() / timeWindow;
            long now = System.currentTimeMillis();
            Iterator<Map.Entry<Long, AtomicInteger>> it = requestBuckets.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<Long, AtomicInteger> entry = it.next();
                if (now - entry.getKey() * timeWindow > timeWindow * 2) {
                    it.remove();
                }
            }
            AtomicInteger count = requestBuckets.computeIfAbsent(bucketKey, k -> new AtomicInteger(0));
            int current = count.incrementAndGet();
            return current <= maxRequests;
        }

        public int getRemainingTokens() {
            long bucketKey = System.currentTimeMillis() / timeWindow;
            AtomicInteger count = requestBuckets.get(bucketKey);
            return count != null ? Math.max(0, maxRequests - count.get()) : maxRequests;
        }
    }

    public static class RetryPolicy {
        public int maxRetries;
        public long baseDelayMs;
        public double backoffMultiplier;
        public List<Integer> retryableStatusCodes;

        public RetryPolicy(int maxRetries, long baseDelayMs, double backoffMultiplier) {
            this.maxRetries = maxRetries;
            this.baseDelayMs = baseDelayMs;
            this.backoffMultiplier = backoffMultiplier;
            this.retryableStatusCodes = Arrays.asList(408, 429, 500, 502, 503, 504);
        }

        public long getDelayMs(int attempt) {
            return (long) (baseDelayMs * Math.pow(backoffMultiplier, attempt));
        }

        public boolean shouldRetry(int statusCode) {
            return retryableStatusCodes.contains(statusCode);
        }
    }

    private static class WebSocketConnection {
        public String url;
        public WebSocketListener listener;
        public Socket socket;
        public Thread readerThread;
        public AtomicBoolean isOpen = new AtomicBoolean(false);
        public AtomicBoolean shouldReconnect = new AtomicBoolean(true);
        public int reconnectAttempts = 0;
        public static final int MAX_RECONNECT_ATTEMPTS = 10;

        public void send(String message) {
            if (!isOpen.get() || socket == null) return;
            try {
                OutputStream os = socket.getOutputStream();
                byte[] frame = encodeWebSocketFrame(message.getBytes("UTF-8"), 0x1);
                os.write(frame);
                os.flush();
            } catch (IOException e) {
                listener.onFailure(e);
            }
        }

        public void send(byte[] data) {
            if (!isOpen.get() || socket == null) return;
            try {
                OutputStream os = socket.getOutputStream();
                byte[] frame = encodeWebSocketFrame(data, 0x2);
                os.write(frame);
                os.flush();
            } catch (IOException e) {
                listener.onFailure(e);
            }
        }

        public void close(int code, String reason) {
            shouldReconnect.set(false);
            if (!isOpen.get()) return;
            try {
                byte[] closeFrame = encodeCloseFrame(code, reason);
                OutputStream os = socket.getOutputStream();
                os.write(closeFrame);
                os.flush();
                socket.close();
            } catch (IOException e) {
            }
            isOpen.set(false);
        }

        private byte[] encodeWebSocketFrame(byte[] payload, int opcode) {
            byte[] frame;
            int len = payload.length;
            if (len < 126) {
                frame = new byte[2 + (len > 0 ? 4 : 0) + len];
                frame[0] = (byte) (0x80 | opcode);
                frame[1] = (byte) (0x80 | len);
            } else if (len < 65536) {
                frame = new byte[4 + 4 + len];
                frame[0] = (byte) (0x80 | opcode);
                frame[1] = (byte) (0x80 | 126);
                frame[2] = (byte) (len >> 8);
                frame[3] = (byte) (len & 0xFF);
            } else {
                frame = new byte[10 + 4 + len];
                frame[0] = (byte) (0x80 | opcode);
                frame[1] = (byte) (0x80 | 127);
                for (int i = 0; i < 8; i++) {
                    frame[2 + i] = (byte) ((len >> (8 * (7 - i))) & 0xFF);
                }
            }
            if (len > 0) {
                byte[] mask = new byte[4];
                new SecureRandom().nextBytes(mask);
                int offset = frame.length - len - 4;
                System.arraycopy(mask, 0, frame, offset, 4);
                for (int i = 0; i < len; i++) {
                    frame[offset + 4 + i] = (byte) (payload[i] ^ mask[i % 4]);
                }
            }
            return frame;
        }

        private byte[] encodeCloseFrame(int code, String reason) {
            byte[] reasonBytes = reason != null ? reason.getBytes() : new byte[0];
            ByteBuffer bb = ByteBuffer.allocate(2 + reasonBytes.length);
            bb.putShort((short) code);
            bb.put(reasonBytes);
            return encodeWebSocketFrame(bb.array(), 0x8);
        }
    }

    private NetworkManager(Context context) {
        this.context = context.getApplicationContext();
        initDefaultHeaders();
        initCertificatePinning();
    }

    public static NetworkManager getInstance(Context context) {
        if (instance == null) {
            synchronized (NetworkManager.class) {
                if (instance == null) {
                    instance = new NetworkManager(context);
                }
            }
        }
        return instance;
    }

    private void initDefaultHeaders() {
        defaultHeaders.put("User-Agent", "BugorEngine/" + getAppVersion() +
            " (Android " + Build.VERSION.RELEASE + "; " + Build.MODEL + ")");
        defaultHeaders.put("Accept", "application/json, text/plain, */*");
        defaultHeaders.put("Accept-Encoding", "gzip, deflate");
        defaultHeaders.put("Accept-Language", Locale.getDefault().getLanguage());
        defaultHeaders.put("Connection", "keep-alive");
        defaultHeaders.put("Content-Type", "application/json; charset=UTF-8");
        defaultHeaders.put("X-Client-Version", String.valueOf(getAppVersion()));
        defaultHeaders.put("X-Platform", "android");
        defaultHeaders.put("X-Device-ID", Utils.getMaskedAndroidId());
    }

    private void initCertificatePinning() {
        // TODO: set real cert hashes
    }

    public void get(String url, NetworkCallback callback) {
        request("GET", url, null, null, callback);
    }

    public void post(String url, byte[] body, NetworkCallback callback) {
        request("POST", url, body, null, callback);
    }

    public void post(String url, String jsonBody, NetworkCallback callback) {
        request("POST", url, jsonBody.getBytes(), null, callback);
    }

    public void put(String url, byte[] body, NetworkCallback callback) {
        request("PUT", url, body, null, callback);
    }

    public void delete(String url, NetworkCallback callback) {
        request("DELETE", url, null, null, callback);
    }

    public void patch(String url, byte[] body, NetworkCallback callback) {
        request("PATCH", url, body, null, callback);
    }

    public void request(String method, String url, byte[] body,
                        Map<String, String> extraHeaders, NetworkCallback callback) {
        if (!isNetworkAvailable()) {
            if (callback != null)
                callback.onError(0, "No network connection");
            return;
        }
        if (!rateLimiter.tryAcquire()) {
            if (callback != null)
                callback.onError(429, "Rate limit exceeded");
            return;
        }
        activeRequests.incrementAndGet();
        executor.submit(() -> {
            long startTime = System.currentTimeMillis();
            try {
                NetworkResponse response = executeRequest(method, url, body, extraHeaders);
                response.duration = System.currentTimeMillis() - startTime;
                totalBytesSent.addAndGet(body != null ? body.length : 0);
                totalBytesReceived.addAndGet(response.data != null ? response.data.length : 0);
                mainHandler.post(() -> {
                    activeRequests.decrementAndGet();
                    if (response.statusCode >= 200 && response.statusCode < 300) {
                        if (callback != null)
                            callback.onSuccess(response.statusCode, response.data, response.headers);
                    } else {
                        if (retryPolicy.shouldRetry(response.statusCode)) {
                            retryWithBackoff(method, url, body, extraHeaders, callback, 0, startTime);
                        } else {
                            if (callback != null) {
                                String errorMsg = response.data != null ?
                                    new String(response.data) : "Error " + response.statusCode;
                                callback.onError(response.statusCode, errorMsg);
                            }
                        }
                    }
                });
            } catch (Exception e) {
                activeRequests.decrementAndGet();
                retryWithBackoff(method, url, body, extraHeaders, callback, 0, startTime);
            }
        });
    }

    private void retryWithBackoff(String method, String url, byte[] body,
                                  Map<String, String> extraHeaders,
                                  NetworkCallback callback, int attempt, long startTime) {
        if (attempt >= retryPolicy.maxRetries) {
            mainHandler.post(() -> {
                if (callback != null)
                    callback.onError(0, "Max retries exceeded");
            });
            return;
        }
        long delay = retryPolicy.getDelayMs(attempt);
        scheduler.schedule(() -> {
            try {
                NetworkResponse response = executeRequest(method, url, body, extraHeaders);
                response.duration = System.currentTimeMillis() - startTime;
                totalBytesReceived.addAndGet(response.data != null ? response.data.length : 0);
                mainHandler.post(() -> {
                    if (response.statusCode >= 200 && response.statusCode < 300) {
                        if (callback != null)
                            callback.onSuccess(response.statusCode, response.data, response.headers);
                    } else if (retryPolicy.shouldRetry(response.statusCode)) {
                        retryWithBackoff(method, url, body, extraHeaders, callback,
                            attempt + 1, startTime);
                    } else {
                        if (callback != null) {
                            callback.onError(response.statusCode, new String(response.data));
                        }
                    }
                });
            } catch (Exception e) {
                retryWithBackoff(method, url, body, extraHeaders, callback,
                    attempt + 1, startTime);
            }
        }, delay, TimeUnit.MILLISECONDS);
    }

    private NetworkResponse executeRequest(String method, String url, byte[] body,
                                           Map<String, String> extraHeaders) throws IOException {
        HttpURLConnection conn = null;
        try {
            URL requestUrl = new URL(url);
            if (useProxy && !proxyHost.isEmpty()) {
                Proxy proxy = new Proxy(proxyType,
                    new InetSocketAddress(proxyHost, proxyPort));
                conn = (HttpURLConnection) requestUrl.openConnection(proxy);
                if (!proxyUsername.isEmpty()) {
                    Authenticator.setDefault(new Authenticator() {
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication(
                                proxyUsername, proxyPassword.toCharArray());
                        }
                    });
                }
            } else {
                conn = (HttpURLConnection) requestUrl.openConnection();
            }
            conn.setRequestMethod(method);
            conn.setConnectTimeout(DEFAULT_TIMEOUT);
            conn.setReadTimeout(DEFAULT_TIMEOUT);
            conn.setDoInput(true);
            conn.setUseCaches(false);
            for (Map.Entry<String, String> entry : defaultHeaders.entrySet()) {
                conn.setRequestProperty(entry.getKey(), entry.getValue());
            }
            for (Map.Entry<String, String> entry : headers.entrySet()) {
                conn.setRequestProperty(entry.getKey(), entry.getValue());
            }
            if (extraHeaders != null) {
                for (Map.Entry<String, String> entry : extraHeaders.entrySet()) {
                    conn.setRequestProperty(entry.getKey(), entry.getValue());
                }
            }
            if (body != null && body.length > 0) {
                conn.setDoOutput(true);
                byte[] encryptedBody = encryptPayload(body);
                OutputStream os = conn.getOutputStream();
                os.write(encryptedBody);
                os.flush();
                os.close();
            }
            if (url.startsWith("https") && certificatePinning) {
                if (conn instanceof HttpsURLConnection) {
                    HttpsURLConnection httpsConn = (HttpsURLConnection) conn;
                    httpsConn.setSSLSocketFactory(createPinnedSSLSocketFactory());
                    httpsConn.setHostnameVerifier(new HostnameVerifier() {
                        public boolean verify(String hostname, SSLSession session) {
                            return verifyCertificatePinning(hostname, session);
                        }
                    });
                }
            }
            NetworkResponse response = new NetworkResponse();
            response.statusCode = conn.getResponseCode();
            response.url = url;
            response.headers = new HashMap<>();
            for (Map.Entry<String, List<String>> entry : conn.getHeaderFields().entrySet()) {
                if (entry.getKey() != null && !entry.getValue().isEmpty()) {
                    response.headers.put(entry.getKey(), entry.getValue().get(0));
                }
            }
            InputStream is;
            if (response.statusCode >= 400) {
                is = conn.getErrorStream();
            } else {
                is = conn.getInputStream();
            }
            if (is != null) {
                String encoding = conn.getContentEncoding();
                if ("gzip".equalsIgnoreCase(encoding)) {
                    is = new GZIPInputStream(is);
                }
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                byte[] buffer = new byte[8192];
                int read;
                while ((read = is.read(buffer)) != -1) {
                    baos.write(buffer, 0, read);
                }
                is.close();
                response.data = decryptPayload(baos.toByteArray());
            }
            return response;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private SSLSocketFactory createPinnedSSLSocketFactory() {
        try {
            if (pinnedCertHashes.isEmpty()) {
                return (SSLSocketFactory) SSLSocketFactory.getDefault();
            }
            TrustManagerFactory tmf = TrustManagerFactory.getInstance(
                TrustManagerFactory.getDefaultAlgorithm());
            tmf.init((KeyStore) null);
            SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, tmf.getTrustManagers(), new SecureRandom());
            return sslContext.getSocketFactory();
        } catch (Exception e) {
            return (SSLSocketFactory) SSLSocketFactory.getDefault();
        }
    }

    private boolean verifyCertificatePinning(String hostname, SSLSession session) {
        if (pinnedCertHashes.isEmpty()) return true;
        try {
            X509Certificate[] certs = (X509Certificate[]) session
                .getPeerCertificates();
            for (X509Certificate cert : certs) {
                byte[] der = cert.getEncoded();
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                byte[] hash = md.digest(der);
                String hashBase64 = "sha256/" +
                    Base64.encodeToString(hash, Base64.NO_WRAP);
                for (String pinned : pinnedCertHashes) {
                    if (pinned.equals(hashBase64)) return true;
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    public WebSocketConnection createWebSocket(String url, WebSocketListener listener) {
        WebSocketConnection ws = new WebSocketConnection();
        ws.url = url;
        ws.listener = listener;
        webSockets.put(url, ws);
        connectWebSocket(ws);
        return ws;
    }

    private void connectWebSocket(WebSocketConnection ws) {
        executor.submit(() -> {
            try {
                URL wsUrl = new URL(ws.url.replace("ws://", "http://").replace("wss://", "https://"));
                Socket socket;
                if (ws.url.startsWith("wss")) {
                    SSLContext sslContext = SSLContext.getInstance("TLS");
                    sslContext.init(null, null, new SecureRandom());
                    socket = sslContext.getSocketFactory().createSocket(
                        wsUrl.getHost(), wsUrl.getPort() > 0 ? wsUrl.getPort() : 443);
                } else {
                    socket = new Socket(wsUrl.getHost(),
                        wsUrl.getPort() > 0 ? wsUrl.getPort() : 80);
                }
                ws.socket = socket;
                String path = wsUrl.getPath().isEmpty() ? "/" : wsUrl.getPath();
                byte[] keyBytes = new byte[16];
                new SecureRandom().nextBytes(keyBytes);
                String wsKey = Base64.encodeToString(keyBytes, Base64.NO_WRAP);
                String handshake = "GET " + path + " HTTP/1.1\r\n" +
                    "Host: " + wsUrl.getHost() + "\r\n" +
                    "Upgrade: websocket\r\n" +
                    "Connection: Upgrade\r\n" +
                    "Sec-WebSocket-Key: " + wsKey + "\r\n" +
                    "Sec-WebSocket-Version: 13\r\n\r\n";
                OutputStream handshakeOs = socket.getOutputStream();
                handshakeOs.write(handshake.getBytes("UTF-8"));
                handshakeOs.flush();
                InputStream handshakeIs = socket.getInputStream();
                java.io.BufferedReader handshakeReader = new java.io.BufferedReader(
                    new java.io.InputStreamReader(handshakeIs));
                String statusLine = handshakeReader.readLine();
                if (statusLine == null || !statusLine.contains("101")) {
                    socket.close();
                    ws.listener.onFailure(new IOException("WebSocket handshake failed: " + statusLine));
                    return;
                }
                String headerLine;
                while ((headerLine = handshakeReader.readLine()) != null && !headerLine.isEmpty()) {}
                ws.isOpen.set(true);
                ws.listener.onOpen();
                byte[] buffer = new byte[8192];
                InputStream is = socket.getInputStream();
                while (ws.isOpen.get()) {
                    int read = is.read(buffer);
                    if (read == -1) break;
                    processWebSocketFrame(ws, buffer, read);
                }
            } catch (Exception e) {
                ws.isOpen.set(false);
                ws.listener.onFailure(e);
                if (ws.shouldReconnect.get() &&
                    ws.reconnectAttempts < WebSocketConnection.MAX_RECONNECT_ATTEMPTS) {
                    ws.reconnectAttempts++;
                    long delay = (long) Math.pow(2, ws.reconnectAttempts) * 1000;
                    scheduler.schedule(() -> connectWebSocket(ws), delay, TimeUnit.MILLISECONDS);
                }
            }
        });
    }

    private void processWebSocketFrame(WebSocketConnection ws, byte[] buffer, int length) {
        if (length < 2) return;
        byte firstByte = buffer[0];
        byte secondByte = buffer[1];
        boolean masked = (secondByte & 0x80) != 0;
        int payloadLength = secondByte & 0x7F;
        int offset = 2;
        if (payloadLength == 126) {
            payloadLength = ((buffer[offset] & 0xFF) << 8) | (buffer[offset + 1] & 0xFF);
            offset += 2;
        } else if (payloadLength == 127) {
            payloadLength = 0;
            for (int i = 0; i < 8; i++) {
                payloadLength = (payloadLength << 8) | (buffer[offset + i] & 0xFF);
            }
            offset += 8;
        }
        byte[] maskKey = null;
        if (masked) {
            maskKey = new byte[4];
            System.arraycopy(buffer, offset, maskKey, 0, 4);
            offset += 4;
        }
        byte[] payload = new byte[payloadLength];
        System.arraycopy(buffer, offset, payload, 0, payloadLength);
        if (masked && maskKey != null) {
            for (int i = 0; i < payload.length; i++) {
                payload[i] ^= maskKey[i % 4];
            }
        }
        int opcode = firstByte & 0x0F;
        switch (opcode) {
            case 0x1:
                ws.listener.onMessage(new String(payload));
                break;
            case 0x2:
                ws.listener.onMessage(payload);
                break;
            case 0x8:
                int closeCode = payload.length >= 2 ?
                    ((payload[0] & 0xFF) << 8) | (payload[1] & 0xFF) : 1000;
                String reason = payload.length > 2 ?
                    new String(payload, 2, payload.length - 2) : "";
                ws.isOpen.set(false);
                ws.listener.onClosing(closeCode, reason);
                ws.listener.onClosed(closeCode, reason);
                break;
            case 0x9:
                byte[] pong = new byte[1];
                pong[0] = (byte) 0x8A;
                try {
                    ws.socket.getOutputStream().write(pong);
                } catch (IOException e) {
                }
                break;
        }
    }

    public void uploadFile(String url, File file, String fieldName,
                           Map<String, String> formFields, UploadCallback callback) {
        executor.submit(() -> {
            try {
                String boundary = "Boundary-" + System.currentTimeMillis();
                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type",
                    "multipart/form-data; boundary=" + boundary);
                conn.setConnectTimeout(DEFAULT_TIMEOUT);
                conn.setReadTimeout(0);
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                if (formFields != null) {
                    for (Map.Entry<String, String> entry : formFields.entrySet()) {
                        baos.write(("--" + boundary + "\r\n").getBytes());
                        baos.write(("Content-Disposition: form-data; name=\"" +
                            entry.getKey() + "\"\r\n\r\n").getBytes());
                        baos.write((entry.getValue() + "\r\n").getBytes());
                    }
                }
                baos.write(("--" + boundary + "\r\n").getBytes());
                baos.write(("Content-Disposition: form-data; name=\"" + fieldName +
                    "\"; filename=\"" + file.getName() + "\"\r\n").getBytes());
                baos.write(("Content-Type: application/octet-stream\r\n\r\n").getBytes());
                long fileLength = file.length();
                try (FileInputStream fis = new FileInputStream(file)) {
                    byte[] buffer = new byte[8192];
                    int read;
                    long totalRead = 0;
                    while ((read = fis.read(buffer)) != -1) {
                        baos.write(buffer, 0, read);
                        totalRead += read;
                        final long progress = totalRead;
                        mainHandler.post(() -> {
                            if (callback != null)
                                callback.onProgress(progress, fileLength);
                        });
                    }
                }
                baos.write(("\r\n--" + boundary + "--\r\n").getBytes());
                byte[] body = baos.toByteArray();
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(body);
                    os.flush();
                }
                int code = conn.getResponseCode();
                StringBuilder response = new StringBuilder();
                try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(conn.getInputStream()))) {
                    String line;
                    while ((line = br.readLine()) != null) response.append(line);
                }
                conn.disconnect();
                final String result = response.toString();
                mainHandler.post(() -> {
                    if (code >= 200 && code < 300) {
                        if (callback != null) callback.onComplete(result);
                    } else {
                        if (callback != null) callback.onError("HTTP " + code + ": " + result);
                    }
                });
            } catch (Exception e) {
                mainHandler.post(() -> {
                    if (callback != null) callback.onError(e.getMessage());
                });
            }
        });
    }

    public void downloadFile(String url, File destination, DownloadCallback callback) {
        executor.submit(() -> {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(DEFAULT_TIMEOUT);
                conn.setReadTimeout(0);
                for (Map.Entry<String, String> entry : defaultHeaders.entrySet()) {
                    conn.setRequestProperty(entry.getKey(), entry.getValue());
                }
                if (destination.exists()) {
                    long existingLength = destination.length();
                    conn.setRequestProperty("Range", "bytes=" + existingLength + "-");
                }
                int code = conn.getResponseCode();
                long contentLength = conn.getContentLengthLong();
                boolean resume = code == 206;
                try (InputStream is = conn.getInputStream();
                     RandomAccessFile raf = new RandomAccessFile(destination, "rw")) {
                    if (resume) raf.seek(destination.length());
                    byte[] buffer = new byte[8192];
                    int read;
                    long totalRead = resume ? destination.length() : 0;
                    long lastProgressUpdate = 0;
                    while ((read = is.read(buffer)) != -1) {
                        raf.write(buffer, 0, read);
                        totalRead += read;
                        if (totalRead - lastProgressUpdate > 65536) {
                            lastProgressUpdate = totalRead;
                            final long progress = totalRead;
                            final long total = contentLength > 0 ? contentLength : -1;
                            mainHandler.post(() -> {
                                if (callback != null)
                                    callback.onProgress(progress, total);
                            });
                        }
                    }
                }
                conn.disconnect();
                final File downloadedFile = destination;
                mainHandler.post(() -> {
                    if (callback != null)
                        callback.onComplete(downloadedFile);
                });
            } catch (Exception e) {
                mainHandler.post(() -> {
                    if (callback != null) callback.onError(e.getMessage());
                });
            }
        });
    }

    public void fetchCloudConfig(ConfigCallback callback) {
        get(CLOUD_CONFIG_URL, new NetworkCallback() {
            public void onSuccess(int code, byte[] data, Map<String, String> headers) {
                try {
                    String json = new String(data, "UTF-8");
                    Map<String, Object> config = parseConfigJson(json);
                    cacheConfig(json);
                    mainHandler.post(() -> {
                        if (callback != null) callback.onConfigLoaded(config);
                    });
                } catch (Exception e) {
                    loadCachedConfig(callback);
                }
            }

            public void onError(int code, String error) {
                loadCachedConfig(callback);
            }

            public void onProgress(long written, long total) {
            }
        });
    }

    private void loadCachedConfig(ConfigCallback callback) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(
                PREFS_CONFIG, Context.MODE_PRIVATE);
            String cached = prefs.getString("cloud_config", null);
            if (cached != null) {
                Map<String, Object> config = parseConfigJson(cached);
                if (callback != null) callback.onConfigLoaded(config);
            } else {
                if (callback != null) callback.onConfigError("No cached config");
            }
        } catch (Exception e) {
            if (callback != null) callback.onConfigError(e.getMessage());
        }
    }

    private void cacheConfig(String json) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(
                PREFS_CONFIG, Context.MODE_PRIVATE);
            prefs.edit().putString("cloud_config", json).apply();
        } catch (Exception e) {
        }
    }

    private Map<String, Object> parseConfigJson(String json) {
        Map<String, Object> config = new HashMap<>();
        try {
            String cleaned = json.trim();
            if (cleaned.startsWith("{")) cleaned = cleaned.substring(1);
            if (cleaned.endsWith("}")) cleaned = cleaned.substring(0, cleaned.length() - 1);
            String[] pairs = splitJsonPairs(cleaned);
            for (String pair : pairs) {
                int colonIdx = pair.indexOf(':');
                if (colonIdx > 0) {
                    String key = pair.substring(0, colonIdx).trim();
                    String value = pair.substring(colonIdx + 1).trim();
                    key = key.replaceAll("^\"|\"$", "");
                    if (value.startsWith("\"")) {
                        value = value.replaceAll("^\"|\"$", "");
                        config.put(key, value);
                    } else if (value.equals("true") || value.equals("false")) {
                        config.put(key, Boolean.parseBoolean(value));
                    } else if (value.contains(".")) {
                        config.put(key, Double.parseDouble(value));
                    } else {
                        try {
                            config.put(key, Integer.parseInt(value));
                        } catch (NumberFormatException e) {
                            config.put(key, Long.parseLong(value));
                        }
                    }
                }
            }
        } catch (Exception e) {
        }
        return config;
    }

    private String[] splitJsonPairs(String json) {
        List<String> pairs = new ArrayList<>();
        int depth = 0;
        StringBuilder current = new StringBuilder();
        boolean inString = false;
        for (char c : json.toCharArray()) {
            if (c == '"' && (current.length() == 0 || current.charAt(current.length() - 1) != '\\')) {
                inString = !inString;
            }
            if (!inString) {
                if (c == '{' || c == '[') depth++;
                if (c == '}' || c == ']') depth--;
                if (c == ',' && depth == 0) {
                    pairs.add(current.toString());
                    current = new StringBuilder();
                    continue;
                }
            }
            current.append(c);
        }
        if (current.length() > 0) pairs.add(current.toString());
        return pairs.toArray(new String[0]);
    }

    public byte[] encryptPayload(byte[] data) {
        if (encryptKey.isEmpty()) return data;
        try {
            byte[] keyBytes = Base64.decode(encryptKey, Base64.DEFAULT);
            byte[] ivBytes = Base64.decode(encryptIv, Base64.DEFAULT);
            SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");
            IvParameterSpec ivSpec = new IvParameterSpec(ivBytes);
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);
            byte[] encrypted = cipher.doFinal(data);
            Mac mac = Mac.getInstance("HmacSHA256");
            SecretKeySpec macKey = new SecretKeySpec(
                Base64.decode(hmacKey, Base64.DEFAULT), "HmacSHA256");
            mac.init(macKey);
            byte[] hmac = mac.doFinal(encrypted);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            baos.write(encrypted);
            baos.write(hmac);
            return baos.toByteArray();
        } catch (Exception e) {
            return data;
        }
    }

    public byte[] decryptPayload(byte[] data) {
        if (encryptKey.isEmpty()) return data;
        try {
            if (data.length < 32) return data;
            byte[] encrypted = new byte[data.length - 32];
            byte[] hmac = new byte[32];
            System.arraycopy(data, 0, encrypted, 0, encrypted.length);
            System.arraycopy(data, data.length - 32, hmac, 0, 32);
            Mac mac = Mac.getInstance("HmacSHA256");
            SecretKeySpec macKey = new SecretKeySpec(
                Base64.decode(hmacKey, Base64.DEFAULT), "HmacSHA256");
            mac.init(macKey);
            byte[] computedHmac = mac.doFinal(encrypted);
            if (!MessageDigest.isEqual(hmac, computedHmac)) return data;
            byte[] keyBytes = Base64.decode(encryptKey, Base64.DEFAULT);
            byte[] ivBytes = Base64.decode(encryptIv, Base64.DEFAULT);
            SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");
            IvParameterSpec ivSpec = new IvParameterSpec(ivBytes);
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
            return cipher.doFinal(encrypted);
        } catch (Exception e) {
            return data;
        }
    }

    public boolean isNetworkAvailable() {
        try {
            ConnectivityManager cm = (ConnectivityManager)
                context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                NetworkCapabilities nc = cm.getNetworkCapabilities(cm.getActiveNetwork());
                return nc != null && nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
            } else {
                NetworkInfo ni = cm.getActiveNetworkInfo();
                return ni != null && ni.isConnected();
            }
        } catch (Exception e) {
            return false;
        }
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = baseUrl;
    }

    public void setApiKey(String apiKey) {
        this.apiKey = apiKey;
        headers.put("X-API-Key", apiKey);
    }

    public void setEncryptionKeys(String encryptKey, String encryptIv, String hmacKey) {
        this.encryptKey = encryptKey;
        this.encryptIv = encryptIv;
        this.hmacKey = hmacKey;
    }

    public void setProxy(String host, int port, Proxy.Type type, String user, String pass) {
        this.useProxy = true;
        this.proxyHost = host;
        this.proxyPort = port;
        this.proxyType = type;
        this.proxyUsername = user != null ? user : "";
        this.proxyPassword = pass != null ? pass : "";
    }

    public void disableProxy() {
        this.useProxy = false;
    }

    public void setCertificatePinning(boolean enable) {
        this.certificatePinning = enable;
    }

    public void addPinnedCertificateHash(String hash) {
        pinnedCertHashes.add(hash);
    }

    public void setRetryPolicy(RetryPolicy policy) {
        this.retryPolicy = policy;
    }

    public void setRateLimit(int maxRequests, TimeUnit timeUnit) {
        this.rateLimiter = new RateLimiter(maxRequests, timeUnit);
    }

    public void addHeader(String key, String value) {
        headers.put(key, value);
    }

    public void removeHeader(String key) {
        headers.remove(key);
    }

    public void clearHeaders() {
        headers.clear();
    }

    public long getTotalBytesSent() {
        return totalBytesSent.get();
    }

    public long getTotalBytesReceived() {
        return totalBytesReceived.get();
    }

    public int getActiveRequests() {
        return activeRequests.get();
    }

    public void cancelAll() {
        executor.shutdownNow();
        connectionPool.closeAll();
        for (WebSocketConnection ws : webSockets.values()) {
            ws.close(1001, "Shutdown");
        }
        webSockets.clear();
    }

    public void destroy() {
        cancelAll();
        scheduler.shutdownNow();
        instance = null;
    }

    private int getAppVersion() {
        try {
            return context.getPackageManager()
                .getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (Exception e) {
            return 1;
        }
    }
}
