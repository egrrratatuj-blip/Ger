package com.bugor.engine;

import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.util.Base64;
import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlSerializer;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class ConfigSerializer {
    private static volatile ConfigSerializer instance;
    private Context context;
    private ExecutorService executor = Executors.newFixedThreadPool(3);
    private AtomicBoolean isExporting = new AtomicBoolean(false);
    private AtomicBoolean isImporting = new AtomicBoolean(false);
    private String configDir;
    private String cloudUploadUrl = "https://config.bugor-engine.com/upload";
    private String cloudDownloadUrl = "https://config.bugor-engine.com/download";
    private byte[] encryptionKey;
    private static final int GCM_TAG_LENGTH = 128;
    private static final int GCM_IV_LENGTH = 12;
    private static final String CONFIG_EXTENSION_JSON = ".json";
    private static final String CONFIG_EXTENSION_XML = ".xml";
    private static final String CONFIG_EXTENSION_BIN = ".bcf";
    private static final String CONFIG_EXTENSION_ENCRYPTED = ".enc";
    private static final String DEFAULT_CONFIG_NAME = "bugor_config";
    private static final int BUFFER_SIZE = 8192;

    public interface ConfigCallback {
        void onExportCompleted(File file, String format);
        void onImportCompleted(Map<String, Object> config);
        void onMergeCompleted(Map<String, Object> merged);
        void onError(String error);
        void onProgress(int percent, String status);
    }

    public interface CloudCallback {
        void onUploaded(String url);
        void onDownloaded(Map<String, Object> config);
        void onError(String error);
    }

    public static class ConfigDiff {
        public List<String> added = new ArrayList<>();
        public List<String> removed = new ArrayList<>();
        public List<String> modified = new ArrayList<>();
        public List<String> unchanged = new ArrayList<>();
        public Map<String, Object> oldValues = new HashMap<>();
        public Map<String, Object> newValues = new HashMap<>();

        public boolean hasChanges() {
            return !added.isEmpty() || !removed.isEmpty() || !modified.isEmpty();
        }

        public int totalChanges() {
            return added.size() + removed.size() + modified.size();
        }
    }

    public static class ConfigEntry {
        public String key;
        public Object value;
        public String type;
        public String group;
        public String description;
        public long timestamp;
    }

    private ConfigSerializer(Context context) {
        this.context = context.getApplicationContext();
        this.configDir = context.getFilesDir().getAbsolutePath() + File.separator + "configs";
        new File(configDir).mkdirs();
        initEncryptionKey();
    }

    public static ConfigSerializer getInstance(Context context) {
        if (instance == null) {
            synchronized (ConfigSerializer.class) {
                if (instance == null) {
                    instance = new ConfigSerializer(context);
                }
            }
        }
        return instance;
    }

    private void initEncryptionKey() {
        try {
            String hwid = Utils.getMaskedAndroidId();
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest((hwid + "bugor_salt_2024").getBytes("UTF-8"));
            encryptionKey = Arrays.copyOf(hash, 32);
        } catch (Exception e) {
            encryptionKey = new byte[32];
            new SecureRandom().nextBytes(encryptionKey);
        }
    }

    public File exportToJson(Map<String, Object> config, String name) {
        try {
            String json = serializeJson(config);
            if (name == null) name = DEFAULT_CONFIG_NAME;
            File file = new File(configDir, name + CONFIG_EXTENSION_JSON);
            FileWriter fw = new FileWriter(file);
            fw.write(json);
            fw.close();
            return file;
        } catch (Exception e) {
            return null;
        }
    }

    public File exportToXml(Map<String, Object> config, String name) {
        try {
            String xml = serializeXml(config);
            if (name == null) name = DEFAULT_CONFIG_NAME;
            File file = new File(configDir, name + CONFIG_EXTENSION_XML);
            FileWriter fw = new FileWriter(file);
            fw.write(xml);
            fw.close();
            return file;
        } catch (Exception e) {
            return null;
        }
    }

    public File exportToBinary(Map<String, Object> config, String name, boolean encrypt) {
        try {
            if (name == null) name = DEFAULT_CONFIG_NAME;
            byte[] data = serializeBinary(config);
            if (encrypt) {
                data = encryptData(data);
                name += CONFIG_EXTENSION_ENCRYPTED;
            } else {
                name += CONFIG_EXTENSION_BIN;
            }
            File file = new File(configDir, name);
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(data);
            fos.close();
            return file;
        } catch (Exception e) {
            return null;
        }
    }

    public Map<String, Object> importFromFile(File file) {
        try {
            String name = file.getName().toLowerCase(Locale.US);
            if (name.endsWith(CONFIG_EXTENSION_JSON)) {
                return importFromJson(file);
            } else if (name.endsWith(CONFIG_EXTENSION_XML)) {
                return importFromXml(file);
            } else if (name.endsWith(CONFIG_EXTENSION_ENCRYPTED)) {
                return importFromEncrypted(file);
            } else if (name.endsWith(CONFIG_EXTENSION_BIN)) {
                return importFromBinary(file);
            } else {
                return importFromJson(file);
            }
        } catch (Exception e) {
            return null;
        }
    }

    public Map<String, Object> importFromJson(File file) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(file));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            return deserializeJson(sb.toString());
        } catch (Exception e) {
            return null;
        }
    }

    public Map<String, Object> importFromJson(String json) {
        return deserializeJson(json);
    }

    public Map<String, Object> importFromXml(File file) {
        try {
            FileInputStream fis = new FileInputStream(file);
            Map<String, Object> config = deserializeXml(fis);
            fis.close();
            return config;
        } catch (Exception e) {
            return null;
        }
    }

    public Map<String, Object> importFromBinary(File file) {
        try {
            FileInputStream fis = new FileInputStream(file);
            byte[] data = new byte[(int) file.length()];
            fis.read(data);
            fis.close();
            return deserializeBinary(data);
        } catch (Exception e) {
            return null;
        }
    }

    public Map<String, Object> importFromEncrypted(File file) {
        try {
            FileInputStream fis = new FileInputStream(file);
            byte[] data = new byte[(int) file.length()];
            fis.read(data);
            fis.close();
            byte[] decrypted = decryptData(data);
            return deserializeBinary(decrypted);
        } catch (Exception e) {
            return null;
        }
    }

    public Map<String, Object> mergeConfigs(Map<String, Object> base,
                                            Map<String, Object> override) {
        Map<String, Object> result = new LinkedHashMap<>(base);
        mergeDeep(result, override);
        return result;
    }

    public Map<String, Object> mergeConfigsWithStrategy(Map<String, Object> base,
                                                         Map<String, Object> override,
                                                         MergeStrategy strategy) {
        Map<String, Object> result = new LinkedHashMap<>(base);
        for (Map.Entry<String, Object> entry : override.entrySet()) {
            switch (strategy) {
                case OVERRIDE:
                    result.put(entry.getKey(), entry.getValue());
                    break;
                case KEEP_EXISTING:
                    if (!result.containsKey(entry.getKey())) {
                        result.put(entry.getKey(), entry.getValue());
                    }
                    break;
                case MERGE_DEEP:
                    if (result.containsKey(entry.getKey())) {
                        Object existing = result.get(entry.getKey());
                        if (existing instanceof Map && entry.getValue() instanceof Map) {
                            @SuppressWarnings("unchecked")
                            Map<String, Object> merged = mergeConfigs(
                                (Map<String, Object>) existing,
                                (Map<String, Object>) entry.getValue());
                            result.put(entry.getKey(), merged);
                        } else {
                            result.put(entry.getKey(), entry.getValue());
                        }
                    } else {
                        result.put(entry.getKey(), entry.getValue());
                    }
                    break;
                case PREFER_NEWER:
                    result.put(entry.getKey(), entry.getValue());
                    break;
            }
        }
        return result;
    }

    public ConfigDiff diffConfigs(Map<String, Object> oldConfig,
                                  Map<String, Object> newConfig) {
        ConfigDiff diff = new ConfigDiff();
        for (Map.Entry<String, Object> entry : newConfig.entrySet()) {
            if (!oldConfig.containsKey(entry.getKey())) {
                diff.added.add(entry.getKey());
                diff.newValues.put(entry.getKey(), entry.getValue());
            } else {
                Object oldVal = oldConfig.get(entry.getKey());
                Object newVal = entry.getValue();
                if (!valuesEqual(oldVal, newVal)) {
                    diff.modified.add(entry.getKey());
                    diff.oldValues.put(entry.getKey(), oldVal);
                    diff.newValues.put(entry.getKey(), newVal);
                } else {
                    diff.unchanged.add(entry.getKey());
                }
            }
        }
        for (Map.Entry<String, Object> entry : oldConfig.entrySet()) {
            if (!newConfig.containsKey(entry.getKey())) {
                diff.removed.add(entry.getKey());
                diff.oldValues.put(entry.getKey(), entry.getValue());
            }
        }
        return diff;
    }

    public String diffToJson(ConfigDiff diff) {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"added\": [");
        for (int i = 0; i < diff.added.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append("\"").append(escapeJson(diff.added.get(i))).append("\"");
        }
        sb.append("],\n");
        sb.append("  \"removed\": [");
        for (int i = 0; i < diff.removed.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append("\"").append(escapeJson(diff.removed.get(i))).append("\"");
        }
        sb.append("],\n");
        sb.append("  \"modified\": [");
        for (int i = 0; i < diff.modified.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append("\"").append(escapeJson(diff.modified.get(i))).append("\"");
        }
        sb.append("],\n");
        sb.append("  \"changes\": ").append(diff.totalChanges()).append("\n");
        sb.append("}");
        return sb.toString();
    }

    public void exportConfigAsync(Map<String, Object> config, String name,
                                  String format, boolean encrypt, ConfigCallback callback) {
        if (isExporting.getAndSet(true)) {
            if (callback != null) callback.onError("Already exporting");
            return;
        }
        executor.submit(() -> {
            try {
                mainHandler.post(() -> {
                    if (callback != null) callback.onProgress(10, "Serializing config");
                });
                File file;
                switch (format.toLowerCase(Locale.US)) {
                    case "xml":
                        file = exportToXml(config, name);
                        break;
                    case "binary":
                        file = exportToBinary(config, name, encrypt);
                        break;
                    case "json":
                    default:
                        file = exportToJson(config, name);
                        break;
                }
                final File result = file;
                mainHandler.post(() -> {
                    isExporting.set(false);
                    if (result != null && callback != null) {
                        callback.onProgress(100, "Completed");
                        callback.onExportCompleted(result, format);
                    } else if (callback != null) {
                        callback.onError("Export failed");
                    }
                });
            } catch (Exception e) {
                mainHandler.post(() -> {
                    isExporting.set(false);
                    if (callback != null) callback.onError(e.getMessage());
                });
            }
        });
    }

    public void importConfigAsync(File file, ConfigCallback callback) {
        if (isImporting.getAndSet(true)) {
            if (callback != null) callback.onError("Already importing");
            return;
        }
        executor.submit(() -> {
            try {
                mainHandler.post(() -> {
                    if (callback != null) callback.onProgress(10, "Reading file");
                });
                Map<String, Object> config = importFromFile(file);
                final Map<String, Object> result = config;
                mainHandler.post(() -> {
                    isImporting.set(false);
                    if (result != null && callback != null) {
                        callback.onProgress(100, "Completed");
                        callback.onImportCompleted(result);
                    } else if (callback != null) {
                        callback.onError("Import failed: invalid format");
                    }
                });
            } catch (Exception e) {
                mainHandler.post(() -> {
                    isImporting.set(false);
                    if (callback != null) callback.onError(e.getMessage());
                });
            }
        });
    }

    public void mergeConfigsAsync(Map<String, Object> base, Map<String, Object> override,
                                  MergeStrategy strategy, ConfigCallback callback) {
        executor.submit(() -> {
            try {
                Map<String, Object> merged;
                if (strategy != null) {
                    merged = mergeConfigsWithStrategy(base, override, strategy);
                } else {
                    merged = mergeConfigs(base, override);
                }
                final Map<String, Object> result = merged;
                mainHandler.post(() -> {
                    if (result != null && callback != null) {
                        callback.onMergeCompleted(result);
                    } else if (callback != null) {
                        callback.onError("Merge failed");
                    }
                });
            } catch (Exception e) {
                mainHandler.post(() -> {
                    if (callback != null) callback.onError(e.getMessage());
                });
            }
        });
    }

    public void uploadToCloud(Map<String, Object> config, String fileName,
                              CloudCallback callback) {
        executor.submit(() -> {
            try {
                String json = serializeJson(config);
                byte[] compressed = compress(json.getBytes("UTF-8"));
                byte[] encrypted = encryptData(compressed);
                URL url = new URL(cloudUploadUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setConnectTimeout(30000);
                conn.setReadTimeout(60000);
                conn.setRequestProperty("Content-Type", "application/octet-stream");
                conn.setRequestProperty("X-File-Name", fileName != null ? fileName : DEFAULT_CONFIG_NAME);
                conn.setRequestProperty("X-Device-ID", Utils.getMaskedAndroidId());
                OutputStream os = conn.getOutputStream();
                os.write(encrypted);
                os.close();
                int code = conn.getResponseCode();
                if (code == 200) {
                    BufferedReader br = new BufferedReader(
                        new InputStreamReader(conn.getInputStream(), "UTF-8"));
                    String response = br.readLine();
                    br.close();
                    final String downloadUrl = response;
                    mainHandler.post(() -> {
                        if (callback != null) callback.onUploaded(downloadUrl);
                    });
                } else {
                    mainHandler.post(() -> {
                        if (callback != null) callback.onError("Upload failed: " + code);
                    });
                }
                conn.disconnect();
            } catch (Exception e) {
                mainHandler.post(() -> {
                    if (callback != null) callback.onError(e.getMessage());
                });
            }
        });
    }

    public void downloadFromCloud(String downloadUrl, CloudCallback callback) {
        executor.submit(() -> {
            try {
                URL url = new URL(downloadUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(30000);
                conn.setReadTimeout(60000);
                int code = conn.getResponseCode();
                if (code == 200) {
                    InputStream is = conn.getInputStream();
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    byte[] buffer = new byte[BUFFER_SIZE];
                    int read;
                    while ((read = is.read(buffer)) != -1) baos.write(buffer, 0, read);
                    is.close();
                    byte[] encrypted = baos.toByteArray();
                    byte[] decrypted = decryptData(encrypted);
                    byte[] decompressed = decompress(decrypted);
                    String json = new String(decompressed, "UTF-8");
                    final Map<String, Object> config = deserializeJson(json);
                    mainHandler.post(() -> {
                        if (callback != null) callback.onDownloaded(config);
                    });
                } else {
                    mainHandler.post(() -> {
                        if (callback != null) callback.onError("Download failed: " + code);
                    });
                }
                conn.disconnect();
            } catch (Exception e) {
                mainHandler.post(() -> {
                    if (callback != null) callback.onError(e.getMessage());
                });
            }
        });
    }

    private String serializeJson(Map<String, Object> config) {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n");
        sb.append("  \"_generated\": \"").append(getCurrentTimestamp()).append("\",\n");
        sb.append("  \"_version\": 1,\n");
        sb.append("  \"config\": {\n");
        boolean first = true;
        for (Map.Entry<String, Object> entry : config.entrySet()) {
            if (!first) sb.append(",\n");
            first = false;
            sb.append("    \"").append(escapeJson(entry.getKey())).append("\": ");
            sb.append(valueToJson(entry.getValue()));
        }
        sb.append("\n  }\n}");
        return sb.toString();
    }

    private String valueToJson(Object value) {
        if (value == null) return "null";
        if (value instanceof String) return "\"" + escapeJson((String) value) + "\"";
        if (value instanceof Boolean) return value.toString();
        if (value instanceof Integer) return value.toString();
        if (value instanceof Long) return value.toString();
        if (value instanceof Float) return value.toString();
        if (value instanceof Double) return value.toString();
        if (value instanceof Map) {
            @SuppressWarnings("unchecked")
            Map<String, Object> map = (Map<String, Object>) value;
            StringBuilder sb = new StringBuilder("{");
            boolean first = true;
            for (Map.Entry<String, Object> e : map.entrySet()) {
                if (!first) sb.append(",");
                first = false;
                sb.append("\"").append(escapeJson(e.getKey())).append("\":");
                sb.append(valueToJson(e.getValue()));
            }
            sb.append("}");
            return sb.toString();
        }
        if (value instanceof List) {
            @SuppressWarnings("unchecked")
            List<Object> list = (List<Object>) value;
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < list.size(); i++) {
                if (i > 0) sb.append(",");
                sb.append(valueToJson(list.get(i)));
            }
            sb.append("]");
            return sb.toString();
        }
        return "\"" + escapeJson(value.toString()) + "\"";
    }

    private String serializeXml(Map<String, Object> config) {
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        sb.append("<config>\n");
        sb.append("  <metadata>\n");
        sb.append("    <generated>").append(escapeXml(getCurrentTimestamp())).append("</generated>\n");
        sb.append("    <version>1</version>\n");
        sb.append("  </metadata>\n");
        sb.append("  <settings>\n");
        for (Map.Entry<String, Object> entry : config.entrySet()) {
            sb.append("    <setting name=\"").append(escapeXml(entry.getKey())).append("\">");
            sb.append(escapeXml(String.valueOf(entry.getValue())));
            sb.append("</setting>\n");
        }
        sb.append("  </settings>\n");
        sb.append("</config>");
        return sb.toString();
    }

    private byte[] serializeBinary(Map<String, Object> config) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            baos.write("BCF1".getBytes("UTF-8"));
            for (Map.Entry<String, Object> entry : config.entrySet()) {
                byte[] keyBytes = entry.getKey().getBytes("UTF-8");
                baos.write((byte) (keyBytes.length & 0xFF));
                baos.write((byte) ((keyBytes.length >> 8) & 0xFF));
                baos.write(keyBytes);
                Object value = entry.getValue();
                if (value instanceof String) {
                    baos.write(0x01);
                    byte[] valBytes = ((String) value).getBytes("UTF-8");
                    baos.write((byte) (valBytes.length & 0xFF));
                    baos.write((byte) ((valBytes.length >> 8) & 0xFF));
                    baos.write(valBytes);
                } else if (value instanceof Boolean) {
                    baos.write(0x02);
                    baos.write((Boolean) value ? 1 : 0);
                } else if (value instanceof Integer) {
                    baos.write(0x03);
                    int val = (Integer) value;
                    for (int i = 0; i < 4; i++) baos.write((byte) ((val >> (i * 8)) & 0xFF));
                } else if (value instanceof Long) {
                    baos.write(0x04);
                    long val = (Long) value;
                    for (int i = 0; i < 8; i++) baos.write((byte) ((val >> (i * 8)) & 0xFF));
                } else if (value instanceof Double) {
                    baos.write(0x05);
                    long bits = Double.doubleToLongBits((Double) value);
                    for (int i = 0; i < 8; i++) baos.write((byte) ((bits >> (i * 8)) & 0xFF));
                } else {
                    baos.write(0x01);
                    byte[] valBytes = String.valueOf(value).getBytes("UTF-8");
                    baos.write((byte) (valBytes.length & 0xFF));
                    baos.write((byte) ((valBytes.length >> 8) & 0xFF));
                    baos.write(valBytes);
                }
            }
            baos.write(0x00);
            return baos.toByteArray();
        } catch (Exception e) {
            return new byte[0];
        }
    }

    private Map<String, Object> deserializeJson(String json) {
        Map<String, Object> config = new LinkedHashMap<>();
        try {
            String clean = json.trim();
            int configStart = clean.indexOf("\"config\":");
            if (configStart > 0) {
                configStart = clean.indexOf('{', configStart);
                if (configStart > 0) {
                    int depth = 1;
                    int pos = configStart + 1;
                    StringBuilder inner = new StringBuilder();
                    while (depth > 0 && pos < clean.length()) {
                        char c = clean.charAt(pos);
                        if (c == '{') depth++;
                        if (c == '}') depth--;
                        if (depth > 0) inner.append(c);
                        pos++;
                    }
                    String content = inner.toString();
                    String[] pairs = splitTopLevel(content);
                    for (String pair : pairs) {
                        int colon = pair.indexOf(':');
                        if (colon > 0) {
                            String key = pair.substring(0, colon).trim();
                            String value = pair.substring(colon + 1).trim();
                            key = key.replaceAll("^\"|\"$", "");
                            config.put(key, parseJsonValue(value));
                        }
                    }
                }
            }
        } catch (Exception e) {
        }
        return config;
    }

    private Object parseJsonValue(String value) {
        value = value.trim();
        if (value.equals("null")) return null;
        if (value.equals("true")) return true;
        if (value.equals("false")) return false;
        if (value.startsWith("\"") && value.endsWith("\"")) {
            return value.substring(1, value.length() - 1);
        }
        if (value.startsWith("{")) {
            Map<String, Object> map = new LinkedHashMap<>();
            String inner = value.substring(1, value.length() - 1);
            String[] pairs = splitTopLevel(inner);
            for (String pair : pairs) {
                int colon = pair.indexOf(':');
                if (colon > 0) {
                    String k = pair.substring(0, colon).trim().replaceAll("^\"|\"$", "");
                    String v = pair.substring(colon + 1).trim();
                    map.put(k, parseJsonValue(v));
                }
            }
            return map;
        }
        if (value.startsWith("[")) {
            List<Object> list = new ArrayList<>();
            String inner = value.substring(1, value.length() - 1);
            if (!inner.trim().isEmpty()) {
                String[] items = splitTopLevel(inner);
                for (String item : items) list.add(parseJsonValue(item.trim()));
            }
            return list;
        }
        if (value.contains(".")) {
            try { return Double.parseDouble(value); } catch (NumberFormatException e) {}
        }
        try { return Integer.parseInt(value); } catch (NumberFormatException e) {}
        try { return Long.parseLong(value); } catch (NumberFormatException e) {}
        return value;
    }

    private String[] splitTopLevel(String s) {
        List<String> parts = new ArrayList<>();
        int depth = 0;
        boolean inStr = false;
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c == '"' && (sb.length() == 0 || sb.charAt(sb.length() - 1) != '\\')) inStr = !inStr;
            if (!inStr) {
                if (c == '{' || c == '[') depth++;
                if (c == '}' || c == ']') depth--;
                if (c == ',' && depth == 0) {
                    parts.add(sb.toString());
                    sb = new StringBuilder();
                    continue;
                }
            }
            sb.append(c);
        }
        if (sb.length() > 0) parts.add(sb.toString());
        return parts.toArray(new String[0]);
    }

    private Map<String, Object> deserializeXml(InputStream is) {
        Map<String, Object> config = new LinkedHashMap<>();
        try {
            XmlPullParser parser = Xml.newPullParser();
            parser.setInput(is, "UTF-8");
            int eventType = parser.getEventType();
            String currentKey = null;
            while (eventType != XmlPullParser.END_DOCUMENT) {
                if (eventType == XmlPullParser.START_TAG) {
                    if ("setting".equals(parser.getName())) {
                        currentKey = parser.getAttributeValue(null, "name");
                    }
                } else if (eventType == XmlPullParser.TEXT && currentKey != null) {
                    config.put(currentKey, parser.getText());
                } else if (eventType == XmlPullParser.END_TAG) {
                    if ("setting".equals(parser.getName())) currentKey = null;
                }
                eventType = parser.next();
            }
        } catch (Exception e) {
        }
        return config;
    }

    private Map<String, Object> deserializeBinary(byte[] data) {
        Map<String, Object> config = new LinkedHashMap<>();
        try {
            ByteArrayInputStream bais = new ByteArrayInputStream(data);
            byte[] header = new byte[4];
            bais.read(header);
            while (true) {
                int keyLenLow = bais.read();
                if (keyLenLow == 0 || keyLenLow == -1) break;
                int keyLenHigh = bais.read();
                if (keyLenHigh == -1) break;
                int keyLen = keyLenLow | (keyLenHigh << 8);
                byte[] keyBytes = new byte[keyLen];
                bais.read(keyBytes);
                String key = new String(keyBytes, "UTF-8");
                int type = bais.read();
                if (type == -1) break;
                switch (type) {
                    case 0x01: {
                        int valLen = bais.read() | (bais.read() << 8);
                        byte[] valBytes = new byte[valLen];
                        bais.read(valBytes);
                        config.put(key, new String(valBytes, "UTF-8"));
                        break;
                    }
                    case 0x02:
                        config.put(key, bais.read() == 1);
                        break;
                    case 0x03: {
                        int val = 0;
                        for (int i = 0; i < 4; i++) val |= (bais.read() << (i * 8));
                        config.put(key, val);
                        break;
                    }
                    case 0x04: {
                        long val = 0;
                        for (int i = 0; i < 8; i++) val |= ((long) bais.read() << (i * 8));
                        config.put(key, val);
                        break;
                    }
                    case 0x05: {
                        long bits = 0;
                        for (int i = 0; i < 8; i++) bits |= ((long) bais.read() << (i * 8));
                        config.put(key, Double.longBitsToDouble(bits));
                        break;
                    }
                }
            }
        } catch (Exception e) {
        }
        return config;
    }

    private byte[] encryptData(byte[] data) {
        try {
            KeyGenerator kg = KeyGenerator.getInstance("AES");
            kg.init(256);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            SecureRandom sr = new SecureRandom();
            byte[] iv = new byte[GCM_IV_LENGTH];
            sr.nextBytes(iv);
            GCMParameterSpec spec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
            SecretKeySpec keySpec = new SecretKeySpec(encryptionKey, "AES");
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, spec);
            byte[] encrypted = cipher.doFinal(data);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            baos.write(iv);
            baos.write(encrypted);
            return baos.toByteArray();
        } catch (Exception e) {
            return data;
        }
    }

    private byte[] decryptData(byte[] data) {
        try {
            if (data.length < GCM_IV_LENGTH + GCM_TAG_LENGTH / 8) return data;
            byte[] iv = new byte[GCM_IV_LENGTH];
            System.arraycopy(data, 0, iv, 0, GCM_IV_LENGTH);
            byte[] encrypted = new byte[data.length - GCM_IV_LENGTH];
            System.arraycopy(data, GCM_IV_LENGTH, encrypted, 0, encrypted.length);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            GCMParameterSpec spec = new GCMParameterSpec(GCM_TAG_LENGTH, iv);
            SecretKeySpec keySpec = new SecretKeySpec(encryptionKey, "AES");
            cipher.init(Cipher.DECRYPT_MODE, keySpec, spec);
            return cipher.doFinal(encrypted);
        } catch (Exception e) {
            return data;
        }
    }

    private byte[] compress(byte[] data) {
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            GZIPOutputStream gzip = new GZIPOutputStream(baos);
            gzip.write(data);
            gzip.close();
            return baos.toByteArray();
        } catch (Exception e) {
            return data;
        }
    }

    private byte[] decompress(byte[] data) {
        try {
            ByteArrayInputStream bais = new ByteArrayInputStream(data);
            GZIPInputStream gzip = new GZIPInputStream(bais);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buffer = new byte[BUFFER_SIZE];
            int read;
            while ((read = gzip.read(buffer)) != -1) baos.write(buffer, 0, read);
            gzip.close();
            return baos.toByteArray();
        } catch (Exception e) {
            return data;
        }
    }

    private void mergeDeep(Map<String, Object> base, Map<String, Object> override) {
        for (Map.Entry<String, Object> entry : override.entrySet()) {
            String key = entry.getKey();
            Object value = entry.getValue();
            if (base.containsKey(key) && value instanceof Map &&
                base.get(key) instanceof Map) {
                @SuppressWarnings("unchecked")
                Map<String, Object> baseMap = (Map<String, Object>) base.get(key);
                @SuppressWarnings("unchecked")
                Map<String, Object> overrideMap = (Map<String, Object>) value;
                mergeDeep(baseMap, overrideMap);
            } else {
                base.put(key, value);
            }
        }
    }

    private boolean valuesEqual(Object a, Object b) {
        if (a == null && b == null) return true;
        if (a == null || b == null) return false;
        return a.equals(b);
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t");
    }

    private String escapeXml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;");
    }

    private String getCurrentTimestamp() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        return sdf.format(new Date());
    }

    public enum MergeStrategy {
        OVERRIDE,
        KEEP_EXISTING,
        MERGE_DEEP,
        PREFER_NEWER
    }

    public boolean isExporting() {
        return isExporting.get();
    }

    public boolean isImporting() {
        return isImporting.get();
    }

    public File[] listConfigFiles() {
        File dir = new File(configDir);
        return dir.listFiles((d, name) ->
            name.endsWith(CONFIG_EXTENSION_JSON) ||
            name.endsWith(CONFIG_EXTENSION_XML) ||
            name.endsWith(CONFIG_EXTENSION_BIN) ||
            name.endsWith(CONFIG_EXTENSION_ENCRYPTED));
    }

    public boolean deleteConfigFile(String name) {
        File dir = new File(configDir);
        boolean deleted = false;
        String[] exts = {CONFIG_EXTENSION_JSON, CONFIG_EXTENSION_XML,
            CONFIG_EXTENSION_BIN, CONFIG_EXTENSION_ENCRYPTED};
        for (String ext : exts) {
            File f = new File(dir, name + ext);
            if (f.exists()) {
                if (f.delete()) deleted = true;
            }
        }
        return deleted;
    }

    public void setConfigDir(String dir) {
        this.configDir = dir;
        new File(dir).mkdirs();
    }

    public void setCloudUrls(String uploadUrl, String downloadUrl) {
        this.cloudUploadUrl = uploadUrl;
        this.cloudDownloadUrl = downloadUrl;
    }

    public void setEncryptionKey(byte[] key) {
        if (key != null && key.length >= 16) {
            try {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                this.encryptionKey = md.digest(key);
            } catch (Exception e) {
                this.encryptionKey = Arrays.copyOf(key, 32);
            }
        }
    }

    public void destroy() {
        executor.shutdownNow();
        instance = null;
    }

    private android.os.Handler mainHandler = new android.os.Handler(
        android.os.Looper.getMainLooper());
}
