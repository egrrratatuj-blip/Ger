package com.bugor.engine;

import android.app.Activity;
import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;

import com.bugor.engine.IPCCond.IPCService;
import android.view.WindowManager;

public class StartGame {
    private static WindowManager manager;
    private static View touchView;
    private static WindowManager.LayoutParams touchParams;

    public static void showFloatWindow(final Activity activity) {
        manager = (WindowManager) activity.getSystemService(Context.WINDOW_SERVICE);

        final WindowManager.LayoutParams overlayParams = new WindowManager.LayoutParams();
        overlayParams.systemUiVisibility = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN;
        overlayParams.type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
            WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
        overlayParams.gravity = Gravity.TOP | Gravity.LEFT;
        overlayParams.format = PixelFormat.TRANSPARENT;
        overlayParams.width = WindowManager.LayoutParams.MATCH_PARENT;
        overlayParams.height = WindowManager.LayoutParams.MATCH_PARENT;
        overlayParams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED |
            WindowManager.LayoutParams.FLAG_FULLSCREEN |
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS |
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            overlayParams.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        touchView = new View(activity);
        touchParams = new WindowManager.LayoutParams();
        touchParams.type = overlayParams.type;
        touchParams.gravity = Gravity.TOP | Gravity.LEFT;
        touchParams.format = PixelFormat.TRANSPARENT;
        touchParams.width = 800;
        touchParams.height = 800;
        touchParams.x = 40;
        touchParams.y = 40;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            touchParams.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        touchParams.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED |
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;

        touchView.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent event) {
                try {
                    int actionMasked = event.getActionMasked();
                    int pointerCount = event.getPointerCount();
                    int[] viewLoc = new int[2];
                    v.getLocationOnScreen(viewLoc);

                    if (actionMasked == MotionEvent.ACTION_MOVE) {
                        for (int i = 0; i < pointerCount; i++) {
                            int pid = event.getPointerId(i);
                            float x = event.getX(i) + viewLoc[0];
                            float y = event.getY(i) + viewLoc[1];
                            float p = event.getPressure(i);
                            if (MainActivity.useRoot) {
                                IPCService.GetIPC().MotionEventClick(2, pid, x, y, p);
                            } else {
                                SuperJNI.MotionEventClick(2, pid, x, y, p);
                            }
                        }
                    } else {
                        int idx = event.getActionIndex();
                        int pid = event.getPointerId(idx);
                        float x = event.getX(idx) + viewLoc[0];
                        float y = event.getY(idx) + viewLoc[1];
                        float p = event.getPressure(idx);
                        int nativeAction = (actionMasked == MotionEvent.ACTION_DOWN || actionMasked == MotionEvent.ACTION_POINTER_DOWN) ? 0 : 1;
                        if (MainActivity.useRoot) {
                            IPCService.GetIPC().MotionEventClick(nativeAction, pid, x, y, p);
                        } else {
                            SuperJNI.MotionEventClick(nativeAction, pid, x, y, p);
                        }
                    }
                } catch (Exception e) {}
                return true;
            }
        });

        final TV myTV = new TV(activity);
        overlayParams.token = myTV.getApplicationWindowToken();
        touchParams.token = touchView.getApplicationWindowToken();

        manager.addView(myTV, overlayParams);
        manager.addView(touchView, touchParams);
        updateTouchWinSize();
    }

    public static void updateTouchWinSize() {
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                try {
                    float[] rect = MainActivity.useRoot ?
                        IPCService.GetIPC().GetImGuiwinsize() :
                        SuperJNI.GetImGuiwinsize();
                    if (rect != null && rect.length >= 4) {
                        touchParams.x = (int) rect[0];
                        touchParams.y = (int) rect[1];
                        touchParams.width = (int) rect[2];
                        touchParams.height = (int) rect[3];
                        manager.updateViewLayout(touchView, touchParams);
                    }
                } catch (Exception e) {}
                handler.postDelayed(this, 17);
            }
        }, 17);
    }
}
