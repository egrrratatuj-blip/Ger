package com.bugor.engine;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends AppCompatActivity {
    static {
        try {
            System.loadLibrary("BugorEngine");
        } catch (UnsatisfiedLinkError e) {
            Log.e("Bugor", "Native lib not loaded: " + e.getMessage());
        }
    }

    public static boolean useRoot = false;
    public static MainActivity instance;
    public static android.content.Context appContext;
    private static final String TAG = "BugorEngine";
    private static final int OVERLAY_PERMISSION_REQUEST = 1001;
    private static final int WRITE_STORAGE_REQUEST = 1002;

    private SurfaceView surfaceView;
    private Surface nativeSurface;

    private BugorBridge bridge;
    private Handler handler;
    private SharedPreferences prefs;
    private LinearLayout mainContainer;
    private TextView statusText;
    private TextView logText;
    private EditText addressInput;
    private EditText valueInput;
    private EditText scriptInput;
    private EditText searchValueInput;
    private EditText moduleNameInput;
    private Spinner valueTypeSpinner;
    private Spinner valueSizeSpinner;
    private Spinner searchTypeSpinner;
    private Button attachButton;
    private Button readButton;
    private Button writeButton;
    private Button searchButton;
    private Button freezeButton;
    private Button unfreezeButton;
    private Button regionsButton;
    private Button executeButton;
    private Button loadScriptButton;
    private Button hookButton;
    private Button dumpButton;
    private Button clearLogButton;
    private Button speedHackButton;
    private Button godModeButton;
    private Button currencyButton;
    private Button xpButton;
    private Button unlimitedAmmoButton;
    private Button noCooldownButton;
    private Button instantKillButton;
    private Button damageMultiplierButton;
    private Button unlockAllButton;
    private Button antiBanButton;
    private Button bypassButton;
    private Button settingsButton;
    private Button aboutButton;
    private Button remoteConnectButton;
    private Button remoteDisconnectButton;
    private Button encryptButton;
    private Button decryptButton;
    private Button hashButton;
    private Button saveStateButton;
    private Button loadStateButton;
    private ProgressBar progressBar;
    private Switch freezeSwitch;
    private Switch hookSwitch;
    private Switch remoteSwitch;
    private ListView resultsListView;
    private ListView regionsListView;
    private ArrayAdapter<String> resultsAdapter;
    private ArrayAdapter<String> regionsAdapter;
    private ArrayList<String> resultsList;
    private ArrayList<String> regionsList;
    private ScrollView logScrollView;
    private TabHost tabHost;
    private LinearLayout frozenValuesLayout;

    private String targetProcess = "";
    private boolean attached = false;
    private long currentAddress = 0;
    private int currentValueType = 0;
    private int currentValueSize = 4;
    private Map<Long, String> frozenAddresses = new HashMap<>();
    private volatile boolean autoFreezeEnabled = false;
    private volatile boolean activityAlive = true;

    private static final String[] VALUE_TYPES = {"Byte", "Short", "Int", "Long", "Float", "Double", "String", "Bytes"};
    private static final String[] VALUE_SIZES = {"1", "2", "4", "8"};
    private static final String[] SEARCH_TYPES = {"Exact", "Range", "Increased", "Decreased", "Changed", "Unchanged", "String", "Bytes", "Fuzzy"};
    private static final String[] SPEED_PRESETS = {"0.1x", "0.25x", "0.5x", "1x (Normal)", "2x", "3x", "5x", "10x"};
    private static final String[] GAME_CATEGORIES = {"RPG", "FPS", "Strategy", "Puzzle", "Racing", "Arcade", "Card", "Simulation", "MMO"};

    private Map<String, List<String>> gameHacks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;
        appContext = getApplicationContext();
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("BugorPrefs", MODE_PRIVATE);
        handler = new Handler(Looper.getMainLooper());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                requestOverlayPermission();
            }
        }

        bridge = BugorBridge.getInstance(this);

        setupViews();
        setupSurfaceView();
        setupGameHacks();
        setupListeners();
        loadSavedState();
        startEngine();
    }

    private void setupViews() {
        mainContainer = findViewById(R.id.mainContainer);
        statusText = findViewById(R.id.statusText);
        logText = findViewById(R.id.logText);
        if (logText != null) logText.setMovementMethod(new ScrollingMovementMethod());
        addressInput = findViewById(R.id.addressInput);
        valueInput = findViewById(R.id.valueInput);
        scriptInput = findViewById(R.id.scriptInput);
        searchValueInput = findViewById(R.id.searchValueInput);
        moduleNameInput = findViewById(R.id.moduleNameInput);
        valueTypeSpinner = findViewById(R.id.valueTypeSpinner);
        valueSizeSpinner = findViewById(R.id.valueSizeSpinner);
        searchTypeSpinner = findViewById(R.id.searchTypeSpinner);
        progressBar = findViewById(R.id.progressBar);
        freezeSwitch = findViewById(R.id.freezeSwitch);
        hookSwitch = findViewById(R.id.hookSwitch);
        remoteSwitch = findViewById(R.id.remoteSwitch);
        resultsListView = findViewById(R.id.resultsListView);
        regionsListView = findViewById(R.id.regionsListView);
        logScrollView = findViewById(R.id.logScrollView);
        frozenValuesLayout = findViewById(R.id.frozenValuesLayout);
        tabHost = findViewById(R.id.tabHost);

        attachButton = findViewById(R.id.attachButton);
        readButton = findViewById(R.id.readButton);
        writeButton = findViewById(R.id.writeButton);
        searchButton = findViewById(R.id.searchButton);
        freezeButton = findViewById(R.id.freezeButton);
        unfreezeButton = findViewById(R.id.unfreezeButton);
        regionsButton = findViewById(R.id.regionsButton);
        executeButton = findViewById(R.id.executeButton);
        loadScriptButton = findViewById(R.id.loadScriptButton);
        hookButton = findViewById(R.id.hookButton);
        dumpButton = findViewById(R.id.dumpButton);
        clearLogButton = findViewById(R.id.clearLogButton);
        speedHackButton = findViewById(R.id.speedHackButton);
        godModeButton = findViewById(R.id.godModeButton);
        currencyButton = findViewById(R.id.currencyButton);
        xpButton = findViewById(R.id.xpButton);
        unlimitedAmmoButton = findViewById(R.id.unlimitedAmmoButton);
        noCooldownButton = findViewById(R.id.noCooldownButton);
        instantKillButton = findViewById(R.id.instantKillButton);
        damageMultiplierButton = findViewById(R.id.damageMultiplierButton);
        unlockAllButton = findViewById(R.id.unlockAllButton);
        antiBanButton = findViewById(R.id.antiBanButton);
        bypassButton = findViewById(R.id.bypassButton);
        settingsButton = findViewById(R.id.settingsButton);
        aboutButton = findViewById(R.id.aboutButton);
        remoteConnectButton = findViewById(R.id.remoteConnectButton);
        remoteDisconnectButton = findViewById(R.id.remoteDisconnectButton);
        encryptButton = findViewById(R.id.encryptButton);
        decryptButton = findViewById(R.id.decryptButton);
        hashButton = findViewById(R.id.hashButton);
        saveStateButton = findViewById(R.id.saveStateButton);
        loadStateButton = findViewById(R.id.loadStateButton);

        if (valueTypeSpinner != null) {
            ArrayAdapter<String> typeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, VALUE_TYPES);
            typeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            valueTypeSpinner.setAdapter(typeAdapter);
        }

        if (valueSizeSpinner != null) {
            ArrayAdapter<String> sizeAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, VALUE_SIZES);
            sizeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            valueSizeSpinner.setAdapter(sizeAdapter);
        }

        if (searchTypeSpinner != null) {
            ArrayAdapter<String> searchAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, SEARCH_TYPES);
            searchAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            searchTypeSpinner.setAdapter(searchAdapter);
        }

        resultsList = new ArrayList<>();
        regionsList = new ArrayList<>();
        resultsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, resultsList);
        regionsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, regionsList);
        if (resultsListView != null) resultsListView.setAdapter(resultsAdapter);
        if (regionsListView != null) regionsListView.setAdapter(regionsAdapter);

        if (tabHost != null) {
            tabHost.setup();
            tabHost.addTab(tabHost.newTabSpec("memory").setIndicator("Memory").setContent(R.id.tabMemory));
            tabHost.addTab(tabHost.newTabSpec("search").setIndicator("Search").setContent(R.id.tabSearch));
            tabHost.addTab(tabHost.newTabSpec("hacks").setIndicator("Hacks").setContent(R.id.tabHacks));
            tabHost.addTab(tabHost.newTabSpec("scripts").setIndicator("Scripts").setContent(R.id.tabScripts));
            tabHost.addTab(tabHost.newTabSpec("network").setIndicator("Network").setContent(R.id.tabNetwork));
            tabHost.addTab(tabHost.newTabSpec("settings").setIndicator("Settings").setContent(R.id.tabSettings));
            tabHost.addTab(tabHost.newTabSpec("tools").setIndicator("Tools").setContent(R.id.tabTools));
            tabHost.addTab(tabHost.newTabSpec("log").setIndicator("Log").setContent(R.id.tabLog));
        }

        setupSpeedHackMenu();
    }

    private void setupSurfaceView() {
        surfaceView = findViewById(R.id.surface_view);
        if (surfaceView == null) return;
        surfaceView.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                nativeSurface = holder.getSurface();
                NativeBridge.onSurfaceCreated(nativeSurface);
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                NativeBridge.onSurfaceDestroyed();
            }
        });
    }

    private void startEngine() {
        NativeBridge.initEngine();
        bridge.initialize(() -> {
            handler.post(() -> {
                updateStatus("Engine Ready v" + bridge.getVersion(), Color.GREEN);
                addLog("Bugor Engine initialized successfully");
                addLog("Version: " + bridge.getVersion());
                addLog("Build: " + bridge.getBuildInfo());
            });
        });
    }

    private void setupSpeedHackMenu() {
        if (speedHackButton != null) {
            speedHackButton.setOnClickListener(v -> {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Speed Hack");
                builder.setItems(SPEED_PRESETS, (dialog, which) -> {
                    String speed = SPEED_PRESETS[which];
                    float multiplier = 1.0f;
                    if (speed.contains("0.1")) multiplier = 0.1f;
                    else if (speed.contains("0.25")) multiplier = 0.25f;
                    else if (speed.contains("0.5")) multiplier = 0.5f;
                    else if (speed.contains("2")) multiplier = 2.0f;
                    else if (speed.contains("3")) multiplier = 3.0f;
                    else if (speed.contains("5")) multiplier = 5.0f;
                    else if (speed.contains("10")) multiplier = 10.0f;
                    applySpeedHack(multiplier);
                    addLog("Speed set to: " + multiplier + "x");
                });
                builder.show();
            });
        }
    }

    private void setupGameHacks() {
        gameHacks = new HashMap<>();

        gameHacks.put("RPG", Arrays.asList(
            "Gold/Currency x9999", "Max Level (99)", "Infinite HP/MP",
            "Max Stats (STR/DEX/INT)", "All Skills Unlocked", "Unlimited Skill Points",
            "God Mode (Invincible)", "One Hit Kill", "Damage Multiplier x10",
            "Infinite Stamina", "No Cooldown Skills", "Free Shopping",
            "Max Equipment Slots", "All Items Unlocked", "Legendary Drop Rate 100%",
            "Unlimited Mana", "Regen HP/MP Fast", "EXP Multiplier x10",
            "No Level Requirements", "Pet Max Level", "Crafting Instant", "No Durability Loss"
        ));
        gameHacks.put("FPS", Arrays.asList(
            "Wallhack (See Through Walls)", "Aimbot (Auto-Headshot)", "No Recoil/Spray",
            "Infinite Ammo", "No Reload", "Rapid Fire", "Instant Kill", "God Mode",
            "Speed Hack x5", "No Spread", "Triggerbot", "ESP (Enemy Location)",
            "Radar Hack", "No Fall Damage", "Infinite Grenades", "No Weapon Switch Delay",
            "X-Ray Vision", "Auto-Aim", "Anti-Ban Shield", "Unlock All Weapons",
            "All Attachments Unlocked", "Unlimited Tactical Equipment"
        ));
        gameHacks.put("Strategy", Arrays.asList(
            "Unlimited Resources", "Instant Build", "Max Troops", "Infinite Mana/Energy",
            "Research Instant", "All Units Unlocked", "No Upgrade Wait", "Max Base Level",
            "Unlimited Gems/Gold", "Speed Multiplier x5", "Fog of War Removed",
            "Full Map Reveal", "AI Disabled", "Perfect Matchmaking", "Auto-Win Battles",
            "Unlimited Turns", "All Cards Unlocked", "Max Card Level", "Infinite Lives", "No Energy Cost"
        ));
        gameHacks.put("Puzzle", Arrays.asList(
            "Unlimited Moves", "Unlimited Time", "Auto-Solve Puzzle", "All Levels Unlocked",
            "Unlimited Boosters", "Infinite Lives", "Score Multiplier x10", "No Timer",
            "Perfect Match", "Unlimited Hints", "All Power-Ups Maxed", "Skip Level",
            "No Locked Content", "Max Stars All Levels", "Unlimited Coins/Gems", "Free Shopping", "No Ads"
        ));
        gameHacks.put("Racing", Arrays.asList(
            "Unlimited Nitro/Boost", "Max Speed", "No Collision", "Perfect Drift",
            "All Cars Unlocked", "Max Upgrades", "Infinite Fuel", "Auto-Win Race",
            "No Damage", "Gold Medals All", "Unlimited Currency", "All Tracks Unlocked",
            "Perfect Grip", "No Obstacles", "Max Stats All Cars", "Unlimited Keys/Tickets"
        ));
        gameHacks.put("Arcade", Arrays.asList(
            "Infinite Lives", "Score Multiplier x100", "God Mode", "All Characters Unlocked",
            "Max Power-Ups", "Unlimited Coins", "No Cooldown", "Speed Hack x3",
            "Auto-Play Perfect", "Invincibility", "All Levels Unlocked", "Unlimited Continues",
            "No Ads", "Free Shopping", "Max Upgrades"
        ));
        gameHacks.put("Card", Arrays.asList(
            "All Cards Unlocked", "Max Card Level", "Unlimited Gems/Gold", "Auto-Win Battles",
            "Infinite Energy", "No Card Cost", "Perfect Draw", "Max Arena/Trophy",
            "All Decks Unlocked", "Unlimited Chests", "No Wait Timer", "Undefeated Streak",
            "Legendary Cards All", "Unlimited Keys", "Max Player Level"
        ));
        gameHacks.put("Simulation", Arrays.asList(
            "Unlimited Money/Gold", "Max All Stats", "Instant Actions", "All Items/Clothes Unlocked",
            "No Energy/Stamina", "Max Relationship", "Unlimited Premium Currency",
            "All Areas Unlocked", "No Wait Timers", "Speed Hack x3", "Perfect Happiness",
            "Unlimited Inventory", "All Achievements", "Max Character Level", "Free Shopping"
        ));
        gameHacks.put("MMO", Arrays.asList(
            "EXP Multiplier x100", "Auto-Farm", "Fly Hack", "No Clip (Walk Through Walls)",
            "Speed Hack", "Unlimited HP/MP", "Max Stats", "All Skills Unlocked",
            "Teleport Anywhere", "Item Duplication", "Gold/Currency Hack", "God Mode",
            "Instant Kill", "No Cooldown", "Unlimited Stamina", "Anti-Detection",
            "Auto-Loot", "Max Level Instant", "All Mounts/Pets", "Perfect Equipment",
            "Infinite Inventory", "Trade Hack", "Guild Max Level"
        ));
    }

    private void setupListeners() {
        if (attachButton != null) attachButton.setOnClickListener(v -> showProcessSelector());
        if (readButton != null) readButton.setOnClickListener(v -> readMemory());
        if (writeButton != null) writeButton.setOnClickListener(v -> writeMemory());
        if (searchButton != null) searchButton.setOnClickListener(v -> searchMemory());
        if (freezeButton != null) freezeButton.setOnClickListener(v -> freezeValue());
        if (unfreezeButton != null) unfreezeButton.setOnClickListener(v -> unfreezeValue());
        if (regionsButton != null) regionsButton.setOnClickListener(v -> showMemoryRegions());
        if (executeButton != null) executeButton.setOnClickListener(v -> executeScript());
        if (loadScriptButton != null) loadScriptButton.setOnClickListener(v -> loadScriptFile());
        if (hookButton != null) hookButton.setOnClickListener(v -> installHook());
        if (dumpButton != null) dumpButton.setOnClickListener(v -> dumpMemory());
        if (clearLogButton != null) clearLogButton.setOnClickListener(v -> clearLog());

        if (godModeButton != null) godModeButton.setOnClickListener(v -> toggleGodMode());
        if (currencyButton != null) currencyButton.setOnClickListener(v -> hackCurrency());
        if (xpButton != null) xpButton.setOnClickListener(v -> hackXP());
        if (unlimitedAmmoButton != null) unlimitedAmmoButton.setOnClickListener(v -> hackUnlimitedAmmo());
        if (noCooldownButton != null) noCooldownButton.setOnClickListener(v -> hackNoCooldown());
        if (instantKillButton != null) instantKillButton.setOnClickListener(v -> hackInstantKill());
        if (damageMultiplierButton != null) damageMultiplierButton.setOnClickListener(v -> showDamageMultiplier());
        if (unlockAllButton != null) unlockAllButton.setOnClickListener(v -> unlockAll());
        if (antiBanButton != null) antiBanButton.setOnClickListener(v -> toggleAntiBan());
        if (bypassButton != null) bypassButton.setOnClickListener(v -> toggleBypass());

        if (settingsButton != null) settingsButton.setOnClickListener(v -> showSettings());
        if (aboutButton != null) aboutButton.setOnClickListener(v -> showAbout());
        if (remoteConnectButton != null) remoteConnectButton.setOnClickListener(v -> connectRemote());
        if (remoteDisconnectButton != null) remoteDisconnectButton.setOnClickListener(v -> disconnectRemote());
        if (encryptButton != null) encryptButton.setOnClickListener(v -> showEncryptDialog());
        if (decryptButton != null) decryptButton.setOnClickListener(v -> showDecryptDialog());
        if (hashButton != null) hashButton.setOnClickListener(v -> showHashDialog());
        if (saveStateButton != null) saveStateButton.setOnClickListener(v -> saveState());
        if (loadStateButton != null) loadStateButton.setOnClickListener(v -> loadState());

        if (freezeSwitch != null) {
            freezeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
                autoFreezeEnabled = isChecked;
                if (isChecked) {
                    addLog("Auto-freeze enabled");
                    startFrozenLoop();
                } else {
                    addLog("Auto-freeze disabled");
                }
            });
        }

        if (hookSwitch != null) {
            hookSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
                addLog(isChecked ? "Hooking enabled" : "Hooking disabled");
            });
        }

        if (remoteSwitch != null) {
            remoteSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked && bridge != null) {
                    connectRemote();
                } else if (bridge != null) {
                    bridge.disconnectRemote();
                }
            });
        }

        if (resultsListView != null) {
            resultsListView.setOnItemClickListener((parent, view, position, id) -> {
                String item = resultsList.get(position);
                try {
                    long addr = Long.parseLong(item.split(" ")[0].replace("0x", ""), 16);
                    addressInput.setText("0x" + Long.toHexString(addr));
                    addLog("Selected address: 0x" + Long.toHexString(addr));
                } catch (Exception e) {
                    addLog("Failed to parse address from: " + item);
                }
            });
        }

        if (regionsListView != null) {
            regionsListView.setOnItemClickListener((parent, view, position, id) -> {
                String item = regionsList.get(position);
                try {
                    String[] parts = item.split(" ");
                    if (parts.length >= 2) {
                        long startAddr = Long.parseLong(parts[0].replace("0x", ""), 16);
                        addressInput.setText("0x" + Long.toHexString(startAddr));
                        addLog("Selected region start: 0x" + Long.toHexString(startAddr));
                    }
                } catch (Exception e) {
                    addLog("Failed to parse region");
                }
            });
        }

        if (valueTypeSpinner != null) {
            valueTypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    currentValueType = position;
                    if (position >= 4 && valueSizeSpinner != null) valueSizeSpinner.setSelection(2);
                }
                @Override
                public void onNothingSelected(AdapterView<?> parent) {}
            });
        }

        if (valueSizeSpinner != null) {
            valueSizeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    currentValueSize = Integer.parseInt(VALUE_SIZES[position]);
                }
                @Override
                public void onNothingSelected(AdapterView<?> parent) {}
            });
        }
    }

    private void showProcessSelector() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select Process");
        List<String> processList = getProcessList();
        String[] processes = processList.toArray(new String[0]);
        builder.setItems(processes, (dialog, which) -> {
            String selected = processes[which];
            targetProcess = selected.split(" ")[0];
            attachToProcess(targetProcess);
        });
        builder.setNeutralButton("Refresh", (dialog, which) -> showProcessSelector());
        builder.show();
    }

    private List<String> getProcessList() {
        List<String> processes = new ArrayList<>();
        try {
            Process proc = Runtime.getRuntime().exec("ps -A -o pid,NAME");
            BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream()));
            String line;
            reader.readLine();
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) {
                    String[] parts = line.split("\\s+");
                    if (parts.length >= 2 && !parts[1].contains("bugor") && !parts[1].contains("com.android")) {
                        processes.add(parts[0] + " " + parts[1]);
                    }
                }
            }
            reader.close();
        } catch (Exception e) {
            addLog("Error listing processes: " + e.getMessage());
            processes.add("self (current app)");
        }
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream("/proc/self/maps")));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains("/data/app/")) {
                    String pkg = line.substring(line.lastIndexOf("/") + 1);
                    if (!pkg.contains("bugor") && !processes.contains(pkg)) {
                        processes.add(pkg);
                    }
                }
            }
            reader.close();
        } catch (Exception ignored) {}
        return processes;
    }

    private void attachToProcess(String process) {
        showProgress(true);
        new Thread(() -> {
            try {
                int pid = -1;
                try {
                    pid = Integer.parseInt(process);
                } catch (NumberFormatException e) {
                    Process proc = Runtime.getRuntime().exec("pidof " + process);
                    BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream()));
                    String line = reader.readLine();
                    if (line != null) pid = Integer.parseInt(line.trim());
                    reader.close();
                }
                if (pid > 0) {
                    attached = bridge.attachDebugger(pid);
                    final int fPid = pid;
                    handler.post(() -> {
                        if (attached) {
                            updateStatus("Attached to PID: " + fPid + " (" + process + ")", Color.GREEN);
                            addLog("Successfully attached to process: " + process + " (PID: " + fPid + ")");
                            attachButton.setText("Attached: " + process.substring(0, Math.min(process.length(), 20)));
                        } else {
                            updateStatus("Failed to attach to " + process, Color.RED);
                            addLog("Failed to attach to process: " + process);
                        }
                        showProgress(false);
                    });
                } else {
                    handler.post(() -> {
                        updateStatus("Process not found: " + process, Color.RED);
                        addLog("Process not found: " + process);
                        showProgress(false);
                    });
                }
            } catch (Exception e) {
                handler.post(() -> {
                    updateStatus("Error attaching: " + e.getMessage(), Color.RED);
                    addLog("Error attaching: " + e.getMessage());
                    showProgress(false);
                });
            }
        }).start();
    }

    private void readMemory() {
        if (!validateAddress()) return;
        showProgress(true);
        new Thread(() -> {
            try {
                long addr = currentAddress;
                Object value = null;
                String valueStr = "";
                switch (currentValueType) {
                    case 0: value = bridge.readInt(addr) & 0xFF; valueStr = String.valueOf(value); break;
                    case 1: value = bridge.readInt(addr) & 0xFFFF; valueStr = String.valueOf(value); break;
                    case 2: value = bridge.readInt(addr); valueStr = String.valueOf(value); break;
                    case 3: value = bridge.readLong(addr); valueStr = String.valueOf(value); break;
                    case 4: value = bridge.readFloat(addr); valueStr = String.format("%.6f", value); break;
                    case 5: value = bridge.readDouble(addr); valueStr = String.format("%.6f", value); break;
                }
                String hex = bridge.nativeDumpMemory(addr, 64);
                final String finalValue = valueStr;
                final String finalHex = hex;
                handler.post(() -> {
                    addLog("Memory Read @ 0x" + Long.toHexString(addr));
                    addLog("Value: " + finalValue);
                    addLog("Hex dump:");
                    addLog(finalHex);
                    updateStatus("Read @ " + Long.toHexString(addr) + " = " + finalValue, Color.CYAN);
                    showProgress(false);
                });
            } catch (Exception e) {
                handler.post(() -> {
                    addLog("Read error: " + e.getMessage());
                    showProgress(false);
                });
            }
        }).start();
    }

    private void writeMemory() {
        if (!validateAddress()) return;
        String valueStr = valueInput.getText().toString();
        if (valueStr.isEmpty()) {
            showToast("Enter a value to write");
            return;
        }
        showProgress(true);
        new Thread(() -> {
            try {
                long addr = currentAddress;
                boolean success = false;
                switch (currentValueType) {
                    case 0: success = bridge.writeLong(addr, Long.parseLong(valueStr) & 0xFF); break;
                    case 1: success = bridge.writeInt(addr, (int)(Long.parseLong(valueStr) & 0xFFFF)); break;
                    case 2: success = bridge.writeInt(addr, Integer.parseInt(valueStr)); break;
                    case 3: success = bridge.writeLong(addr, Long.parseLong(valueStr)); break;
                    case 4: success = bridge.writeFloat(addr, Float.parseFloat(valueStr)); break;
                    case 5: success = bridge.writeDouble(addr, Double.parseDouble(valueStr)); break;
                }
                final boolean finalSuccess = success;
                handler.post(() -> {
                    if (finalSuccess) {
                        addLog("Written " + valueStr + " @ 0x" + Long.toHexString(addr));
                        updateStatus("Written OK", Color.GREEN);
                    } else {
                        addLog("Write failed @ 0x" + Long.toHexString(addr));
                        updateStatus("Write FAILED", Color.RED);
                    }
                    showProgress(false);
                });
            } catch (Exception e) {
                handler.post(() -> {
                    addLog("Write error: " + e.getMessage());
                    showProgress(false);
                });
            }
        }).start();
    }

    private void searchMemory() {
        String searchValue = searchValueInput.getText().toString();
        if (searchValue.isEmpty()) {
            showToast("Enter search value");
            return;
        }
        showProgress(true);
        resultsList.clear();
        new Thread(() -> {
            try {
                int searchType = searchTypeSpinner.getSelectedItemPosition();
                long value = 0;
                int valueType = currentValueType;
                int valueSize = currentValueSize;
                try {
                    if (searchType < 6) {
                        value = Long.parseLong(searchValue);
                    }
                } catch (NumberFormatException e1) {
                    try {
                        value = (long) Float.parseFloat(searchValue);
                    } catch (NumberFormatException e2) {
                        handler.post(() -> {
                            addLog("Invalid search value format");
                            showProgress(false);
                        });
                        return;
                    }
                }
                long regionStart = 0;
                long regionEnd = 0x7FFFFFFF;
                String results = bridge.nativeSearchMemory(valueType, value, valueSize, regionStart, regionEnd);
                List<Map<String, Object>> parsed = parseResults(results);
                handler.post(() -> {
                    resultsList.clear();
                    for (Map<String, Object> result : parsed) {
                        long addr = (Long) result.get("address");
                        Object val = result.get("value");
                        resultsList.add("0x" + Long.toHexString(addr) + " = " + val);
                    }
                    resultsAdapter.notifyDataSetChanged();
                    addLog("Found " + parsed.size() + " results");
                    updateStatus("Found " + parsed.size() + " matches", Color.YELLOW);
                    showProgress(false);
                    if (parsed.size() > 0 && parsed.size() < 50) {
                        showToast("Found " + parsed.size() + " matches");
                    }
                });
            } catch (Exception e) {
                handler.post(() -> {
                    addLog("Search error: " + e.getMessage());
                    showProgress(false);
                });
            }
        }).start();
    }

    private void freezeValue() {
        if (!validateAddress()) return;
        String valStr = valueInput.getText().toString();
        long val = 0;
        try { val = Long.parseLong(valStr); } catch (NumberFormatException ignored) {}
        if (!bridge.nativeFreezeValue(currentAddress, val, currentValueType)) {
            addLog("Freeze failed @ 0x" + Long.toHexString(currentAddress));
            return;
        }
        frozenAddresses.put(currentAddress, valStr);
        addLog("Value frozen @ 0x" + Long.toHexString(currentAddress) + " = " + valStr);
        updateStatus("Frozen @ " + Long.toHexString(currentAddress), Color.MAGENTA);
        updateFrozenValuesUI();
    }

    private void unfreezeValue() {
        if (!validateAddress()) return;
        bridge.unfreezeValue(currentAddress);
        frozenAddresses.remove(currentAddress);
        addLog("Unfrozen @ 0x" + Long.toHexString(currentAddress));
        updateFrozenValuesUI();
    }

    private void showMemoryRegions() {
        showProgress(true);
        regionsList.clear();
        new Thread(() -> {
            try {
                String results = bridge.nativeGetRegions();
                List<Map<String, Object>> regions = parseResults(results);
                handler.post(() -> {
                    regionsList.clear();
                    int writableCount = 0;
                    int executableCount = 0;
                    for (Map<String, Object> region : regions) {
                        long start = (Long) region.get("start");
                        long end = (Long) region.get("end");
                        long size = (Long) region.get("size");
                        boolean writable = (Boolean) region.get("writable");
                        boolean executable = (Boolean) region.get("executable");
                        String path = (String) region.get("path");
                        StringBuilder sb = new StringBuilder();
                        sb.append("0x").append(Long.toHexString(start)).append("-0x").append(Long.toHexString(end));
                        sb.append(" [").append(writable ? "W" : "-").append(executable ? "X" : "-").append("]");
                        if (!path.isEmpty()) sb.append(" ").append(path);
                        regionsList.add(sb.toString());
                        if (writable) writableCount++;
                        if (executable) executableCount++;
                    }
                    regionsAdapter.notifyDataSetChanged();
                    addLog("Memory regions: " + regions.size() + " total (" + writableCount + " writable, " + executableCount + " executable)");
                    updateStatus(regions.size() + " regions loaded", Color.CYAN);
                    showProgress(false);
                });
            } catch (Exception e) {
                handler.post(() -> {
                    addLog("Region error: " + e.getMessage());
                    showProgress(false);
                });
            }
        }).start();
    }

    private void executeScript() {
        String script = scriptInput.getText().toString();
        if (script.isEmpty()) {
            showToast("Enter a script");
            return;
        }
        showProgress(true);
        new Thread(() -> {
            try {
                bridge.executeScript(script);
                handler.post(() -> {
                    addLog("Script executed");
                    updateStatus("Script OK", Color.GREEN);
                    showProgress(false);
                });
            } catch (Exception e) {
                handler.post(() -> {
                    addLog("Script error: " + e.getMessage());
                    showProgress(false);
                });
            }
        }).start();
    }

    private void loadScriptFile() {
        String moduleName = moduleNameInput.getText().toString();
        if (moduleName.isEmpty()) {
            showToast("Enter module name or path");
            return;
        }
        showProgress(true);
        new Thread(() -> {
            try {
                String path = moduleName;
                if (!path.startsWith("/")) {
                    path = getFilesDir() + "/scripts/" + path;
                }
                boolean result = bridge.nativeLoadScriptFile(path);
                final String fPath = path;
                handler.post(() -> {
                    if (result) {
                        addLog("Script loaded: " + fPath);
                        updateStatus("Loaded: " + fPath, Color.GREEN);
                    } else {
                        addLog("Failed to load: " + fPath);
                        updateStatus("Load failed", Color.RED);
                    }
                    showProgress(false);
                });
            } catch (Exception e) {
                handler.post(() -> {
                    addLog("Load error: " + e.getMessage());
                    showProgress(false);
                });
            }
        }).start();
    }

    private void installHook() {
        if (!validateAddress()) return;
        showProgress(true);
        new Thread(() -> {
            try {
                int hookId = bridge.nativeInstallHook(currentAddress, 0);
                handler.post(() -> {
                    if (hookId >= 0) {
                        addLog("Hook installed @ 0x" + Long.toHexString(currentAddress) + " ID: " + hookId);
                        updateStatus("Hook installed: " + hookId, Color.GREEN);
                    } else {
                        addLog("Hook install failed");
                        updateStatus("Hook failed", Color.RED);
                    }
                    showProgress(false);
                });
            } catch (Exception e) {
                handler.post(() -> {
                    addLog("Hook error: " + e.getMessage());
                    showProgress(false);
                });
            }
        }).start();
    }

    private void dumpMemory() {
        if (!validateAddress()) return;
        showProgress(true);
        new Thread(() -> {
            try {
                String hex = bridge.nativeDumpMemory(currentAddress, 256);
                String fileName = "dump_0x" + Long.toHexString(currentAddress) + ".txt";
                File file = new File(getExternalFilesDir(null), fileName);
                FileOutputStream fos = new FileOutputStream(file);
                fos.write(hex.getBytes());
                fos.close();
                handler.post(() -> {
                    addLog("Memory dumped to: " + file.getAbsolutePath());
                    updateStatus("Dumped to " + fileName, Color.GREEN);
                    showProgress(false);
                });
            } catch (Exception e) {
                handler.post(() -> {
                    addLog("Dump error: " + e.getMessage());
                    showProgress(false);
                });
            }
        }).start();
    }

    private void toggleGodMode() {
        showProgress(true);
        new Thread(() -> {
            try {
                bridge.executeScript("toggle_god_mode()");
                handler.post(() -> { addLog("God Mode toggled"); updateStatus("God Mode", Color.GREEN); showProgress(false); });
            } catch (Exception e) { handler.post(() -> { addLog("God Mode error: " + e.getMessage()); showProgress(false); }); }
        }).start();
    }

    private void hackCurrency() {
        showEditDialog("Currency Hack", "Enter amount:", "999999", value -> {
            showProgress(true);
            new Thread(() -> {
                try { bridge.executeScript("hack_currency(" + value + ")"); handler.post(() -> { addLog("Currency hacked to: " + value); updateStatus("Currency: " + value, Color.GREEN); showProgress(false); }); }
                catch (Exception e) { handler.post(() -> { addLog("Currency hack error: " + e.getMessage()); showProgress(false); }); }
            }).start();
        });
    }

    private void hackXP() {
        showEditDialog("XP Hack", "Enter XP amount:", "999999", value -> {
            showProgress(true);
            new Thread(() -> {
                try { bridge.executeScript("hack_xp(" + value + ")"); handler.post(() -> { addLog("XP hacked to: " + value); updateStatus("XP: " + value, Color.GREEN); showProgress(false); }); }
                catch (Exception e) { handler.post(() -> { addLog("XP hack error: " + e.getMessage()); showProgress(false); }); }
            }).start();
        });
    }

    private void hackUnlimitedAmmo() {
        showProgress(true);
        new Thread(() -> {
            try { bridge.executeScript("unlimited_ammo()"); handler.post(() -> { addLog("Unlimited Ammo enabled"); updateStatus("Unlimited Ammo", Color.GREEN); showProgress(false); }); }
            catch (Exception e) { handler.post(() -> { addLog("Ammo hack error: " + e.getMessage()); showProgress(false); }); }
        }).start();
    }

    private void hackNoCooldown() {
        showProgress(true);
        new Thread(() -> {
            try { bridge.executeScript("no_cooldown()"); handler.post(() -> { addLog("No Cooldown enabled"); updateStatus("No Cooldown", Color.GREEN); showProgress(false); }); }
            catch (Exception e) { handler.post(() -> { addLog("No cooldown error: " + e.getMessage()); showProgress(false); }); }
        }).start();
    }

    private void hackInstantKill() {
        showProgress(true);
        new Thread(() -> {
            try { bridge.executeScript("instant_kill()"); handler.post(() -> { addLog("Instant Kill enabled"); updateStatus("Instant Kill", Color.GREEN); showProgress(false); }); }
            catch (Exception e) { handler.post(() -> { addLog("Instant kill error: " + e.getMessage()); showProgress(false); }); }
        }).start();
    }

    private void showDamageMultiplier() {
        showEditDialog("Damage Multiplier", "Enter multiplier:", "10", value -> {
            showProgress(true);
            new Thread(() -> {
                try { bridge.executeScript("damage_multiplier(" + value + ")"); handler.post(() -> { addLog("Damage Multiplier set to: " + value + "x"); updateStatus("Damage x" + value, Color.GREEN); showProgress(false); }); }
                catch (Exception e) { handler.post(() -> { addLog("Damage multiplier error: " + e.getMessage()); showProgress(false); }); }
            }).start();
        });
    }

    private void unlockAll() {
        showProgress(true);
        new Thread(() -> {
            try { bridge.executeScript("unlock_all()"); handler.post(() -> { addLog("All content unlocked"); updateStatus("All Unlocked", Color.GREEN); showProgress(false); }); }
            catch (Exception e) { handler.post(() -> { addLog("Unlock error: " + e.getMessage()); showProgress(false); }); }
        }).start();
    }

    private void toggleAntiBan() {
        showProgress(true);
        new Thread(() -> {
            try { bridge.executeScript("anti_ban()"); handler.post(() -> { addLog("Anti-Ban shield toggled"); updateStatus("Anti-Ban Active", Color.GREEN); showProgress(false); }); }
            catch (Exception e) { handler.post(() -> { addLog("Anti-Ban error: " + e.getMessage()); showProgress(false); }); }
        }).start();
    }

    private void toggleBypass() {
        showProgress(true);
        new Thread(() -> {
            try { bridge.executeScript("security_bypass()"); handler.post(() -> { addLog("Security Bypass enabled"); updateStatus("Bypass Active", Color.GREEN); showProgress(false); }); }
            catch (Exception e) { handler.post(() -> { addLog("Bypass error: " + e.getMessage()); showProgress(false); }); }
        }).start();
    }

    private void applySpeedHack(float multiplier) {
        showProgress(true);
        new Thread(() -> {
            try { bridge.executeScript("speed_hack(" + multiplier + ")"); handler.post(() -> { addLog("Speed hack applied: " + multiplier + "x"); updateStatus("Speed: " + multiplier + "x", Color.GREEN); showProgress(false); }); }
            catch (Exception e) { handler.post(() -> { addLog("Speed hack error: " + e.getMessage()); showProgress(false); }); }
        }).start();
    }

    private void connectRemote() {
        showEditDialog("Remote Connection", "Server (host:port):", "192.168.1.100:8080", value -> {
            String[] parts = value.split(":");
            if (parts.length == 2) {
                showProgress(true);
                new Thread(() -> {
                    try {
                        boolean result = bridge.connectRemote(parts[0], Integer.parseInt(parts[1]), "bugor_key_2024");
                        handler.post(() -> {
                            if (result) {
                                addLog("Connected to remote server: " + value);
                                updateStatus("Remote: Connected", Color.GREEN);
                                if (remoteSwitch != null) remoteSwitch.setChecked(true);
                            } else {
                                addLog("Remote connection failed");
                                updateStatus("Remote: Failed", Color.RED);
                            }
                            showProgress(false);
                        });
                    } catch (Exception e) {
                        handler.post(() -> { addLog("Remote error: " + e.getMessage()); showProgress(false); });
                    }
                }).start();
            } else {
                showToast("Invalid format. Use host:port");
            }
        });
    }

    private void disconnectRemote() {
        new Thread(() -> {
            bridge.disconnectRemote();
            handler.post(() -> {
                addLog("Disconnected from remote server");
                updateStatus("Remote: Disconnected", Color.YELLOW);
                if (remoteSwitch != null) remoteSwitch.setChecked(false);
            });
        }).start();
    }

    private void showEncryptDialog() {
        showEditDialog("Encrypt", "Enter text to encrypt:", "", value -> {
            showEditDialog("Encryption Key", "Enter encryption key:", "bugor_secret_key", key -> {
                String encrypted = bridge.encrypt(value, key);
                addLog("Encrypted: " + encrypted);
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                clipboard.setPrimaryClip(ClipData.newPlainText("encrypted", encrypted));
                showToast("Encrypted text copied to clipboard");
            });
        });
    }

    private void showDecryptDialog() {
        showEditDialog("Decrypt", "Enter text to decrypt:", "", value -> {
            showEditDialog("Decryption Key", "Enter decryption key:", "bugor_secret_key", key -> {
                String decrypted = bridge.decrypt(value, key);
                addLog("Decrypted: " + decrypted);
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                clipboard.setPrimaryClip(ClipData.newPlainText("decrypted", decrypted));
                showToast("Decrypted text copied to clipboard");
            });
        });
    }

    private void showHashDialog() {
        showEditDialog("Hash", "Enter text to hash:", "", value -> {
            String hash = bridge.hash(value);
            addLog("Hash: " + hash);
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("hash", hash));
            showToast("Hash copied to clipboard");
        });
    }

    private void saveState() {
        showProgress(true);
        new Thread(() -> {
            try {
                String state = bridge.nativeGetMetrics();
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("saved_state", state);
                StringBuilder addrBuilder = new StringBuilder();
                boolean first = true;
                for (Long addr : frozenAddresses.keySet()) {
                    if (!first) addrBuilder.append(",");
                    addrBuilder.append("0x").append(Long.toHexString(addr));
                    first = false;
                }
                editor.putString("frozen_addresses", addrBuilder.toString());
                editor.apply();
                handler.post(() -> { addLog("State saved"); updateStatus("State Saved", Color.GREEN); showProgress(false); });
            } catch (Exception e) { handler.post(() -> { addLog("Save error: " + e.getMessage()); showProgress(false); }); }
        }).start();
    }

    private void loadState() {
        showProgress(true);
        new Thread(() -> {
            try {
                String state = prefs.getString("saved_state", "");
                String addrs = prefs.getString("frozen_addresses", "");
                handler.post(() -> {
                    if (!state.isEmpty()) { addLog("State restored"); updateStatus("State Loaded", Color.GREEN); }
                    else { addLog("No saved state found"); }
                    showProgress(false);
                });
            } catch (Exception e) { handler.post(() -> { addLog("Load error: " + e.getMessage()); showProgress(false); }); }
        }).start();
    }

    private void showSettings() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Bugor Engine Settings");
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 20, 50, 20);

        final CheckBox autoAttach = new CheckBox(this);
        autoAttach.setText("Auto-attach to last process");
        autoAttach.setChecked(prefs.getBoolean("auto_attach", false));
        layout.addView(autoAttach);

        final CheckBox rootMode = new CheckBox(this);
        rootMode.setText("Root mode (su)");
        rootMode.setChecked(prefs.getBoolean("root_mode", false));
        layout.addView(rootMode);

        final CheckBox stealthMode = new CheckBox(this);
        stealthMode.setText("Stealth mode (hide from detection)");
        stealthMode.setChecked(prefs.getBoolean("stealth_mode", true));
        layout.addView(stealthMode);

        final CheckBox backgroundService = new CheckBox(this);
        backgroundService.setText("Run as background service");
        backgroundService.setChecked(prefs.getBoolean("background_service", false));
        layout.addView(backgroundService);

        final CheckBox notificationHack = new CheckBox(this);
        notificationHack.setText("Hack notifications");
        notificationHack.setChecked(prefs.getBoolean("notifications", true));
        layout.addView(notificationHack);

        final EditText themeInput = new EditText(this);
        themeInput.setHint("Theme (dark/light/amoled)");
        themeInput.setText(prefs.getString("theme", "dark"));
        layout.addView(themeInput);

        builder.setView(layout);
        builder.setPositiveButton("Save", (dialog, which) -> {
            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean("auto_attach", autoAttach.isChecked());
            editor.putBoolean("root_mode", rootMode.isChecked());
            editor.putBoolean("stealth_mode", stealthMode.isChecked());
            editor.putBoolean("background_service", backgroundService.isChecked());
            editor.putBoolean("notifications", notificationHack.isChecked());
            editor.putString("theme", themeInput.getText().toString());
            editor.apply();
            showToast("Settings saved");
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void showAbout() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("About Bugor Engine");
        builder.setMessage(
            "Bugor Engine v" + (bridge != null ? bridge.getVersion() : "loading...") + "\n\n" +
            "Advanced Game Cheat Engine for Android\n\n" +
            "Features:\n" +
            "\u2022 Memory Read/Write/Freeze\n" +
            "\u2022 Memory Search (Value, Range, Pattern)\n" +
            "\u2022 Dynamic Hooking Framework\n" +
            "\u2022 Crash Reporter & Minidump\n" +
            "\u2022 Script Engine (Lua/Python)\n" +
            "\u2022 Encryption (AES, ChaCha20, RSA)\n" +
            "\u2022 Remote Control Server/Client\n" +
            "\u2022 Debugger (GDB-compatible)\n" +
            "\u2022 Analytics Engine\n" +
            "\u2022 Persistence Layer (SQLite/LevelDB)\n" +
            "\u2022 Hot Reload & Sandboxing\n" +
            "\u2022 Anti-Detection & Anti-Ban\n\n" +
            "Built with NDK r26 \u2022 C++17\n" +
            "OpenSSL \u2022 LevelDB \u2022 Protobuf\n\n" +
            "\u00a9 2024 Bugor Team"
        );
        builder.setPositiveButton("OK", null);
        builder.show();
    }

    private void showEditDialog(String title, String hint, String defaultValue, EditDialogCallback callback) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        final EditText input = new EditText(this);
        input.setHint(hint);
        input.setText(defaultValue);
        input.selectAll();
        builder.setView(input);
        builder.setPositiveButton("OK", (dialog, which) -> {
            String value = input.getText().toString();
            if (!value.isEmpty()) callback.onResult(value);
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    public void updateStatus(String status, int color) {
        runOnUiThread(() -> {
            if (statusText != null) {
                statusText.setText(status);
                statusText.setTextColor(color);
            }
        });
    }

    public void addLog(String message) {
        String timestamp = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(new Date());
        String logLine = "[" + timestamp + "] " + message;
        handler.post(() -> {
            if (logText != null) logText.append(logLine + "\n");
            if (logScrollView != null) {
                logScrollView.post(() -> logScrollView.fullScroll(View.FOCUS_DOWN));
            }
        });
        Log.d(TAG, message);
    }

    private void clearLog() {
        if (logText != null) logText.setText("");
        addLog("Log cleared");
    }

    private void showProgress(boolean show) {
        handler.post(() -> {
            if (progressBar != null) {
                progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
            }
        });
    }

    private boolean validateAddress() {
        String addrStr = addressInput.getText().toString();
        if (addrStr.isEmpty()) {
            showToast("Enter an address");
            return false;
        }
        try {
            if (addrStr.startsWith("0x")) {
                currentAddress = Long.parseLong(addrStr.substring(2), 16);
            } else {
                currentAddress = Long.parseLong(addrStr);
            }
            return true;
        } catch (NumberFormatException e) {
            showToast("Invalid address format");
            return false;
        }
    }

    private void updateFrozenValuesUI() {
        handler.post(() -> {
            if (frozenValuesLayout == null) return;
            frozenValuesLayout.removeAllViews();
            for (Map.Entry<Long, String> entry : frozenAddresses.entrySet()) {
                TextView tv = new TextView(this);
                tv.setText("0x" + Long.toHexString(entry.getKey()) + " = " + entry.getValue());
                tv.setTextColor(Color.MAGENTA);
                tv.setPadding(10, 5, 10, 5);
                frozenValuesLayout.addView(tv);
            }
        });
    }

    private void startFrozenLoop() {
        new Thread(() -> {
            while (activityAlive && attached && autoFreezeEnabled) {
                for (Long addr : new java.util.ArrayList<>(frozenAddresses.keySet())) {
                    if (!activityAlive || !autoFreezeEnabled) break;
                    String val = frozenAddresses.get(addr);
                    if (val == null) continue;
                    try {
                        if (bridge != null && bridge.isInitialized()) {
                            bridge.nativeWriteLong(addr, Long.parseLong(val));
                        }
                    } catch (Exception ignored) {}
                }
                try { Thread.sleep(50); } catch (InterruptedException e) { break; }
            }
        }, "FreezeLoop").start();
    }

    private void loadSavedState() {
        String lastAddr = prefs.getString("last_address", "");
        if (!lastAddr.isEmpty()) {
            addressInput.setText(lastAddr);
        }
    }

    private void saveCurrentState() {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("last_address", addressInput.getText().toString());
        editor.putString("last_search_value", searchValueInput.getText().toString());
        editor.apply();
    }

    private List<Map<String, Object>> parseResults(String json) {
        List<Map<String, Object>> results = new ArrayList<>();
        try {
            if (json == null || json.equals("[]")) return results;
            json = json.trim();
            if (json.startsWith("[")) json = json.substring(1, json.length() - 1);
            if (json.isEmpty()) return results;
            String[] items = json.split("\\},\\{");
            for (String item : items) {
                item = item.replace("{", "").replace("}", "");
                Map<String, Object> map = new HashMap<>();
                String[] pairs = item.split(",");
                for (String pair : pairs) {
                    String[] kv = pair.split(":", 2);
                    if (kv.length == 2) {
                        String key = kv[0].replace("\"", "").trim();
                        String val = kv[1].trim();
                        if (val.equals("true")) map.put(key, true);
                        else if (val.equals("false")) map.put(key, false);
                        else if (key.equals("path")) map.put(key, val.replace("\"", ""));
                        else {
                            try {
                                if (val.contains(".")) { map.put(key, Double.parseDouble(val)); }
                                else { map.put(key, Long.parseLong(val)); }
                            } catch (NumberFormatException e) { map.put(key, val); }
                        }
                    }
                }
                results.add(map);
            }
        } catch (Exception e) {
            Log.e(TAG, "Parse error: " + e.getMessage());
        }
        return results;
    }

    @Override
    protected void onDestroy() {
        activityAlive = false;
        autoFreezeEnabled = false;
        attached = false;
        NativeBridge.shutdownEngine();
        saveCurrentState();
        if (bridge != null) bridge.shutdown();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (tabHost != null && tabHost.getCurrentTab() != 0) {
            tabHost.setCurrentTab(0);
        } else {
            super.onBackPressed();
        }
    }

    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, OVERLAY_PERMISSION_REQUEST);
        }
    }

    private interface EditDialogCallback {
        void onResult(String value);
    }

    public static class Utils {
        public static String bytesToHex(byte[] bytes) {
            StringBuilder hex = new StringBuilder();
            for (byte b : bytes) {
                hex.append(String.format("%02X ", b));
            }
            return hex.toString().trim();
        }

        public static byte[] hexToBytes(String hex) {
            hex = hex.replace(" ", "").replace("0x", "");
            int len = hex.length();
            byte[] data = new byte[len / 2];
            for (int i = 0; i < len; i += 2) {
                data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                    + Character.digit(hex.charAt(i + 1), 16));
            }
            return data;
        }

        public static boolean isGameProcess(String processName) {
            String[] indicators = {".game", ".unity", ".cocos", ".ue4", ".godot",
                "com.tencent", "com.netease", "com.miHoYo", "com.activision",
                "com.ea.game", "com.epicgames", "com.rockstargames"};
            for (String ind : indicators) {
                if (processName.contains(ind)) return true;
            }
            return false;
        }
    }
}
