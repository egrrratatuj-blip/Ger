package com.bugor.engine;

import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.URL;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.UUID;

public class DeviceUtils {
    private static volatile DeviceUtils instance;
    private Context context;
    private String cachedHardwareId;
    private String cachedMacAddress;
    private String cachedAndroidId;
    private Map<String, String> deviceInfoCache = new HashMap<>();
    private long lastCacheUpdate = 0;
    private static final long CACHE_TTL = 60000L;

    public static class DeviceInfo {
        public String hardwareId;
        public String androidId;
        public String serialNumber;
        public String fingerprint;
        public String macAddress;
        public String deviceModel;
        public String manufacturer;
        public String brand;
        public String board;
        public String hardware;
        public String product;
        public String device;
        public String display;
        public String host;
        public String user;
        public String tags;
        public String type;
        public String abi;
        public String abi2;
        public String bootloader;
        public String radio;
        public String buildId;
        public String buildTime;
        public String buildVersion;
        public String buildRelease;
        public int sdkInt;
        public String securityPatch;
        public String baseOs;
        public String incremental;
        public String codename;
    }

    public static class NetworkInfoData {
        public boolean isConnected;
        public String type;
        public String subtype;
        public String ssid;
        public String bssid;
        public int rssi;
        public int linkSpeed;
        public String ipAddress;
        public String macAddress;
        public boolean isRoaming;
        public String operatorName;
        public String networkCountry;
        public int networkType;
        public String wifiIp;
    }

    public static class BatteryInfo {
        public int level;
        public int scale;
        public int temperature;
        public int voltage;
        public int status;
        public int health;
        public String technology;
        public boolean isCharging;
        public boolean isPresent;
        public int plugged;
        public int chargeCounter;
        public int currentAvg;
        public int currentNow;
        public int energyCounter;
        public int capacity;
    }

    public static class MemoryInfo {
        public long totalRam;
        public long freeRam;
        public long usedRam;
        public long maxHeap;
        public long totalHeap;
        public long freeHeap;
        public long usedHeap;
        public long nativeHeap;
        public long nativeHeapFree;
        public long totalSwap;
        public long freeSwap;
        public long usedSwap;
        public long totalStorage;
        public long freeStorage;
        public long usedStorage;
        public long totalSdCard;
        public long freeSdCard;
        public long usedSdCard;
    }

    public static class CpuInfo {
        public int cores;
        public int coresOnline;
        public long maxFreq;
        public long minFreq;
        public long currentFreq;
        public String architecture;
        public String implementer;
        public String part;
        public String revision;
        public String governor;
        public String features;
        public List<Long> coreFrequencies;
        public List<String> coreGovernors;
    }

    public static class ScreenInfo {
        public int widthPixels;
        public int heightPixels;
        public int densityDpi;
        public float density;
        public float scaledDensity;
        public float xDpi;
        public float yDpi;
        public float refreshRate;
        public int orientation;
        public int logicalWidth;
        public int logicalHeight;
        public int statusBarHeight;
        public int navigationBarHeight;
    }

    private DeviceUtils(Context context) {
        this.context = context.getApplicationContext();
    }

    public static DeviceUtils getInstance(Context context) {
        if (instance == null) {
            synchronized (DeviceUtils.class) {
                if (instance == null) {
                    instance = new DeviceUtils(context);
                }
            }
        }
        return instance;
    }

    public String getHardwareId() {
        if (cachedHardwareId != null) return cachedHardwareId;
        try {
            StringBuilder sb = new StringBuilder();
            sb.append(getAndroidId());
            sb.append(Build.BOARD);
            sb.append(Build.BRAND);
            sb.append(Build.DEVICE);
            sb.append(Build.HARDWARE);
            sb.append(Build.MANUFACTURER);
            sb.append(Build.MODEL);
            sb.append(Build.PRODUCT);
            sb.append(Build.SERIAL);
            sb.append(getMacAddress());
            sb.append(Build.FINGERPRINT);
            sb.append(Build.HOST);
            sb.append(Build.DISPLAY);
            sb.append(Build.BOOTLOADER);
            String combined = sb.toString();
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(combined.getBytes("UTF-8"));
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) hex.append(String.format("%02x", b & 0xFF));
            cachedHardwareId = hex.toString();
            return cachedHardwareId;
        } catch (Exception e) {
            cachedHardwareId = UUID.randomUUID().toString().replace("-", "");
            return cachedHardwareId;
        }
    }

    public String getUniqueDeviceId() {
        try {
            String id = Utils.getMaskedAndroidId();
            if (id.startsWith("android-fallback") || id.startsWith("android-unknown")) {
                id = getHardwareId().substring(0, 16);
            }
            return id;
        } catch (Exception e) {
            return UUID.randomUUID().toString().substring(0, 16);
        }
    }

    public String getAndroidId() {
        if (cachedAndroidId != null) return cachedAndroidId;
        try {
            cachedAndroidId = Utils.getMaskedAndroidId();
            if (cachedAndroidId == null) cachedAndroidId = "unknown";
            return cachedAndroidId;
        } catch (Exception e) {
            return "unknown";
        }
    }

    public String getMacAddress() {
        if (cachedMacAddress != null) return cachedMacAddress;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Enumeration<NetworkInterface> interfaces =
                    NetworkInterface.getNetworkInterfaces();
                while (interfaces.hasMoreElements()) {
                    NetworkInterface ni = interfaces.nextElement();
                    if (ni.getName().equalsIgnoreCase("wlan0")) {
                        byte[] mac = ni.getHardwareAddress();
                        if (mac != null) {
                            StringBuilder sb = new StringBuilder();
                            for (int i = 0; i < mac.length; i++) {
                                if (i > 0) sb.append(":");
                                sb.append(String.format("%02x", mac[i] & 0xFF));
                            }
                            cachedMacAddress = sb.toString();
                            return cachedMacAddress;
                        }
                    }
                }
            } else {
                WifiManager wm = (WifiManager) context.getSystemService(
                    Context.WIFI_SERVICE);
                if (wm != null) {
                    WifiInfo wi = wm.getConnectionInfo();
                    if (wi != null) {
                        cachedMacAddress = wi.getMacAddress();
                        return cachedMacAddress;
                    }
                }
            }
            cachedMacAddress = "02:00:00:00:00:00";
            return cachedMacAddress;
        } catch (Exception e) {
            cachedMacAddress = "02:00:00:00:00:00";
            return cachedMacAddress;
        }
    }

    public String getSerialNumber() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                return Build.getSerial();
            }
            return Build.SERIAL;
        } catch (Exception e) {
            return "unknown";
        }
    }

    public String getFingerprint() {
        return Build.FINGERPRINT;
    }

    public DeviceInfo getDeviceInfo() {
        DeviceInfo info = new DeviceInfo();
        info.hardwareId = getHardwareId();
        info.androidId = getAndroidId();
        info.serialNumber = getSerialNumber();
        info.fingerprint = Build.FINGERPRINT;
        info.macAddress = getMacAddress();
        info.deviceModel = Build.MODEL;
        info.manufacturer = Build.MANUFACTURER;
        info.brand = Build.BRAND;
        info.board = Build.BOARD;
        info.hardware = Build.HARDWARE;
        info.product = Build.PRODUCT;
        info.device = Build.DEVICE;
        info.display = Build.DISPLAY;
        info.host = Build.HOST;
        info.user = Build.USER;
        info.tags = Build.TAGS;
        info.type = Build.TYPE;
        info.abi = Build.CPU_ABI;
        info.abi2 = Build.CPU_ABI2;
        info.bootloader = Build.BOOTLOADER;
        info.buildId = Build.ID;
        info.buildTime = String.valueOf(Build.TIME);
        info.buildVersion = Build.VERSION.INCREMENTAL;
        info.buildRelease = Build.VERSION.RELEASE;
        info.sdkInt = Build.VERSION.SDK_INT;
        info.securityPatch = Build.VERSION.SECURITY_PATCH;
        info.baseOs = Build.VERSION.BASE_OS;
        info.incremental = Build.VERSION.INCREMENTAL;
        info.codename = Build.VERSION.CODENAME;
        return info;
    }

    public NetworkInfoData getNetworkInfo() {
        NetworkInfoData data = new NetworkInfoData();
        try {
            ConnectivityManager cm = (ConnectivityManager)
                context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null) {
                NetworkInfo ni = cm.getActiveNetworkInfo();
                if (ni != null) {
                    data.isConnected = ni.isConnected();
                    data.type = ni.getTypeName();
                    data.subtype = ni.getSubtypeName();
                    data.isRoaming = ni.isRoaming();
                    data.networkType = ni.getType();
                }
            }
            TelephonyManager tm = (TelephonyManager)
                context.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm != null) {
                data.operatorName = tm.getNetworkOperatorName();
                data.networkCountry = tm.getNetworkCountryIso();
            }
            WifiManager wm = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                WifiInfo wi = wm.getConnectionInfo();
                if (wi != null) {
                    data.ssid = wi.getSSID();
                    data.bssid = wi.getBSSID();
                    data.rssi = wi.getRssi();
                    data.linkSpeed = wi.getLinkSpeed();
                    data.macAddress = wi.getMacAddress();
                    int ip = wi.getIpAddress();
                    data.wifiIp = String.format(Locale.US, "%d.%d.%d.%d",
                        (ip & 0xFF), (ip >> 8 & 0xFF),
                        (ip >> 16 & 0xFF), (ip >> 24 & 0xFF));
                }
            }
        } catch (Exception e) {
        }
        return data;
    }

    public BatteryInfo getBatteryInfo() {
        BatteryInfo info = new BatteryInfo();
        try {
            IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent battery = context.registerReceiver(null, ifilter);
            if (battery != null) {
                info.level = battery.getIntExtra("level", 0);
                info.scale = battery.getIntExtra("scale", 100);
                info.temperature = battery.getIntExtra("temperature", 0);
                info.voltage = battery.getIntExtra("voltage", 0);
                info.status = battery.getIntExtra("status", 0);
                info.health = battery.getIntExtra("health", 0);
                info.technology = battery.getStringExtra("technology");
                info.isPresent = battery.getBooleanExtra("present", false);
                info.plugged = battery.getIntExtra("plugged", 0);
                info.isCharging = info.status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    info.status == BatteryManager.BATTERY_STATUS_FULL;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                BatteryManager bm = (BatteryManager)
                    context.getSystemService(Context.BATTERY_SERVICE);
                if (bm != null) {
                    info.chargeCounter = bm.getIntProperty(
                        BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);
                    info.currentAvg = bm.getIntProperty(
                        BatteryManager.BATTERY_PROPERTY_CURRENT_AVERAGE);
                    info.currentNow = bm.getIntProperty(
                        BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);
                    info.energyCounter = bm.getIntProperty(
                        BatteryManager.BATTERY_PROPERTY_ENERGY_COUNTER);
                    info.capacity = bm.getIntProperty(
                        BatteryManager.BATTERY_PROPERTY_CAPACITY);
                }
            }
        } catch (Exception e) {
        }
        return info;
    }

    public MemoryInfo getMemoryInfo() {
        MemoryInfo info = new MemoryInfo();
        try {
            Runtime rt = Runtime.getRuntime();
            info.totalHeap = rt.totalMemory();
            info.freeHeap = rt.freeMemory();
            info.usedHeap = info.totalHeap - info.freeHeap;
            info.maxHeap = rt.maxMemory();
            info.nativeHeap = getNativeHeapSize();
            info.nativeHeapFree = getNativeHeapFreeSize();
            info.totalRam = getTotalMemory();
            info.freeRam = getFreeMemory();
            info.usedRam = info.totalRam - info.freeRam;
            StatFs dataStat = new StatFs(Environment.getDataDirectory().getPath());
            info.totalStorage = (long) dataStat.getBlockCountLong() *
                dataStat.getBlockSizeLong();
            info.freeStorage = (long) dataStat.getAvailableBlocksLong() *
                dataStat.getBlockSizeLong();
            info.usedStorage = info.totalStorage - info.freeStorage;
            if (Environment.getExternalStorageState().equals(
                Environment.MEDIA_MOUNTED)) {
                StatFs sdStat = new StatFs(
                    Environment.getExternalStorageDirectory().getPath());
                info.totalSdCard = (long) sdStat.getBlockCountLong() *
                    sdStat.getBlockSizeLong();
                info.freeSdCard = (long) sdStat.getAvailableBlocksLong() *
                    sdStat.getBlockSizeLong();
                info.usedSdCard = info.totalSdCard - info.freeSdCard;
            }
            info.totalSwap = getTotalSwap();
            info.freeSwap = getFreeSwap();
            info.usedSwap = info.totalSwap - info.freeSwap;
        } catch (Exception e) {
        }
        return info;
    }

    public CpuInfo getCpuInfo() {
        CpuInfo info = new CpuInfo();
        try {
            info.cores = Runtime.getRuntime().availableProcessors();
            info.coreFrequencies = new ArrayList<>();
            info.coreGovernors = new ArrayList<>();
            for (int i = 0; i < info.cores; i++) {
                try {
                    String freqPath = "/sys/devices/system/cpu/cpu" + i +
                        "/cpufreq/scaling_cur_freq";
                    BufferedReader br = new BufferedReader(new FileReader(freqPath));
                    String freq = br.readLine();
                    if (freq != null) {
                        info.coreFrequencies.add(Long.parseLong(freq.trim()));
                    }
                    br.close();
                } catch (Exception e) {
                    info.coreFrequencies.add(0L);
                }
                try {
                    String govPath = "/sys/devices/system/cpu/cpu" + i +
                        "/cpufreq/scaling_governor";
                    BufferedReader br = new BufferedReader(new FileReader(govPath));
                    String gov = br.readLine();
                    if (gov != null) info.coreGovernors.add(gov.trim());
                    br.close();
                } catch (Exception e) {
                    info.coreGovernors.add("unknown");
                }
            }
            try {
                BufferedReader br = new BufferedReader(
                    new FileReader("/sys/devices/system/cpu/online"));
                String online = br.readLine();
                if (online != null) {
                    String[] parts = online.split("-");
                    if (parts.length >= 2) {
                        int start = Integer.parseInt(parts[0]);
                        int end = Integer.parseInt(parts[1]);
                        info.coresOnline = end - start + 1;
                    } else {
                        info.coresOnline = parts.length;
                    }
                }
                br.close();
            } catch (Exception e) {
                info.coresOnline = info.cores;
            }
            try {
                BufferedReader br = new BufferedReader(
                    new FileReader("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq"));
                String freq = br.readLine();
                if (freq != null) info.maxFreq = Long.parseLong(freq.trim());
                br.close();
            } catch (Exception e) {
            }
            try {
                BufferedReader br = new BufferedReader(
                    new FileReader("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_min_freq"));
                String freq = br.readLine();
                if (freq != null) info.minFreq = Long.parseLong(freq.trim());
                br.close();
            } catch (Exception e) {
            }
            try {
                BufferedReader br = new BufferedReader(
                    new FileReader("/proc/cpuinfo"));
                String line;
                while ((line = br.readLine()) != null) {
                    if (line.startsWith("Processor") || line.startsWith("model name")) {
                        info.architecture = line.split(":")[1].trim();
                    }
                    if (line.startsWith("CPU implementer")) {
                        info.implementer = line.split(":")[1].trim();
                    }
                    if (line.startsWith("CPU part")) {
                        info.part = line.split(":")[1].trim();
                    }
                    if (line.startsWith("CPU revision")) {
                        info.revision = line.split(":")[1].trim();
                    }
                    if (line.startsWith("Features")) {
                        info.features = line.split(":")[1].trim();
                    }
                }
                br.close();
            } catch (Exception e) {
            }
            try {
                BufferedReader br = new BufferedReader(
                    new FileReader("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor"));
                String gov = br.readLine();
                if (gov != null) info.governor = gov.trim();
                br.close();
            } catch (Exception e) {
            }
        } catch (Exception e) {
        }
        return info;
    }

    public ScreenInfo getScreenInfo() {
        ScreenInfo info = new ScreenInfo();
        try {
            WindowManager wm = (WindowManager)
                context.getSystemService(Context.WINDOW_SERVICE);
            if (wm != null) {
                Display display = wm.getDefaultDisplay();
                DisplayMetrics dm = new DisplayMetrics();
                display.getMetrics(dm);
                info.widthPixels = dm.widthPixels;
                info.heightPixels = dm.heightPixels;
                info.densityDpi = dm.densityDpi;
                info.density = dm.density;
                info.scaledDensity = dm.scaledDensity;
                info.xDpi = dm.xdpi;
                info.yDpi = dm.ydpi;
                info.refreshRate = display.getRefreshRate();
                info.orientation = display.getRotation();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                    DisplayMetrics realDm = new DisplayMetrics();
                    display.getRealMetrics(realDm);
                    info.logicalWidth = realDm.widthPixels;
                    info.logicalHeight = realDm.heightPixels;
                } else {
                    info.logicalWidth = dm.widthPixels;
                    info.logicalHeight = dm.heightPixels;
                }
            }
            info.statusBarHeight = getStatusBarHeight();
            info.navigationBarHeight = getNavigationBarHeight();
        } catch (Exception e) {
        }
        return info;
    }

    public Map<String, Object> getAllDeviceInfo() {
        Map<String, Object> all = new HashMap<>();
        try {
            DeviceInfo dev = getDeviceInfo();
            all.put("hardware_id", dev.hardwareId);
            all.put("android_id", dev.androidId);
            all.put("serial", dev.serialNumber);
            all.put("fingerprint", dev.fingerprint);
            all.put("mac", dev.macAddress);
            all.put("model", dev.deviceModel);
            all.put("manufacturer", dev.manufacturer);
            all.put("brand", dev.brand);
            all.put("board", dev.board);
            all.put("hardware", dev.hardware);
            all.put("product", dev.product);
            all.put("device", dev.device);
            all.put("sdk", dev.sdkInt);
            all.put("release", dev.buildRelease);
            NetworkInfoData net = getNetworkInfo();
            all.put("network_connected", net.isConnected);
            all.put("network_type", net.type);
            all.put("wifi_ssid", net.ssid);
            all.put("wifi_ip", net.wifiIp);
            BatteryInfo bat = getBatteryInfo();
            all.put("battery_level", bat.level);
            all.put("battery_temperature", bat.temperature);
            all.put("battery_charging", bat.isCharging);
            MemoryInfo mem = getMemoryInfo();
            all.put("ram_total", mem.totalRam);
            all.put("ram_free", mem.freeRam);
            all.put("storage_total", mem.totalStorage);
            all.put("storage_free", mem.freeStorage);
            CpuInfo cpu = getCpuInfo();
            all.put("cpu_cores", cpu.cores);
            all.put("cpu_max_freq", cpu.maxFreq);
            all.put("cpu_arch", cpu.architecture);
            ScreenInfo screen = getScreenInfo();
            all.put("screen_width", screen.widthPixels);
            all.put("screen_height", screen.heightPixels);
            all.put("screen_density", screen.densityDpi);
            all.put("screen_refresh", screen.refreshRate);
        } catch (Exception e) {
        }
        return all;
    }

    private long getTotalMemory() {
        try {
            BufferedReader br = new BufferedReader(
                new FileReader("/proc/meminfo"));
            String line = br.readLine();
            br.close();
            if (line != null) {
                String[] parts = line.split("\\s+");
                if (parts.length >= 2) {
                    return Long.parseLong(parts[1]) * 1024;
                }
            }
        } catch (Exception e) {
        }
        return Runtime.getRuntime().totalMemory();
    }

    private long getFreeMemory() {
        try {
            BufferedReader br = new BufferedReader(
                new FileReader("/proc/meminfo"));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("MemFree:")) {
                    String[] parts = line.split("\\s+");
                    if (parts.length >= 2) {
                        br.close();
                        return Long.parseLong(parts[1]) * 1024;
                    }
                }
            }
            br.close();
        } catch (Exception e) {
        }
        return Runtime.getRuntime().freeMemory();
    }

    private long getTotalSwap() {
        try {
            BufferedReader br = new BufferedReader(
                new FileReader("/proc/meminfo"));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("SwapTotal:")) {
                    String[] parts = line.split("\\s+");
                    if (parts.length >= 2) {
                        br.close();
                        return Long.parseLong(parts[1]) * 1024;
                    }
                }
            }
            br.close();
        } catch (Exception e) {
        }
        return 0;
    }

    private long getFreeSwap() {
        try {
            BufferedReader br = new BufferedReader(
                new FileReader("/proc/meminfo"));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("SwapFree:")) {
                    String[] parts = line.split("\\s+");
                    if (parts.length >= 2) {
                        br.close();
                        return Long.parseLong(parts[1]) * 1024;
                    }
                }
            }
            br.close();
        } catch (Exception e) {
        }
        return 0;
    }

    private long getNativeHeapSize() {
        try {
            RandomAccessFile raf = new RandomAccessFile("/proc/self/status", "r");
            String line;
            while ((line = raf.readLine()) != null) {
                if (line.startsWith("VmSize:")) {
                    String[] parts = line.split("\\s+");
                    if (parts.length >= 2) {
                        raf.close();
                        return Long.parseLong(parts[1]) * 1024;
                    }
                }
            }
            raf.close();
        } catch (Exception e) {
        }
        return 0;
    }

    private long getNativeHeapFreeSize() {
        try {
            RandomAccessFile raf = new RandomAccessFile("/proc/self/status", "r");
            String line;
            while ((line = raf.readLine()) != null) {
                if (line.startsWith("VmRSS:")) {
                    String[] parts = line.split("\\s+");
                    if (parts.length >= 2) {
                        raf.close();
                        return Long.parseLong(parts[1]) * 1024;
                    }
                }
            }
            raf.close();
        } catch (Exception e) {
        }
        return 0;
    }

    private int getStatusBarHeight() {
        int resourceId = context.getResources().getIdentifier(
            "status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            return context.getResources().getDimensionPixelSize(resourceId);
        }
        return (int) (24 * context.getResources().getDisplayMetrics().density);
    }

    private int getNavigationBarHeight() {
        int resourceId = context.getResources().getIdentifier(
            "navigation_bar_height", "dimen", "android");
        if (resourceId > 0) {
            return context.getResources().getDimensionPixelSize(resourceId);
        }
        return 0;
    }

    public String getTimeZone() {
        return TimeZone.getDefault().getID();
    }

    public String getLanguage() {
        return Locale.getDefault().getLanguage();
    }

    public String getCountry() {
        return Locale.getDefault().getCountry();
    }

    public String getDisplayLanguage() {
        return Locale.getDefault().getDisplayLanguage();
    }

    public boolean hasGPS() {
        return context.getPackageManager().hasSystemFeature(
            PackageManager.FEATURE_LOCATION_GPS);
    }

    public boolean hasNFC() {
        return context.getPackageManager().hasSystemFeature(
            PackageManager.FEATURE_NFC);
    }

    public boolean hasBluetooth() {
        return context.getPackageManager().hasSystemFeature(
            PackageManager.FEATURE_BLUETOOTH);
    }

    public boolean hasCamera() {
        return context.getPackageManager().hasSystemFeature(
            PackageManager.FEATURE_CAMERA);
    }

    public boolean hasFrontCamera() {
        return context.getPackageManager().hasSystemFeature(
            PackageManager.FEATURE_CAMERA_FRONT);
    }

    public boolean hasFlash() {
        return context.getPackageManager().hasSystemFeature(
            PackageManager.FEATURE_CAMERA_FLASH);
    }

    public boolean hasGyroscope() {
        return context.getPackageManager().hasSystemFeature(
            PackageManager.FEATURE_SENSOR_GYROSCOPE);
    }

    public boolean hasAccelerometer() {
        return context.getPackageManager().hasSystemFeature(
            PackageManager.FEATURE_SENSOR_ACCELEROMETER);
    }

    public boolean hasCompass() {
        return context.getPackageManager().hasSystemFeature(
            PackageManager.FEATURE_SENSOR_COMPASS);
    }

    public boolean hasBarometer() {
        return context.getPackageManager().hasSystemFeature(
            PackageManager.FEATURE_SENSOR_BAROMETER);
    }

    public boolean hasHeartRate() {
        return context.getPackageManager().hasSystemFeature(
            PackageManager.FEATURE_SENSOR_HEART_RATE);
    }

    public boolean hasFingerprint() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return context.getPackageManager().hasSystemFeature(
                PackageManager.FEATURE_FINGERPRINT);
        }
        return false;
    }

    public boolean hasIR() {
        return context.getPackageManager().hasSystemFeature(
            PackageManager.FEATURE_CONSUMER_IR);
    }

    public boolean hasUSB() {
        return context.getPackageManager().hasSystemFeature(
            PackageManager.FEATURE_USB_ACCESSORY);
    }

    public boolean hasMicrophone() {
        return context.getPackageManager().hasSystemFeature(
            PackageManager.FEATURE_MICROPHONE);
    }

    public boolean hasTelephony() {
        return context.getPackageManager().hasSystemFeature(
            PackageManager.FEATURE_TELEPHONY);
    }

    public boolean hasWiFi() {
        return context.getPackageManager().hasSystemFeature(
            PackageManager.FEATURE_WIFI);
    }

    public boolean hasEthernet() {
        return context.getPackageManager().hasSystemFeature(
            PackageManager.FEATURE_ETHERNET);
    }

    public boolean hasMultiTouch() {
        return context.getPackageManager().hasSystemFeature(
            PackageManager.FEATURE_TOUCHSCREEN_MULTITOUCH);
    }

    public boolean isTV() {
        return context.getPackageManager().hasSystemFeature(
            PackageManager.FEATURE_LEANBACK);
    }

    public boolean isTablet() {
        return (context.getResources().getConfiguration().screenLayout &
            Configuration.SCREENLAYOUT_SIZE_MASK) >=
            Configuration.SCREENLAYOUT_SIZE_LARGE;
    }

    public void clearCache() {
        cachedHardwareId = null;
        cachedMacAddress = null;
        cachedAndroidId = null;
        deviceInfoCache.clear();
        lastCacheUpdate = 0;
    }
}
