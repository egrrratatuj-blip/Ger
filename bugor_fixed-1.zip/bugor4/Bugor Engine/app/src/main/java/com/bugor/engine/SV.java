package com.bugor.engine;

import android.content.Context;
import android.graphics.PixelFormat;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import com.bugor.engine.IPCCond.IPCService;

public class SV extends SurfaceView implements SurfaceHolder.Callback {
    public SV(Context context) {
        super(context);
        setZOrderOnTop(true);
        getHolder().setFormat(PixelFormat.TRANSPARENT);
        getHolder().addCallback(this);
    }

    public void surfaceCreated(SurfaceHolder holder) {
        try {
            IPCService.GetIPC().setSurface(holder.getSurface());
        } catch (Exception e) {}
    }

    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        try {
            IPCService.GetIPC().start(width, height);
        } catch (Exception e) {}
    }

    public void surfaceDestroyed(SurfaceHolder holder) {}
}
