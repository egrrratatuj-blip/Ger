package com.bugor.engine;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Debug;
import android.os.Environment;
import android.os.Process;
import android.os.StatFs;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class CrashReporter implements Thread.UncaughtExceptionHandler {
    private static volatile CrashReporter instance;
    private Context context;
    private Thread.UncaughtExceptionHandler defaultHandler;
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(2);
    private AtomicBoolean isCrashing = new AtomicBoolean(false);
    private AtomicBoolean anrDetected = new AtomicBoolean(false);
    private AtomicInteger crashCount = new AtomicInteger(0);
    private String crashReportUrl = "https://crash.bugor-engine.com/report";
    private String crashLogDir;
    private String appVersion = "";
    private String appBuild = "";
    private String userId = "";
    private boolean autoUpload = true;
    private boolean showDialog = true;
    private boolean collectLogcat = true;
    private long anrTimeoutMs = 5000;
    private Map<String, String> customKeys = new HashMap<>();
    private List<CrashListener> listeners = new ArrayList<>();
    private ScheduledFuture<?> anrWatchdog;
    private static final int MAX_CRASH_LOGS = 50;
    private static final String CRASH_DIR_NAME = "crash_logs";
    private static final String ANR_DIR_NAME = "anr_logs";
    private static final String LOG_DIR_NAME = "app_logs";
    private static final int MAX_LOG_SIZE = 1048576;

    public interface CrashListener {
        void onCrashDetected(Throwable throwable, String reportPath);
        void onCrashUploaded(String reportPath, boolean success);
        void onANRDetected(String stackTrace);
        void onUserFeedbackProvided(String reportPath, String feedback);
    }

    public static class CrashReport {
        public String id;
        public String timestamp;
        public String appVersion;
        public String androidVersion;
        public String deviceModel;
        public String manufacturer;
        public String stackTrace;
        public String threadName;
        public Map<String, String> deviceInfo;
        public Map<String, String> customData;
        public String logcat;
        public boolean uploaded;
        public String filePath;
    }

    private CrashReporter(Context context) {
        this.context = context.getApplicationContext();
        this.defaultHandler = Thread.getDefaultUncaughtExceptionHandler();
        this.crashLogDir = context.getFilesDir().getAbsolutePath() + File.separator + CRASH_DIR_NAME;
        new File(crashLogDir).mkdirs();
        new File(context.getFilesDir() + File.separator + ANR_DIR_NAME).mkdirs();
        new File(context.getFilesDir() + File.separator + LOG_DIR_NAME).mkdirs();
        initAppInfo();
    }

    public static CrashReporter getInstance(Context context) {
        if (instance == null) {
            synchronized (CrashReporter.class) {
                if (instance == null) {
                    instance = new CrashReporter(context);
                }
            }
        }
        return instance;
    }

    public void init() {
        Thread.setDefaultUncaughtExceptionHandler(this);
        startANRWatchdog();
        uploadPendingReports();
    }

    public void uncaughtException(Thread thread, Throwable throwable) {
        if (isCrashing.getAndSet(true)) {
            try { Thread.sleep(1000); } catch (InterruptedException e) {}
            Process.killProcess(Process.myPid());
            System.exit(1);
            return;
        }
        crashCount.incrementAndGet();
        try {
            CrashReport report = createCrashReport(thread, throwable);
            String reportPath = saveCrashReport(report);
            report.filePath = reportPath;
            for (CrashListener listener : listeners) {
                try { listener.onCrashDetected(throwable, reportPath); } catch (Exception e) {}
            }
            if (autoUpload) {
                uploadCrashReport(report);
            }
            if (showDialog) {
                showCrashDialog(report);
            }
        } catch (Exception e) {
            try {
                File fallback = new File(crashLogDir, "fatal_" +
                    System.currentTimeMillis() + ".log");
                FileWriter fw = new FileWriter(fallback);
                fw.write("Fatal error in crash reporter: " +
                    android.util.Log.getStackTraceString(e));
                fw.write("\n\nOriginal crash:\n");
                fw.write(android.util.Log.getStackTraceString(throwable));
                fw.close();
            } catch (Exception ex) {
            }
        }
        if (defaultHandler != null) {
            defaultHandler.uncaughtException(thread, throwable);
        } else {
            Process.killProcess(Process.myPid());
            System.exit(1);
        }
    }

    public void setDefaultUncaughtExceptionHandler(Thread.UncaughtExceptionHandler handler) {
        this.defaultHandler = handler;
    }

    public void registerThreadDeathHandler() {
        Thread.setDefaultUncaughtExceptionHandler(this);
    }

    public void registerThread(Thread thread) {
        thread.setUncaughtExceptionHandler(this);
    }

    private void startANRWatchdog() {
        anrWatchdog = scheduler.scheduleAtFixedRate(() -> {
            try {
                long startTime = SystemClock.uptimeMillis();
                Thread watchdogThread = new Thread(() -> {
                    try {
                        Thread.sleep(anrTimeoutMs);
                        long elapsed = SystemClock.uptimeMillis() - startTime;
                        if (elapsed >= anrTimeoutMs && !anrDetected.getAndSet(true)) {
                            detectANR();
                        }
                    } catch (InterruptedException e) {
                    }
                }, "ANR-Watchdog");
                watchdogThread.setDaemon(true);
                watchdogThread.start();
                watchdogThread.join(anrTimeoutMs + 1000);
                anrDetected.set(false);
            } catch (Exception e) {
            }
        }, 10000, anrTimeoutMs, TimeUnit.MILLISECONDS);
    }

    private void detectANR() {
        try {
            StringBuilder sb = new StringBuilder();
            sb.append("ANR Detected at ").append(getCurrentTimestamp()).append("\n");
            sb.append("========================================\n");
            Map<Thread, StackTraceElement[]> stacks = Thread.getAllStackTraces();
            for (Map.Entry<Thread, StackTraceElement[]> entry : stacks.entrySet()) {
                Thread thread = entry.getKey();
                StackTraceElement[] stack = entry.getValue();
                sb.append("Thread: ").append(thread.getName())
                    .append(" (priority=").append(thread.getPriority())
                    .append(", state=").append(thread.getState()).append(")\n");
                for (StackTraceElement element : stack) {
                    sb.append("  at ").append(element.toString()).append("\n");
                }
                sb.append("\n");
            }
            String stackTrace = sb.toString();
            saveANRLog(stackTrace);
            for (CrashListener listener : listeners) {
                try { listener.onANRDetected(stackTrace); } catch (Exception e) {}
            }
        } catch (Exception e) {
        }
    }

    public void trackActivityLifecycle(Activity activity) {
        try {
            android.app.Application app = (android.app.Application) context;
            app.registerActivityLifecycleCallbacks(
                new android.app.Application.ActivityLifecycleCallbacks() {
                    public void onActivityCreated(Activity a, Bundle b) {}
                    public void onActivityStarted(Activity a) {}
                    public void onActivityResumed(Activity a) {}
                    public void onActivityPaused(Activity a) {}
                    public void onActivityStopped(Activity a) {}
                    public void onActivitySaveInstanceState(Activity a, Bundle b) {}
                    public void onActivityDestroyed(Activity a) {}
                });
        } catch (Exception e) {
        }
    }

    private CrashReport createCrashReport(Thread thread, Throwable throwable) {
        CrashReport report = new CrashReport();
        report.id = generateReportId();
        report.timestamp = getCurrentTimestamp();
        report.appVersion = appVersion;
        report.androidVersion = Build.VERSION.RELEASE;
        report.deviceModel = Build.MODEL;
        report.manufacturer = Build.MANUFACTURER;
        report.threadName = thread != null ? thread.getName() : "unknown";
        report.stackTrace = getStackTraceString(throwable);
        report.deviceInfo = collectDeviceInfo();
        report.customData = new HashMap<>(customKeys);
        report.uploaded = false;
        if (collectLogcat) {
            report.logcat = collectLogcat();
        }
        return report;
    }

    private String saveCrashReport(CrashReport report) {
        try {
            String fileName = "crash_" + report.id + "_" +
                System.currentTimeMillis() + ".crash";
            File file = new File(crashLogDir, fileName);
            StringBuilder sb = new StringBuilder();
            sb.append("ID: ").append(report.id).append("\n");
            sb.append("Timestamp: ").append(report.timestamp).append("\n");
            sb.append("App Version: ").append(report.appVersion).append("\n");
            sb.append("Android: ").append(report.androidVersion).append("\n");
            sb.append("Device: ").append(report.deviceModel).append("\n");
            sb.append("Manufacturer: ").append(report.manufacturer).append("\n");
            sb.append("Thread: ").append(report.threadName).append("\n");
            sb.append("Stack Trace:\n").append(report.stackTrace).append("\n");
            if (report.deviceInfo != null) {
                sb.append("Device Info:\n");
                for (Map.Entry<String, String> entry : report.deviceInfo.entrySet()) {
                    sb.append("  ").append(entry.getKey()).append(": ")
                        .append(entry.getValue()).append("\n");
                }
            }
            if (report.customData != null && !report.customData.isEmpty()) {
                sb.append("Custom Data:\n");
                for (Map.Entry<String, String> entry : report.customData.entrySet()) {
                    sb.append("  ").append(entry.getKey()).append(": ")
                        .append(entry.getValue()).append("\n");
                }
            }
            if (report.logcat != null) {
                sb.append("Logcat:\n").append(report.logcat).append("\n");
            }
            byte[] data = sb.toString().getBytes("UTF-8");
            byte[] encrypted = encryptReport(data);
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(encrypted);
            fos.close();
            cleanupOldReports();
            return file.getAbsolutePath();
        } catch (Exception e) {
            try {
                File file = new File(crashLogDir, "crash_" + report.id + ".txt");
                FileWriter fw = new FileWriter(file);
                fw.write(report.stackTrace);
                fw.close();
                return file.getAbsolutePath();
            } catch (Exception ex) {
                return "";
            }
        }
    }

    private void saveANRLog(String stackTrace) {
        try {
            File dir = new File(context.getFilesDir(), ANR_DIR_NAME);
            String fileName = "anr_" + System.currentTimeMillis() + ".txt";
            File file = new File(dir, fileName);
            FileWriter fw = new FileWriter(file);
            fw.write(stackTrace);
            fw.close();
        } catch (Exception e) {
        }
    }

    public void logToFile(String tag, String message) {
        try {
            File dir = new File(context.getFilesDir(), LOG_DIR_NAME);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            String fileName = "log_" + sdf.format(new Date()) + ".txt";
            File file = new File(dir, fileName);
            if (file.length() > MAX_LOG_SIZE) {
                file.renameTo(new File(dir, fileName + ".old"));
                file = new File(dir, fileName);
            }
            FileWriter fw = new FileWriter(file, true);
            fw.write("[" + getCurrentTimestamp() + "][" + tag + "] " + message + "\n");
            fw.close();
        } catch (Exception e) {
        }
    }

    public void uploadCrashReport(CrashReport report) {
        executor.submit(() -> {
            try {
                String json = buildReportJson(report);
                byte[] data = json.getBytes("UTF-8");
                URL url = new URL(crashReportUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(15000);
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("X-Crash-ID", report.id);
                conn.setRequestProperty("X-App-Version", appVersion);
                OutputStream os = conn.getOutputStream();
                os.write(data);
                os.close();
                int code = conn.getResponseCode();
                boolean success = code >= 200 && code < 300;
                report.uploaded = success;
                for (CrashListener listener : listeners) {
                    try {
                        listener.onCrashUploaded(report.filePath, success);
                    } catch (Exception e) {
                    }
                }
                if (success) {
                    markReportUploaded(report.filePath);
                }
                conn.disconnect();
            } catch (Exception e) {
                for (CrashListener listener : listeners) {
                    try {
                        listener.onCrashUploaded(report.filePath, false);
                    } catch (Exception ex) {
                    }
                }
            }
        });
    }

    private void uploadPendingReports() {
        executor.submit(() -> {
            try {
                File dir = new File(crashLogDir);
                File[] files = dir.listFiles((d, name) -> name.endsWith(".crash") &&
                    !name.contains("_uploaded"));
                if (files == null) return;
                for (File file : files) {
                    try {
                        FileInputStream fis = new FileInputStream(file);
                        byte[] encrypted = new byte[(int) file.length()];
                        fis.read(encrypted);
                        fis.close();
                        byte[] decrypted = decryptReport(encrypted);
                        String content = new String(decrypted, "UTF-8");
                        CrashReport report = parseReportFromFile(content, file.getAbsolutePath());
                        if (report != null) {
                            uploadCrashReport(report);
                        }
                    } catch (Exception e) {
                    }
                }
            } catch (Exception e) {
            }
        });
    }

    private void showCrashDialog(CrashReport report) {
        try {
            Activity activity = getCurrentActivity();
            if (activity == null) return;
            AlertDialog.Builder builder = new AlertDialog.Builder(activity);
            builder.setTitle("Application Crash");
            builder.setMessage("The application has encountered an unexpected error.\n" +
                "Please provide any additional information if you'd like to help us fix this issue.");
            final EditText input = new EditText(activity);
            input.setHint("Describe what you were doing...");
            builder.setView(input);
            builder.setPositiveButton("Send Report", (DialogInterface dialog, int which) -> {
                String feedback = input.getText().toString().trim();
                if (!feedback.isEmpty()) {
                    saveFeedback(report, feedback);
                    for (CrashListener listener : listeners) {
                        try {
                            listener.onUserFeedbackProvided(report.filePath, feedback);
                        } catch (Exception e) {
                        }
                    }
                }
                Toast.makeText(context, "Thank you for your feedback!", Toast.LENGTH_SHORT).show();
            });
            builder.setNegativeButton("Don't Send", (DialogInterface dialog, int which) -> {
                dialog.dismiss();
            });
            builder.setCancelable(false);
            builder.show();
        } catch (Exception e) {
        }
    }

    private void saveFeedback(CrashReport report, String feedback) {
        try {
            if (report.filePath != null && !report.filePath.isEmpty()) {
                File file = new File(report.filePath + ".feedback");
                FileWriter fw = new FileWriter(file);
                fw.write(feedback);
                fw.close();
            }
        } catch (Exception e) {
        }
    }

    private void markReportUploaded(String filePath) {
        try {
            if (filePath != null && !filePath.isEmpty()) {
                File oldFile = new File(filePath);
                File newFile = new File(filePath.replace(".crash", "_uploaded.crash"));
                oldFile.renameTo(newFile);
            }
        } catch (Exception e) {
        }
    }

    private void cleanupOldReports() {
        try {
            File dir = new File(crashLogDir);
            File[] files = dir.listFiles((d, name) -> name.endsWith(".crash"));
            if (files == null || files.length <= MAX_CRASH_LOGS) return;
            List<File> fileList = new ArrayList<>();
            for (File f : files) fileList.add(f);
            fileList.sort((a, b) -> Long.compare(a.lastModified(), b.lastModified()));
            while (fileList.size() > MAX_CRASH_LOGS) {
                File oldest = fileList.remove(0);
                oldest.delete();
            }
        } catch (Exception e) {
        }
    }

    private Map<String, String> collectDeviceInfo() {
        Map<String, String> info = new HashMap<>();
        try {
            info.put("board", Build.BOARD);
            info.put("bootloader", Build.BOOTLOADER);
            info.put("brand", Build.BRAND);
            info.put("cpu_abi", Build.CPU_ABI);
            info.put("cpu_abi2", Build.CPU_ABI2);
            info.put("device", Build.DEVICE);
            info.put("display", Build.DISPLAY);
            info.put("fingerprint", Build.FINGERPRINT);
            info.put("hardware", Build.HARDWARE);
            info.put("host", Build.HOST);
            info.put("id", Build.ID);
            info.put("manufacturer", Build.MANUFACTURER);
            info.put("model", Build.MODEL);
            info.put("product", Build.PRODUCT);
            info.put("serial", Build.SERIAL);
            info.put("tags", Build.TAGS);
            info.put("type", Build.TYPE);
            info.put("user", Build.USER);
            info.put("sdk_int", String.valueOf(Build.VERSION.SDK_INT));
            info.put("release", Build.VERSION.RELEASE);
            info.put("base_os", Build.VERSION.BASE_OS);
            info.put("security_patch", Build.VERSION.SECURITY_PATCH);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                info.put("abi_list", String.join(", ", Build.SUPPORTED_ABIS));
            }
            PackageManager pm = context.getPackageManager();
            try {
                PackageInfo pi = pm.getPackageInfo(context.getPackageName(), 0);
                info.put("package_name", context.getPackageName());
                info.put("version_name", pi.versionName);
                info.put("version_code", String.valueOf(pi.versionCode));
                info.put("first_install", new SimpleDateFormat("yyyy-MM-dd", Locale.US)
                    .format(new Date(pi.firstInstallTime)));
                info.put("last_update", new SimpleDateFormat("yyyy-MM-dd", Locale.US)
                    .format(new Date(pi.lastUpdateTime)));
            } catch (Exception e) {
            }
            WindowManager wm = (WindowManager)
                context.getSystemService(Context.WINDOW_SERVICE);
            if (wm != null) {
                Display display = wm.getDefaultDisplay();
                DisplayMetrics dm = new DisplayMetrics();
                display.getMetrics(dm);
                info.put("screen_width", String.valueOf(dm.widthPixels));
                info.put("screen_height", String.valueOf(dm.heightPixels));
                info.put("screen_density", String.valueOf(dm.densityDpi));
            }
            info.put("android_id", Utils.getMaskedAndroidId());
            long totalMem = Runtime.getRuntime().totalMemory();
            long freeMem = Runtime.getRuntime().freeMemory();
            long maxMem = Runtime.getRuntime().maxMemory();
            info.put("total_memory", String.valueOf(totalMem));
            info.put("free_memory", String.valueOf(freeMem));
            info.put("max_memory", String.valueOf(maxMem));
            info.put("available_processors", String.valueOf(Runtime.getRuntime().availableProcessors()));
            info.put("heap_size", String.valueOf(Runtime.getRuntime().totalMemory() / 1048576) + "MB");
            info.put("heap_free", String.valueOf(Runtime.getRuntime().freeMemory() / 1048576) + "MB");
            info.put("heap_max", String.valueOf(Runtime.getRuntime().maxMemory() / 1048576) + "MB");
        } catch (Exception e) {
        }
        return info;
    }

    private String collectLogcat() {
        try {
            java.lang.Process p = Runtime.getRuntime().exec(
                "logcat -d -t 200 *:V");
            BufferedReader br = new BufferedReader(
                new InputStreamReader(p.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                if (sb.length() > 65536) {
                    sb.append("... [truncated]");
                    break;
                }
                sb.append(line).append("\n");
            }
            br.close();
            return sb.toString();
        } catch (Exception e) {
            return "Unable to collect logcat: " + e.getMessage();
        }
    }

    private String getStackTraceString(Throwable throwable) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        throwable.printStackTrace(pw);
        Throwable cause = throwable.getCause();
        while (cause != null) {
            cause.printStackTrace(pw);
            cause = cause.getCause();
        }
        pw.close();
        return sw.toString();
    }

    private String buildReportJson(CrashReport report) {
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        sb.append("\"id\":\"").append(escapeJson(report.id)).append("\",");
        sb.append("\"timestamp\":\"").append(escapeJson(report.timestamp)).append("\",");
        sb.append("\"app_version\":\"").append(escapeJson(report.appVersion)).append("\",");
        sb.append("\"android_version\":\"").append(escapeJson(report.androidVersion)).append("\",");
        sb.append("\"device_model\":\"").append(escapeJson(report.deviceModel)).append("\",");
        sb.append("\"manufacturer\":\"").append(escapeJson(report.manufacturer)).append("\",");
        sb.append("\"thread_name\":\"").append(escapeJson(report.threadName)).append("\",");
        sb.append("\"stack_trace\":\"").append(escapeJson(report.stackTrace)).append("\"");
        if (report.deviceInfo != null && !report.deviceInfo.isEmpty()) {
            sb.append(",\"device_info\":{");
            boolean first = true;
            for (Map.Entry<String, String> entry : report.deviceInfo.entrySet()) {
                if (!first) sb.append(",");
                sb.append("\"").append(escapeJson(entry.getKey())).append("\":\"")
                    .append(escapeJson(entry.getValue())).append("\"");
                first = false;
            }
            sb.append("}");
        }
        if (report.customData != null && !report.customData.isEmpty()) {
            sb.append(",\"custom_data\":{");
            boolean first = true;
            for (Map.Entry<String, String> entry : report.customData.entrySet()) {
                if (!first) sb.append(",");
                sb.append("\"").append(escapeJson(entry.getKey())).append("\":\"")
                    .append(escapeJson(entry.getValue())).append("\"");
                first = false;
            }
            sb.append("}");
        }
        if (report.logcat != null) {
            sb.append(",\"logcat\":\"").append(escapeJson(report.logcat)).append("\"");
        }
        sb.append("}");
        return sb.toString();
    }

    private String escapeJson(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t");
    }

    private CrashReport parseReportFromFile(String content, String filePath) {
        try {
            CrashReport report = new CrashReport();
            report.filePath = filePath;
            for (String line : content.split("\n")) {
                if (line.startsWith("ID: ")) report.id = line.substring(4);
                else if (line.startsWith("Timestamp: ")) report.timestamp = line.substring(11);
                else if (line.startsWith("App Version: ")) report.appVersion = line.substring(13);
                else if (line.startsWith("Android: ")) report.androidVersion = line.substring(9);
                else if (line.startsWith("Device: ")) report.deviceModel = line.substring(8);
                else if (line.startsWith("Manufacturer: ")) report.manufacturer = line.substring(14);
                else if (line.startsWith("Thread: ")) report.threadName = line.substring(8);
            }
            report.stackTrace = content;
            report.deviceInfo = new HashMap<>();
            report.customData = new HashMap<>(customKeys);
            return report;
        } catch (Exception e) {
            return null;
        }
    }

    private byte[] encryptReport(byte[] data) {
        try {
            byte[] key = new byte[16];
            byte[] iv = new byte[16];
            String hwid = Utils.getMaskedAndroidId();
            byte[] hwidBytes = hwid.getBytes("UTF-8");
            System.arraycopy(hwidBytes, 0, key, 0, Math.min(hwidBytes.length, 16));
            new java.security.SecureRandom().nextBytes(iv);
            SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
            javax.crypto.spec.IvParameterSpec ivSpec = new javax.crypto.spec.IvParameterSpec(iv);
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);
            byte[] encrypted = cipher.doFinal(data);
            byte[] result = new byte[iv.length + encrypted.length];
            System.arraycopy(iv, 0, result, 0, iv.length);
            System.arraycopy(encrypted, 0, result, iv.length, encrypted.length);
            return result;
        } catch (Exception e) {
            return data;
        }
    }

    private byte[] decryptReport(byte[] data) {
        try {
            if (data.length < 32) return data;
            byte[] key = new byte[16];
            byte[] iv = new byte[16];
            String hwid = Utils.getMaskedAndroidId();
            byte[] hwidBytes = hwid.getBytes("UTF-8");
            System.arraycopy(hwidBytes, 0, key, 0, Math.min(hwidBytes.length, 16));
            System.arraycopy(data, 0, iv, 0, 16);
            byte[] encrypted = new byte[data.length - 16];
            System.arraycopy(data, 16, encrypted, 0, encrypted.length);
            SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
            javax.crypto.spec.IvParameterSpec ivSpec = new javax.crypto.spec.IvParameterSpec(iv);
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec);
            return cipher.doFinal(encrypted);
        } catch (Exception e) {
            return data;
        }
    }

    private String generateReportId() {
        return UUID.randomUUID().toString().replace("-", "").substring(0, 16);
    }

    private String getCurrentTimestamp() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        return sdf.format(new Date());
    }

    private void initAppInfo() {
        try {
            PackageInfo pi = context.getPackageManager()
                .getPackageInfo(context.getPackageName(), 0);
            appVersion = pi.versionName;
            appBuild = String.valueOf(pi.versionCode);
        } catch (Exception e) {
            appVersion = "unknown";
            appBuild = "0";
        }
    }

    private Activity getCurrentActivity() {
        try {
            Class<?> activityThreadClass = Class.forName("android.app.ActivityThread");
            Method currentActivityThread = activityThreadClass.getMethod("currentActivityThread");
            Object activityThread = currentActivityThread.invoke(null);
            Field activitiesField = activityThreadClass.getDeclaredField("mActivities");
            activitiesField.setAccessible(true);
            Object activities = activitiesField.get(activityThread);
            if (activities instanceof Map) {
                Map<?, ?> activitiesMap = (Map<?, ?>) activities;
                for (Object record : activitiesMap.values()) {
                    Class<?> recordClass = record.getClass();
                    Field pausedField = recordClass.getDeclaredField("paused");
                    pausedField.setAccessible(true);
                    if (!pausedField.getBoolean(record)) {
                        Field activityField = recordClass.getDeclaredField("activity");
                        activityField.setAccessible(true);
                        return (Activity) activityField.get(record);
                    }
                }
            }
        } catch (Exception e) {
        }
        return null;
    }

    public void setCrashReportUrl(String url) {
        this.crashReportUrl = url;
    }

    public void setAutoUpload(boolean autoUpload) {
        this.autoUpload = autoUpload;
    }

    public void setShowDialog(boolean showDialog) {
        this.showDialog = showDialog;
    }

    public void setCollectLogcat(boolean collect) {
        this.collectLogcat = collect;
    }

    public void setUserId(String userId) {
        this.userId = userId;
        customKeys.put("user_id", userId);
    }

    public void addCustomKey(String key, String value) {
        customKeys.put(key, value);
    }

    public void removeCustomKey(String key) {
        customKeys.remove(key);
    }

    public void addListener(CrashListener listener) {
        listeners.add(listener);
    }

    public void removeListener(CrashListener listener) {
        listeners.remove(listener);
    }

    public int getCrashCount() {
        return crashCount.get();
    }

    public int getPendingReportCount() {
        File dir = new File(crashLogDir);
        File[] files = dir.listFiles((d, name) -> name.endsWith(".crash") &&
            !name.contains("_uploaded"));
        return files != null ? files.length : 0;
    }

    public List<CrashReport> getPendingReports() {
        List<CrashReport> reports = new ArrayList<>();
        File dir = new File(crashLogDir);
        File[] files = dir.listFiles((d, name) -> name.endsWith(".crash"));
        if (files == null) return reports;
        for (File file : files) {
            try {
                FileInputStream fis = new FileInputStream(file);
                byte[] encrypted = new byte[(int) file.length()];
                fis.read(encrypted);
                fis.close();
                byte[] decrypted = decryptReport(encrypted);
                String content = new String(decrypted, "UTF-8");
                CrashReport report = parseReportFromFile(content, file.getAbsolutePath());
                if (report != null) reports.add(report);
            } catch (Exception e) {
            }
        }
        return reports;
    }

    public void deleteAllReports() {
        File dir = new File(crashLogDir);
        File[] files = dir.listFiles();
        if (files != null) {
            for (File f : files) f.delete();
        }
    }

    public void destroy() {
        if (anrWatchdog != null) anrWatchdog.cancel(false);
        executor.shutdownNow();
        scheduler.shutdownNow();
        instance = null;
    }
}
