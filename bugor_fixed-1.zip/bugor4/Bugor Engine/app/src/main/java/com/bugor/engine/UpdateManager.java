package com.bugor.engine;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.util.Base64;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

public class UpdateManager {
    private static volatile UpdateManager instance;
    private Context context;
    private ExecutorService executor = Executors.newFixedThreadPool(3);
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private AtomicBoolean isChecking = new AtomicBoolean(false);
    private AtomicBoolean isDownloading = new AtomicBoolean(false);
    private AtomicLong downloadProgress = new AtomicLong(0);
    private AtomicLong downloadTotal = new AtomicLong(0);
    private String updateServerUrl = "https://update.bugor-engine.com";
    private String versionCheckEndpoint = "/version.json";
    private String downloadEndpoint = "/download";
    private String currentVersion = "";
    private int currentVersionCode = 0;
    private String updateVersion = "";
    private int updateVersionCode = 0;
    private String downloadUrl = "";
    private String updateChangelog = "";
    private long updateSize = 0;
    private String updateChecksum = "";
    private String updateSignature = "";
    private boolean forceUpdate = false;
    private boolean incrementalUpdate = false;
    private String patchUrl = "";
    private long patchSize = 0;
    private String patchChecksum = "";
    private List<UpdateListener> listeners = new ArrayList<>();
    private Map<String, UpdateCheckCallback> pendingCallbacks = new HashMap<>();
    private static final String UPDATE_DIR = "updates";
    private static final String PATCH_DIR = "patches";
    private static final String DOWNLOAD_FILE = "update.apk";
    private static final String PATCH_FILE = "update.patch";
    private static final String METADATA_FILE = "update_metadata.json";
    private static final long DOWNLOAD_TIMEOUT = 300000L;
    private static final int MAX_DOWNLOAD_RETRIES = 3;
    private static final int BUFFER_SIZE = 32768;

    public interface UpdateListener {
        void onUpdateAvailable(String version, String changelog, boolean force);
        void onUpdateNotAvailable();
        void onDownloadStarted(long totalSize);
        void onDownloadProgress(long downloaded, long total);
        void onDownloadCompleted(File apkFile);
        void onDownloadFailed(String error);
        void onVerificationStarted();
        void onVerificationPassed();
        void onVerificationFailed(String reason);
        void onInstallStarted();
        void onInstallCompleted();
        void onInstallFailed(String error);
    }

    public interface UpdateCheckCallback {
        void onResult(boolean available, String version, String changelog, boolean force);
        void onError(String error);
    }

    public static class UpdateInfo {
        public String versionName;
        public int versionCode;
        public String downloadUrl;
        public long fileSize;
        public String checksumSha256;
        public String signature;
        public String changelog;
        public boolean forceUpdate;
        public boolean incremental;
        public String patchUrl;
        public long patchSize;
        public String patchChecksum;
        public String minSdkVersion;
        public String targetSdkVersion;
        public Map<String, String> metadata;
    }

    public static class UpdateException extends Exception {
        public UpdateException(String message) { super(message); }
        public UpdateException(String message, Throwable cause) { super(message, cause); }
    }

    private UpdateManager(Context context) {
        this.context = context.getApplicationContext();
        initVersionInfo();
        File updateDir = new File(context.getFilesDir(), UPDATE_DIR);
        updateDir.mkdirs();
        File patchDir = new File(context.getFilesDir(), PATCH_DIR);
        patchDir.mkdirs();
    }

    public static UpdateManager getInstance(Context context) {
        if (instance == null) {
            synchronized (UpdateManager.class) {
                if (instance == null) {
                    instance = new UpdateManager(context);
                }
            }
        }
        return instance;
    }

    private void initVersionInfo() {
        try {
            PackageInfo pi = context.getPackageManager()
                .getPackageInfo(context.getPackageName(), 0);
            currentVersion = pi.versionName;
            currentVersionCode = pi.versionCode;
        } catch (Exception e) {
            currentVersion = "1.0";
            currentVersionCode = 1;
        }
    }

    public void checkForUpdate(UpdateCheckCallback callback) {
        if (isChecking.getAndSet(true)) {
            if (callback != null)
                callback.onError("Already checking for updates");
            return;
        }
        executor.submit(() -> {
            try {
                UpdateInfo info = fetchVersionInfo();
                if (info != null && info.versionCode > currentVersionCode) {
                    updateVersion = info.versionName;
                    updateVersionCode = info.versionCode;
                    downloadUrl = info.downloadUrl;
                    updateSize = info.fileSize;
                    updateChecksum = info.checksumSha256;
                    updateSignature = info.signature;
                    updateChangelog = info.changelog;
                    forceUpdate = info.forceUpdate;
                    incrementalUpdate = info.incremental;
                    patchUrl = info.patchUrl;
                    patchSize = info.patchSize;
                    patchChecksum = info.patchChecksum;
                    mainHandler.post(() -> {
                        isChecking.set(false);
                        notifyUpdateAvailable();
                        if (callback != null)
                            callback.onResult(true, updateVersion, updateChangelog, forceUpdate);
                    });
                } else {
                    mainHandler.post(() -> {
                        isChecking.set(false);
                        notifyUpdateNotAvailable();
                        if (callback != null)
                            callback.onResult(false, "", "", false);
                    });
                }
            } catch (Exception e) {
                mainHandler.post(() -> {
                    isChecking.set(false);
                    if (callback != null)
                        callback.onError("Check failed: " + e.getMessage());
                });
            }
        });
    }

    public void downloadUpdate() {
        if (isDownloading.getAndSet(true)) return;
        executor.submit(() -> {
            try {
                File updateDir = new File(context.getFilesDir(), UPDATE_DIR);
                File apkFile = new File(updateDir, DOWNLOAD_FILE);
                notifyDownloadStarted(updateSize);
                boolean success = false;
                int retries = 0;
                while (retries < MAX_DOWNLOAD_RETRIES && !success) {
                    try {
                        success = downloadWithResume(downloadUrl, apkFile, updateSize);
                    } catch (Exception e) {
                        retries++;
                        if (retries >= MAX_DOWNLOAD_RETRIES) {
                            throw e;
                        }
                        Thread.sleep(2000L * retries);
                    }
                }
                if (success) {
                    mainHandler.post(() -> {
                        downloadTotal.set(updateSize);
                        downloadProgress.set(updateSize);
                        notifyDownloadProgress(updateSize, updateSize);
                        notifyDownloadCompleted(apkFile);
                        isDownloading.set(false);
                    });
                } else {
                    throw new UpdateException("Download failed after " +
                        MAX_DOWNLOAD_RETRIES + " retries");
                }
            } catch (Exception e) {
                mainHandler.post(() -> {
                    notifyDownloadFailed(e.getMessage());
                    isDownloading.set(false);
                });
            }
        });
    }

    public void verifyAndInstall(File apkFile) {
        executor.submit(() -> {
            try {
                mainHandler.post(this::notifyVerificationStarted);
                if (!verifyChecksum(apkFile, updateChecksum)) {
                    mainHandler.post(() -> notifyVerificationFailed(
                        "Checksum mismatch"));
                    return;
                }
                if (!verifySignature(apkFile, updateSignature)) {
                    mainHandler.post(() -> notifyVerificationFailed(
                        "Signature verification failed"));
                    return;
                }
                mainHandler.post(this::notifyVerificationPassed);
                mainHandler.post(this::notifyInstallStarted);
                boolean installed = installApk(apkFile);
                mainHandler.post(() -> {
                    if (installed) {
                        notifyInstallCompleted();
                    } else {
                        notifyInstallFailed("Installation failed");
                    }
                });
            } catch (Exception e) {
                mainHandler.post(() -> notifyInstallFailed(e.getMessage()));
            }
        });
    }

    public void applyIncrementalUpdate() {
        executor.submit(() -> {
            try {
                File patchDir = new File(context.getFilesDir(), PATCH_DIR);
                File patchFile = new File(patchDir, PATCH_FILE);
                if (!downloadWithResume(patchUrl, patchFile, patchSize)) {
                    mainHandler.post(() -> notifyDownloadFailed("Patch download failed"));
                    return;
                }
                if (!verifyChecksum(patchFile, patchChecksum)) {
                    mainHandler.post(() -> notifyVerificationFailed("Patch checksum mismatch"));
                    return;
                }
                File updateDir = new File(context.getFilesDir(), UPDATE_DIR);
                File outputApk = new File(updateDir, "updated.apk");
                applyPatch(patchFile, outputApk);
                verifyAndInstall(outputApk);
            } catch (Exception e) {
                mainHandler.post(() -> notifyInstallFailed(e.getMessage()));
            }
        });
    }

    private UpdateInfo fetchVersionInfo() throws UpdateException {
        try {
            URL url = new URL(updateServerUrl + versionCheckEndpoint +
                "?version=" + currentVersionCode + "&pkg=" +
                context.getPackageName());
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(15000);
            conn.setRequestProperty("X-Device-ID", Utils.getDeviceId());
            int code = conn.getResponseCode();
            if (code != 200) {
                throw new UpdateException("Server returned " + code);
            }
            BufferedReader br = new BufferedReader(
                new InputStreamReader(conn.getInputStream(), "UTF-8"));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) response.append(line);
            br.close();
            conn.disconnect();
            return parseUpdateJson(response.toString());
        } catch (UpdateException e) {
            throw e;
        } catch (Exception e) {
            throw new UpdateException("Failed to fetch version info", e);
        }
    }

    private UpdateInfo parseUpdateJson(String json) {
        try {
            UpdateInfo info = new UpdateInfo();
            Map<String, String> map = parseJsonToMap(json);
            info.versionName = map.get("version_name");
            info.versionCode = Integer.parseInt(map.get("version_code"));
            info.downloadUrl = map.get("download_url");
            info.fileSize = Long.parseLong(map.getOrDefault("file_size", "0"));
            info.checksumSha256 = map.get("checksum_sha256");
            info.signature = map.get("signature");
            info.changelog = map.get("changelog");
            info.forceUpdate = "true".equals(map.get("force_update"));
            info.incremental = "true".equals(map.get("incremental"));
            info.patchUrl = map.get("patch_url");
            info.patchSize = Long.parseLong(map.getOrDefault("patch_size", "0"));
            info.patchChecksum = map.get("patch_checksum");
            info.minSdkVersion = map.get("min_sdk");
            info.targetSdkVersion = map.get("target_sdk");
            info.metadata = map;
            return info;
        } catch (Exception e) {
            return null;
        }
    }

    private Map<String, String> parseJsonToMap(String json) {
        Map<String, String> map = new HashMap<>();
        try {
            String cleaned = json.trim();
            if (cleaned.startsWith("{")) cleaned = cleaned.substring(1);
            if (cleaned.endsWith("}")) cleaned = cleaned.substring(0, cleaned.length() - 1);
            String[] pairs = splitTopLevel(cleaned);
            for (String pair : pairs) {
                int colonIdx = pair.indexOf(':');
                if (colonIdx > 0) {
                    String key = pair.substring(0, colonIdx).trim();
                    String value = pair.substring(colonIdx + 1).trim();
                    key = key.replaceAll("^\"|\"$", "");
                    value = value.replaceAll("^\"|\"$", "");
                    map.put(key, value);
                }
            }
        } catch (Exception e) {
        }
        return map;
    }

    private String[] splitTopLevel(String json) {
        List<String> parts = new ArrayList<>();
        int depth = 0;
        boolean inStr = false;
        StringBuilder sb = new StringBuilder();
        for (char c : json.toCharArray()) {
            if (c == '"' && (sb.length() == 0 || sb.charAt(sb.length() - 1) != '\\')) {
                inStr = !inStr;
            }
            if (!inStr) {
                if (c == '{' || c == '[') depth++;
                if (c == '}' || c == ']') depth--;
                if (c == ',' && depth == 0) {
                    parts.add(sb.toString());
                    sb = new StringBuilder();
                    continue;
                }
            }
            sb.append(c);
        }
        if (sb.length() > 0) parts.add(sb.toString());
        return parts.toArray(new String[0]);
    }

    private boolean downloadWithResume(String urlStr, File destination, long expectedSize)
            throws Exception {
        HttpURLConnection conn = null;
        RandomAccessFile raf = null;
        InputStream is = null;
        try {
            long existingSize = 0;
            if (destination.exists()) {
                existingSize = destination.length();
                if (existingSize >= expectedSize && expectedSize > 0) {
                    return true;
                }
            }
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(0);
            conn.setRequestProperty("Accept-Encoding", "identity");
            if (existingSize > 0) {
                conn.setRequestProperty("Range", "bytes=" + existingSize + "-");
            }
            int code = conn.getResponseCode();
            boolean resume = code == HttpURLConnection.HTTP_PARTIAL;
            long contentLength = conn.getContentLengthLong();
            if (!resume && existingSize > 0) {
                destination.delete();
                existingSize = 0;
                conn.disconnect();
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(0);
                code = conn.getResponseCode();
                contentLength = conn.getContentLengthLong();
            }
            is = conn.getInputStream();
            raf = new RandomAccessFile(destination, "rw");
            if (resume) raf.seek(existingSize);
            byte[] buffer = new byte[BUFFER_SIZE];
            int read;
            long totalRead = existingSize;
            long lastNotify = 0;
            while ((read = is.read(buffer)) != -1) {
                raf.write(buffer, 0, read);
                totalRead += read;
                if (totalRead - lastNotify > 262144) {
                    lastNotify = totalRead;
                    downloadProgress.set(totalRead);
                    if (expectedSize > 0) downloadTotal.set(expectedSize);
                    else downloadTotal.set(contentLength);
                    mainHandler.post(() -> {
                        long prog = downloadProgress.get();
                        long total = downloadTotal.get();
                        notifyDownloadProgress(prog, total > 0 ? total : prog);
                    });
                }
            }
            raf.close();
            is.close();
            conn.disconnect();
            downloadProgress.set(totalRead);
            downloadTotal.set(totalRead);
            return true;
        } catch (Exception e) {
            throw e;
        } finally {
            try { if (raf != null) raf.close(); } catch (Exception e) {}
            try { if (is != null) is.close(); } catch (Exception e) {}
            if (conn != null) conn.disconnect();
        }
    }

    private boolean verifyChecksum(File file, String expectedSha256) {
        try {
            if (expectedSha256 == null || expectedSha256.isEmpty()) return true;
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            FileInputStream fis = new FileInputStream(file);
            byte[] buffer = new byte[8192];
            int read;
            while ((read = fis.read(buffer)) != -1) {
                md.update(buffer, 0, read);
            }
            fis.close();
            byte[] hash = md.digest();
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) hex.append(String.format("%02x", b & 0xFF));
            return expectedSha256.equalsIgnoreCase(hex.toString());
        } catch (Exception e) {
            return false;
        }
    }

    private boolean verifySignature(File apkFile, String expectedSignature) {
        try {
            if (expectedSignature == null || expectedSignature.isEmpty()) return true;
            PackageManager pm = context.getPackageManager();
            PackageInfo pi = pm.getPackageArchiveInfo(
                apkFile.getAbsolutePath(),
                PackageManager.GET_SIGNATURES);
            if (pi == null || pi.signatures == null || pi.signatures.length == 0) {
                return false;
            }
            Signature sig = pi.signatures[0];
            byte[] certBytes = sig.toByteArray();
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            X509Certificate cert = (X509Certificate)
                cf.generateCertificate(new ByteArrayInputStream(certBytes));
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] certHash = md.digest(cert.getEncoded());
            StringBuilder hex = new StringBuilder();
            for (byte b : certHash) hex.append(String.format("%02x", b & 0xFF));
            return expectedSignature.equalsIgnoreCase(hex.toString());
        } catch (Exception e) {
            return false;
        }
    }

    private boolean installApk(File apkFile) {
        try {
            if (Utils.isRoot()) {
                return installRoot(apkFile);
            } else {
                return installNonRoot(apkFile);
            }
        } catch (Exception e) {
            return false;
        }
    }

    private boolean installRoot(File apkFile) {
        try {
            String apkPath = apkFile.getAbsolutePath();
            java.lang.Process p = Runtime.getRuntime().exec("su");
            java.io.DataOutputStream dos = new java.io.DataOutputStream(p.getOutputStream());
            dos.writeBytes("pm install -r " + apkPath + "\n");
            dos.writeBytes("exit\n");
            dos.flush();
            p.waitFor();
            BufferedReader br = new BufferedReader(
                new InputStreamReader(p.getInputStream()));
            String line;
            StringBuilder result = new StringBuilder();
            while ((line = br.readLine()) != null) result.append(line);
            br.close();
            return result.toString().contains("Success");
        } catch (Exception e) {
            return false;
        }
    }

    private boolean installNonRoot(File apkFile) {
        try {
            Uri uri = Uri.fromFile(apkFile);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "application/vnd.android.package-archive");
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                Intent.FLAG_GRANT_READ_URI_PERMISSION);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                uri = FileProvider.getUriForFile(context,
                    context.getPackageName() + ".fileprovider", apkFile);
                intent.setDataAndType(uri, "application/vnd.android.package-archive");
                intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                    Intent.FLAG_ACTIVITY_NEW_TASK);
            }
            context.startActivity(intent);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void applyPatch(File patchFile, File outputApk) {
        try {
            File baseApk = new File(context.getApplicationInfo().sourceDir);
            FileInputStream baseIs = new FileInputStream(baseApk);
            FileInputStream patchIs = new FileInputStream(patchFile);
            FileOutputStream outputOs = new FileOutputStream(outputApk);
            byte[] baseBuffer = new byte[BUFFER_SIZE];
            byte[] patchBuffer = new byte[BUFFER_SIZE];
            int baseRead;
            int patchRead;
            while ((patchRead = patchIs.read(patchBuffer)) != -1) {
                outputOs.write(patchBuffer, 0, patchRead);
            }
            while ((baseRead = baseIs.read(baseBuffer)) != -1) {
                outputOs.write(baseBuffer, 0, baseRead);
            }
            baseIs.close();
            patchIs.close();
            outputOs.close();
        } catch (Exception e) {
            throw new RuntimeException("Patch application failed", e);
        }
    }

    public void showUpdateDialog(Activity activity) {
        if (activity == null || activity.isFinishing()) return;
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("Update Available v" + updateVersion);
        builder.setMessage(updateChangelog != null && !updateChangelog.isEmpty() ?
            updateChangelog : "A new version is available. Would you like to update?");
        builder.setPositiveButton("Update", (DialogInterface dialog, int which) -> {
            dialog.dismiss();
            downloadUpdate();
        });
        if (!forceUpdate) {
            builder.setNegativeButton("Later", (DialogInterface dialog, int which) -> {
                dialog.dismiss();
            });
        }
        builder.setCancelable(!forceUpdate);
        builder.show();
    }

    public void showForceUpdateDialog(Activity activity) {
        if (activity == null || activity.isFinishing()) return;
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("Update Required");
        builder.setMessage("A mandatory update is required to continue using this application.\n\n" +
            "Current: v" + currentVersion + "\nNew: v" + updateVersion + "\n\n" +
            (updateChangelog != null ? updateChangelog : ""));
        builder.setPositiveButton("Update Now", (DialogInterface dialog, int which) -> {
            dialog.dismiss();
            downloadUpdate();
        });
        builder.setCancelable(false);
        builder.show();
    }

    public void showDownloadProgressDialog(Activity activity) {
        if (activity == null || activity.isFinishing()) return;
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("Downloading Update");
        builder.setCancelable(false);
        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 40, 40, 40);
        ProgressBar progressBar = new ProgressBar(activity, null,
            android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        layout.addView(progressBar);
        final TextView statusText = new TextView(activity);
        statusText.setText("Starting download...");
        statusText.setPadding(0, 20, 0, 0);
        layout.addView(statusText);
        builder.setView(layout);
        final AlertDialog dialog = builder.show();
        addListener(new UpdateListener() {
            public void onDownloadStarted(long total) {}
            public void onDownloadProgress(long downloaded, long total) {
                int percent = total > 0 ? (int) (downloaded * 100 / total) : 0;
                progressBar.setProgress(percent);
                statusText.setText("Downloading... " + formatSize(downloaded) +
                    " / " + formatSize(total));
            }
            public void onDownloadCompleted(File apk) {
                dialog.dismiss();
                verifyAndInstall(apk);
            }
            public void onDownloadFailed(String error) {
                dialog.dismiss();
                Toast.makeText(activity, "Download failed: " + error,
                    Toast.LENGTH_LONG).show();
            }
            public void onUpdateAvailable(String v, String c, boolean f) {}
            public void onUpdateNotAvailable() {}
            public void onVerificationStarted() {}
            public void onVerificationPassed() {}
            public void onVerificationFailed(String reason) {
                Toast.makeText(activity, "Verification failed: " + reason,
                    Toast.LENGTH_LONG).show();
            }
            public void onInstallStarted() {}
            public void onInstallCompleted() {}
            public void onInstallFailed(String error) {
                Toast.makeText(activity, "Install failed: " + error,
                    Toast.LENGTH_LONG).show();
            }
        });
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1048576) return String.format(Locale.US, "%.1f KB", bytes / 1024.0);
        if (bytes < 1073741824) return String.format(Locale.US, "%.1f MB", bytes / 1048576.0);
        return String.format(Locale.US, "%.1f GB", bytes / 1073741824.0);
    }

    public void checkAndUpdate(Activity activity) {
        checkForUpdate(new UpdateCheckCallback() {
            public void onResult(boolean available, String version, String changelog, boolean force) {
                if (available) {
                    if (force) {
                        showForceUpdateDialog(activity);
                    } else {
                        showUpdateDialog(activity);
                    }
                } else {
                    Toast.makeText(activity, "You have the latest version",
                        Toast.LENGTH_SHORT).show();
                }
            }
            public void onError(String error) {
                Toast.makeText(activity, "Update check failed: " + error,
                    Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void setUpdateServerUrl(String url) {
        this.updateServerUrl = url;
    }

    public void setVersionCheckEndpoint(String endpoint) {
        this.versionCheckEndpoint = endpoint;
    }

    public void setDownloadEndpoint(String endpoint) {
        this.downloadEndpoint = endpoint;
    }

    public String getCurrentVersion() {
        return currentVersion;
    }

    public int getCurrentVersionCode() {
        return currentVersionCode;
    }

    public String getUpdateVersion() {
        return updateVersion;
    }

    public int getUpdateVersionCode() {
        return updateVersionCode;
    }

    public boolean isUpdateAvailable() {
        return updateVersionCode > currentVersionCode;
    }

    public boolean isForceUpdate() {
        return forceUpdate;
    }

    public boolean isDownloading() {
        return isDownloading.get();
    }

    public boolean isChecking() {
        return isChecking.get();
    }

    public long getDownloadProgress() {
        return downloadProgress.get();
    }

    public long getDownloadTotal() {
        return downloadTotal.get();
    }

    public int getDownloadPercent() {
        long total = downloadTotal.get();
        return total > 0 ? (int) (downloadProgress.get() * 100 / total) : 0;
    }

    public void addListener(UpdateListener listener) {
        listeners.add(listener);
    }

    public void removeListener(UpdateListener listener) {
        listeners.remove(listener);
    }

    public void clearListeners() {
        listeners.clear();
    }

    private void notifyUpdateAvailable() {
        for (UpdateListener l : listeners) {
            try { l.onUpdateAvailable(updateVersion, updateChangelog, forceUpdate); } catch (Exception e) {}
        }
    }

    private void notifyUpdateNotAvailable() {
        for (UpdateListener l : listeners) {
            try { l.onUpdateNotAvailable(); } catch (Exception e) {}
        }
    }

    private void notifyDownloadStarted(long totalSize) {
        for (UpdateListener l : listeners) {
            try { l.onDownloadStarted(totalSize); } catch (Exception e) {}
        }
    }

    private void notifyDownloadProgress(long downloaded, long total) {
        for (UpdateListener l : listeners) {
            try { l.onDownloadProgress(downloaded, total); } catch (Exception e) {}
        }
    }

    private void notifyDownloadCompleted(File apkFile) {
        for (UpdateListener l : listeners) {
            try { l.onDownloadCompleted(apkFile); } catch (Exception e) {}
        }
    }

    private void notifyDownloadFailed(String error) {
        for (UpdateListener l : listeners) {
            try { l.onDownloadFailed(error); } catch (Exception e) {}
        }
    }

    private void notifyVerificationStarted() {
        for (UpdateListener l : listeners) {
            try { l.onVerificationStarted(); } catch (Exception e) {}
        }
    }

    private void notifyVerificationPassed() {
        for (UpdateListener l : listeners) {
            try { l.onVerificationPassed(); } catch (Exception e) {}
        }
    }

    private void notifyVerificationFailed(String reason) {
        for (UpdateListener l : listeners) {
            try { l.onVerificationFailed(reason); } catch (Exception e) {}
        }
    }

    private void notifyInstallStarted() {
        for (UpdateListener l : listeners) {
            try { l.onInstallStarted(); } catch (Exception e) {}
        }
    }

    private void notifyInstallCompleted() {
        for (UpdateListener l : listeners) {
            try { l.onInstallCompleted(); } catch (Exception e) {}
        }
    }

    private void notifyInstallFailed(String error) {
        for (UpdateListener l : listeners) {
            try { l.onInstallFailed(error); } catch (Exception e) {}
        }
    }

    public void cleanup() {
        File updateDir = new File(context.getFilesDir(), UPDATE_DIR);
        File patchDir = new File(context.getFilesDir(), PATCH_DIR);
        deleteDirectory(updateDir);
        deleteDirectory(patchDir);
    }

    private void deleteDirectory(File dir) {
        if (dir == null || !dir.exists()) return;
        File[] files = dir.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isDirectory()) deleteDirectory(f);
                else f.delete();
            }
        }
        dir.delete();
    }

    public void destroy() {
        executor.shutdownNow();
        instance = null;
    }
}
