package com.bugor.engine;

import android.content.Context;
import android.util.Log;

import com.topjohnwu.superuser.CallbackList;
import com.topjohnwu.superuser.Shell;
import com.topjohnwu.superuser.ShellUtils;
import com.topjohnwu.superuser.nio.FileSystemManager;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.regex.Pattern;

public class RootShell {
    private static final String TAG = "BugorRoot";
    private static volatile RootShell instance;
    private Context context;
    private Shell shell;
    private boolean rootAvailable;
    private boolean busyboxAvailable;
    private ExecutorService executor;
    private ConcurrentHashMap<String, long[]> pidCache;
    private long lastShellRefresh;
    private static final long SHELL_REFRESH_INTERVAL = 300000L;
    private static final Pattern SAFE_ARG_PATTERN = Pattern.compile("[a-zA-Z0-9_./:=+\\-]+");

    public interface ShellCallback {
        void onResult(int exitCode, String output);
        void onError(String error);
    }

    public static RootShell getInstance(Context ctx) {
        if (instance == null) {
            synchronized (RootShell.class) {
                if (instance == null) {
                    instance = new RootShell(ctx);
                }
            }
        }
        return instance;
    }

    private RootShell(Context ctx) {
        this.context = ctx.getApplicationContext();
        this.pidCache = new ConcurrentHashMap<>();
        this.executor = Executors.newFixedThreadPool(2);
        try {
            Shell.enableVerboseLogging = true;
            Shell.setDefaultBuilder(Shell.Builder.create()
                .setFlags(Shell.FLAG_REDIRECT_STDERR)
                .setTimeout(15));
        } catch (Throwable t) {
            Log.w(TAG, "Shell builder init failed: " + t.getMessage());
        }
    }

    public synchronized boolean initialize() {
        try {
            long now = System.currentTimeMillis();
            if (shell != null && (now - lastShellRefresh) < SHELL_REFRESH_INTERVAL) {
                return rootAvailable;
            }
            shell = Shell.getShell();
            rootAvailable = shell != null && shell.isRoot();
            if (rootAvailable) {
                busyboxAvailable = Shell.cmd("which busybox").exec().isSuccess();
                if (!busyboxAvailable) {
                    String bbCheck = Shell.cmd("ls /system/bin/busybox /system/xbin/busybox /sbin/busybox /vendor/bin/busybox 2>/dev/null").exec().getOut().toString();
                    busyboxAvailable = bbCheck.contains("busybox");
                }
                lastShellRefresh = now;
                Log.i(TAG, "Root shell initialized. Busybox: " + busyboxAvailable);
            } else {
                Log.w(TAG, "Root not available");
            }
        } catch (Throwable t) {
            Log.e(TAG, "Root init error: " + t.getMessage());
            rootAvailable = false;
        }
        return rootAvailable;
    }

    public boolean isRootAvailable() {
        return rootAvailable;
    }

    public boolean isBusyboxAvailable() {
        return busyboxAvailable;
    }

    private static String sanitizeArg(String arg) {
        if (arg == null) return "''";
        if (SAFE_ARG_PATTERN.matcher(arg).matches()) return arg;
        return "'" + arg.replace("'", "'\\''") + "'";
    }

    public int execSync(String command) {
        try {
            if (shell == null || !rootAvailable) return -1;
            Shell.Result result = Shell.cmd(command).exec();
            return result.getCode();
        } catch (Throwable t) {
            Log.e(TAG, "execSync error: " + t.getMessage());
            return -1;
        }
    }

    public String execSyncWithOutput(String command) {
        try {
            if (shell == null || !rootAvailable) return "";
            Shell.Result result = Shell.cmd(command).exec();
            if (result.isSuccess()) {
                List<String> out = result.getOut();
                StringBuilder sb = new StringBuilder();
                for (String line : out) sb.append(line).append("\n");
                return sb.toString();
            }
        } catch (Throwable t) {
            Log.e(TAG, "execSyncWithOutput error: " + t.getMessage());
        }
        return "";
    }

    public void execAsync(final String command, final ShellCallback callback) {
        executor.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    if (shell == null || !rootAvailable) {
                        if (callback != null) callback.onError("Root not available");
                        return;
                    }
                    Shell.Result result = Shell.cmd(command).exec();
                    List<String> out = result.getOut();
                    StringBuilder sb = new StringBuilder();
                    for (String line : out) sb.append(line).append("\n");
                    if (callback != null) callback.onResult(result.getCode(), sb.toString());
                } catch (Throwable t) {
                    if (callback != null) callback.onError(t.getMessage());
                }
            }
        });
    }

    public int execSyncList(List<String> commands) {
        try {
            if (shell == null || !rootAvailable) return -1;
            ArrayList<String> cmdArray = new ArrayList<>();
            cmdArray.addAll(commands);
            Shell.Result result = Shell.cmd(cmdArray.toArray(new String[0])).exec();
            return result.isSuccess() ? result.getCode() : -1;
        } catch (Throwable t) {
            Log.e(TAG, "execSyncList error: " + t.getMessage());
            return -1;
        }
    }

    public boolean copyFileAsRoot(String source, String dest) {
        try {
            if (!rootAvailable) return false;
            String cmd = "cp -f " + sanitizeArg(source) + " " + sanitizeArg(dest) +
                " && chmod 644 " + sanitizeArg(dest);
            return Shell.cmd(cmd).exec().isSuccess();
        } catch (Throwable t) {
            return false;
        }
    }

    public boolean writeFileAsRoot(String path, String content) {
        try {
            if (!rootAvailable) return false;
            String escaped = content.replace("'", "'\\''");
            String safeContent = "'" + escaped + "'";
            String cmd = "echo " + safeContent + " > " + sanitizeArg(path) +
                " && chmod 644 " + sanitizeArg(path);
            return Shell.cmd(cmd).exec().isSuccess();
        } catch (Throwable t) {
            return false;
        }
    }

    public String readFileAsRoot(String path) {
        try {
            if (!rootAvailable) return "";
            String cmd = "cat " + sanitizeArg(path);
            Shell.Result result = Shell.cmd(cmd).exec();
            if (result.isSuccess()) {
                List<String> out = result.getOut();
                StringBuilder sb = new StringBuilder();
                for (String line : out) sb.append(line).append("\n");
                return sb.toString();
            }
        } catch (Throwable t) {
            Log.e(TAG, "readFileAsRoot error: " + t.getMessage());
        }
        return "";
    }

    public boolean setPermissions(String path, String permissions) {
        if (!rootAvailable) return false;
        if (!SAFE_ARG_PATTERN.matcher(permissions).matches()) return false;
        String cmd = "chmod " + sanitizeArg(permissions) + " " + sanitizeArg(path);
        return Shell.cmd(cmd).exec().isSuccess();
    }

    public boolean setOwner(String path, String owner, String group) {
        if (!rootAvailable) return false;
        if (!SAFE_ARG_PATTERN.matcher(owner).matches()) return false;
        if (!SAFE_ARG_PATTERN.matcher(group).matches()) return false;
        String cmd = "chown " + sanitizeArg(owner) + ":" + sanitizeArg(group) + " " + sanitizeArg(path);
        return Shell.cmd(cmd).exec().isSuccess();
    }

    public boolean setSELinuxContext(String path, String context) {
        if (!rootAvailable) return false;
        String cmd = "chcon " + sanitizeArg(context) + " " + sanitizeArg(path);
        return Shell.cmd(cmd).exec().isSuccess();
    }

    public boolean mountFile(String source, String target) {
        if (!rootAvailable) return false;
        String cmd = "mount --bind " + sanitizeArg(source) + " " + sanitizeArg(target);
        return Shell.cmd(cmd).exec().isSuccess();
    }

    public boolean remountRW(String path) {
        if (!rootAvailable) return false;
        String cmd = "mount -o rw,remount " + sanitizeArg(path);
        return Shell.cmd(cmd).exec().isSuccess();
    }

    public int getPidByName(String processName) {
        if (processName == null || processName.isEmpty()) return -1;
        if (!SAFE_ARG_PATTERN.matcher(processName).matches()) return -1;
        long[] cached = pidCache.get(processName);
        if (cached != null && (System.currentTimeMillis() - cached[1]) < 5000L) {
            return (int) cached[0];
        }
        try {
            if (!rootAvailable) return -1;
            String output = execSyncWithOutput("pidof " + sanitizeArg(processName));
            String trimmed = output.trim();
            if (trimmed.isEmpty()) {
                output = execSyncWithOutput("pgrep -f " + sanitizeArg(processName) + " | head -1");
                trimmed = output.trim();
            }
            if (!trimmed.isEmpty()) {
                String[] lines = trimmed.split("\\s+");
                int pid = Integer.parseInt(lines[0]);
                pidCache.put(processName, new long[]{pid, System.currentTimeMillis()});
                return pid;
            }
        } catch (Throwable t) {
            Log.e(TAG, "getPidByName error: " + t.getMessage());
        }
        return -1;
    }

    public long[] getAllPidsByName(String processName) {
        if (!rootAvailable) return new long[0];
        if (!SAFE_ARG_PATTERN.matcher(processName).matches()) return new long[0];
        try {
            String output = execSyncWithOutput("pidof " + sanitizeArg(processName));
            String trimmed = output.trim();
            if (trimmed.isEmpty()) return new long[0];
            String[] parts = trimmed.split("\\s+");
            long[] pids = new long[parts.length];
            for (int i = 0; i < parts.length; i++) pids[i] = Long.parseLong(parts[i]);
            return pids;
        } catch (Throwable t) {
            return new long[0];
        }
    }

    public String readMemory(long pid, long address, int size) {
        if (!rootAvailable || pid <= 0) return null;
        if (size <= 0) return null;
        try {
            String path = "/proc/" + pid + "/mem";
            String safePath = sanitizeArg(path);
            String cmd = "dd if=" + safePath + " bs=1 count=" + size +
                " skip=" + address + " 2>/dev/null | base64";
            String output = execSyncWithOutput(cmd);
            if (output.isEmpty()) return null;
            return output.replace("\n", "");
        } catch (Throwable t) {
            return null;
        }
    }

    public boolean writeMemory(long pid, long address, byte[] data) {
        if (!rootAvailable || pid <= 0 || data == null) return false;
        try {
            String path = "/proc/" + pid + "/mem";
            String safePath = sanitizeArg(path);
            StringBuilder hex = new StringBuilder();
            for (byte b : data) hex.append(String.format("\\x%02x", b & 0xFF));
            String safeHex = "'" + hex.toString().replace("'", "'\\''") + "'";
            String cmd = "printf " + safeHex + " | dd of=" + safePath +
                " bs=1 count=" + data.length + " seek=" + address + " conv=notrunc 2>/dev/null";
            return execSync(cmd) == 0;
        } catch (Throwable t) {
            return false;
        }
    }

    public boolean writeMemoryString(long pid, long address, String base64) {
        if (!rootAvailable || pid <= 0) return false;
        if (base64 == null) return false;
        try {
            String path = "/proc/" + pid + "/mem";
            String safePath = sanitizeArg(path);
            String safeB64 = sanitizeArg(base64);
            String cmd = "echo " + safeB64 + " | base64 -d | dd of=" + safePath +
                " bs=4096 conv=notrunc oflag=seek_bytes seek=" + address + " 2>/dev/null";
            return execSync(cmd) == 0;
        } catch (Throwable t) {
            return false;
        }
    }

    public long getModuleBase(long pid, String moduleName) {
        if (!rootAvailable || pid <= 0) return 0;
        if (moduleName == null) return 0;
        try {
            String safeName = sanitizeArg(moduleName);
            String output = execSyncWithOutput("cat /proc/" + pid + "/maps | grep -i " + safeName + " | head -1");
            if (output.isEmpty()) return 0;
            String[] parts = output.split("\\s+");
            if (parts.length > 0) {
                String[] range = parts[0].split("-");
                if (range.length == 2) {
                    return Long.parseLong(range[0], 16);
                }
            }
        } catch (Throwable t) {
            Log.e(TAG, "getModuleBase error: " + t.getMessage());
        }
        return 0;
    }

    public String[] listModules(long pid) {
        if (!rootAvailable || pid <= 0) return new String[0];
        try {
            String output = execSyncWithOutput("cat /proc/" + pid + "/maps | awk '{print $NF}' | sort -u");
            if (output.isEmpty()) return new String[0];
            return output.split("\n");
        } catch (Throwable t) {
            return new String[0];
        }
    }

    public long[] getMemoryRegions(long pid) {
        if (!rootAvailable || pid <= 0) return new long[0];
        try {
            String output = execSyncWithOutput("cat /proc/" + pid + "/maps | awk '{print $1}'");
            if (output.isEmpty()) return new long[0];
            String[] lines = output.split("\n");
            long[] regions = new long[lines.length * 2];
            int idx = 0;
            for (String line : lines) {
                String[] parts = line.trim().split("-");
                if (parts.length == 2) {
                    try {
                        regions[idx++] = Long.parseLong(parts[0], 16);
                        regions[idx++] = Long.parseLong(parts[1], 16);
                    } catch (NumberFormatException e) {}
                }
            }
            long[] result = new long[idx];
            System.arraycopy(regions, 0, result, 0, idx);
            return result;
        } catch (Throwable t) {
            return new long[0];
        }
    }

    public boolean injectLibrary(long pid, String libPath) {
        if (!rootAvailable || pid <= 0) return false;
        if (libPath == null) return false;
        try {
            String output = execSyncWithOutput("cat /proc/" + pid + "/maps | grep -E 'libc\\.so' | head -1");
            if (output.isEmpty()) return false;
            String[] parts = output.split("\\s+");
            if (parts.length < 6) return false;
            String libcPath = parts[parts.length - 1];
            String safeLibPath = sanitizeArg(libPath);
            String safeLibcPath = sanitizeArg(libcPath);
            String tempLib = "/data/local/tmp/bugor_inject.so";
            String safeTempLib = sanitizeArg(tempLib);
            String cmd = "cp -f " + safeLibPath + " " + safeTempLib + " && " +
                "chmod 755 " + safeTempLib + " && " +
                "cat /proc/" + pid + "/maps | grep " + safeLibcPath + " | head -1";
            String memInfo = execSyncWithOutput(cmd);
            if (memInfo.isEmpty()) return false;
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    public boolean killProcess(long pid) {
        if (!rootAvailable || pid <= 0) return false;
        return execSync("kill -9 " + pid) == 0;
    }

    public boolean killProcess(String name) {
        if (!rootAvailable || name == null) return false;
        if (!SAFE_ARG_PATTERN.matcher(name).matches()) return false;
        return execSync("pkill -9 -f " + sanitizeArg(name)) == 0;
    }

    public String[] getRunningProcesses() {
        if (!rootAvailable) return new String[0];
        try {
            String output = execSyncWithOutput("ps -A 2>/dev/null || ps 2>/dev/null");
            if (output.isEmpty()) return new String[0];
            return output.split("\n");
        } catch (Throwable t) {
            return new String[0];
        }
    }

    public boolean setSystemProperty(String key, String value) {
        if (!rootAvailable) return false;
        if (key == null || value == null) return false;
        String cmd = "setprop " + sanitizeArg(key) + " " + sanitizeArg(value);
        return execSync(cmd) == 0;
    }

    public String getSystemProperty(String key) {
        if (!rootAvailable) return "";
        if (key == null) return "";
        return execSyncWithOutput("getprop " + sanitizeArg(key)).trim();
    }

    public boolean hideFromProcessList(String processName) {
        if (!rootAvailable) return false;
        if (processName == null) return false;
        String safeName = sanitizeArg(processName);
        String safeFile = sanitizeArg("/data/local/tmp/.hidden_processes");
        return execSync("echo " + safeName + " >> " + safeFile) == 0;
    }

    public boolean disableMagiskHide() {
        if (!rootAvailable) return false;
        return execSync("pm disable com.topjohnwu.magisk 2>/dev/null || true") == 0;
    }

    public boolean flushDNSCache() {
        if (!rootAvailable) return false;
        return execSync("ndc resolver flushdefaultif") == 0;
    }

    public boolean setTCPMTU(int mtu) {
        if (!rootAvailable) return false;
        if (mtu < 64 || mtu > 9000) return false;
        return execSync("ip link set mtu " + mtu + " dev wlan0 2>/dev/null || true") == 0;
    }

    public void clearPidCache() {
        pidCache.clear();
    }

    public void refresh() {
        lastShellRefresh = 0;
        initialize();
    }

    public void shutdown() {
        try {
            if (executor != null) {
                executor.shutdown();
                if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                    executor.shutdownNow();
                }
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
            Thread.currentThread().interrupt();
        }
        pidCache.clear();
        shell = null;
    }

    public static byte[] decodeBase64(String input) {
        try {
            return android.util.Base64.decode(input, android.util.Base64.NO_WRAP);
        } catch (Throwable t) {
            return new byte[0];
        }
    }

    public static String encodeBase64(byte[] data) {
        try {
            return android.util.Base64.encodeToString(data, android.util.Base64.NO_WRAP);
        } catch (Throwable t) {
            return "";
        }
    }
}
