package com.bugor.engine;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class SettingsManager {
    private static volatile SettingsManager instance;
    private Context context;
    private SharedPreferences prefs;
    private Map<String, Object> toggles;
    private Map<String, Object> configs;
    private static final String PREFS_NAME = "bugor_settings";
    private static final String KEY_TOGGLES = "toggles";
    private static final String KEY_CONFIGS = "configs";

    private SettingsManager(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        this.toggles = new HashMap<>();
        this.configs = new HashMap<>();
        loadConfig();
    }

    public static SettingsManager getInstance(Context context) {
        if (instance == null) {
            synchronized (SettingsManager.class) {
                if (instance == null) {
                    instance = new SettingsManager(context);
                }
            }
        }
        return instance;
    }

    public static SettingsManager getInstance() {
        return instance;
    }

    public void setToggle(String fieldName, boolean value) {
        toggles.put(fieldName, value);
    }

    public boolean getToggle(String fieldName) {
        Object val = toggles.get(fieldName);
        return val instanceof Boolean && (Boolean) val;
    }

    public void setConfig(String fieldName, Object value) {
        configs.put(fieldName, value);
    }

    public Object getConfig(String fieldName) {
        return configs.get(fieldName);
    }

    public String getConfigString(String fieldName) {
        Object val = configs.get(fieldName);
        return val instanceof String ? (String) val : "";
    }

    public int getConfigInt(String fieldName) {
        Object val = configs.get(fieldName);
        if (val instanceof Number) return ((Number) val).intValue();
        return 0;
    }

    public float getConfigFloat(String fieldName) {
        Object val = configs.get(fieldName);
        if (val instanceof Number) return ((Number) val).floatValue();
        return 0f;
    }

    public boolean getConfigBoolean(String fieldName) {
        Object val = configs.get(fieldName);
        return val instanceof Boolean && (Boolean) val;
    }

    public void saveConfig() {
        try {
            JSONObject toggleJson = new JSONObject();
            for (Map.Entry<String, Object> entry : toggles.entrySet()) {
                toggleJson.put("tog_" + entry.getKey(), entry.getValue());
            }
            JSONObject configJson = new JSONObject();
            for (Map.Entry<String, Object> entry : configs.entrySet()) {
                configJson.put("cfg_" + entry.getKey(), entry.getValue());
            }
            prefs.edit()
                .putString(KEY_TOGGLES, toggleJson.toString())
                .putString(KEY_CONFIGS, configJson.toString())
                .apply();
        } catch (Exception e) {
            android.util.Log.e("SettingsManager", "saveConfig error: " + e.getMessage());
        }
    }

    public void loadConfig() {
        try {
            toggles.clear();
            configs.clear();
            String toggleStr = prefs.getString(KEY_TOGGLES, "{}");
            JSONObject toggleJson = new JSONObject(toggleStr);
            Iterator<String> toggleKeys = toggleJson.keys();
            while (toggleKeys.hasNext()) {
                String key = toggleKeys.next();
                if (key.startsWith("tog_")) {
                    toggles.put(key.substring(4), toggleJson.get(key));
                }
            }
            String configStr = prefs.getString(KEY_CONFIGS, "{}");
            JSONObject configJson = new JSONObject(configStr);
            Iterator<String> configKeys = configJson.keys();
            while (configKeys.hasNext()) {
                String key = configKeys.next();
                if (key.startsWith("cfg_")) {
                    configs.put(key.substring(4), configJson.get(key));
                }
            }
        } catch (Exception e) {
            android.util.Log.e("SettingsManager", "loadConfig error: " + e.getMessage());
        }
    }

    public void resetConfig() {
        toggles.clear();
        configs.clear();
        prefs.edit()
            .putString(KEY_TOGGLES, "{}")
            .putString(KEY_CONFIGS, "{}")
            .apply();
    }
}
