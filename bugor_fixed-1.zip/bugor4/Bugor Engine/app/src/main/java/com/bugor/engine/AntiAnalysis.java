package com.bugor.engine;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Application;
import android.bluetooth.BluetoothAdapter;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ConfigurationInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Debug;
import android.os.Process;
import android.os.StatFs;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.Proxy;
import java.net.ProxySelector;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.security.MessageDigest;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class AntiAnalysis {
    private static volatile AntiAnalysis instance;
    private Context context;
    private ExecutorService executor = Executors.newCachedThreadPool();
    private Map<String, Boolean> detectionCache = new HashMap<>();
    private long lastDetectionTime = 0;
    private static final long CACHE_TTL = 30000L;
    private static final int FRIDA_DEFAULT_PORT = 27042;
    private static final int FRIDA_INJECT_PORT = 27043;
    private static final String[] EMULATOR_PROPERTIES = {
        "ro.kernel.qemu", "ro.product.cpu.abi", "ro.hardware",
        "ro.build.product", "ro.build.fingerprint", "ro.product.name",
        "ro.product.device", "ro.product.board", "ro.product.manufacturer",
        "ro.serialno", "ro.boot.serialno", "ro.build.display.id",
        "ro.build.version.release", "ro.build.version.sdk",
        "ro.build.version.incremental", "ro.build.tags",
        "ro.build.flavor", "ro.build.host", "ro.build.user",
        "ro.build.date", "ro.build.date.utc"
    };
    private static final String[] ROOT_BINARIES = {
        "/system/bin/su", "/system/xbin/su", "/sbin/su",
        "/system/sd/xbin/su", "/system/bin/failsafe/su",
        "/data/local/su", "/data/local/xbin/su", "/data/local/bin/su",
        "/system/bin/busybox", "/system/xbin/busybox",
        "/system/bin/magisk", "/system/xbin/magisk",
        "/sbin/magisk", "/data/adb/magisk",
        "/system/bin/supolicy", "/system/xbin/supolicy",
        "/system/bin/suhelper", "/data/adb/su"
    };
    private static final String[] XPOSED_CLASSES = {
        "de.robv.android.xposed.XposedBridge",
        "de.robv.android.xposed.XposedHelpers",
        "de.robv.android.xposed.IXposedHookLoadPackage",
        "de.robv.android.xposed.callbacks.XC_LoadPackage",
        "de.robv.android.xposed.callbacks.XC_MethodHook",
        "com.saurik.substrate.MS",
        "com.saurik.substrate.MS$2"
    };
    private static final int[] FRIDA_PORTS = {27042, 27043, 27044, 27045, 27046, 27047, 27048, 27049, 27050};
    private static final String[] EMULATOR_FILES = {
        "/system/lib/emulator.so", "/system/lib64/emulator.so",
        "/system/bin/qemu-props", "/system/bin/qemu-trace",
        "/dev/socket/qemud", "/dev/qemu_pipe",
        "/system/lib/libc_malloc_debug_qemu.so",
        "/system/lib64/libc_malloc_debug_qemu.so",
        "/system/bin/emulator64-x86", "/system/bin/emulator64-arm",
        "/system/bin/emulator-x86", "/system/bin/emulator-arm"
    };
    private static final String[] EMULATOR_PACKAGES = {
        "com.bluestacks", "com.bluestacks2", "com.bluestacks3",
        "com.bignox.app", "com.bignox.appcenter",
        "com.vphone.launcher", "com.vphone.launcher.vn",
        "com.mumu.launcher", "com.mumu.manager",
        "com.kaopu001", "com.kaopu002",
        "com.genymotion.genymotion", "com.genymotion.vms",
        "com.android.emulator", "com.google.android.gms.snaps",
        "com.google.android.apps.nexuslauncher"
    };

    public interface AnalysisCallback {
        void onEmulatorDetected(double confidence);
        void onDebugDetected(String method);
        void onRootDetected(String method);
        void onXposedDetected(String method);
        void onFridaDetected(String method);
        void onHookDetected(String framework);
        void onVPNDetected();
        void onProxyDetected();
        void onScreenRecordingDetected();
        void onSecureEnvironment();
    }

    private AntiAnalysis(Context context) {
        this.context = context.getApplicationContext();
    }

    public static AntiAnalysis getInstance(Context context) {
        if (instance == null) {
            synchronized (AntiAnalysis.class) {
                if (instance == null) {
                    instance = new AntiAnalysis(context);
                }
            }
        }
        return instance;
    }

    public boolean isEmulator() {
        String cacheKey = "emulator";
        if (useCache(cacheKey)) return detectionCache.get(cacheKey);
        boolean result = checkEmulatorBuildProps() || checkEmulatorCPU() ||
            checkEmulatorSensors() || checkEmulatorSIM() ||
            checkEmulatorFiles() || checkEmulatorPackages() ||
            checkEmulatorBluetooth() || checkEmulatorCamera() ||
            checkEmulatorBattery() || checkEmulatorPhoneNumber() ||
            checkEmulatorNetwork() || checkEmulatorIpRoute() ||
            checkEmulatorDeviceId() || checkEmulatorPlatform() ||
            checkEmulatorGLES() || checkEmulatorTemperatures() ||
            checkEmulatorProcesses() || checkEmulatorQemuPipe() ||
            checkEmulatorDriver() || checkEmulatorDisplayMetrics();
        cacheResult(cacheKey, result);
        return result;
    }

    public boolean isDebuggerAttached() {
        String cacheKey = "debugger";
        if (useCache(cacheKey)) return detectionCache.get(cacheKey);
        boolean result = Debug.isDebuggerConnected() || Debug.waitingForDebugger();
        cacheResult(cacheKey, result);
        return result;
    }

    public boolean isDebuggable() {
        String cacheKey = "debuggable";
        if (useCache(cacheKey)) return detectionCache.get(cacheKey);
        boolean result = false;
        try {
            ApplicationInfo appInfo = context.getApplicationInfo();
            result = (appInfo.flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
            if (!result) {
                int resultCode = (Integer) ApplicationInfo.class.getField("FLAG_DEBUGGABLE").get(null);
                result = (appInfo.flags & resultCode) != 0;
            }
        } catch (Exception e) {
            result = false;
        }
        cacheResult(cacheKey, result);
        return result;
    }

    public boolean isTracerPID() {
        String cacheKey = "tracerpid";
        if (useCache(cacheKey)) return detectionCache.get(cacheKey);
        boolean result = false;
        try {
            RandomAccessFile raf = new RandomAccessFile("/proc/" + Process.myPid() + "/status", "r");
            String line;
            while ((line = raf.readLine()) != null) {
                if (line.startsWith("TracerPid:")) {
                    String tracerPid = line.substring(10).trim();
                    if (!"0".equals(tracerPid)) {
                        result = true;
                    }
                    break;
                }
            }
            raf.close();
        } catch (Exception e) {
            result = false;
        }
        cacheResult(cacheKey, result);
        return result;
    }

    public boolean hasDebugFlags() {
        String cacheKey = "debugflags";
        if (useCache(cacheKey)) return detectionCache.get(cacheKey);
        boolean result = false;
        try {
            int pid = Process.myPid();
            RandomAccessFile raf = new RandomAccessFile("/proc/" + pid + "/status", "r");
            String line;
            while ((line = raf.readLine()) != null) {
                if (line.startsWith("SigCgt:")) {
                    String sigStr = line.substring(7).trim();
                    long sigMask = Long.parseLong(sigStr, 16);
                    if ((sigMask & (1L << 11)) != 0 || (sigMask & (1L << 5)) != 0) {
                        result = true;
                    }
                    break;
                }
            }
            raf.close();
        } catch (Exception e) {
            result = false;
        }
        cacheResult(cacheKey, result);
        return result;
    }

    public boolean isRooted() {
        String cacheKey = "root";
        if (useCache(cacheKey)) return detectionCache.get(cacheKey);
        boolean result = checkRootBinaries() || checkRootBuildTags() ||
            checkRootTestKeys() || checkRootSU() || checkRootMagisk() ||
            checkRootSuperuser() || checkRootBusybox() ||
            checkRootAccess() || checkRootPath() ||
            checkRootClInitRC() || checkRootDaemonSU() ||
            checkRootNative() || checkRootAppPackages() ||
            checkRootWritableSystem() || checkRootEnforceForce();
        cacheResult(cacheKey, result);
        return result;
    }

    public boolean isXposed() {
        String cacheKey = "xposed";
        if (useCache(cacheKey)) return detectionCache.get(cacheKey);
        boolean result = checkXposedLoad() || checkXposedReflection() ||
            checkXposedProcess() || checkXposedJar() ||
            checkXposedBridge() || checkXposedResources() ||
            checkXposedModules() || checkXposedInstall() ||
            checkXposedGetObject() || checkXposedNative();
        cacheResult(cacheKey, result);
        return result;
    }

    public boolean isFrida() {
        String cacheKey = "frida";
        if (useCache(cacheKey)) return detectionCache.get(cacheKey);
        boolean result = checkFridaPorts() || checkFridaProcesses() ||
            checkFridaPipe() || checkFridaLibrary() ||
            checkFridaThreads() || checkFridaMaps() ||
            checkFridaSocket() || checkFridaStatus() ||
            checkFridaLocalhost() || checkFridaInject();
        cacheResult(cacheKey, result);
        return result;
    }

    public boolean isHooked() {
        String cacheKey = "hook";
        if (useCache(cacheKey)) return detectionCache.get(cacheKey);
        boolean result = checkXposedLoad() || checkSubstrate() ||
            checkCydia() || checkHookFramework() ||
            checkMethodOverrides() || checkDexFile() ||
            checkNativeHooks() || checkInlineHooks() ||
            checkGOTHook() || checkPLTHook();
        cacheResult(cacheKey, result);
        return result;
    }

    public boolean isVPNActive() {
        String cacheKey = "vpn";
        if (useCache(cacheKey)) return detectionCache.get(cacheKey);
        boolean result = false;
        try {
            ConnectivityManager cm = (ConnectivityManager)
                context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                NetworkCapabilities nc = cm.getNetworkCapabilities(cm.getActiveNetwork());
                result = nc != null && !nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN);
                result = !result;
            } else {
                NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
                if (activeNetwork != null) {
                    String typeName = activeNetwork.getTypeName().toLowerCase(Locale.US);
                    result = typeName.contains("vpn");
                }
            }
            if (!result) {
                List<String> ifaces = new ArrayList<>();
                Enumeration<NetworkInterface> nets = NetworkInterface.getNetworkInterfaces();
                while (nets.hasMoreElements()) {
                    NetworkInterface ni = nets.nextElement();
                    if (ni.isUp() && (ni.getName().contains("tun") ||
                        ni.getName().contains("ppp") ||
                        ni.getName().contains("tap"))) {
                        result = true;
                        break;
                    }
                }
            }
        } catch (Exception e) {
            result = false;
        }
        cacheResult(cacheKey, result);
        return result;
    }

    public boolean isProxyActive() {
        String cacheKey = "proxy";
        if (useCache(cacheKey)) return detectionCache.get(cacheKey);
        boolean result = false;
        try {
            String proxyHost = System.getProperty("http.proxyHost");
            String proxyPort = System.getProperty("http.proxyPort");
            if (proxyHost != null && !proxyHost.isEmpty()) {
                result = true;
            }
            if (!result) {
                ProxySelector ps = ProxySelector.getDefault();
                List<Proxy> proxies = ps.select(new java.net.URI("http://google.com"));
                for (Proxy p : proxies) {
                    if (p.type() != Proxy.Type.DIRECT) {
                        result = true;
                        break;
                    }
                }
            }
            if (!result && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                try {
                    String host = Settings.Global.getString(context.getContentResolver(),
                        Settings.Global.HTTP_PROXY);
                    result = host != null && !host.isEmpty();
                } catch (Exception e) {
                }
            }
        } catch (Exception e) {
            result = false;
        }
        cacheResult(cacheKey, result);
        return result;
    }

    public boolean isScreenRecording() {
        String cacheKey = "screenrec";
        if (useCache(cacheKey)) return detectionCache.get(cacheKey);
        boolean result = false;
        try {
            result = Settings.Global.getInt(context.getContentResolver(),
                "show_touches", 0) == 1;
        } catch (Exception e) {
            result = false;
        }
        if (!result) {
            result = isScreenRecordingMediaProjection();
        }
        if (!result) {
            result = isScreenRecordingProcesses();
        }
        cacheResult(cacheKey, result);
        return result;
    }

    public void preventScreenshot(Activity activity) {
        if (activity != null) {
            activity.getWindow().setFlags(
                android.view.WindowManager.LayoutParams.FLAG_SECURE,
                android.view.WindowManager.LayoutParams.FLAG_SECURE);
        }
    }

    public double getEmulatorConfidence() {
        double totalScore = 0;
        int checks = 0;
        checks++; if (checkEmulatorBuildProps()) totalScore += 1.0;
        checks++; if (checkEmulatorCPU()) totalScore += 0.9;
        checks++; if (checkEmulatorSensors()) totalScore += 0.8;
        checks++; if (checkEmulatorSIM()) totalScore += 1.0;
        checks++; if (checkEmulatorFiles()) totalScore += 0.9;
        checks++; if (checkEmulatorPackages()) totalScore += 0.7;
        checks++; if (checkEmulatorBluetooth()) totalScore += 0.6;
        checks++; if (checkEmulatorCamera()) totalScore += 0.5;
        checks++; if (checkEmulatorBattery()) totalScore += 0.6;
        checks++; if (checkEmulatorPhoneNumber()) totalScore += 0.8;
        checks++; if (checkEmulatorNetwork()) totalScore += 0.5;
        checks++; if (checkEmulatorIpRoute()) totalScore += 0.7;
        checks++; if (checkEmulatorDeviceId()) totalScore += 0.4;
        checks++; if (checkEmulatorPlatform()) totalScore += 0.3;
        checks++; if (checkEmulatorGLES()) totalScore += 0.7;
        checks++; if (checkEmulatorTemperatures()) totalScore += 0.5;
        checks++; if (checkEmulatorProcesses()) totalScore += 0.8;
        checks++; if (checkEmulatorQemuPipe()) totalScore += 1.0;
        checks++; if (checkEmulatorDriver()) totalScore += 0.6;
        checks++; if (checkEmulatorDisplayMetrics()) totalScore += 0.5;
        return checks > 0 ? totalScore / checks : 0;
    }

    private boolean checkEmulatorBuildProps() {
        try {
            String[] props = {
                Build.PRODUCT, Build.MANUFACTURER, Build.BRAND,
                Build.DEVICE, Build.MODEL, Build.HARDWARE,
                Build.FINGERPRINT, Build.BOARD, Build.HOST
            };
            String[] emuSignatures = {
                "sdk", "google_sdk", "generic", "generic_x86",
                "generic_x86_64", "generic_arm64", "emu64",
                "android_x86", "vbox86p", "vbox86", "vbox",
                "goldfish", "ranchu", "qemu", "android-emulator",
                "AndyWin", "ttVM_x86", "nox", "genymotion",
                "Bluestacks", "MuMu", "LDPlayer", "MEmu"
            };
            for (String prop : props) {
                if (prop != null) {
                    String lower = prop.toLowerCase(Locale.US);
                    for (String sig : emuSignatures) {
                        if (lower.contains(sig.toLowerCase(Locale.US))) {
                            return true;
                        }
                    }
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkEmulatorCPU() {
        try {
            String arch = System.getProperty("ro.product.cpu.abi");
            if (arch != null) {
                if (arch.toLowerCase(Locale.US).contains("x86") &&
                    !arch.toLowerCase(Locale.US).contains("arm")) {
                    return true;
                }
            }
            if (Build.CPU_ABI != null) {
                String abi = Build.CPU_ABI.toLowerCase(Locale.US);
                if ((abi.contains("x86") || abi.contains("mips")) &&
                    !abi.contains("arm")) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkEmulatorSensors() {
        try {
            SensorManager sm = (SensorManager)
                context.getSystemService(Context.SENSOR_SERVICE);
            if (sm == null) return true;
            List<Sensor> sensors = sm.getSensorList(Sensor.TYPE_ALL);
            Set<String> requiredSensors = new HashSet<>();
            requiredSensors.add("msm");
            requiredSensors.add("accelerometer");
            requiredSensors.add("gyroscope");
            requiredSensors.add("magnetic");
            requiredSensors.add("light");
            requiredSensors.add("proximity");
            requiredSensors.add("pressure");
            requiredSensors.add("temperature");
            int foundCount = 0;
            for (Sensor s : sensors) {
                String name = s.getName().toLowerCase(Locale.US);
                for (String req : requiredSensors) {
                    if (name.contains(req)) {
                        foundCount++;
                        break;
                    }
                }
            }
            return foundCount < 3;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkEmulatorSIM() {
        try {
            TelephonyManager tm = (TelephonyManager)
                context.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm == null) return true;
            if (tm.getSimState() == TelephonyManager.SIM_STATE_ABSENT) {
                String opName = tm.getNetworkOperatorName();
                if (opName == null || opName.isEmpty()) {
                    if (tm.getPhoneType() == TelephonyManager.PHONE_TYPE_GSM) {
                        String imei = tm.getDeviceId();
                        if (imei == null || imei.isEmpty() || imei.matches("0+")) {
                            return true;
                        }
                    }
                }
            }
            String imei = tm.getDeviceId();
            if (imei != null && (imei.matches("0+") || imei.contains("000000000000000"))) {
                return true;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkEmulatorFiles() {
        for (String path : EMULATOR_FILES) {
            File f = new File(path);
            if (f.exists()) return true;
        }
        return false;
    }

    private boolean checkEmulatorPackages() {
        PackageManager pm = context.getPackageManager();
        for (String pkg : EMULATOR_PACKAGES) {
            try {
                pm.getPackageInfo(pkg, 0);
                return true;
            } catch (PackageManager.NameNotFoundException e) {
            }
        }
        return false;
    }

    private boolean checkEmulatorBluetooth() {
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            return adapter == null;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkEmulatorCamera() {
        try {
            PackageManager pm = context.getPackageManager();
            boolean hasCamera = pm.hasSystemFeature(PackageManager.FEATURE_CAMERA);
            boolean hasCameraFront = pm.hasSystemFeature(PackageManager.FEATURE_CAMERA_FRONT);
            if (!hasCamera && !hasCameraFront) return true;
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkEmulatorBattery() {
        try {
            Intent batteryIntent = context.registerReceiver(null,
                new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (batteryIntent == null) return true;
            int level = batteryIntent.getIntExtra("level", -1);
            int scale = batteryIntent.getIntExtra("scale", -1);
            int temperature = batteryIntent.getIntExtra("temperature", 0);
            if (level == 0 || scale == 0) return true;
            if (temperature == 0) return true;
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkEmulatorPhoneNumber() {
        try {
            TelephonyManager tm = (TelephonyManager)
                context.getSystemService(Context.TELEPHONY_SERVICE);
            if (tm == null) return true;
            String number = tm.getLine1Number();
            if (number == null || number.isEmpty() ||
                number.equals("15555215554") ||
                number.equals("1555215554") ||
                number.matches("0+")) {
                return true;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkEmulatorNetwork() {
        try {
            ConnectivityManager cm = (ConnectivityManager)
                context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return true;
            NetworkInfo ni = cm.getActiveNetworkInfo();
            if (ni == null) return false;
            if (ni.getType() == ConnectivityManager.TYPE_WIFI) {
                WifiManager wm = (WifiManager)
                    context.getSystemService(Context.WIFI_SERVICE);
                if (wm != null) {
                    WifiInfo wi = wm.getConnectionInfo();
                    if (wi != null && wi.getMacAddress() != null &&
                        wi.getMacAddress().equals("02:00:00:00:00:00")) {
                        return true;
                    }
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkEmulatorIpRoute() {
        try {
            java.lang.Process p = Runtime.getRuntime().exec("ip route");
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.contains("10.0.2.") || line.contains("192.168.56.")) {
                    br.close();
                    return true;
                }
            }
            br.close();
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkEmulatorDeviceId() {
        try {
            String androidId = Settings.Secure.getString(
                context.getContentResolver(), Settings.Secure.ANDROID_ID);
            if (androidId == null) return false;
            String masked = Utils.getMaskedAndroidId();
            if (masked.startsWith("android-fallback") || masked.startsWith("android-unknown")) {
                return true;
            }
            if (androidId.equals("0000000000000000") ||
                androidId.equals("9774d56d682e549c") ||
                androidId.equals("0123456789abcdef")) {
                return true;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkEmulatorPlatform() {
        String platform = System.getProperty("os.arch");
        if (platform != null) {
            if (platform.toLowerCase(Locale.US).contains("i686") ||
                platform.toLowerCase(Locale.US).contains("x86_64")) {
                return true;
            }
        }
        return false;
    }

    private boolean checkEmulatorGLES() {
        try {
            ActivityManager am = (ActivityManager)
                context.getSystemService(Context.ACTIVITY_SERVICE);
            if (am == null) return false;
            ConfigurationInfo ci = am.getDeviceConfigurationInfo();
            if (ci != null && ci.reqGlEsVersion != 0) {
                int version = ci.reqGlEsVersion;
                if (version < 0x20000) return true;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkEmulatorTemperatures() {
        try {
            String[] tempPaths = {
                "/sys/class/thermal/thermal_zone0/temp",
                "/sys/class/thermal/thermal_zone1/temp",
                "/sys/class/thermal/thermal_zone2/temp",
                "/sys/class/hwmon/hwmon0/temp1_input"
            };
            boolean anyValid = false;
            for (String path : tempPaths) {
                File f = new File(path);
                if (f.exists()) {
                    anyValid = true;
                    BufferedReader br = new BufferedReader(new FileReader(f));
                    String temp = br.readLine();
                    br.close();
                    if (temp != null) {
                        try {
                            int t = Integer.parseInt(temp.trim());
                            if (t == 0) return true;
                        } catch (NumberFormatException e) {
                        }
                    }
                }
            }
            return !anyValid;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkEmulatorProcesses() {
        try {
            File[] processes = new File("/proc").listFiles();
            if (processes == null) return true;
            int appCount = 0;
            for (File f : processes) {
                if (f.isDirectory() && f.getName().matches("\\d+")) {
                    appCount++;
                }
            }
            if (appCount < 10) return true;
            String[] knownProcesses = {
                "goldfish", "qemu", "emulator", "android_x86",
                "vbox", "nox", "bluestacks"
            };
            BufferedReader br = new BufferedReader(new FileReader("/proc/self/status"));
            String line;
            while ((line = br.readLine()) != null) {
                for (String kp : knownProcesses) {
                    if (line.toLowerCase(Locale.US).contains(kp)) {
                        br.close();
                        return true;
                    }
                }
            }
            br.close();
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkEmulatorQemuPipe() {
        File qemuPipe = new File("/dev/qemu_pipe");
        File qemuSocket = new File("/dev/socket/qemud");
        return qemuPipe.exists() || qemuSocket.exists();
    }

    private boolean checkEmulatorDriver() {
        File goldfish = new File("/dev/goldfish");
        File goldfishMem = new File("/dev/goldfish_mem");
        File goldfishRtc = new File("/dev/goldfish_rtc");
        return goldfish.exists() || goldfishMem.exists() || goldfishRtc.exists();
    }

    private boolean checkEmulatorDisplayMetrics() {
        try {
            WindowManager wm = (WindowManager)
                context.getSystemService(Context.WINDOW_SERVICE);
            if (wm == null) return true;
            Display display = wm.getDefaultDisplay();
            DisplayMetrics dm = new DisplayMetrics();
            display.getMetrics(dm);
            int density = dm.densityDpi;
            if (density == DisplayMetrics.DENSITY_LOW ||
                density == DisplayMetrics.DENSITY_MEDIUM ||
                density == 120 || density == 160) {
                if (dm.widthPixels < 480 || dm.heightPixels < 800) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkRootBinaries() {
        for (String path : ROOT_BINARIES) {
            File f = new File(path);
            if (f.exists() && f.canExecute()) return true;
        }
        return false;
    }

    private boolean checkRootBuildTags() {
        String tags = Build.TAGS;
        return tags != null && tags.toLowerCase(Locale.US).contains("test-keys");
    }

    private boolean checkRootTestKeys() {
        if (Build.TAGS != null && Build.TAGS.contains("test-keys")) return true;
        if (Build.FINGERPRINT != null &&
            Build.FINGERPRINT.toLowerCase(Locale.US).contains("test-keys")) return true;
        return false;
    }

    private boolean checkRootSU() {
        try {
            java.lang.Process p = Runtime.getRuntime().exec("su -c id");
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line = br.readLine();
            br.close();
            return line != null && line.contains("uid=0");
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkRootMagisk() {
        try {
            java.lang.Process p = Runtime.getRuntime().exec("magisk -c");
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line = br.readLine();
            br.close();
            return line != null && (line.contains("Magisk") || line.contains("v"));
        } catch (Exception e) {
            File magisk = new File("/data/adb/magisk");
            if (magisk.exists()) return true;
            magisk = new File("/sbin/magisk");
            return magisk.exists();
        }
    }

    private boolean checkRootSuperuser() {
        try {
            java.lang.Process p = Runtime.getRuntime().exec("supolicy --dump");
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line = br.readLine();
            br.close();
            return line != null;
        } catch (Exception e) {
            try {
                Class<?> c = Class.forName("com.noshufou.android.su.SU");
                return true;
            } catch (Exception ex) {
                try {
                    Class<?> c = Class.forName("eu.chainfire.supersu");
                    return true;
                } catch (Exception exc) {
                    return false;
                }
            }
        }
    }

    private boolean checkRootBusybox() {
        try {
            java.lang.Process p = Runtime.getRuntime().exec("busybox");
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line = br.readLine();
            br.close();
            return line != null && line.contains("BusyBox");
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkRootAccess() {
        String[] paths = {
            "/data/local/", "/data/local/bin/", "/data/local/xbin/",
            "/system/bin/.ext/", "/system/xbin/.ext/",
            "/system/bin/su", "/system/xbin/su",
            "/system/sd/xbin/su", "/data/adb/",
            "/data/adb/bin/", "/data/adb/service.d/"
        };
        for (String path : paths) {
            File f = new File(path);
            if (f.exists() && f.canRead() && f.canExecute()) {
                File[] files = f.listFiles();
                if (files != null) {
                    for (File file : files) {
                        if (file.getName().contains("su") ||
                            file.getName().contains("magisk") ||
                            file.getName().contains("supolicy")) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    private boolean checkRootPath() {
        String path = System.getenv("PATH");
        if (path != null) {
            String[] dirs = path.split(":");
            for (String dir : dirs) {
                if (dir.contains("su") || dir.contains("magisk")) {
                    return true;
                }
                File d = new File(dir);
                if (d.exists()) {
                    File[] files = d.listFiles();
                    if (files != null) {
                        for (File f : files) {
                            if (f.getName().toLowerCase(Locale.US).contains("su") ||
                                f.getName().toLowerCase(Locale.US).contains("magisk")) {
                                return true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    private boolean checkRootClInitRC() {
        File initrc = new File("/init.rc");
        if (!initrc.exists()) return true;
        try {
            BufferedReader br = new BufferedReader(new FileReader(initrc));
            String line;
            boolean hasService = false;
            while ((line = br.readLine()) != null) {
                if (line.contains("service") && line.contains("su")) {
                    hasService = true;
                    break;
                }
            }
            br.close();
            return hasService;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkRootDaemonSU() {
        try {
            java.lang.Process p = Runtime.getRuntime().exec("ps");
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.contains("daemonsu") || line.contains("superuser") ||
                    line.contains("magiskd")) {
                    br.close();
                    return true;
                }
            }
            br.close();
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkRootNative() {
        try {
            File libsupath = new File("/system/lib/libsupol.so");
            File libsu64 = new File("/system/lib64/libsupol.so");
            return libsupath.exists() || libsu64.exists();
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkRootAppPackages() {
        String[] packages = {
            "com.noshufou.android.su", "com.noshufou.android.su.elite",
            "eu.chainfire.supersu", "com.koushikdutta.superuser",
            "com.thirdparty.superuser", "com.kingroot.kinguser",
            "com.kinguser", "com.kingouser", "com.kingoapp",
            "com.dianxinos.superuser", "com.magisk.manager",
            "topjohnwu.magisk", "com.keramidas.TitaniumBackup",
            "com.ramdroid.appquarantine", "com.devadvance.rootcloak",
            "com.amphoras.hideitpro", "com.jrummy.busybox.installer",
            "com.jrummy.root.browserfree", "com.jrummy.root.system.tools",
            "com.saurik.substrate", "com.zachspong.temprootremovejb",
            "com.ramdroid.appquarantinepro", "com.dimonvideo.luckypatcher",
            "com.chelpus.lackypatch", "com.vipercn.viper4android"
        };
        PackageManager pm = context.getPackageManager();
        for (String pkg : packages) {
            try {
                pm.getPackageInfo(pkg, PackageManager.GET_ACTIVITIES);
                return true;
            } catch (PackageManager.NameNotFoundException e) {
            }
        }
        return false;
    }

    private boolean checkRootWritableSystem() {
        try {
            File systemDir = new File("/system");
            return systemDir.canWrite();
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkRootEnforceForce() {
        try {
            java.lang.Process p = Runtime.getRuntime().exec("ls -l /system/bin/su");
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line = br.readLine();
            br.close();
            return line != null;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkXposedLoad() {
        try {
            Class<?> xposedClass = Class.forName("de.robv.android.xposed.XposedBridge");
            return xposedClass != null;
        } catch (ClassNotFoundException e) {
            return false;
        }
    }

    private boolean checkXposedReflection() {
        try {
            ClassLoader cl = context.getClassLoader();
            Method findMethod = ClassLoader.class.getDeclaredMethod("loadClass",
                String.class, boolean.class);
            findMethod.setAccessible(true);
            Object xposed = findMethod.invoke(cl,
                "de.robv.android.xposed.XposedBridge", false);
            return xposed != null;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkXposedProcess() {
        try {
            BufferedReader br = new BufferedReader(new FileReader("/proc/self/cmdline"));
            String cmdline = br.readLine();
            br.close();
            if (cmdline != null && cmdline.contains(":xposed")) return true;
            BufferedReader br2 = new BufferedReader(new FileReader("/proc/self/maps"));
            String line;
            while ((line = br2.readLine()) != null) {
                if (line.contains("XposedBridge") || line.contains("xposed")) {
                    br2.close();
                    return true;
                }
            }
            br2.close();
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkXposedJar() {
        File xposedJar = new File("/system/framework/XposedBridge.jar");
        return xposedJar.exists();
    }

    private boolean checkXposedBridge() {
        try {
            Class<?> bridge = Class.forName("de.robv.android.xposed.XposedBridge");
            Field disableHooks = bridge.getDeclaredField("disableHooks");
            disableHooks.setAccessible(true);
            boolean disabled = disableHooks.getBoolean(null);
            return !disabled;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkXposedResources() {
        try {
            Class<?> resClass = Class.forName(
                "android.content.res.XResources");
            return true;
        } catch (ClassNotFoundException e) {
            try {
                Class<?> resClass = Class.forName(
                    "android.content.res.XModuleResources");
                return true;
            } catch (ClassNotFoundException ex) {
                return false;
            }
        }
    }

    private boolean checkXposedModules() {
        try {
            File modulesDir = new File("/data/data/de.robv.android.xposed.installer/conf/modules.list");
            if (modulesDir.exists()) {
                BufferedReader br = new BufferedReader(new FileReader(modulesDir));
                String line;
                while ((line = br.readLine()) != null) {
                    if (line.trim().length() > 0 && !line.trim().startsWith("#")) {
                        br.close();
                        return true;
                    }
                }
                br.close();
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkXposedInstall() {
        String[] paths = {
            "/data/data/de.robv.android.xposed.installer/",
            "/data/data/de.robv.android.xposed.installer/bin/",
            "/data/data/de.robv.android.xposed.installer/conf/"
        };
        for (String path : paths) {
            if (new File(path).exists()) return true;
        }
        return false;
    }

    private boolean checkXposedGetObject() {
        try {
            Class<?> xposedHelpers = Class.forName(
                "de.robv.android.xposed.XposedHelpers");
            Method getObjectField = xposedHelpers.getDeclaredMethod(
                "getObjectField", Object.class, String.class);
            return getObjectField != null;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkXposedNative() {
        try {
            File libxposed = new File("/system/lib/libxposed_art.so");
            File libxposed64 = new File("/system/lib64/libxposed_art.so");
            return libxposed.exists() || libxposed64.exists();
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkFridaPorts() {
        for (int port : FRIDA_PORTS) {
            try {
                Socket s = new Socket();
                s.connect(new InetSocketAddress("127.0.0.1", port), 100);
                s.close();
                return true;
            } catch (Exception e) {
            }
        }
        return false;
    }

    private boolean checkFridaProcesses() {
        try {
            java.lang.Process p = Runtime.getRuntime().exec("ps");
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.toLowerCase(Locale.US).contains("frida") ||
                    line.contains("frida-helper") ||
                    line.contains("frida-server") ||
                    line.contains("frida-inject")) {
                    br.close();
                    return true;
                }
            }
            br.close();
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkFridaPipe() {
        try {
            File[] pipes = new File("/data/local/tmp").listFiles();
            if (pipes != null) {
                for (File f : pipes) {
                    if (f.getName().contains("frida") ||
                        f.getName().contains("re.frida")) {
                        return true;
                    }
                }
            }
            File fridaDir = new File("/data/local/tmp/re.frida.server");
            if (fridaDir.exists()) return true;
            File fridaFile = new File("/data/local/tmp/frida-server");
            return fridaFile.exists();
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkFridaLibrary() {
        try {
            RandomAccessFile raf = new RandomAccessFile("/proc/self/maps", "r");
            String line;
            while ((line = raf.readLine()) != null) {
                if (line.contains("frida") ||
                    line.contains("frida-agent") ||
                    line.contains("gumjs")) {
                    raf.close();
                    return true;
                }
            }
            raf.close();
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkFridaThreads() {
        try {
            File[] threadDirs = new File("/proc/self/task").listFiles();
            if (threadDirs == null) return false;
            int threadCount = threadDirs.length;
            int normalThreshold = 30;
            if (threadCount > normalThreshold * 2) {
                BufferedReader br = new BufferedReader(
                    new FileReader("/proc/self/status"));
                String line;
                while ((line = br.readLine()) != null) {
                    if (line.startsWith("Threads:")) {
                        int count = Integer.parseInt(line.substring(8).trim());
                        br.close();
                        return count > normalThreshold * 2;
                    }
                }
                br.close();
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkFridaMaps() {
        try {
            BufferedReader br = new BufferedReader(
                new FileReader("/proc/self/maps"));
            String line;
            int matchCount = 0;
            while ((line = br.readLine()) != null) {
                if (line.contains("frida") || line.contains("gum") ||
                    line.contains("stalker") || line.contains("interceptor")) {
                    matchCount++;
                }
            }
            br.close();
            return matchCount > 5;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkFridaSocket() {
        try {
            ServerSocket ss = new ServerSocket(FRIDA_DEFAULT_PORT);
            ss.close();
            return false;
        } catch (IOException e) {
            return true;
        }
    }

    private boolean checkFridaStatus() {
        try {
            java.lang.Process p = Runtime.getRuntime().exec(
                "cat /proc/self/status");
            BufferedReader br = new BufferedReader(
                new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.toLowerCase(Locale.US).contains("tracerpid") &&
                    !line.contains("0")) {
                    br.close();
                    return true;
                }
            }
            br.close();
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkFridaLocalhost() {
        try {
            Socket s = new Socket();
            s.connect(new InetSocketAddress("127.0.0.1", 27042), 50);
            s.close();
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    private boolean checkFridaInject() {
        try {
            File psDir = new File("/proc");
            File[] processes = psDir.listFiles();
            if (processes == null) return false;
            for (File proc : processes) {
                if (proc.isDirectory() && proc.getName().matches("\\d+")) {
                    try {
                        BufferedReader br = new BufferedReader(
                            new FileReader(proc.getAbsolutePath() + "/cmdline"));
                        String cmdline = br.readLine();
                        br.close();
                        if (cmdline != null && cmdline.contains("frida-inject")) {
                            return true;
                        }
                    } catch (Exception e) {
                    }
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkSubstrate() {
        try {
            Class<?> substrate = Class.forName("com.saurik.substrate.MS");
            return true;
        } catch (ClassNotFoundException e) {
            try {
                Class<?> substrate2 = Class.forName("com.saurik.substrate.MS$2");
                return true;
            } catch (ClassNotFoundException ex) {
                return false;
            }
        }
    }

    private boolean checkCydia() {
        try {
            Class<?> cydia = Class.forName("com.saurik.substrate.Cydia");
            return true;
        } catch (ClassNotFoundException e) {
            try {
                Class<?> cydiaSubstrate = Class.forName("com.saurik.substrate.SafeMode");
                return true;
            } catch (ClassNotFoundException ex) {
                return false;
            }
        }
    }

    private boolean checkHookFramework() {
        try {
            Class<?> hookClass = Class.forName(
                "de.robv.android.xposed.IXposedHookLoadPackage");
            return true;
        } catch (ClassNotFoundException e) {
            try {
                Class<?> entryClass = Class.forName(
                    "de.robv.android.xposed.IXposedHookZygoteInit");
                return true;
            } catch (ClassNotFoundException ex) {
                return false;
            }
        }
    }

    private boolean checkMethodOverrides() {
        try {
            Class<?> proxyClass = Class.forName("java.lang.reflect.Proxy");
            Method[] methods = proxyClass.getDeclaredMethods();
            for (Method m : methods) {
                if (m.getName().contains("Xposed") ||
                    m.getName().contains("hook")) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkDexFile() {
        try {
            BufferedReader br = new BufferedReader(
                new FileReader("/proc/self/maps"));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.contains("XposedBridge") ||
                    line.contains("substrate") ||
                    line.contains("cydia")) {
                    br.close();
                    return true;
                }
            }
            br.close();
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkNativeHooks() {
        try {
            BufferedReader br = new BufferedReader(
                new FileReader("/proc/self/maps"));
            String line;
            int anonymousMaps = 0;
            while ((line = br.readLine()) != null) {
                if (line.contains("anon_inode:dm-user") ||
                    line.contains("/memfd:")) {
                    anonymousMaps++;
                }
            }
            br.close();
            return anonymousMaps > 5;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkInlineHooks() {
        try {
            long startAddr = 0;
            BufferedReader br = new BufferedReader(
                new FileReader("/proc/self/maps"));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.contains("r-xp") && line.contains("linker")) {
                    String[] parts = line.split("-");
                    if (parts.length > 1) {
                        startAddr = Long.parseLong(parts[0], 16);
                    }
                    break;
                }
            }
            br.close();
            if (startAddr == 0) return false;
            RandomAccessFile raf = new RandomAccessFile("/proc/self/mem", "r");
            raf.seek(startAddr);
            byte[] header = new byte[8];
            raf.read(header);
            raf.close();
            if ((header[0] & 0xFF) == 0x00 && (header[1] & 0xFF) == 0x00 &&
                (header[2] & 0xFF) == 0x00 && (header[3] & 0xFF) == 0x00) {
                return true;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkGOTHook() {
        try {
            BufferedReader br = new BufferedReader(
                new FileReader("/proc/self/maps"));
            String line;
            boolean hasGOT = false;
            while ((line = br.readLine()) != null) {
                if (line.contains("rw-p") && line.contains("[vdso]")) {
                    hasGOT = true;
                    String[] parts = line.split("\\s+");
                    if (parts.length > 4) {
                        String perms = parts[1];
                        if (perms.contains("w")) {
                            br.close();
                            return true;
                        }
                    }
                }
            }
            br.close();
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkPLTHook() {
        try {
            java.lang.Process p = Runtime.getRuntime().exec(
                "cat /proc/self/auxv");
            BufferedReader br = new BufferedReader(
                new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.contains("AT_PLATFORM") ||
                    line.contains("AT_BASE_PLATFORM")) {
                    br.close();
                    return true;
                }
            }
            br.close();
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean isScreenRecordingMediaProjection() {
        try {
            String serviceName = "media_projection";
            Object service = context.getSystemService("media_projection");
            if (service != null) {
                try {
                    Method isActiveMethod = service.getClass().getMethod(
                        "isActive");
                    return (Boolean) isActiveMethod.invoke(service);
                } catch (Exception e) {
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean isScreenRecordingProcesses() {
        try {
            ActivityManager am = (ActivityManager)
                context.getSystemService(Context.ACTIVITY_SERVICE);
            if (am == null) return false;
            List<ActivityManager.RunningServiceInfo> services =
                am.getRunningServices(Integer.MAX_VALUE);
            for (ActivityManager.RunningServiceInfo rsi : services) {
                if (rsi.service != null) {
                    String className = rsi.service.getClassName()
                        .toLowerCase(Locale.US);
                    if (className.contains("screenrecord") ||
                        className.contains("recording") ||
                        className.contains("capture")) {
                        return true;
                    }
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    public Map<String, Boolean> fullAnalysis() {
        Map<String, Boolean> results = new HashMap<>();
        results.put("emulator", isEmulator());
        results.put("debugger", isDebuggerAttached());
        results.put("debuggable", isDebuggable());
        results.put("tracerpid", isTracerPID());
        results.put("debugflags", hasDebugFlags());
        results.put("rooted", isRooted());
        results.put("xposed", isXposed());
        results.put("frida", isFrida());
        results.put("hooked", isHooked());
        results.put("vpn", isVPNActive());
        results.put("proxy", isProxyActive());
        results.put("screen_recording", isScreenRecording());
        return results;
    }

    public Map<String, Double> getDetailedConfidence() {
        Map<String, Double> confidence = new HashMap<>();
        confidence.put("emulator", getEmulatorConfidence());
        confidence.put("root", isRooted() ? 1.0 : 0.0);
        confidence.put("debug", (isDebuggerAttached() || isDebuggable()) ? 1.0 : 0.0);
        confidence.put("xposed", isXposed() ? 1.0 : 0.0);
        confidence.put("frida", isFrida() ? 1.0 : 0.0);
        confidence.put("hook", isHooked() ? 1.0 : 0.0);
        confidence.put("vpn", isVPNActive() ? 1.0 : 0.0);
        confidence.put("proxy", isProxyActive() ? 1.0 : 0.0);
        confidence.put("screen_recording", isScreenRecording() ? 1.0 : 0.0);
        return confidence;
    }

    public boolean isSafeEnvironment() {
        return !isEmulator() && !isDebuggerAttached() && !isDebuggable() &&
            !isTracerPID() && !hasDebugFlags() && !isRooted() &&
            !isXposed() && !isFrida() && !isHooked() &&
            !isVPNActive() && !isProxyActive() && !isScreenRecording();
    }

    public void runFullAnalysis(AnalysisCallback callback) {
        executor.submit(() -> {
            if (isEmulator()) {
                double confidence = getEmulatorConfidence();
                callback.onEmulatorDetected(confidence);
            }
            if (isDebuggerAttached()) {
                callback.onDebugDetected("debugger_attached");
            }
            if (isDebuggable()) {
                callback.onDebugDetected("debuggable_flag");
            }
            if (isTracerPID()) {
                callback.onDebugDetected("tracer_pid");
            }
            if (hasDebugFlags()) {
                callback.onDebugDetected("debug_flags");
            }
            if (isRooted()) {
                if (checkRootBinaries()) callback.onRootDetected("binaries");
                else if (checkRootBuildTags()) callback.onRootDetected("build_tags");
                else if (checkRootMagisk()) callback.onRootDetected("magisk");
                else if (checkRootSU()) callback.onRootDetected("su_access");
                else if (checkRootSuperuser()) callback.onRootDetected("supersu");
                else if (checkRootBusybox()) callback.onRootDetected("busybox");
                else callback.onRootDetected("unknown");
            }
            if (isXposed()) {
                if (checkXposedLoad()) callback.onXposedDetected("load_class");
                else if (checkXposedReflection()) callback.onXposedDetected("reflection");
                else if (checkXposedProcess()) callback.onXposedDetected("process");
                else if (checkXposedJar()) callback.onXposedDetected("jar_file");
                else callback.onXposedDetected("unknown");
            }
            if (isFrida()) {
                if (checkFridaPorts()) callback.onFridaDetected("ports");
                else if (checkFridaProcesses()) callback.onFridaDetected("processes");
                else if (checkFridaPipe()) callback.onFridaDetected("pipe");
                else if (checkFridaLibrary()) callback.onFridaDetected("library");
                else if (checkFridaThreads()) callback.onFridaDetected("threads");
                else callback.onFridaDetected("unknown");
            }
            if (isHooked()) {
                if (checkSubstrate()) callback.onHookDetected("substrate");
                else if (checkXposedLoad()) callback.onHookDetected("xposed");
                else if (checkCydia()) callback.onHookDetected("cydia");
                else callback.onHookDetected("unknown");
            }
            if (isVPNActive()) callback.onVPNDetected();
            if (isProxyActive()) callback.onProxyDetected();
            if (isScreenRecording()) callback.onScreenRecordingDetected();
            if (isSafeEnvironment()) callback.onSecureEnvironment();
        });
    }

    private boolean useCache(String key) {
        if (System.currentTimeMillis() - lastDetectionTime < CACHE_TTL) {
            return detectionCache.containsKey(key);
        }
        return false;
    }

    private void cacheResult(String key, boolean result) {
        detectionCache.put(key, result);
        lastDetectionTime = System.currentTimeMillis();
    }

    public void clearCache() {
        detectionCache.clear();
        lastDetectionTime = 0;
    }

    public void destroy() {
        executor.shutdownNow();
        instance = null;
    }

}
