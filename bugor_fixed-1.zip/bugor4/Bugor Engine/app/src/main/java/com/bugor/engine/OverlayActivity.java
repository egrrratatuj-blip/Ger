package com.bugor.engine;

import android.app.Activity;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;

public class OverlayActivity extends Activity {
    private WindowManager windowManager;
    private LinearLayout overlayView;
    private boolean isAdded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        overlayView = new LinearLayout(this);
        overlayView.setOrientation(LinearLayout.VERTICAL);
        overlayView.setBackgroundColor(0xAA1A1A2E);

        Button closeButton = new Button(this);
        closeButton.setText("X");
        closeButton.setTextColor(0xFFFF4444);
        closeButton.setBackgroundColor(0x66000000);
        closeButton.setOnClickListener(v -> {
            if (isAdded) {
                windowManager.removeView(overlayView);
                isAdded = false;
            }
            finish();
        });

        Button mainButton = new Button(this);
        mainButton.setText("Bugor");
        mainButton.setTextColor(0xFF00FF88);
        mainButton.setBackgroundColor(0x66000000);
        mainButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        });

        overlayView.addView(closeButton);
        overlayView.addView(mainButton);

        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
            | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            flags |= WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED;
        }

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            150,
            200,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                WindowManager.LayoutParams.TYPE_PHONE,
            flags,
            PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 0;
        params.y = 100;

        try {
            windowManager.addView(overlayView, params);
            isAdded = true;
        } catch (Exception e) {
            e.printStackTrace();
            finish();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isAdded && windowManager != null) {
            try {
                windowManager.removeView(overlayView);
            } catch (Exception ignored) {}
            isAdded = false;
        }
    }
}
