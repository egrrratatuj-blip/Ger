package com.bugor.engine;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.LightingColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.TextPaint;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.OvershootInterpolator;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class UIManager {
    private static volatile UIManager instance;
    private Context context;
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private Map<String, Theme> themes = new HashMap<>();
    private Map<String, Typeface> fonts = new HashMap<>();
    private String activeTheme = "dark";
    private String activeFont = "default";
    private LayoutInflater inflater;
    private DisplayMetrics displayMetrics;
    private Queue<ToastData> toastQueue = new ConcurrentLinkedQueue<>();
    private AtomicBoolean showingToast = new AtomicBoolean(false);
    private AtomicInteger dialogCount = new AtomicInteger(0);
    private List<OverlayView> overlays = new ArrayList<>();
    private int statusBarHeight = -1;
    private int navigationBarHeight = -1;
    private WindowManager windowManager;

    public static class Theme {
        public String id;
        public String name;
        public int primaryColor;
        public int secondaryColor;
        public int backgroundColor;
        public int surfaceColor;
        public int onPrimaryColor;
        public int onSecondaryColor;
        public int onBackgroundColor;
        public int onSurfaceColor;
        public int errorColor;
        public int accentColor;
        public int successColor;
        public int warningColor;
        public int infoColor;
        public int dividerColor;
        public int disabledColor;
        public int rippleColor;
        public int overlayColor;
        public int statusBarStyle;
        public int cornerRadius;
        public int elevation;
        public boolean isDark;

        public Theme(String id, String name) {
            this.id = id;
            this.name = name;
            this.cornerRadius = 12;
            this.elevation = 8;
            this.statusBarStyle = View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        }

        public static Theme createDarkTheme() {
            Theme t = new Theme("dark", "Dark");
            t.primaryColor = 0xFF00C0FF;
            t.secondaryColor = 0xFF0080FF;
            t.backgroundColor = 0xFF1A1A2E;
            t.surfaceColor = 0xFF16213E;
            t.onPrimaryColor = 0xFFFFFFFF;
            t.onSecondaryColor = 0xFFFFFFFF;
            t.onBackgroundColor = 0xFFE0E0E0;
            t.onSurfaceColor = 0xFFCCCCCC;
            t.errorColor = 0xFFFF5252;
            t.accentColor = 0xFF00E5FF;
            t.successColor = 0xFF69F0AE;
            t.warningColor = 0xFFFFD740;
            t.infoColor = 0xFF40C4FF;
            t.dividerColor = 0x33FFFFFF;
            t.disabledColor = 0x61FFFFFF;
            t.rippleColor = 0x33FFFFFF;
            t.overlayColor = 0x80000000;
            t.isDark = true;
            t.cornerRadius = 16;
            t.elevation = 12;
            return t;
        }

        public static Theme createLightTheme() {
            Theme t = new Theme("light", "Light");
            t.primaryColor = 0xFF1976D2;
            t.secondaryColor = 0xFF42A5F5;
            t.backgroundColor = 0xFFF5F5F5;
            t.surfaceColor = 0xFFFFFFFF;
            t.onPrimaryColor = 0xFFFFFFFF;
            t.onSecondaryColor = 0xFFFFFFFF;
            t.onBackgroundColor = 0xFF212121;
            t.onSurfaceColor = 0xFF424242;
            t.errorColor = 0xFFD32F2F;
            t.accentColor = 0xFF448AFF;
            t.successColor = 0xFF388E3C;
            t.warningColor = 0xFFFFA000;
            t.infoColor = 0xFF1976D2;
            t.dividerColor = 0x1F000000;
            t.disabledColor = 0x61000000;
            t.rippleColor = 0x33000000;
            t.overlayColor = 0x40000000;
            t.isDark = false;
            return t;
        }

        public static Theme createAmoledTheme() {
            Theme t = createDarkTheme();
            t.id = "amoled";
            t.name = "AMOLED";
            t.backgroundColor = 0xFF000000;
            t.surfaceColor = 0xFF0D0D0D;
            t.onBackgroundColor = 0xFFE0E0E0;
            t.onSurfaceColor = 0xFFCCCCCC;
            return t;
        }
    }

    public static class OverlayView {
        public View view;
        public WindowManager.LayoutParams params;
        public String id;
        public boolean isVisible;
        public int x;
        public int y;
        public int width;
        public int height;
    }

    public static class ToastData {
        public String message;
        public int duration;
        public int style;
        public int icon;
        public ToastData(String msg, int dur, int style) {
            this.message = msg; this.duration = dur; this.style = style;
        }
    }

    public interface DialogCallback {
        void onPositive();
        void onNegative();
        void onDismiss();
    }

    public interface AnimationEndListener {
        void onAnimationEnd();
    }

    private UIManager(Context context) {
        this.context = context.getApplicationContext();
        this.inflater = LayoutInflater.from(context);
        this.windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        this.displayMetrics = context.getResources().getDisplayMetrics();
        initThemes();
        initFonts();
    }

    public static UIManager getInstance(Context context) {
        if (instance == null) {
            synchronized (UIManager.class) {
                if (instance == null) {
                    instance = new UIManager(context);
                }
            }
        }
        return instance;
    }

    private void initThemes() {
        themes.put("dark", Theme.createDarkTheme());
        themes.put("light", Theme.createLightTheme());
        themes.put("amoled", Theme.createAmoledTheme());
    }

    private void initFonts() {
        try {
            AssetManager am = context.getAssets();
            String[] fontFiles = am.list("fonts");
            if (fontFiles != null) {
                for (String f : fontFiles) {
                    if (f.endsWith(".ttf") || f.endsWith(".otf")) {
                        String name = f.replace(".ttf", "").replace(".otf", "");
                        fonts.put(name, Typeface.createFromAsset(am, "fonts/" + f));
                    }
                }
            }
        } catch (IOException e) {
        }
        fonts.put("default", Typeface.DEFAULT);
        fonts.put("monospace", Typeface.MONOSPACE);
        fonts.put("serif", Typeface.SERIF);
        fonts.put("sans_serif", Typeface.SANS_SERIF);
    }

    public Theme getCurrentTheme() {
        return themes.get(activeTheme);
    }

    public Theme getTheme(String id) {
        return themes.get(id);
    }

    public void setTheme(String id) {
        if (themes.containsKey(id)) {
            this.activeTheme = id;
        }
    }

    public void applyTheme(Activity activity) {
        Theme theme = getCurrentTheme();
        if (theme == null) return;
        activity.getWindow().setStatusBarColor(theme.backgroundColor);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            View decor = activity.getWindow().getDecorView();
            int flags = decor.getSystemUiVisibility();
            if (!theme.isDark) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            } else {
                flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            }
            decor.setSystemUiVisibility(flags);
        }
    }

    public void applyThemeToView(View view) {
        Theme theme = getCurrentTheme();
        if (theme == null) return;
        if (view instanceof TextView) {
            TextView tv = (TextView) view;
            tv.setTextColor(theme.onBackgroundColor);
        }
        if (view instanceof Button) {
            Button btn = (Button) view;
            btn.setBackgroundColor(theme.primaryColor);
            btn.setTextColor(theme.onPrimaryColor);
        }
        if (view instanceof ViewGroup) {
            ViewGroup vg = (ViewGroup) view;
            for (int i = 0; i < vg.getChildCount(); i++) {
                applyThemeToView(vg.getChildAt(i));
            }
        }
    }

    public Typeface getFont(String name) {
        return fonts.getOrDefault(name, Typeface.DEFAULT);
    }

    public void setActiveFont(String name) {
        if (fonts.containsKey(name)) {
            this.activeFont = name;
        }
    }

    public String getActiveFont() {
        return activeFont;
    }

    public void showProgressDialog(Activity activity, String title, String message) {
        if (activity == null || activity.isFinishing()) return;
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setCancelable(false);
        LinearLayout layout = new LinearLayout(activity);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);
        ProgressBar progressBar = new ProgressBar(activity);
        progressBar.setIndeterminate(true);
        layout.addView(progressBar);
        builder.setView(layout);
        builder.show();
        dialogCount.incrementAndGet();
    }

    public void showInfoDialog(Activity activity, String title, String message) {
        if (activity == null || activity.isFinishing()) return;
        new AlertDialog.Builder(activity)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("OK", null)
            .show();
        dialogCount.incrementAndGet();
    }

    public void showErrorDialog(Activity activity, String title, String message) {
        if (activity == null || activity.isFinishing()) return;
        new AlertDialog.Builder(activity)
            .setTitle(title != null ? title : "Error")
            .setMessage(message)
            .setPositiveButton("OK", null)
            .setIcon(android.R.drawable.ic_dialog_alert)
            .show();
        dialogCount.incrementAndGet();
    }

    public void showConfirmDialog(Activity activity, String title, String message,
                                  DialogCallback callback) {
        if (activity == null || activity.isFinishing()) return;
        new AlertDialog.Builder(activity)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Yes", (d, w) -> {
                if (callback != null) callback.onPositive();
                dialogCount.decrementAndGet();
            })
            .setNegativeButton("No", (d, w) -> {
                if (callback != null) callback.onNegative();
                dialogCount.decrementAndGet();
            })
            .setOnDismissListener(d -> {
                if (callback != null) callback.onDismiss();
                dialogCount.decrementAndGet();
            })
            .show();
        dialogCount.incrementAndGet();
    }

    public void showCustomDialog(Activity activity, View contentView,
                                 DialogCallback callback) {
        if (activity == null || activity.isFinishing()) return;
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setView(contentView);
        builder.setPositiveButton("OK", (d, w) -> {
            if (callback != null) callback.onPositive();
        });
        builder.setNegativeButton("Cancel", (d, w) -> {
            if (callback != null) callback.onNegative();
        });
        builder.setOnDismissListener(d -> {
            if (callback != null) callback.onDismiss();
        });
        builder.show();
        dialogCount.incrementAndGet();
    }

    public void showToast(String message) {
        showToast(message, Toast.LENGTH_SHORT, 0);
    }

    public void showToast(String message, int duration) {
        showToast(message, duration, 0);
    }

    public void showToast(String message, int duration, int style) {
        toastQueue.add(new ToastData(message, duration, style));
        if (showingToast.compareAndSet(false, true)) {
            processToastQueue();
        }
    }

    private void processToastQueue() {
        if (toastQueue.isEmpty()) {
            showingToast.set(false);
            return;
        }
        ToastData data = toastQueue.poll();
        if (data == null) {
            showingToast.set(false);
            return;
        }
        Toast toast = Toast.makeText(context, data.message, data.duration);
        View toastView = toast.getView();
        if (toastView != null) {
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(24);
            Theme theme = getCurrentTheme();
            if (theme != null) bg.setColor(theme.surfaceColor);
            else bg.setColor(0xFF333333);
            bg.setStroke(1, 0x33FFFFFF);
            toastView.setBackground(bg);
            toastView.setElevation(12);
            if (toastView instanceof TextView) {
                TextView tv = (TextView) toastView;
                tv.setTextColor(theme != null ? theme.onSurfaceColor : 0xFFFFFFFF);
                tv.setTextSize(14);
                tv.setPadding(32, 16, 32, 16);
                tv.setTypeface(getFont(activeFont));
            }
        }
        toast.show();
        mainHandler.postDelayed(this::processToastQueue,
            data.duration == Toast.LENGTH_SHORT ? 2500 : 4500);
    }

    public OverlayView createOverlay(String id, View view, int width, int height,
                                     int x, int y) {
        OverlayView ov = new OverlayView();
        ov.id = id;
        ov.view = view;
        ov.width = width;
        ov.height = height;
        ov.x = x;
        ov.y = y;
        ov.isVisible = false;
        ov.params = new WindowManager.LayoutParams(
            width, height,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT);
        ov.params.gravity = Gravity.TOP | Gravity.START;
        ov.params.x = x;
        ov.params.y = y;
        return ov;
    }

    public void showOverlay(OverlayView overlay) {
        if (overlay == null || overlay.isVisible) return;
        try {
            windowManager.addView(overlay.view, overlay.params);
            overlay.isVisible = true;
            if (!overlays.contains(overlay)) overlays.add(overlay);
        } catch (Exception e) {
        }
    }

    public void hideOverlay(OverlayView overlay) {
        if (overlay == null || !overlay.isVisible) return;
        try {
            windowManager.removeView(overlay.view);
            overlay.isVisible = false;
            overlays.remove(overlay);
        } catch (Exception e) {
        }
    }

    public void updateOverlayPosition(OverlayView overlay, int x, int y) {
        if (overlay == null) return;
        overlay.x = x;
        overlay.y = y;
        overlay.params.x = x;
        overlay.params.y = y;
        try {
            windowManager.updateViewLayout(overlay.view, overlay.params);
        } catch (Exception e) {
        }
    }

    public void removeAllOverlays() {
        List<OverlayView> copy = new ArrayList<>(overlays);
        for (OverlayView ov : copy) {
            hideOverlay(ov);
        }
        overlays.clear();
    }

    public int dpToPx(float dp) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, dp, displayMetrics);
    }

    public int spToPx(float sp) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_SP, sp, displayMetrics);
    }

    public int getScreenWidth() {
        return displayMetrics.widthPixels;
    }

    public int getScreenHeight() {
        return displayMetrics.heightPixels;
    }

    public int getScreenDensity() {
        return displayMetrics.densityDpi;
    }

    public float getDensity() {
        return displayMetrics.density;
    }

    public float getScaledDensity() {
        return displayMetrics.scaledDensity;
    }

    public int getStatusBarHeight() {
        if (statusBarHeight > 0) return statusBarHeight;
        int resourceId = context.getResources().getIdentifier(
            "status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            statusBarHeight = context.getResources().getDimensionPixelSize(resourceId);
        } else {
            statusBarHeight = dpToPx(24);
        }
        return statusBarHeight;
    }

    public int getNavigationBarHeight() {
        if (navigationBarHeight > 0) return navigationBarHeight;
        int resourceId = context.getResources().getIdentifier(
            "navigation_bar_height", "dimen", "android");
        if (resourceId > 0) {
            navigationBarHeight = context.getResources().getDimensionPixelSize(resourceId);
        } else {
            navigationBarHeight = dpToPx(48);
        }
        return navigationBarHeight;
    }

    public boolean isLandscape() {
        return context.getResources().getConfiguration().orientation ==
            Configuration.ORIENTATION_LANDSCAPE;
    }

    public int getScreenOrientation() {
        return context.getResources().getConfiguration().orientation;
    }

    public View inflateLayout(int layoutId, ViewGroup parent) {
        return inflater.inflate(layoutId, parent, false);
    }

    public View inflateLayout(int layoutId) {
        return inflater.inflate(layoutId, null, false);
    }

    public ObjectAnimator createFadeIn(View view, long duration) {
        ObjectAnimator anim = ObjectAnimator.ofFloat(view, "alpha", 0f, 1f);
        anim.setDuration(duration);
        anim.setInterpolator(new AccelerateDecelerateInterpolator());
        return anim;
    }

    public ObjectAnimator createFadeOut(View view, long duration) {
        ObjectAnimator anim = ObjectAnimator.ofFloat(view, "alpha", 1f, 0f);
        anim.setDuration(duration);
        anim.setInterpolator(new AccelerateDecelerateInterpolator());
        return anim;
    }

    public ObjectAnimator createSlideInLeft(View view, long duration) {
        ObjectAnimator anim = ObjectAnimator.ofFloat(view, "translationX",
            -view.getWidth(), 0f);
        anim.setDuration(duration);
        anim.setInterpolator(new OvershootInterpolator());
        return anim;
    }

    public ObjectAnimator createSlideInRight(View view, long duration) {
        ObjectAnimator anim = ObjectAnimator.ofFloat(view, "translationX",
            view.getWidth(), 0f);
        anim.setDuration(duration);
        anim.setInterpolator(new OvershootInterpolator());
        return anim;
    }

    public ObjectAnimator createSlideInUp(View view, long duration) {
        ObjectAnimator anim = ObjectAnimator.ofFloat(view, "translationY",
            view.getHeight(), 0f);
        anim.setDuration(duration);
        anim.setInterpolator(new OvershootInterpolator());
        return anim;
    }

    public ObjectAnimator createSlideInDown(View view, long duration) {
        ObjectAnimator anim = ObjectAnimator.ofFloat(view, "translationY",
            -view.getHeight(), 0f);
        anim.setDuration(duration);
        anim.setInterpolator(new OvershootInterpolator());
        return anim;
    }

    public ObjectAnimator createScaleIn(View view, long duration) {
        ObjectAnimator anim = ObjectAnimator.ofPropertyValuesHolder(view,
            PropertyValuesHolder.ofFloat("scaleX", 0f, 1f),
            PropertyValuesHolder.ofFloat("scaleY", 0f, 1f));
        anim.setDuration(duration);
        anim.setInterpolator(new OvershootInterpolator());
        return anim;
    }

    public ObjectAnimator createRotation(View view, long duration, float from, float to) {
        ObjectAnimator anim = ObjectAnimator.ofFloat(view, "rotation", from, to);
        anim.setDuration(duration);
        anim.setInterpolator(new AccelerateDecelerateInterpolator());
        return anim;
    }

    public ValueAnimator createColorAnimation(View view, int fromColor, int toColor,
                                              long duration) {
        ValueAnimator anim = ValueAnimator.ofObject(new ArgbEvaluator(), fromColor, toColor);
        anim.setDuration(duration);
        anim.addUpdateListener(a -> {
            if (view != null) view.setBackgroundColor((Integer) a.getAnimatedValue());
        });
        return anim;
    }

    public ValueAnimator createTextColorAnimation(TextView textView, int fromColor,
                                                  int toColor, long duration) {
        ValueAnimator anim = ValueAnimator.ofObject(new ArgbEvaluator(), fromColor, toColor);
        anim.setDuration(duration);
        anim.addUpdateListener(a -> {
            if (textView != null) textView.setTextColor((Integer) a.getAnimatedValue());
        });
        return anim;
    }

    public void animateViewIn(View view, long duration, AnimationEndListener listener) {
        view.setAlpha(0f);
        view.setScaleX(0.8f);
        view.setScaleY(0.8f);
        view.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(duration)
            .setInterpolator(new OvershootInterpolator())
            .setListener(new AnimatorListenerAdapter() {
                public void onAnimationEnd(Animator anim) {
                    if (listener != null) listener.onAnimationEnd();
                }
            })
            .start();
    }

    public void animateViewOut(View view, long duration, AnimationEndListener listener) {
        view.animate()
            .alpha(0f)
            .scaleX(0.8f)
            .scaleY(0.8f)
            .setDuration(duration)
            .setInterpolator(new AccelerateInterpolator())
            .setListener(new AnimatorListenerAdapter() {
                public void onAnimationEnd(Animator anim) {
                    if (listener != null) listener.onAnimationEnd();
                }
            })
            .start();
    }

    public void shakeView(View view) {
        ObjectAnimator anim = ObjectAnimator.ofFloat(view, "translationX",
            0f, 20f, -20f, 15f, -15f, 10f, -10f, 5f, -5f, 0f);
        anim.setDuration(500);
        anim.setInterpolator(new AccelerateDecelerateInterpolator());
        anim.start();
    }

    public void pulseView(View view) {
        ObjectAnimator anim = ObjectAnimator.ofPropertyValuesHolder(view,
            PropertyValuesHolder.ofFloat("scaleX", 1f, 1.1f, 1f),
            PropertyValuesHolder.ofFloat("scaleY", 1f, 1.1f, 1f));
        anim.setDuration(600);
        anim.setRepeatCount(ValueAnimator.INFINITE);
        anim.setRepeatMode(ValueAnimator.REVERSE);
        anim.setInterpolator(new AccelerateDecelerateInterpolator());
        anim.start();
    }

    public GradientDrawable createRoundedBackground(int color, float cornerRadius) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(color);
        gd.setCornerRadius(cornerRadius);
        return gd;
    }

    public GradientDrawable createGradientBackground(int[] colors, float cornerRadius,
                                                     GradientDrawable.Orientation orientation) {
        GradientDrawable gd = new GradientDrawable(orientation, colors);
        gd.setCornerRadius(cornerRadius);
        return gd;
    }

    public LayerDrawable createShadowBackground(int color, float cornerRadius, float elevation) {
        GradientDrawable shadow = new GradientDrawable();
        shadow.setColor(Color.TRANSPARENT);
        shadow.setCornerRadius(cornerRadius);
        shadow.setStroke(0, Color.TRANSPARENT);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(cornerRadius);
        return new LayerDrawable(new Drawable[]{shadow, bg});
    }

    public void setRoundedCorners(View view, float radius) {
        GradientDrawable gd = new GradientDrawable();
        gd.setCornerRadius(radius);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            view.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
            view.setClipToOutline(true);
        }
        view.setBackground(gd);
    }

    public void setCircularShape(View view) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            view.setOutlineProvider(ViewOutlineProvider.BACKGROUND);
            view.setClipToOutline(true);
        }
    }

    public int darkenColor(int color, float factor) {
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        hsv[2] *= factor;
        return Color.HSVToColor(hsv);
    }

    public int lightenColor(int color, float factor) {
        float[] hsv = new float[3];
        Color.colorToHSV(color, hsv);
        hsv[2] = Math.min(1.0f, hsv[2] * (1 + factor));
        return Color.HSVToColor(hsv);
    }

    public int blendColors(int color1, int color2, float ratio) {
        float inverse = 1 - ratio;
        int a = (int) (Color.alpha(color1) * inverse + Color.alpha(color2) * ratio);
        int r = (int) (Color.red(color1) * inverse + Color.red(color2) * ratio);
        int g = (int) (Color.green(color1) * inverse + Color.green(color2) * ratio);
        int b = (int) (Color.blue(color1) * inverse + Color.blue(color2) * ratio);
        return Color.argb(a, r, g, b);
    }

    public int getActiveDialogCount() {
        return dialogCount.get();
    }

    public void destroy() {
        removeAllOverlays();
        instance = null;
    }
}
