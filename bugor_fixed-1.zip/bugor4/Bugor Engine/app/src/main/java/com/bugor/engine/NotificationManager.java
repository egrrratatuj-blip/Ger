package com.bugor.engine;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class NotificationManager {
    private static volatile NotificationManager instance;
    private Context context;
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private Queue<QueuedToast> toastQueue = new ConcurrentLinkedQueue<>();
    private AtomicBoolean isShowingToast = new AtomicBoolean(false);
    private List<NotificationEntry> notificationHistory = new ArrayList<>();
    private AtomicInteger notificationIdCounter = new AtomicInteger(1000);
    private int maxHistorySize = 100;
    private boolean useCustomToasts = true;
    private boolean useStatusBarNotifications = true;
    private android.app.NotificationManager systemNotificationManager;
    private String defaultChannelId = "bugor_general";
    private String defaultChannelName = "Bugor Engine Notifications";
    private Vibrator vibrator;

    public static class QueuedToast {
        public String message;
        public int duration;
        public int priority;
        public String tag;
        public long timestamp;
        public Runnable onDismiss;

        public QueuedToast(String message, int duration, int priority) {
            this.message = message;
            this.duration = duration;
            this.priority = priority;
            this.timestamp = System.currentTimeMillis();
        }
    }

    public static class NotificationEntry {
        public int id;
        public String title;
        public String message;
        public int priority;
        public long timestamp;
        public boolean isRead;
        public String tag;
        public String formattedTime;

        public NotificationEntry(int id, String title, String message, int priority) {
            this.id = id;
            this.title = title;
            this.message = message;
            this.priority = priority;
            this.timestamp = System.currentTimeMillis();
            this.isRead = false;
            this.formattedTime = formatTime(this.timestamp);
        }

        private static String formatTime(long time) {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss", Locale.US);
            return sdf.format(new Date(time));
        }
    }

    public interface NotificationCallback {
        void onNotificationTapped(NotificationEntry entry);
        void onNotificationDismissed(int id);
        void onToastShown(QueuedToast toast);
    }

    public enum Priority {
        LOW(0),
        NORMAL(1),
        HIGH(2),
        URGENT(3),
        CRITICAL(4);

        final int value;
        Priority(int value) { this.value = value; }
    }

    private NotificationManager(Context context) {
        this.context = context.getApplicationContext();
        this.vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        this.systemNotificationManager = (android.app.NotificationManager)
            context.getSystemService(Context.NOTIFICATION_SERVICE);
        createNotificationChannel();
    }

    public static NotificationManager getInstance(Context context) {
        if (instance == null) {
            synchronized (NotificationManager.class) {
                if (instance == null) {
                    instance = new NotificationManager(context);
                }
            }
        }
        return instance;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                defaultChannelId,
                defaultChannelName,
                android.app.NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("General notifications from Bugor Engine");
            channel.enableLights(true);
            channel.setLightColor(Color.CYAN);
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{100, 200, 100, 200});
            systemNotificationManager.createNotificationChannel(channel);
        }
    }

    public void showToast(String message) {
        showToast(message, Toast.LENGTH_SHORT, Priority.NORMAL);
    }

    public void showToast(String message, int duration) {
        showToast(message, duration, Priority.NORMAL);
    }

    public void showToast(String message, int duration, Priority priority) {
        showToast(message, duration, priority.value, null);
    }

    public void showToast(String message, int duration, int priority, String tag) {
        QueuedToast qt = new QueuedToast(message, duration, priority);
        qt.tag = tag;
        toastQueue.add(qt);
        if (isShowingToast.compareAndSet(false, true)) {
            processToastQueue();
        }
    }

    private void processToastQueue() {
        QueuedToast qt = toastQueue.poll();
        if (qt == null) {
            isShowingToast.set(false);
            return;
        }
        if (useCustomToasts) {
            showCustomToast(qt);
        } else {
            Toast toast = Toast.makeText(context, qt.message, qt.duration);
            toast.show();
        }
        long delay = qt.duration == Toast.LENGTH_SHORT ? 2500 : 4500;
        mainHandler.postDelayed(this::processToastQueue, delay);
    }

    private void showCustomToast(QueuedToast qt) {
        Toast toast = new Toast(context);
        View layout = LayoutInflater.from(context).inflate(
            context.getResources().getIdentifier(
                "custom_toast", "layout", context.getPackageName()),
            null);
        if (layout == null) {
            LinearLayout ll = new LinearLayout(context);
            ll.setOrientation(LinearLayout.HORIZONTAL);
            ll.setPadding(32, 16, 32, 16);
            ll.setBackgroundColor(0xE0333333);
            TextView tv = new TextView(context);
            tv.setText(qt.message);
            tv.setTextColor(0xFFFFFFFF);
            tv.setTextSize(14);
            ll.addView(tv);
            layout = ll;
        }
        toast.setView(layout);
        toast.setDuration(qt.duration);
        toast.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 80);
        toast.show();
    }

    public void showStatusBarNotification(String title, String message) {
        showStatusBarNotification(title, message, Priority.NORMAL, null);
    }

    public void showStatusBarNotification(String title, String message,
                                          Priority priority, Intent intent) {
        if (!useStatusBarNotifications) return;
        int id = notificationIdCounter.incrementAndGet();
        NotificationEntry entry = new NotificationEntry(id, title, message, priority.value);
        notificationHistory.add(0, entry);
        trimHistory();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder builder = new Notification.Builder(context, defaultChannelId)
                .setContentTitle(title)
                .setContentText(message)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setAutoCancel(true)
                .setPriority(mapPriority(priority));
            if (intent != null) {
                PendingIntent pi = PendingIntent.getActivity(context, id, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                builder.setContentIntent(pi);
            }
            systemNotificationManager.notify(id, builder.build());
        } else {
            Notification.Builder builder = new Notification.Builder(context)
                .setContentTitle(title)
                .setContentText(message)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setAutoCancel(true);
            if (intent != null) {
                PendingIntent pi = PendingIntent.getActivity(context, id, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT);
                builder.setContentIntent(pi);
            }
            systemNotificationManager.notify(id, builder.build());
        }
    }

    public void showAlertDialog(Activity activity, String title, String message,
                                String positiveText, String negativeText,
                                DialogInterface.OnClickListener positiveListener,
                                DialogInterface.OnClickListener negativeListener) {
        if (activity == null || activity.isFinishing()) return;
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle(title);
        builder.setMessage(message);
        if (positiveText != null) {
            builder.setPositiveButton(positiveText, positiveListener);
        }
        if (negativeText != null) {
            builder.setNegativeButton(negativeText, negativeListener);
        }
        builder.setCancelable(false);
        builder.show();
    }

    public void showAlertDialog(Activity activity, String title, String message) {
        showAlertDialog(activity, title, message, "OK", null,
            (d, w) -> d.dismiss(), null);
    }

    public void showConfirmDialog(Activity activity, String title, String message,
                                  Runnable onConfirm, Runnable onCancel) {
        showAlertDialog(activity, title, message, "Confirm", "Cancel",
            (d, w) -> { if (onConfirm != null) onConfirm.run(); },
            (d, w) -> { if (onCancel != null) onCancel.run(); });
    }

    public void showVibrateToast(String message, int duration) {
        vibrate(100);
        showToast(message, duration, Priority.HIGH);
    }

    public void showPersistentNotification(String title, String message) {
        int id = notificationIdCounter.incrementAndGet();
        NotificationEntry entry = new NotificationEntry(id, title, message, Priority.HIGH.value);
        notificationHistory.add(0, entry);
        trimHistory();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder builder = new Notification.Builder(context, defaultChannelId)
                .setContentTitle(title)
                .setContentText(message)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setOngoing(true)
                .setPriority(Notification.PRIORITY_HIGH);
            systemNotificationManager.notify(id, builder.build());
        } else {
            Notification.Builder builder = new Notification.Builder(context)
                .setContentTitle(title)
                .setContentText(message)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setOngoing(true);
            systemNotificationManager.notify(id, builder.build());
        }
    }

    public void dismissNotification(int id) {
        systemNotificationManager.cancel(id);
        for (NotificationEntry entry : notificationHistory) {
            if (entry.id == id) {
                entry.isRead = true;
                break;
            }
        }
    }

    public void dismissAllNotifications() {
        systemNotificationManager.cancelAll();
        for (NotificationEntry entry : notificationHistory) {
            entry.isRead = true;
        }
    }

    private void vibrate(long duration) {
        try {
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(
                        duration, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    vibrator.vibrate(duration);
                }
            }
        } catch (Exception e) {
        }
    }

    private int mapPriority(Priority priority) {
        switch (priority) {
            case LOW: return Notification.PRIORITY_LOW;
            case NORMAL: return Notification.PRIORITY_DEFAULT;
            case HIGH: return Notification.PRIORITY_HIGH;
            case URGENT: return Notification.PRIORITY_MAX;
            case CRITICAL: return Notification.PRIORITY_MAX;
            default: return Notification.PRIORITY_DEFAULT;
        }
    }

    public List<NotificationEntry> getNotificationHistory() {
        return new ArrayList<>(notificationHistory);
    }

    public List<NotificationEntry> getUnreadNotifications() {
        List<NotificationEntry> unread = new ArrayList<>();
        for (NotificationEntry entry : notificationHistory) {
            if (!entry.isRead) unread.add(entry);
        }
        return unread;
    }

    public int getUnreadCount() {
        int count = 0;
        for (NotificationEntry entry : notificationHistory) {
            if (!entry.isRead) count++;
        }
        return count;
    }

    public void markAsRead(int id) {
        for (NotificationEntry entry : notificationHistory) {
            if (entry.id == id) {
                entry.isRead = true;
                break;
            }
        }
    }

    public void markAllAsRead() {
        for (NotificationEntry entry : notificationHistory) {
            entry.isRead = true;
        }
    }

    public void clearHistory() {
        notificationHistory.clear();
    }

    private void trimHistory() {
        while (notificationHistory.size() > maxHistorySize) {
            notificationHistory.remove(notificationHistory.size() - 1);
        }
    }

    public boolean isUseCustomToasts() {
        return useCustomToasts;
    }

    public void setUseCustomToasts(boolean useCustomToasts) {
        this.useCustomToasts = useCustomToasts;
    }

    public boolean isUseStatusBarNotifications() {
        return useStatusBarNotifications;
    }

    public void setUseStatusBarNotifications(boolean useStatusBarNotifications) {
        this.useStatusBarNotifications = useStatusBarNotifications;
    }

    public int getMaxHistorySize() {
        return maxHistorySize;
    }

    public void setMaxHistorySize(int maxHistorySize) {
        this.maxHistorySize = maxHistorySize;
    }

    public void setDefaultChannel(String id, String name) {
        this.defaultChannelId = id;
        this.defaultChannelName = name;
        createNotificationChannel();
    }

    public void destroy() {
        dismissAllNotifications();
        toastQueue.clear();
        notificationHistory.clear();
        instance = null;
    }
}
