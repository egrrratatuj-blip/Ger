package com.bugor.engine;

import android.content.Context;
import android.provider.Settings;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.security.MessageDigest;

public class Utils {
    public static boolean isRoot() {
        String[] paths = {"/system/bin/", "/system/xbin/", "/sbin/", "/system/sd/xbin/",
                          "/system/bin/failsafe/", "/data/local/xbin/", "/data/local/bin/",
                          "/data/local/"};
        for (String p : paths) {
            File f = new File(p + "su");
            if (f.exists() && f.canExecute()) return true;
        }
        return false;
    }

    public static boolean runShell(String cmd, boolean root) {
        try {
            Process p;
            if (root) {
                p = Runtime.getRuntime().exec("su");
            } else {
                p = Runtime.getRuntime().exec("sh");
            }
            DataOutputStream dos = new DataOutputStream(p.getOutputStream());
            dos.write(cmd.getBytes());
            dos.writeBytes("\n");
            dos.writeBytes("exit\n");
            dos.flush();
            dos.close();
            p.waitFor();
            return p.exitValue() == 0;
        } catch (Exception e) { return false; }
    }

    public static String getDeviceId() {
        return getMaskedAndroidId();
    }

    public static String getMaskedAndroidId() {
        try {
            String androidId = Settings.Secure.getString(
                MainActivity.appContext.getContentResolver(),
                Settings.Secure.ANDROID_ID);
            if (androidId == null || androidId.isEmpty()) return "android-unknown";
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(androidId.getBytes("UTF-8"));
            StringBuilder hex = new StringBuilder();
            for (int i = 0; i < 4 && i < hash.length; i++) {
                hex.append(String.format("%02x", hash[i] & 0xFF));
            }
            return "android-" + hex.toString().substring(0, Math.min(8, hex.length()));
        } catch (Exception e) {
            return "android-fallback";
        }
    }

    public static int getAppVersion() {
        try {
            return MainActivity.instance.getPackageManager()
                .getPackageInfo(MainActivity.instance.getPackageName(), 0).versionCode;
        } catch (Exception e) { return 0; }
    }
}
