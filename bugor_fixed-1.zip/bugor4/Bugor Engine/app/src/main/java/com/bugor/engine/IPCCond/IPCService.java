package com.bugor.engine.IPCCond;

public class IPCService {
    private static IMutual ipc;

    public static boolean isConnected() { return ipc != null; }

    public static void init(IMutual service) { ipc = service; }

    public static IMutual GetIPC() { return ipc; }
}
