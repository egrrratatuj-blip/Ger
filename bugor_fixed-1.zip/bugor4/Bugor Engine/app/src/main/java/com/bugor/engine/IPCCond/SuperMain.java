package com.bugor.engine.IPCCond;

import android.content.Intent;
import android.os.IBinder;
import android.os.Process;
import android.os.RemoteException;
import android.view.Surface;

import com.bugor.engine.SuperJNI;
import com.topjohnwu.superuser.ipc.RootService;

public class SuperMain extends RootService {
    static {
        if (Process.myUid() == 0) System.loadLibrary("BugorEngine");
    }

    public IBinder onBind(Intent intent) {
        return new IMutual.Stub() {
            public void setSurface(Surface s) { SuperJNI.setSurface(s); }
            public String start(int w, int h) { return SuperJNI.start(w, h); }
            public void MotionEventClick(int action, int pointerId, float x, float y, float pressure) {
                SuperJNI.MotionEventClick(action, pointerId, x, y, pressure);
            }
            public float[] GetImGuiwinsize() { return SuperJNI.GetImGuiwinsize(); }
            public void setPid(int pid) { SuperJNI.setPid(pid); }
            public void setKey(String key) { SuperJNI.setKey(key); }
            public void setUUid(String uuid) { SuperJNI.setUUid(uuid); }
        };
    }
}
