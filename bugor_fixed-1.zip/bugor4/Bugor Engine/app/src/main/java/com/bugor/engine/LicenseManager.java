package com.bugor.engine;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.provider.Settings;
import android.util.Base64;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class LicenseManager {
    private static volatile LicenseManager instance;
    private Context context;
    private String publicKeyPem;
    private String licenseKey;
    private LicenseInfo currentLicense;
    private AtomicBoolean isValidating = new AtomicBoolean(false);
    private AtomicBoolean isActivated = new AtomicBoolean(false);
    private AtomicLong lastCheckTime = new AtomicLong(0);
    private AtomicInteger activationAttempts = new AtomicInteger(0);
    private AtomicInteger trialDaysUsed = new AtomicInteger(0);
    private static final long CHECK_INTERVAL = 3600000L;
    private static final int MAX_ACTIVATION_ATTEMPTS = 10;
    private static final int TRIAL_MAX_DAYS = 7;
    private static final String PREFS_NAME = "bugor_license_prefs";
    private static final String CACHE_FILE = "lc.dat";
    private static final String HWID_CACHE_FILE = "hc.dat";
    private static final String LICENSE_SERVER = "https://api.bugor-engine.com/license";
    private static final String ACTIVATE_ENDPOINT = "/activate";
    private static final String VALIDATE_ENDPOINT = "/validate";
    private static final String DEACTIVATE_ENDPOINT = "/deactivate";
    private static final String CHECK_BLACKLIST_ENDPOINT = "/blacklist";
    private Map<String, LicenseCallback> callbacks = new ConcurrentHashMap<>();
    private Map<String, String> hardwareBindings = new HashMap<>();

    public interface LicenseCallback {
        void onLicenseValidated(LicenseInfo info);
        void onLicenseInvalid(String reason);
        void onActivationSuccess(LicenseInfo info);
        void onActivationFailed(String error);
        void onTrialStarted(int daysRemaining);
        void onTrialExpired();
        void onLicenseExpired(LicenseInfo info);
        void onDeviceBlacklisted(String reason);
    }

    public static class LicenseInfo implements Serializable {
        private static final long serialVersionUID = 1L;
        public String licenseKey;
        public String licenseType;
        public String hwid;
        public long issuedAt;
        public long expiresAt;
        public boolean isTrial;
        public boolean isLifetime;
        public int maxDevices;
        public int currentDevices;
        public String email;
        public String productId;
        public Map<String, String> metadata;

        public boolean isValid() {
            if (isLifetime && !isExpired()) return true;
            return !isExpired() && !isRevoked();
        }

        public boolean isExpired() {
            return expiresAt > 0 && System.currentTimeMillis() > expiresAt;
        }

        public boolean isRevoked() {
            return metadata != null && "true".equals(metadata.get("revoked"));
        }

        public long remainingDays() {
            if (isLifetime) return 99999;
            long diff = expiresAt - System.currentTimeMillis();
            if (diff <= 0) return 0;
            return diff / 86400000L;
        }
    }

    public static class LicenseException extends Exception {
        public LicenseException(String message) { super(message); }
        public LicenseException(String message, Throwable cause) { super(message, cause); }
    }

    private LicenseManager(Context context) {
        this.context = context.getApplicationContext();
        initKey();
        loadCachedLicense();
    }

    public static LicenseManager getInstance(Context context) {
        if (instance == null) {
            synchronized (LicenseManager.class) {
                if (instance == null) {
                    instance = new LicenseManager(context);
                }
            }
        }
        return instance;
    }

    private void initKey() {
        try {
            String x509Base64 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtNq3nZ8r2uT1vqJ3+7QaVxL0h4m"
                + "WbS9jKk3pV5dQrY8xT2LhN6sF0gB1cD3eA4iO5pP6lE7nT8oU9mK0jG1hY2sZ3xC4vB5"
                + "nM6qW7rR8tY9uI0oA1pE2sD3fG4hJ5kL6zX7cV8bN9mQ0wE1rT2yU3iO4pA5lS6dF7gH8"
                + "jI9kK0lZ1xC2vB3nM4qW5rR6tY7uI8oA9pE0sD1fG2hJ3kL4zX5cV6bN7mQ8wE9rT0yU1"
                + "iO2pA3lS4dF5gH6jI7kK8lZ9xC0vB1nM2qW3rR4tY5uI6oA7pE8sD9fG0hJ1kL2zX3cV4"
                + "bN5mQ6wE7rT8yU9iO0pA1lS2dF3gH4jI5kK6lZ7xC8vB9nM0qW1rR2tY3uI4oA5pE6sD7"
                + "fG8hJ9kL0zX1cV2bN3mQ4wE5rT6yU7iO8pA9lS0dF1gH2jI3kK4lZ5xC6vB7nM8qW9rR0"
                + "tY1uI2oA3pE4sD5fG6hJ7kL8zX9cV0bN1mQ2wE3rT4yU5iO6pA7lS8dF9gH0jI1kK2lZ3"
                + "xC4vB5nM6qW7rR8tY9uI0oA1pE2sD3fG4hJ5kL6zX7cV8bN9mQ0wE1rT2yU3iO4pA5lS6"
                + "dF7gH8jI9kK0lZ1xC2vB3nM4qW5rR6tY7uI8oA9pE0sD1fG2hJ3kL4zX5cV6bN7mQ8wE9"
                + "rT0yU1iO2pA3lS4dF5gH6jI7kK8lZ9xC0vB1nM2qW3rR4tY5uI6oA7pE8sD9fG0hJ1kL2"
                + "zX3cV4bN5mQ6wE7rT8yU9iO0pA1lS2dF3gH4jI5kK6lZ7xC8vB9nM0qW1rR2tY3uI4oA5"
                + "pE6sD7fG8hJ9kL0zX1cV2bN3mQ4wE5rT6yU7iO8pA9lS0dF1gH2jI3kK4lZ5xC6vB7nM8"
                + "qW9rR0tY1uI2oA3pE4sD5fG6hJ7kL8zX9cV0bN1mQ2wE3rT4yU5iO6pA7lS8dF9gH0jIB"
                + "AQAB";
            publicKeyPem = x509Base64;
        } catch (Exception e) {
            publicKeyPem = "";
        }
    }

    public String generateHardwareId() {
        StringBuilder sb = new StringBuilder();
        try {
            String androidId = Settings.Secure.getString(context.getContentResolver(),
                Settings.Secure.ANDROID_ID);
            sb.append(androidId != null ? androidId : "unknown");
            sb.append(Build.BOARD);
            sb.append(Build.BRAND);
            sb.append(Build.DEVICE);
            sb.append(Build.HARDWARE);
            sb.append(Build.MANUFACTURER);
            sb.append(Build.MODEL);
            sb.append(Build.PRODUCT);
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    String serial = Build.getSerial();
                    sb.append(serial != null ? serial : "no-serial");
                } else {
                    sb.append(Build.SERIAL);
                }
            } catch (SecurityException se) {
                sb.append("restricted-serial");
            }
            sb.append(Build.FINGERPRINT);
            String combined = sb.toString();
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(combined.getBytes("UTF-8"));
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) hex.append(String.format("%02x", b & 0xFF));
            return hex.toString();
        } catch (Exception e) {
            try {
                SecureRandom sr = new SecureRandom();
                byte[] random = new byte[32];
                sr.nextBytes(random);
                StringBuilder hex = new StringBuilder();
                for (byte b : random) hex.append(String.format("%02x", b & 0xFF));
                return hex.toString();
            } catch (Exception ex) {
                return "fallback-" + System.currentTimeMillis();
            }
        }
    }

    public boolean activateLicense(String key, LicenseCallback callback) {
        if (isValidating.getAndSet(true)) {
            if (callback != null) callback.onActivationFailed("Already validating");
            return false;
        }
        this.licenseKey = key;
        new Thread(() -> {
            try {
                if (activationAttempts.get() >= MAX_ACTIVATION_ATTEMPTS) {
                    if (callback != null)
                        callback.onActivationFailed("Too many activation attempts. Contact support.");
                    isValidating.set(false);
                    return;
                }
                String hwid = generateHardwareId();
                if (checkDeviceBlacklist(hwid)) {
                    if (callback != null)
                        callback.onDeviceBlacklisted("Device is blacklisted");
                    isValidating.set(false);
                    return;
                }
                LicenseInfo info = onlineActivate(key, hwid);
                if (info != null && info.isValid()) {
                    currentLicense = info;
                    isActivated.set(true);
                    cacheLicense(info);
                    activationAttempts.set(0);
                    if (callback != null) callback.onActivationSuccess(info);
                } else {
                    activationAttempts.incrementAndGet();
                    if (callback != null)
                        callback.onActivationFailed("Server returned invalid license");
                }
            } catch (Exception e) {
                activationAttempts.incrementAndGet();
                LicenseInfo offline = validateOffline(key);
                if (offline != null && offline.isValid()) {
                    currentLicense = offline;
                    isActivated.set(true);
                    if (callback != null) callback.onActivationSuccess(offline);
                } else {
                    if (callback != null)
                        callback.onActivationFailed("Activation failed: " + e.getMessage());
                }
            } finally {
                isValidating.set(false);
            }
        }).start();
        return true;
    }

    public boolean validateLicense(LicenseCallback callback) {
        if (isValidating.getAndSet(true)) {
            if (callback != null) callback.onLicenseInvalid("Already validating");
            return false;
        }
        new Thread(() -> {
            try {
                if (currentLicense == null) {
                    if (startTrial()) {
                        if (callback != null)
                            callback.onTrialStarted(TRIAL_MAX_DAYS - trialDaysUsed.get());
                    } else {
                        if (callback != null)
                            callback.onLicenseInvalid("No license found and trial not available");
                    }
                    isValidating.set(false);
                    return;
                }
                if (currentLicense.isExpired()) {
                    if (callback != null) callback.onLicenseExpired(currentLicense);
                    isValidating.set(false);
                    return;
                }
                if (System.currentTimeMillis() - lastCheckTime.get() < CHECK_INTERVAL) {
                    if (currentLicense.isValid()) {
                        if (callback != null) callback.onLicenseValidated(currentLicense);
                    } else {
                        if (callback != null) callback.onLicenseInvalid("License invalid");
                    }
                    isValidating.set(false);
                    return;
                }
                String hwid = generateHardwareId();
                LicenseInfo serverInfo = onlineValidate(licenseKey, hwid);
                if (serverInfo != null && serverInfo.isValid()) {
                    currentLicense = serverInfo;
                    lastCheckTime.set(System.currentTimeMillis());
                    cacheLicense(serverInfo);
                    if (callback != null) callback.onLicenseValidated(serverInfo);
                } else {
                    LicenseInfo offlineCheck = validateOffline(licenseKey);
                    if (offlineCheck != null && offlineCheck.isValid()) {
                        if (callback != null) callback.onLicenseValidated(offlineCheck);
                    } else {
                        if (callback != null)
                            callback.onLicenseInvalid("License validation failed");
                    }
                }
            } catch (Exception e) {
                if (currentLicense != null && !currentLicense.isExpired()) {
                    if (callback != null) callback.onLicenseValidated(currentLicense);
                } else {
                    if (callback != null)
                        callback.onLicenseInvalid("Validation error: " + e.getMessage());
                }
            } finally {
                isValidating.set(false);
            }
        }).start();
        return true;
    }

    public boolean deactivateLicense(LicenseCallback callback) {
        new Thread(() -> {
            try {
                String hwid = generateHardwareId();
                onlineDeactivate(licenseKey, hwid);
                currentLicense = null;
                isActivated.set(false);
                clearCachedLicense();
                if (callback != null) callback.onLicenseValidated(null);
            } catch (Exception e) {
                currentLicense = null;
                isActivated.set(false);
                clearCachedLicense();
                if (callback != null) callback.onLicenseValidated(null);
            }
        }).start();
        return true;
    }

    public boolean startTrial() {
        try {
            loadTrialData();
            if (trialDaysUsed.get() >= TRIAL_MAX_DAYS) {
                return false;
            }
            if (currentLicense != null && currentLicense.isTrial) {
                return trialDaysUsed.get() < TRIAL_MAX_DAYS;
            }
            LicenseInfo trialInfo = new LicenseInfo();
            trialInfo.licenseKey = "trial-" + generateHardwareId().substring(0, 16);
            trialInfo.licenseType = "trial";
            trialInfo.hwid = generateHardwareId();
            trialInfo.issuedAt = System.currentTimeMillis();
            trialInfo.expiresAt = System.currentTimeMillis() +
                (TRIAL_MAX_DAYS - trialDaysUsed.get()) * 86400000L;
            trialInfo.isTrial = true;
            trialInfo.isLifetime = false;
            trialInfo.maxDevices = 1;
            trialInfo.currentDevices = 1;
            trialInfo.metadata = new HashMap<>();
            trialInfo.metadata.put("trial_start", String.valueOf(System.currentTimeMillis()));
            currentLicense = trialInfo;
            isActivated.set(true);
            saveTrialData();
            cacheLicense(trialInfo);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean checkDeviceBlacklist(String hwid) {
        try {
            URL url = new URL(LICENSE_SERVER + CHECK_BLACKLIST_ENDPOINT + "?hwid=" + hwid);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            try {
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(5000);
                int code = conn.getResponseCode();
                if (code == 200) {
                    try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(conn.getInputStream()))) {
                        String response = br.readLine();
                        return "blacklisted".equals(response);
                    }
                }
                return false;
            } finally {
                conn.disconnect();
            }
        } catch (Exception e) {
            return false;
        }
    }

    private LicenseInfo onlineActivate(String key, String hwid) throws LicenseException {
        try {
            URL url = new URL(LICENSE_SERVER + ACTIVATE_ENDPOINT);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            try {
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(15000);
                conn.setRequestProperty("Content-Type", "application/json");
                org.json.JSONObject body = new org.json.JSONObject();
                body.put("license_key", key);
                body.put("hwid", hwid);
                body.put("device_info", getDeviceInfo());
                byte[] payloadBytes = body.toString().getBytes("UTF-8");
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(payloadBytes);
                    os.flush();
                }
                int code = conn.getResponseCode();
                if (code == 200) {
                    try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(conn.getInputStream(), "UTF-8"))) {
                        StringBuilder response = new StringBuilder();
                        String line;
                        while ((line = br.readLine()) != null) response.append(line);
                        return parseLicenseResponse(response.toString());
                    }
                } else {
                    throw new LicenseException("Server returned code: " + code);
                }
            } finally {
                conn.disconnect();
            }
        } catch (LicenseException e) {
            throw e;
        } catch (Exception e) {
            throw new LicenseException("Activation network error", e);
        }
    }

    private LicenseInfo onlineValidate(String key, String hwid) {
        try {
            URL url = new URL(LICENSE_SERVER + VALIDATE_ENDPOINT);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            try {
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);
                conn.setRequestProperty("Content-Type", "application/json");
                org.json.JSONObject body = new org.json.JSONObject();
                body.put("license_key", key);
                body.put("hwid", hwid);
                byte[] payloadBytes = body.toString().getBytes("UTF-8");
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(payloadBytes);
                    os.flush();
                }
                int code = conn.getResponseCode();
                if (code == 200) {
                    try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(conn.getInputStream(), "UTF-8"))) {
                        StringBuilder response = new StringBuilder();
                        String line;
                        while ((line = br.readLine()) != null) response.append(line);
                        return parseLicenseResponse(response.toString());
                    }
                }
                return null;
            } finally {
                conn.disconnect();
            }
        } catch (Exception e) {
            return null;
        }
    }

    private void onlineDeactivate(String key, String hwid) throws LicenseException {
        try {
            URL url = new URL(LICENSE_SERVER + DEACTIVATE_ENDPOINT);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            try {
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);
                conn.setRequestProperty("Content-Type", "application/json");
                org.json.JSONObject body = new org.json.JSONObject();
                body.put("license_key", key);
                body.put("hwid", hwid);
                byte[] payloadBytes = body.toString().getBytes("UTF-8");
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(payloadBytes);
                    os.flush();
                }
                conn.getResponseCode();
            } finally {
                conn.disconnect();
            }
        } catch (Exception e) {
            throw new LicenseException("Deactivation failed", e);
        }
    }

    private LicenseInfo validateOffline(String key) {
        try {
            if (key == null || key.isEmpty()) return null;
            if (publicKeyPem == null || publicKeyPem.isEmpty()) return null;

            String[] parts = key.split("\\.");
            if (parts.length < 3) return null;

            String data      = parts[0];
            String signature = parts[1];

            byte[] sigBytes = Base64.decode(signature, Base64.URL_SAFE | Base64.NO_WRAP);
            byte[] keyBytes = Base64.decode(publicKeyPem, Base64.DEFAULT | Base64.NO_WRAP);

            X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
            KeyFactory kf = KeyFactory.getInstance("RSA");
            PublicKey pubKey = kf.generatePublic(spec);

            Signature sig = Signature.getInstance("SHA256withRSA");
            sig.initVerify(pubKey);
            sig.update(data.getBytes("UTF-8"));
            if (!sig.verify(sigBytes)) return null;

            String decoded = new String(Base64.decode(data, Base64.URL_SAFE | Base64.NO_WRAP), "UTF-8");
            String[] fields = decoded.split("\\|", -1);
            if (fields.length < 4) return null;

            LicenseInfo info = new LicenseInfo();
            info.licenseKey  = key;
            info.hwid        = fields[0];
            info.licenseType = fields[1];
            info.issuedAt    = safeParseLong(fields[2]);
            info.expiresAt   = safeParseLong(fields[3]);
            info.isLifetime  = "lifetime".equals(info.licenseType);
            info.isTrial     = "trial".equals(info.licenseType);
            info.metadata    = new HashMap<>();
            if (fields.length > 4) info.metadata.put("extra", fields[4]);

            String localHwid = generateHardwareId();
            if (!info.hwid.equals(localHwid) && !info.hwid.equals("any")) return null;

            return info;
        } catch (Exception e) {
            return null;
        }
    }

    private static long safeParseLong(String s) {
        try { return Long.parseLong(s.trim()); } catch (Exception e) { return 0L; }
    }

    private LicenseInfo parseLicenseResponse(String json) {
        try {
            JSONObject obj = new JSONObject(json);
            LicenseInfo info = new LicenseInfo();
            info.licenseKey = obj.optString("license_key");
            info.licenseType = obj.optString("license_type");
            info.hwid = obj.optString("hwid");
            info.issuedAt = obj.optLong("issued_at");
            info.expiresAt = obj.optLong("expires_at");
            info.isTrial = "trial".equals(info.licenseType);
            info.isLifetime = "lifetime".equals(info.licenseType);
            info.maxDevices = obj.optInt("max_devices");
            info.currentDevices = obj.optInt("current_devices");
            info.email = obj.optString("email");
            info.productId = obj.optString("product_id");
            info.metadata = new HashMap<>();
            return info;
        } catch (Exception e) {
            return null;
        }
    }

    private byte[] deriveDeviceKey() {
        try {
            String salt = "bugor-engine-cache-salt-v1";
            String fingerprint = Build.FINGERPRINT;
            String androidId = Settings.Secure.getString(
                context.getContentResolver(), Settings.Secure.ANDROID_ID);
            String seed = salt + "|" + (androidId != null ? androidId : "unknown") +
                          "|" + (fingerprint != null ? fingerprint : "nofp");
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return md.digest(seed.getBytes("UTF-8"));
        } catch (Exception e) {
            byte[] fallback = new byte[32];
            for (int i = 0; i < 32; i++) fallback[i] = (byte) (i * 7 + 0x42);
            return fallback;
        }
    }

    private void cacheLicense(LicenseInfo info) {
        try {
            File cacheFile = new File(context.getCacheDir(), CACHE_FILE);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(info);
            oos.close();
            byte[] data = baos.toByteArray();
            byte[] keyBytes = deriveDeviceKey();
            SecretKey key = new SecretKeySpec(keyBytes, "AES");
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] iv = cipher.getIV();
            byte[] encrypted = cipher.doFinal(data);
            FileOutputStream fos = new FileOutputStream(cacheFile);
            fos.write(iv);
            fos.write(encrypted);
            fos.close();
        } catch (Exception e) {
            try {
                File cacheFile = new File(context.getCacheDir(), CACHE_FILE);
                FileOutputStream fos = new FileOutputStream(cacheFile);
                ObjectOutputStream oos = new ObjectOutputStream(fos);
                oos.writeObject(info);
                oos.close();
            } catch (Exception ex) {
            }
        }
    }

    private void loadCachedLicense() {
        try {
            File cacheFile = new File(context.getCacheDir(), CACHE_FILE);
            if (!cacheFile.exists()) return;
            byte[] keyBytes = deriveDeviceKey();
            SecretKey key = new SecretKeySpec(keyBytes, "AES");
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            byte[] fileBytes = new byte[(int) cacheFile.length()];
            try (FileInputStream fis = new FileInputStream(cacheFile)) {
                int total = 0;
                while (total < fileBytes.length) {
                    int r = fis.read(fileBytes, total, fileBytes.length - total);
                    if (r < 0) break;
                    total += r;
                }
            }
            if (fileBytes.length < 17) {
                return;
            }
            byte[] iv = new byte[16];
            System.arraycopy(fileBytes, 0, iv, 0, 16);
            byte[] encrypted = new byte[fileBytes.length - 16];
            System.arraycopy(fileBytes, 16, encrypted, 0, encrypted.length);
            cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(iv));
            byte[] decrypted = cipher.doFinal(encrypted);
            try (ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(decrypted))) {
                currentLicense = (LicenseInfo) ois.readObject();
            }
        } catch (Exception e) {
            currentLicense = null;
        }
    }

    private void clearCachedLicense() {
        try {
            File cacheFile = new File(context.getCacheDir(), CACHE_FILE);
            if (cacheFile.exists()) cacheFile.delete();
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            prefs.edit().clear().apply();
        } catch (Exception e) {
        }
    }

    private void loadTrialData() {
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            trialDaysUsed.set(prefs.getInt("trial_days_used", 0));
            File trialFile = new File(context.getFilesDir(), "t.dat");
            if (trialFile.exists()) {
                FileInputStream fis = new FileInputStream(trialFile);
                byte[] data = new byte[(int) trialFile.length()];
                fis.read(data);
                fis.close();
                String content = new String(data, "UTF-8");
                String[] parts = content.split("\\|");
                if (parts.length >= 2) {
                    trialDaysUsed.set(Integer.parseInt(parts[0]));
                }
            }
        } catch (Exception e) {
            trialDaysUsed.set(0);
        }
    }

    private void saveTrialData() {
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            prefs.edit().putInt("trial_days_used", trialDaysUsed.get()).apply();
            File trialFile = new File(context.getFilesDir(), "t.dat");
            FileOutputStream fos = new FileOutputStream(trialFile);
            String data = trialDaysUsed.get() + "|" + System.currentTimeMillis();
            fos.write(data.getBytes("UTF-8"));
            fos.close();
        } catch (Exception e) {
        }
    }

    public boolean isLicenseValid() {
        return currentLicense != null && currentLicense.isValid() && isActivated.get();
    }

    public boolean isTrialActive() {
        return currentLicense != null && currentLicense.isTrial && !currentLicense.isExpired();
    }

    public int getTrialDaysRemaining() {
        if (currentLicense == null || !currentLicense.isTrial) return 0;
        return (int) currentLicense.remainingDays();
    }

    public LicenseInfo getCurrentLicense() {
        return currentLicense;
    }

    public String getLicenseType() {
        if (currentLicense == null) return "none";
        return currentLicense.licenseType;
    }

    public long getLicenseExpiry() {
        if (currentLicense == null) return 0;
        return currentLicense.expiresAt;
    }

    public String getFormattedExpiryDate() {
        if (currentLicense == null || currentLicense.expiresAt == 0) return "N/A";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        return sdf.format(new Date(currentLicense.expiresAt));
    }

    public boolean isLifetime() {
        return currentLicense != null && currentLicense.isLifetime;
    }

    public boolean requiresActivation() {
        return currentLicense == null || !isActivated.get();
    }

    public void registerCallback(String id, LicenseCallback callback) {
        callbacks.put(id, callback);
    }

    public void unregisterCallback(String id) {
        callbacks.remove(id);
    }

    public boolean verifyLicenseSignature(String data, String signature) {
        try {
            byte[] sigBytes = Base64.decode(signature, Base64.URL_SAFE);
            byte[] keyBytes = Base64.decode(publicKeyPem, Base64.DEFAULT);
            X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
            KeyFactory kf = KeyFactory.getInstance("RSA");
            PublicKey pubKey = kf.generatePublic(spec);
            Signature sig = Signature.getInstance("SHA256withRSA");
            sig.initVerify(pubKey);
            sig.update(data.getBytes("UTF-8"));
            return sig.verify(sigBytes);
        } catch (Exception e) {
            return false;
        }
    }

    public String signData(String data) {
        throw new UnsupportedOperationException("signData requires private key not available in client");
    }

    private String getDeviceInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append(Build.MODEL).append("|");
        sb.append(Build.MANUFACTURER).append("|");
        sb.append(Build.VERSION.RELEASE).append("|");
        sb.append(Build.VERSION.SDK_INT).append("|");
        sb.append(Build.BOARD).append("|");
        sb.append(Build.BRAND).append("|");
        sb.append(Build.DEVICE).append("|");
        sb.append(Build.HARDWARE).append("|");
        sb.append(Build.PRODUCT).append("|");
        sb.append(Build.FINGERPRINT);
        return sb.toString();
    }

    public boolean checkLicenseIntegrity() {
        if (currentLicense == null) return false;
        if (currentLicense.issuedAt > System.currentTimeMillis()) return false;
        if (currentLicense.expiresAt > 0 && currentLicense.expiresAt < currentLicense.issuedAt)
            return false;
        if (currentLicense.maxDevices > 0 && currentLicense.currentDevices > currentLicense.maxDevices)
            return false;
        return true;
    }

    public int getActivationAttempts() {
        return activationAttempts.get();
    }

    public boolean isBlacklisted() {
        try {
            String hwid = generateHardwareId();
            File blacklistFile = new File(context.getFilesDir(), "blacklist.dat");
            if (blacklistFile.exists()) {
                FileInputStream fis = new FileInputStream(blacklistFile);
                BufferedReader br = new BufferedReader(new InputStreamReader(fis));
                String line;
                while ((line = br.readLine()) != null) {
                    if (line.trim().equals(hwid)) {
                        br.close();
                        return true;
                    }
                }
                br.close();
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    public void resetLicense() {
        currentLicense = null;
        isActivated.set(false);
        licenseKey = null;
        activationAttempts.set(0);
        trialDaysUsed.set(0);
        clearCachedLicense();
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().clear().apply();
    }

    public boolean extendTrial(int additionalDays) {
        if (currentLicense == null || !currentLicense.isTrial) return false;
        currentLicense.expiresAt += additionalDays * 86400000L;
        cacheLicense(currentLicense);
        saveTrialData();
        return true;
    }

    public boolean convertTrialToFull(String licenseKey) {
        if (currentLicense == null || !currentLicense.isTrial) return false;
        this.licenseKey = licenseKey;
        return activateLicense(licenseKey, null);
    }

    public boolean isActivated() {
        return isActivated.get();
    }

    public boolean isValidationInProgress() {
        return isValidating.get();
    }

    public long getLastCheckTime() {
        return lastCheckTime.get();
    }

    public void forceRevalidation() {
        lastCheckTime.set(0);
    }

    public void updateLicenseInfo(LicenseInfo info) {
        if (info != null) {
            currentLicense = info;
            cacheLicense(info);
        }
    }
}
