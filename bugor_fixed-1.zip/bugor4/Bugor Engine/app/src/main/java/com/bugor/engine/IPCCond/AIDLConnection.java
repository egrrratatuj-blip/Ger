package com.bugor.engine.IPCCond;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;

public class AIDLConnection implements ServiceConnection {
    private final boolean daemon;

    public AIDLConnection(boolean d) { daemon = d; }

    public void onServiceConnected(ComponentName name, IBinder service) {
        IMutual stub = IMutual.Stub.asInterface(service);
        IPCService.init(stub);
    }

    public void onServiceDisconnected(ComponentName name) { IPCService.init(null); }
}
