package com.bugor.engine;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BugorBridge {
    private static final String TAG = "BugorBridge";

    private static BugorBridge instance;
    private Context context;
    private Handler mainHandler;
    private ExecutorService executor;
    private boolean initialized = false;
    private Runnable onReadyCallback;

    private BugorBridge(Context context) {
        this.context = context;
        this.mainHandler = new Handler(Looper.getMainLooper());
        this.executor = Executors.newFixedThreadPool(4);
    }

    public static synchronized BugorBridge getInstance(Context context) {
        if (instance == null) {
            instance = new BugorBridge(context.getApplicationContext());
        }
        return instance;
    }

    public static BugorBridge getInstance() {
        return instance;
    }

    public void initialize(Runnable onReady) {
        this.onReadyCallback = onReady;
        executor.execute(() -> {
            try {
                String configPath = context.getFilesDir().getAbsolutePath() + "/config.json";
                boolean success = SuperJNI.initialize(configPath);
                if (success) {
                    initialized = true;
                    Log.i(TAG, "Engine initialized successfully, version: " + SuperJNI.getVersion());
                }
                if (onReadyCallback != null) {
                    mainHandler.post(onReadyCallback);
                }
            } catch (Exception e) {
                Log.e(TAG, "Initialization error: " + e.getMessage());
            }
        });
    }

    public void shutdown() {
        executor.execute(() -> {
            try {
                SuperJNI.shutdown();
            } catch (UnsatisfiedLinkError e) {
                Log.e(TAG, "shutdown native error: " + e.getMessage());
            }
            initialized = false;
        });
    }

    public boolean isInitialized() { return initialized; }

    public boolean nativeInitialize(String configPath) {
        try {
            return SuperJNI.initialize(configPath);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeInitialize error: " + e.getMessage());
            return false;
        }
    }

    public boolean nativeShutdown() {
        try {
            return SuperJNI.shutdown();
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeShutdown error: " + e.getMessage());
            return false;
        }
    }

    public boolean nativeIsInitialized() {
        try {
            return SuperJNI.isInitialized();
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeIsInitialized error: " + e.getMessage());
            return false;
        }
    }

    public String nativeGetVersion() {
        try {
            String v = SuperJNI.getVersion();
            return v != null ? v : "";
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeGetVersion error: " + e.getMessage());
            return "";
        }
    }

    public boolean nativeExecuteScript(String script) {
        try {
            return SuperJNI.executeScript(script);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeExecuteScript error: " + e.getMessage());
            return false;
        }
    }

    public String nativeExecuteCommand(String command) {
        try {
            String r = SuperJNI.executeCommand(command);
            return r != null ? r : "";
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeExecuteCommand error: " + e.getMessage());
            return "";
        }
    }

    public long nativeReadLong(long address) {
        try {
            return SuperJNI.readLong(address);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeReadLong error: " + e.getMessage());
            return 0;
        }
    }

    public int nativeReadInt(long address) {
        try {
            return SuperJNI.readInt(address);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeReadInt error: " + e.getMessage());
            return 0;
        }
    }

    public float nativeReadFloat(long address) {
        try {
            return SuperJNI.readFloat(address);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeReadFloat error: " + e.getMessage());
            return 0f;
        }
    }

    public double nativeReadDouble(long address) {
        try {
            return SuperJNI.readDouble(address);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeReadDouble error: " + e.getMessage());
            return 0.0;
        }
    }

    public boolean nativeWriteLong(long address, long value) {
        try {
            return SuperJNI.writeLong(address, value);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeWriteLong error: " + e.getMessage());
            return false;
        }
    }

    public boolean nativeWriteInt(long address, int value) {
        try {
            return SuperJNI.writeInt(address, value);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeWriteInt error: " + e.getMessage());
            return false;
        }
    }

    public boolean nativeWriteFloat(long address, float value) {
        try {
            return SuperJNI.writeFloat(address, value);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeWriteFloat error: " + e.getMessage());
            return false;
        }
    }

    public boolean nativeWriteDouble(long address, double value) {
        try {
            return SuperJNI.writeDouble(address, value);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeWriteDouble error: " + e.getMessage());
            return false;
        }
    }

    public String nativeSearchMemory(int valueType, long value, int valueSize, long regionStart, long regionEnd) {
        try {
            String r = SuperJNI.searchMemory(valueType, value, valueSize, regionStart, regionEnd);
            return r != null ? r : "[]";
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeSearchMemory error: " + e.getMessage());
            return "[]";
        }
    }

    public boolean nativePatchMemory(long address, byte[] patchData) {
        try {
            return SuperJNI.patchMemory(address, patchData);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativePatchMemory error: " + e.getMessage());
            return false;
        }
    }

    public long nativeGetModuleBase(String moduleName) {
        try {
            return SuperJNI.getModuleBase(moduleName);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeGetModuleBase error: " + e.getMessage());
            return 0;
        }
    }

    public String nativeDumpMemory(long address, int size) {
        try {
            String r = SuperJNI.dumpMemory(address, size);
            return r != null ? r : "";
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeDumpMemory error: " + e.getMessage());
            return "";
        }
    }

    public int nativeInstallHook(long targetAddress, long hookFunction) {
        try {
            return SuperJNI.installHook(targetAddress, hookFunction);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeInstallHook error: " + e.getMessage());
            return -1;
        }
    }

    public boolean nativeUninstallHook(int hookId) {
        try {
            return SuperJNI.uninstallHook(hookId);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeUninstallHook error: " + e.getMessage());
            return false;
        }
    }

    public boolean nativeFreezeValue(long address, long value, int valueType) {
        try {
            return SuperJNI.freezeValue(address, value, valueType);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeFreezeValue error: " + e.getMessage());
            return false;
        }
    }

    public boolean nativeUnfreezeValue(long address) {
        try {
            return SuperJNI.unfreezeValue(address);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeUnfreezeValue error: " + e.getMessage());
            return false;
        }
    }

    public boolean nativeUnfreezeAll() {
        try {
            return SuperJNI.unfreezeAll();
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeUnfreezeAll error: " + e.getMessage());
            return false;
        }
    }

    public boolean nativeProtectMemory(long address, long size, int protection) {
        try {
            return SuperJNI.protectMemory(address, size, protection);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeProtectMemory error: " + e.getMessage());
            return false;
        }
    }

    public long nativeAllocateMemory(long size, int protection) {
        try {
            return SuperJNI.allocateMemory(size, protection);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeAllocateMemory error: " + e.getMessage());
            return 0;
        }
    }

    public boolean nativeFreeMemory(long address) {
        try {
            return SuperJNI.freeMemory(address);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeFreeMemory error: " + e.getMessage());
            return false;
        }
    }

    public String nativeGetRegions() {
        try {
            String r = SuperJNI.getRegions();
            return r != null ? r : "[]";
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeGetRegions error: " + e.getMessage());
            return "[]";
        }
    }

    public boolean nativeLoadScriptFile(String path) {
        try {
            return SuperJNI.loadScriptFile(path);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeLoadScriptFile error: " + e.getMessage());
            return false;
        }
    }

    public boolean nativeLoadScript(String name, String source) {
        try {
            return SuperJNI.loadScript(name, source);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeLoadScript error: " + e.getMessage());
            return false;
        }
    }

    public boolean nativeConnectRemote(String host, int port, String apiKey) {
        try {
            return SuperJNI.connectRemote(host, port, apiKey);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeConnectRemote error: " + e.getMessage());
            return false;
        }
    }

    public boolean nativeDisconnectRemote() {
        try {
            return SuperJNI.disconnectRemote();
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeDisconnectRemote error: " + e.getMessage());
            return false;
        }
    }

    public String nativeSendRemoteCommand(String command, String args) {
        try {
            String r = SuperJNI.sendRemoteCommand(command, args);
            return r != null ? r : "";
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeSendRemoteCommand error: " + e.getMessage());
            return "";
        }
    }

    public String nativeEncrypt(String data, String key) {
        try {
            String r = SuperJNI.encrypt(data, key);
            return r != null ? r : "";
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeEncrypt error: " + e.getMessage());
            return "";
        }
    }

    public String nativeDecrypt(String data, String key) {
        try {
            String r = SuperJNI.decrypt(data, key);
            return r != null ? r : "";
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeDecrypt error: " + e.getMessage());
            return "";
        }
    }

    public String nativeHash(String data) {
        try {
            String r = SuperJNI.hash(data);
            return r != null ? r : "";
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeHash error: " + e.getMessage());
            return "";
        }
    }

    public String nativeGetMetrics() {
        try {
            String r = SuperJNI.getMetrics();
            return r != null ? r : "";
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeGetMetrics error: " + e.getMessage());
            return "";
        }
    }

    public void nativeSetLogLevel(int level) {
        try {
            SuperJNI.setLogLevel(level);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeSetLogLevel error: " + e.getMessage());
        }
    }

    public void nativeLog(int level, String message) {
        try {
            SuperJNI.log(level, message);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeLog error: " + e.getMessage());
        }
    }

    public boolean nativeAttachDebugger(int pid) {
        try {
            return SuperJNI.attachDebugger(pid);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeAttachDebugger error: " + e.getMessage());
            return false;
        }
    }

    public boolean nativeDetachDebugger() {
        try {
            return SuperJNI.detachDebugger();
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeDetachDebugger error: " + e.getMessage());
            return false;
        }
    }

    public boolean nativeSetBreakpoint(long address) {
        try {
            return SuperJNI.setBreakpoint(address);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeSetBreakpoint error: " + e.getMessage());
            return false;
        }
    }

    public boolean nativeStoreValue(String key, String value) {
        try {
            return SuperJNI.storeValue(key, value);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeStoreValue error: " + e.getMessage());
            return false;
        }
    }

    public String nativeLoadValue(String key) {
        try {
            String r = SuperJNI.loadValue(key);
            return r != null ? r : "";
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeLoadValue error: " + e.getMessage());
            return "";
        }
    }

    public boolean nativeDeleteValue(String key) {
        try {
            return SuperJNI.deleteValue(key);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeDeleteValue error: " + e.getMessage());
            return false;
        }
    }

    public String nativeGetHealthStatus() {
        try {
            String r = SuperJNI.getHealthStatus();
            return r != null ? r : "";
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeGetHealthStatus error: " + e.getMessage());
            return "";
        }
    }

    public long nativeGetEnginePointer() {
        try {
            return SuperJNI.getEnginePointer();
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeGetEnginePointer error: " + e.getMessage());
            return 0;
        }
    }

    public int nativeGetState() {
        try {
            return SuperJNI.getState();
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeGetState error: " + e.getMessage());
            return -1;
        }
    }

    public boolean nativePause() {
        try {
            return SuperJNI.pause();
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativePause error: " + e.getMessage());
            return false;
        }
    }

    public boolean nativeResume() {
        try {
            return SuperJNI.resume();
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeResume error: " + e.getMessage());
            return false;
        }
    }

    public boolean nativeRestart() {
        try {
            return SuperJNI.restart();
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeRestart error: " + e.getMessage());
            return false;
        }
    }

    public String nativeGetBuildInfo() {
        try {
            String r = SuperJNI.getBuildInfo();
            return r != null ? r : "";
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeGetBuildInfo error: " + e.getMessage());
            return "";
        }
    }

    public boolean nativeRegisterFunction(String name, long funcPtr) {
        try {
            return SuperJNI.registerFunction(name, funcPtr);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeRegisterFunction error: " + e.getMessage());
            return false;
        }
    }

    public boolean nativeStartServer(int port) {
        try {
            return SuperJNI.startServer(port);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeStartServer error: " + e.getMessage());
            return false;
        }
    }

    public boolean nativeStopServer() {
        try {
            return SuperJNI.stopServer();
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeStopServer error: " + e.getMessage());
            return false;
        }
    }

    public void nativeRegisterFunctionDirect(String name, long ptr) {
        try {
            SuperJNI.nativeRegisterFunction(name, ptr);
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeRegisterFunction error: " + e.getMessage());
        }
    }

    public void nativeStartServerDefault() {
        try {
            SuperJNI.nativeStartServer();
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "nativeStartServer error: " + e.getMessage());
        }
    }

    public boolean writeLong(long address, long value) {
        return nativeWriteLong(address, value);
    }

    public boolean writeInt(long address, int value) {
        return nativeWriteInt(address, value);
    }

    public boolean writeFloat(long address, float value) {
        return nativeWriteFloat(address, value);
    }

    public boolean writeDouble(long address, double value) {
        return nativeWriteDouble(address, value);
    }

    public long readLong(long address) {
        return nativeReadLong(address);
    }

    public int readInt(long address) {
        return nativeReadInt(address);
    }

    public float readFloat(long address) {
        return nativeReadFloat(address);
    }

    public double readDouble(long address) {
        return nativeReadDouble(address);
    }

    public List<Map<String, Object>> searchMemory(int valueType, long value, int valueSize, long regionStart, long regionEnd) {
        String json = nativeSearchMemory(valueType, value, valueSize, regionStart, regionEnd);
        return parseSearchResults(json);
    }

    public void patchMemory(long address, byte[] data) {
        nativePatchMemory(address, data);
    }

    public void freezeValue(long address, long value, int type) {
        nativeFreezeValue(address, value, type);
    }

    public void unfreezeValue(long address) {
        nativeUnfreezeValue(address);
    }

    public void unfreezeAll() {
        nativeUnfreezeAll();
    }

    public long getModuleBase(String moduleName) {
        return nativeGetModuleBase(moduleName);
    }

    public void installHook(long target, long hookFunc) {
        nativeInstallHook(target, hookFunc);
    }

    public void uninstallHook(int hookId) {
        nativeUninstallHook(hookId);
    }

    public String executeCommand(String command) {
        return nativeExecuteCommand(command);
    }

    public void executeScript(String script) {
        nativeExecuteScript(script);
    }

    public void loadScript(String name, String source) {
        nativeLoadScript(name, source);
    }

    public String getVersion() {
        return nativeGetVersion();
    }

    public String getBuildInfo() {
        return nativeGetBuildInfo();
    }

    public List<Map<String, Object>> getMemoryRegions() {
        String json = nativeGetRegions();
        return parseRegionResults(json);
    }

    public long allocateMemory(long size, int protection) {
        return nativeAllocateMemory(size, protection);
    }

    public void freeMemory(long address) {
        nativeFreeMemory(address);
    }

    public void protectMemory(long address, long size, int protection) {
        nativeProtectMemory(address, size, protection);
    }

    public void setLogLevel(int level) {
        nativeSetLogLevel(level);
    }

    public void log(int level, String message) {
        nativeLog(level, message);
    }

    public boolean connectRemote(String host, int port, String apiKey) {
        return nativeConnectRemote(host, port, apiKey);
    }

    public void disconnectRemote() {
        nativeDisconnectRemote();
    }

    public String sendRemoteCommand(String command, String args) {
        return nativeSendRemoteCommand(command, args);
    }

    public String encrypt(String data, String key) {
        return nativeEncrypt(data, key);
    }

    public String decrypt(String data, String key) {
        return nativeDecrypt(data, key);
    }

    public String hash(String data) {
        return nativeHash(data);
    }

    public void storeValue(String key, String value) {
        nativeStoreValue(key, value);
    }

    public String loadValue(String key) {
        return nativeLoadValue(key);
    }

    public void deleteValue(String key) {
        nativeDeleteValue(key);
    }

    public boolean attachDebugger(int pid) {
        return nativeAttachDebugger(pid);
    }

    public static boolean isModuleLoaded(String moduleName) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream("/proc/self/maps")));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(moduleName)) {
                    reader.close();
                    return true;
                }
            }
            reader.close();
        } catch (Exception e) {
            Log.e(TAG, "Error checking module: " + e.getMessage());
        }
        return false;
    }

    public static boolean isRooted() {
        for (String path : new String[]{
                "/system/app/Superuser.apk",
                "/sbin/su",
                "/system/bin/su",
                "/system/xbin/su",
                "/data/local/xbin/su",
                "/data/local/bin/su",
                "/system/sd/xbin/su",
                "/system/bin/failsafe/su",
                "/data/local/su",
                "/su/bin/su"
        }) {
            if (new File(path).exists()) return true;
        }
        return false;
    }

    public static int getTargetSDKVersion() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return 30;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return 29;
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            return 28;
        }
        return Build.VERSION.SDK_INT;
    }

    public static boolean isServiceRunning(Context context, Class<?> serviceClass) {
        try {
            ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                android.app.NotificationManager nm =
                    (android.app.NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                return nm != null;
            }
            if (manager == null) return false;
            for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
                if (serviceClass.getName().equals(service.service.getClassName())) return true;
            }
        } catch (Exception e) {
            Log.e(TAG, "isServiceRunning error: " + e.getMessage());
        }
        return false;
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> parseSearchResults(String json) {
        List<Map<String, Object>> results = new ArrayList<>();
        try {
            if (json == null || json.equals("[]")) return results;
            json = json.trim();
            if (json.startsWith("[")) json = json.substring(1, json.length() - 1);
            String[] items = json.split("\\},\\{");
            for (String item : items) {
                item = item.replace("{", "").replace("}", "");
                Map<String, Object> map = new HashMap<>();
                String[] pairs = item.split(",");
                for (String pair : pairs) {
                    String[] kv = pair.split(":", 2);
                    if (kv.length == 2) {
                        String key = kv[0].replace("\"", "").trim();
                        String val = kv[1].trim();
                        if (key.equals("address") || key.equals("value") || key.equals("size")) {
                            if (val.contains(".")) {
                                map.put(key, Double.parseDouble(val));
                            } else {
                                map.put(key, Long.parseLong(val));
                            }
                        } else {
                            map.put(key, val);
                        }
                    }
                }
                results.add(map);
            }
        } catch (Exception e) {
            Log.e(TAG, "Parse error: " + e.getMessage());
        }
        return results;
    }

    private List<Map<String, Object>> parseRegionResults(String json) {
        List<Map<String, Object>> results = new ArrayList<>();
        try {
            if (json == null || json.equals("[]")) return results;
            json = json.trim();
            if (json.startsWith("[")) json = json.substring(1, json.length() - 1);
            String[] items = json.split("\\},\\{");
            for (String item : items) {
                item = item.replace("{", "").replace("}", "");
                Map<String, Object> map = new HashMap<>();
                String[] pairs = item.split(",");
                for (String pair : pairs) {
                    String[] kv = pair.split(":", 2);
                    if (kv.length == 2) {
                        String key = kv[0].replace("\"", "").trim();
                        String val = kv[1].trim();
                        if (val.equals("true") || val.equals("false")) {
                            map.put(key, Boolean.parseBoolean(val));
                        } else if (key.equals("path")) {
                            map.put(key, val.replace("\"", ""));
                        } else {
                            try {
                                map.put(key, Long.parseLong(val));
                            } catch (NumberFormatException e) {
                                map.put(key, val);
                            }
                        }
                    }
                }
                results.add(map);
            }
        } catch (Exception e) {
            Log.e(TAG, "Parse region error: " + e.getMessage());
        }
        return results;
    }

    public static String getAppVersionName(Context context) {
        try {
            PackageInfo info = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            return info.versionName;
        } catch (Exception e) {
            return "unknown";
        }
    }

    public static int getAppVersionCode(Context context) {
        try {
            PackageInfo info = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            return info.versionCode;
        } catch (Exception e) {
            return 0;
        }
    }

    public static boolean hasOverlayPermission(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return Settings.canDrawOverlays(context);
        }
        return true;
    }

    public static void requestOverlayPermission(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(activity)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + activity.getPackageName()));
                activity.startActivityForResult(intent, 1001);
            }
        }
    }

    private static RootShell rootShell;
    private static volatile boolean rootReady = false;

    public static synchronized RootShell getRootShell(Context context) {
        if (rootShell == null) {
            rootShell = RootShell.getInstance(context);
            rootReady = false;
            new Thread(() -> {
                rootShell.initialize();
                rootReady = true;
            }, "RootShell-Init").start();
        }
        return rootShell;
    }

    public static boolean isRootReady() { return rootReady; }

    public static RootShell getRootShellWhenReady(Context context, long timeoutMs) {
        RootShell shell = getRootShell(context);
        long deadline = System.currentTimeMillis() + timeoutMs;
        while (!rootReady && System.currentTimeMillis() < deadline) {
            try { Thread.sleep(50); } catch (InterruptedException e) { break; }
        }
        return shell;
    }

    public static boolean isRootAvailable(Context context) {
        RootShell shell = getRootShell(context);
        if (!shell.isRootAvailable()) {
            shell.refresh();
        }
        return shell.isRootAvailable();
    }

    public static int rootExec(Context context, String command) {
        try {
            return getRootShell(context).execSync(command);
        } catch (Exception e) {
            return -1;
        }
    }

    public static String rootExecWithOutput(Context context, String command) {
        try {
            return getRootShell(context).execSyncWithOutput(command);
        } catch (Exception e) {
            return "";
        }
    }

    public static int rootGetPid(Context context, String processName) {
        try {
            return getRootShell(context).getPidByName(processName);
        } catch (Exception e) {
            return -1;
        }
    }

    public static long rootGetModuleBase(Context context, int pid, String moduleName) {
        try {
            return getRootShell(context).getModuleBase(pid, moduleName);
        } catch (Exception e) {
            return 0L;
        }
    }

    public static String[] rootListModules(Context context, int pid) {
        try {
            return getRootShell(context).listModules(pid);
        } catch (Exception e) {
            return new String[0];
        }
    }

    public static boolean rootWriteMemory(Context context, int pid, long address, byte[] data) {
        try {
            return getRootShell(context).writeMemory(pid, address, data);
        } catch (Exception e) {
            return false;
        }
    }

    public static byte[] rootReadMemory(Context context, int pid, long address, int size) {
        try {
            String base64 = getRootShell(context).readMemory(pid, address, size);
            if (base64 == null || base64.isEmpty()) return new byte[0];
            return android.util.Base64.decode(base64, android.util.Base64.NO_WRAP);
        } catch (Exception e) {
            return new byte[0];
        }
    }

    public static boolean rootMount(Context context, String source, String target) {
        try {
            return getRootShell(context).mountFile(source, target);
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean rootSetSELinux(Context context, String path, String contextStr) {
        try {
            return getRootShell(context).setSELinuxContext(path, contextStr);
        } catch (Exception e) {
            return false;
        }
    }
}
