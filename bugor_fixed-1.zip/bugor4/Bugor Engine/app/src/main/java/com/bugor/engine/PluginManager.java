package com.bugor.engine;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.provider.Settings;
import android.util.Base64;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLClassLoader;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import dalvik.system.DexClassLoader;

public class PluginManager {
    private static volatile PluginManager instance;
    private Context context;
    private ExecutorService executor = Executors.newFixedThreadPool(4);
    private Handler mainHandler = new Handler(Looper.getMainLooper());
    private Map<String, PluginInfo> plugins = new ConcurrentHashMap<>();
    private Map<String, PluginState> pluginStates = new ConcurrentHashMap<>();
    private Map<String, DexClassLoader> classLoaders = new ConcurrentHashMap<>();
    private Map<String, Object> pluginInstances = new ConcurrentHashMap<>();
    private Map<String, List<PluginBridge>> bridges = new ConcurrentHashMap<>();
    private String pluginsDir;
    private String pluginsDataDir;
    private AtomicBoolean isLoading = new AtomicBoolean(false);
    private AtomicInteger activePluginCount = new AtomicInteger(0);
    private List<PluginEventListener> eventListeners = new CopyOnWriteArrayList<>();
    private static final String PLUGIN_DIR_NAME = "plugins";
    private static final String PLUGIN_DATA_DIR_NAME = "plugin_data";
    private static final String PLUGIN_MANIFEST_FILE = "plugin.json";
    private static final String PLUGIN_STATE_FILE = "plugin_states.json";
    private static final String MARKETPLACE_URL = "https://plugins.bugor-engine.com/api/v1";
    private static final String PLUGIN_EXTENSION_APK = ".apk";
    private static final String PLUGIN_EXTENSION_SO = ".so";
    private static final int MAX_PLUGIN_SIZE = 52428800;
    private static final String[] TRUSTED_PLUGIN_HASHES = new String[0];

    public static class PluginInfo {
        public String id;
        public String name;
        public String version;
        public int versionCode;
        public String description;
        public String author;
        public String packageName;
        public String entryClass;
        public String[] nativeLibs;
        public String[] permissions;
        public String[] dependencies;
        public int minSdk;
        public int targetSdk;
        public String type;
        public long size;
        public String filePath;
        public String checksum;
        public String icon;
        public String[] categories;
        public Map<String, String> metadata;
        public long installedAt;
        public long updatedAt;
    }

    public static class PluginState {
        public String pluginId;
        public boolean enabled;
        public boolean loaded;
        public boolean running;
        public long lastLoaded;
        public int loadCount;
        public String lastError;
        public Map<String, Object> persistedState;
    }

    public static class PluginBridge {
        public String pluginId;
        public String interfaceName;
        public Object implementation;
        public Method[] methods;
        public boolean isNative;
    }

    public interface PluginEventListener {
        void onPluginLoaded(PluginInfo info);
        void onPluginUnloaded(PluginInfo info);
        void onPluginEnabled(PluginInfo info);
        void onPluginDisabled(PluginInfo info);
        void onPluginError(PluginInfo info, String error);
        void onPluginInstalled(PluginInfo info);
        void onPluginUninstalled(String pluginId);
    }

    public interface PluginMarketplaceCallback {
        void onPluginsListed(List<PluginInfo> plugins);
        void onPluginDownloaded(PluginInfo info, File file);
        void onError(String error);
    }

    public static class PluginException extends Exception {
        public PluginException(String message) { super(message); }
        public PluginException(String message, Throwable cause) { super(message, cause); }
    }

    public static class PluginInterface {
        public String getName() { return "plugin"; }
        public void onLoad(Context context) {}
        public void onUnload() {}
        public void onEnable() {}
        public void onDisable() {}
        public void onTick() {}
        public void onMessage(String sender, String type, byte[] data) {}
    }

    private PluginManager(Context context) {
        this.context = context.getApplicationContext();
        this.pluginsDir = context.getFilesDir().getAbsolutePath() +
            File.separator + PLUGIN_DIR_NAME;
        this.pluginsDataDir = context.getFilesDir().getAbsolutePath() +
            File.separator + PLUGIN_DATA_DIR_NAME;
        new File(pluginsDir).mkdirs();
        new File(pluginsDataDir).mkdirs();
        loadPluginStates();
    }

    public static PluginManager getInstance(Context context) {
        if (instance == null) {
            synchronized (PluginManager.class) {
                if (instance == null) {
                    instance = new PluginManager(context);
                }
            }
        }
        return instance;
    }

    public PluginInfo installPlugin(File apkFile) throws PluginException {
        try {
            if (!apkFile.exists()) throw new PluginException("Plugin file not found");
            if (apkFile.length() > MAX_PLUGIN_SIZE)
                throw new PluginException("Plugin too large");
            String checksum = calculateChecksum(apkFile);
            PluginInfo info = parsePluginManifest(apkFile);
            if (info == null) throw new PluginException("Invalid plugin manifest");
            info.size = apkFile.length();
            info.checksum = checksum;
            info.installedAt = System.currentTimeMillis();
            info.updatedAt = System.currentTimeMillis();
            String targetName = info.id + "_" + info.versionCode + PLUGIN_EXTENSION_APK;
            File targetFile = new File(pluginsDir, targetName);
            if (targetFile.exists()) targetFile.delete();
            copyFile(apkFile, targetFile);
            info.filePath = targetFile.getAbsolutePath();
            plugins.put(info.id, info);
            PluginState state = new PluginState();
            state.pluginId = info.id;
            state.enabled = true;
            state.loaded = false;
            state.persistedState = new HashMap<>();
            pluginStates.put(info.id, state);
            savePluginStates();
            notifyPluginsChanged();
            for (PluginEventListener l : eventListeners) {
                try { l.onPluginInstalled(info); } catch (Exception e) {}
            }
            return info;
        } catch (PluginException e) {
            throw e;
        } catch (Exception e) {
            throw new PluginException("Install failed", e);
        }
    }

    public PluginInfo installNativePlugin(File soFile) throws PluginException {
        try {
            if (!soFile.exists()) throw new PluginException("Native library not found");
            if (!soFile.getName().endsWith(PLUGIN_EXTENSION_SO))
                throw new PluginException("Not a .so file");
            String pluginId = soFile.getName().replace(PLUGIN_EXTENSION_SO, "");
            PluginInfo info = new PluginInfo();
            info.id = pluginId;
            info.name = pluginId;
            info.version = "1.0";
            info.versionCode = 1;
            info.type = "native";
            info.nativeLibs = new String[]{soFile.getAbsolutePath()};
            info.size = soFile.length();
            info.checksum = calculateChecksum(soFile);
            info.installedAt = System.currentTimeMillis();
            String targetName = pluginId + "_1" + PLUGIN_EXTENSION_SO;
            File targetFile = new File(pluginsDir, targetName);
            if (targetFile.exists()) targetFile.delete();
            copyFile(soFile, targetFile);
            info.filePath = targetFile.getAbsolutePath();
            plugins.put(info.id, info);
            PluginState state = new PluginState();
            state.pluginId = info.id;
            state.enabled = true;
            pluginStates.put(info.id, state);
            savePluginStates();
            return info;
        } catch (Exception e) {
            throw new PluginException("Native plugin install failed", e);
        }
    }

    public void uninstallPlugin(String pluginId) throws PluginException {
        PluginInfo info = plugins.get(pluginId);
        if (info == null) throw new PluginException("Plugin not found");
        unloadPlugin(pluginId);
        if (info.filePath != null) {
            File f = new File(info.filePath);
            if (f.exists()) f.delete();
        }
        File dataDir = new File(pluginsDataDir, pluginId);
        if (dataDir.exists()) deleteDirectory(dataDir);
        plugins.remove(pluginId);
        pluginStates.remove(pluginId);
        classLoaders.remove(pluginId);
        pluginInstances.remove(pluginId);
        bridges.remove(pluginId);
        savePluginStates();
        for (PluginEventListener l : eventListeners) {
            try { l.onPluginUninstalled(pluginId); } catch (Exception e) {}
        }
    }

    public void loadPlugin(String pluginId) throws PluginException {
        PluginInfo info = plugins.get(pluginId);
        if (info == null) throw new PluginException("Plugin not found");
        PluginState state = pluginStates.get(pluginId);
        if (state == null) {
            state = new PluginState();
            state.pluginId = pluginId;
            state.enabled = true;
            pluginStates.put(pluginId, state);
        }
        if (!state.enabled) throw new PluginException("Plugin is disabled");
        if (state.loaded) return;
        if (!verifyPluginSignature(info)) {
            throw new PluginException("Plugin signature verification failed");
        }
        try {
            if ("native".equals(info.type)) {
                loadNativePlugin(info);
            } else {
                loadDexPlugin(info);
            }
            state.loaded = true;
            state.lastLoaded = System.currentTimeMillis();
            state.loadCount++;
            state.lastError = null;
            activePluginCount.incrementAndGet();
            for (PluginEventListener l : eventListeners) {
                try { l.onPluginLoaded(info); } catch (Exception e) {}
            }
        } catch (Exception e) {
            state.lastError = e.getMessage();
            throw new PluginException("Failed to load plugin: " + e.getMessage(), e);
        }
    }

    public void unloadPlugin(String pluginId) {
        PluginInfo info = plugins.get(pluginId);
        if (info == null) return;
        PluginState state = pluginStates.get(pluginId);
        if (state == null || !state.loaded) return;
        try {
            Object instance = pluginInstances.get(pluginId);
            if (instance != null) {
                try {
                    Method onUnload = instance.getClass().getMethod("onUnload");
                    onUnload.invoke(instance);
                } catch (Exception e) {
                }
            }
            state.loaded = false;
            state.running = false;
            activePluginCount.decrementAndGet();
            pluginInstances.remove(pluginId);
            for (PluginEventListener l : eventListeners) {
                try { l.onPluginUnloaded(info); } catch (Exception e) {}
            }
        } catch (Exception e) {
        }
    }

    public void enablePlugin(String pluginId) {
        PluginState state = pluginStates.get(pluginId);
        if (state == null) {
            state = new PluginState();
            state.pluginId = pluginId;
            pluginStates.put(pluginId, state);
        }
        state.enabled = true;
        savePluginStates();
        PluginInfo info = plugins.get(pluginId);
        if (info != null) {
            for (PluginEventListener l : eventListeners) {
                try { l.onPluginEnabled(info); } catch (Exception e) {}
            }
        }
    }

    public void disablePlugin(String pluginId) {
        unloadPlugin(pluginId);
        PluginState state = pluginStates.get(pluginId);
        if (state != null) {
            state.enabled = false;
            savePluginStates();
        }
        PluginInfo info = plugins.get(pluginId);
        if (info != null) {
            for (PluginEventListener l : eventListeners) {
                try { l.onPluginDisabled(info); } catch (Exception e) {}
            }
        }
    }

    public void togglePlugin(String pluginId) {
        PluginState state = pluginStates.get(pluginId);
        if (state != null && state.enabled) {
            disablePlugin(pluginId);
        } else {
            enablePlugin(pluginId);
        }
    }

    public boolean loadAllPlugins() {
        if (isLoading.getAndSet(true)) return false;
        executor.submit(() -> {
            try {
                for (PluginInfo info : plugins.values()) {
                    PluginState state = pluginStates.get(info.id);
                    if (state != null && state.enabled && !state.loaded) {
                        try {
                            loadPlugin(info.id);
                        } catch (Exception e) {
                            if (state != null) state.lastError = e.getMessage();
                        }
                    }
                }
            } finally {
                isLoading.set(false);
            }
        });
        return true;
    }

    public void unloadAllPlugins() {
        for (String id : plugins.keySet()) {
            unloadPlugin(id);
        }
    }

    public void sendMessage(String targetPlugin, String sender, String type, byte[] data) {
        List<PluginBridge> bridgeList = bridges.get(targetPlugin);
        if (bridgeList == null) return;
        for (PluginBridge bridge : bridgeList) {
            try {
                Object instance = pluginInstances.get(targetPlugin);
                if (instance != null) {
                    Method onMessage = instance.getClass().getMethod(
                        "onMessage", String.class, String.class, byte[].class);
                    onMessage.invoke(instance, sender, type, data);
                }
            } catch (Exception e) {
            }
        }
    }

    public void broadcastMessage(String sender, String type, byte[] data) {
        for (String pluginId : plugins.keySet()) {
            if (!pluginId.equals(sender)) {
                sendMessage(pluginId, sender, type, data);
            }
        }
    }

    public void registerBridge(String pluginId, String interfaceName,
                               Object implementation) {
        PluginBridge bridge = new PluginBridge();
        bridge.pluginId = pluginId;
        bridge.interfaceName = interfaceName;
        bridge.implementation = implementation;
        bridge.methods = implementation.getClass().getMethods();
        bridges.computeIfAbsent(pluginId, k -> new ArrayList<>()).add(bridge);
    }

    public void unregisterBridge(String pluginId, String interfaceName) {
        List<PluginBridge> bridgeList = bridges.get(pluginId);
        if (bridgeList == null) return;
        bridgeList.removeIf(b -> b.interfaceName.equals(interfaceName));
        if (bridgeList.isEmpty()) bridges.remove(pluginId);
    }

    public <T> T getBridge(String pluginId, String interfaceName, Class<T> interfaceClass) {
        List<PluginBridge> bridgeList = bridges.get(pluginId);
        if (bridgeList == null) return null;
        for (PluginBridge bridge : bridgeList) {
            if (bridge.interfaceName.equals(interfaceName)) {
                return interfaceClass.cast(bridge.implementation);
            }
        }
        return null;
    }

    public List<PluginInfo> searchMarketplace(String query, PluginMarketplaceCallback callback) {
        executor.submit(() -> {
            try {
                String urlStr = MARKETPLACE_URL + "/search?q=" +
                    java.net.URLEncoder.encode(query, "UTF-8") +
                    "&device=" + getDeviceId();
                URL url = new URL(urlStr);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(15000);
                int code = conn.getResponseCode();
                if (code == 200) {
                    BufferedReader br = new BufferedReader(
                        new InputStreamReader(conn.getInputStream(), "UTF-8"));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) sb.append(line);
                    br.close();
                    List<PluginInfo> results = parsePluginList(sb.toString());
                    mainHandler.post(() -> {
                        if (callback != null) callback.onPluginsListed(results);
                    });
                } else {
                    mainHandler.post(() -> {
                        if (callback != null) callback.onError("Server error: " + code);
                    });
                }
                conn.disconnect();
            } catch (Exception e) {
                mainHandler.post(() -> {
                    if (callback != null) callback.onError(e.getMessage());
                });
            }
        });
        return new ArrayList<>();
    }

    public void downloadFromMarketplace(String pluginId, String downloadUrl,
                                        PluginMarketplaceCallback callback) {
        executor.submit(() -> {
            try {
                URL url = new URL(downloadUrl);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(30000);
                conn.setReadTimeout(60000);
                int code = conn.getResponseCode();
                if (code == 200) {
                    File tempFile = new File(pluginsDir, pluginId + "_download" +
                        PLUGIN_EXTENSION_APK);
                    FileOutputStream fos = new FileOutputStream(tempFile);
                    InputStream is = conn.getInputStream();
                    byte[] buffer = new byte[8192];
                    int read;
                    while ((read = is.read(buffer)) != -1) fos.write(buffer, 0, read);
                    fos.close();
                    is.close();
                    PluginInfo info = parsePluginManifest(tempFile);
                    final PluginInfo finalInfo = info;
                    mainHandler.post(() -> {
                        if (callback != null)
                            callback.onPluginDownloaded(finalInfo, tempFile);
                    });
                } else {
                    mainHandler.post(() -> {
                        if (callback != null) callback.onError("Download failed: " + code);
                    });
                }
                conn.disconnect();
            } catch (Exception e) {
                mainHandler.post(() -> {
                    if (callback != null) callback.onError(e.getMessage());
                });
            }
        });
    }

    private void loadDexPlugin(PluginInfo info) throws PluginException {
        try {
            File optDir = new File(context.getCacheDir(), "plugin_opt");
            optDir.mkdirs();
            File dexDir = new File(context.getCacheDir(), "plugin_dex");
            dexDir.mkdirs();
            DexClassLoader loader = new DexClassLoader(
                info.filePath,
                optDir.getAbsolutePath(),
                dexDir.getAbsolutePath(),
                context.getClassLoader());
            classLoaders.put(info.id, loader);
            Class<?> entryClass = loader.loadClass(info.entryClass);
            Constructor<?> constructor = entryClass.getConstructor();
            Object instance = constructor.newInstance();
            pluginInstances.put(info.id, instance);
            Method onLoad = entryClass.getMethod("onLoad", Context.class);
            onLoad.invoke(instance, context);
            PluginState state = pluginStates.get(info.id);
            if (state != null) state.running = true;
        } catch (ClassNotFoundException e) {
            throw new PluginException("Entry class not found: " + info.entryClass, e);
        } catch (NoSuchMethodException e) {
            throw new PluginException("Required methods not found", e);
        } catch (Exception e) {
            throw new PluginException("Failed to load dex plugin", e);
        }
    }

    private void loadNativePlugin(PluginInfo info) throws PluginException {
        try {
            if (info.nativeLibs != null) {
                for (String libPath : info.nativeLibs) {
                    File libFile = new File(libPath);
                    if (libFile.exists()) {
                        File targetLib = new File(context.getApplicationInfo().nativeLibraryDir,
                            libFile.getName());
                        if (!targetLib.exists()) {
                            copyFile(libFile, targetLib);
                        }
                        System.load(targetLib.getAbsolutePath());
                    }
                }
            }
            PluginState state = pluginStates.get(info.id);
            if (state != null) state.running = true;
        } catch (Exception e) {
            throw new PluginException("Failed to load native plugin", e);
        }
    }

    private PluginInfo parsePluginManifest(File apkFile) {
        try {
            ZipFile zip = new ZipFile(apkFile);
            ZipEntry manifest = zip.getEntry(PLUGIN_MANIFEST_FILE);
            if (manifest == null) {
                ZipEntry entry = zip.getEntry("assets/" + PLUGIN_MANIFEST_FILE);
                if (entry == null) {
                    zip.close();
                    return null;
                }
                manifest = entry;
            }
            InputStream is = zip.getInputStream(manifest);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            int read;
            while ((read = is.read(buffer)) != -1) baos.write(buffer, 0, read);
            is.close();
            zip.close();
            String json = new String(baos.toByteArray(), "UTF-8");
            return parsePluginJson(json);
        } catch (Exception e) {
            return null;
        }
    }

    private PluginInfo parsePluginJson(String json) {
        try {
            PluginInfo info = new PluginInfo();
            info.id = extractJsonString(json, "id");
            info.name = extractJsonString(json, "name");
            info.version = extractJsonString(json, "version");
            info.versionCode = extractJsonInt(json, "version_code");
            info.description = extractJsonString(json, "description");
            info.author = extractJsonString(json, "author");
            info.packageName = extractJsonString(json, "package");
            info.entryClass = extractJsonString(json, "entry_class");
            info.type = extractJsonString(json, "type");
            info.minSdk = extractJsonInt(json, "min_sdk");
            info.targetSdk = extractJsonInt(json, "target_sdk");
            info.icon = extractJsonString(json, "icon");
            info.metadata = new HashMap<>();
            String permissionsStr = extractJsonString(json, "permissions");
            if (permissionsStr != null && !permissionsStr.isEmpty()) {
                info.permissions = permissionsStr.split(",");
            }
            if (info.id == null || info.id.isEmpty()) return null;
            if (info.name == null) info.name = info.id;
            if (info.type == null) info.type = "dex";
            if (info.entryClass == null) info.entryClass = "com.plugin.Main";
            return info;
        } catch (Exception e) {
            return null;
        }
    }

    private String extractJsonString(String json, String key) {
        String search = "\"" + key + "\":\"";
        int start = json.indexOf(search);
        if (start < 0) return null;
        start += search.length();
        int end = json.indexOf('"', start);
        if (end < 0) return null;
        return json.substring(start, end);
    }

    private int extractJsonInt(String json, String key) {
        String search = "\"" + key + "\":";
        int start = json.indexOf(search);
        if (start < 0) return 0;
        start += search.length();
        int end = json.indexOf(',', start);
        if (end < 0) end = json.indexOf('}', start);
        if (end < 0) return 0;
        try {
            return Integer.parseInt(json.substring(start, end).trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private List<PluginInfo> parsePluginList(String json) {
        List<PluginInfo> list = new ArrayList<>();
        try {
            String[] items = json.split("\\},\\{");
            for (String item : items) {
                PluginInfo info = parsePluginJson(item.replaceAll("^\\[?\\{?", "")
                    .replaceAll("\\}?\\]?$", ""));
                if (info != null) list.add(info);
            }
        } catch (Exception e) {
        }
        return list;
    }

    private void loadPluginStates() {
        try {
            File stateFile = new File(pluginsDir, PLUGIN_STATE_FILE);
            if (!stateFile.exists()) return;
            BufferedReader br = new BufferedReader(new FileReader(stateFile));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            String json = sb.toString();
            String[] entries = json.split("\\},\\{");
            for (String entry : entries) {
                String clean = entry.replaceAll("^\\[?\\{?", "").replaceAll("\\}?\\]?$", "");
                PluginState state = new PluginState();
                state.pluginId = extractJsonString(clean, "plugin_id");
                state.enabled = "true".equals(extractJsonString(clean, "enabled"));
                state.loadCount = extractJsonInt(clean, "load_count");
                if (state.pluginId != null) {
                    pluginStates.put(state.pluginId, state);
                }
            }
        } catch (Exception e) {
        }
    }

    private void savePluginStates() {
        try {
            StringBuilder sb = new StringBuilder("[");
            boolean first = true;
            for (PluginState state : pluginStates.values()) {
                if (!first) sb.append(",");
                first = false;
                sb.append("{\"plugin_id\":\"").append(escapeJson(state.pluginId))
                    .append("\",\"enabled\":\"").append(state.enabled)
                    .append("\",\"load_count\":").append(state.loadCount)
                    .append("}");
            }
            sb.append("]");
            File stateFile = new File(pluginsDir, PLUGIN_STATE_FILE);
            FileWriter fw = new FileWriter(stateFile);
            fw.write(sb.toString());
            fw.close();
        } catch (Exception e) {
        }
    }

    private String calculateChecksum(File file) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            FileInputStream fis = new FileInputStream(file);
            byte[] buffer = new byte[8192];
            int read;
            while ((read = fis.read(buffer)) != -1) md.update(buffer, 0, read);
            fis.close();
            byte[] hash = md.digest();
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) hex.append(String.format("%02x", b & 0xFF));
            return hex.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private void copyFile(File source, File dest) throws IOException {
        FileInputStream fis = new FileInputStream(source);
        FileOutputStream fos = new FileOutputStream(dest);
        byte[] buffer = new byte[8192];
        int read;
        while ((read = fis.read(buffer)) != -1) fos.write(buffer, 0, read);
        fis.close();
        fos.close();
    }

    private void deleteDirectory(File dir) {
        File[] files = dir.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isDirectory()) deleteDirectory(f);
                else f.delete();
            }
        }
        dir.delete();
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r");
    }

    private boolean verifyPluginSignature(PluginInfo info) {
        if (info == null || info.checksum == null || info.checksum.isEmpty()) return false;
        if (TRUSTED_PLUGIN_HASHES.length == 0) return true;
        for (String trusted : TRUSTED_PLUGIN_HASHES) {
            if (trusted != null && trusted.equalsIgnoreCase(info.checksum)) return true;
        }
        return false;
    }

    private String getDeviceId() {
        return Utils.getMaskedAndroidId();
    }

    private void notifyPluginsChanged() {
    }

    public PluginInfo getPlugin(String id) {
        return plugins.get(id);
    }

    public List<PluginInfo> getAllPlugins() {
        return new ArrayList<>(plugins.values());
    }

    public List<PluginInfo> getEnabledPlugins() {
        List<PluginInfo> enabled = new ArrayList<>();
        for (PluginInfo info : plugins.values()) {
            PluginState state = pluginStates.get(info.id);
            if (state != null && state.enabled) enabled.add(info);
        }
        return enabled;
    }

    public List<PluginInfo> getLoadedPlugins() {
        List<PluginInfo> loaded = new ArrayList<>();
        for (PluginInfo info : plugins.values()) {
            PluginState state = pluginStates.get(info.id);
            if (state != null && state.loaded) loaded.add(info);
        }
        return loaded;
    }

    public PluginState getPluginState(String id) {
        return pluginStates.get(id);
    }

    public boolean isPluginEnabled(String id) {
        PluginState state = pluginStates.get(id);
        return state != null && state.enabled;
    }

    public boolean isPluginLoaded(String id) {
        PluginState state = pluginStates.get(id);
        return state != null && state.loaded;
    }

    public int getActivePluginCount() {
        return activePluginCount.get();
    }

    public int getTotalPluginCount() {
        return plugins.size();
    }

    public boolean isLoading() {
        return isLoading.get();
    }

    public void addEventListener(PluginEventListener listener) {
        eventListeners.add(listener);
    }

    public void removeEventListener(PluginEventListener listener) {
        eventListeners.remove(listener);
    }

    public void destroy() {
        unloadAllPlugins();
        executor.shutdownNow();
        eventListeners.clear();
        plugins.clear();
        pluginStates.clear();
        classLoaders.clear();
        pluginInstances.clear();
        bridges.clear();
        instance = null;
    }
}
