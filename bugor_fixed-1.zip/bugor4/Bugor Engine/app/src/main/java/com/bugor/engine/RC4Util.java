package com.bugor.engine;

import java.io.UnsupportedEncodingException;

public class RC4Util {
    public static String encryRC4String(String data, String key, String charset) {
        try {
            byte[] dataBytes = data.getBytes(charset);
            byte[] keyBytes = key.getBytes(charset);
            byte[] encrypted = rc4(dataBytes, keyBytes);
            return bytesToHex(encrypted);
        } catch (UnsupportedEncodingException e) { return null; }
    }

    public static String decryRC4(String data, String key, String charset) {
        try {
            byte[] dataBytes = hexToBytes(data);
            byte[] keyBytes = key.getBytes(charset);
            byte[] decrypted = rc4(dataBytes, keyBytes);
            return new String(decrypted, charset);
        } catch (Exception e) { return null; }
    }

    private static byte[] rc4(byte[] data, byte[] key) {
        int[] s = new int[256];
        byte[] result = new byte[data.length];
        for (int i = 0; i < 256; i++) s[i] = i;
        int j = 0;
        for (int i = 0; i < 256; i++) {
            j = (j + s[i] + (key[i % key.length] & 0xFF)) % 256;
            int temp = s[i];
            s[i] = s[j];
            s[j] = temp;
        }
        int i = 0;
        j = 0;
        for (int k = 0; k < data.length; k++) {
            i = (i + 1) % 256;
            j = (j + s[i]) % 256;
            int temp = s[i];
            s[i] = s[j];
            s[j] = temp;
            result[k] = (byte) (data[k] ^ s[(s[i] + s[j]) % 256]);
        }
        return result;
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) sb.append(String.format("%02x", b & 0xFF));
        return sb.toString();
    }

    private static byte[] hexToBytes(String hex) {
        int len = hex.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                + Character.digit(hex.charAt(i + 1), 16));
        }
        return data;
    }
}
