package com.bugor.engine;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;

public class Tools {
    public static void createFile(String path) {
        File f = new File(path);
        if (f.exists()) f.delete();
        try { f.createNewFile(); } catch (IOException e) {}
    }

    public static void createFolder(String path) {
        File f = new File(path);
        if (!f.exists()) f.mkdirs();
    }

    public static void writeFile(String path, String content) {
        try {
            FileWriter fw = new FileWriter(path);
            fw.write(content);
            fw.close();
        } catch (IOException e) {}
    }

    public static boolean deleteFile(String path) {
        return new File(path).delete();
    }

    public static String readFile(String path) {
        StringBuilder sb = new StringBuilder();
        try {
            BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(path), "UTF-8"));
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
        } catch (IOException e) {}
        return sb.toString();
    }

    public static void execShell(String cmd) {
        try { Runtime.getRuntime().exec(cmd); } catch (IOException e) {}
    }

    public static void execShellAsync(final String cmd) {
        new Thread(() -> {
            try {
                Process p = Runtime.getRuntime().exec("sh");
                DataOutputStream dos = new DataOutputStream(p.getOutputStream());
                dos.write(cmd.getBytes());
                dos.writeBytes("\n");
                dos.flush();
                dos.close();
            } catch (IOException e) {}
        }).start();
    }

    public static boolean exportAsset(Context ctx, String outPath, String fileName) {
        File file = new File(outPath);
        if (!file.exists() && !file.mkdirs()) return false;
        try {
            InputStream is = ctx.getAssets().open(fileName);
            FileOutputStream fos = new FileOutputStream(new File(file, fileName));
            byte[] buf = new byte[1024];
            int len;
            while ((len = is.read(buf)) > 0) fos.write(buf, 0, len);
            is.close();
            fos.close();
            return true;
        } catch (IOException e) { return false; }
    }

    public static boolean openApp(Context ctx, String pkg) {
        try {
            Intent i = ctx.getPackageManager().getLaunchIntentForPackage(pkg);
            ctx.startActivity(i);
            return true;
        } catch (Exception e) { return false; }
    }

    public static String urlPost(String urlStr, String data) {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(9000);
            conn.setRequestMethod("POST");
            OutputStream os = conn.getOutputStream();
            os.write(data.getBytes());
            BufferedReader br = new BufferedReader(
                new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            return sb.toString();
        } catch (IOException e) { return ""; }
    }

    public static String md5(String str) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(str.getBytes("UTF-8"));
            byte[] digest = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : digest) sb.append(String.format("%02X", b));
            return sb.toString().toLowerCase();
        } catch (Exception e) { return ""; }
    }
}
