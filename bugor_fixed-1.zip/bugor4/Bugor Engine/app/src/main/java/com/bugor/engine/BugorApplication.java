package com.bugor.engine;

import android.app.Application;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import com.bugor.engine.IPCCond.AIDLConnection;
import com.bugor.engine.IPCCond.SuperMain;
import com.topjohnwu.superuser.ipc.RootService;

public class BugorApplication extends Application {
    private static final String TAG = "BugorApplication";
    private static final String CHANNEL_ID = "bugor_service_channel";
    private static BugorApplication instance;

    private AIDLConnection aidlConnection;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;

        Log.i(TAG, "Bugor Application starting...");

        createNotificationChannel();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(new Intent(this, BugorService.class));
        }

        bindRootService();
    }

    private void bindRootService() {
        try {
            aidlConnection = new AIDLConnection(false);
            Intent intent = new Intent(this, SuperMain.class);
            RootService.bind(intent, aidlConnection);
            Log.i(TAG, "RootService bind requested");
        } catch (Throwable t) {
            Log.w(TAG, "RootService bind failed (no root?): " + t.getMessage());
        }
    }

    @Override
    public void onTerminate() {
        try {
            if (aidlConnection != null) {
                RootService.unbind(aidlConnection);
            }
        } catch (Throwable ignored) {}
        super.onTerminate();
    }

    public static BugorApplication getInstance() {
        return instance;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Bugor Engine Service",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Bugor Engine background service");
            channel.setShowBadge(false);
            channel.setLockscreenVisibility(Notification.VISIBILITY_SECRET);

            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    public String getChannelId() {
        return CHANNEL_ID;
    }
}
