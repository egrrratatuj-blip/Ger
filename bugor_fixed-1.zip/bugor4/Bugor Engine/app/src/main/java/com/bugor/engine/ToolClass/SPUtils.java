package com.bugor.engine.ToolClass;

import android.content.Context;
import android.content.SharedPreferences;

public class SPUtils {
    private static final String NAME = "bugor_engine_prefs";

    public static void setParam(Context ctx, String key, Object val) {
        SharedPreferences sp = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor e = sp.edit();
        if (val instanceof Boolean) e.putBoolean(key, (Boolean) val);
        else if (val instanceof String) e.putString(key, (String) val);
        else if (val instanceof Integer) e.putInt(key, (Integer) val);
        else if (val instanceof Float) e.putFloat(key, (Float) val);
        e.apply();
    }

    public static Object getParam(Context ctx, String key, Object def) {
        SharedPreferences sp = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE);
        if (def instanceof Boolean) return sp.getBoolean(key, (Boolean) def);
        if (def instanceof String) return sp.getString(key, (String) def);
        if (def instanceof Integer) return sp.getInt(key, (Integer) def);
        if (def instanceof Float) return sp.getFloat(key, (Float) def);
        return def;
    }
}
