package com.bugor.engine.ToolClass;

import java.io.DataOutputStream;
import java.io.IOException;

public class FloatTool {
    public static void RunShell(String cmd, boolean root) {
        try {
            Process p = root ? Runtime.getRuntime().exec("su") : Runtime.getRuntime().exec("sh");
            DataOutputStream dos = new DataOutputStream(p.getOutputStream());
            dos.write(cmd.getBytes());
            dos.writeBytes("\n");
            dos.writeBytes("exit\n");
            dos.flush();
            dos.close();
        } catch (IOException e) {}
    }
}
