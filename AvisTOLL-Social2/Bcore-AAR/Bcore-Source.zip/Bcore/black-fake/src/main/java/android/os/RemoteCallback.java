package android.os;

/** SDK-28 compilation shape; Android supplies the runtime class. */
public class RemoteCallback {}
