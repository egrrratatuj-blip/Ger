package android.content;

/** SDK-28 compilation shape; Android supplies the runtime class. */
public class AttributionSource {}
