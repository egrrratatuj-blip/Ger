package top.niunaijun.blackbox.utils;

import java.io.*;
import java.nio.channels.FileLock;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** Publishes immutable native library copies, reusable across host processes. */
public final class RuntimeNativeLibrary {
    private RuntimeNativeLibrary() {}
    private static String digest(File file) throws IOException {
        try {
            MessageDigest hash = MessageDigest.getInstance("SHA-256");
            try (InputStream input = new FileInputStream(file)) {
                byte[] buffer = new byte[65536]; int count;
                while ((count = input.read(buffer)) != -1) hash.update(buffer, 0, count);
            }
            StringBuilder result = new StringBuilder();
            for (byte value : hash.digest()) result.append(String.format(java.util.Locale.US, "%02x", value & 255));
            return result.toString();
        } catch (NoSuchAlgorithmException impossible) { throw new IOException(impossible); }
    }
    public static synchronized File publish(File source, File root) throws IOException {
        String hash = digest(source);
        if (!root.isDirectory() && !root.mkdirs()) throw new IOException("Cannot create runtime directory");
        try (RandomAccessFile lockFile = new RandomAccessFile(new File(root, "bridge.lock"), "rw");
             FileLock lock = lockFile.getChannel().lock()) {
            File directory = new File(root, "bridge-" + hash);
            if (!directory.isDirectory() && !directory.mkdirs()) throw new IOException("Cannot create version directory");
            File target = new File(directory, "libkxv72q4n.so");
            if (target.isFile() && hash.equals(digest(target))) {
                if (!target.setReadable(true, true) || !target.setExecutable(true, true)
                        || !target.setWritable(false, false)) throw new IOException("Cannot protect runtime copy");
                return target;
            }
            File pending = File.createTempFile("bridge-", ".pending", directory);
            try {
                try (InputStream input = new FileInputStream(source); FileOutputStream output = new FileOutputStream(pending)) {
                    byte[] buffer = new byte[65536]; int count;
                    while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
                    output.getFD().sync();
                }
                if (!hash.equals(digest(pending))) throw new IOException("Runtime copy hash mismatch");
                if (!pending.setReadable(true, true) || !pending.setExecutable(true, true)
                        || !pending.setWritable(false, false)) throw new IOException("Cannot protect runtime copy");
                // Rename replaces the directory entry, never bytes of an already mapped inode.
                if (!pending.renameTo(target)) throw new IOException("Cannot publish runtime copy");
                return target;
            } finally { if (pending.exists()) pending.delete(); }
        }
    }
}
