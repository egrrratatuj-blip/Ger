package top.niunaijun.blackbox.utils;

import android.content.pm.ApplicationInfo;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.system.Os;
import android.system.OsConstants;
import android.system.StructStat;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import top.niunaijun.blackbox.core.NativeCore;

/**
 * Version-specific storage compatibility for the supplied ARM64 loader dump.
 * Only a completed source-path cache can change. Native code, package identity,
 * once flags, kernel stat results and exit decisions remain original.
 */
public final class GuestStorageAlias {
    private static final String TAG = "AvisStorageAlias";
    private static final String PACKAGE = "com.catsbit.oxidesurvivalisland";
    private static final String SPLIT = "split_config.arm64_v8a.apk";
    private static final long CACHE = 0xf5a0b0L;
    private static final long ONCE = 0xf5a074L;
    private static final long PACKAGE_CACHE = 0xf5a263L;
    private static final long ADDRESS_MASK = 0x00ffffffffffffffL;
    private static boolean started;
    // Both resources stay alive after publication: native consumers retain char*.
    private static ParcelFileDescriptor retainedDirectory;
    private static long retainedBuffer;

    private GuestStorageAlias() {}

    public static synchronized void start(String packageName, String dataDir,
                                           ApplicationInfo host, int hostUser) {
        if (started || !PACKAGE.equals(packageName)) return;
        started = true;
        final String root = new File(host.dataDir, "data").getAbsolutePath();
        if (!new File(root, "user/" + hostUser + "/" + PACKAGE).getAbsolutePath().equals(dataDir)) {
            Log.w(TAG, "skipped: data directory layout differs");
            return;
        }
        // Capture the host identity before the guest finishes binding. Os.getuid
        // and Os.stat are virtualized by OsStub and cannot measure kernel ownership.
        final int hostUid = host.uid;
        Thread worker = new Thread(() -> run(root, dataDir, hostUser, hostUid), "AvisStorageAlias");
        worker.setDaemon(true);
        worker.start();
    }

    private static void run(String root, String dataDir, int hostUser, int uid) {
        ParcelFileDescriptor directory = null;
        RawMemory memory = null;
        long buffer = 0;
        boolean exposed = false;
        final long began = SystemClock.elapsedRealtime();
        try {
            if (uid / 100000 != hostUser) throw new IOException("kernel user mismatch");
            FileDescriptor opened = Os.open(root,
                    OsConstants.O_RDONLY | OsConstants.O_CLOEXEC, 0);
            try {
                StructStat openedStat = Os.fstat(opened);
                if ((openedStat.st_mode & OsConstants.S_IFMT) != OsConstants.S_IFDIR
                        || openedStat.st_uid != uid) throw new IOException("invalid storage root expectedUid="
                        + uid + " observed=" + describe(openedStat));
                directory = ParcelFileDescriptor.dup(opened);
            }
            finally { Os.close(opened); }
            String prefix = prefix(directory.getFd());
            String expected = root + "/app/" + PACKAGE + "/" + SPLIT;
            String alias = prefix + "app/" + PACKAGE + "/" + SPLIT;
            String ownerPath = prefix + "user/" + hostUser + "/" + PACKAGE;
            sameObject(expected, alias, false, uid);
            sameObject(dataDir, ownerPath, true, uid);
            memory = new RawMemory();
            memory.selfTest();
            Log.i(TAG, "preflight=ok fd=" + directory.getFd() + " prefixBytes=" + prefix.length()
                    + " sameApk=1 sameDirectory=1 kernelUid=" + uid);
            byte[] aliasBytes = (alias + '\0').getBytes(StandardCharsets.UTF_8);
            buffer = memory.allocate(aliasBytes);
            long deadline = began + 20000;
            List<Mapping> maps;
            long base = 0;
            try (RandomAccessFile mem = new RandomAccessFile("/proc/self/mem", "r")) {
                while (SystemClock.elapsedRealtime() < deadline) {
                    maps = mappings();
                    long candidate = loaderBase(maps);
                    if (candidate != 0) {
                        try {
                            validateLoader(mem, maps, candidate);
                            base = candidate;
                            break;
                        } catch (IOException unpackingOrDifferentVersion) {
                            // The mapping can precede .init/unpacking. Never write
                            // until every version signature and region matches.
                        }
                    }
                    Thread.sleep(20);
                }
                if (base == 0) throw new IOException("loader fingerprint/mapping timeout");
                Log.i(TAG, "loader=matched elapsedMs=" + (SystemClock.elapsedRealtime() - began));
                long old = 0;
                while (SystemClock.elapsedRealtime() < deadline) {
                    int once = readInt(mem, base + ONCE);
                    if (once == 2) {
                        old = readLong(mem, base + CACHE); break;
                    }
                    if (once != 0 && once != 1) throw new IOException("unexpected once state " + once);
                    Thread.sleep(1);
                }
                if (old == 0) throw new IOException("source cache not completed with a value");
                String source = readString(mem, old, 1024);
                if (!expected.equals(source)) throw new IOException("unexpected completed source: " + source);
                if (readInt(mem, base + 0xf5a068L) == 2
                        && !PACKAGE.equals(readString(mem, base + PACKAGE_CACHE, 129))) {
                    throw new IOException("guest package cache mismatch or not initialized");
                }
                // Revalidate permissions and exact source before the single aligned
                // store. The original once initializer has completed and never writes
                // this slot again. Its old allocation is deliberately not freed.
                maps = mappings();
                validateLoader(mem, maps, base);
                if (readInt(mem, base + ONCE) != 2 || readLong(mem, base + CACHE) != old) {
                    throw new IOException("source cache changed during validation");
                }
                sameObject(expected, alias, false, uid);
                sameObject(dataDir, ownerPath, true, uid);
                memory.fence();
                retainedDirectory = directory;
                retainedBuffer = buffer;
                // Set this before invoking native putLong: even an invocation error
                // must not free a pointer that could have become visible.
                exposed = true;
                memory.putLong(base + CACHE, buffer);
                memory.fence();
                if (readLong(mem, base + CACHE) != buffer
                        || !alias.equals(readString(mem, buffer, 1024))
                        || (readInt(mem, base + 0xf5a068L) == 2
                        && !PACKAGE.equals(readString(mem, base + PACKAGE_CACHE, 129)))) {
                    throw new IOException("post-publication verification failed");
                }
                Log.i(TAG, "published=1 elapsedMs=" + (SystemClock.elapsedRealtime() - began)
                        + " source=" + alias + " originalAllocationRetained=1 textModified=0");
            }
            // Existing baseline JNI performs actual raw newfstatat/geteuid and
            // records the native event queue. This is evidence, not a fake result.
            NativeCore.logGuestFilesystemState(dataDir);
        } catch (Throwable failure) {
            Log.w(TAG, "stopped published=" + (exposed ? 1 : 0) + " elapsedMs="
                    + (SystemClock.elapsedRealtime() - began), failure);
        } finally {
            if (!exposed) {
                if (memory != null && buffer != 0) {
                    try { memory.free(buffer); } catch (Throwable ignored) { }
                }
                if (directory != null) {
                    try { directory.close(); } catch (IOException ignored) { }
                }
            }
        }
    }

    static String prefix(int fd) throws IOException {
        if (fd < 0) throw new IOException("negative fd");
        StringBuilder result = new StringBuilder("/mnt/expand/../../proc/self/fd/").append(fd).append('/');
        if (result.length() > 49) throw new IOException("fd alias too long");
        while (result.length() < 49) result.append('/');
        return result.toString();
    }

    private static void sameObject(String physical, String alias, boolean directory, int uid)
            throws Exception {
        // OsStub changes stat.st_uid. Its fstat result passes through unchanged.
        // Keep the owner/inode/type checks; measure the actual opened objects.
        StructStat a = openedStat(physical);
        StructStat b = openedStat(alias);
        int type = directory ? OsConstants.S_IFDIR : OsConstants.S_IFREG;
        String details = "object=" + (directory ? "directory" : "apk") + " expectedUid=" + uid
                + " physical={" + describe(a) + "} alias={" + describe(b) + "}";
        Log.i(TAG, "preflight.objects " + details);
        if (a.st_dev != b.st_dev || a.st_ino != b.st_ino || a.st_uid != uid || b.st_uid != uid
                || (a.st_mode & OsConstants.S_IFMT) != type || (b.st_mode & OsConstants.S_IFMT) != type) {
            throw new IOException("alias inode/type/owner mismatch " + details);
        }
    }

    private static StructStat openedStat(String path) throws Exception {
        FileDescriptor fd = Os.open(path, OsConstants.O_RDONLY | OsConstants.O_CLOEXEC, 0);
        try { return Os.fstat(fd); }
        finally { Os.close(fd); }
    }

    private static String describe(StructStat value) {
        return "dev=" + value.st_dev + " ino=" + value.st_ino + " uid=" + value.st_uid
                + " mode=" + Integer.toOctalString(value.st_mode);
    }

    static final class Mapping {
        final long start, end, offset;
        final String permissions, name;
        Mapping(String line) throws IOException {
            String[] parts = line.trim().split("\\s+", 6);
            if (parts.length < 5) throw new IOException("bad maps record");
            String[] range = parts[0].split("-", 2);
            if (range.length != 2) throw new IOException("bad maps range");
            try {
                start = Long.parseLong(range[0], 16);
                end = Long.parseLong(range[1], 16);
                offset = Long.parseLong(parts[2], 16);
            } catch (NumberFormatException invalid) { throw new IOException("bad maps address", invalid); }
            permissions = parts[1];
            name = parts.length == 6 ? parts[5] : "";
            if (start <= 0 || end <= start || permissions.length() != 4) throw new IOException("bad maps bounds");
        }
    }

    private static List<Mapping> mappings() throws IOException {
        List<Mapping> result = new ArrayList<>();
        try (BufferedReader in = new BufferedReader(new FileReader("/proc/self/maps"))) {
            String line;
            while ((line = in.readLine()) != null) result.add(new Mapping(line));
        }
        return result;
    }

    static long loaderBase(List<Mapping> maps) throws IOException {
        long result = 0;
        for (Mapping m : maps) {
            if (m.offset == 0 && m.name.endsWith("/libloader.so") && m.permissions.charAt(0) == 'r') {
                if (result != 0 && result != m.start) throw new IOException("multiple loader bases");
                result = m.start;
            }
        }
        return result;
    }

    static void requireRegion(List<Mapping> maps, long address, int size, boolean write) throws IOException {
        if (address <= 0 || size <= 0 || address > Long.MAX_VALUE - size) throw new IOException("bad region");
        for (Mapping m : maps) {
            if (m.start <= address && address + size <= m.end && m.permissions.charAt(0) == 'r'
                    && (!write || (m.permissions.charAt(1) == 'w' && m.permissions.charAt(2) != 'x'))) return;
        }
        throw new IOException("cache/signature mapping unavailable");
    }

    static void validateLoader(RandomAccessFile mem, List<Mapping> maps, long base) throws IOException {
        // Covers source getter, both original detectors, original suffix copy,
        // initializer slot store and raw syscall wrapper. No .text bytes are written.
        long[] offsets = {0x4de2d0, 0x73cfe8, 0x73d254, 0x4d7c20, 0x4de5dc, 0x78e9cc};
        String[] bytes = {
            "fd7bbea9f30b00f9fd030091f353009073d201910100009021200c91e00313aa1f2003d584680a9460c243f8f30b40f9fd7bc2a8c0035fd6",
            "fd7bbca9fc5f01a9f65702a9f44f03a9fd030091ff0b40d1",
            "fd7bbaa9fc6f01a9fa6702a9f85f03a9f65704a9f44f05a9",
            "025400f0428c0991e60314aac0021fd6ea0306aa56004039f10307aa5615003836040034",
            "e8530090090f0051135900f9",
            "e80980d2010000d41f0440b1009480daa8eeff54c0035fd6"
        };
        for (int i = 0; i < offsets.length; i++) {
            byte[] expected = hex(bytes[i]);
            requireRegion(maps, base + offsets[i], expected.length, false);
            byte[] actual = read(mem, base + offsets[i], expected.length);
            if (!java.util.Arrays.equals(expected, actual)) throw new IOException("loader fingerprint mismatch at " + Long.toHexString(offsets[i]));
        }
        requireRegion(maps, base + CACHE, 8, true);
        requireRegion(maps, base + ONCE, 4, false);
        requireRegion(maps, base + 0xf5a068L, 4, false);
        requireRegion(maps, base + PACKAGE_CACHE, 129, false);
        if (((base + CACHE) & 7) != 0) throw new IOException("unaligned source pointer slot");
    }

    private static byte[] hex(String value) {
        byte[] bytes = new byte[value.length() / 2];
        for (int i = 0; i < bytes.length; i++) bytes[i] = (byte) Integer.parseInt(value.substring(i * 2, i * 2 + 2), 16);
        return bytes;
    }
    private static byte[] read(RandomAccessFile mem, long address, int count) throws IOException {
        long canonical = address & ADDRESS_MASK;
        if (canonical <= 0 || canonical > Long.MAX_VALUE - count) throw new IOException("invalid memory address");
        mem.seek(canonical);
        byte[] result = new byte[count];
        mem.readFully(result);
        return result;
    }
    private static int readInt(RandomAccessFile mem, long address) throws IOException {
        return ByteBuffer.wrap(read(mem, address, 4)).order(ByteOrder.LITTLE_ENDIAN).getInt();
    }
    private static long readLong(RandomAccessFile mem, long address) throws IOException {
        return ByteBuffer.wrap(read(mem, address, 8)).order(ByteOrder.LITTLE_ENDIAN).getLong();
    }
    private static String readString(RandomAccessFile mem, long address, int capacity) throws IOException {
        StringBuilder result = new StringBuilder();
        // Read one byte so an allocation or page boundary cannot invalidate a
        // successful short string. This transport cannot dereference bad pointers.
        for (int i = 0; i < capacity; i++) {
            int c = read(mem, address + i, 1)[0] & 255;
            if (c == 0) return result.toString();
            if (c < 32 || c > 126) throw new IOException("non-ASCII source cache");
            result.append((char) c);
        }
        throw new IOException("unterminated source cache");
    }

    static final class RawMemory {
        final Object unsafe;
        final Method allocate, free, putByte, putLong, getLong, fence;
        RawMemory() throws Exception {
            Class<?> cls = Class.forName("sun.misc.Unsafe");
            Field singleton = cls.getDeclaredField("theUnsafe");
            singleton.setAccessible(true);
            unsafe = singleton.get(null);
            if (!Integer.valueOf(8).equals(cls.getMethod("addressSize").invoke(unsafe))) throw new IOException("requires 64-bit native pointers");
            allocate = cls.getMethod("allocateMemory", long.class);
            free = cls.getMethod("freeMemory", long.class);
            putByte = cls.getMethod("putByte", long.class, byte.class);
            // These exact raw-address overloads matter. Android's object-offset
            // CAS methods are NOT used with a null object or an absolute address.
            putLong = cls.getMethod("putLong", long.class, long.class);
            getLong = cls.getMethod("getLong", long.class);
            fence = cls.getMethod("storeFence");
        }
        void selfTest() throws Exception {
            long pointer = (Long) allocate.invoke(unsafe, 8L);
            if (pointer == 0) throw new IOException("native allocation failed");
            try {
                if ((pointer & 7) != 0) throw new IOException("native allocation unaligned");
                long value = 0x1234567887654321L;
                putLong(pointer, value);
                fence();
                if (!Long.valueOf(value).equals(getLong.invoke(unsafe, pointer))) throw new IOException("native pointer self-test failed");
            } finally { free(pointer); }
        }
        long allocate(byte[] bytes) throws Exception {
            long pointer = (Long) allocate.invoke(unsafe, (long) bytes.length);
            if (pointer == 0) throw new IOException("native allocation failed");
            try {
                for (int i = 0; i < bytes.length; i++) putByte.invoke(unsafe, pointer + i, bytes[i]);
                fence();
                return pointer;
            } catch (Throwable failure) {
                free(pointer);
                throw failure;
            }
        }
        void putLong(long address, long value) throws Exception { putLong.invoke(unsafe, address, value); }
        void fence() throws Exception { fence.invoke(unsafe); }
        void free(long pointer) throws Exception { free.invoke(unsafe, pointer); }
    }
}
