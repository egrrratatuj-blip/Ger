package top.niunaijun.blackbox.fake.service.context.providers;

import android.content.AttributionSource;
import android.content.ContentProviderOperation;
import android.content.ContentProviderResult;
import android.content.ContentValues;
import android.content.IContentProvider;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.ICancellationSignal;
import android.os.IInterface;
import android.os.ParcelFileDescriptor;
import android.os.RemoteCallback;
import android.os.RemoteException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

/** Ordinary methods give native callers valid dex method signatures on Android 16.
 * All operations still pass through the original provider identity delegate.
 * Do not extend this API gate without checking that release's hidden contract.
 */
public final class JniContentProviderAdapter implements IContentProvider {
    private final IInterface delegate;
    private static final ConcurrentHashMap<String, Method> METHODS = new ConcurrentHashMap<>();
    private static final java.util.concurrent.atomic.AtomicInteger LOGS = new java.util.concurrent.atomic.AtomicInteger();

    private JniContentProviderAdapter(IInterface delegate) { this.delegate = delegate; }

    static IInterface wrap(IInterface delegate) {
        if (delegate == null || Build.VERSION.SDK_INT != 36
                || delegate instanceof JniContentProviderAdapter) return delegate;
        if (LOGS.getAndIncrement() < 16) android.util.Log.i("AvisProvider",
                "jni facade=typed api=36 delegate=" + delegate.getClass().getName());
        return new JniContentProviderAdapter(delegate);
    }

    @Override public IBinder asBinder() { return delegate.asBinder(); }

    private Object forward(String name, Class<?>[] types, Object... args) {
        String key = name + java.util.Arrays.toString(types);
        try {
            Method method = METHODS.get(key);
            if (method == null) {
                method = IContentProvider.class.getMethod(name, types);
                method.setAccessible(true);
                METHODS.putIfAbsent(key, method);
            }
            return method.invoke(delegate, args);
        } catch (InvocationTargetException target) {
            return JniContentProviderAdapter.<RuntimeException, Object>raise(target.getCause());
        } catch (ReflectiveOperationException failure) {
            throw new IllegalStateException("Provider contract mismatch: " + key, failure);
        }
    }

    @SuppressWarnings("unchecked")
    private static <E extends Throwable, T> T raise(Throwable failure) throws E { throw (E) failure; }

    public Cursor query(AttributionSource source, Uri uri, String[] projection, Bundle queryArgs, ICancellationSignal signal) throws RemoteException {
        return (Cursor) forward("query", new Class<?>[]{AttributionSource.class, Uri.class, String[].class, Bundle.class, ICancellationSignal.class}, source, uri, projection, queryArgs, signal);
    }

    public String getType(AttributionSource source, Uri uri) throws RemoteException {
        return (String) forward("getType", new Class<?>[]{AttributionSource.class, Uri.class}, source, uri);
    }

    public void getTypeAsync(AttributionSource source, Uri uri, RemoteCallback callback) throws RemoteException {
        forward("getTypeAsync", new Class<?>[]{AttributionSource.class, Uri.class, RemoteCallback.class}, source, uri, callback);
    }

    public void getTypeAnonymousAsync(Uri uri, RemoteCallback callback) throws RemoteException {
        forward("getTypeAnonymousAsync", new Class<?>[]{Uri.class, RemoteCallback.class}, uri, callback);
    }

    public Uri insert(AttributionSource source, Uri uri, ContentValues values, Bundle extras) throws RemoteException {
        return (Uri) forward("insert", new Class<?>[]{AttributionSource.class, Uri.class, ContentValues.class, Bundle.class}, source, uri, values, extras);
    }

    public int bulkInsert(AttributionSource source, Uri uri, ContentValues[] values) throws RemoteException {
        return (Integer) forward("bulkInsert", new Class<?>[]{AttributionSource.class, Uri.class, ContentValues[].class}, source, uri, values);
    }

    public int delete(AttributionSource source, Uri uri, Bundle extras) throws RemoteException {
        return (Integer) forward("delete", new Class<?>[]{AttributionSource.class, Uri.class, Bundle.class}, source, uri, extras);
    }

    public int update(AttributionSource source, Uri uri, ContentValues values, Bundle extras) throws RemoteException {
        return (Integer) forward("update", new Class<?>[]{AttributionSource.class, Uri.class, ContentValues.class, Bundle.class}, source, uri, values, extras);
    }

    public ParcelFileDescriptor openFile(AttributionSource source, Uri uri, String mode, ICancellationSignal signal) throws RemoteException, java.io.FileNotFoundException {
        return (ParcelFileDescriptor) forward("openFile", new Class<?>[]{AttributionSource.class, Uri.class, String.class, ICancellationSignal.class}, source, uri, mode, signal);
    }

    public AssetFileDescriptor openAssetFile(AttributionSource source, Uri uri, String mode, ICancellationSignal signal) throws RemoteException, java.io.FileNotFoundException {
        return (AssetFileDescriptor) forward("openAssetFile", new Class<?>[]{AttributionSource.class, Uri.class, String.class, ICancellationSignal.class}, source, uri, mode, signal);
    }

    public ContentProviderResult[] applyBatch(AttributionSource source, String authority, ArrayList<ContentProviderOperation> operations) throws RemoteException, android.content.OperationApplicationException {
        return (ContentProviderResult[]) forward("applyBatch", new Class<?>[]{AttributionSource.class, String.class, ArrayList.class}, source, authority, operations);
    }

    public Bundle call(AttributionSource source, String authority, String method, String arg, Bundle extras) throws RemoteException {
        return (Bundle) forward("call", new Class<?>[]{AttributionSource.class, String.class, String.class, String.class, Bundle.class}, source, authority, method, arg, extras);
    }

    public int checkUriPermission(AttributionSource source, Uri uri, int uid, int modeFlags) throws RemoteException {
        return (Integer) forward("checkUriPermission", new Class<?>[]{AttributionSource.class, Uri.class, int.class, int.class}, source, uri, uid, modeFlags);
    }

    public ICancellationSignal createCancellationSignal() throws RemoteException {
        return (ICancellationSignal) forward("createCancellationSignal", new Class<?>[]{});
    }

    public Uri canonicalize(AttributionSource source, Uri uri) throws RemoteException {
        return (Uri) forward("canonicalize", new Class<?>[]{AttributionSource.class, Uri.class}, source, uri);
    }

    public void canonicalizeAsync(AttributionSource source, Uri uri, RemoteCallback callback) throws RemoteException {
        forward("canonicalizeAsync", new Class<?>[]{AttributionSource.class, Uri.class, RemoteCallback.class}, source, uri, callback);
    }

    public Uri uncanonicalize(AttributionSource source, Uri uri) throws RemoteException {
        return (Uri) forward("uncanonicalize", new Class<?>[]{AttributionSource.class, Uri.class}, source, uri);
    }

    public void uncanonicalizeAsync(AttributionSource source, Uri uri, RemoteCallback callback) throws RemoteException {
        forward("uncanonicalizeAsync", new Class<?>[]{AttributionSource.class, Uri.class, RemoteCallback.class}, source, uri, callback);
    }

    public boolean refresh(AttributionSource source, Uri uri, Bundle extras, ICancellationSignal signal) throws RemoteException {
        return (Boolean) forward("refresh", new Class<?>[]{AttributionSource.class, Uri.class, Bundle.class, ICancellationSignal.class}, source, uri, extras, signal);
    }

    public String[] getStreamTypes(AttributionSource source, Uri uri, String mimeType) throws RemoteException {
        return (String[]) forward("getStreamTypes", new Class<?>[]{AttributionSource.class, Uri.class, String.class}, source, uri, mimeType);
    }

    public AssetFileDescriptor openTypedAssetFile(AttributionSource source, Uri uri, String mimeType, Bundle opts, ICancellationSignal signal) throws RemoteException, java.io.FileNotFoundException {
        return (AssetFileDescriptor) forward("openTypedAssetFile", new Class<?>[]{AttributionSource.class, Uri.class, String.class, Bundle.class, ICancellationSignal.class}, source, uri, mimeType, opts, signal);
    }

    public String getType(Uri uri) throws RemoteException {
        return (String) forward("getType", new Class<?>[]{Uri.class}, uri);
    }

    public void getTypeAsync(Uri uri, RemoteCallback callback) throws RemoteException {
        forward("getTypeAsync", new Class<?>[]{Uri.class, RemoteCallback.class}, uri, callback);
    }

    public Uri insert(String callingPkg, Uri uri, ContentValues values) throws RemoteException {
        return (Uri) forward("insert", new Class<?>[]{String.class, Uri.class, ContentValues.class}, callingPkg, uri, values);
    }

    public int bulkInsert(String callingPkg, Uri uri, ContentValues[] values) throws RemoteException {
        return (Integer) forward("bulkInsert", new Class<?>[]{String.class, Uri.class, ContentValues[].class}, callingPkg, uri, values);
    }

    public int delete(String callingPkg, Uri uri, String selection, String[] selectionArgs) throws RemoteException {
        return (Integer) forward("delete", new Class<?>[]{String.class, Uri.class, String.class, String[].class}, callingPkg, uri, selection, selectionArgs);
    }

    public int update(String callingPkg, Uri uri, ContentValues values, String selection, String[] selectionArgs) throws RemoteException {
        return (Integer) forward("update", new Class<?>[]{String.class, Uri.class, ContentValues.class, String.class, String[].class}, callingPkg, uri, values, selection, selectionArgs);
    }

    public Bundle call(String callingPkg, String method, String arg, Bundle extras) throws RemoteException {
        return (Bundle) forward("call", new Class<?>[]{String.class, String.class, String.class, Bundle.class}, callingPkg, method, arg, extras);
    }

    public String[] getStreamTypes(Uri uri, String mimeType) throws RemoteException {
        return (String[]) forward("getStreamTypes", new Class<?>[]{Uri.class, String.class}, uri, mimeType);
    }

}
