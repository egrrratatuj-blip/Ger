package top.niunaijun.blackbox.fake.delegate;

import android.content.Intent;
import android.os.Bundle;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/** Android 16's local InnerReceiver overload; never retries after invocation. */
public final class ReceiverDeliveryCompat {
    private ReceiverDeliveryCompat() {}

    public static boolean dispatch(Object receiver, Intent intent, int resultCode, String data,
            Bundle extras, boolean ordered, boolean sticky, int sendingUser, int sdk) throws Throwable {
        if (sdk < 36) return false;
        Method full = null;
        for (Class<?> type = receiver.getClass(); type != null; type = type.getSuperclass()) {
            try {
                full = type.getDeclaredMethod("performReceive", Intent.class, int.class,
                        String.class, Bundle.class, boolean.class, boolean.class,
                        boolean.class, int.class, int.class, String.class);
                break;
            } catch (NoSuchMethodException unavailable) { }
        }
        if (full == null) return false;
        try { full.setAccessible(true); }
        catch (SecurityException denied) { return false; }
        try {
            // Same defaults as Android 16's seven-argument compatibility wrapper:
            // TYPE_REGISTERED implies assumeDelivered = !ordered, unknown sender.
            full.invoke(receiver, intent, resultCode, data, extras, ordered, sticky,
                    !ordered, sendingUser, -1, null);
        } catch (IllegalAccessException unavailable) {
            return false;
        } catch (InvocationTargetException failed) {
            // The receiver may already have enqueued delivery. Retrying would
            // duplicate broadcasts; surface its original failure instead.
            throw failed.getCause();
        }
        return true;
    }
}
