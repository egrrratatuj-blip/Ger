package top.niunaijun.blackbox.core;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.entity.pm.InstallResult;

/** Preserve native Discord OAuth; only select the virtual installation/receiver. */
public final class VirtualAuthRoutes {
    public static final String GAME="com.catsbit.oxidesurvivalisland";
    public static final String DISCORD="com.discord";
    public static final String CALLBACK_SCHEME="discord-1527264928220577925";
    private VirtualAuthRoutes() {}
    public static boolean isGameCallback(Intent intent) {
        if(intent==null || !Intent.ACTION_VIEW.equals(intent.getAction()) || intent.getData()==null) return false;
        String scheme=intent.getData().getScheme();
        return CALLBACK_SCHEME.equals(scheme) || "oxide".equals(scheme);
    }
    public static String targetPackage(Intent intent) {
        if(intent==null)return null;
        if(isGameCallback(intent)) return GAME;
        if(DISCORD.equals(intent.getPackage()) || intent.getComponent()!=null
                && DISCORD.equals(intent.getComponent().getPackageName())) return DISCORD;
        Uri uri=intent.getData();
        if(Intent.ACTION_VIEW.equals(intent.getAction()) && uri!=null) {
            if("discord".equals(uri.getScheme()))return DISCORD;
            String scheme=uri.getScheme(),host=uri.getHost(),path=uri.getPath();
            if("https".equals(scheme) && ("discord.com".equals(host) || "discordapp.com".equals(host)
                    || "canary.discord.com".equals(host) || "ptb.discord.com".equals(host))
                    && ("/oauth2/authorize".equals(path) || "/api/oauth2/authorize".equals(path))) return DISCORD;
        }
        return null;
    }
    public static Intent normalize(Intent original) {
        String target=targetPackage(original);
        if(target==null)return original;
        Intent routed=new Intent(original);
        routed.setSelector(null);
        if(isGameCallback(original)) routed.setComponent(null);
        routed.setPackage(target);
        return routed;
    }
    public static ResolveInfo resolve(Intent original,int flags,String type,int user) {
        Intent routed=normalize(original);
        return BlackBoxCore.getBPackageManager().resolveActivity(routed,flags,type,user);
    }
    public static synchronized InstallResult ensureDiscord(int user) {
        BlackBoxCore core=BlackBoxCore.get();
        if(core.isInstalled(DISCORD,user)) return new InstallResult();
        try {
            ApplicationInfo info=BlackBoxCore.getPackageManager().getApplicationInfo(DISCORD,0);
            if(!info.enabled)return new InstallResult().installError(DISCORD,"Включи Discord на телефоне");
        } catch(PackageManager.NameNotFoundException missing) {
            return new InstallResult().installError(DISCORD,"Сначала установи Discord на телефон");
        }
        InstallResult result=core.installPackageAsUser(DISCORD,user);
        if(result==null || !result.success || !core.isInstalled(DISCORD,user))
            return new InstallResult().installError(DISCORD,"Не удалось импортировать Discord");
        android.util.Log.i("AvisAuth","Discord imported user="+user);
        return result;
    }
    public static boolean discordOnPhone() {
        try { return BlackBoxCore.getPackageManager().getApplicationInfo(DISCORD,0).enabled; }
        catch(PackageManager.NameNotFoundException missing) { return false; }
    }
    public static int dispatchCallback(Uri uri,int user) {
        Intent callback=new Intent(Intent.ACTION_VIEW,uri).addCategory(Intent.CATEGORY_BROWSABLE);
        if(!isGameCallback(callback))throw new IllegalArgumentException("Unsupported callback scheme");
        Intent routed=normalize(callback);
        ResolveInfo info=resolve(routed,0,null,user);
        if(info==null)throw new IllegalStateException("OXIDE callback is not installed in this profile");
        routed.setComponent(new ComponentName(info.activityInfo.packageName,info.activityInfo.name));
        routed.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        android.util.Log.i("AvisAuth","callback route=virtual user="+user+" scheme="+uri.getScheme());
        return BlackBoxCore.getBActivityManager().startActivityAms(user,routed,null,null,null,-1,0,null);
    }
}
