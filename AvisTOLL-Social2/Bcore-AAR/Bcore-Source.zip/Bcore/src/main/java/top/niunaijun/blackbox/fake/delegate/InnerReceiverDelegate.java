package top.niunaijun.blackbox.fake.delegate;

import android.content.IIntentReceiver;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;

import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

import android.os.Build;
import android.util.Log;
import top.niunaijun.blackbox.app.BActivityThread;
import top.niunaijun.blackbox.proxy.record.ProxyBroadcastRecord;

/**
 * Created by Milk on 4/2/21.
 * * ∧＿∧
 * (`･ω･∥
 * 丶　つ０
 * しーＪ
 * 此处无Bug
 */
public class InnerReceiverDelegate extends IIntentReceiver.Stub {
    public static final String TAG = "InnerReceiverDelegate";

    private static final Map<IBinder, InnerReceiverDelegate> sInnerReceiverDelegate = new HashMap<>();
    private final WeakReference<IIntentReceiver> mIntentReceiver;

    private InnerReceiverDelegate(IIntentReceiver iIntentReceiver) {
        this.mIntentReceiver = new WeakReference<>(iIntentReceiver);
    }

    public static InnerReceiverDelegate getDelegate(IBinder iBinder) {
        return sInnerReceiverDelegate.get(iBinder);
    }

    public static IIntentReceiver createProxy(IIntentReceiver base) {
        if (base instanceof InnerReceiverDelegate) {
            return base;
        }
        final IBinder iBinder = base.asBinder();
        InnerReceiverDelegate delegate = sInnerReceiverDelegate.get(iBinder);
        if (delegate == null) {
            try {
                iBinder.linkToDeath(new DeathRecipient() {
                    @Override
                    public void binderDied() {
                        sInnerReceiverDelegate.remove(iBinder);
                        iBinder.unlinkToDeath(this, 0);
                    }
                }, 0);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
            delegate = new InnerReceiverDelegate(base);
            sInnerReceiverDelegate.put(iBinder, delegate);
        }
        return delegate;
    }

    @Override
    public void performReceive(Intent intent, int resultCode, String data, Bundle extras, boolean ordered, boolean sticky, int sendingUser) throws RemoteException {
        if (intent == null) {
            Log.w("AvisReceiver", "dispatch skipped: null intent");
            return;
        }
        intent.setExtrasClassLoader(BActivityThread.getApplication().getClassLoader());
        ProxyBroadcastRecord proxyBroadcastRecord = ProxyBroadcastRecord.create(intent);
        Intent perIntent;
        if (proxyBroadcastRecord.mIntent != null) {
            proxyBroadcastRecord.mIntent.setExtrasClassLoader(BActivityThread.getApplication().getClassLoader());
            perIntent = proxyBroadcastRecord.mIntent;
        } else {
            perIntent = intent;
        }
        IIntentReceiver iIntentReceiver = mIntentReceiver.get();
        if (iIntentReceiver != null) {
            try {
                boolean modern = ReceiverDeliveryCompat.dispatch(iIntentReceiver, perIntent,
                        resultCode, data, extras, ordered, sticky, sendingUser, Build.VERSION.SDK_INT);
                if (!modern) iIntentReceiver.performReceive(perIntent, resultCode, data, extras,
                        ordered, sticky, sendingUser);
                Log.i("AvisReceiver", "dispatch=queued route=" + (modern ? "local10" : "binder7")
                        + " action=" + perIntent.getAction() + " receiver=" + iIntentReceiver.getClass().getName()
                        + " ordered=" + ordered + " user=" + sendingUser);
            } catch (RemoteException failure) {
                Log.e("AvisReceiver", "dispatch failed action=" + perIntent.getAction(), failure);
                throw failure;
            } catch (RuntimeException failure) {
                Log.e("AvisReceiver", "dispatch failed action=" + perIntent.getAction(), failure);
                throw failure;
            } catch (Error failure) {
                throw failure;
            } catch (Throwable failure) {
                Log.e("AvisReceiver", "dispatch failed action=" + perIntent.getAction(), failure);
                throw new IllegalStateException("Receiver dispatch failed", failure);
            }
        } else {
            Log.w("AvisReceiver", "dispatch skipped: receiver reference unavailable action=" + perIntent.getAction());
        }
    }
}
