package top.niunaijun.blackbox.utils;

import android.app.Application;
import android.content.Intent;
import android.os.Bundle;

import java.lang.reflect.Field;

import top.niunaijun.blackbox.BuildConfig;
import top.niunaijun.blackbox.app.BActivityThread;
import top.niunaijun.blackbox.core.NativeCore;

/** Read-only diagnostics for the supplied OXIDE 1.17.11995 build. */
public final class GuestExitDiagnostics {
    private static final String TAG = "AvisGuestExit";
    private static final String PACKAGE = "com.catsbit.oxidesurvivalisland";
    private static final String POPUP = "adnhr5.yaPy02.aPHKt2";
    private static final String[] MESSAGE_FIELDS = {
            "msg", "shortMsg", "shouldExit", "restart", "localeKey", "messageSuffix"
    };
    private static final String[] EVENT_FIELDS = {
            "externalID", "reasonCode", "reason", "reasonData", "threatCode", "message"
    };
    private static final int MAX_VALUE_LENGTH = 4096;

    private GuestExitDiagnostics() {
    }

    private static boolean enabled() {
        return BuildConfig.DEBUG && PACKAGE.equals(BActivityThread.getAppPackageName());
    }

    public static void beforeFinishActivity() {
        try {
            if (!enabled()) return;
            StackTraceElement[] trace = Thread.currentThread().getStackTrace();
            boolean popupOnStack = false;
            StringBuilder callers = new StringBuilder("finishActivity callers:");
            int remaining = 20;
            for (StackTraceElement frame : trace) {
                String name = frame.getClassName();
                if (name.equals(POPUP) || name.startsWith(POPUP + "$")) {
                    popupOnStack = true;
                }
                if (remaining > 0 && !name.equals(Thread.class.getName())
                        && !name.equals(GuestExitDiagnostics.class.getName())) {
                    callers.append("\n  at ").append(frame);
                    remaining--;
                }
            }
            logValue("finish", callers.toString());
            // A popup frame proves the class is already initialized. Avoid initializing
            // application classes during an ordinary user-requested activity finish.
            if (!popupOnStack) {
                Slog.i(TAG, "popup snapshot skipped: known popup is absent from the call stack");
                return;
            }
            Application application = BActivityThread.getApplication();
            if (application == null) {
                Slog.i(TAG, "popup snapshot unavailable: guest application is null");
                return;
            }
            Class<?> popup = Class.forName(POPUP, false, application.getClassLoader());
            Field persistent = popup.getDeclaredField(
                    "UserIndicationPopup_private_static_persistentMessage");
            persistent.setAccessible(true);
            Object message = persistent.get(null);
            if (message == null) {
                Slog.i(TAG, "popup snapshot: persistentMessage=null");
                return;
            }
            for (String name : MESSAGE_FIELDS) {
                try {
                    Field field = message.getClass().getDeclaredField(
                            "UserIndicationPopup_MessageOutput_" + name);
                    field.setAccessible(true);
                    logValue("popup." + name, field.get(message));
                } catch (Throwable error) {
                    Slog.i(TAG, "popup." + name + " unavailable: "
                            + error.getClass().getSimpleName());
                }
            }
            try {
                NativeCore.logGuestFilesystemState(application.getApplicationInfo().dataDir);
            } catch (Throwable error) {
                reportFailure("native filesystem snapshot", error);
            }
        } catch (Throwable error) {
            reportFailure("finish snapshot", error);
        }
    }

    public static void beforeBroadcast(Intent intent) {
        try {
            if (!enabled() || intent == null) return;
            Bundle extras = intent.getExtras();
            if (extras == null || (!extras.containsKey("reasonCode")
                    && !extras.containsKey("threatCode"))) return;
            logValue("event.action", intent.getAction());
            // Deliberately omit device identifiers, tokens, and unrelated extras.
            for (String key : EVENT_FIELDS) {
                if (extras.containsKey(key)) logValue("event." + key, extras.get(key));
            }
        } catch (Throwable error) {
            reportFailure("event snapshot", error);
        }
    }

    private static void logValue(String name, Object value) {
        String text;
        if (value == null) {
            text = "<null>";
        } else if (value instanceof CharSequence || value instanceof Number
                || value instanceof Boolean || value instanceof Character) {
            text = String.valueOf(value);
        } else {
            text = "<" + value.getClass().getName() + ">";
        }
        boolean truncated = text.length() > MAX_VALUE_LENGTH;
        if (truncated) text = text.substring(0, MAX_VALUE_LENGTH);
        // Escape line breaks and split long values below Android's per-entry limit.
        text = text.replace("\\", "\\\\").replace("\r", "\\r")
                .replace("\n", "\\n").replace("\t", "\\t");
        int count = Math.max(1, (text.length() + 899) / 900);
        for (int index = 0; index < count; index++) {
            String part = text.substring(index * 900, Math.min(text.length(), (index + 1) * 900));
            Slog.i(TAG, name + " [" + (index + 1) + "/" + count + "]=" + part
                    + (truncated && index == count - 1 ? " <truncated>" : ""));
        }
    }

    private static void reportFailure(String operation, Throwable error) {
        // Diagnostics must never change the result or exception of the guest call.
        try {
            Slog.i(TAG, operation + " unavailable: " + error.getClass().getSimpleName());
        } catch (Throwable ignored) {
        }
    }
}
