package top.niunaijun.blackbox.utils.compat;

import java.util.Collections;
import java.util.List;

import top.niunaijun.blackbox.utils.Reflector;

/** Accesses current and legacy transaction layouts without linking hidden framework classes. */
public final class ClientTransactionCompat {
    private ClientTransactionCompat() {}

    private static Object read(Object owner, String getter, String field) {
        if (owner == null) return null;
        try {
            Object result = Reflector.with(owner).method(getter).call();
            if (result != null) return result;
        } catch (Exception ignored) {
            // Older releases may only expose the field.
        }
        try {
            return Reflector.with(owner).field(field).get();
        } catch (Exception ignored) {
            return null;
        }
    }

    public static List<?> getTransactionItems(Object transaction) {
        Object items = read(transaction, "getTransactionItems", "mTransactionItems");
        if (!(items instanceof List)) {
            items = read(transaction, "getCallbacks", "mActivityCallbacks");
        }
        return items instanceof List ? (List<?>) items : Collections.emptyList();
    }

    public static Object findLaunchActivityItem(Object transaction, Class<?> launchClass) {
        for (Object item : getTransactionItems(transaction)) {
            if (launchClass.isInstance(item)) return item;
        }
        return null;
    }

    public static Object getActivityToken(Object transaction, Object item) {
        Object token = read(item, "getActivityToken", "mActivityToken");
        return token != null ? token : read(transaction, "getActivityToken", "mActivityToken");
    }
}
