package top.niunaijun.blackbox.core;

import android.util.AtomicFile;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import top.niunaijun.blackbox.core.env.BEnvironment;

/** Server-owned, durable user seed. Android ID is stable and scoped to a guest package. */
public final class VirtualDeviceProfile {
    private static final int MAGIC = 0x41564931;
    private static final SecureRandom RANDOM = new SecureRandom();
    private VirtualDeviceProfile() {}
    private static AtomicFile file(int user) {
        if (user < 0) throw new IllegalArgumentException("Invalid virtual user");
        File dir = new File(BEnvironment.getSystemDir(), "device-profiles");
        if (!dir.isDirectory() && !dir.mkdirs() && !dir.isDirectory())
            throw new IllegalStateException("Cannot create device profile directory");
        return new AtomicFile(new File(dir, user + ".bin"));
    }
    private static final class Seed {
        final byte[] value; final long generation;
        Seed(byte[] value, long generation) { this.value=value; this.generation=generation; }
    }
    private static Seed read(int user) {
        AtomicFile file=file(user);
        try (DataInputStream in = new DataInputStream(file.openRead())) {
            if (in.readInt()!=MAGIC) throw new IOException("Invalid device profile format");
            long generation=in.readLong();
            byte[] seed=new byte[32]; in.readFully(seed);
            if (generation<1 || in.read()!=-1) throw new IOException("Invalid device profile record");
            return new Seed(seed,generation);
        } catch (FileNotFoundException absent) {
            byte[] seed=new byte[32]; RANDOM.nextBytes(seed);
            Seed first=new Seed(seed,1); write(file,first); return first;
        } catch (IOException failure) {
            // Never silently rotate an existing identity after a read/format error.
            throw new IllegalStateException("Cannot read virtual device profile",failure);
        }
    }
    private static void write(AtomicFile file, Seed seed) {
        FileOutputStream stream=null;
        try {
            stream=file.startWrite(); DataOutputStream out=new DataOutputStream(stream);
            out.writeInt(MAGIC); out.writeLong(seed.generation); out.write(seed.value); out.flush();
            file.finishWrite(stream);
        } catch (IOException failure) {
            if (stream!=null) file.failWrite(stream);
            throw new IllegalStateException("Cannot save virtual device profile",failure);
        }
    }
    public static synchronized String androidId(int user,String packageName) {
        if (packageName==null || packageName.isEmpty()) throw new IllegalArgumentException("Missing guest package");
        Seed seed=read(user);
        try {
            Mac mac=Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(seed.value,"HmacSHA256"));
            byte[] value=mac.doFinal(packageName.getBytes(StandardCharsets.UTF_8));
            StringBuilder hex=new StringBuilder(16);
            for(int i=0;i<8;i++) { hex.append(Character.forDigit((value[i]>>>4)&15,16)); hex.append(Character.forDigit(value[i]&15,16)); }
            return hex.toString();
        } catch (java.security.GeneralSecurityException failure) {
            throw new IllegalStateException("Cannot derive Android ID",failure);
        }
    }
    public static synchronized long reset(int user) {
        Seed previous=read(user); byte[] seed=new byte[32]; RANDOM.nextBytes(seed);
        long generation=Math.addExact(previous.generation,1);
        write(file(user),new Seed(seed,generation)); return generation;
    }
}
