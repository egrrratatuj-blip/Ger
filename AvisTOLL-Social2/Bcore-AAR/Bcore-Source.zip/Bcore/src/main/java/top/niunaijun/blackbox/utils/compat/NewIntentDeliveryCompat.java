package top.niunaijun.blackbox.utils.compat;

import android.os.IBinder;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

/** Invoke a supported framework entry point once; never retry a target exception. */
public final class NewIntentDeliveryCompat {
    private NewIntentDeliveryCompat() {}
    private static Method find(Class<?> owner,String name,Class<?>... args) {
        for(Class<?> type=owner;type!=null;type=type.getSuperclass()) {
            try { Method method=type.getDeclaredMethod(name,args); method.setAccessible(true); return method; }
            catch(NoSuchMethodException absent) { /* Try superclass/signature. */ }
        }
        return null;
    }
    private static Method recordMethod(Class<?> owner,Object record) {
        if(record!=null) {
            for(Class<?> type=record.getClass();type!=null && type!=Object.class;type=type.getSuperclass()) {
                Method found=find(owner,"handleNewIntent",type,List.class);
                if(found!=null)return found;
            }
        }
        // Detect the modern contract even if its token no longer has a record.
        for(Class<?> type=owner;type!=null;type=type.getSuperclass()) {
            for(Method method:type.getDeclaredMethods()) {
                Class<?>[] p=method.getParameterTypes();
                if("handleNewIntent".equals(method.getName()) && p.length==2 && p[1]==List.class
                        && "ActivityClientRecord".equals(p[0].getSimpleName())) {
                    method.setAccessible(true); return method;
                }
            }
        }
        return null;
    }
    private static void invoke(Method method,Object receiver,Object... args) throws Throwable {
        try { method.invoke(receiver,args); }
        catch(InvocationTargetException target) { throw target.getCause(); }
    }
    public static String dispatch(Object thread,Object record,IBinder token,List<?> intents) throws Throwable {
        if(thread==null || token==null || intents==null || intents.isEmpty())
            throw new IllegalArgumentException("Missing new-intent delivery context");
        Method modern=recordMethod(thread.getClass(),record);
        if(modern!=null) {
            if(record==null || !modern.getParameterTypes()[0].isInstance(record))
                throw new IllegalStateException("ActivityClientRecord unavailable for callback token");
            invoke(modern,thread,record,intents); return "record2";
        }
        Method method=find(thread.getClass(),"handleNewIntent",IBinder.class,List.class);
        if(method!=null) { invoke(method,thread,token,intents); return "token2"; }
        method=find(thread.getClass(),"performNewIntents",IBinder.class,List.class);
        if(method!=null) { invoke(method,thread,token,intents); return "perform2"; }
        method=find(thread.getClass(),"performNewIntents",IBinder.class,List.class,boolean.class);
        if(method!=null) { invoke(method,thread,token,intents,true); return "perform3"; }
        throw new UnsupportedOperationException("No supported framework new-intent entry point");
    }
}
