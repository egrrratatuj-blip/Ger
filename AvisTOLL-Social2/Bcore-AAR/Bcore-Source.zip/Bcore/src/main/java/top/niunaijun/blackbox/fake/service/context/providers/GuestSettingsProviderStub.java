package top.niunaijun.blackbox.fake.service.context.providers;

import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Bundle;
import java.lang.reflect.Method;
import java.util.concurrent.atomic.AtomicInteger;
import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.app.BActivityThread;

/** Intercept only Settings.Secure android_id, before the physical SettingsProvider/cache. */
public final class GuestSettingsProviderStub extends SystemProviderStub {
    private static final AtomicInteger LOGS=new AtomicInteger();
    public static void clearAndroidIdCache(Object cache) {
        synchronized(cache) {
            try {
                java.lang.reflect.Field values=cache.getClass().getDeclaredField("mValues");
                values.setAccessible(true);
                ((java.util.Map<?,?>)values.get(cache)).remove("android_id");
                try {
                    java.lang.reflect.Field trackers=cache.getClass().getDeclaredField("mGenerationTrackers");
                    trackers.setAccessible(true);
                    Object tracker=((java.util.Map<?,?>)trackers.get(cache)).remove("android_id");
                    if(tracker!=null) {
                        Method destroy=tracker.getClass().getDeclaredMethod("destroy");
                        destroy.setAccessible(true); destroy.invoke(tracker);
                    }
                } catch(NoSuchFieldException oldRelease) { /* Old releases use one global tracker. */ }
            } catch(ReflectiveOperationException | ClassCastException failure) {
                android.util.Log.w("AvisDeviceId","framework cache clear failed type="+failure.getClass().getSimpleName());
            }
        }
    }
    private String id(String route) {
        String value=BlackBoxCore.getBPackageManager().getVirtualAndroidId(
                BActivityThread.getAppPackageName(),BActivityThread.getUserId());
        if(value==null || !value.matches("[0-9a-f]{16}")) throw new IllegalStateException("Virtual Android ID unavailable");
        if(LOGS.getAndIncrement()<16) android.util.Log.i("AvisDeviceId","read route="+route
                +" package="+BActivityThread.getAppPackageName()+" user="+BActivityThread.getUserId());
        return value;
    }
    @Override public Object invoke(Object proxy,Method method,Object[] args) throws Throwable {
        if(BActivityThread.getAppPackageName()!=null && args!=null) {
            if("call".equals(method.getName())) {
                for(int i=0;i+1<args.length;i++) {
                    if("GET_secure".equals(args[i]) && "android_id".equals(args[i+1])) {
                        Bundle result=new Bundle(); result.putString("value",id("call")); return result;
                    }
                }
            }
            if("query".equals(method.getName())) {
                Uri uri=null; String[] projection=null; Bundle query=null;
                for(Object arg:args) { if(arg instanceof Uri) uri=(Uri)arg; if(arg instanceof String[]) projection=(String[])arg; if(arg instanceof Bundle)query=(Bundle)arg; }
                boolean exact=uri!=null && "settings".equals(uri.getAuthority())
                        && "/secure/android_id".equals(uri.getPath());
                boolean selected=uri!=null && "settings".equals(uri.getAuthority()) && "/secure".equals(uri.getPath())
                        && query!=null && "name=?".equals(query.getString("android:query-arg-sql-selection"))
                        && java.util.Arrays.equals(new String[]{"android_id"},query.getStringArray("android:query-arg-sql-selection-args"));
                if(exact || selected) {
                    String[] columns=projection==null?new String[]{"name","value"}:projection;
                    MatrixCursor cursor=new MatrixCursor(columns); Object[] row=new Object[columns.length];
                    String value=id("query");
                    for(int i=0;i<columns.length;i++) {
                        if("name".equals(columns[i]))row[i]="android_id";
                        else if("value".equals(columns[i]))row[i]=value;
                        else if("_id".equals(columns[i]))row[i]=0;
                    }
                    cursor.addRow(row); return cursor;
                }
            }
        }
        return super.invoke(proxy,method,args);
    }
}
