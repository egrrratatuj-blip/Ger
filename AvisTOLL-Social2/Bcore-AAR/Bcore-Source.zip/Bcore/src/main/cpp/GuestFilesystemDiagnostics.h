#pragma once

#include <jni.h>
#include <cstddef>
#include <cstdint>
#include <string>

namespace guest_fs_diagnostics {
bool readMemory(uintptr_t address, void *output, size_t size);
using MemoryReader = bool (*)(uintptr_t, void *, size_t);
bool readCString(uintptr_t address, size_t limit, std::string &output,
                 MemoryReader reader = readMemory);
bool buildProbePath(const std::string &source, uint32_t euid,
                    const std::string &packageName, std::string &output);
bool matchesLoader(uintptr_t base, MemoryReader reader = readMemory);
}

void logGuestFilesystemState(JNIEnv *env, jclass clazz, jstring dataDir);
