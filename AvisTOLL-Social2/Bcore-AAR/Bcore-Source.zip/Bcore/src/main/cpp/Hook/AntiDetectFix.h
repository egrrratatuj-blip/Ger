#ifndef BLACKBOX_ANTIDETECTFIX_H
#define BLACKBOX_ANTIDETECTFIX_H

#include <jni.h>

class AntiDetectFix {
public:
    // Apply every on-disk neutralization (memcpy bug, libc kill imports, svc stubs).
    static void patchAll(const char *path);

    // Patch known crash bugs in the guest protection loader after its library is mapped.
    static void onLibraryLoaded(const char *path);

    // Patch the on-disk copy before it is loaded: neutralize the null-source
    // deref in the loader's embedded memcpy small-tail path.
    static void patchFileOnDisk(const char *path);

    // Neutralize the protection's process-kill syscalls in its on-disk copy:
    // kill/tgkill/getpid imports become harmless getpid calls.
    static void patchSyscallsOnDisk(const char *path);

    // Neutralize raw svc stubs for fatal syscalls (exit_group/kill/tgkill/tkill)
    // in the protection's own syscall table: they return 0 instead.
    static void patchSvcStubsOnDisk(const char *path);

    // In-memory: scan libloader's executable segments for the inlined memcpy
    // small-tail pattern (ldr x3,[x1],#8 / str x3,[x6],#8) that dereferences a
    // null source during init, and nop the pair. No hardcoded offsets: the
    // libloader build on device differs from the one the constants came from.
    static void patchMemcpyCrashInMemory();
};

#endif //BLACKBOX_ANTIDETECTFIX_H
