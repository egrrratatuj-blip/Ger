#include <cstring>
#include <cstdint>
#include <cstdlib>
#include <link.h>
#include <sys/mman.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <elf.h>
#include "../Stealth/AcProbe.h"
#include "AntiDetectFix.h"
#include "Log.h"

extern "C" {
    long avis_noop(long, long, long, long, long, long);
}

__asm__(
        ".text\n"
        ".global avis_noop\n"
        "avis_noop:\n"
#if defined(__aarch64__)
        "mov w0, #0\n"
        "ret\n"
#elif defined(__arm__)
        "mov r0, #0\n"
        "bx lr\n"
#elif defined(__i386__)
        "xor %eax, %eax\n"
        "ret\n"
#endif
        );

// libloader.so ships an inlined memcpy at this offset whose small-tail path
// dereferences a null source when its JNI_OnLoad clears a stack buffer.
static constexpr uintptr_t kEmbeddedMemcpyOff = 0x2c5700;

extern "C" void *avis_memcpy_fixup(void *dst, const void *src, size_t n) {
    if (src == nullptr) {
        ALOGD("memcpy fixup: null src, dst=%p n=%zu, skipped", dst, n);
        return dst;
    }
    return memcpy(dst, src, n);
}

static int phdr_cb(struct dl_phdr_info *info, size_t, void *data) {
    const char *target = static_cast<const char *>(data);
    if (info->dlpi_name == nullptr || strstr(info->dlpi_name, target) == nullptr)
        return 0;

    uintptr_t base = info->dlpi_addr;
    uintptr_t want = base + kEmbeddedMemcpyOff;
    int patched = 0;

    for (int i = 0; i < info->dlpi_phnum; ++i) {
        const ElfW(Phdr) &ph = info->dlpi_phdr[i];
        if (ph.p_type != PT_LOAD || !(ph.p_flags & PF_W))
            continue;
        uintptr_t segStart = base + ph.p_vaddr;
        uintptr_t segEnd = segStart + ph.p_memsz;
        uintptr_t page = (uintptr_t) sysconf(_SC_PAGESIZE);
        for (uintptr_t slot = segStart; slot + sizeof(uintptr_t) <= segEnd; slot += sizeof(uintptr_t)) {
            if (*(uintptr_t *) slot == want) {
                uintptr_t pageStart = slot & ~(page - 1);
                if (mprotect((void *) pageStart, page, PROT_READ | PROT_WRITE) == 0) {
                    *(uintptr_t *) slot = (uintptr_t) &avis_memcpy_fixup;
                    mprotect((void *) pageStart, page, PROT_READ);
                    patched++;
                }
            }
        }
    }
    if (patched > 0) {
        ALOGD("memcpy fixup: patched %d GOT slots in %s", patched, info->dlpi_name);
        return 1;
    }
    return 0;
}

void AntiDetectFix::onLibraryLoaded(const char *path) {
    if (path == nullptr || strstr(path, "libloader.so") == nullptr)
        return;
    dl_iterate_phdr(phdr_cb, (void *) "libloader.so");
    patchMemcpyCrashInMemory();
}

void AntiDetectFix::patchAll(const char *path) {
    if (path == nullptr)
        return;
    // Disabled: every binary rewrite of libloader.so (GOT import swap and the
    // fatal-svc stub neutralization) breaks its DT_PREINIT_ARRAY init, which
    // uses call results to index an internal dispatch table. Any substituted
    // return value makes it read a NULL entry and die at +0x9c80d4 with
    // fault addr 0x27. All syscall-level spoofing now lives in SyscallSpoof
    // (libc inline hooks) and in the loader's own raw-svc path, which we
    // leave running so the init contract stays intact.
    ALOGD("AntiDetectFix: binary rewrites disabled for %s (spoofing at libc layer)", path);
    (void) &patchFileOnDisk;
    (void) &patchSyscallsOnDisk;
    (void) &patchSvcStubsOnDisk;
}

// AArch64: ldr x3, [x1], #8  /  str x3, [x6], #8 at the memcpy small-tail path.
// With a null source these fault; the copy result is unused, so nop them out.
static constexpr uintptr_t kCrashInsnOff = 0x2c5768;
static constexpr uint32_t kInsnLdrPost = 0xf8408423;
static constexpr uint32_t kInsnStrPost = 0xf80084c3;
static constexpr uint32_t kInsnNop = 0xd503201f;

void AntiDetectFix::patchFileOnDisk(const char *path) {
    int fd = open(path, O_RDWR);
    if (fd < 0) {
        ALOGD("memcpy fixup: open %s failed", path);
        return;
    }
    struct stat st;
    if (fstat(fd, &st) != 0 || st.st_size < (off_t) (kCrashInsnOff + 8)) {
        close(fd);
        return;
    }
    off_t mapSize = st.st_size;
    void *map = mmap(nullptr, mapSize, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (map == MAP_FAILED) {
        close(fd);
        ALOGD("memcpy fixup: mmap %s failed", path);
        return;
    }
    auto insn = reinterpret_cast<uint32_t *>((char *) map + kCrashInsnOff);
    if (insn[0] == kInsnLdrPost && insn[1] == kInsnStrPost) {
        insn[0] = kInsnNop;
        insn[1] = kInsnNop;
        msync(map, mapSize, MS_SYNC);
        ALOGD("memcpy fixup: patched on-disk memcpy tail in %s", path);
    } else if (insn[0] == kInsnNop && insn[1] == kInsnNop) {
        ALOGD("memcpy fixup: %s already patched", path);
    } else {
        ALOGD("memcpy fixup: unexpected insns %08x %08x in %s (libloader build changed, skipping)", insn[0], insn[1], path);
    }
    munmap(map, mapSize);
    close(fd);
}

void AntiDetectFix::patchSyscallsOnDisk(const char *path) {
    int fd = open(path, O_RDWR);
    if (fd < 0)
        return;
    struct stat st;
    if (fstat(fd, &st) != 0) {
        close(fd);
        return;
    }
    off_t mapSize = st.st_size;
    auto base = reinterpret_cast<char *>(mmap(nullptr, mapSize, PROT_READ | PROT_WRITE,
                                              MAP_SHARED, fd, 0));
    if (base == MAP_FAILED) {
        close(fd);
        return;
    }
    auto ehdr = reinterpret_cast<Elf64_Ehdr *>(base);
    Elf64_Dyn *dyn = nullptr;
    for (int i = 0; i < ehdr->e_phnum; ++i) {
        auto ph = reinterpret_cast<Elf64_Phdr *>(base + ehdr->e_phoff +
                                                 i * ehdr->e_phentsize);
        if (ph->p_type == PT_DYNAMIC) {
            dyn = reinterpret_cast<Elf64_Dyn *>(base + ph->p_offset);
            break;
        }
    }
    if (dyn == nullptr) {
        munmap(base, mapSize);
        close(fd);
        return;
    }
    Elf64_Rela *jmprel = nullptr;
    size_t pltrelsz = 0;
    const char *strtab = nullptr;
    Elf64_Sym *symtab = nullptr;
    for (Elf64_Dyn *d = dyn; d->d_tag != DT_NULL; ++d) {
        switch (d->d_tag) {
            case DT_JMPREL: jmprel = reinterpret_cast<Elf64_Rela *>(base + d->d_un.d_ptr); break;
            case DT_PLTRELSZ: pltrelsz = d->d_un.d_val; break;
            case DT_STRTAB: strtab = base + d->d_un.d_ptr; break;
            case DT_SYMTAB: symtab = reinterpret_cast<Elf64_Sym *>(base + d->d_un.d_ptr); break;
            default: break;
        }
    }
    int patched = 0;
    if (jmprel != nullptr && pltrelsz > 0 && strtab != nullptr && symtab != nullptr) {
        for (size_t i = 0; i < pltrelsz / sizeof(Elf64_Rela); ++i) {
            uint32_t symIdx = ELF64_R_SYM(jmprel[i].r_info);
            const char *name = strtab + symtab[symIdx].st_name;
            // Never replace the generic "syscall" import: the loader uses it
            // as its main conduit for every check (prctl, openat, getdents,
            // statfs...). Its result feeds a jump table; replacing it with a
            // noop makes the loader read a NULL dispatch entry and die at
            // +0x9c80d4 with x0=x1=-1. libc is already spoofed one layer up.
            if (strcmp(name, "syscall") == 0)
                continue;
            if (strcmp(name, "kill") == 0 || strcmp(name, "tgkill") == 0 ||
                strcmp(name, "abort") == 0) {
                auto slot = reinterpret_cast<void **>(base + jmprel[i].r_offset);
                void *replacement = strcmp(name, "kill") == 0
                                    ? (void *) &getpid : (void *) &avis_noop;
                if (*slot != replacement) {
                    ALOGD("syscall fixup: import %s slot %p -> %p in %s",
                          name, (void *) jmprel[i].r_offset, replacement, path);
                    *slot = replacement;
                    patched++;
                }
            }
        }
    }
    if (patched > 0) {
        msync(base, mapSize, MS_SYNC);
        ALOGD("syscall fixup: neutralized %d kill/syscall/abort imports in %s", patched, path);
    }
    munmap(base, mapSize);
    close(fd);
}

// aarch64 syscall numbers that end or signal the process.
static bool fatalSyscall(uint32_t n) {
    switch (n) {
        case 93:   // exit
        case 94:   // exit_group
        case 129:  // kill
        case 130:  // tkill
        case 131:  // tgkill
            return true;
        default:
            return false;
    }
}

void AntiDetectFix::patchSvcStubsOnDisk(const char *path) {
#if defined(__aarch64__)
    int fd = open(path, O_RDWR);
    if (fd < 0)
        return;
    struct stat st;
    if (fstat(fd, &st) != 0) {
        close(fd);
        return;
    }
    off_t mapSize = st.st_size;
    auto base = reinterpret_cast<char *>(mmap(nullptr, mapSize, PROT_READ | PROT_WRITE,
                                              MAP_SHARED, fd, 0));
    if (base == MAP_FAILED) {
        close(fd);
        return;
    }
    constexpr uint32_t kSvc = 0xd4000001;          // svc #0
    constexpr uint32_t kMovX8ImmMask = 0xFFE0001F; // mov x8, #imm
    constexpr uint32_t kMovX8Imm = 0xD2800008;
    int patched = 0;
    auto words = reinterpret_cast<uint32_t *>(base);
    size_t count = mapSize / sizeof(uint32_t);
    for (size_t i = 1; i + 1 < count; ++i) {
        if (words[i] != kSvc)
            continue;
        if ((words[i - 1] & kMovX8ImmMask) != kMovX8Imm)
            continue;
        uint32_t nr = (words[i - 1] >> 5) & 0xFFFF;
        if (!fatalSyscall(nr) && nr != 96 && nr != 117 && nr != 124)
            continue;
        ALOGD("svc fixup: nr=%u at fileoff 0x%zx in %s", nr,
              (i - 1) * sizeof(uint32_t), path);
        // Return a plausible live value; never execute the syscall.
        // gettid/set_tid_address/set_robust_list callers expect a tid, others expect 0.
        uint32_t imm = nr == 96 || nr == 117 ? 1000 : 0;
        words[i - 1] = 0x52800000 | ((imm & 0xFFFF) << 5); // mov w0, #imm
        words[i] = 0xd65f03c0;                             // ret
        patched++;
    }
    // Generic syscall(nr, a0..a5) stub: "mov x8,x0; mov x0,x1; ... mov x5,x6; svc".
    // Rewrite it to refuse fatal numbers and pass everything else through.
    int generic = 0;
    for (size_t i = 7; i + 19 < count; ++i) {
        if (words[i] != kSvc)
            continue;
        if (words[i - 7] == 0xaa0003e8 && words[i - 6] == 0xaa0103e0 &&
            words[i - 5] == 0xaa0203e1 && words[i - 4] == 0xaa0303e2 &&
            words[i - 3] == 0xaa0403e3 && words[i - 2] == 0xaa0503e4 &&
            words[i - 1] == 0xaa0603e5) {
            uint32_t *w = &words[i - 7];
            // Fatal numbers arrive in x0 (shifted before x8); others run the
            // original arg shuffle + svc. Branch offsets are byte offsets / 4.
            w[0] = 0x7101741F; // cmp w0, #93
            w[1] = 0x540001C0; // b.eq -> ret0
            w[2] = 0x7101941F; // cmp w0, #94
            w[3] = 0x54000180; // b.eq -> ret0
            w[4] = 0x7110151F; // cmp w0, #129
            w[5] = 0x54000140; // b.eq -> ret0
            w[6] = 0x7110541F; // cmp w0, #131
            w[7] = 0x54000100; // b.eq -> ret0
            w[8] = 0xaa0003e8; // mov x8, x0
            w[9] = 0xaa0103e0; // mov x0, x1
            w[10] = 0xaa0203e1; // mov x1, x2
            w[11] = 0xaa0303e2; // mov x2, x3
            w[12] = 0xaa0403e3; // mov x3, x4
            w[13] = 0xaa0503e4; // mov x4, x5
            w[14] = 0xaa0603e5; // mov x5, x6
            // w[15] is the original svc (words[i]) — falls through to it
            w[16] = 0xd65f03c0; // ret (after svc)
            w[17] = 0x52800000; // ret0: mov w0, #0
            w[18] = 0xd65f03c0; // ret
            generic++;
        }
    }
    if (generic > 0)
        ALOGD("svc fixup: filtered %d generic syscall stubs in %s", generic, path);
    if (patched > 0) {
        msync(base, mapSize, MS_SYNC);
        ALOGD("svc fixup: neutralized %d fatal svc stubs in %s", patched, path);
    }
    munmap(base, mapSize);
    close(fd);
#endif
}

#if defined(__aarch64__)
void AntiDetectFix::patchMemcpyCrashInMemory() {
    struct Ctx { int patched; };
    auto cb = [](struct dl_phdr_info *info, size_t, void *data) -> int {
        if (info->dlpi_name == nullptr || strstr(info->dlpi_name, "libloader.so") == nullptr)
            return 0;
        auto *ctx = static_cast<Ctx *>(data);
        uintptr_t base = info->dlpi_addr;
        constexpr uint32_t kLdrX3Post = 0xf8408423; // ldr x3, [x1], #8
        constexpr uint32_t kStrX3Post = 0xf80084c3; // str x3, [x6], #8
        constexpr uint32_t kNop = 0xd503201f;
        uintptr_t page = (uintptr_t) sysconf(_SC_PAGESIZE);
        for (int i = 0; i < info->dlpi_phnum; ++i) {
            const ElfW(Phdr) &ph = info->dlpi_phdr[i];
            if (ph.p_type != PT_LOAD || !(ph.p_flags & PF_X))
                continue;
            uintptr_t seg = base + ph.p_vaddr;
            size_t words = (ph.p_memsz - 4) / 4;
            auto *w = reinterpret_cast<uint32_t *>(seg);
            for (size_t k = 0; k < words; ++k) {
                if (w[k] == kLdrX3Post && w[k + 1] == kStrX3Post) {
                    uintptr_t addr = (uintptr_t) &w[k];
                    uintptr_t pageStart = addr & ~(page - 1);
                    if (mprotect((void *) pageStart, page * 2,
                                 PROT_READ | PROT_WRITE | PROT_EXEC) == 0) {
                        w[k] = kNop;
                        w[k + 1] = kNop;
                        __builtin___clear_cache((char *) addr, (char *) addr + 8);
                        mprotect((void *) pageStart, page * 2, PROT_READ | PROT_EXEC);
                        ctx->patched++;
                        acprobe::CallerInfo ci{};
                        strcpy(ci.module, "libloader.so");
                        acprobe::logAddr(acprobe::Cat::kCodeRestore,
                                         acprobe::Verdict::kSpoofed, ci,
                                         (void *) (addr - base), 0xdead);
                        ALOGD("memcpy fixup(mem): nopped crash pair at %s+0x%lx",
                              info->dlpi_name, (unsigned long) (addr - base));
                    }
                }
            }
        }
        return ctx->patched > 0 ? 1 : 0;
    };
    Ctx ctx{};
    dl_iterate_phdr(cb, &ctx);
    if (ctx.patched == 0)
        ALOGD("memcpy fixup(mem): pattern not found (libloader build changed again?)");
}
#else
void AntiDetectFix::patchMemcpyCrashInMemory() {}
#endif
