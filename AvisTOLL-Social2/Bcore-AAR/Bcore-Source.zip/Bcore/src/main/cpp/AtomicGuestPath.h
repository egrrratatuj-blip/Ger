#pragma once
#include <cstdint>
namespace atomic_guest_path {
bool configure(const char*,const char*,const char*,int);
bool beginLoad(const char*);
void endLoad(bool,bool);
bool active();
void logStats();
}
