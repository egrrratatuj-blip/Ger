#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace guest_event_diagnostics {
using MemoryReader = bool (*)(uintptr_t, void *, size_t);
struct Record {
    uint32_t index = 0;
    uintptr_t tagRva = 0;
    uint32_t argumentCount = 0;
    std::string tag;
    bool virtualSpaceField = false;
    bool valueAvailable = false;
    std::string virtualSpaceValue;
    bool dataField = false;
    bool dataAvailable = false;
    std::string dataValue;
};
struct Snapshot {
    std::string status;
    uint32_t countBefore = 0;
    uint32_t countAfter = 0;
    uint32_t processedBefore = 0;
    uint32_t processedAfter = 0;
    uint32_t unreadable = 0;
    uint32_t invalid = 0;
    uint32_t unstable = 0;
    std::vector<Record> records;
};
bool matchesDispatchLayout(uintptr_t base, MemoryReader reader);
Snapshot readSnapshot(uintptr_t base, MemoryReader reader);
void logSnapshot(uintptr_t base);
}
