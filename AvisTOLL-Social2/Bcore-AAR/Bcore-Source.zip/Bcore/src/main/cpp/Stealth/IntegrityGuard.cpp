#include "IntegrityGuard.h"

#include <pthread.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

#include "dobby.h"
#include "../Log.h"
#include "AcProbe.h"

namespace {

struct GuardEntry {
    void *addr;
    void *replacement;
    void **origSlot;
    unsigned char snapshot[32];
    size_t snapLen;
    bool active;
};

static GuardEntry gEntries[64];
static size_t gCount = 0;
static pthread_mutex_t gLock = PTHREAD_MUTEX_INITIALIZER;
static volatile bool gRunning = false;
static pthread_t gThread;
static unsigned long gGeneration = 0;

static void snapshotEntry(GuardEntry &e) {
    memcpy(e.snapshot, e.addr, e.snapLen);
}

static bool entryIntact(const GuardEntry &e) {
    return memcmp(e.addr, e.snapshot, e.snapLen) == 0;
}

static unsigned long mixSeed(unsigned long v) {
    v ^= v >> 33;
    v *= 0xff51afd7ed558ccdUL;
    v ^= v >> 33;
    return v;
}

static void *guardLoop(void *) {
    unsigned long seed = (unsigned long) time(nullptr) ^ (unsigned long) (uintptr_t) &gCount;
    while (gRunning) {
        seed = mixSeed(seed + gGeneration);
        struct timespec ts;
        ts.tv_sec = 1 + (long) (seed % 3);
        ts.tv_nsec = (long) (seed % 900000000UL);
        nanosleep(&ts, nullptr);
        if (!gRunning) break;
        pthread_mutex_lock(&gLock);
        for (size_t i = 0; i < gCount; ++i) {
            GuardEntry &e = gEntries[i];
            if (!e.active) continue;
            if (!entryIntact(e)) {
                ALOGD("IntegrityGuard: hook %zu at %p was tampered, reinstalling", i, e.addr);
                acprobe::CallerInfo ci{};
                strcpy(ci.module, "integrity-guard");
                acprobe::logAddr(acprobe::Cat::kCodeRestore,
                                 acprobe::Verdict::kSpoofed, ci, e.addr, (long) i);
                void *freshOrig = nullptr;
                if (DobbyHook(e.addr, e.replacement, &freshOrig) == 0) {
                    if (e.origSlot != nullptr) *e.origSlot = freshOrig;
                    snapshotEntry(e);
                    gGeneration++;
                } else {
                    e.active = false;
                }
            }
        }
        pthread_mutex_unlock(&gLock);
    }
    return nullptr;
}

}

void IntegrityGuard::add(void *addr, void *replacement, void **origSlot) {
    pthread_mutex_lock(&gLock);
    if (gCount < sizeof(gEntries) / sizeof(gEntries[0]) && addr != nullptr) {
        GuardEntry &e = gEntries[gCount++];
        e.addr = addr;
        e.replacement = replacement;
        e.origSlot = origSlot;
        e.snapLen = 16;
        e.active = true;
        snapshotEntry(e);
    }
    pthread_mutex_unlock(&gLock);
}

void IntegrityGuard::start() {
    if (gRunning) return;
    gRunning = true;
    if (pthread_create(&gThread, nullptr, &guardLoop, nullptr) != 0) {
        gRunning = false;
    }
}

void IntegrityGuard::stop() {
    gRunning = false;
}
