#ifndef BLACKBOX_SYSCALLSPOOF_H
#define BLACKBOX_SYSCALLSPOOF_H

class SyscallSpoof {
public:
    static void install();
    static void installLate();
    static void addPathPair(const char *virtualPath, const char *realPath);
    static bool isBridgeAddress(void *addr);
};

#endif
