#ifndef BLACKBOX_ACPROBE_H
#define BLACKBOX_ACPROBE_H

#include <stddef.h>
#include <stdint.h>

namespace acprobe {

enum class Cat : int {
    kPrctl = 0,
    kTiming = 1,
    kFdScan = 2,
    kReadlink = 3,
    kFileProbe = 4,
    kKillProbe = 5,
    kModuleScan = 6,
    kAuxv = 7,
    kMincore = 8,
    kProp = 9,
    kUname = 10,
    kStatfs = 11,
    kPkgScan = 12,
    kProcRead = 13,
    kThreadSpawn = 14,
    kCodeRestore = 15,
    kHookCheck = 16,
    kUnknown = 17,
};

enum class Verdict : int {
    kPassThrough = 0,
    kSpoofed = 1,
    kBlocked = 2,
    kRewritten = 3,
    kFiltered = 4,
};

struct CallerInfo {
    void *ret;
    char module[128];
    uintptr_t moduleBase;
    uintptr_t offset;
    bool isProtection;
    bool isBridge;
    bool isGuestGame;
};

void init();
void setEnabled(bool on);
bool enabled();

CallerInfo classifyCaller(void *ret);
const char *catName(Cat c);
const char *verdictName(Verdict v);

void logEvent(Cat cat, Verdict verdict, const CallerInfo &caller,
              const char *detail, ...);
void logPath(Cat cat, Verdict verdict, const CallerInfo &caller,
             const char *pathIn, const char *pathOut);
void logAddr(Cat cat, Verdict verdict, const CallerInfo &caller,
             void *addr, long aux);

bool pathFromProtectionModule(const char *path);
void noteProtectionModule(const char *name, uintptr_t base, uintptr_t end);

}

#endif
