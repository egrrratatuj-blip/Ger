#ifndef BLACKBOX_STEALTHSTRINGS_H
#define BLACKBOX_STEALTHSTRINGS_H

#include <stddef.h>
#include <string.h>

namespace stealth {

static inline void decodeBlob(const unsigned char *src, size_t len, char *dst) {
    for (size_t i = 0; i < len; ++i) {
        dst[i] = (char) (src[i] ^ (unsigned char) (0xA5 ^ (i * 0x3D)));
    }
    dst[len] = '\0';
}

struct Blob {
    const unsigned char *data;
    size_t len;
    char *get(char *scratch) const {
        decodeBlob(data, len, scratch);
        return scratch;
    }
};

#define STEALTH_BLOB(name, str) \
    static const unsigned char name##_raw[] = { str }; \
    static const ::stealth::Blob name = { name##_raw, sizeof(name##_raw) - 1 };

#define STEALTH_STR lit
#define STEALTH_ENC1(c, i) ((unsigned char)((c) ^ (unsigned char)(0xA5 ^ ((i) * 0x3D))))
#define STEALTH_E0(c)  STEALTH_ENC1(c, 0)
#define STEALTH_E1(c)  STEALTH_ENC1(c, 1)
#define STEALTH_E2(c)  STEALTH_ENC1(c, 2)
#define STEALTH_E3(c)  STEALTH_ENC1(c, 3)
#define STEALTH_E4(c)  STEALTH_ENC1(c, 4)
#define STEALTH_E5(c)  STEALTH_ENC1(c, 5)
#define STEALTH_E6(c)  STEALTH_ENC1(c, 6)
#define STEALTH_E7(c)  STEALTH_ENC1(c, 7)
#define STEALTH_E8(c)  STEALTH_ENC1(c, 8)
#define STEALTH_E9(c)  STEALTH_ENC1(c, 9)
#define STEALTH_E10(c) STEALTH_ENC1(c, 10)
#define STEALTH_E11(c) STEALTH_ENC1(c, 11)
#define STEALTH_E12(c) STEALTH_ENC1(c, 12)
#define STEALTH_E13(c) STEALTH_ENC1(c, 13)
#define STEALTH_E14(c) STEALTH_ENC1(c, 14)
#define STEALTH_E15(c) STEALTH_ENC1(c, 15)
#define STEALTH_E16(c) STEALTH_ENC1(c, 16)
#define STEALTH_E17(c) STEALTH_ENC1(c, 17)
#define STEALTH_E18(c) STEALTH_ENC1(c, 18)
#define STEALTH_E19(c) STEALTH_ENC1(c, 19)
#define STEALTH_E20(c) STEALTH_ENC1(c, 20)
#define STEALTH_E21(c) STEALTH_ENC1(c, 21)
#define STEALTH_E22(c) STEALTH_ENC1(c, 22)
#define STEALTH_E23(c) STEALTH_ENC1(c, 23)
#define STEALTH_E24(c) STEALTH_ENC1(c, 24)
#define STEALTH_E25(c) STEALTH_ENC1(c, 25)
#define STEALTH_E26(c) STEALTH_ENC1(c, 26)
#define STEALTH_E27(c) STEALTH_ENC1(c, 27)
#define STEALTH_E28(c) STEALTH_ENC1(c, 28)
#define STEALTH_E29(c) STEALTH_ENC1(c, 29)
#define STEALTH_E30(c) STEALTH_ENC1(c, 30)
#define STEALTH_E31(c) STEALTH_ENC1(c, 31)

static const unsigned char kTokHostPkg_raw[] = {
    STEALTH_E0('c'),STEALTH_E1('o'),STEALTH_E2('m'),STEALTH_E3('.'),STEALTH_E4('a'),
    STEALTH_E5('v'),STEALTH_E6('i'),STEALTH_E7('s'),STEALTH_E8('.'),STEALTH_E9('t'),
    STEALTH_E10('o'),STEALTH_E11('o'),STEALTH_E12('l')
};
static const Blob kTokHostPkg = { kTokHostPkg_raw, sizeof(kTokHostPkg_raw) };

static const unsigned char kTokGuestPkg_raw[] = {
    STEALTH_E0('c'),STEALTH_E1('o'),STEALTH_E2('m'),STEALTH_E3('.'),STEALTH_E4('c'),
    STEALTH_E5('a'),STEALTH_E6('t'),STEALTH_E7('s'),STEALTH_E8('b'),STEALTH_E9('i'),
    STEALTH_E10('t'),STEALTH_E11('.'),STEALTH_E12('o'),STEALTH_E13('x'),STEALTH_E14('i'),
    STEALTH_E15('d'),STEALTH_E16('e'),STEALTH_E17('s'),STEALTH_E18('u'),STEALTH_E19('r'),
    STEALTH_E20('v'),STEALTH_E21('i'),STEALTH_E22('v'),STEALTH_E23('a'),STEALTH_E24('l'),
    STEALTH_E25('i'),STEALTH_E26('s'),STEALTH_E27('l'),STEALTH_E28('a'),STEALTH_E29('n'),
    STEALTH_E30('d')
};
static const Blob kTokGuestPkg = { kTokGuestPkg_raw, sizeof(kTokGuestPkg_raw) };

static const unsigned char kTokBridge_raw[] = {
    STEALTH_E0('l'),STEALTH_E1('i'),STEALTH_E2('b'),STEALTH_E3('A'),STEALTH_E4('B'),
    STEALTH_E5('r'),STEALTH_E6('i'),STEALTH_E7('d'),STEALTH_E8('g'),STEALTH_E9('e')
};
static const Blob kTokBridge = { kTokBridge_raw, sizeof(kTokBridge_raw) };

static const unsigned char kTokBoxDir_raw[] = {
    STEALTH_E0('/'),STEALTH_E1('b'),STEALTH_E2('l'),STEALTH_E3('a'),STEALTH_E4('c'),
    STEALTH_E5('k'),STEALTH_E6('b'),STEALTH_E7('o'),STEALTH_E8('x')
};
static const Blob kTokBoxDir = { kTokBoxDir_raw, sizeof(kTokBoxDir_raw) };

static const unsigned char kTokPine_raw[] = {
    STEALTH_E0('p'),STEALTH_E1('i'),STEALTH_E2('n'),STEALTH_E3('e')
};
static const Blob kTokPine = { kTokPine_raw, sizeof(kTokPine_raw) };

static const unsigned char kTokDataUserPrefix_raw[] = {
    STEALTH_E0('/'),STEALTH_E1('d'),STEALTH_E2('a'),STEALTH_E3('t'),STEALTH_E4('a'),
    STEALTH_E5('/'),STEALTH_E6('u'),STEALTH_E7('s'),STEALTH_E8('e'),STEALTH_E9('r'),
    STEALTH_E10('/'),STEALTH_E11('0'),STEALTH_E12('/')
};
static const Blob kTokDataUserPrefix = { kTokDataUserPrefix_raw, sizeof(kTokDataUserPrefix_raw) };

static const unsigned char kTokLinker64_raw[] = {
    STEALTH_E0('l'),STEALTH_E1('i'),STEALTH_E2('n'),STEALTH_E3('k'),STEALTH_E4('e'),
    STEALTH_E5('r'),STEALTH_E6('6'),STEALTH_E7('4')
};
static const Blob kTokLinker64 = { kTokLinker64_raw, sizeof(kTokLinker64_raw) };

static const unsigned char kTokLinker32_raw[] = {
    STEALTH_E0('/'),STEALTH_E1('l'),STEALTH_E2('i'),STEALTH_E3('n'),STEALTH_E4('k'),
    STEALTH_E5('e'),STEALTH_E6('r')
};
static const Blob kTokLinker32 = { kTokLinker32_raw, sizeof(kTokLinker32_raw) };

static const unsigned char kTokVdso_raw[] = {
    STEALTH_E0('['),STEALTH_E1('v'),STEALTH_E2('d'),STEALTH_E3('s'),STEALTH_E4('o'),
    STEALTH_E5(']')
};
static const Blob kTokVdso = { kTokVdso_raw, sizeof(kTokVdso_raw) };

static const unsigned char kTokProcSelfFd_raw[] = {
    STEALTH_E0('/'),STEALTH_E1('p'),STEALTH_E2('r'),STEALTH_E3('o'),STEALTH_E4('c'),
    STEALTH_E5('/'),STEALTH_E6('s'),STEALTH_E7('e'),STEALTH_E8('l'),STEALTH_E9('f'),
    STEALTH_E10('/'),STEALTH_E11('f'),STEALTH_E12('d')
};
static const Blob kTokProcSelfFd = { kTokProcSelfFd_raw, sizeof(kTokProcSelfFd_raw) };

static const unsigned char kTokDataUser_raw[] = {
    STEALTH_E0('/'),STEALTH_E1('d'),STEALTH_E2('a'),STEALTH_E3('t'),STEALTH_E4('a'),
    STEALTH_E5('/'),STEALTH_E6('u'),STEALTH_E7('s'),STEALTH_E8('e'),STEALTH_E9('r')
};
static const Blob kTokDataUser = { kTokDataUser_raw, sizeof(kTokDataUser_raw) };

static const unsigned char kTokDataData_raw[] = {
    STEALTH_E0('/'),STEALTH_E1('d'),STEALTH_E2('a'),STEALTH_E3('t'),STEALTH_E4('a'),
    STEALTH_E5('/'),STEALTH_E6('d'),STEALTH_E7('a'),STEALTH_E8('t'),STEALTH_E9('a')
};
static const Blob kTokDataData = { kTokDataData_raw, sizeof(kTokDataData_raw) };

struct BadTokenEntry { Blob blob; char scratch[128]; bool ready; };

static const unsigned char kBad0_raw[] = {
    STEALTH_E0('g'),STEALTH_E1('a'),STEALTH_E2('m'),STEALTH_E3('e'),STEALTH_E4('g'),
    STEALTH_E5('u'),STEALTH_E6('a'),STEALTH_E7('r'),STEALTH_E8('d'),STEALTH_E9('i'),
    STEALTH_E10('a'),STEALTH_E11('n')
};
static const unsigned char kBad1_raw[] = {
    STEALTH_E0('c'),STEALTH_E1('o'),STEALTH_E2('m'),STEALTH_E3('.'),STEALTH_E4('g'),
    STEALTH_E5('g'),STEALTH_E6('p')
};
static const unsigned char kBad2_raw[] = {
    STEALTH_E0('c'),STEALTH_E1('o'),STEALTH_E2('m'),STEALTH_E3('.'),STEALTH_E4('s'),
    STEALTH_E5('f'),STEALTH_E6('z'),STEALTH_E7('m'),STEALTH_E8('.'),STEALTH_E9('t'),
    STEALTH_E10('o'),STEALTH_E11('o'),STEALTH_E12('l'),STEALTH_E13('s')
};
static const unsigned char kBad3_raw[] = {
    STEALTH_E0('v'),STEALTH_E1('i'),STEALTH_E2('r'),STEALTH_E3('t'),STEALTH_E4('u'),
    STEALTH_E5('a'),STEALTH_E6('l'),STEALTH_E7('x'),STEALTH_E8('p'),STEALTH_E9('o'),
    STEALTH_E10('s'),STEALTH_E11('e'),STEALTH_E12('d')
};
static const unsigned char kBad4_raw[] = {
    STEALTH_E0('v'),STEALTH_E1('i'),STEALTH_E2('r'),STEALTH_E3('t'),STEALTH_E4('u'),
    STEALTH_E5('a'),STEALTH_E6('l'),STEALTH_E7('a'),STEALTH_E8('p'),STEALTH_E9('p')
};
static const unsigned char kBad5_raw[] = {
    STEALTH_E0('l'),STEALTH_E1('b'),STEALTH_E2('e'),STEALTH_E3('.'),STEALTH_E4('p'),
    STEALTH_E5('a'),STEALTH_E6('r'),STEALTH_E7('a'),STEALTH_E8('l'),STEALTH_E9('l'),
    STEALTH_E10('e'),STEALTH_E11('l')
};
static const unsigned char kBad6_raw[] = {
    STEALTH_E0('p'),STEALTH_E1('a'),STEALTH_E2('r'),STEALTH_E3('a'),STEALTH_E4('l'),
    STEALTH_E5('l'),STEALTH_E6('e'),STEALTH_E7('l'),STEALTH_E8('.'),STEALTH_E9('s'),
    STEALTH_E10('p'),STEALTH_E11('a'),STEALTH_E12('c'),STEALTH_E13('e')
};
static const unsigned char kBad7_raw[] = {
    STEALTH_E0('d'),STEALTH_E1('u'),STEALTH_E2('a'),STEALTH_E3('l'),STEALTH_E4('s'),
    STEALTH_E5('p'),STEALTH_E6('a'),STEALTH_E7('c'),STEALTH_E8('e')
};
static const unsigned char kBad8_raw[] = {
    STEALTH_E0('a'),STEALTH_E1('p'),STEALTH_E2('p'),STEALTH_E3('c'),STEALTH_E4('l'),
    STEALTH_E5('o'),STEALTH_E6('n'),STEALTH_E7('e'),STEALTH_E8('r')
};
static const unsigned char kBad9_raw[] = {
    STEALTH_E0('e'),STEALTH_E1('x'),STEALTH_E2('c'),STEALTH_E3('e'),STEALTH_E4('l'),
    STEALTH_E5('l'),STEALTH_E6('i'),STEALTH_E7('a'),STEALTH_E8('n'),STEALTH_E9('c'),
    STEALTH_E10('e')
};
static const unsigned char kBad10_raw[] = {
    STEALTH_E0('m'),STEALTH_E1('u'),STEALTH_E2('l'),STEALTH_E3('t'),STEALTH_E4('i'),
    STEALTH_E5('a'),STEALTH_E6('c'),STEALTH_E7('c'),STEALTH_E8('o'),STEALTH_E9('u'),
    STEALTH_E10('n'),STEALTH_E11('t'),STEALTH_E12('s')
};
static const unsigned char kBad11_raw[] = {
    STEALTH_E0('m'),STEALTH_E1('u'),STEALTH_E2('l'),STEALTH_E3('t'),STEALTH_E4('i'),
    STEALTH_E5('.'),STEALTH_E6('p'),STEALTH_E7('a'),STEALTH_E8('r'),STEALTH_E9('a'),
    STEALTH_E10('l'),STEALTH_E11('l'),STEALTH_E12('e'),STEALTH_E13('l')
};
static const unsigned char kBad12_raw[] = {
    STEALTH_E0('c'),STEALTH_E1('o'),STEALTH_E2('m'),STEALTH_E3('.'),STEALTH_E4('p'),
    STEALTH_E5('o'),STEALTH_E6('l'),STEALTH_E7('e'),STEALTH_E8('s'),STEALTH_E9('t'),
    STEALTH_E10('a'),STEALTH_E11('r')
};
static const unsigned char kBad13_raw[] = {
    STEALTH_E0('g'),STEALTH_E1('o'),STEALTH_E2('l'),STEALTH_E3('d'),STEALTH_E4('f'),
    STEALTH_E5('i'),STEALTH_E6('s'),STEALTH_E7('h')
};
static const unsigned char kBad14_raw[] = {
    STEALTH_E0('r'),STEALTH_E1('a'),STEALTH_E2('n'),STEALTH_E3('c'),STEALTH_E4('h'),
    STEALTH_E5('u')
};
static const unsigned char kBad15_raw[] = {
    STEALTH_E0('x'),STEALTH_E1('p'),STEALTH_E2('o'),STEALTH_E3('s'),STEALTH_E4('e'),
    STEALTH_E5('d')
};
static const unsigned char kBad16_raw[] = {
    STEALTH_E0('f'),STEALTH_E1('r'),STEALTH_E2('i'),STEALTH_E3('d'),STEALTH_E4('a')
};
static const unsigned char kBad17_raw[] = {
    STEALTH_E0('m'),STEALTH_E1('a'),STEALTH_E2('g'),STEALTH_E3('i'),STEALTH_E4('s'),
    STEALTH_E5('k')
};
static const unsigned char kBad18_raw[] = {
    STEALTH_E0('s'),STEALTH_E1('u'),STEALTH_E2('b'),STEALTH_E3('s'),STEALTH_E4('t'),
    STEALTH_E5('r'),STEALTH_E6('a'),STEALTH_E7('t'),STEALTH_E8('e')
};
static const unsigned char kBad19_raw[] = {
    STEALTH_E0('c'),STEALTH_E1('o'),STEALTH_E2('m'),STEALTH_E3('.'),STEALTH_E4('t'),
    STEALTH_E5('o'),STEALTH_E6('p'),STEALTH_E7('j'),STEALTH_E8('o'),STEALTH_E9('h'),
    STEALTH_E10('n'),STEALTH_E11('w'),STEALTH_E12('u')
};

static BadTokenEntry gBadTokens[] = {
    { { kBad0_raw, sizeof(kBad0_raw) }, {}, false },
    { { kBad1_raw, sizeof(kBad1_raw) }, {}, false },
    { { kBad2_raw, sizeof(kBad2_raw) }, {}, false },
    { { kBad3_raw, sizeof(kBad3_raw) }, {}, false },
    { { kBad4_raw, sizeof(kBad4_raw) }, {}, false },
    { { kBad5_raw, sizeof(kBad5_raw) }, {}, false },
    { { kBad6_raw, sizeof(kBad6_raw) }, {}, false },
    { { kBad7_raw, sizeof(kBad7_raw) }, {}, false },
    { { kBad8_raw, sizeof(kBad8_raw) }, {}, false },
    { { kBad9_raw, sizeof(kBad9_raw) }, {}, false },
    { { kBad10_raw, sizeof(kBad10_raw) }, {}, false },
    { { kBad11_raw, sizeof(kBad11_raw) }, {}, false },
    { { kBad12_raw, sizeof(kBad12_raw) }, {}, false },
    { { kBad13_raw, sizeof(kBad13_raw) }, {}, false },
    { { kBad14_raw, sizeof(kBad14_raw) }, {}, false },
    { { kBad15_raw, sizeof(kBad15_raw) }, {}, false },
    { { kBad16_raw, sizeof(kBad16_raw) }, {}, false },
    { { kBad17_raw, sizeof(kBad17_raw) }, {}, false },
    { { kBad18_raw, sizeof(kBad18_raw) }, {}, false },
    { { kBad19_raw, sizeof(kBad19_raw) }, {}, false },
};

static void ensureBadTokensDecoded() {
    for (auto &entry : gBadTokens) {
        if (!entry.ready) {
            decodeBlob(entry.blob.data, entry.blob.len, entry.scratch);
            for (size_t i = 0; entry.scratch[i]; ++i) {
                if (entry.scratch[i] >= 'A' && entry.scratch[i] <= 'Z')
                    entry.scratch[i] = (char) (entry.scratch[i] - 'A' + 'a');
            }
            entry.ready = true;
        }
    }
}

static inline bool containsToken(const char *text, size_t textLen,
                                 const char *token, size_t tokenLen) {
    if (tokenLen == 0 || textLen < tokenLen) return false;
    for (size_t i = 0; i + tokenLen <= textLen; ++i) {
        size_t j = 0;
        for (; j < tokenLen; ++j) {
            char c = text[i + j];
            if (c >= 'A' && c <= 'Z') c = (char) (c - 'A' + 'a');
            if (c != token[j]) break;
        }
        if (j == tokenLen) return true;
    }
    return false;
}

static inline void lowercase(char *s) {
    for (; *s; ++s) {
        if (*s >= 'A' && *s <= 'Z') *s = (char) (*s - 'A' + 'a');
    }
}

static bool matchesBadTokensLen(const char *text, size_t len) {
    if (text == nullptr) return false;
    ensureBadTokensDecoded();
    for (auto &entry : gBadTokens) {
        if (containsToken(text, len, entry.scratch, entry.blob.len)) return true;
    }
    char host[64];
    kTokHostPkg.get(host);
    if (containsToken(text, len, host, kTokHostPkg.len)) return true;
    char bridge[64];
    kTokBridge.get(bridge);
    lowercase(bridge);
    if (containsToken(text, len, bridge, kTokBridge.len)) return true;
    char boxdir[64];
    kTokBoxDir.get(boxdir);
    lowercase(boxdir);
    if (containsToken(text, len, boxdir + 1, kTokBoxDir.len - 1)) return true;
    char pine[64];
    kTokPine.get(pine);
    if (containsToken(text, len, pine, kTokPine.len)) return true;
    return false;
}

static bool matchesBadTokensLenNoHost(const char *text, size_t len) {
    if (text == nullptr) return false;
    ensureBadTokensDecoded();
    for (auto &entry : gBadTokens) {
        if (containsToken(text, len, entry.scratch, entry.blob.len)) return true;
    }
    char bridge[64];
    kTokBridge.get(bridge);
    lowercase(bridge);
    if (containsToken(text, len, bridge, kTokBridge.len)) return true;
    char boxdir[64];
    kTokBoxDir.get(boxdir);
    lowercase(boxdir);
    if (containsToken(text, len, boxdir + 1, kTokBoxDir.len - 1)) return true;
    char pine[64];
    kTokPine.get(pine);
    if (containsToken(text, len, pine, kTokPine.len)) return true;
    return false;
}

static bool matchesBadTokens(const char *text) {
    if (text == nullptr) return false;
    ensureBadTokensDecoded();
    size_t len = strlen(text);
    for (auto &entry : gBadTokens) {
        if (containsToken(text, len, entry.scratch, entry.blob.len)) return true;
    }
    char host[64];
    kTokHostPkg.get(host);
    if (containsToken(text, len, host, kTokHostPkg.len)) return true;
    char bridge[64];
    kTokBridge.get(bridge);
    lowercase(bridge);
    if (containsToken(text, len, bridge, kTokBridge.len)) return true;
    char boxdir[64];
    kTokBoxDir.get(boxdir);
    lowercase(boxdir);
    if (containsToken(text, len, boxdir + 1, kTokBoxDir.len - 1)) return true;
    return false;
}

}

#endif
