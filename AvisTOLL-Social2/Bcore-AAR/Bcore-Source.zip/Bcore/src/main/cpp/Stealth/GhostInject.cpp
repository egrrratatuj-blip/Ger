#include "GhostInject.h"

#include <dlfcn.h>
#include <elf.h>
#include <fcntl.h>
#include <link.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <unistd.h>

#include "StealthStrings.h"
#include "AcProbe.h"
#include "dobby.h"
#include "../Log.h"
#include <signal.h>
#include <setjmp.h>
#include <ucontext.h>
#include <unwind.h>

namespace {

constexpr uintptr_t kNoBase = 0;

// ---- crash forensics: temporary SIGSEGV handler with siglongjmp recovery ----
// Installed only around the window where the protection's PREINIT_ARRAY runs
// after nativeLoad. If it still dies, we dump the exact pc/x0..x28 context to
// the probe log and re-raise, so the tombstone keeps working as before.

static sigjmp_buf gCrashJmp;
static volatile bool gHandlerArmed = false;
static struct sigaction gPrevSegv{};

static uintptr_t gLoaderBaseFwd = 0;
static uintptr_t gLoaderEndFwd = 0;

#if defined(__aarch64__)
static uintptr_t findCallerFrame(uintptr_t lr, uintptr_t sp, uintptr_t stackTop) {
    // The faulting frame is the inlined leaf (strlen/memcpy walk); its caller
    // sits one frame up. Scan the stack window for the lr value itself, then
    // one slot below for the next saved lr. Falls back to the raw lr.
    for (uintptr_t p = sp; p + 16 <= stackTop; p += 8) {
        uintptr_t v = *reinterpret_cast<uintptr_t *>(p);
        if (v == lr && p >= sp + 8) {
            uintptr_t outer = *reinterpret_cast<uintptr_t *>(p - 8);
            if (outer > gLoaderBaseFwd && outer < gLoaderEndFwd)
                return outer;
            if (outer > 0x700000000000ULL && outer < 0x800000000000ULL)
                return outer;
        }
    }
    return lr;
}
#endif

static volatile bool gStubsPatched = false;

#if defined(__aarch64__)
static void writeInsns(uintptr_t addr, const uint32_t *insns, size_t count) {
    uintptr_t page = (uintptr_t) sysconf(_SC_PAGESIZE);
    uintptr_t start = addr & ~(page - 1);
    size_t span = ((addr + count * 4 + page - 1) & ~(page - 1)) - start;
    if (mprotect((void *) start, span, PROT_READ | PROT_WRITE | PROT_EXEC) != 0)
        return;
    auto *w = reinterpret_cast<uint32_t *>(addr);
    for (size_t i = 0; i < count; ++i) w[i] = insns[i];
    __builtin___clear_cache((char *) addr, (char *) (addr + count * 4));
    mprotect((void *) start, span, PROT_READ | PROT_EXEC);
}

// Emulates readlinkat(AT_FDCWD, path, buf, size) = 0 with buf[0] = 0:
// the link the loader probes resolves to an empty target on a clean install.
static void patchStubAt(uintptr_t va, uint32_t expectMov, uint32_t expectSvc) {
    uintptr_t addr = gLoaderBaseFwd + va;
    auto *w = reinterpret_cast<uint32_t *>(addr);
    if (w[0] != expectMov || w[1] != expectSvc) {
        acprobe::CallerInfo ci{};
        strcpy(ci.module, "ghostinject");
        acprobe::logEvent(acprobe::Cat::kCodeRestore,
                          acprobe::Verdict::kPassThrough, ci,
                          "stub mismatch at +0x%lx: %08x %08x",
                          (unsigned long) va, w[0], w[1]);
        return;
    }
    uint32_t code[] = {
        0x3900007f, // strb wzr, [x3]      buf[0] = 0
        0xaa1f03e0, // mov x0, xzr         return 0
        0xd65f03c0, // ret
        0xd503201f, // nop (pad over cmn/cneg/b.hi)
        0xd503201f,
        0xd503201f,
    };
    writeInsns(addr, code, sizeof(code) / sizeof(code[0]));
    acprobe::CallerInfo ci{};
    strcpy(ci.module, "ghostinject");
    acprobe::logEvent(acprobe::Cat::kCodeRestore,
                      acprobe::Verdict::kSpoofed, ci,
                      "stub +0x%lx now returns empty link", (unsigned long) va);
}

// exit_group(94)/tkill/tgkill raw stubs: the loader kills itself through
// these when its environment verdict fails; making them return keeps the
// process alive so we can observe what it does next.
static void patchFatalStubAt(uintptr_t va, uint32_t expectMov) {
    uintptr_t addr = gLoaderBaseFwd + va;
    auto *w = reinterpret_cast<uint32_t *>(addr);
    if (w[0] != expectMov || w[1] != 0xd4000001u) return;
    uint32_t code[] = {
        0xaa1f03e0, // mov x0, xzr
        0xd65f03c0, // ret
    };
    writeInsns(addr, code, 2);
    acprobe::CallerInfo ci{};
    strcpy(ci.module, "ghostinject");
    acprobe::logEvent(acprobe::Cat::kCodeRestore,
                      acprobe::Verdict::kSpoofed, ci,
                      "fatal stub +0x%lx neutralized", (unsigned long) va);
}

// GOT entry replacement: libloader imports "syscall" and uses it once
// (0xc94964). Route fatal numbers to success, pass everything else through
// to the real libc syscall().
static long (*gRealSyscall)(long, ...) = nullptr;
static long ghostSyscall(long nr, long a1, long a2, long a3, long a4, long a5, long a6) {
    if (nr == 93 || nr == 94 || nr == 129 || nr == 130 || nr == 131) {
        acprobe::CallerInfo ci{};
        strcpy(ci.module, "ghostinject");
        acprobe::logEvent(acprobe::Cat::kKillProbe, acprobe::Verdict::kBlocked,
                          ci, "syscall(%ld) blocked", nr);
        return 0;
    }
    return gRealSyscall(nr, a1, a2, a3, a4, a5, a6);
}

static void patchLoaderGotSyscall() {
    // find libloader's .dynamic GOT slot for the "syscall" import and point it
    // at ghostSyscall. Walk its dynamic segment from the in-memory image.
    struct Ctx { uintptr_t base; bool done; };
    auto cb = [](struct dl_phdr_info *info, size_t, void *data) -> int {
        if (info->dlpi_name == nullptr || strstr(info->dlpi_name, "libloader.so") == nullptr)
            return 0;
        auto *ctx = static_cast<Ctx *>(data);
        uintptr_t base = info->dlpi_addr;
        Elf64_Dyn *dyn = nullptr;
        for (int i = 0; i < info->dlpi_phnum; ++i) {
            const Elf64_Phdr &ph = info->dlpi_phdr[i];
            if (ph.p_type == PT_DYNAMIC) {
                dyn = reinterpret_cast<Elf64_Dyn *>(base + ph.p_vaddr);
                break;
            }
        }
        if (dyn == nullptr) return 1;
        Elf64_Rela *rela = nullptr;
        size_t relasz = 0;
        Elf64_Rela *jmprel = nullptr;
        size_t pltrelsz = 0;
        const char *strtab = nullptr;
        Elf64_Sym *symtab = nullptr;
        for (Elf64_Dyn *d = dyn; d->d_tag != DT_NULL; ++d) {
            switch (d->d_tag) {
                case DT_RELA: rela = reinterpret_cast<Elf64_Rela *>(base + d->d_un.d_ptr); break;
                case DT_RELASZ: relasz = d->d_un.d_val; break;
                case DT_JMPREL: jmprel = reinterpret_cast<Elf64_Rela *>(base + d->d_un.d_ptr); break;
                case DT_PLTRELSZ: pltrelsz = d->d_un.d_val; break;
                case DT_STRTAB: strtab = reinterpret_cast<const char *>(base + d->d_un.d_ptr); break;
                case DT_SYMTAB: symtab = reinterpret_cast<Elf64_Sym *>(base + d->d_un.d_ptr); break;
                default: break;
            }
        }
        if (strtab == nullptr || symtab == nullptr) return 1;
        uintptr_t page = (uintptr_t) sysconf(_SC_PAGESIZE);
        // "syscall" is a PLT import (JUMP_SLOT), not a RELA one.
        size_t total = (relasz + pltrelsz);
        (void) total;
        for (int pass = 0; pass < 2; ++pass) {
            Elf64_Rela *table = pass == 0 ? jmprel : rela;
            size_t bytes = pass == 0 ? pltrelsz : relasz;
            if (table == nullptr || bytes == 0) continue;
            for (size_t i = 0; i < bytes / sizeof(Elf64_Rela); ++i) {
                uint32_t symIdx = ELF64_R_SYM(table[i].r_info);
                const char *name = strtab + symtab[symIdx].st_name;
                if (strcmp(name, "syscall") != 0) continue;
                auto slot = reinterpret_cast<void **>(base + table[i].r_offset);
                uintptr_t pageStart = (uintptr_t) slot & ~(page - 1);
                mprotect((void *) pageStart, page, PROT_READ | PROT_WRITE);
                *slot = (void *) &ghostSyscall;
                mprotect((void *) pageStart, page, PROT_READ);
                ctx->done = true;
                acprobe::CallerInfo ci{};
                strcpy(ci.module, "ghostinject");
                acprobe::logEvent(acprobe::Cat::kCodeRestore,
                                  acprobe::Verdict::kSpoofed, ci,
                                  "GOT syscall slot +0x%lx routed (pass=%d)",
                                  (unsigned long) table[i].r_offset, pass);
            }
        }
        // also patch kill import while we are here
        for (int pass = 0; pass < 2; ++pass) {
            Elf64_Rela *table = pass == 0 ? jmprel : rela;
            size_t bytes = pass == 0 ? pltrelsz : relasz;
            if (table == nullptr || bytes == 0) continue;
            for (size_t i = 0; i < bytes / sizeof(Elf64_Rela); ++i) {
                uint32_t symIdx = ELF64_R_SYM(table[i].r_info);
                const char *name = strtab + symtab[symIdx].st_name;
                if (strcmp(name, "kill") != 0) continue;
                auto slot = reinterpret_cast<void **>(base + table[i].r_offset);
                uintptr_t pageStart = (uintptr_t) slot & ~(page - 1);
                mprotect((void *) pageStart, page, PROT_READ | PROT_WRITE);
                *slot = (void *) &getpid; // any kill() call yields a positive pid-like value
                mprotect((void *) pageStart, page, PROT_READ);
                acprobe::CallerInfo ci{};
                strcpy(ci.module, "ghostinject");
                acprobe::logEvent(acprobe::Cat::kCodeRestore,
                                  acprobe::Verdict::kSpoofed, ci,
                                  "GOT kill slot +0x%lx neutralized",
                                  (unsigned long) table[i].r_offset);
            }
        }
        return 1;
    };
    Ctx ctx{};
    dl_iterate_phdr(cb, &ctx);
}

static void logFullSigCtx(ucontext_t *uc, siginfo_t *si) {
#if defined(__aarch64__)
    acprobe::CallerInfo ci{};
    strcpy(ci.module, "ghostinject");
    acprobe::logEvent(acprobe::Cat::kHookCheck, acprobe::Verdict::kBlocked, ci,
        "SIGCTX fa=%llx pc=+0x%llx "
        "x0=%llx x1=%llx x2=%llx x3=%llx x4=%llx x5=%llx x6=%llx x7=%llx "
        "x8=%llx x9=%llx x10=%llx x11=%llx x12=%llx x13=%llx x14=%llx x15=%llx "
        "x16=%llx x17=%llx x18=%llx x19=%llx x20=%llx x21=%llx x22=%llx x23=%llx "
        "x24=%llx x25=%llx x26=%llx x27=%llx x28=%llx fp=%llx lr=+0x%llx sp=%llx",
        (unsigned long long)(uintptr_t) si->si_addr,
        (unsigned long long)(uc->uc_mcontext.pc - gLoaderBaseFwd),
        (unsigned long long)uc->uc_mcontext.regs[0], (unsigned long long)uc->uc_mcontext.regs[1],
        (unsigned long long)uc->uc_mcontext.regs[2], (unsigned long long)uc->uc_mcontext.regs[3],
        (unsigned long long)uc->uc_mcontext.regs[4], (unsigned long long)uc->uc_mcontext.regs[5],
        (unsigned long long)uc->uc_mcontext.regs[6], (unsigned long long)uc->uc_mcontext.regs[7],
        (unsigned long long)uc->uc_mcontext.regs[8], (unsigned long long)uc->uc_mcontext.regs[9],
        (unsigned long long)uc->uc_mcontext.regs[10], (unsigned long long)uc->uc_mcontext.regs[11],
        (unsigned long long)uc->uc_mcontext.regs[12], (unsigned long long)uc->uc_mcontext.regs[13],
        (unsigned long long)uc->uc_mcontext.regs[14], (unsigned long long)uc->uc_mcontext.regs[15],
        (unsigned long long)uc->uc_mcontext.regs[16], (unsigned long long)uc->uc_mcontext.regs[17],
        (unsigned long long)uc->uc_mcontext.regs[18], (unsigned long long)uc->uc_mcontext.regs[19],
        (unsigned long long)uc->uc_mcontext.regs[20], (unsigned long long)uc->uc_mcontext.regs[21],
        (unsigned long long)uc->uc_mcontext.regs[22], (unsigned long long)uc->uc_mcontext.regs[23],
        (unsigned long long)uc->uc_mcontext.regs[24], (unsigned long long)uc->uc_mcontext.regs[25],
        (unsigned long long)uc->uc_mcontext.regs[26], (unsigned long long)uc->uc_mcontext.regs[27],
        (unsigned long long)uc->uc_mcontext.regs[28], (unsigned long long)uc->uc_mcontext.regs[29],
        (unsigned long long)(uc->uc_mcontext.regs[30] - gLoaderBaseFwd),
        (unsigned long long)uc->uc_mcontext.sp);
#else
    (void) uc; (void) si;
#endif
}

static void patchLoaderSvcStubs() {
    if (gLoaderBaseFwd == 0) return;
    gStubsPatched = true;
    if (gRealSyscall == nullptr) {
        gRealSyscall = reinterpret_cast<long (*)(long, ...)>(dlsym(RTLD_NEXT, "syscall"));
        if (gRealSyscall == nullptr)
            gRealSyscall = reinterpret_cast<long (*)(long, ...)>(dlsym(RTLD_DEFAULT, "syscall"));
    }
    patchLoaderGotSyscall();
    // 0x73a848 = readlinkat stub wrapper (b 0x73a3f4: mov x8,#56; svc; errno)
    // Patch the shared body at 0x73a3f4: every readlinkat call returns "".
    patchStubAt(0x73a3f4, 0xd2800708u, 0xd4000001u);
    patchFatalStubAt(0x73a5fc, 0xd2800bc8u); // exit_group(94)
    patchFatalStubAt(0x73a614, 0xd2801068u); // tgkill(131)
    patchFatalStubAt(0x73a74c, 0xd2801028u); // kill(129)
    patchFatalStubAt(0x73a6d4, 0xd2800ea8u); // set_tid_address(117) -> keep? it was neutralized before harmlessly
}
#endif

static void ghostSegvHandler(int sig, siginfo_t *si, void *ucRaw) {
    auto *uc = reinterpret_cast<ucontext_t *>(ucRaw);
#if defined(__aarch64__)
    uintptr_t pc = uc->uc_mcontext.pc;
    uintptr_t lr = uc->uc_mcontext.regs[30];
    uintptr_t sp = uc->uc_mcontext.sp;

    // The log below doubles as liveness proof: its writes go through raw
    // syscalls, so even if ART's sigchain tears the process down right after
    // us, the line is already in the file.
    {
        char raw[192];
        int rn = snprintf(raw, sizeof(raw),
                          "GHFAULT pc=%llx fa=%llx base=%llx off=%llx\n",
                          (unsigned long long) pc,
                          (unsigned long long) (uintptr_t) si->si_addr,
                          (unsigned long long) gLoaderBaseFwd,
                          (unsigned long long)
                              (gLoaderBaseFwd != 0 ? pc - gLoaderBaseFwd : 0));
        syscall(SYS_write, 2, raw, (size_t) rn);
        // also into the probe log file through acprobe's own fd path
        acprobe::CallerInfo rc{};
        strcpy(rc.module, "ghostinject");
        acprobe::logEvent(acprobe::Cat::kHookCheck, acprobe::Verdict::kPassThrough,
                          rc, "GHFAULT pc=%llx fa=%llx base=%llx",
                          (unsigned long long) pc,
                          (unsigned long long) (uintptr_t) si->si_addr,
                          (unsigned long long) gLoaderBaseFwd);
    }

    uintptr_t caller = 0;
    if (gLoaderBaseFwd != 0 && lr >= gLoaderBaseFwd && lr < gLoaderEndFwd) {
        uintptr_t stackTop = (sp + 0x4000) & ~0xFFFULL;
        caller = findCallerFrame(lr, sp, stackTop);
    }
    acprobe::CallerInfo ci{};
    strcpy(ci.module, "ghostinject");
    acprobe::logEvent(acprobe::Cat::kHookCheck, acprobe::Verdict::kBlocked, ci,
        "SIGSEGV fault_addr=%p pc=0x%llx (libloader+0x%llx) caller~0x%llx "
        "(libloader+0x%llx) x0=%llx x1=%llx x2=%llx x3=%llx x8=%llx x16=%llx "
        "x17=%llx lr=0x%llx sp=0x%llx",
        si->si_addr,
        (unsigned long long) pc,
        (unsigned long long) (pc - gLoaderBaseFwd),
        (unsigned long long) caller,
        (unsigned long long) (caller != 0 ? caller - gLoaderBaseFwd : 0),
        (unsigned long long) uc->uc_mcontext.regs[0],
        (unsigned long long) uc->uc_mcontext.regs[1],
        (unsigned long long) uc->uc_mcontext.regs[2],
        (unsigned long long) uc->uc_mcontext.regs[3],
        (unsigned long long) uc->uc_mcontext.regs[8],
        (unsigned long long) uc->uc_mcontext.regs[16],
        (unsigned long long) uc->uc_mcontext.regs[17],
        (unsigned long long) lr,
        (unsigned long long) sp);
#else
    (void) uc;
    (void) si;
#endif
    // First fault: skip the faulting half-copy in place (the inlined memcpy
    // tail at libloader+0x73d5a8, null source). The thread continues with the
    // next tbz — no register or stack damage, so subsequent faults should not
    // cascade from this one. Any second fault goes to the default handler.
    static volatile int gRecovered = 0;
#if defined(__aarch64__)
    uintptr_t pcNow = uc->uc_mcontext.pc;
    uintptr_t lrNow = uc->uc_mcontext.regs[30];
    if (gLoaderBaseFwd == 0) {
        // First fault arrives before the deferred scanner wakes: the text
        // segment is already mapped, so the faulting pc itself tells us the
        // base (the file offset of the faulting insn is constant).
        constexpr uintptr_t kTailOff = 0x73d5a8;
        uintptr_t base = pcNow - kTailOff;
        if ((base & 0xFFF) == 0 && base > 0x4000000000ULL && base < 0x800000000000ULL) {
            gLoaderBaseFwd = base;
            gLoaderEndFwd = base + 0x1000000;
            {
                acprobe::CallerInfo bc{};
                strcpy(bc.module, "ghostinject");
                acprobe::logEvent(acprobe::Cat::kHookCheck,
                                  acprobe::Verdict::kPassThrough, bc,
                                  "GHBASE base=%llx", (unsigned long long) base);
            }
        }
    }
    // Base sanity: a same-process (gdb/debugger) test fault at the same
    // offset from a different mapping must not be treated as the loader.
    if (gLoaderBaseFwd != 0 && !gStubsPatched) {
        // We know the base (a previous fault computed it). Patch the raw-svc
        // stubs BEFORE the faulting instruction runs again. This is the real
        // fix for the whole cascade: openat(-100, path, 0) gets its virtual
        // path rewritten, so the init's stat/readlink see what they expect
        // on a real device and never feed NULL into the string machinery.
        patchLoaderSvcStubs();
    }
    if (gLoaderBaseFwd != 0) {
        uintptr_t off = pcNow - gLoaderBaseFwd;
        acprobe::CallerInfo dbg{};
        strcpy(dbg.module, "ghostinject");
        if (off < 0x1000000) {
            acprobe::logEvent(acprobe::Cat::kHookCheck,
                              acprobe::Verdict::kPassThrough, dbg,
                              "fault in loader range: off=0x%llx x0=%llx x1=%llx x2=%llx",
                              (unsigned long long) off,
                              (unsigned long long) uc->uc_mcontext.regs[0],
                              (unsigned long long) uc->uc_mcontext.regs[1],
                              (unsigned long long) uc->uc_mcontext.regs[2]);
        }
        if (off == 0x9c80d4) {
            // ldr x8, [x0, #40] where x0 = openat result (-1 in the box).
            // Give the state machine a small positive "fd" and re-run.
            uc->uc_mcontext.regs[0] = 0x1000;
            return;
        }
        if (off == 0xb98ec || off == 0xb98e8) {
            {
                static volatile int gCtxDumped = 0;
                if (__sync_fetch_and_add(&gCtxDumped, 1) < 2)
                    logFullSigCtx(uc, si);
            }
            // Second init fault: worker thread walks a std::string that
            // PREINIT never filled (x0==0, ldrb [x9,#8]). Same empty-link
            // contract: give it a NUL and return to the caller (lr), which
            // then does readlinkat(x1=that buffer) and proceeds with "".
            uintptr_t dst = lrNow; // not used; see below
            (void) dst;
            // x0 is the string object; emulate the empty-SSO state by making
            // the caller see a zero-length read. Returning x0=0 with pc=lr
            // makes the wrapper yield "" and the thread exits cleanly.
            uc->uc_mcontext.regs[0] = 0;
            uc->uc_mcontext.pc = lrNow;
            int n = __sync_fetch_and_add(&gRecovered, 1);
            if (n < 3) {
                acprobe::CallerInfo ci{};
                strcpy(ci.module, "ghostinject");
                acprobe::logEvent(acprobe::Cat::kHookCheck,
                                  acprobe::Verdict::kSpoofed, ci,
                                  "emulated empty-string worker at +0xb98ec lr=+0x%llx",
                                  (unsigned long long) (lrNow - gLoaderBaseFwd));
            }
            return;
        }
        if (off == 0x73d5a4 || off == 0x73d5a8) {
            // memcpy(dst=x0, src=x1, len=x2) with x1==0 and x2==u64(-8) comes
            // from the init state machine right after its raw-svc readlinkat
            // returned -1 (the link target the loader wants does not exist in
            // the container). The state machine only needs a well-formed
            // empty C string at the destination and the trailing NUL write
            // that follows the call; emulate exactly that and return to the
            // caller (lr), leaving x0=dst so `strb wzr,[x28,x20]` terminates
            // it as on a real device where the link resolves to "".
            uintptr_t dst = uc->uc_mcontext.regs[0];
            uintptr_t dstPage = dst & ~0xFFFULL;
            if (dst != 0 && dstPage > 0x1000 &&
                mprotect((void *) dstPage, 0x2000,
                         PROT_READ | PROT_WRITE) == 0) {
                *reinterpret_cast<unsigned char *>(dst) = 0;
                uc->uc_mcontext.regs[2] = 0;      // len := 0
                uc->uc_mcontext.pc = lrNow; // return to caller
                int n = __sync_fetch_and_add(&gRecovered, 1);
                if (n < 3) {
                    acprobe::CallerInfo ci{};
                    strcpy(ci.module, "ghostinject");
                    acprobe::logEvent(acprobe::Cat::kHookCheck,
                                      acprobe::Verdict::kSpoofed, ci,
                                      "emulated empty-link memcpy: dst=%llx lr=+0x%llx",
                                      (unsigned long long) dst,
                                      (unsigned long long) (lrNow - gLoaderBaseFwd));
                }
                return;
            }
        }
    }
    (void) gRecovered;
#endif
    signal(sig, SIG_DFL);
    raise(sig);
}

static void armCrashWindow() {
    struct sigaction sa{};
    sa.sa_sigaction = &ghostSegvHandler;
    sa.sa_flags = SA_SIGINFO | SA_ONSTACK;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGSEGV, &sa, &gPrevSegv);
}

uintptr_t gLoaderBase = kNoBase;
uintptr_t gLoaderEnd = 0;
char gLoaderPath[256] = {};

bool gArmed = false;

static ssize_t rawWriteLog(const char *s, size_t n) {
    return (ssize_t) syscall(SYS_write, 2, s, n);
}

static void logRaw(const char *msg) {
    size_t n = strlen(msg);
    rawWriteLog(msg, n);
    rawWriteLog("\n", 1);
}

struct CallSite {
    uintptr_t offset;
    char note[96];
    bool patched;
};

static CallSite gSites[4096];
static size_t gSiteCount = 0;
static pthread_mutex_t gSiteLock = PTHREAD_MUTEX_INITIALIZER;

#if defined(__aarch64__)

static inline uint32_t makeBl(uintptr_t from, uintptr_t to) {
    int64_t delta = (int64_t) (to - from);
    int64_t imm26 = delta >> 2;
    return 0x94000000u | ((uint32_t) imm26 & 0x03FFFFFFu);
}

static inline bool isBl(uint32_t insn) {
    return (insn & 0xFC000000u) == 0x94000000u;
}

static inline uintptr_t blTarget(uintptr_t pc, uint32_t insn) {
    int32_t imm26 = (int32_t) (insn << 6) >> 6;
    return pc + ((int64_t) imm26 << 2);
}

#endif

static void armWrite(uintptr_t addr, uint32_t value) {
    uintptr_t page = (uintptr_t) sysconf(_SC_PAGESIZE);
    uintptr_t pageStart = addr & ~(page - 1);
    if (mprotect((void *) pageStart, page * 2,
                 PROT_READ | PROT_WRITE | PROT_EXEC) == 0) {
        *reinterpret_cast<uint32_t *>(addr) = value;
        __builtin___clear_cache((char *) addr, (char *) addr + 4);
        mprotect((void *) pageStart, page * 2, PROT_READ | PROT_EXEC);
    }
}

static void dumpTextAround(uintptr_t addr, int wordsBefore, int wordsAfter) {
    auto *w = reinterpret_cast<uint32_t *>(addr);
    char line[256];
    for (int i = -wordsBefore; i <= wordsAfter; ++i) {
        uintptr_t a = (uintptr_t) (w + i);
        int n = snprintf(line, sizeof(line),
                         "GHOSTTEXT %s+0x%lx: %08x",
                         gLoaderPath, (unsigned long) (a - gLoaderBase), w[i]);
        rawWriteLog(line, (size_t) n);
        rawWriteLog("\n", 1);
    }
}

struct TraceRecord {
    uintptr_t pc;
    uint32_t insn;
};

static TraceRecord gTrace[256];
static volatile size_t gTraceCount = 0;

static void noteSite(uintptr_t off, const char *note) {
    pthread_mutex_lock(&gSiteLock);
    if (gSiteCount < sizeof(gSites) / sizeof(gSites[0])) {
        CallSite &s = gSites[gSiteCount++];
        s.offset = off;
        strncpy(s.note, note, sizeof(s.note) - 1);
        s.note[sizeof(s.note) - 1] = '\0';
        s.patched = false;
    }
    pthread_mutex_unlock(&gSiteLock);
}

static void scanLoaderImage() {
#if defined(__aarch64__)
    if (gLoaderBase == kNoBase) return;
    uintptr_t page = (uintptr_t) sysconf(_SC_PAGESIZE);

    struct dl_phdr_info self{};
    int fd = (int) syscall(SYS_openat, AT_FDCWD, gLoaderPath, O_RDONLY | O_CLOEXEC, 0);
    if (fd < 0) return;
    struct stat st{};
    if (syscall(SYS_fstat, fd, &st) != 0) {
        syscall(SYS_close, fd);
        return;
    }
    void *map = mmap(nullptr, (size_t) st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
    syscall(SYS_close, fd);
    if (map == MAP_FAILED) return;

    auto ehdr = reinterpret_cast<Elf64_Ehdr *>(map);
    uintptr_t textOff = 0;
    size_t textSize = 0;
    for (int i = 0; i < ehdr->e_phnum; ++i) {
        auto ph = reinterpret_cast<Elf64_Phdr *>((char *) map + ehdr->e_phoff +
                                                 i * ehdr->e_phentsize);
        if (ph->p_type == PT_LOAD && (ph->p_flags & PF_X)) {
            textOff = ph->p_offset;
            textSize = ph->p_filesz;
            break;
        }
    }
    if (textOff == 0 && textSize == 0) {
        munmap(map, (size_t) st.st_size);
        return;
    }

    auto *fileWords = reinterpret_cast<uint32_t *>((char *) map + textOff);
    size_t fileCount = textSize / 4;

    size_t blCalls = 0, svcStubs = 0, adrPairs = 0;
    for (size_t i = 1; i + 1 < fileCount; ++i) {
        uint32_t w = fileWords[i];
        if (isBl(w)) blCalls++;
        if (w == 0xd4000001u && (fileWords[i - 1] & 0xFFE0001Fu) == 0xD2800008u) {
            uint32_t nr = (fileWords[i - 1] >> 5) & 0xFFFF;
            uintptr_t voff = textOff + i * 4;
            char note[64];
            snprintf(note, sizeof(note), "raw-svc nr=%u", nr);
            noteSite(voff, note);
            svcStubs++;
        }
        if ((w & 0x9F000000u) == 0x90000000u) adrPairs++;
    }
    char line[160];
    int n = snprintf(line, sizeof(line),
                     "GHOST scan %s: bl=%zu svc-stubs=%zu adrp=%zu textfilesz=0x%zx",
                     gLoaderPath, blCalls, svcStubs, adrPairs, textSize);
    rawWriteLog(line, (size_t) n);
    rawWriteLog("\n", 1);

    uintptr_t crashVA = 0x73d5a8;
    uintptr_t crashAddr = gLoaderBase + crashVA;
    if (crashVA < textSize + textOff) {
        dumpTextAround(crashAddr, 12, 6);
        uintptr_t pageStart = crashAddr & ~(page - 1);
        (void) pageStart;
    }
    munmap(map, (size_t) st.st_size);
#endif
}

static bool isLoaderPath(const char *path) {
    return path != nullptr && strstr(path, "libloader.so") != nullptr;
}

}

#if defined(__aarch64__)
// Patch libloader ON DISK before dlopen: readlinkat stub (+0x73a3f4) returns
// an empty link; fatal stubs (exit_group 94, tgkill 131, kill 129 at
// +0x73a5fc/+0x73a614/+0x73a74c) become no-ops. The file offset equals the
// vaddr here (PT_LOAD with p_offset == p_vaddr alignment for .text).
static void patchFileOnDiskEarly(const char *path) {
    int fd = (int) syscall(SYS_openat, AT_FDCWD, path, O_RDWR | O_CLOEXEC, 0);
    if (fd < 0) {
        // read-only mount: fall back to the fault-driven in-memory path
        return;
    }
    struct StatCompat { char b[256]; };
    struct stat st{};
    if (syscall(SYS_fstat, fd, &st) != 0 || st.st_size < 0x740000) {
        syscall(SYS_close, fd);
        return;
    }
    void *map = mmap(nullptr, (size_t) st.st_size, PROT_READ | PROT_WRITE,
                     MAP_SHARED, fd, 0);
    syscall(SYS_close, fd);
    if (map == MAP_FAILED) return;
    auto *w = reinterpret_cast<uint32_t *>((char *) map);

    struct Patch { uintptr_t off; uint32_t expect[2]; uint32_t repl[6]; size_t n; };
    const Patch patches[] = {
        // openat(56) stub body: strb wzr,[x3]; mov x0,xzr; ret; nops
        { 0x73a3f4, { 0xd2800708u, 0xd4000001u },
          { 0x3900007fu, 0xaa1f03e0u, 0xd65f03c0u, 0xd503201fu, 0xd503201fu, 0xd503201fu }, 6 },
        // exit_group
        { 0x73a5fc, { 0xd2800bc8u, 0xd4000001u },
          { 0xaa1f03e0u, 0xd65f03c0u, 0,0,0,0 }, 2 },
        // tgkill
        { 0x73a614, { 0xd2801068u, 0xd4000001u },
          { 0xaa1f03e0u, 0xd65f03c0u, 0,0,0,0 }, 2 },
        // kill
        { 0x73a74c, { 0xd2801028u, 0xd4000001u },
          { 0xaa1f03e0u, 0xd65f03c0u, 0,0,0,0 }, 2 },
        // readlinkat(78) at 0x73a50c: empty link result
        { 0x73a50c, { 0xd28009c8u, 0xd4000001u },
          { 0x3900007fu, 0xaa1f03e0u, 0xd65f03c0u, 0xd503201fu, 0xd503201fu, 0xd503201fu }, 6 },
    };
    int applied = 0;
    for (const Patch &p : patches) {
        uint32_t *at = reinterpret_cast<uint32_t *>((char *) map + p.off);
        if (at[0] == p.repl[0] && (p.n < 2 || at[1] == p.repl[1])) {
            applied++; // already patched
            continue;
        }
        if (at[0] != p.expect[0] || at[1] != p.expect[1]) continue;
        for (size_t i = 0; i < p.n; ++i) at[i] = p.repl[i];
        applied++;
    }
    msync(map, (size_t) st.st_size, MS_SYNC);
    munmap(map, (size_t) st.st_size);
    if (applied > 0) {
        acprobe::CallerInfo ci{};
        strcpy(ci.module, "ghostinject");
        acprobe::logEvent(acprobe::Cat::kCodeRestore, acprobe::Verdict::kSpoofed,
                          ci, "on-disk pre-patch applied to %d stubs", applied);
    }
}
#endif

void GhostInject::preLoad(const char *path) {
    if (!isLoaderPath(path)) return;
#if defined(__aarch64__)
    patchFileOnDiskEarly(path);
#endif
    armCrashWindow();
    gHandlerArmed = true;
    (void) gCrashJmp;
    strncpy(gLoaderPath, path, sizeof(gLoaderPath) - 1);
    gLoaderPath[sizeof(gLoaderPath) - 1] = '\0';
    acprobe::CallerInfo ci{};
    strcpy(ci.module, "ghostinject");
    acprobe::logEvent(acprobe::Cat::kProcRead, acprobe::Verdict::kPassThrough,
                      ci, "preLoad libloader path=[%s]", path);

    // Deferred scan: the scan must run after dlopen finished mapping, but the
    // nativeLoad hook returns straight into the protection's init which never
    // comes back to us. A detached thread waits for the mapping to appear.
    pthread_t t;
    pthread_create(&t, nullptr, [](void *) -> void * {
        for (int i = 0; i < 500; ++i) {
            struct timespec ts{0, 10 * 1000 * 1000};
            nanosleep(&ts, nullptr);
            if (gLoaderBase != kNoBase) break;
            struct FindCtx {};
            auto findCb = [](struct dl_phdr_info *info, size_t, void *) -> int {
                if (info->dlpi_name == nullptr ||
                    strstr(info->dlpi_name, "libloader.so") == nullptr)
                    return 0;
                uintptr_t base = info->dlpi_addr;
                uintptr_t end = base;
                for (int p = 0; p < info->dlpi_phnum; ++p) {
                    if (info->dlpi_phdr[p].p_type == PT_LOAD) {
                        uintptr_t e = base + info->dlpi_phdr[p].p_vaddr +
                                      info->dlpi_phdr[p].p_memsz;
                        if (e > end) end = e;
                    }
                }
                gLoaderBase = base;
                gLoaderEnd = end;
                gLoaderBaseFwd = base;
                gLoaderEndFwd = end;
                return 1;
            };
            dl_iterate_phdr(findCb, nullptr);
        }
        if (gLoaderBase != kNoBase) {
            acprobe::CallerInfo ci{};
            strcpy(ci.module, "ghostinject");
            acprobe::logEvent(acprobe::Cat::kModuleScan,
                              acprobe::Verdict::kPassThrough, ci,
                              "libloader mapped base=%p end=%p",
                              (void *) gLoaderBase, (void *) gLoaderEnd);
            scanLoaderImage();
            pthread_mutex_lock(&gSiteLock);
            for (size_t i = 0; i < gSiteCount; ++i) {
                acprobe::logEvent(acprobe::Cat::kCodeRestore,
                                  acprobe::Verdict::kPassThrough, ci,
                                  "site libloader.so+0x%lx %s",
                                  (unsigned long) gSites[i].offset,
                                  gSites[i].note);
            }
            pthread_mutex_unlock(&gSiteLock);
        }
        return nullptr;
    }, nullptr);
    pthread_detach(t);
}

void GhostInject::postLoad(const char *path) {
    gHandlerArmed = false;
    if (gPrevSegv.sa_sigaction != nullptr || gPrevSegv.sa_handler != nullptr) {
        sigaction(SIGSEGV, &gPrevSegv, nullptr);
        gPrevSegv = {};
    }
    if (!isLoaderPath(path) || gArmed) return;
    gArmed = true;

    struct Ctx {};
    auto cb = [](struct dl_phdr_info *info, size_t, void *) -> int {
        if (info->dlpi_name == nullptr || strstr(info->dlpi_name, "libloader.so") == nullptr)
            return 0;
        uintptr_t base = info->dlpi_addr;
        uintptr_t end = base;
        for (int i = 0; i < info->dlpi_phnum; ++i) {
            if (info->dlpi_phdr[i].p_type == PT_LOAD) {
                uintptr_t e = base + info->dlpi_phdr[i].p_vaddr +
                              info->dlpi_phdr[i].p_memsz;
                if (e > end) end = e;
            }
        }
        gLoaderBase = base;
        gLoaderEnd = end;
        gLoaderBaseFwd = base;
        gLoaderEndFwd = end;
        return 1;
    };
    dl_iterate_phdr(cb, nullptr);

    acprobe::CallerInfo ci{};
    strcpy(ci.module, "ghostinject");
    acprobe::logEvent(acprobe::Cat::kModuleScan, acprobe::Verdict::kPassThrough,
                      ci, "libloader mapped base=%p end=%p",
                      (void *) gLoaderBase, (void *) gLoaderEnd);

    scanLoaderImage();

    pthread_mutex_lock(&gSiteLock);
    for (size_t i = 0; i < gSiteCount; ++i) {
        acprobe::logEvent(acprobe::Cat::kCodeRestore, acprobe::Verdict::kPassThrough,
                          ci, "site %s+0x%lx %s", "libloader.so",
                          (unsigned long) gSites[i].offset, gSites[i].note);
    }
    pthread_mutex_unlock(&gSiteLock);
}
