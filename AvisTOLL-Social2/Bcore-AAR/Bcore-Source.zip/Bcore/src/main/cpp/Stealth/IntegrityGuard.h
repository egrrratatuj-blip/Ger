#ifndef BLACKBOX_INTEGRITYGUARD_H
#define BLACKBOX_INTEGRITYGUARD_H

#include <stddef.h>

class IntegrityGuard {
public:
    static void add(void *addr, void *replacement, void **origSlot);
    static void start();
    static void stop();
};

#endif
