#ifndef BLACKBOX_GHOSTINJECT_H
#define BLACKBOX_GHOSTINJECT_H

class GhostInject {
public:
    // Called from the nativeLoad JNI hook before the load completes.
    static void preLoad(const char *path);
    // Called after the library mapped; arms in-image patches before control
    // returns to the Java side that triggered the load.
    static void postLoad(const char *path);
};

#endif
