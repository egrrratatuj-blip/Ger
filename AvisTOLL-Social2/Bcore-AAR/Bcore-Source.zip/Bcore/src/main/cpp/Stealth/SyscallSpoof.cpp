#include "SyscallSpoof.h"

#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <link.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/auxv.h>
#include <sys/mman.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/system_properties.h>
#include <sys/types.h>
#include <unistd.h>

#include "dobby.h"
#include "StealthStrings.h"
#include "IntegrityGuard.h"
#include "../Log.h"
#include "AcProbe.h"

namespace {

struct PathPair {
    char virtualPath[256];
    char realPath[256];
    bool used;
};

static PathPair gPairs[64];
static size_t gPairCount = 0;
static pthread_mutex_t gPairLock = PTHREAD_MUTEX_INITIALIZER;

static uintptr_t gBridgeBase = 0;
static uintptr_t gBridgeEnd = 0;
static unsigned long gLinkerBase = 0;
static unsigned long gVdsoBase = 0;
static bool gInstalled = false;

static char gHostPkg[64];
static char gGuestPkg[64];
static size_t gHostPkgLen = 0;
static size_t gGuestPkgLen = 0;

static int rawOpen(const char *path, int flags) {
    return (int) syscall(SYS_openat, AT_FDCWD, path, flags, 0);
}

static ssize_t rawRead(int fd, void *buf, size_t count) {
    return (ssize_t) syscall(SYS_read, fd, buf, count);
}

static void rawClose(int fd) {
    syscall(SYS_close, fd);
}

static ssize_t rawReadlinkat(int dirfd, const char *path, char *buf, size_t size) {
    return (ssize_t) syscall(SYS_readlinkat, dirfd, path, buf, size);
}

static void initStrings() {
    static bool done = false;
    if (done) return;
    done = true;
    stealth::kTokHostPkg.get(gHostPkg);
    stealth::kTokGuestPkg.get(gGuestPkg);
    gHostPkgLen = strlen(gHostPkg);
    gGuestPkgLen = strlen(gGuestPkg);
    stealth::ensureBadTokensDecoded();
}

static int phdrSelfCb(struct dl_phdr_info *info, size_t, void *) {
    if (info->dlpi_addr != 0 && info->dlpi_name != nullptr &&
        strstr(info->dlpi_name, "kxv72q4n") != nullptr) {
        uintptr_t base = (uintptr_t) info->dlpi_addr;
        uintptr_t maxEnd = base;
        for (int i = 0; i < info->dlpi_phnum; ++i) {
            if (info->dlpi_phdr[i].p_type == PT_LOAD) {
                uintptr_t end = base + info->dlpi_phdr[i].p_vaddr +
                                info->dlpi_phdr[i].p_memsz;
                if (end > maxEnd) maxEnd = end;
            }
        }
        gBridgeBase = base;
        gBridgeEnd = maxEnd;
    }
    return 0;
}

static void resolveBridgeBounds() {
    dl_iterate_phdr(&phdrSelfCb, nullptr);
    if (gBridgeBase == 0) {
        Dl_info info{};
        if (dladdr((void *) &resolveBridgeBounds, &info) != 0) {
            gBridgeBase = (uintptr_t) info.dli_fbase;
            gBridgeEnd = gBridgeBase + 4 * 1024 * 1024;
        }
    }
}

static void resolveKernelBases() {
    char tok64[32], tok32[32], tokVdso[32];
    stealth::kTokLinker64.get(tok64);
    stealth::kTokLinker32.get(tok32);
    stealth::kTokVdso.get(tokVdso);
    int fd = rawOpen("/proc/self/maps", O_RDONLY | O_CLOEXEC);
    if (fd < 0) return;
    char buf[8192];
    ssize_t n;
    size_t carry = 0;
    char line[1024];
    size_t lineLen = 0;
    while ((n = rawRead(fd, buf + carry, sizeof(buf) - 1 - carry)) > 0) {
        n += (ssize_t) carry;
        buf[n] = '\0';
        char *p = buf;
        char *end = buf + n;
        while (p < end) {
            char *nl = (char *) memchr(p, '\n', (size_t) (end - p));
            if (nl == nullptr) break;
            *nl = '\0';
            size_t len = (size_t) (nl - p);
            if (len < sizeof(line)) {
                memcpy(line, p, len + 1);
                lineLen = len;
                if (gLinkerBase == 0 &&
                    (strstr(line, tok64) != nullptr || strstr(line, tok32) != nullptr)) {
                    gLinkerBase = strtoul(line, nullptr, 16);
                }
                if (gVdsoBase == 0 && strstr(line, tokVdso) != nullptr) {
                    gVdsoBase = strtoul(line, nullptr, 16);
                }
            }
            p = nl + 1;
        }
        carry = (size_t) (end - p);
        if (carry > 0 && carry < sizeof(buf)) memmove(buf, p, carry);
        else carry = 0;
    }
    (void) lineLen;
    rawClose(fd);
}

}

bool SyscallSpoof::isBridgeAddress(void *addr) {
    uintptr_t a = (uintptr_t) addr;
    return a >= gBridgeBase && a < gBridgeEnd;
}

void SyscallSpoof::addPathPair(const char *virtualPath, const char *realPath) {
    if (virtualPath == nullptr || realPath == nullptr) return;
    pthread_mutex_lock(&gPairLock);
    if (gPairCount < sizeof(gPairs) / sizeof(gPairs[0])) {
        PathPair &p = gPairs[gPairCount++];
        strncpy(p.virtualPath, virtualPath, sizeof(p.virtualPath) - 1);
        p.virtualPath[sizeof(p.virtualPath) - 1] = '\0';
        strncpy(p.realPath, realPath, sizeof(p.realPath) - 1);
        p.realPath[sizeof(p.realPath) - 1] = '\0';
        p.used = true;
    }
    pthread_mutex_unlock(&gPairLock);
}

namespace {

static size_t rewriteLeakedPath(char *path, size_t cap) {
    size_t len = strlen(path);
    if (len == 0) return len;
    pthread_mutex_lock(&gPairLock);
    for (size_t i = 0; i < gPairCount; ++i) {
        PathPair &pr = gPairs[i];
        size_t rl = strlen(pr.realPath);
        if (rl > 0 && strncmp(path, pr.realPath, rl) == 0) {
            size_t vl = strlen(pr.virtualPath);
            size_t tail = len - rl;
            if (vl + tail < cap) {
                memmove(path + vl, path + rl, tail + 1);
                memcpy(path, pr.virtualPath, vl);
                len = vl + tail;
            }
            break;
        }
    }
    pthread_mutex_unlock(&gPairLock);

    size_t pos = 0;
    while (pos + gHostPkgLen <= len) {
        char *hit = strstr(path + pos, gHostPkg);
        if (hit == nullptr) break;
        size_t off = (size_t) (hit - path);
        size_t tail = len - off - gHostPkgLen;
        if (off + gGuestPkgLen + tail >= cap) {
            pos = off + gHostPkgLen;
            continue;
        }
        memmove(path + off + gGuestPkgLen, path + off + gHostPkgLen, tail + 1);
        memcpy(path + off, gGuestPkg, gGuestPkgLen);
        len += gGuestPkgLen - gHostPkgLen;
        pos = off + gGuestPkgLen;
    }

    char boxdir[32];
    stealth::kTokBoxDir.get(boxdir);
    char *bd = strstr(path, boxdir);
    if (bd != nullptr) {
        char *pkg = strstr(bd, gGuestPkg);
        if (pkg != nullptr) {
            char prefix[32];
            stealth::kTokDataUserPrefix.get(prefix);
            size_t pl = strlen(prefix);
            size_t rest = strlen(pkg);
            if (pl + rest < cap) {
                memmove(path + pl, pkg, rest + 1);
                memcpy(path, prefix, pl);
                len = pl + rest;
            }
        } else {
            *bd = '\0';
            len = (size_t) (bd - path);
            if (len == 0) {
                strncpy(path, "/", cap - 1);
                len = 1;
            }
        }
    }
    return len;
}

static __attribute__((always_inline)) inline bool callerIsGuest() {
    void *ret = __builtin_return_address(0);
    return !SyscallSpoof::isBridgeAddress(ret);
}

static void setErrno(int e, int *errOut) {
    if (errOut != nullptr) *errOut = e;
    errno = e;
}

static int (*o_prctl)(int, unsigned long, unsigned long, unsigned long, unsigned long) = nullptr;
static int (*o_kill)(pid_t, int) = nullptr;
static int (*o_openat)(int, const char *, int, ...) = nullptr;
static int (*o_open)(const char *, int, ...) = nullptr;
static int (*o___open_2)(const char *, int) = nullptr;
static int (*o___openat_2)(int, const char *, int) = nullptr;
static int (*o_access)(const char *, int) = nullptr;
static int (*o_faccessat)(int, const char *, int, int) = nullptr;
static int (*o_stat)(const char *, struct stat *) = nullptr;
static int (*o_lstat)(const char *, struct stat *) = nullptr;
static int (*o_fstatat)(int, const char *, struct stat *, int) = nullptr;
static ssize_t (*o_readlink)(const char *, char *, size_t) = nullptr;
static ssize_t (*o_readlinkat)(int, const char *, char *, size_t) = nullptr;
static ssize_t (*o_getdents64)(int, void *, size_t) = nullptr;
static unsigned long (*o_getauxval)(unsigned long) = nullptr;
static int (*o_dl_iterate_phdr)(int (*)(struct dl_phdr_info *, size_t, void *), void *) = nullptr;
static int (*o_mincore)(void *, size_t, unsigned char *) = nullptr;
static FILE *(*o_fopen)(const char *, const char *) = nullptr;
static int (*o_sysprop_get)(const char *, char *) = nullptr;

static int hooked_prctl(int option, unsigned long a2, unsigned long a3,
                        unsigned long a4, unsigned long a5) {
    void *ret = __builtin_return_address(0);
    bool guest = !SyscallSpoof::isBridgeAddress(ret);
    acprobe::CallerInfo ci = acprobe::classifyCaller(ret);
    int r;
    acprobe::Verdict v;
    if (guest) {
        r = (int) syscall(SYS_prctl, option, a2, a3, a4, a5);
        v = (option == PR_GET_DUMPABLE || option == PR_SET_DUMPABLE)
            ? acprobe::Verdict::kPassThrough : acprobe::Verdict::kSpoofed;
    } else {
        r = o_prctl(option, a2, a3, a4, a5);
        v = acprobe::Verdict::kPassThrough;
    }
    if (ci.isProtection || (unsigned) option >= 0x1000) {
        acprobe::logEvent(acprobe::Cat::kPrctl, v, ci,
                          "option=0x%x a2=%lx a3=%lx r=%d", option, a2, a3, r);
    }
    return r;
}

static int hooked_kill(pid_t pid, int sig) {
    void *ret = __builtin_return_address(0);
    bool guest = !SyscallSpoof::isBridgeAddress(ret);
    acprobe::CallerInfo ci = acprobe::classifyCaller(ret);
    if (guest) {
        if (sig == 0 || pid == getpid() || pid == -1) {
            if (ci.isProtection || sig != 0) {
                acprobe::logEvent(acprobe::Cat::kKillProbe, acprobe::Verdict::kSpoofed,
                                  ci, "pid=%d sig=%d -> 0 (blocked)", pid, sig);
            }
            return 0;
        }
    }
    int r = o_kill(pid, sig);
    if (ci.isProtection) {
        acprobe::logEvent(acprobe::Cat::kKillProbe, acprobe::Verdict::kPassThrough,
                          ci, "pid=%d sig=%d -> %d", pid, sig, r);
    }
    return r;
}

static bool pathBlocked(const char *path) {
    if (path == nullptr || path[0] != '/') return false;
    return stealth::matchesBadTokens(path);
}

static int hooked_openat(int dirfd, const char *path, int flags, ...) {
    mode_t mode = 0;
    if (flags & (O_CREAT | O_TMPFILE)) {
        va_list ap;
        va_start(ap, flags);
        mode = (mode_t) va_arg(ap, int);
        va_end(ap);
    }
    if (callerIsGuest() && pathBlocked(path)) {
        setErrno(ENOENT, nullptr);
        return -1;
    }
    return o_openat(dirfd, path, flags, mode);
}

static int hooked_open(const char *path, int flags, ...) {
    mode_t mode = 0;
    if (flags & (O_CREAT | O_TMPFILE)) {
        va_list ap;
        va_start(ap, flags);
        mode = (mode_t) va_arg(ap, int);
        va_end(ap);
    }
    if (callerIsGuest() && pathBlocked(path)) {
        setErrno(ENOENT, nullptr);
        return -1;
    }
    return o_open(path, flags, mode);
}

static int hooked___open_2(const char *path, int flags) {
    if (callerIsGuest() && pathBlocked(path)) {
        setErrno(ENOENT, nullptr);
        return -1;
    }
    return o___open_2(path, flags);
}

static int hooked___openat_2(int dirfd, const char *path, int flags) {
    if (callerIsGuest() && pathBlocked(path)) {
        setErrno(ENOENT, nullptr);
        return -1;
    }
    return o___openat_2(dirfd, path, flags);
}

static int hooked_access(const char *path, int mode) {
    void *ret = __builtin_return_address(0);
    bool guest = !SyscallSpoof::isBridgeAddress(ret);
    acprobe::CallerInfo ci = acprobe::classifyCaller(ret);
    if (guest && pathBlocked(path)) {
        setErrno(ENOENT, nullptr);
        acprobe::logPath(acprobe::Cat::kFileProbe, acprobe::Verdict::kBlocked,
                         ci, path, nullptr);
        return -1;
    }
    int r = o_access(path, mode);
    if (ci.isProtection && path != nullptr && path[0] == '/') {
        acprobe::logPath(acprobe::Cat::kFileProbe, acprobe::Verdict::kPassThrough,
                         ci, path, nullptr);
    }
    return r;
}

static int hooked_faccessat(int dirfd, const char *path, int mode, int flags) {
    if (callerIsGuest() && pathBlocked(path)) {
        setErrno(ENOENT, nullptr);
        return -1;
    }
    return o_faccessat(dirfd, path, mode, flags);
}

static int hooked_stat(const char *path, struct stat *st) {
    void *ret = __builtin_return_address(0);
    bool guest = !SyscallSpoof::isBridgeAddress(ret);
    acprobe::CallerInfo ci = acprobe::classifyCaller(ret);
    if (guest && pathBlocked(path)) {
        setErrno(ENOENT, nullptr);
        acprobe::logPath(acprobe::Cat::kFileProbe, acprobe::Verdict::kBlocked,
                         ci, path, nullptr);
        return -1;
    }
    int r = o_stat(path, st);
    if (ci.isProtection && path != nullptr && path[0] == '/') {
        acprobe::logPath(acprobe::Cat::kFileProbe, acprobe::Verdict::kPassThrough,
                         ci, path, nullptr);
    }
    return r;
}

static int hooked_lstat(const char *path, struct stat *st) {
    if (callerIsGuest() && pathBlocked(path)) {
        setErrno(ENOENT, nullptr);
        return -1;
    }
    return o_lstat(path, st);
}

static int hooked_fstatat(int dirfd, const char *path, struct stat *st, int flags) {
    if (callerIsGuest() && path[0] != '\0' && pathBlocked(path)) {
        setErrno(ENOENT, nullptr);
        return -1;
    }
    return o_fstatat(dirfd, path, st, flags);
}

static ssize_t hooked_readlink(const char *path, char *buf, size_t size) {
    void *ret = __builtin_return_address(0);
    bool guest = !SyscallSpoof::isBridgeAddress(ret);
    acprobe::CallerInfo ci = acprobe::classifyCaller(ret);
    ssize_t n = o_readlink(path, buf, size);
    if (n > 0) {
        buf[n] = '\0';
        if (ci.isProtection) {
            acprobe::logPath(acprobe::Cat::kReadlink, acprobe::Verdict::kPassThrough,
                             ci, path, buf);
        }
        if (guest) {
            char tokFd[32];
            stealth::kTokProcSelfFd.get(tokFd);
            if (strncmp(path, tokFd, stealth::kTokProcSelfFd.len) == 0) {
                char before[1024];
                strncpy(before, buf, sizeof(before) - 1);
                before[sizeof(before) - 1] = '\0';
                ssize_t nl = (ssize_t) rewriteLeakedPath(buf, size);
                if (nl > 0 && buf[0] == '/') {
                    if ((size_t) nl != strlen(before) || strcmp(buf, before) != 0) {
                        if (ci.isProtection || strstr(before, gHostPkg) != nullptr) {
                            acprobe::logPath(acprobe::Cat::kFdScan,
                                             acprobe::Verdict::kRewritten,
                                             ci, before, buf);
                        }
                        n = nl;
                    }
                }
            }
        }
    }
    return n;
}

static ssize_t hooked_readlinkat(int dirfd, const char *path, char *buf, size_t size) {
    ssize_t n = o_readlinkat(dirfd, path, buf, size);
    if (n > 0 && callerIsGuest()) {
        buf[n] = '\0';
        char tokFd[32];
        stealth::kTokProcSelfFd.get(tokFd);
        bool fdLink = strncmp(path, tokFd, stealth::kTokProcSelfFd.len) == 0;
        if (!fdLink && path[0] >= '0' && path[0] <= '9') {
            bool digits = true;
            for (const char *p = path; *p; ++p) {
                if (*p < '0' || *p > '9') { digits = false; break; }
            }
            fdLink = digits;
        }
        if (fdLink) {
            ssize_t nl = (ssize_t) rewriteLeakedPath(buf, size);
            if (nl > 0 && buf[0] == '/') n = nl;
        }
    }
    return n;
}

struct linux_dirent64 {
    uint64_t d_ino;
    int64_t d_off;
    unsigned short d_reclen;
    unsigned char d_type;
    char d_name[];
};

static bool numericName(const char *name) {
    if (name[0] == '\0') return false;
    for (const char *p = name; *p; ++p) {
        if (*p < '0' || *p > '9') return false;
    }
    return true;
}

static ssize_t hooked_getdents64(int fd, void *buf, size_t count) {
    ssize_t n = o_getdents64(fd, buf, count);
    if (n <= 0 || !callerIsGuest()) return n;
    char fdPath[64];
    char dirPath[1024];
    snprintf(fdPath, sizeof(fdPath), "/proc/self/fd/%d", fd);
    ssize_t dl = rawReadlinkat(AT_FDCWD, fdPath, dirPath, sizeof(dirPath) - 1);
    if (dl <= 0) return n;
    dirPath[dl] = '\0';

    char tokUser[32], tokData[32], tokFd[32];
    stealth::kTokDataUser.get(tokUser);
    stealth::kTokDataData.get(tokData);
    stealth::kTokProcSelfFd.get(tokFd);
    bool isUserRoot = strcmp(dirPath, tokUser) == 0;
    bool isDataRoot = strcmp(dirPath, tokData) == 0;
    bool isUser0 = strcmp(dirPath, "/data/user/0") == 0;
    bool isFdDir = strcmp(dirPath, tokFd) == 0;
    bool isAndroidData = strcmp(dirPath, "/sdcard/Android/data") == 0 ||
                         strcmp(dirPath, "/storage/emulated/0/Android/data") == 0;

    acprobe::CallerInfo ci = acprobe::classifyCaller(__builtin_return_address(0));

    char *out = (char *) buf;
    size_t outLen = 0;
    size_t i = 0;
    while (i < (size_t) n) {
        auto *ent = (linux_dirent64 *) ((char *) buf + i);
        unsigned short reclen = ent->d_reclen;
        if (reclen == 0 || i + reclen > (size_t) n) break;
        bool drop = stealth::matchesBadTokens(ent->d_name);
        if (!drop && isUserRoot && numericName(ent->d_name) && strcmp(ent->d_name, "0") != 0) {
            drop = true;
        }
        if (!drop && (isDataRoot || isUser0 || isAndroidData) &&
            strstr(ent->d_name, gHostPkg) != nullptr) {
            drop = true;
        }
        if (!drop && isFdDir && ent->d_type == 0xA && numericName(ent->d_name)) {
            char linkPath[64];
            char target[1024];
            snprintf(linkPath, sizeof(linkPath), "/proc/self/fd/%s", ent->d_name);
            ssize_t tl = rawReadlinkat(AT_FDCWD, linkPath, target, sizeof(target) - 1);
            if (tl > 0) {
                target[tl] = '\0';
                if (stealth::matchesBadTokens(target)) drop = true;
            }
        }
        if (drop) {
            acprobe::logEvent(acprobe::Cat::kFdScan, acprobe::Verdict::kFiltered,
                              ci, "dir=[%s] dropped=[%s]", dirPath, ent->d_name);
        } else {
            if ((char *) ent != out + outLen) {
                memmove(out + outLen, ent, reclen);
            }
            outLen += reclen;
        }
        i += reclen;
    }
    if (outLen == 0) {
        return o_getdents64(fd, buf, count);
    }
    return (ssize_t) outLen;
}

static unsigned long hooked_getauxval(unsigned long type) {
    void *ret = __builtin_return_address(0);
    bool guest = !SyscallSpoof::isBridgeAddress(ret);
    unsigned long v = o_getauxval(type);
    acprobe::CallerInfo ci = acprobe::classifyCaller(ret);
    acprobe::Verdict verdict = acprobe::Verdict::kPassThrough;
    if (guest) {
        if (type == AT_BASE && v == 0 && gLinkerBase != 0) {
            v = gLinkerBase;
            verdict = acprobe::Verdict::kSpoofed;
        }
        if (type == AT_SYSINFO_EHDR && v == 0 && gVdsoBase != 0) {
            v = gVdsoBase;
            verdict = acprobe::Verdict::kSpoofed;
        }
    }
    if (ci.isProtection || (guest && type >= 6 && type <= 9)) {
        acprobe::logEvent(acprobe::Cat::kAuxv, verdict, ci,
                          "type=%lu -> 0x%lx", type, v);
    }
    return v;
}

struct IterateCtx {
    int (*cb)(struct dl_phdr_info *, size_t, void *);
    void *data;
};

static thread_local IterateCtx *gIterCtx = nullptr;

static bool moduleNameHidden(const char *name) {
    if (name == nullptr || name[0] == '\0') return false;
    if (stealth::matchesBadTokens(name)) return true;
    if (strstr(name, gHostPkg) != nullptr) return true;
    char pine[32];
    stealth::kTokPine.get(pine);
    if (strstr(name, pine) != nullptr) return true;
    return false;
}

static int iterateTrampoline(struct dl_phdr_info *info, size_t size, void *data) {
    IterateCtx *ctx = gIterCtx;
    if (ctx == nullptr) return 0;
    if (moduleNameHidden(info->dlpi_name)) return 0;
    return ctx->cb(info, size, ctx->data);
}

static int hooked_dl_iterate_phdr(int (*cb)(struct dl_phdr_info *, size_t, void *), void *data) {
    void *ret = __builtin_return_address(0);
    bool guest = !SyscallSpoof::isBridgeAddress(ret);
    if (!guest) return o_dl_iterate_phdr(cb, data);
    acprobe::CallerInfo ci = acprobe::classifyCaller(ret);
    if (ci.isProtection) {
        acprobe::logEvent(acprobe::Cat::kModuleScan, acprobe::Verdict::kFiltered,
                          ci, "iterate_phdr cb=%p hidden=bridge+pine", (void *) cb);
    }
    IterateCtx ctx{cb, data};
    IterateCtx *prev = gIterCtx;
    gIterCtx = &ctx;
    int r = o_dl_iterate_phdr(&iterateTrampoline, data);
    gIterCtx = prev;
    return r;
}

static int hooked_mincore(void *addr, size_t length, unsigned char *vec) {
    void *ret = __builtin_return_address(0);
    bool guest = !SyscallSpoof::isBridgeAddress(ret);
    int r = o_mincore(addr, length, vec);
    acprobe::CallerInfo ci = acprobe::classifyCaller(ret);
    acprobe::Verdict verdict = acprobe::Verdict::kPassThrough;
    if (guest && r == 0 && vec != nullptr) {
        long page = sysconf(_SC_PAGESIZE);
        if (page <= 0) page = 4096;
        size_t pages = (length + (size_t) page - 1) / (size_t) page;
        memset(vec, 1, pages);
        verdict = acprobe::Verdict::kSpoofed;
    }
    if (ci.isProtection) {
        acprobe::logAddr(acprobe::Cat::kMincore, verdict, ci, addr, (long) length);
    }
    return r;
}

static FILE *hooked_fopen(const char *path, const char *mode) {
    if (callerIsGuest() && pathBlocked(path)) {
        setErrno(ENOENT, nullptr);
        return nullptr;
    }
    return o_fopen(path, mode);
}

static void sanitizePropValue(const char *name, char *value) {
    if (value == nullptr) return;
    char goldfish[32], ranchu[32];
    stealth::decodeBlob(stealth::gBadTokens[13].blob.data, stealth::gBadTokens[13].blob.len, goldfish);
    stealth::decodeBlob(stealth::gBadTokens[14].blob.data, stealth::gBadTokens[14].blob.len, ranchu);
    size_t vl = strlen(value);
    if (stealth::containsToken(value, vl, goldfish, strlen(goldfish)) ||
        stealth::containsToken(value, vl, ranchu, strlen(ranchu))) {
        strcpy(value, "qcom");
        return;
    }
    if (strcmp(name, "ro.debuggable") == 0 && strcmp(value, "1") == 0) {
        strcpy(value, "0");
        return;
    }
    if (strcmp(name, "ro.kernel.qemu") == 0 && value[0] != '0') {
        strcpy(value, "0");
        return;
    }
    if (strcmp(name, "init.svc.adbd") == 0) {
        strcpy(value, "stopped");
        return;
    }
    if (strcmp(name, "service.adb.root") == 0) {
        strcpy(value, "0");
        return;
    }
    if (strcmp(name, "sys.oem_unlock_allowed") == 0) {
        strcpy(value, "0");
        return;
    }
}

static int hooked_sysprop_get(const char *name, char *value) {
    void *ret = __builtin_return_address(0);
    bool guest = !SyscallSpoof::isBridgeAddress(ret);
    acprobe::CallerInfo ci = acprobe::classifyCaller(ret);
    char before[128];
    int r = o_sysprop_get(name, value);
    if (r > 0 && name != nullptr) {
        strncpy(before, value, sizeof(before) - 1);
        before[sizeof(before) - 1] = '\0';
        if (guest) {
            sanitizePropValue(name, value);
            r = (int) strlen(value);
        }
        if (ci.isProtection) {
            acprobe::Verdict v = strcmp(before, value) != 0
                ? acprobe::Verdict::kSpoofed : acprobe::Verdict::kPassThrough;
            acprobe::logPath(acprobe::Cat::kProp, v, ci, name, value);
        }
    }
    return r;
}

struct HookSpec {
    const char *sym;
    void *replacement;
    void **origSlot;
    bool required;
};

#define HOOK_ENTRY(sym, fn) { sym, (void *) &fn, (void **) &o_##fn, false }

static bool installOne(void *addr, void *replacement, void **origSlot, const char *name) {
    if (addr == nullptr) return false;
    if (DobbyHook(addr, replacement, origSlot) == 0) {
        IntegrityGuard::add(addr, replacement, origSlot);
        return true;
    }
    ALOGD("SyscallSpoof: failed to hook %s@%p", name, addr);
    return false;
}

}

void SyscallSpoof::install() {
    if (gInstalled) return;
    gInstalled = true;
    initStrings();
    acprobe::init();
    resolveBridgeBounds();
    resolveKernelBases();
    IntegrityGuard::start();

    installOne(dlsym(RTLD_DEFAULT, "prctl"), (void *) &hooked_prctl, (void **) &o_prctl, "prctl");
    installOne(dlsym(RTLD_DEFAULT, "kill"), (void *) &hooked_kill, (void **) &o_kill, "kill");
    installOne(dlsym(RTLD_DEFAULT, "openat"), (void *) &hooked_openat, (void **) &o_openat, "openat");
    installOne(dlsym(RTLD_DEFAULT, "open"), (void *) &hooked_open, (void **) &o_open, "open");
    installOne(dlsym(RTLD_DEFAULT, "__open_2"), (void *) &hooked___open_2, (void **) &o___open_2, "__open_2");
    installOne(dlsym(RTLD_DEFAULT, "__openat_2"), (void *) &hooked___openat_2, (void **) &o___openat_2, "__openat_2");
    installOne(dlsym(RTLD_DEFAULT, "access"), (void *) &hooked_access, (void **) &o_access, "access");
    installOne(dlsym(RTLD_DEFAULT, "faccessat"), (void *) &hooked_faccessat, (void **) &o_faccessat, "faccessat");
    installOne(dlsym(RTLD_DEFAULT, "stat"), (void *) &hooked_stat, (void **) &o_stat, "stat");
    installOne(dlsym(RTLD_DEFAULT, "lstat"), (void *) &hooked_lstat, (void **) &o_lstat, "lstat");
    installOne(dlsym(RTLD_DEFAULT, "fstatat"), (void *) &hooked_fstatat, (void **) &o_fstatat, "fstatat");
    installOne(dlsym(RTLD_DEFAULT, "readlink"), (void *) &hooked_readlink, (void **) &o_readlink, "readlink");
    installOne(dlsym(RTLD_DEFAULT, "readlinkat"), (void *) &hooked_readlinkat, (void **) &o_readlinkat, "readlinkat");
    installOne(dlsym(RTLD_DEFAULT, "getdents64"), (void *) &hooked_getdents64, (void **) &o_getdents64, "getdents64");
    installOne(dlsym(RTLD_DEFAULT, "getauxval"), (void *) &hooked_getauxval, (void **) &o_getauxval, "getauxval");
    installOne(dlsym(RTLD_DEFAULT, "dl_iterate_phdr"), (void *) &hooked_dl_iterate_phdr, (void **) &o_dl_iterate_phdr, "dl_iterate_phdr");
    installOne(dlsym(RTLD_DEFAULT, "mincore"), (void *) &hooked_mincore, (void **) &o_mincore, "mincore");
    installOne(dlsym(RTLD_DEFAULT, "fopen"), (void *) &hooked_fopen, (void **) &o_fopen, "fopen");
    installOne(dlsym(RTLD_DEFAULT, "__system_property_get"), (void *) &hooked_sysprop_get, (void **) &o_sysprop_get, "__system_property_get");

    ALOGD("SyscallSpoof: installed (bridge=%p..%p linker=%lx vdso=%lx)",
          (void *) gBridgeBase, (void *) gBridgeEnd, gLinkerBase, gVdsoBase);
}

void SyscallSpoof::installLate() {
    if (!gInstalled) {
        install();
        return;
    }
    resolveKernelBases();
}
