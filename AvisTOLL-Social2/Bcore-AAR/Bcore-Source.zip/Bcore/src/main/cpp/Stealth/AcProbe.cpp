#include "AcProbe.h"

#include <dlfcn.h>
#include <fcntl.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/syscall.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#include "StealthStrings.h"
#include "SyscallSpoof.h"
#include "../Log.h"

namespace acprobe {

namespace {

static bool gEnabled = true;
static int gLogFd = -1;
static pthread_mutex_t gLogLock = PTHREAD_MUTEX_INITIALIZER;

struct ModuleRange {
    char name[128];
    uintptr_t base;
    uintptr_t end;
};

static ModuleRange gModules[256];
static size_t gModuleCount = 0;
static time_t gModuleScanAt = 0;
static pthread_mutex_t gModuleLock = PTHREAD_MUTEX_INITIALIZER;

static const char *kProtNames[] = {
    "libloader",
    "libtersafe",
    "libtprt",
    "libSecShell",
    "libantibot",
    "libsgmain",
    "libsgsecuritybody",
    "libxguardian",
};

static int rawOpen(const char *p, int fl) {
    return (int) syscall(SYS_openat, AT_FDCWD, p, fl, 0644);
}

static ssize_t rawWrite(int fd, const void *b, size_t n) {
    return (ssize_t) syscall(SYS_write, fd, b, n);
}

static ssize_t rawRead(int fd, void *b, size_t n) {
    return (ssize_t) syscall(SYS_read, fd, b, n);
}

static void rawClose(int fd) {
    syscall(SYS_close, fd);
}

static bool isProtectionName(const char *name) {
    if (name == nullptr) return false;
    for (const char *p : kProtNames) {
        if (strstr(name, p) != nullptr) return true;
    }
    return false;
}

static void rescanModulesLocked() {
    int fd = rawOpen("/proc/self/maps", O_RDONLY | O_CLOEXEC);
    if (fd < 0) return;
    gModuleCount = 0;
    char buf[16384];
    ssize_t n;
    char line[1024];
    size_t carry = 0;
    while ((n = rawRead(fd, buf + carry, sizeof(buf) - 1 - carry)) > 0) {
        n += (ssize_t) carry;
        buf[n] = '\0';
        char *p = buf;
        char *end = buf + n;
        while (p < end) {
            char *nl = (char *) memchr(p, '\n', (size_t) (end - p));
            if (nl == nullptr) break;
            *nl = '\0';
            char *nameField = strrchr(p, ' ');
            if (nameField != nullptr && nameField[1] == '/' && gModuleCount < 256) {
                const char *path = nameField + 1;
                if (strchr(p, 'x') != nullptr || strstr(p, "r-xp") != nullptr) {
                    uintptr_t lo = strtoul(p, nullptr, 16);
                    char *dash = strchr(p, '-');
                    uintptr_t hi = dash != nullptr ? strtoul(dash + 1, nullptr, 16) : lo;
                    bool found = false;
                    for (size_t i = 0; i < gModuleCount; ++i) {
                        if (strcmp(gModules[i].name, path) == 0) {
                            if (lo < gModules[i].base) gModules[i].base = lo;
                            if (hi > gModules[i].end) gModules[i].end = hi;
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        ModuleRange &m = gModules[gModuleCount++];
                        strncpy(m.name, path, sizeof(m.name) - 1);
                        m.name[sizeof(m.name) - 1] = '\0';
                        m.base = lo;
                        m.end = hi;
                    }
                }
            }
            p = nl + 1;
        }
        carry = (size_t) (end - p);
        if (carry > 0 && carry < sizeof(buf)) memmove(buf, p, carry);
        else carry = 0;
    }
    rawClose(fd);
    gModuleScanAt = time(nullptr);
}

static void refreshModules() {
    time_t now = time(nullptr);
    if (now - gModuleScanAt < 10) return;
    pthread_mutex_lock(&gModuleLock);
    if (now - gModuleScanAt >= 10) rescanModulesLocked();
    pthread_mutex_unlock(&gModuleLock);
}

static const char *baseName(const char *p) {
    const char *s = strrchr(p, '/');
    return s != nullptr ? s + 1 : p;
}

static void openLogFile() {
    if (gLogFd >= 0) return;
    char path[256];
    const char *candidates[] = {
        "/sdcard/Download/ac_probe.log",
        "/sdcard/Android/data/com.avis.tool/files/ac_probe.log",
        "/data/data/com.avis.tool/files/ac_probe.log",
    };
    for (const char *cand : candidates) {
        int fd = rawOpen(cand, O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC);
        if (fd >= 0) {
            gLogFd = fd;
            return;
        }
    }
}

static void writeLogLine(const char *line, size_t len) {
    if (gLogFd < 0) openLogFile();
    if (gLogFd >= 0) rawWrite(gLogFd, line, len);
    ALOGD("ACP %s", line);
}

}

void init() {
    refreshModules();
    openLogFile();
    char banner[128];
    int n = snprintf(banner, sizeof(banner),
                     "==== acprobe session start pid=%d ====\n", getpid());
    writeLogLine(banner, (size_t) n);
}

void setEnabled(bool on) { gEnabled = on; }
bool enabled() { return gEnabled; }

const char *catName(Cat c) {
    switch (c) {
        case Cat::kPrctl: return "PRCTL";
        case Cat::kTiming: return "TIMING";
        case Cat::kFdScan: return "FDSCAN";
        case Cat::kReadlink: return "READLINK";
        case Cat::kFileProbe: return "FILEPROBE";
        case Cat::kKillProbe: return "KILL";
        case Cat::kModuleScan: return "MODSCAN";
        case Cat::kAuxv: return "AUXV";
        case Cat::kMincore: return "MINCORE";
        case Cat::kProp: return "PROP";
        case Cat::kUname: return "UNAME";
        case Cat::kStatfs: return "STATFS";
        case Cat::kPkgScan: return "PKGSCAN";
        case Cat::kProcRead: return "PROCREAD";
        case Cat::kThreadSpawn: return "THREAD";
        case Cat::kCodeRestore: return "CODERESTORE";
        case Cat::kHookCheck: return "HOOKCHECK";
        default: return "UNKNOWN";
    }
}

const char *verdictName(Verdict v) {
    switch (v) {
        case Verdict::kPassThrough: return "PASS";
        case Verdict::kSpoofed: return "SPOOF";
        case Verdict::kBlocked: return "BLOCK";
        case Verdict::kRewritten: return "REWRITE";
        case Verdict::kFiltered: return "FILTER";
        default: return "?";
    }
}

CallerInfo classifyCaller(void *ret) {
    CallerInfo ci{};
    ci.ret = ret;
    refreshModules();
    uintptr_t a = (uintptr_t) ret;
    pthread_mutex_lock(&gModuleLock);
    for (size_t i = 0; i < gModuleCount; ++i) {
        ModuleRange &m = gModules[i];
        if (a >= m.base && a < m.end) {
            strncpy(ci.module, baseName(m.name), sizeof(ci.module) - 1);
            ci.moduleBase = m.base;
            ci.offset = a - m.base;
            ci.isProtection = isProtectionName(ci.module);
            pthread_mutex_unlock(&gModuleLock);
            ci.isBridge = SyscallSpoof::isBridgeAddress(ret);
            char guest[64];
            stealth::kTokGuestPkg.get(guest);
            ci.isGuestGame = strstr(m.name, guest) != nullptr;
            return ci;
        }
    }
    pthread_mutex_unlock(&gModuleLock);
    strcpy(ci.module, "?");
    ci.isBridge = SyscallSpoof::isBridgeAddress(ret);
    return ci;
}

bool pathFromProtectionModule(const char *path) {
    return path != nullptr && isProtectionName(path);
}

void noteProtectionModule(const char *name, uintptr_t base, uintptr_t end) {
    if (!isProtectionName(name)) return;
    pthread_mutex_lock(&gModuleLock);
    bool found = false;
    for (size_t i = 0; i < gModuleCount; ++i) {
        if (strcmp(gModules[i].name, name) == 0) { found = true; break; }
    }
    if (!found && gModuleCount < 256) {
        ModuleRange &m = gModules[gModuleCount++];
        strncpy(m.name, name, sizeof(m.name) - 1);
        m.name[sizeof(m.name) - 1] = '\0';
        m.base = base;
        m.end = end;
    }
    pthread_mutex_unlock(&gModuleLock);
}

void logEvent(Cat cat, Verdict verdict, const CallerInfo &caller,
              const char *detail, ...) {
    if (!gEnabled) return;
    char detailBuf[512];
    va_list ap;
    va_start(ap, detail);
    vsnprintf(detailBuf, sizeof(detailBuf), detail, ap);
    va_end(ap);
    char line[1024];
    struct timespec ts{};
    clock_gettime(CLOCK_REALTIME, &ts);
    int n = snprintf(line, sizeof(line),
                     "[%lld.%03ld] %-11s %-7s caller=%s+0x%lx %s%s%s | %s\n",
                     (long long) ts.tv_sec, ts.tv_nsec / 1000000,
                     catName(cat), verdictName(verdict),
                     caller.module, (unsigned long) caller.offset,
                     caller.isProtection ? "[PROT] " : "",
                     caller.isBridge ? "[BRIDGE] " : "",
                     caller.isGuestGame ? "[GAME] " : "",
                     detailBuf);
    if (n > 0) {
        pthread_mutex_lock(&gLogLock);
        writeLogLine(line, (size_t) n);
        pthread_mutex_unlock(&gLogLock);
    }
}

void logPath(Cat cat, Verdict verdict, const CallerInfo &caller,
             const char *pathIn, const char *pathOut) {
    if (pathOut != nullptr && strcmp(pathIn, pathOut) != 0) {
        logEvent(cat, verdict, caller, "path=[%s] -> [%s]", pathIn, pathOut);
    } else {
        logEvent(cat, verdict, caller, "path=[%s]", pathIn);
    }
}

void logAddr(Cat cat, Verdict verdict, const CallerInfo &caller,
             void *addr, long aux) {
    logEvent(cat, verdict, caller, "addr=%p aux=0x%lx", addr, aux);
}

}
