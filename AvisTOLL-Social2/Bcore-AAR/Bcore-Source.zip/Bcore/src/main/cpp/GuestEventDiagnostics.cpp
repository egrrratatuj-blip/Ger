#include "GuestEventDiagnostics.h"
#include "GuestFilesystemDiagnostics.h"
#include "Log.h"
#include <cstring>

namespace guest_event_diagnostics {
namespace {
constexpr uintptr_t kCountOffset = 0xf7bc90;
constexpr uintptr_t kSlotsOffset = 0xf7b970;
constexpr uint32_t kMaxRecords = 100;
constexpr uint32_t kMaxArguments = 32;
struct Header { uint64_t tag; uint32_t count; uint32_t reserved; };
static_assert(sizeof(Header) == 16, "Unexpected record header layout");

uintptr_t pointer(uint64_t value) {
#if defined(__aarch64__)
    value &= UINT64_C(0x00ffffffffffffff);
#endif
    return static_cast<uintptr_t>(value);
}
bool isTag(const std::string &text) {
    if (text.size() != 32 && text.size() != 33) return false;
    for (size_t i = 0; i < text.size(); ++i) {
        const char ch = text[i];
        if (i == 16) { if (ch != '_') return false; }
        else if (!((ch >= '0' && ch <= '9') || (ch >= 'a' && ch <= 'f'))) return false;
    }
    return true;
}
}

bool matchesDispatchLayout(uintptr_t base, MemoryReader reader) {
    if (reader == nullptr || base > UINTPTR_MAX - kCountOffset - 8) return false;
    struct Signature { uintptr_t offset; size_t size; unsigned char bytes[44]; };
    static const Signature signatures[] = {
        {0xa0efec,20,{0x68,0x2b,0x00,0xb0,0x08,0x41,0x32,0x91,0x0a,0xfd,0xdf,0x88,0x08,0x11,0x00,0x91,0x08,0xfd,0xdf,0x88}},
        {0xa0f080,32,{0xfa,0x03,0x08,0xaa,0x28,0x0f,0x08,0x8b,0x08,0xfd,0xdf,0xc8,0xc8,0x02,0x00,0xb4,0x00,0x01,0x40,0xf9,0x02,0x09,0x40,0xb9,0x01,0x41,0x00,0x91,0xe4,0xe6,0xfa,0x97}},
        {0xa0f2d8,12,{0x68,0x2b,0x00,0x90,0x08,0x41,0x32,0x91,0x20,0x01,0x1f,0xd6}},
        {0xa0f4f0,36,{0x68,0x2b,0x00,0x90,0x08,0xc1,0x25,0x91,0xca,0x05,0x00,0x51,0x9f,0x03,0x00,0x71,0xe9,0x43,0x0a,0x91,0x08,0xcd,0x3c,0x8b,0x4a,0xb5,0x8e,0x1a,0x09,0xfd,0x9f,0xc8,0xea,0x6f,0x01,0xb9}},
        {0xa0f618,44,{0xe9,0x0f,0x40,0xf9,0xe8,0x43,0x0a,0x91,0xca,0x11,0x00,0x11,0x9f,0x02,0x00,0x71,0xe9,0x4b,0x01,0xf9,0xc9,0x21,0x00,0x51,0x08,0x01,0x7d,0xb2,0xe8,0x33,0x00,0xf9,0x28,0xc1,0x8a,0x1a,0xff,0x9b,0x02,0xb9,0xe8,0x6f,0x01,0xb9}}
    };
    for (const auto &signature : signatures) {
        unsigned char bytes[44];
        if (!reader(base + signature.offset, bytes, signature.size)
                || memcmp(bytes, signature.bytes, signature.size) != 0) return false;
    }
    return true;
}

Snapshot readSnapshot(uintptr_t base, MemoryReader reader) {
    Snapshot result;
    if (!matchesDispatchLayout(base, reader)) {
        result.status = "fingerprint-mismatch-or-unreadable";
        return result;
    }
    uint32_t before[2], after[2];
    if (!reader(base + kCountOffset, before, sizeof(before))) {
        result.status = "counter-unreadable";
        return result;
    }
    result.countBefore = before[0]; result.processedBefore = before[1];
    if (before[0] > kMaxRecords || before[1] > kMaxRecords) {
        result.status = "counter-out-of-range";
        return result;
    }
    for (uint32_t i = 0; i < before[0]; ++i) {
        uint64_t slot = 0, slotAgain = 0;
        const uintptr_t slotAddress = base + kSlotsOffset + i * sizeof(slot);
        Header first{}, last{};
        if (!reader(slotAddress, &slot, sizeof(slot)) || pointer(slot) == 0
                || !reader(pointer(slot), &first, sizeof(first))) {
            ++result.unreadable; continue;
        }
        const uintptr_t tag = pointer(first.tag);
        const uintptr_t address = pointer(slot);
        if (first.count > kMaxArguments || address > UINTPTR_MAX - 16 - 8 * kMaxArguments
                || tag < base + 0x8c000 || tag >= base + 0xcd4000) {
            ++result.invalid; continue;
        }
        Record entry;
        entry.index = i; entry.tagRva = tag - base; entry.argumentCount = first.count;
        if (!guest_fs_diagnostics::readCString(tag, 34, entry.tag, reader) || !isTag(entry.tag)) {
            ++result.invalid; continue;
        }
        // Read only the virtual-space field and the exact second tag observed
        // in the supplied device log. Other event arguments remain uninterpreted.
        for (uint32_t j = 0; j + 1 < first.count; j += 2) {
            uint64_t pair[2];
            if (!reader(address + 16 + j * sizeof(uint64_t), pair, sizeof(pair))) break;
            std::string key;
            if (!guest_fs_diagnostics::readCString(pointer(pair[0]), 64, key, reader)) continue;
            if (key == "virtualSpaceApp") {
                entry.virtualSpaceField = true;
                entry.valueAvailable = guest_fs_diagnostics::readCString(pointer(pair[1]), 256,
                        entry.virtualSpaceValue, reader);
            } else if (key == "data" && entry.tagRva == 0x6dfd44
                    && entry.tag == "5d0c5b352c22a37e_1dbb72e53098378") {
                entry.dataField = true;
                entry.dataAvailable = guest_fs_diagnostics::readCString(pointer(pair[1]), 256,
                        entry.dataValue, reader);
            } else continue;
            break;
        }
        if (!reader(pointer(slot), &last, sizeof(last))
                || !reader(slotAddress, &slotAgain, sizeof(slotAgain))) {
            ++result.unreadable; continue;
        }
        if (first.tag != last.tag || first.count != last.count || slot != slotAgain) {
            ++result.unstable; continue;
        }
        result.records.push_back(entry);
    }
    if (!reader(base + kCountOffset, after, sizeof(after))) {
        result.status = "counter-reread-unavailable";
        return result;
    }
    result.countAfter = after[0]; result.processedAfter = after[1];
    result.status = after[0] > kMaxRecords || after[1] > kMaxRecords ? "counter-changed-out-of-range"
            : (before[0] != after[0] || before[1] != after[1] ? "changed-during-read" : "ok");
    return result;
}

void logSnapshot(uintptr_t base) {
    const Snapshot value = readSnapshot(base, guest_fs_diagnostics::readMemory);
    ALOGD("AvisNativeEvent: snapshot=v1 status=%s count=%u/%u processed=%u/%u records=%zu unreadable=%u invalid=%u unstable=%u",
            value.status.c_str(), value.countBefore, value.countAfter,
            value.processedBefore, value.processedAfter, value.records.size(),
            value.unreadable, value.invalid, value.unstable);
    for (const auto &entry : value.records) {
        ALOGD("AvisNativeEvent: record=%u tag=%s tagRva=0x%llx argc=%u virtualSpaceField=%d valueAvailable=%d value=%s",
                entry.index, entry.tag.c_str(), static_cast<unsigned long long>(entry.tagRva),
                entry.argumentCount, entry.virtualSpaceField, entry.valueAvailable,
                entry.virtualSpaceValue.c_str());
        if (entry.dataField) {
            ALOGD("AvisNativeEvent: recordData=%u tag=%s available=%d data=%s",
                    entry.index, entry.tag.c_str(), entry.dataAvailable, entry.dataValue.c_str());
        }
    }
}
}
