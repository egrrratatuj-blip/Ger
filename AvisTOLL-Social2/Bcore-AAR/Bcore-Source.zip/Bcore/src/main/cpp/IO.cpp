//
// Created by Milk on 4/10/21.
//

#include "IO.h"
#include <stdint.h>
#include "Log.h"
#include "Stealth/SyscallSpoof.h"

jmethodID getAbsolutePathMethodId;

list<IO::RelocateInfo> relocate_rule;

char *replace(const char *str, const char *src, const char *dst) {
    if (str == nullptr || src == nullptr || dst == nullptr) return nullptr;
    const size_t inputLen = strlen(str);
    const size_t sourceLen = strlen(src);
    const size_t targetLen = strlen(dst);
    size_t count = 0;
    if (sourceLen != 0) {
        for (const char *pos = str; (pos = strstr(pos, src)) != nullptr; pos += sourceLen)
            ++count;
    }
    size_t resultLen = inputLen;
    if (targetLen > sourceLen) {
        const size_t growth = targetLen - sourceLen;
        if (count > (SIZE_MAX - inputLen - 1) / growth) return nullptr;
        resultLen += count * growth;
    } else {
        resultLen -= count * (sourceLen - targetLen);
    }
    char *result = static_cast<char *>(malloc(resultLen + 1));
    if (result == nullptr) return nullptr;
    char *write = result;
    const char *left = str;
    if (sourceLen != 0) {
        const char *right;
        while ((right = strstr(left, src)) != nullptr) {
            const size_t prefixLen = static_cast<size_t>(right - left);
            memcpy(write, left, prefixLen);
            write += prefixLen;
            memcpy(write, dst, targetLen);
            write += targetLen;
            left = right + sourceLen;
        }
    }
    memcpy(write, left, strlen(left) + 1);
    return result;
}

const char *IO::redirectPath(const char *__path) {
    if (__path == nullptr) return nullptr;
    list<IO::RelocateInfo>::iterator iterator;
    for (iterator = relocate_rule.begin(); iterator != relocate_rule.end(); ++iterator) {
        IO::RelocateInfo info = *iterator;
        if (strstr(__path, info.targetPath) && !strstr(__path, "/blackbox/")) {
            char *ret = replace(__path, info.targetPath, info.relocatePath);
            // ALOGD("redirectPath %s  => %s", __path, ret);
            return ret != nullptr ? ret : __path;
        }
    }
    return __path;
}

jstring IO::redirectPath(JNIEnv *env, jstring path) {
//    const char * pathC = env->GetStringUTFChars(path, JNI_FALSE);
//    const char *redirect = redirectPath(pathC);
//    env->ReleaseStringUTFChars(path, pathC);
//    return env->NewStringUTF(redirect);
    return BoxCore::redirectPathString(env, path);
}

jobject IO::redirectPath(JNIEnv *env, jobject path) {
//    auto pathStr =
//            reinterpret_cast<jstring>(env->CallObjectMethod(path, getAbsolutePathMethodId));
//    jstring redirect = redirectPath(env, pathStr);
//    jobject file = env->NewObject(fileClazz, fileNew, redirect);
//    env->DeleteLocalRef(pathStr);
//    env->DeleteLocalRef(redirect);
    return BoxCore::redirectPathFile(env, path);
}

void IO::addRule(const char *targetPath, const char *relocatePath) {
    IO::RelocateInfo info{};
    info.targetPath = targetPath;
    info.relocatePath = relocatePath;
    relocate_rule.push_back(info);
    SyscallSpoof::addPathPair(targetPath, relocatePath);
}

void IO::init(JNIEnv *env) {
    jclass tmpFile = env->FindClass("java/io/File");
    getAbsolutePathMethodId = env->GetMethodID(tmpFile, "getAbsolutePath", "()Ljava/lang/String;");
}
