#include "GuestFilesystemDiagnostics.h"
#include "GuestEventDiagnostics.h"
#include "AtomicGuestPath.h"
#include "Log.h"

#include <algorithm>
#include <cerrno>
#include <cstring>
#include <fcntl.h>
#include <link.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>

namespace guest_fs_diagnostics {

bool readMemory(uintptr_t address, void *output, size_t size) {
    if (address == 0 || output == nullptr || size == 0 || size > SIZE_MAX - address)
        return false;
#if defined(__aarch64__)
    address &= UINT64_C(0x00ffffffffffffff);
#endif
    if (address > static_cast<uintptr_t>(INT64_MAX)
            || size > static_cast<uintptr_t>(INT64_MAX) - address) return false;
    // pread validates the address without directly dereferencing guest memory.
    const int fd = open("/proc/self/mem", O_RDONLY | O_CLOEXEC);
    if (fd < 0) return false;
    const ssize_t count = pread(fd, output, size, static_cast<off_t>(address));
    const int readErrno = errno;
    close(fd);
    errno = readErrno;
    return count == static_cast<ssize_t>(size);
}

bool readCString(uintptr_t address, size_t limit, std::string &output, MemoryReader reader) {
    output.clear();
    if (address == 0 || limit == 0 || limit > 4096 || reader == nullptr) return false;
#if defined(__aarch64__)
    address &= UINT64_C(0x00ffffffffffffff);
#endif
    const long pageResult = sysconf(_SC_PAGESIZE);
    if (pageResult <= 0) return false;
    const size_t page = static_cast<size_t>(pageResult);
    size_t consumed = 0;
    while (consumed < limit) {
        if (consumed > UINTPTR_MAX - address) break;
        const uintptr_t current = address + consumed;
        char buffer[64];
        const size_t count = std::min(sizeof(buffer),
                std::min(limit - consumed, page - current % page));
        if (!reader(current, buffer, count)) break;
        for (size_t index = 0; index < count; ++index) {
            const unsigned char ch = static_cast<unsigned char>(buffer[index]);
            if (ch == 0) return true;
            if (ch < 0x20 || ch > 0x7e) {
                output.clear();
                return false;
            }
            output.push_back(static_cast<char>(ch));
        }
        consumed += count;
    }
    output.clear();
    return false;
}

bool buildProbePath(const std::string &source, uint32_t euid,
                    const std::string &packageName, std::string &output) {
    output.clear();
    if (packageName.empty() || packageName.size() > 128) return false;
    for (const unsigned char ch : packageName) {
        if (!((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')
                || (ch >= '0' && ch <= '9') || ch == '_' || ch == '.')) return false;
    }
    std::string prefix;
    if (source.compare(0, 6, "/data/") == 0) {
        prefix = source.substr(0, 6);
    } else if (source.compare(0, 12, "/mnt/expand/") == 0 && source.size() >= 49) {
        prefix = source.substr(0, 49);
    } else {
        return false;
    }
    // The final helper 0x4d7b04 appends the cached guest package. The old probe
    // omitted that helper and therefore measured only the shared parent path.
    output = prefix + "user/" + std::to_string(euid / 100000) + "/" + packageName;
    return true;
}

bool matchesLoader(uintptr_t base, MemoryReader reader) {
    if (reader == nullptr) return false;
    struct Signature { size_t offset; size_t length; unsigned char bytes[76]; };
    static const Signature signatures[] = {
        {0x4de2d0, 56, {0xfd,0x7b,0xbe,0xa9,0xf3,0x0b,0x00,0xf9,0xfd,0x03,0x00,0x91,0xf3,0x53,0x00,0x90,0x73,0xd2,0x01,0x91,0x01,0x00,0x00,0x90,0x21,0x20,0x0c,0x91,0xe0,0x03,0x13,0xaa,0x1f,0x20,0x03,0xd5,0x84,0x68,0x0a,0x94,0x60,0xc2,0x43,0xf8,0xf3,0x0b,0x40,0xf9,0xfd,0x7b,0xc2,0xa8,0xc0,0x03,0x5f,0xd6}},
        {0x73cfe8, 24, {0xfd,0x7b,0xbc,0xa9,0xfc,0x5f,0x01,0xa9,0xf6,0x57,0x02,0xa9,0xf4,0x4f,0x03,0xa9,0xfd,0x03,0x00,0x91,0xff,0x0b,0x40,0xd1}},
        {0x73d254, 24, {0xfd,0x7b,0xba,0xa9,0xfc,0x6f,0x01,0xa9,0xfa,0x67,0x02,0xa9,0xf8,0x5f,0x03,0xa9,0xf6,0x57,0x04,0xa9,0xf4,0x4f,0x05,0xa9}},
        {0x78e9cc, 24, {0xe8,0x09,0x80,0xd2,0x01,0x00,0x00,0xd4,0x1f,0x04,0x40,0xb1,0x00,0x94,0x80,0xda,0xa8,0xee,0xff,0x54,0xc0,0x03,0x5f,0xd6}},
        {0x78e824, 24, {0xe8,0x15,0x80,0xd2,0x01,0x00,0x00,0xd4,0x1f,0x04,0x40,0xb1,0x00,0x94,0x80,0xda,0xe8,0xfb,0xff,0x54,0xc0,0x03,0x5f,0xd6}},
        {0x4d7b24,28,{0x00,0x54,0x00,0xf0,0x01,0x00,0x00,0xb0,0x95,0xdd,0x8b,0x52,0x00,0xa0,0x01,0x91,0x21,0xd0,0x0b,0x91,0x15,0xd8,0xad,0x72,0x72,0x82,0x0a,0x94}},
        {0x4d7c20,36,{0x02,0x54,0x00,0xf0,0x42,0x8c,0x09,0x91,0xe6,0x03,0x14,0xaa,0xc0,0x02,0x1f,0xd6,0xea,0x03,0x06,0xaa,0x56,0x00,0x40,0x39,0xf1,0x03,0x07,0xaa,0x56,0x15,0x00,0x38,0x36,0x04,0x00,0x34}},
        {0x4d82f4,76,{0x49,0x4e,0x00,0x90,0xff,0x03,0x1f,0xaa,0xff,0x03,0x1f,0x8a,0x29,0x41,0x40,0xf9,0x0b,0x54,0x00,0xd0,0xe8,0x03,0x1f,0xaa,0xaa,0x0a,0x80,0x52,0x29,0x01,0x40,0xf9,0x6b,0x81,0x01,0x91,0x2c,0x69,0x68,0x38,0x6d,0x01,0x08,0x8b,0x8c,0x01,0x0a,0x4a,0x9f,0x1d,0x00,0x72,0xac,0x0d,0x08,0x39,0x80,0x00,0x00,0x54,0x1f,0x01,0x02,0xf1,0x08,0x05,0x00,0x91,0x01,0xff,0xff,0x54,0xc0,0x03,0x5f,0xd6}}
    };
    for (const Signature &signature : signatures) {
        if (signature.offset > UINTPTR_MAX - base) return false;
        unsigned char actual[76];
        if (!reader(base + signature.offset, actual, signature.length)
                || memcmp(actual, signature.bytes, signature.length) != 0) return false;
    }
    return true;
}
}

namespace {
struct Module { uintptr_t base = 0; bool found = false; };

int findLoader(struct dl_phdr_info *info, size_t, void *context) {
    if (info->dlpi_name == nullptr) return 0;
    const char *name = strrchr(info->dlpi_name, '/');
    name = name == nullptr ? info->dlpi_name : name + 1;
    if (strcmp(name, "libloader.so") != 0) return 0;
    Module *module = static_cast<Module *>(context);
    module->base = static_cast<uintptr_t>(info->dlpi_addr);
    module->found = true;
    return 1;
}

void logStat(const char *label, const char *path, uid_t euid) {
    struct stat result{};
    errno = 0;
    const long status = syscall(__NR_newfstatat, AT_FDCWD, path, &result, 0);
    const int error = status == 0 ? 0 : errno;
    if (status == 0) {
        ALOGD("AvisNativeIO: %s path=%s status=0 owner=%u euid=%u ownerMatch=%d",
                label, path, static_cast<unsigned>(result.st_uid),
                static_cast<unsigned>(euid), result.st_uid == euid);
    } else {
        ALOGD("AvisNativeIO: %s path=%s status=%ld errno=%d euid=%u",
                label, path, status, error, static_cast<unsigned>(euid));
    }
}
}

void logGuestFilesystemState(JNIEnv *env, jclass, jstring dataDir) {
    const int savedErrno = errno;
    const uid_t euid = static_cast<uid_t>(syscall(__NR_geteuid));
    ALOGD("AvisNativeIO: probe=v2 pid=%d euid=%u", getpid(), static_cast<unsigned>(euid));
    if (dataDir != nullptr) {
        const char *path = env->GetStringUTFChars(dataDir, nullptr);
        if (path != nullptr) {
            logStat("guestDataDir", path, euid);
            env->ReleaseStringUTFChars(dataDir, path);
        }
    }
#if defined(__aarch64__)
    Module module;
    dl_iterate_phdr(findLoader, &module);
    if (module.found) guest_event_diagnostics::logSnapshot(module.base);
    atomic_guest_path::logStats();
    if (!module.found || !guest_fs_diagnostics::matchesLoader(module.base)) {
        ALOGD("AvisNativeIO: cache snapshot unavailable: module absent or fingerprint mismatch");
    } else {
        // Cache slots are read only after their supplying code signatures match.
        uintptr_t pointer = 0;
        std::string source;
        if (!guest_fs_diagnostics::readMemory(module.base + 0xf5a0b0, &pointer, sizeof(pointer))
                || !guest_fs_diagnostics::readCString(pointer, 1024, source)) {
            ALOGD("AvisNativeIO: cached source unavailable or uninitialized");
        } else {
            ALOGD("AvisNativeIO: cachedSource=%s", source.c_str());
            std::string path, packageName;
            if (!guest_fs_diagnostics::readCString(module.base + 0xf5a263, 129, packageName)) {
                ALOGD("AvisNativeIO: expected guest package unavailable");
            } else if (guest_fs_diagnostics::buildProbePath(source, euid, packageName, path)) {
                ALOGD("AvisNativeIO: expectedGuestPackage=%s", packageName.c_str());
                logStat("ownerProbe", path.c_str(), euid);
            } else {
                ALOGD("AvisNativeIO: ownerProbe path builder declined this source");
            }
        }
    }
#else
    ALOGD("AvisNativeIO: supplied loader cache layout is ARM64-only");
#endif
    errno = savedErrno;
}
