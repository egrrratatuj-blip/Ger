#include "AtomicGuestPath.h"
#include "GuestFilesystemDiagnostics.h"
#include "Log.h"
#include <atomic>
#include <cerrno>
#include <cstring>
#include <initializer_list>
#include <cstdio>
#include <link.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/prctl.h>
#include <sys/syscall.h>
#include <sys/uio.h>
#include <unistd.h>
#include <fcntl.h>

namespace atomic_guest_path {
namespace {
constexpr size_t CAP=1024;
struct Rule { char from[CAP],to[CAP]; } rules[4];
std::atomic<bool> armed{false},installed{false};
std::atomic_flag attaching=ATOMIC_FLAG_INIT;
std::atomic<unsigned> mappedCount{0},passedCount{0};
thread_local bool loading=false;
thread_local char destination[CAP];
bool put(Rule &r,const char *from,const char *to) {
    if(!from||!to||to[0]!='/'||strlen(from)>=CAP||strlen(to)>=CAP)return false;
    strcpy(r.from,from);strcpy(r.to,to);return true;
}
const char *redirect(const char *source) {
    const int saved=errno;
    char input[CAP];
    bool readable=false;
    uintptr_t address=reinterpret_cast<uintptr_t>(source);
#if defined(__aarch64__)
    address&=UINT64_C(0x00ffffffffffffff);
#endif
    const long page=sysconf(_SC_PAGESIZE);
    if(address&&page>0)for(size_t offset=0;offset<CAP;) {
        if(address>UINTPTR_MAX-offset)break;
        size_t n=CAP-offset;if(n>32)n=32;
        size_t remaining=static_cast<size_t>(page)-(address+offset)%static_cast<size_t>(page);if(n>remaining)n=remaining;
        struct iovec local{input+offset,n},remote{reinterpret_cast<void*>(address+offset),n};
        // Unlike /proc/self/mem, process_vm_readv does not force access to unreadable VMAs.
        if(syscall(__NR_process_vm_readv,static_cast<long>(getpid()),&local,1UL,&remote,1UL,0UL)!=static_cast<long>(n))break;
        if(memchr(input+offset,0,n)){readable=true;break;}
        offset+=n;
    }
    const char *result=source;
    if(readable) {
        const size_t size=strlen(input);
        for(const Rule &r:rules) {
            const size_t n=strlen(r.from);
            if(size<n||strncmp(input,r.from,n)!=0)continue;
            if(size>n&&input[n]!='/')continue;
            const size_t m=strlen(r.to),tail=size-n;
            if(m+tail>=CAP)break;
            memcpy(destination,r.to,m);memcpy(destination+m,input+n,tail+1);
            result=destination;break;
        }
    }
    if(result==source)passedCount.fetch_add(1,std::memory_order_relaxed);
    else mappedCount.fetch_add(1,std::memory_order_relaxed);
    errno=saved;return result;
}
#if defined(__aarch64__)
extern "C" char avis_stat_stub_start[],avis_stat_stub_end[],avis_stat_stub_branch[],avis_stat_stub_callback[];
bool branch(uintptr_t from,uintptr_t to,uint32_t &code) {
    const int64_t delta=static_cast<int64_t>(to)-static_cast<int64_t>(from);
    if((from&3)||(to&3)||delta<-(INT64_C(1)<<27)||delta>=(INT64_C(1)<<27))return false;
    code=0x14000000U|(static_cast<uint32_t>(delta/4)&0x03ffffffU);return true;
}
int permission(uintptr_t address) {
    FILE *maps=fopen("/proc/self/maps","re");if(!maps)return -1;
    char line[1024],modes[5];unsigned long begin,end;int result=-1;
    while(fgets(line,sizeof(line),maps)) {
        if(sscanf(line,"%lx-%lx %4s",&begin,&end,modes)!=3)continue;
        if(address<begin||address>=end)continue;
        result=(modes[0]=='r'?PROT_READ:0)|(modes[1]=='w'?PROT_WRITE:0)|(modes[2]=='x'?PROT_EXEC:0);break;
    }
    fclose(maps);return result;
}
int locate(dl_phdr_info *info,size_t,void *out) {
    if(!info->dlpi_name)return 0;
    const char *name=strrchr(info->dlpi_name,'/');name=name?name+1:info->dlpi_name;
    if(strcmp(name,"libloader.so"))return 0;
    *static_cast<uintptr_t*>(out)=info->dlpi_addr;return 1;
}
void attach() {
    if(!armed.load(std::memory_order_acquire)||installed.load()||attaching.test_and_set())return;
    uintptr_t base=0;dl_iterate_phdr(locate,&base);
    if(!base||!guest_fs_diagnostics::matchesLoader(base)) {
        ALOGD("AvisAtomicFs: active=0 stage=fingerprint");attaching.clear();return;
    }
    const uintptr_t target=base+0x73d06c;
    // Concurrent modification is restricted by AArch64 CMODX: BL -> BL only.
    const long supported=syscall(__NR_membarrier,0,0,0);
    if(supported<0||(supported&96)!=96||syscall(__NR_membarrier,64,0,0)!=0) {
        ALOGD("AvisAtomicFs: active=0 stage=sync-core-unavailable errno=%d",errno);attaching.clear();return;
    }
    const long page=sysconf(_SC_PAGESIZE);int prot=permission(target);
    const size_t length=static_cast<size_t>(reinterpret_cast<uintptr_t>(avis_stat_stub_end)-reinterpret_cast<uintptr_t>(avis_stat_stub_start));
    if(page<=0||length>static_cast<size_t>(page)||prot<0||!(prot&PROT_EXEC)) {
        ALOGD("AvisAtomicFs: active=0 stage=permissions");attaching.clear();return;
    }
    void *memory=MAP_FAILED;uint32_t entry=0,back=0;
    const size_t branchOffset=reinterpret_cast<uintptr_t>(avis_stat_stub_branch)-reinterpret_cast<uintptr_t>(avis_stat_stub_start);
    for(uintptr_t distance=0x10000;distance<0x07800000&&memory==MAP_FAILED;distance+=0x200000) {
        for(int sign:{1,-1}) {
            if(sign<0&&target<distance)continue;
            uintptr_t hint=(sign>0?target+distance:target-distance)&~(static_cast<uintptr_t>(page)-1);
            void *candidate=mmap(reinterpret_cast<void*>(hint),page,PROT_READ|PROT_WRITE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
            if(candidate==MAP_FAILED)continue;
            uintptr_t address=reinterpret_cast<uintptr_t>(candidate);
            if(branch(target,address,entry)&&branch(address+branchOffset,base+0x78e9cc,back)){memory=candidate;break;}
            munmap(candidate,page);
        }
    }
    if(memory==MAP_FAILED){ALOGD("AvisAtomicFs: active=0 stage=near-allocation");attaching.clear();return;}
    entry|=0x80000000U; // BL keeps the original caller return address.
    memcpy(memory,avis_stat_stub_start,length);
    memcpy(static_cast<char*>(memory)+branchOffset,&back,4);
    uintptr_t callback=reinterpret_cast<uintptr_t>(redirect);
    memcpy(static_cast<char*>(memory)+(reinterpret_cast<uintptr_t>(avis_stat_stub_callback)-reinterpret_cast<uintptr_t>(avis_stat_stub_start)),&callback,8);
    __builtin___clear_cache(static_cast<char*>(memory),static_cast<char*>(memory)+length);
    if(mprotect(memory,page,PROT_READ|PROT_EXEC)!=0){munmap(memory,page);attaching.clear();return;}
    const uintptr_t targetPage=target&~(static_cast<uintptr_t>(page)-1);
    if(mprotect(reinterpret_cast<void*>(targetPage),page,prot|PROT_WRITE)!=0){munmap(memory,page);attaching.clear();return;}
    uint32_t original=0;branch(target,base+0x78e9cc,original);original|=0x80000000U;
    uint32_t expected=original; // The original owner-detector BL, not its syscall stub.
    bool published=__atomic_compare_exchange_n(reinterpret_cast<uint32_t*>(target),&expected,entry,false,__ATOMIC_SEQ_CST,__ATOMIC_SEQ_CST);
    __builtin___clear_cache(reinterpret_cast<char*>(target),reinterpret_cast<char*>(target+4));
    const int restore=mprotect(reinterpret_cast<void*>(targetPage),page,prot);
    // Once published, a stub stays mapped for the life of the process, including rollback.
    if(!published){munmap(memory,page);attaching.clear();return;}
    if(restore!=0) {
        __atomic_store_n(reinterpret_cast<uint32_t*>(target),original,__ATOMIC_SEQ_CST);
        __builtin___clear_cache(reinterpret_cast<char*>(target),reinterpret_cast<char*>(target+4));
        mprotect(reinterpret_cast<void*>(targetPage),page,prot);
        ALOGD("AvisAtomicFs: active=0 stage=permission-rollback errno=%d",errno);return;
    }
    const long synchronized=syscall(__NR_membarrier,32,0,0);
    const int syncError=synchronized==0?0:errno;
    installed.store(true);
    struct stat alias{},real{};
    using StatCall=long(*)(int,const char*,void*,int);
    long status=reinterpret_cast<StatCall>(memory)(AT_FDCWD,rules[3].from,&alias,0);
    int error=errno;int physical=fstatat(AT_FDCWD,rules[3].to,&real,0);
    ALOGD("AvisAtomicFs: active=1 patchBytes=4 ownerCallOnly=1 syncCoreErrno=%d noNewPrivs=%d aliasStatus=%ld aliasErrno=%d realStatus=%d sameObject=%d",
        syncError,prctl(PR_GET_NO_NEW_PRIVS,0,0,0,0),status,status?error:0,physical,status==0&&physical==0&&alias.st_dev==real.st_dev&&alias.st_ino==real.st_ino&&alias.st_uid==real.st_uid);
}
#endif
}
bool configure(const char *package,const char *data,const char *library,int user) {
    if(armed.load())return true;
    if(!package||strcmp(package,"com.catsbit.oxidesurvivalisland")||!data||!library||user<0)return false;
    char a[CAP],b[CAP],c[CAP],d[CAP];
    snprintf(a,CAP,"/data/data/%s/lib",package);snprintf(b,CAP,"/data/user/%d/%s/lib",user,package);
    snprintf(c,CAP,"/data/data/%s",package);snprintf(d,CAP,"/data/user/%d/%s",user,package);
    if(!put(rules[0],a,library)||!put(rules[1],b,library)||!put(rules[2],c,data)||!put(rules[3],d,data))return false;
    armed.store(true,std::memory_order_release);
    ALOGD("AvisAtomicFs: armed=1 mode=owner-callsite-bl");return true;
}
bool beginLoad(const char *name){bool previous=loading;if(name){const char *base=strrchr(name,'/');if(!strcmp(base?base+1:name,"libloader.so"))loading=true;}return previous;}
void endLoad(bool previous,bool success){
#if defined(__aarch64__)
    if(loading&&!previous&&success)attach();
#endif
    loading=previous;
}
bool active(){return installed.load();}
void logStats(){ALOGD("AvisAtomicFs: snapshot active=%d mapped=%u passed=%u",installed.load(),mappedCount.load(),passedCount.load());}
}
